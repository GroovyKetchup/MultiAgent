package bap.java;

import com.cdao.mgr.CDao;
import com.cdao.mgr.CDaoClient;
import com.leavay.common.util.ToolUtilities;

// 提供一些基础的功能，如Dao相关的、日志、翻译等
public abstract class BapMgr
{
    public CDao newDao() throws Exception
    {
        return CDaoClient.getMe().newDao();
    }
    
    public String getString(String s)
    {
        return s;
    }
    
    public abstract String getLog();
    
    public void out(String s)
    {
        System.out.println(s);
    }
    
    public void error(String msg, Throwable err)
    {
        ToolUtilities.error(getLog(), msg, err);
    }
    
    public void error(String msg)
    {
        ToolUtilities.error(getLog(), msg);
    }
    
    public void warn(String msg)
    {
        ToolUtilities.warning(getLog(), msg);
    }
    
    public void warn(String msg, Throwable err)
    {
        ToolUtilities.warning(getLog(), msg, err);
    }
    
    public void info(String msg)
    {
        ToolUtilities.info(getLog(), msg);
    }
}
