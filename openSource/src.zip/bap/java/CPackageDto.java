package bap.java;

import com.leavay.common.util.javac.CompileStastic;
import com.leavay.ms.cmn.DtoIntf;
import com.leavay.ms.tool.CmnUtil;

// 虚拟的包对象，实际后台并没有存这个到库里
public class CPackageDto implements DtoIntf, CJavaGuiCompilable
{
    private static final long serialVersionUID = 6420191010610979399L;
    
    String projectUuid;
    String packagePath;
    

    CompileStastic compileStastic;
    
    public String getProjectUuid()
    {
        return projectUuid;
    }

    public void setProjectUuid(String projectUuid)
    {
        this.projectUuid = projectUuid;
    }

    public String getPackagePath()
    {
        return packagePath;
    }

    public void setPackagePath(String packagePath)
    {
        this.packagePath = packagePath;
    }

    public String getKey()
    {
        return packagePath;
    }

    public CompileStastic getCompileStastic()
    {
        return compileStastic;
    }

    public void setCompileStastic(CompileStastic compileStastic)
    {
        this.compileStastic = compileStastic;
    }

    public String toString()
    {
        return CmnUtil.getString(getPackagePath(), "");
    }
}
