package bap.java;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cplugin.ms.dto.CResFileDto;

public class CommitPackage implements Serializable
{

    private static final long serialVersionUID = 1826081255487488315L;

    String comments;
    
    // 源码的增删列表
    Map<String, List<CJavaCode>> mapFolder2Codes; // 要提交的java代码，Key是所属Folder的名字
    Map<String, Set<String>> deleteCodeMap; //要删除的类全名，key是所属Folder的名字
    
    // 资源文件增删列表
    Map<String, List<CResFileDto>> mapFolder2Files; // 要提交的资源文件对象，Key是所属Folder的名字
    Map<String, Set<String>> deleteFileMap; // 要删除的资源文件的相对路径，相对于所属Folder的路径，例如：com/res/lang_zh.prop(key是所属Folder的名字)
    public String getComments()
    {
        return comments;
    }
    public void setComments(String comments)
    {
        this.comments = comments;
    }
    public Map<String, List<CJavaCode>> getMapFolder2Codes()
    {
        return mapFolder2Codes;
    }
    public void setMapFolder2Codes(Map<String, List<CJavaCode>> mapFolder2Codes)
    {
        this.mapFolder2Codes = mapFolder2Codes;
    }
    public Map<String, List<CResFileDto>> getMapFolder2Files()
    {
        return mapFolder2Files;
    }
    public void setMapFolder2Files(Map<String, List<CResFileDto>> mapFolder2Files)
    {
        this.mapFolder2Files = mapFolder2Files;
    }
    public Map<String, Set<String>> getDeleteCodeMap()
    {
        return deleteCodeMap;
    }
    public void setDeleteCodeMap(Map<String, Set<String>> deleteCodeMap)
    {
        this.deleteCodeMap = deleteCodeMap;
    }
    public Map<String, Set<String>> getDeleteFileMap()
    {
        return deleteFileMap;
    }
    public void setDeleteFileMap(Map<String, Set<String>> deleteFileMap)
    {
        this.deleteFileMap = deleteFileMap;
    }
    
}
