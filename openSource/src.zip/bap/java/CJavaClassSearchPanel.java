package bap.java;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.table.DefaultTableCellRenderer;

import com.leavay.client.util.MBox;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SortButtonRenderer;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.dfc.mgr.javaDev.ClassNameInfoExt;
import com.leavay.dfc.mgr.javaDev.JavaClassSearchPanel;
import com.project.gui.common.BasicDockView;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import bap.client.BapClient;

public class CJavaClassSearchPanel extends BasicDockView
{
    public JLabel jLab_Key = new JLabel(GuiUtil.getString("Enter type name prefix or pattern (*, or camel case)")+" : ");
    public JTextField jTxt_Key = new JTextField();
    public SortButtonRenderer.SortableModel _model = new SortButtonRenderer.SortableModel();
    public JTable jTbl_Result = new JTable(_model);
    public JCheckBox jChk_SearchJar = new JCheckBox(GuiUtil.getString("Search in jar files"));
    
    public CJavaClassSearchPanel()
    {
        super();
        
        jbInit();
    }
    
    public class MyRenderer extends DefaultTableCellRenderer
    {
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (value != null && value instanceof ClassNameInfoExt)
            {
                ClassNameInfoExt info = (ClassNameInfoExt) value;
                if (!ToolUtilities.isStringEmpty(info.getCodeRDN()))
                {
                    setText("<html>"+info.getClassSimpleName() + "<font size=3 color=gray> - " +info.getClassFullName()+"</font> - "+ info.getProjectName()+ "</html>" );
                    setIcon(GuiResource.getIcon("com/ide/class_normal.png"));
                }
                else
                {
                    setIcon(GuiResource.getIcon("com/ide/class_zip.png"));
                    setText("<html>"+info.getClassSimpleName() + "<font size=3 color=gray> - " +LvJavac.getPackageFromFullClass(info.getClassFullName())+" - "+ info.getProjectName()+"/"+ToolUtilities.getPureFileName(info.getSrcPath())+"</font></html>" );
                }
                if (info.isInterface())
                    setIcon(GuiResource.getIcon("com/ide/interface.png"));
                
            }
            return this;
        }
    }
    
    public void jbInit()
    {
        _model.addColumn("Result");
        jTbl_Result.getTableHeader().setVisible(false);
        jTbl_Result.getTableHeader().setPreferredSize(new Dimension(0, 0));
        jTbl_Result.getColumnModel().getColumn(0).setCellRenderer(new MyRenderer());
        jTbl_Result.setShowHorizontalLines(false);
        jTbl_Result.setShowVerticalLines(false);
        jTbl_Result.setRowHeight(24);
        jTbl_Result.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() >= 2 && e.getButton() == MouseEvent.BUTTON1)
                    ((JSimpleDialog)GuiUtil.getWindowForComponent(CJavaClassSearchPanel.this)).OnBtnOK();
            }
        });
        
        Box mainBox = Box.createVerticalBox();
        mainBox.add(MBox.VStrut(5));
        mainBox.add(MBox.createHBar(22, jLab_Key));
        mainBox.add(MBox.VStrut(5));
        mainBox.add(MBox.createHBar(22, jTxt_Key));
        mainBox.add(MBox.VStrut(5));
        mainBox.add(MBox.createHBar(22, new JLabel(GuiUtil.getString("Matching items")+" : ")));
        mainBox.add(MBox.VStrut(5));
        mainBox.add(new JScrollPane(jTbl_Result));
        mainBox.add(MBox.VStrut(5));
        mainBox.add(MBox.createHBar(22, jChk_SearchJar, MBox.HGlue()));
        mainBox.add(MBox.VStrut(5));
        mainBox.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        this.setLayout(new GridLayout(1,1));
        this.add(mainBox);
        
        jChk_SearchJar.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                OnSearch();
            }
        });
        GuiUtil.MyDocumentListener lsnr = new GuiUtil.MyDocumentListener()
        {
            public void fireDocumentChanged(DocumentEvent e)
            {
                OnSearch();
            }
        };
        jTxt_Key.getDocument().addDocumentListener(lsnr);
        jTxt_Key.addKeyListener(new KeyAdapter()
        {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP)
                    OnKeyUp();
                else if (e.getKeyCode() == KeyEvent.VK_DOWN)
                    OnKeyDown();
            }
        });
    }

    LazyPool _lazySearch = new LazyPool(200)
    {
        public void handle(List objects)
        {
            List<ClassNameInfoExt> lstClazz = null;
            try
            {
                lstClazz = BapClient.getJavaIntf().searchCode(jTxt_Key.getText(), jChk_SearchJar.isSelected(), 50);
            } catch (Exception exp)
            {
                exp.printStackTrace();
            }
            
            if (false) showData(lstClazz);
            GuiUtil.invokeLater(CJavaClassSearchPanel.this, "showData", lstClazz);
        }
    };
    
    public void showData(List<ClassNameInfoExt> lstClazz )
    {
        try
        {
            while (_model.getRowCount() > 0)
                _model.removeRow(0);

            if (!ToolUtilities.isObjectEmpty(lstClazz))
            {
                Collections.sort(lstClazz, new Comparator<ClassNameInfoExt>()
                {
                    public int compare(ClassNameInfoExt o1, ClassNameInfoExt o2)
                    {
                        try
                        {
                            int length = Integer.compare(o1.getClassSimpleName().length(), o2.getClassSimpleName().length());
                            if (length != 0)
                                return length;

                            return ToolUtilities.compareString(o1.getClassSimpleName(), o2.getClassSimpleName());
                        } catch (Throwable err)
                        {
                            return 0;
                        }
                    }
                });

                for (ClassNameInfoExt clzz : lstClazz)
                    _model.addRow(new Object[] { clzz });

                jTbl_Result.getSelectionModel().setSelectionInterval(0, 0);
            }
        } catch (Throwable exp)
        {
            DetailErrorMsg.showError(this, exp);
        }
    }
    
    public void OnSearch()
    {
        _lazySearch.add(System.currentTimeMillis());
    }

    public void OnKeyUp()
    {
        int iSelRow = jTbl_Result.getSelectedRow();
        if (iSelRow == 0)
            iSelRow = _model.getRowCount() - 1;
        else
            iSelRow--;

        jTbl_Result.getSelectionModel().setSelectionInterval(iSelRow, iSelRow);
        jTbl_Result.scrollRectToVisible(jTbl_Result.getCellRect(iSelRow, 0, false));
    }

    public void OnKeyDown()
    {

        int iSelRow = jTbl_Result.getSelectedRow();
        if (iSelRow >= _model.getRowCount() - 1)
            iSelRow = 0;
        else
            iSelRow++;

        jTbl_Result.getSelectionModel().setSelectionInterval(iSelRow, iSelRow);
        jTbl_Result.scrollRectToVisible(jTbl_Result.getCellRect(iSelRow, 0, false));
    }
    
    public CJavaCode getSelectCode() throws Exception
    {
        int selRow = jTbl_Result.getSelectedRow();
        if (selRow < 0)
            return null;
        
        ClassNameInfoExt info = (ClassNameInfoExt) _model.getValueAt(selRow, 0);
        if (info == null)
            return null;
        
        return BapClient.getJavaIntf().getJavaCode(info.getCodeRDN());
    }
    
    public ClassNameInfoExt getSelectClassInfo()
    {
        int selRow = jTbl_Result.getSelectedRow();
        if (selRow < 0)
            return null;
        
        return (ClassNameInfoExt) _model.getValueAt(selRow, 0);
    }
    
    public String getTypedText()
    {
        return jTxt_Key.getText();
    }
    
    public List<ClassNameInfoExt> getSelectCodes()
    {
        List<ClassNameInfoExt> lstRet = new ArrayList<ClassNameInfoExt>();
        int[] rows = jTbl_Result.getSelectedRows();
        if (rows == null)
            return lstRet;
        
        for (int row : rows)
        {
            ClassNameInfoExt info = (ClassNameInfoExt) _model.getValueAt(row, 0);
            if (info != null)
                lstRet.add(info);
        }
        
        return lstRet;
    }
    
    public ClassNameInfoExt getSelectClass()
    {
        int selRow = jTbl_Result.getSelectedRow();
        if (selRow < 0)
            return null;
        
        return (ClassNameInfoExt) _model.getValueAt(selRow, 0);
    }
}
