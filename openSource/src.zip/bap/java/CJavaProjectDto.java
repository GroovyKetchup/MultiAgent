package bap.java;

import com.cdao.dto.DaoDto;

public class CJavaProjectDto extends DaoDto
{
    private static final long serialVersionUID = 5918157044304992941L;

    public String name;
    
    public int dependType=CJavaConst.DEPEND_PLATFORM;
    
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    protected String initDaoClass()
    {
        return "bap.md.java.CJavaProject";
    }

    public int getDependType()
    {
        return dependType;
    }

    public void setDependType(int dependType)
    {
        this.dependType = dependType;
    }
    
    public boolean isDependIsolate()
    {
        return CJavaConst.DEPEND_ISOLATE == getDependType();
    }
    
    public boolean isDependPlatform()
    {
        return CJavaConst.DEPEND_PLATFORM == getDependType();
    }
    
    public boolean isDependPlugin()
    {
        return CJavaConst.DEPEND_PLUGIN == getDependType();
    }
    
    public boolean isUdfLib()
    {
        return CJavaConst.UDF_LIB == getDependType();
    }

    public String toString()
    {
        return getName();
    }
}
