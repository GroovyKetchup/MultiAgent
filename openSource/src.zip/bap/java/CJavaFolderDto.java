package bap.java;

import com.cdao.dto.DaoSlaveDto;
import com.cdao.impl.entity.field.GID;
import com.leavay.common.util.javac.CompileStastic;
import com.leavay.ms.tool.CmnUtil;

public class CJavaFolderDto extends DaoSlaveDto implements CJavaGuiCompilable
{
    private static final long serialVersionUID = 5588128074946743528L;
    
    public String name;
    
    public String privateOwner;

    // 主要用于界面缓存编译统计数据
    CompileStastic compileStastic;
    
    public void setProjectUuid(String pjUuid)
    {
        setMasterKey(pjUuid);
    }
    
    public String getProjectUuid()
    {
        return getMasterKey();
    }
    
    public GID getProjectGid()
    {
        return GID.build(getMasterClass(), getMasterKey());
    }
    
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    protected String initDaoClass()
    {
        return "bap.md.java.CJavaFolder";
    }


    public String getPrivateOwner()
    {
        return privateOwner;
    }

    public void setPrivateOwner(String privateOwner)
    {
        this.privateOwner = privateOwner;
    }

    public boolean isPrivateOwn()
    {
        return !CmnUtil.isStringEmpty(getPrivateOwner());
    }

    public String toString()
    {
        return CmnUtil.getNameAndLabel(getName(), getPrivateOwner());
    }

    public CompileStastic getCompileStastic()
    {
        return compileStastic;
    }

    public void setCompileStastic(CompileStastic compileStastic)
    {
        this.compileStastic = compileStastic;
    }
    
}
