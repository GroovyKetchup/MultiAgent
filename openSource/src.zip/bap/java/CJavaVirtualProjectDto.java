package bap.java;

public class CJavaVirtualProjectDto extends CJavaProjectDto
{
    private static final long serialVersionUID = 2481303117990398761L;

    protected String initDaoClass()
    {
        return "bap.md.java.CJavaVirtualProject";
    }
}
