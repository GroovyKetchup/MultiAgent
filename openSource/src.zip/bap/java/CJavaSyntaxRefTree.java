package bap.java;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.rmi.RemoteException;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.event.DocumentEvent;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreePath;

import com.cdao.mgr.CDaoClient;
import com.leavay.client.util.MBox;
import com.leavay.client.util.EventQ.GuiEvent;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.IntRange;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.ProgressCtrlPanel;
import com.leavay.common.util.ProgressCtrl.ProgressCtrlUtil;
import com.leavay.common.util.ProgressCtrl.SrvProgressIntf;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.dfc.gui.AllGuiEvents;
import com.project.gui.Javac.JavaEditor;
import com.project.gui.common.BasicDockView;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;

import bap.client.BapClient;
import bap.client.BapGuiConst;
import bap.client.BapGuiUtil;

public class CJavaSyntaxRefTree extends BasicDockView implements ActionListener
{
    MyNode _root = new MyNode(null);
    JTree jTree = new JTree(_root);
    JTextField jTxt_Search = new JTextField();
    ProgressCtrlPanel jProg = new ProgressCtrlPanel(){
        public void OnComponentResized()
        {
            
        }
    };
    Box jBoxProgress = Box.createHorizontalBox();
    JButton jBtn_Stop = GuiUtil.createToolButton("stop_16.png", "Stop Searching", this);
    
    public static class MyNode extends DefaultMutableTreeNode
    {
        CodeDeclareInfo _info;
        public MyNode(CodeDeclareInfo info)
        {
            _info = info;
        }
        
        public String toString()
        {
            return _info==null?"":_info.toString();
        }
    }
    
    
    final static Color _background = new Color(255, 255, 225);
    final static Color _selectBackground = new Color(214, 225, 242);
    
    class MyRenderer extends DefaultTreeCellRenderer
    {
        public MyRenderer()
        {
            setBackground(_background);
            setOpaque(true);
        }
        
        public Component getTreeCellRendererComponent(JTree tree, Object value,
                boolean sel,
                boolean expanded,
                boolean leaf, int row,
                boolean hasFocus) {
            super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
            
            if (sel)
                setBackground(_selectBackground);
            else
                setBackground(_background);
            
            if (value == null)
                return this;
            
                if (value instanceof MyNode && ((MyNode)value)._info != null)
                {
                    CodeDeclareInfo info =((MyNode)value)._info;
                    setText("<html>"+info.getCodeText() + "<font size=3 color=gray> - " +info.getDeclareClass() +"</font></html>" );
                    
                    switch (info.getType())
                    {
                    case CodeDeclareInfo.TYPE:
                        setIcon(GuiResource.getIcon("com/ide/class_normal.png"));
                        break;
                    case CodeDeclareInfo.METHOD:
                        if (info.isStatic())
                            setIcon(GuiResource.getIcon("com/ide/method_static.png"));
                        else
                            setIcon(GuiResource.getIcon("com/ide/method.png"));
                        break;
                    case CodeDeclareInfo.FIELD:
                        if (info.isStatic())
                            setIcon(GuiResource.getIcon("com/ide/field_static.png"));
                        else
                            setIcon(GuiResource.getIcon("com/ide/field_public.png"));
                        break;
                    case CodeDeclareInfo.INITIAL_BLOCK:
                    default:
                        setIcon(GuiResource.getIcon("com/ide/other.png"));
                        break;
                    }
                }

            return this;
        }
    }
    
    public CJavaSyntaxRefTree()
    {
        Box mainBox = Box.createVerticalBox();
        jTxt_Search.setBorder(null);
        jTxt_Search.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
        jTxt_Search.getDocument().addDocumentListener(new GuiUtil.MyDocumentListener()
        {
            public void fireDocumentChanged(DocumentEvent e)
            {
                refresh();
            }
        });
        jTxt_Search.setBackground(_background);
        mainBox.add(jTxt_Search);
        
        GuiUtil.setFixedSize(jBtn_Stop, 22, 18);
        jBtn_Stop.setBorder(null);
        GuiUtil.setFixedSize(jProg.jProg, 120, 18);
        jBoxProgress.setMaximumSize(new Dimension(Integer.MAX_VALUE, 18));
        jBoxProgress.setVisible(false);
        jBoxProgress.add(jBtn_Stop);
        jBoxProgress.add(MBox.HStrut(2));
        jBoxProgress.add(jProg.jProg);
        jBoxProgress.add(MBox.HStrut(4));
        jBoxProgress.add(jProg.jLab_Msg);
        jProg.jLab_Msg.setPreferredSize(new Dimension(160, 18));
        mainBox.add(jBoxProgress);
        mainBox.add(MBox.VStrut(1));
        

        jTree.setBackground(_background);
        jTree.setToggleClickCount(0);
      
        JScrollPane jScrTree = new JScrollPane(jTree);
        jScrTree.setBorder(BorderFactory.createLineBorder(Color.gray));
        mainBox.add(jScrTree);
        this.setLayout(new GridLayout(1,1));
        this.add(mainBox);
        jTree.setRootVisible(false);
        jTree.setCellRenderer(new MyRenderer());
        jTree.setRowHeight(22);
        this.setPreferredSize(new Dimension(500,  500));
        
        jTxt_Search.addKeyListener(new KeyAdapter()
        {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP)
                    OnKeyUp();
                else if (e.getKeyCode() == KeyEvent.VK_DOWN)
                    OnKeyDown();
            }
        });
    }
    
    public void setProject(String uuid)
    {
        _projectUuid = uuid;
    }
    
    String _projectUuid = null;
    List<CodeDeclareInfo> _lstData = null;
    public void showData(String projectUuid, List<CodeDeclareInfo> lstData)
    {
        _projectUuid = projectUuid;
        _lstData = lstData;
        _root.removeAllChildren();
        if (lstData != null ) for (CodeDeclareInfo data : lstData)
            insertNode(_root, data);
        
        filterTreeNode();
        
        GuiUtil.updateTreeNode(jTree, _root);
        GuiUtil.expandTree(jTree, _root, 1);
        for (int i=0; i<jTree.getRowCount(); i++)
        {
            MyNode node = (MyNode) jTree.getPathForRow(i).getLastPathComponent();
            if (node.isLeaf())
            {
                jTree.setSelectionRow(i);
                break;
            }
        }
        
        jTree.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() >= 2)
                {
                    try
                    {
                        OnDBClick();
                    } catch (Exception exp)
                    {
                        DetailErrorMsg.showError(CJavaSyntaxRefTree.this, exp);
                    }
                }
            }
        });
        
    }
    
    public void refresh()
    {
        _lazyRefresh.add(1);
    }
    
    LazyPool _lazyRefresh = new LazyPool(1000)
    {
        public void handle(List objects)
        {
            try
            {
                doSearchText(_projectUuid, jTxt_Search.getText());
            }catch(Throwable err)
            {
                err.printStackTrace();
            }
        }
    };
    
    public MyNode insertNode(MyNode pNode, CodeDeclareInfo info)
    {
        if (info == null)
            return null;
        MyNode node = new MyNode(info);
        GuiUtil.insertTreeNode(jTree, pNode, node);
      
        if (!ToolUtilities.isObjectEmpty(info.getChildren()))
        {
            for (CodeDeclareInfo sub : info.getChildren())
            {
                if (sub.isMethod() || sub.isField() || sub.isInitialBlock())
                    insertNode(node, sub);
            }
        }

        return node;
    }
    
    public void filterTreeNode()
    {
        String sFilter = jTxt_Search.getText();
        if (ToolUtilities.isStringEmpty(sFilter) || sFilter.equals("*"))
            return;
        
        String reg = ToolUtilities.convertString2Regular(sFilter, true, true);
        filterTreeNode(_root, reg);
        GuiUtil.updateTreeNode(jTree, _root);
    }
    
    protected void filterTreeNode(MyNode rootNode, String reg)
    {
        if (rootNode.isLeaf())
        {
            if (rootNode._info == null)
                return;
            
            String name = rootNode._info.getCodeText().toLowerCase();
            if (!name.matches(reg) && !name.startsWith(reg))
                rootNode.removeFromParent();
        }else
        {
            int iCnt = rootNode.getChildCount();
            for (int i = iCnt - 1; i >= 0; i--)
            {
                MyNode node = (MyNode) rootNode.getChildAt(i);
                filterTreeNode(node, reg);
            }
            if (rootNode.getChildCount() <= 0)
                rootNode.removeFromParent();
        }
    }
    
    public void OnKeyUp()
    {
        int[] selRows = jTree.getSelectionRows();
        if (selRows == null)
            return;
        int selRow = selRows[0];
        if (selRow <= 0)
            return;

        selRow--;
        jTree.setSelectionRow(selRow);
        jTree.scrollRowToVisible(selRow);
    }

    public void OnKeyDown()
    {
        int[] selRows = jTree.getSelectionRows();
        if (selRows == null)
            return;
        int selRow = selRows[0];
        if (selRow >= jTree.getRowCount()-1)
            return;

        selRow++;
        jTree.setSelectionRow(selRow);
        jTree.scrollRowToVisible(selRow);
    }
    
    static class MyPopup extends JPopupMenu
    {
        JLabel labStatus = new JLabel();
        protected static Dimension lastSize = null;
        public void showMyPopup(Component parent, int iX, int iY)
        {
            final JLabel label = new JLabel(GuiResource.getIcon("com/ide/resize_16.png"));
            label.setCursor(new Cursor(Cursor.SE_RESIZE_CURSOR));
            label.addMouseMotionListener(new MouseMotionAdapter(){
                public void mouseDragged(MouseEvent e) {
                    MyPopup.this.setSize(20, 20);
                    
                    Point ptlabel = label.getLocationOnScreen();
                    ptlabel.x += e.getPoint().x;
                    ptlabel.y += e.getPoint().y;
                    
                    Point ptMenu = MyPopup.this.getLocationOnScreen();
                    lastSize = new Dimension(ptlabel.x + label.getWidth()/2 - ptMenu.x, ptlabel.y + label.getHeight()/2 - ptMenu.y);
                    MyPopup.this.setPopupSize(lastSize);
                    e.consume();
                }
            });
            
            labStatus.setForeground(Color.blue);
            add(MBox.createHBar(22, labStatus, MBox.HGlue(), label));
            
            if (lastSize != null)
            {
                setPopupSize(lastSize);
            }
            
            // Auto adjust screen position
            pack();
            show(parent, iX, iY);
            GuiUtil.adjustWindowInsideScreen(this);
        }
    }
    
    public void showPopup(final JavaEditor javaEditor)
    {
        final MyPopup popup = new MyPopup();
        popup.add(this);
        popup.pack();
        popup.validate();
        popup.showMyPopup(javaEditor, (int) ((javaEditor.getWidth()-popup.getPreferredSize().getWidth())/2), 0);
        jTxt_Search.grabFocus();
        GuiUtil.addKeyAdapterToComponent(new KeyAdapter(){
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    TreePath path = jTree.getSelectionPath();
                    if (path == null)
                        return;
                    MyNode node = (MyNode) path.getLastPathComponent();
                    if (node._info == null || !node._info.hasValidPosition())
                        return;
                    
                    javaEditor.selectRange(new IntRange(node._info.getSourceStart(), node._info.getSourceEnd()+1));
                    popup.setVisible(false);
                }
            }
        }, popup, true);
    }
    
    public CodeDeclareInfo getSelectItem()
    {
        TreePath path = jTree.getSelectionPath();
        if (path == null)
            return null;
        MyNode node = (MyNode) path.getLastPathComponent();
        if (node._info == null)
            return null;
        
        return node._info;
    }
    
    public void OnDBClick() throws Exception
    {
        CodeDeclareInfo dec = getSelectItem();
        if (dec == null || !dec.hasValidPosition())
            return;

        CJavaCode code = BapClient.getJavaIntf().getJavaCode(_projectUuid, dec.getDeclareClass());
        if (code == null)
            throw new Exception("Can not find class in this project : " + dec.getDeclareClass());
        
        IntRange range = null;
        if (dec.hasChildren())
            range = new IntRange(dec.getChildren().get(0).getSourceStart(), dec.getChildren().get(0).getSourceEnd());
        else if (dec.hasValidPosition())
            range = new IntRange(dec.getSourceStart(), dec.getSourceEnd()-1);
        else
            return;
        
        BapGuiUtil.openCode(code);
        BapGuiUtil.fireAsyncGuiEvent(BapGuiConst.SELECT_CJAVA_CODE, code.getUuid(), range);
    }
    

    public void stopCurrProgress()
    {
        jProg.setCancel(true);
        try
        {
            if (_srvProg != null)
                _srvProg.setCancel(true);
        } catch (RemoteException exp)
        {
            exp.printStackTrace();
        }

        jBoxProgress.setVisible(false);
        jTxt_Search.setVisible(true);
    }
    
    public void startProgress()
    {
        jProg.reset();
        jBoxProgress.setVisible(true);
        jTxt_Search.setVisible(false);
        this.updateUI();
    }
    
    public void actionPerformed(ActionEvent e)
    {
        try
        {
            if (e.getSource() == jBtn_Stop)
                stopCurrProgress();
        } catch (Throwable err)
        {
            DetailErrorMsg.showError(this, err);
        }
    }
    
    public void OnSearchSyntaxReference(GuiEvent evt)
    {
        try
        {
            CJavaCode code = (CJavaCode) evt.getParam(0);
            setProject(code.getProjectUuid());
            
            int currPos = evt.getInt(1);

            stopCurrProgress();
            startProgress();
            if (false) doSearchSyntax(code, "", currPos);
            ToolUtilities.asynCallFunction(this, "doSearchSyntax", code, "", currPos);
        }catch(Throwable err)
        {
            DetailErrorMsg.showError(this,  err);
        }
    }
    
    volatile SrvProgressIntf<List<CodeDeclareInfo>> _srvProg = null;
    public synchronized void doSearchSyntax(CJavaCode code , String selString, int currPos)
    {
        try
        {
            List lstData = null;
            _srvProg = BapClient.getJavaIntf().searchSyntaxReference(code, "", currPos);
            if (_srvProg != null)
            {
                ProgressCtrlUtil.startPollingServerProgress(_srvProg, jProg.getProgressImpl());
                lstData = _srvProg.getResult();
            }
            if (false)
                showData(code.getProjectUuid(), lstData);
            GuiUtil.invokeLater(this, "showData", code.getProjectUuid(), lstData);
        }catch(Throwable err)
        {
            err.printStackTrace();
        }finally
        {
            if (false) stopCurrProgress();
            GuiUtil.invokeLater(this, "stopCurrProgress", null);
        }
    }
    
    public void OnEvtSearchTextInCode(GuiEvent evt)
    {
        try
        {
            String pjUuid = evt.getString(0);
            String text = evt.getString(1);
            
            setProject(pjUuid);
            jTxt_Search.setText(text);
        }catch(Throwable err)
        {
            DetailErrorMsg.showError(this,  err);
        }
    }
    
    public synchronized void doSearchText(String projectUuid, String selString)
    {
        try
        {
            List lstData = null;
            _srvProg = BapClient.getJavaIntf().searchText(projectUuid, selString);
            if (_srvProg != null)
            {
                ProgressCtrlUtil.startPollingServerProgress(_srvProg, jProg.getProgressImpl());
                lstData = _srvProg.getResult();
            }
            if (false)
                showData(projectUuid, lstData);
            GuiUtil.invokeLater(this, "showData", projectUuid, lstData);
        }catch(Throwable err)
        {
            err.printStackTrace();
        }finally
        {
            if (false) stopCurrProgress();
            GuiUtil.invokeLater(this, "stopCurrProgress", null);
        }
    }
}
