package bap.java;

public class NoFolderException extends Exception
{
    private static final long serialVersionUID = -2498777111534564703L;
}
