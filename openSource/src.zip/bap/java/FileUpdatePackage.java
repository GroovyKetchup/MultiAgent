package bap.java;

import java.io.Serializable;
import java.util.List;

/**
 * 用于增量式传递文件更新包
 * 通常会有一个zip过的包, 删除文件列表, 其它标识等
 *
 */
public class FileUpdatePackage implements Serializable
{

    private static final long serialVersionUID = -8028067746394239915L;

    byte[] zipContent;
    
    List<String> deleteList;
    
    Object extData;

    public byte[] getZipContent()
    {
        return zipContent;
    }

    public FileUpdatePackage setZipContent(byte[] zipContent)
    {
        this.zipContent = zipContent;
        return this;
    }

    public List<String> getDeleteList()
    {
        return deleteList;
    }

    public FileUpdatePackage setDeleteList(List<String> deleteList)
    {
        this.deleteList = deleteList;
        return this;
    }

    public Object getExtData()
    {
        return extData;
    }

    public FileUpdatePackage setExtData(Object extData)
    {
        this.extData = extData;
        return this;
    }
}
