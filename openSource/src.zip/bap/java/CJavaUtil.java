package bap.java;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import org.apache.tools.ant.taskdefs.Classloader;
import org.nutz.dao.Cnd;
import org.nutz.dao.util.cri.Exps;
import org.nutz.dao.util.cri.SqlExpression;
import org.nutz.dao.util.cri.SqlExpressionGroup;

import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.BasicUdf;
import bap.md.java.CJavaCodeDo;
import bap.md.java.CResFileDo;
import cell.UdfIntf;
import cell.cdao.IDao;

public class CJavaUtil
{
    public static CJavaCode fromDo(CJavaCodeDo codeDo) throws Exception
    {
        return ToolBasic.copyFields(codeDo, new CJavaCode());
    }
    
    public static String toJarFileName(String projectName, String folderName)
    {
        return projectName+"__"+folderName+".jar";
    }
    
    public static String toFilePath(String fullClassName)
    {
        return ToolUtilities.replaceAll(fullClassName, ".", "/")+".java";
    }
    
    public static String newUdfCode(String pkg, String mainName)
    {
        StringBuffer sb = new StringBuffer();
        if (!CmnUtil.isStringEmpty(pkg))
            sb.append("package "+pkg+";\n\n");
        sb.append("import bap.cells.BasicUdf;\n");
        sb.append("public class "+mainName+ " extends " + BasicUdf.class.getSimpleName()+"\n{");

        sb.append("\n    //Main Entry Method :");
        sb.append("\n    public Object "+ UdfIntf.MAIN_METHOD+"()\n    {");
        sb.append("\n        return null;");
        sb.append("\n    }");
        sb.append("\n}");
        
        return sb.toString();
    }
    
    public static CJavaCodeDo queryCode(IDao dao, String className, boolean onlyBrief) throws Exception
    {
        String pkg = CmnUtil.getPackageFromFullClass(className);
        String simpleName = CmnUtil.getClassNameFromFull(className);
        Cnd cnd = Cnd.where(CJavaCodeDo.MainClass, "=", simpleName);
        if (CmnUtil.isStringEmpty(pkg))
            cnd.andIsBlankString(CJavaCodeDo.JavaPackage);
        else
            cnd.and(CJavaCodeDo.JavaPackage, "=", pkg);
      
        return dao.queryDo(CJavaCodeDo.class, cnd, onlyBrief?CJavaCodeDo.FIELDS_BRIEF:null);
    }
    
    public static String queryCodeUuid(IDao dao, String className) throws Exception
    {
        String pkg = CmnUtil.getPackageFromFullClass(className);
        String simpleName = CmnUtil.getClassNameFromFull(className);
        Cnd cnd = Cnd.where(CJavaCodeDo.MainClass, "=", simpleName);
        if (CmnUtil.isStringEmpty(pkg))
            cnd.andIsBlankString(CJavaCodeDo.JavaPackage);
        else
            cnd.and(CJavaCodeDo.JavaPackage, "=", pkg);
        
        return dao.queryString(CJavaCodeDo.class, cnd, CJavaCodeDo.UUID, null);
    }
    
    
    public static SqlExpression queryMetaExp(String className)
    {
        String pkg = CmnUtil.getPackageFromFullClass(className);
        String simpleName = CmnUtil.getClassNameFromFull(className);
        
        SqlExpressionGroup exp = Exps.begin().and(CResFileDo.FileName, "=", simpleName+"."+CJavaConst.CODE_META_FILE_EXT);
        if (CmnUtil.isStringEmpty(pkg))
            exp.and(Exps.isStringBlank(CResFileDo.FilePackage));
        else
            exp.and(CResFileDo.FilePackage, "=", pkg);
        
        return exp;
    }
    
    public static boolean isMetaFile(String fileName)
    {
        return CJavaConst.CODE_META_FILE_EXT.equalsIgnoreCase(ToolBasic.getExtOfFile(fileName));
    }
    
    public static boolean isJavaFile(String fileName)
    {
        return CJavaConst.JAVA_FILE_EXT.equalsIgnoreCase(ToolBasic.getExtOfFile(fileName));
    }
    
    // 通过java文件名，获取meta文件名
    public static String getMetaFile(String javaFile)
    {
        String pathName = ToolBasic.getFileNameWithoutExt(javaFile);
        return pathName +"."+CJavaConst.CODE_META_FILE_EXT;
    }
    
    public static String getCodeFile(String metaFile)
    {
        String pathName = ToolBasic.getFileNameWithoutExt(metaFile);
        return pathName +".java";
    }
    
    // 只查库里的Meta File Do
    public static CResFileDo queryMetaFile(IDao dao, String className) throws Exception
    {
        SqlExpression exp = queryMetaExp(className);
        return dao.queryDo(CResFileDo.class, Cnd.where(exp));
    }
    
    public static CodeMeta queryCodeMeta(IDao dao, String className) throws Exception
    {
        CResFileDo fileDo = queryMetaFile(dao, className);
        if (fileDo == null)
            return null;
        
        CodeMeta meta = new CodeMeta();
        meta.setMeta(new String(fileDo.getFileBin(), "UTF-8"));
        return meta;
    }
    
    public static CodeMeta getCodeMetaFromLoader(ClassLoader loader, String className) throws UnsupportedEncodingException, IOException
    {
        if (!(loader instanceof LvClassLoader))
            loader = new LvClassLoader(loader);
        
        String path = CmnUtil.javaPath2File(className)+"."+CJavaConst.CODE_META_FILE_EXT;
        try(InputStream ins = loader.getResourceAsStream(path))
        {
            if (ins == null)
                return null;
            String s = new String(ToolUtilities.readInputStream(ins), "UTF-8");
            CodeMeta meta = new CodeMeta();
            meta.setMeta(s);
            return meta;
        }
    }
}
