package bap.java;

import com.leavay.ms.tool.CmnUtil;

public class CJavaConst
{
    public final static String SYSTEM_PROJECT_UUID="SYSTEM_PROJECT_UUID";
    public final static String SYSTEM_FOLDER_UUID="SYSTEM_FOLDER_UUID";
    public final static String SYSTEM_CODE_PREFIX="SYSTEM_CODE:";
    
    public final static String JAVA_FILE_EXT = "java";
    public final static String CLASS_FILE_EXT = "class";
    
    // 伴随代码可以有一个同名meta文件，来记录元数据（这样可以在eclipse端、云仓库端都能得以保留）
    public final static String CODE_META_FILE_EXT = "meta";
    
    // 调试中心只缓存一定数量的调试器，因为调试器是被前台主动轮询的，所以不能在结束时自动清理，只能用LRU随时间推移慢慢被挤出队列
    public final static String CONF_DEBUGER_CACHE_SIZE = "java.debuger.cache.size";
    public final static int DEFAULT_DEBUGER_CACHE_SIZE = 100;
    
    // Debugger Status
    public final static int STATUS_PREPARE_RUNNING = 0;
    public final static int STATUS_RUNNING = 1;
    public final static int STATUS_FINISHED = 2;
    public final static int STATUS_ERROR = 3;
    
    // JAVA工程的依赖类型，对应JAVA工程的DependType
    public final static int DEPEND_ISOLATE=0; // 完全不依赖平台及插件，只依赖JDK
    public final static int DEPEND_PLATFORM=1; // 依赖平台，但不依赖插件（默认）
    public final static int DEPEND_PLUGIN=2; // 不仅依赖平台，还依赖发布的插件（主要用于独立的测试工具，本身不会发布为插件的场景，调试时可能会和插件冲突）
    public final static int UDF_LIB=3; // UDF库，代码相互之间独立编译，但是依赖平台，以及发布的插件

    // 导出到Eclipse工程的相关常量
    public final static String PATH_EXPORT_Conf = "conf";
    public final static String PATH_EXPORT_Lib = "lib";
    public final static String PATH_EXPORT_Src = "src";
    public final static String PATH_EXPORT_Open_Src = "openSource";
    public final static String Open_Src_File = "src.zip";
    public final static String Open_Src_Md5_File = "src.md5";
    

    public final static String FILE_Project_Json = "project.json"; // 主要用于发布到云仓库时的输出文件
    public final static String PATH_Platform = "platform";
    public final static String PATH_Model  = "model";
    public final static String PATH_Plugin = "plugin";
    public final static String PATH_Project = "project";
    public final static String PATH_EXPORT_Platform = PATH_EXPORT_Lib+"/"+PATH_Platform;
    public final static String PATH_EXPORT_Plugin = PATH_EXPORT_Lib+"/"+PATH_Plugin;
    public final static String PATH_EXPORT_Model = PATH_EXPORT_Lib+"/" + PATH_Model;
    public final static String PATH_EXPORT_Project = PATH_EXPORT_Lib+"/"+PATH_Project; // 项目本身引入的第三方包
    public final static String PROJECT_DEVELOP_CONF_FILE = ".develop";

    // 在BAP的resource目录下
    public final static String PROJECT_LAUNCH_TEMPLATE= "/bap/java/template.launch";
    public final static String PROJECT_LAUNCH_FILE = ".launch";
    public final static String VAR_PROJECT = "$PROJECT$"; // 用户替换成落地时Eclipse中的工程名
    public final static String VAR_MAIN_TYPE = "$MAIN_TYPE$"; // 用户替换成落地时Eclipse中的启动类名
    public final static String VAR_VM_ARGUMENTS = "$VM_ARGUMENTS$"; // 用户替换成落地时JVM启动参数（内存等）
    public final static String VAR_PROGRAM_ARGUMENTS = "$PROGRAM_ARGUMENTS$"; // 用户替换成落地时进程参数
    
    // Plugin当前的tag
    public final static String PATH_EXPORT_PLUGIN_TAG_FILE = "plugin.tag";
    public final static String PATH_EXPORT_PLUGIN_TAG_PATH = PATH_EXPORT_Plugin+"/"+PATH_EXPORT_PLUGIN_TAG_FILE;

    public final static String PATH_EXPORT_DAO_JAR_FILE = "dao_model.jar";
    public final static String PATH_EXPORT_DAO_TAG_FILE = "dao_model.tag";
    public final static String PATH_EXPORT_DAO_JAR_PATH = PATH_EXPORT_Model+"/"+PATH_EXPORT_DAO_JAR_FILE;
    public final static String PATH_EXPORT_DAO_TAG_PATH = PATH_EXPORT_Model+"/"+PATH_EXPORT_DAO_TAG_FILE;
    
    // 当修改、删除UDF时，需要广播操作时间（只会发生在DAO主控上）
    public final static String DAO_NOTIFY_SAVED_UDF_TIME = "NOTIFY_SAVED_UDF_TAG";
    public final static String DAO_NOTIFY_DELETED_UDF_TIME = "NOTIFY_DELETED_UDF_TAG";
    
    // 在服务端配置，用于eclipse工程中启动管理工具时调用哪个界面类
    public final static String CONF_DEV_ADMIN_TOOL = "dev.admin.tool";
    public final static String DFT_DEV_ADMIN_TOOL = "bap.client.BapMainFrame";
    
    // 系统保留专用JavaTool临时调试的类名，不允许其它地方使用
    public final static String SYS_DEBUG_JAVA_TOOL_PKG = "com.debug.tool";
    public final static String SYS_DEBUG_JAVA_TOOL_CLASS = "JavaTool";
    public final static String SYS_DEBUG_JAVA_TOOL_FULL_CLASS = SYS_DEBUG_JAVA_TOOL_PKG+"."+SYS_DEBUG_JAVA_TOOL_CLASS;
    
    public static boolean isSysProject(String pjUuid)
    {
        return SYSTEM_PROJECT_UUID.equals(pjUuid);
    }
    
    public static boolean isSysFolder(String folderUuid)
    {
        return SYSTEM_FOLDER_UUID.equals(folderUuid);
    }
    
    public static String getStatusName(int status)
    {
        switch(status)
        {
        case CJavaConst.STATUS_PREPARE_RUNNING:
            return "Prepare Running";
        case CJavaConst.STATUS_RUNNING:
            return "Running";
        case CJavaConst.STATUS_ERROR:
            return "Error";
        case CJavaConst.STATUS_FINISHED:
            return "Finished";
        }
        return "Unknown";
    }
    
    public static String getProjectTypeName(int dependType)
    {
        switch (dependType)
        {
        case DEPEND_ISOLATE:
            return "Isolate";
        case DEPEND_PLATFORM:
            return "Depend Platform";
        case DEPEND_PLUGIN:
            return "Depend Plugin";
        case UDF_LIB:
            return "UDF Library";
        }
        
        return "Unknown";
    }
    
    public static boolean isSysCode(String codeUuid)
    {
        return codeUuid.startsWith(SYSTEM_CODE_PREFIX);
    }
    
    public static void assertReservedClassName(String fullClass)
    {
        if (SYS_DEBUG_JAVA_TOOL_FULL_CLASS.equals(fullClass))
            throw new RuntimeException("Reserved class name for java tool : " + SYS_DEBUG_JAVA_TOOL_FULL_CLASS);
    }
}
