package bap.java;

import java.io.Serializable;

import ms.cmn.HostPort;

public class CJavaDebuggerDto implements Serializable
{
    private static final long serialVersionUID = 1393394704956673006L;
    
    public String uuid;
    public String name;
    
    // 执行地
    public HostPort runningOn;
    
    //  CJavaConst.STATUS
    public int status;
    
    public String clientInfo;
    
    public long startTime;
    
    public String errorMsg;

    public String getUuid()
    {
        return uuid;
    }

    public void setUuid(String uuid)
    {
        this.uuid = uuid;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public int getStatus()
    {
        return status;
    }

    public void setStatus(int status)
    {
        this.status = status;
    }

    public HostPort getRunningOn()
    {
        return runningOn;
    }

    public void setRunningOn(HostPort runningOn)
    {
        this.runningOn = runningOn;
    }

    public String getClientInfo()
    {
        return clientInfo;
    }

    public void setClientInfo(String clientInfo)
    {
        this.clientInfo = clientInfo;
    }

    public long getStartTime()
    {
        return startTime;
    }

    public void setStartTime(long startTime)
    {
        this.startTime = startTime;
    }

    public String getErrorMsg()
    {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg)
    {
        this.errorMsg = errorMsg;
    }

    public String toString()
    {
        return getName();
    }
    
}
