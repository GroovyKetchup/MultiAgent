package bap.java;

import bap.md.java.CJavaCodeDo;
import bap.udf.UdfMeta;

public class CUdfBean extends CJavaCodeDo
{
    private static final long serialVersionUID = -1813992842988206353L;

    // 这个对象用于缓存那些不存在的对象，防止反复查询不存在的UDF轰击数据库
    public final static CUdfBean UNEXIST_UDF = (CUdfBean) new CUdfBean().setMainClass("NULL");
    
    // 存放编译解析出的纯语法Meta
    public UdfMeta compileMeta;
    
    public transient Object _udfInstance;
    
    public UdfMeta getCompileMeta()
    {
        return compileMeta;
    }

    public void setCompileMeta(UdfMeta udfMeta)
    {
        this.compileMeta = udfMeta;
    }

    public boolean isUnexistBean()
    {
        return UNEXIST_UDF == this;
    }

    public Object getUdfInstance()
    {
        return _udfInstance;
    }

    public void setUdfInstance(Object udfInstance)
    {
        this._udfInstance = udfInstance;
    }
}
