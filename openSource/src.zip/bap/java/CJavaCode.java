package bap.java;

import com.cdao.dto.DaoSlaveDto;
import com.leavay.common.util.javac.CompileStastic;
import com.leavay.ms.tool.CmnUtil;

import cell.ResourceCellIntf;

public class CJavaCode extends DaoSlaveDto implements CJavaGuiCompilable
{
    private static final long serialVersionUID = -4888539621458307581L;
    
    public String mainClass; // Simple Name
	public String javaPackage;
	public String name;
	public String code;
	public boolean readOnly;
	public String fileEncoding;
    public String lastWriter;
    public String codeMd5;
    public Long saveTime;

	// 主要用于界面缓存编译统计数据
    CompileStastic compileStastic;
    
    protected String initDaoClass()
    {
        return "bap.md.java.CJavaCodeDo";
    }
    
    public void setProjectUuid(String pjUuid)
    {
        setMasterKey(pjUuid);
    }
    
    public String getProjectUuid()
    {
        return getMasterKey();
    }
    
    public String getFolder()
    {
        return getOwner();
    }
    
    public String getMainClass()
    {
        return mainClass;
    }
    public void setMainClass(String mainClass)
    {
        this.mainClass = mainClass;
    }
    public String getJavaPackage()
    {
        return javaPackage;
    }
    public void setJavaPackage(String javaPackage)
    {
        this.javaPackage = javaPackage;
    }
    
    // 生成一个摘要信息，不含源码等大数据量字段
    public CJavaCode newBrief()
    {
        CJavaCode b = new CJavaCode();
        b.setDaoClass(getDaoClass());
        b.setUuid(getUuid());
        b.setProjectUuid(getProjectUuid());
        b.setMasterKey(getMasterKey());
        b.setOwner(getOwner());
        b.setLastWriter(getLastWriter());
        b.setJavaPackage(getJavaPackage());
        b.setMainClass(getMainClass());
        b.setReadOnly(isReadOnly());
        b.setCodeMd5(getCodeMd5());
        b.setSaveTime(getSaveTime());
        
        return b;
    }
    
    public String getFullClassName()
    {
        if (CmnUtil.isStringEmpty(getJavaPackage()))
            return getMainClass();
        else
            return getJavaPackage()+"."+getMainClass();
    }
    
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public String getCode()
    {
        return code;
    }
    public void setCode(String code)
    {
        this.code = code;
    }
    public boolean isReadOnly()
    {
        return readOnly;
    }
    public void setReadOnly(boolean readOnly)
    {
        this.readOnly = readOnly;
    }

    public String getFileEncoding()
    {
        return fileEncoding;
    }
    public void setFileEncoding(String fileEncoding)
    {
        this.fileEncoding = fileEncoding;
    }
    public boolean hasOwner()
    {
        return !CmnUtil.isStringEmpty(getOwner());
    }
    
    public String getPackage()
    {
        return CmnUtil.getString(getJavaPackage(), "");
    }
    
    public boolean hasPackage()
    {
        return !CmnUtil.isStringEmpty(getJavaPackage());
    }
    
    public String getFilePath()
    {
        return getPackage().replace('.', '/') + "/" + getMainClass();
    }

    public CompileStastic getCompileStastic()
    {
        return compileStastic;
    }

    public void setCompileStastic(CompileStastic compileStastic)
    {
        this.compileStastic = compileStastic;
    }

    public void setEmptyCode(boolean mainFunc)
    {
        setCode(newEmptyCode(this, mainFunc));
    }
    
    
    public String getLastWriter()
    {
        return lastWriter;
    }

    public void setLastWriter(String lastWriter)
    {
        this.lastWriter = lastWriter;
    }

    public String getCodeMd5()
    {
        return codeMd5;
    }

    public void setCodeMd5(String codeMd5)
    {
        this.codeMd5 = codeMd5;
    }

    public Long getSaveTime()
    {
        return saveTime;
    }

    public void setSaveTime(Long saveTime)
    {
        this.saveTime = saveTime;
    }

    public String toString()
    {
        return getFullClassName()+"("+getUuid()+")";
    }
    
    public static String newEmptyCode(CJavaCode code, boolean mainFunc)
    {
        StringBuffer sb = new StringBuffer();
        if (code.hasPackage())
            sb.append("package "+code.getJavaPackage()+";\n\n");
        sb.append("public class "+code.getMainClass()+"\n{\n");
        if (mainFunc)
            sb.append("\n    public static void main(String[] args) throws Exception\n    {\n        \n    }");
        sb.append("\n}");
        
        return sb.toString();
    }
    
    public static String newCellCode(String pkg, String mainName, Class baseIntf)
    {
        StringBuffer sb = new StringBuffer();
        if (!CmnUtil.isStringEmpty(pkg))
            sb.append("package "+pkg+";\n\n");
        sb.append("import cell.*;\n");
        sb.append("import bap.cells.Cells;\n");
        sb.append("public interface "+mainName+ " extends " + baseIntf.getSimpleName()+"\n{\n");
        
        // 服务类、普通Cell，自动添加Cell工厂构造的方法
        if (!CmnUtil.isInheritFrom(baseIntf, ResourceCellIntf.class))
        {
            sb.append("\n    public static "+mainName+" get(){ return Cells.get(" + mainName+".class);}");
        }
        
        sb.append("\n}");
        
        return sb.toString();
    }

    // 获取代码对应的树路径（工程/目录/包名/代码）
    public String[] getCodePath()
    {
        String[] path = new String[4];
        path[0] = getProjectUuid();
        path[1] = getFolder();
        path[2] = getPackage();
        path[3] = getUuid();
        return path;
    }
}
