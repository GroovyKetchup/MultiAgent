package bap.java.project;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import com.cdao.mgr.ModelContext;
import com.cdao.mgr.ModelObserver;
import com.cdao.model.CDoAttach;
import com.cdao.model.CDoModel;
import com.leavay.common.util.SJsonList;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.ChildProgress;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.leavay.common.util.ProgressCtrl.crpc.IProgressUtil;
import com.leavay.ms.tool.CmnUtil;

import bap.client.BapGuiUtil;
import bap.md.java.CJavaProject;
import bap.md.java.CJavaVirtualProject;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.yun.ArtifactUtil;
import bap.yun.YunStoreAgent;
import cell.bap.yun.IYunImportObserver;
import cell.cdao.CDaoCell;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import cmn.security.dto.UserPassword;
import cmn.util.Nulls;

/**
 * 导入云端工程到本地，如果有专属模型，则会连同模型一起导入
 * 如果导入模型失败，会导致整体失败回滚
 * 
 * 这是以对象化的方式进行操作，将自身作为模型导入的观察者用以和模型导入在同一个transaction内动作
 *
 */
public class YunProjectImporter implements ModelObserver
{
    ArtifactWare artWare;

    CDoAttach zipProject;

    List<CDoModel> lstModel;

    CJavaProject createdProject;
    
    // 将所有依赖模型设置为本工程独占模型(正常是不需要的, 保持原样即可)
    boolean overwriteAllDependModels = false;
    
    public static CJavaProject importYunProject(IProgress prog, ArtifactWare art, UserPassword yunUser) throws Exception
    {
        try
        {
            // 先尝试登陆一下云仓库，校验连通性以及用户等，然后再准备打包发布
            YunStoreAgent.getIntf().login(yunUser);
            
            YunProjectImporter impt = new YunProjectImporter();
            impt.doImportYunProject(prog, art, yunUser);

            return impt.createdProject;
        } finally
        {
            IProgressUtil.finish(prog);
        }
    }

    protected void doImportYunProject(IProgress prog, ArtifactWare art, UserPassword yunUser) throws Exception
    {
        if (art == null)
            return;

        try
        {
            IProgressUtil.send(prog, 0, "Query artifact from YUN store");
            artWare = YunStoreAgent.getIntf().queryArtifact(art.getGroupId(), art.getArtifactId(), art.getVersion(), true, CmnUtil.append(ArtifactWare.FIELDS_BRIEF, ArtifactWare.ExclusiveModel, ArtifactDefine.ExtendData));
            CmnUtil.assertNotNull(artWare, "Artifact is removed from store");
            
            // 调用外部可能干预的导入前校验
            IYunImportObserver.get().verifyArtifactWare(prog, artWare, yunUser);

            IProgressUtil.send(prog, 5, "Query project package from store");
            zipProject = YunStoreAgent.getIntf().queryProjectPackage(artWare.getUuid());
            ToolUtilities.assertNotNull(zipProject, "This is not a valid project.");

            IProgressUtil.send(prog, 10, "Query model package from store");
            lstModel = ArtifactUtil.queryAllDependModel(artWare, true);

            // 遍历查找已经存在的模型(需报警告信息)
            if (Nulls.isNotEmpty(lstModel))
            {
                Map<String, CDoModel> conflictMds = new HashMap();
                for (CDoModel md : lstModel)
                {
                    CDoModel existed = IDaoService.get().queryModel(md.getFullClassName());
                    if (existed != null)
                        conflictMds.put(md.getFullClassName(), md);
                }

                if (Nulls.isNotEmpty(conflictMds))
                {
                    if (JOptionPane.YES_OPTION != IProgressUtil.showConfirmDialog(prog, BapGuiUtil.getString("Will overwrite these local models")+" :\n" + ToolUtilities.logString(conflictMds.values(), true), BapGuiUtil.getString("Overwrite Models Warning")+" !!!",
                            JOptionPane.YES_NO_OPTION))
                        return;
                }
            }
            
            if (!CmnUtil.isObjectEmpty(lstModel))
            {
                // 如果有模型，则与模型导入动作融合在一起，一旦失败就整体失败
                IProgressUtil.send(prog, 30, "Import model package");
                IDaoService.get().importModels(new ChildProgress(30, 80, prog), lstModel, this);
            } else
            {
                // 如果没有模型，则只是单纯创建java工程
                try (IDao dao = IDaoService.newIDao())
                {
                    createdProject = createYunProject(dao);

                    // 外部hook调用
                    IYunImportObserver.get().beforeCommit(prog, dao, createdProject);
                    dao.commit();
                }
            }

            // 导入成功且提交，则需要初始化工程构建器
            CJavaPJBuilder builder = CJavaCenter.getMe().addCache(new CJavaPJBuilder(createdProject));

            // 外部hook调用
            IYunImportObserver.get().afterAll(prog, createdProject);
        } finally
        {
            IProgressUtil.finish(prog);
        }
    }

    protected CJavaProject createYunProject(IDao dao) throws Exception
    {
        // 创建工程（重名则删掉新建）
        CJavaProject pj = CJavaCenter.importProjectZip(dao, artWare.getArtifactId(), zipProject.getContentBin());

        // 设置工程的Art信息
        ArtifactDefine def = new ArtifactDefine();
        def.setForeignGid(pj.getGid());
        def.setDefine(artWare);
        def.setDependTo(artWare.getDependTo());

        // copy模型列表
        if (overwriteAllDependModels)
        {
            if (!CmnUtil.isObjectEmpty(lstModel))
            {
                SJsonList lstMd = new SJsonList();
                for (CDoModel md : lstModel)
                    lstMd.add(md.getFullClassName());
                def.setExclusiveModelList(lstMd);
            }
        } else
        {
            def.setExclusiveModel(artWare.getExclusiveModel());
        }
        def = dao.createDo(def);

        return pj;
    }

    // 响应监听回调
    public void beforeCommit(IProgress prog, ModelContext ctx)
    {
        IDao dao = new CDaoCell(ctx.getDao());
        try
        {
            IProgressUtil.send(prog, 1, "Create local project ... ");
            createdProject = createYunProject(dao);
            
            // 外部hook调用
            IYunImportObserver.get().beforeCommit(prog, dao, createdProject);
            
//            for (int i =0;i<100;i++)
//            {
//                IProgressUtil.send(prog, i, "Demo create project slowly");
//                ToolUtilities.sleep(200);
//            }
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
        }
    }

    // 从云端导入到虚拟工程中(不导入模型, 不限制重复, 不能发布插件等, 仅用于版本比对)
    public static CJavaVirtualProject importVirtualProject(IProgress prog, ArtifactWare art, UserPassword yunUser) throws Exception
    {
        try
        {
            // 先尝试登陆一下云仓库，校验连通性以及用户等，然后再准备打包发布
            YunStoreAgent.getIntf().login(yunUser);
            
            YunProjectImporter impt = new YunProjectImporter();
            impt.doImportVirtualProject(prog, art);

            return (CJavaVirtualProject) impt.createdProject;
        } finally
        {
            IProgressUtil.finish(prog);
        }
    }

    // 从云端导入到虚拟工程中(不导入模型, 不限制重复, 不能发布插件等, 仅用于版本比对)
    protected void doImportVirtualProject(IProgress prog, ArtifactWare art) throws Exception
    {
        if (art == null)
            return;

        try
        {
            IProgressUtil.send(prog, 0, "Query artifact from YUN store");
            artWare = YunStoreAgent.getIntf().queryArtifact(art.getGroupId(), art.getArtifactId(), art.getVersion(), true, ArtifactWare.FIELDS_BRIEF);
            CmnUtil.assertNotNull(artWare, "Artifact is removed from store");

            IProgressUtil.send(prog, 5, "Download project package from store");
            zipProject = YunStoreAgent.getIntf().queryProjectPackage(artWare.getUuid());
            ToolUtilities.assertNotNull(zipProject, "This is not a valid project.");

            // 如果没有模型，则只是单纯创建java工程
            try (IDao dao = IDaoService.newIDao())
            {
                IProgressUtil.send(prog, 50, "Import project package from store ... ");
                createdProject = CJavaCenter.importVirtualProjectZip(dao, artWare.getArtifactId()+"_"+artWare.getVersion(), zipProject.getContentBin());
                dao.commit();
            }

            // 导入成功且提交，则需要初始化工程构建器
            CJavaPJBuilder builder = CJavaCenter.getMe().addCache(new CJavaPJBuilder(createdProject));

        } finally
        {
            IProgressUtil.finish(prog);
        }
    }
}
