package bap.java.project;

import java.util.List;

import com.cdao.model.CDoModel;

import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import bap.plugin.CPluginJarDto;
import cell.bap.yun.ArtifactGraph;
import cell.cdao.IDao;

/**
 * 专用于在saveGlobalDependence的时候(保存/重建全局依赖时的执行过程), 留给外部干预此后的动作,
 * 以便外部根据依赖图谱自行决定一些相关的联动动作
 */
public interface GlobalDependObserver
{
    /**
     * 重建全局依赖首先会分析出依赖图谱(totalGraph), 然后开始"逐一"下载/分析, 此时会触发此观察动作(多次), 当前尚未开始实质性导入动作
     * 此动作可能被调用"多次"(多个依赖包)
     * 注: 如果依赖的云组件与当前工程同名/同ArtfactID或被显式设定为排除的, 则会被忽略, 不会触发此动作
     * 
     * @param dao
     *            : 当前的DAO
     * @param totalGraph
     *            : 全局整体的依赖图谱, 其中包含整套的依赖关系(如无依赖则为null)
     * @param yunArt
     *            : 当前正在加载/下载的云组件
     * @param lstJars
     *            : 当前云组件的附件
     * @param pkgModels
     *            : 当前云组件的模型包
     */
    public default void preloadPackage(IDao dao, ArtifactGraph totalGraph, ArtifactWare yunArt,  List<CPluginJarDto> lstJars, List<CDoModel> pkgModels)
    {
        
    }
    
    /**
     * 下载完所有组件后, 准备开始导入动作之前
     * 此动作一定会被触发, 且仅一次
     * 
     * @param dao
     *            : 当前的DAO
     * @param totalGraph
     *            : 全局整体的依赖图谱, 其中包含整套的依赖关系(如无依赖则为null)
     * @param globalDep
     *            : 全依赖设定(包含排除以及版本冲突解决)
     * @param lstJars
     *            : 发布的jar包
     * @param pkgModels
     *            : 当前云组件的模型包
     */
    public default void beforeImport(IDao dao, ArtifactGraph totalGraph, GlobalDependSetting globalDep,  List<CPluginJarDto> lstJars, List<CDoModel> allModels)
    {
        
    }
    
    
    /**
     * 接着会整体导入插件包, 并发布, 此时会等待发布插件结束后才调入此方法
     * 此动作只会调用一次
     * 注:此时虽尚未导入DAO模型包,但插件已经发布且不可逆
     * 
     * @param dao
     *            : 当前的DAO
     * @param pluginTag
     *            : 发布后的插件TAG
     */
    public default void afterImport2Plugin(IDao dao, long pluginTag)
    {
        
    }
    
    /**
     * 最后会导入所有模型包, 如果没有模型包则不会触发此调用
     * 此时尚未最终commit(主要是模型包的导入动作还未最终提交)
     * 
     * @param dao
     *            : 当前的DAO
     * @param allModels
     *            : 所有组件的模型包
     * @param modelTag
     *            : 导入后模型的时间戳TAG
     */
    public default void afterImportModels(IDao dao, long modelTag)
    {
        
    }
    
    /**
     * 提交完成后的最后一步触发
     * @param dao
     */
    public default void afterCommit(IDao dao)
    {
        
    }
}
