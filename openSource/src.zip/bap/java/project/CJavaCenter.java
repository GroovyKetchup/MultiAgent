package bap.java.project;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.eclipse.jdt.internal.compiler.ClassFile;
import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
import org.nutz.dao.Cnd;
import org.nutz.dao.util.cri.Exps;
import org.nutz.dao.util.cri.SqlExpressionGroup;
import org.nutz.repo.cache.simple.LRUCache;

import com.cdao.dto.CPager;
import com.cdao.dto.DataRow;
import com.cdao.dto.Params;
import com.cdao.dto.Vars;
import com.cdao.impl.entity.field.GID;
import com.cdao.impl.entity.field.SlaveTable;
import com.cdao.mgr.CDao;
import com.cdao.mgr.CDaoCenter;
import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoUtil;
import com.cdao.mgr.CSession;
import com.cdao.mgr.ModelContext;
import com.cdao.mgr.ModelObserver;
import com.cdao.mgr.listener.CDaoAction;
import com.cdao.model.CDoAttach;
import com.cdao.model.CDoBasic;
import com.cdao.model.CDoModel;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.GsonUtil;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.Pair;
import com.leavay.common.util.SJsonList;
import com.leavay.common.util.SrvRes;
import com.leavay.common.util.StringLock;
import com.leavay.common.util.StringLock.LockObject;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ZipUtils;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ProgressCtrl.ChildProgress;
import com.leavay.common.util.ProgressCtrl.ProgressControllerFEIntf;
import com.leavay.common.util.ProgressCtrl.ProgressCtrlUtil;
import com.leavay.common.util.ProgressCtrl.SrvProgressIntf;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.leavay.common.util.ProgressCtrl.crpc.IProgressUtil;
import com.leavay.common.util.cjson.CJson;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.CodeCompileException;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.common.util.javac.CodeUtil;
import com.leavay.common.util.javac.CodeUtil.BasiceClassInfoLoader;
import com.leavay.common.util.javac.CodeUtil.ClassInfoLoader;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.LvCompileSingleResult;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.common.util.javac.LvJavac.LvCompileResult;
import com.leavay.common.util.javac.LvProblem;
import com.leavay.dfc.mgr.javaDev.ClassNameInfoExt;
import com.leavay.dfc.mgr.javaDev.ClassSearchEngine;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcServer;
import com.leavay.nio.crpc.CRpcUtil;

import art.mvn.MvnArt;
import art.mvn.MvnArtTreeNode;
import bap.cells.CellBuilderIntf;
import bap.cells.CellConfig;
import bap.cells.CellConfigAdapter;
import bap.cells.CellFinder;
import bap.cells.CellServerFactory;
import bap.cells.ConfigFactory;
import bap.cells.annotation.Config;
import bap.client.BapGuiUtil;
import bap.dev.FileDto;
import bap.dev.JavaDto;
import bap.java.BapMgr;
import bap.java.CJavaCenterImpl;
import bap.java.CJavaCenterIntf;
import bap.java.CJavaCode;
import bap.java.CJavaConst;
import bap.java.CJavaDebuggerDto;
import bap.java.CJavaUtil;
import bap.java.CodeMeta;
import bap.java.CommitPackage;
import bap.java.FileUpdatePackage;
import bap.java.NoFolderException;
import bap.java.debug.CJavaDebugPkg;
import bap.java.debug.CJavaDebugger;
import bap.java.debug.CJavaLocalDebuger;
import bap.java.debug.CJavaRpcDebuger;
import bap.java.debug.NoDebuggerException;
import bap.java.project.CJavaPJBuilder.MemberMatcher;
import bap.md.CJarFile;
import bap.md.CellConfigDo;
import bap.md.java.CJavaCodeDo;
import bap.md.java.CJavaFolder;
import bap.md.java.CJavaProject;
import bap.md.java.CJavaVirtualCodeDo;
import bap.md.java.CJavaVirtualProject;
import bap.md.java.CResFileDo;
import bap.md.ver.VersionNode;
import bap.md.ver.VersionProject;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import bap.plugin.CPluginExportPackage;
import bap.plugin.CPluginJarDto;
import bap.plugin.CPluginProjectDto;
import bap.plugin.mgr.CPluginClient;
import bap.udf.CUdfUtil;
import bap.udf.UdfMeta;
import bap.version.CVerMgr;
import bap.yun.ArtifactConst;
import bap.yun.ArtifactPackage;
import bap.yun.ArtifactUtil;
import bap.yun.YunStoreAgent;
import cell.ServiceCellIntf;
import cell.bap.yun.ArtifactGraph;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import cmn.security.dto.UserPassword;
import cmn.util.AutoLock;
import cmn.util.NullUtil;
import cmn.util.Nulls;
import code.maven.util.MavenAgent;
import code.maven.util.MavenToYun;
import cplugin.ms.dto.CResFileDto;
import ms.cmn.HostPort;
import ms.cmn.util.MD5Util;
import ms.cmn.util.TempFile;
import ms.cmn.util.arrays.ByteBuffer;

public class CJavaCenter extends BapMgr
{
    public final static String LOG = "CJava Project Center";

    private static CJavaCenter _me;

    public final static String OPEN_SOURCE_PATH = "openSource";

    public final static String ZIP_FILE = OPEN_SOURCE_PATH + "/src.zip";

    static CJavaProject _sysProject;

    public synchronized static CJavaProject getSysProject()
    {
        if (_sysProject == null)
        {
            _sysProject = new CJavaProject();
            _sysProject.setName("System Open Source");
            _sysProject.setUuid(CJavaConst.SYSTEM_PROJECT_UUID);
            _sysProject.setDependType(CJavaConst.DEPEND_PLUGIN);
        }

        return _sysProject;
    }

    public static boolean isSystemProject(CJavaProject pj)
    {
        return CmnUtil.isStringEqual(CJavaConst.SYSTEM_PROJECT_UUID, pj.getUuid());
    }

    public static boolean isSystemProject(String pjUuid)
    {
        return CmnUtil.isStringEqual(CJavaConst.SYSTEM_PROJECT_UUID, pjUuid);
    }

    static CJavaFolder _sysFolder;

    public synchronized static CJavaFolder getSysFolder()
    {
        if (_sysFolder == null)
        {
            _sysFolder = new CJavaFolder();
            _sysFolder.setName("src");
            _sysFolder.setUuid(CJavaConst.SYSTEM_FOLDER_UUID);
            _sysFolder.setMaster(getSysProject().getGid(), CJavaProject.LstFolder);
        }

        return _sysFolder;
    }

    public List<CJavaFolder> getFolders(String pjUuid) throws Exception
    {
        if (CJavaConst.isSysProject(pjUuid))
            return ToolUtilities.newArrayList(getSysFolder());
        else
        {
            try (CDao dao = newDao())
            {
                return dao.queryDoList(CJavaFolder.class, Cnd.where(CJavaFolder.MasterKey, "=", pjUuid));
            }
        }
    }

    public Set<String> getFolderNames(String pjUuid) throws Exception
    {
        Set<String> setRet = new HashSet<String>();
        try (CDao dao = newDao())
        {
            List<CJavaFolder> lstFolder = dao.queryDoList(CJavaFolder.class, Cnd.where(CJavaFolder.MasterKey, "=", pjUuid), CJavaFolder.Name);
            if (lstFolder != null)
                for (CJavaFolder fd : lstFolder)
                    setRet.add(fd.getName());

            return setRet;
        }
    }

    public Set<String> getFolderUuids(String pjUuid) throws Exception
    {
        Set<String> setRet = new HashSet<String>();
        try (CDao dao = newDao())
        {
            List<CJavaFolder> lstFolder = dao.queryDoList(CJavaFolder.class, Cnd.where(CJavaFolder.MasterKey, "=", pjUuid), CJavaFolder.UUID);
            if (lstFolder != null)
                for (CJavaFolder fd : lstFolder)
                    setRet.add(fd.getUuid());

            return setRet;
        }
    }

    public Map<String, String> getFolderNameMap(String pjUuid) throws Exception
    {
        Map<String, String> map = new HashMap<String, String>();
        try (CDao dao = newDao())
        {
            List<CJavaFolder> lstFolder = dao.queryDoList(CJavaFolder.class, Cnd.where(CJavaFolder.MasterKey, "=", pjUuid), CJavaFolder.UUID, CJavaFolder.Name);
            if (lstFolder != null)
                for (CJavaFolder fd : lstFolder)
                    map.put(fd.getUuid(), fd.getName());

            return map;
        }
    }

    public Map<String, CJavaFolder> getFolderMap(String pjUuid) throws Exception
    {
        Map<String, CJavaFolder> map = new HashMap<String, CJavaFolder>();

        try (CDao dao = newDao())
        {
            List<CJavaFolder> lstFolder = dao.queryDoList(CJavaFolder.class, Cnd.where(CJavaFolder.MasterKey, "=", pjUuid));
            if (lstFolder != null)
                for (CJavaFolder fd : lstFolder)
                    map.put(fd.getUuid(), fd);

            return map;
        }
    }

    public synchronized static CJavaCenter getMe()
    {
        if (_me == null)
            _me = new CJavaCenter();

        return _me;
    }

    protected CJavaCenter()
    {

    }

    public void initBeforeDao()
    {
        CRpcServer.registService(CJavaCenterIntf.class, CJavaCenterImpl.get());

        CDaoCenter.addInitModel(CJavaCodeDo.class);
        CDaoCenter.addInitModel(CResFileDo.class);
        CDaoCenter.addInitModel(CJavaFolder.class);
        CDaoCenter.addInitModel(CJavaProject.class);
        CDaoCenter.addInitModel(CJavaVirtualProject.class);
        CDaoCenter.addInitModel(CJavaVirtualCodeDo.class);

        // 版本管理
        CDaoCenter.addInitModel(VersionProject.class);
        CDaoCenter.addInitModel(VersionNode.class);

        // 仓库管理 (兼容开发端、仓库端)
        CDaoCenter.addInitModel(ArtifactWare.class);
        CDaoCenter.addInitModel(ArtifactDefine.class);
        CDaoCenter.addInitModel(GlobalDependSetting.class);

        // 删除代码的全局监听器
        CDaoCenter.replaceGlobalListener(CDaoAction.DELETE, CJavaCodeDo.class.getName(), CJavaCodeDeleteListener.class.getName(), true);
    }

    private boolean _started = false;

    public void start() throws Exception
    {
        // 代理上不需要分析类，浪费性能
        CodeUtil.setEnable(true);

        reload();

        // 只有主控需要提供全局的类继承帮助，所以只有这里才需要预分析类继承关系
        // 其它场景，等到真要调用searchSubClass时才去分析吧，正常是不会需要的
        ClassFactory.lazyInitSysReflections();

        _started = true;
    }

    public boolean isStarted()
    {
        return _started;
    }

    public CJavaCode saveJavaCode(CJavaCode newCode, boolean autoCompile) throws Exception
    {
        return getBuilder_Force(newCode.getProjectUuid()).saveJavaCode(newCode, autoCompile);
    }

    public void rebuildAll(String projectUuid) throws Exception
    {
        getBuilder_Force(projectUuid).rebuildAll();
    }

    public List<CJavaCode> searchCode(String fullClass) throws Exception
    {
        List<CJavaCode> lst = new LinkedList<CJavaCode>();
        CJavaCode sysCode = getBuilder_Force(CJavaConst.SYSTEM_PROJECT_UUID).getCode(fullClass);
        if (sysCode != null)
            lst.add(sysCode);

        try (CDao dao = newDao())
        {
            String pkg = LvJavac.getPackageFromFullClass(fullClass);

            Cnd cnd = ToolUtilities.isStringEmpty(pkg) ? Cnd.where(Exps.isNull(CJavaCodeDo.JavaPackage)) : Cnd.where(CJavaCodeDo.JavaPackage, "=", pkg);
            cnd.and(CJavaCodeDo.MainClass, "=", LvJavac.getSimpleName(fullClass));

            List<CJavaCodeDo> lstDos = dao.queryDoList(CJavaCodeDo.class, cnd, CmnUtil.append(CJavaCodeDo.MasterFields, CJavaCodeDo.UUID, CJavaCodeDo.JavaPackage, CJavaCodeDo.MainClass));
            if (lstDos != null)
                lst.addAll(CDaoUtil.convertDtos(lstDos, CJavaCode.class));
        }

        return lst;
    }

    public List<ClassNameInfoExt> searchCode(String sKey, boolean searchInJar, int countLimit) throws Exception
    {
        sKey = sKey.toLowerCase();
        List<ClassNameInfoExt> lstRet1 = new ArrayList<ClassNameInfoExt>();
        List<ClassNameInfoExt> lstRet = new ArrayList<ClassNameInfoExt>();
        List<CJavaProject> lstPjs = getAllProjects();
        for (CJavaProject pj : lstPjs)
        {
            CJavaPJBuilder builder = getBuilder(pj.getUuid());
            if (builder == null)
                continue;

            List<ClassNameInfoExt> lstOne = builder.searchCode(sKey, false, countLimit);
            if (ToolUtilities.isObjectEmpty(lstOne))
                continue;

            lstRet1.add(lstOne.get(0));
            lstOne.remove(0);
            lstRet.addAll(lstOne);
        }
        lstRet.addAll(0, lstRet1);
        while (lstRet.size() > countLimit)
            lstRet.remove(lstRet.size() - 1);

        if (searchInJar)
        {
            List<ClassNameInfo> lstSys = ClassSearchEngine.getInstance().searchClass(sKey, true, true);
            for (ClassNameInfo info : Nulls.get(lstSys))
                lstRet.add(ClassNameInfoExt.convert(info, "Platform Jars"));
        }
        return lstRet;
    }

    public Map<String, Object> searchClass(CJavaCode code, String sPreFix, int iCurrentPos) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).searchClass(code, sPreFix, iCurrentPos);
    }

    public Map<String, Object> searchMethodField(CJavaCode code, String sTotalPreword, int iCurrentPos) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).searchMethodField(code, sTotalPreword, iCurrentPos);
    }

    public Map<String, Object> searchMethodField(CJavaCode code, String sTotalPreword, int iCurrentPos, MemberMatcher matcher) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).searchMethodField(code, sTotalPreword, iCurrentPos, matcher);
    }

    public static List<CJavaCodeDo> getAllCodeDos(GID pjGid) throws Exception
    {
        if (CJavaConst.isSysProject(pjGid.getUuid()))
        {
//            return getOpenCode();
            return getOpenCodeFromZip();
        } else if (pjGid.getClassName().equals(CJavaVirtualProject.class.getName()))
            return CDaoClient.getIntf().queryDoList(CJavaVirtualCodeDo.class.getName(), Cnd.where(CJavaCodeDo.MasterKey, "=", pjGid.getUuid()));
        else
            return CDaoClient.getIntf().queryDoList(CJavaCodeDo.class.getName(), Cnd.where(CJavaCodeDo.MasterKey, "=", pjGid.getUuid()));
    }

    // 代码辅助的总入口，不区分是类还是成员的带出
    public List<CJavaHint> searchHint(CJavaCode code, int pos) throws Exception
    {
        long time = System.currentTimeMillis();

        char[] codeChar = code.code.toCharArray();

        int hintStartPos = pos;// 提示内容替换的起始位置是否在preFix的开头处（一般半截字符都需要前移到关键字开头，而打点结尾的不需要，直接以点的位置为准）
        int hintEndPos = pos;// 提示内容替换的结束位置，如果是.结尾，则保持在.后
        boolean endDot = false;
        if ('.' == codeChar[pos - 1])
        {
            endDot = true;
            pos--; // 前移到点之前
        }

        String sTotalPreWord = LvJavac.getPrevWord(codeChar, pos, false, false, false);
        String sPreFix = LvJavac.getPrevWord(codeChar, pos, true, false, true);
        String sPrePreWord = LvJavac.getPrevPrevWord(sTotalPreWord.toCharArray(), sTotalPreWord.length(), false, true);
        if (!endDot) // 不是点结尾的，都需要前移hint的pos
            hintStartPos = pos - sPreFix.length();

        boolean isMember = endDot;
        if (!endDot)
        {
            if (sTotalPreWord.indexOf('.') >= 0)
                isMember = true;
        }

        List<Pair<Float, CJavaHint>> visibleRows = new LinkedList();
        if (isMember)
        {
            // 匹配算法器
            MemMatcher matcher = null;
            if (!endDot)
                matcher = new MemMatcher(sPreFix);

            // 开始搜索
            Map<String, Object> mapData = searchMethodField(code, sTotalPreWord, pos, matcher);
            if (mapData.isEmpty() && !sPrePreWord.isEmpty() && !sPrePreWord.equals(sTotalPreWord))
                mapData = searchMethodField(code, sPrePreWord, pos, matcher);
            for (Entry<String, Object> ent : mapData.entrySet())
            {
                CJavaHint hint = new CJavaHint();
                if (ent.getValue() instanceof CodeDeclareInfo)
                {
                    CodeDeclareInfo dec = (CodeDeclareInfo) ent.getValue();
                    hint.setType(dec.getType());
                    hint.setText(dec.getCodeText());
                    hint.setClassName(dec.getDeclareClass());
                    hint.setDisplayText(dec.getName());
                    hint.setStartPos(hintStartPos);
                    hint.setEndPos(hintEndPos);
                } else
                {
                    hint.setText(ent.getKey());
                    hint.setDisplayText(ToolUtilities.logString(ent.getValue(), false));
                    hint.setStartPos(hintStartPos);
                    hint.setEndPos(hintEndPos);
                }

                visibleRows.add(new Pair<Float, CJavaHint>(ToolBasic.getStringMatchRate(sPreFix, hint.text), hint));
            }
        } else
        {
            Map<String, Object> mapData = searchClass(code, sPreFix, pos);
            for (Entry<String, Object> ent : mapData.entrySet())
            {
                CJavaHint hint = new CJavaHint();
                if (ent.getValue() instanceof ClassNameInfo)
                {
                    ClassNameInfo cls = (ClassNameInfo) ent.getValue();
                    if (!cls.getClassSimpleName().toLowerCase().startsWith(sPreFix.toLowerCase()))
                        continue;

                    hint.setType(CJavaHint.TYPE);
                    hint.setText(cls.classSimpleName);
                    hint.setClassName(cls.getClassFullName());
                    hint.setDisplayText(cls.classSimpleName + " - " + cls.classFullName);
                    hint.setStartPos(hintStartPos);
                    hint.setEndPos(hintEndPos);
                } else if (ent.getValue() instanceof CodeDeclareInfo)
                {
                    CodeDeclareInfo dec = (CodeDeclareInfo) ent.getValue();
                    if (!dec.getCodeText().toLowerCase().startsWith(sPreFix.toLowerCase()))
                        continue;

                    hint.setType(dec.getType());
                    hint.setText(dec.getCodeText());
                    hint.setClassName(dec.getDeclareClass());
                    hint.setDisplayText(dec.getName());
                    hint.setStartPos(hintStartPos);
                    hint.setEndPos(hintEndPos);
                } else
                {
                    if (!ent.getKey().toLowerCase().startsWith(sPreFix.toLowerCase()))
                        continue;

                    hint.setText(ent.getKey());
                    hint.setDisplayText(ToolUtilities.logString(ent.getValue(), false));
                    hint.setStartPos(hintStartPos);
                    hint.setEndPos(hintEndPos);
                }

                visibleRows.add(new Pair<Float, CJavaHint>(ToolBasic.getStringMatchRate(sPreFix, hint.text), hint));
            }
        }

        // 按字符匹配度来排序，以及按长度排序
        sortHints(visibleRows);
        List<CJavaHint> lstHints = new LinkedList<CJavaHint>();
        for (Pair<Float, CJavaHint> p : visibleRows)
            lstHints.add(p.right);

//        CmnUtil.out("Serach Hint : " + lstHints.size() + ", Time=" + (System.currentTimeMillis() - time) + "ms");

        return lstHints;
    }

    public int checkAutoImport(CJavaCode code, String fullClass) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).checkAutoImport(code, fullClass);
    }

    class MemMatcher implements MemberMatcher
    {
        String keyword = null;

        MemMatcher(String keyword)
        {
            this.keyword = keyword.toLowerCase();
        }

        public boolean accept(Object obj)
        {
            String objText = null;
            if (obj instanceof FieldBinding)
                objText = new String(((FieldBinding) obj).name).toLowerCase();
            else if (obj instanceof MethodBinding)
                objText = new String(((MethodBinding) obj).selector).toLowerCase();
            else if (obj instanceof Method)
                objText = ((Method) obj).getName().toLowerCase();
            else if (obj instanceof Field)
                objText = ((Field) obj).getName().toLowerCase();
            else
                objText = "" + obj;

            return ToolUtilities.isStringIncluded(keyword, objText);
        }
    };

    public void sortHints(List<Pair<Float, CJavaHint>> rows)
    {
        Collections.sort(rows, new Comparator<Pair<Float, CJavaHint>>()
        {
            public int compare(Pair<Float, CJavaHint> o1, Pair<Float, CJavaHint> o2)
            {
                if (o1 == null || o2 == null || o1.left == null || o2.left == null)
                    return ToolUtilities.compareObject(o1, o2);

                String s1 = ToolUtilities.getString(o1.right, "");
                String s2 = ToolUtilities.getString(o2.right, "");

                // 有明显级别差距的，以级别为主
                if (!o1.left.equals(o2.left))
                    return -1 * ToolUtilities.compareFloat(o1.left, o2.left);

                int gradeLeft = getObjectSortGrade(o1.right);
                int gradeRight = getObjectSortGrade(o2.right);
                if (gradeLeft != gradeRight)
                    return ToolUtilities.compareInt(gradeLeft, gradeRight);

                // 关键字（要插入代码的字符）长度，越短排越前面
                int keyLength1 = o1.right.text.length();
                int keyLength2 = o2.right.text.length();
                if (keyLength1 != keyLength2)
                    return ToolUtilities.compareInt(keyLength1, keyLength2);

                // jdk的优先
                boolean jdk1 = isJDK(s1);
                boolean jdk2 = isJDK(s2);
                if (jdk1 != jdk2)
                    return jdk1 ? -1 : 1;

                // 同等级的，以字符串长度为主
                if (s1.length() != s2.length())
                    return Integer.compare(s1.length(), s2.length());
                else
                    return ToolUtilities.compareString(s1, s2);
            }
        });
    }

    public boolean isJDK(String text)
    {
        return text.startsWith("java.") || text.startsWith("javax.") || text.startsWith("jdk.") || text.startsWith("sun.") || text.startsWith("com.sun.") || text.startsWith("com.oracle.");
    }

    public int getObjectSortGrade(CJavaHint hint)
    {
        if (hint.type == CJavaHint.ARGUMENT)
            return 1;
        else if (hint.type == CJavaHint.VARIALBE)
            return 2;
        else if (hint.type == CJavaHint.FIELD)
            return 3;
        else if (hint.type == CJavaHint.INITIAL_BLOCK)
            return 4;
        else if (hint.type == CJavaHint.METHOD)
            return 5;
        else if (hint.type == CJavaHint.TYPE)
            return 6;

        return 10;
    }

    public static List<CJavaCodeDo> getOpenCodeFromZip() throws Exception
    {
        List<CJavaCodeDo> lstRet = new LinkedList();

        File file = new File(ZIP_FILE);
        if (!file.exists() || !file.canRead())
            return lstRet;

        ZipFile zipFile = new ZipFile(file);
        boolean hasEntryError = false;
        for (Enumeration entries = zipFile.entries(); entries.hasMoreElements();)
        {
            ZipEntry entry = null;
            try
            {
                entry = (ZipEntry) entries.nextElement();
                if (hasEntryError)
                    CmnUtil.err(entry);
            } catch (Throwable err)
            {
                ToolUtilities.error(LOG, "Failed to unzip some entry", err);
                hasEntryError = true;
                continue;
            }

            if (entry.isDirectory())
                continue;

            String name = entry.getName();
            if (!name.toLowerCase().endsWith(".java"))
                continue;

            String sFullClass = LvJavac.getMainClassFromFileName(name);

            byte[] bt = ToolUtilities.readAndCloseInputStream(zipFile.getInputStream(entry));
            String sCode = new String(bt, "UTF-8");
            CJavaCodeDo newDo = new CJavaCodeDo();
            newDo.setUuid(CJavaConst.SYSTEM_CODE_PREFIX + CDaoUtil.allocUuid());
            newDo.setOwner(getSysFolder().getUuid());
            newDo.setMaster(getSysProject().getGid(), CJavaProject.LstCode);

            newDo.setCode(sCode);
            newDo.setMainClass(LvJavac.getClassNameFromFull(sFullClass));
            newDo.setJavaPackage(LvJavac.getPackageFromFullClass(sFullClass));
            newDo.setReadOnly(true);
            lstRet.add(newDo);
        }

        return lstRet;
    }

    public List<CJavaCodeDo> getOpenCode() throws Exception
    {
        List<CJavaCodeDo> lstRet = new ArrayList();
        File rootFile = new File(OPEN_SOURCE_PATH);
        String realRootPath = rootFile.getCanonicalPath();
        List<String> lstFiles = ToolUtilities.getAllChildFile(rootFile);
        for (String file : lstFiles)
        {
            File f = new File(file);
            if (!f.isFile() || !f.canRead())
                continue;

            if (!f.getName().toLowerCase().endsWith(".java"))
                continue;

            file = f.getCanonicalPath();
            if (!file.startsWith(realRootPath))
                continue;

            String relatePath = ToolUtilities.replaceAll(file, realRootPath, "");
            String sFullClass = LvJavac.getMainClassFromFileName(relatePath);

            String sCode = new String(ToolUtilities.readFile(file), "UTF-8");
            CJavaCodeDo newDo = new CJavaCodeDo();
            newDo.setUuid(CJavaConst.SYSTEM_CODE_PREFIX + CDaoUtil.allocUuid());
            newDo.setOwner(getSysFolder().getUuid());
            newDo.setMaster(getSysProject().getGid(), CJavaProject.LstCode);

            newDo.setCode(sCode);
            newDo.setMainClass(LvJavac.getClassNameFromFull(sFullClass));
            newDo.setJavaPackage(LvJavac.getPackageFromFullClass(sFullClass));
            newDo.setReadOnly(true);
            lstRet.add(newDo);
        }

        return lstRet;
    }

    public List<String> getDependProjects(CJavaProject project) throws Exception
    {
        return new ArrayList<String>();
    }

    public List<CJavaProject> getAllDependProjects(CJavaProject project) throws Exception
    {
        List<CJavaProject> lstRet = new ArrayList();
        return lstRet;
    }

    public List<LvProblem> compileSingleCode(CJavaCode code, boolean useCache) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).compileSingleCode(code, useCache);
    }

    // 主要用于锁住对工程修改、打开、关闭、删除这几个操作
    StringLock _pjLock = new StringLock(2000);

    public CJavaProject createProject(String name, int dependType) throws Exception
    {
        return createProject(name, dependType, "core");
    }

    // withNewFolder：创建新工程时，自动创建一个源码目录（空则不创建）
    public CJavaProject createProject(String name, int dependType, String withNewFolder) throws Exception
    {
        if (!CmnUtil.isValidFileName(name))
            ToolUtilities.assertValidFileName(name);

        CJavaProject pj = new CJavaProject();
        pj.setName(name);
        pj.setDependType(dependType);

        pj = (CJavaProject) CDaoClient.getIntf().createDo(pj);

        CJavaPJBuilder builder = new CJavaPJBuilder(pj);
        addCache(builder);

        if (!CmnUtil.isStringEmpty(withNewFolder))
            createFolder(pj.getGid(), withNewFolder);

        return pj;
    }

    public void deleteProject(GID pjGid) throws Exception
    {
        LockObject lock = _pjLock.lockDN(pjGid.getUuid());
        try
        {
            CDaoClient.getIntf().deleteDo(CDaoClient.getMe().newDo(pjGid));
            logDeleteProject(pjGid);

            removeCache(pjGid.getUuid());
        } finally
        {
            lock.unlock();
        }
    }
    public boolean deleteCode(String projectUuid, Set<String> fullClass) throws Exception
    {
        return getBuilder_Force(projectUuid).deleteCode(fullClass);
    }

    public CJavaProject updateProject(GID pjGid, Map<String, Object> mapV) throws Exception
    {
        if (!ToolUtilities.contains(CJavaProject.FIELDS_GUI_MODIFYABLE, mapV.keySet()))
            throw new Exception("Can not modify some fields of : " + ToolUtilities.logString(mapV.keySet(), false));

        LockObject lock = _pjLock.lockDN(pjGid.getUuid());
        try
        {
            CDaoClient.getIntf().updateDo(pjGid, mapV);
            CJavaProject newDo = (CJavaProject) CDaoClient.getIntf().getDo(pjGid);
            logUpdateProject(newDo, mapV);
            
            getBuilder_Force(pjGid.getUuid()).updateProjectDo(newDo);
            
            // 修改了某些字段，需要重新编译
            if (ToolUtilities.contains(CJavaProject.FIELDS_REBUILD_ON_CHANGE, mapV.keySet()))
                rebuildAll(pjGid.getUuid());

            return newDo;
        } finally
        {
            lock.unlock();
        }
    }

    public static CJavaProject getProject(String uuid) throws Exception
    {
        // 先取缓存(支持虚拟工程), 不行才查库
        CJavaPJBuilder bd = getMe().getBuilder(uuid);
        if (bd != null)
            return bd.getProject();
        else
            return (CJavaProject) CDaoClient.getIntf().queryDo(GID.build(CJavaProject.class, uuid));
    }

    public static List<CJavaProject> queryProject(Cnd cnd) throws Exception
    {
        return CDaoClient.getIntf().queryDoList(CJavaProject.class.getName(), cnd);
    }

    public List<CJavaProject> getAllProjects() throws Exception
    {
        List<CJavaProject> lstPj = CDaoClient.getIntf().queryDoList(CJavaProject.class.getName(), null);
        lstPj.add(0, getSysProject());
        return lstPj;
    }

    public List<CJavaVirtualProject> getAllVirtualProjects() throws Exception
    {
        List<CJavaVirtualProject> lstPj = CDaoClient.getIntf().queryDoList(CJavaVirtualProject.class.getName(), null);
        return lstPj;
    }

    public CJavaFolder createFolder(GID pjGid, String name) throws Exception
    {
        CJavaFolder fd = new CJavaFolder();
        fd.setMaster(pjGid);
        fd.setName(name);

        return (CJavaFolder) CDaoClient.getIntf().createDo(fd);
    }

    public CJavaFolder saveFolder(GID pjGid, String name) throws Exception
    {
        CJavaFolder fd = (CJavaFolder) CDaoClient.getIntf().queryDo(CJavaFolder.class.getName(), Cnd.where(CJavaFolder.MasterKey, "=", pjGid.getUuid()).and(CJavaFolder.Name, "=", name));
        if (fd != null)
            return fd;

        return createFolder(pjGid, name);
    }

    public boolean deleteFolder(String pjUuid, String folderUuid) throws Exception
    {
        return getBuilder_Force(pjUuid).deleteFolder(folderUuid);
    }

    public boolean deleteFolderByName(String pjUuid, String folderName) throws Exception
    {
        return getBuilder_Force(pjUuid).deleteFolderByName(folderName);
    }

    // 设置文件夹专属人，如果没有指派专属人，则为共享代码
    public void setFolderPrivate(GID folderGid, String privateOwner) throws Exception
    {
        try (CDao dao = newDao())
        {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(CJavaFolder.PrivateOwner, privateOwner);
            map.put(CJavaFolder.PrivateOwner, privateOwner);

            dao.updateDo(folderGid, map);
            dao.commit();
        }
    }

    ReentrantLock _cachelock = new ReentrantLock();

    Map<String, CJavaPJBuilder> _cache = new HashMap<String, CJavaPJBuilder>();

    protected CJavaPJBuilder addCache(CJavaPJBuilder builder)
    {
        _cachelock.lock();
        try
        {
            _cache.put(builder.getProject().getUuid(), builder);
            return builder;
        } finally
        {
            _cachelock.unlock();
        }
    }

    protected void removeCache(String pjRDN)
    {
        try
        {
            getBuilder_Force(pjRDN).cleanBuild();
        } catch (Throwable err)
        {
            ToolUtilities.error(LOG, err);
        }

        _cachelock.lock();
        try
        {
            _cache.remove(pjRDN);
        } finally
        {
            _cachelock.unlock();
        }
    }

    protected void reload() throws Exception
    {
        _cachelock.lock();
        try
        {
            _cache.clear();

            List<CJavaProject> lstPjs = getAllProjects();
            lstPjs = ToolUtilities.addAllToList(lstPjs, getAllVirtualProjects());
            for (CJavaProject pj : lstPjs)
            {
                if (pj.isClosed())
                    continue;

                ToolUtilities.infoAndOutput(LOG, "Build java project cache : " + pj.getName() + " ... ");
                CJavaPJBuilder builder = new CJavaPJBuilder(pj);
                try
                {
                    builder.reloadCache();
                } catch (Exception exp)
                {
                    ToolUtilities.error(LOG, exp);
                }
                addCache(builder);
            }
        } finally
        {
            _cachelock.unlock();
        }
    }

    protected CJavaPJBuilder getBuilder(String pjRDN)
    {
        _cachelock.lock();
        try
        {
            return _cache.get(pjRDN);
        } finally
        {
            _cachelock.unlock();
        }
    }

    // 获取工程构建器，如果找不到则报错（正常不会出现）
    public CJavaPJBuilder getBuilder_Force(String projectUuid)
    {
        /**
         * 这段代码是在(14561版本: 实现带文件持久化的JavaTool)时引入的, 现不明其作用.
         * 由于这段代码会导致系统工程(开源)部分工作不正常, 无法展开看到开源代码, 顾先屏蔽观察 if
         * (isSystemProject(projectUuid)) return new
         * CJavaPJBuilder(getSysProject());
         */

        CJavaPJBuilder builder = getBuilder(projectUuid);
        if (builder == null)
        {
            CJavaProject pjDo = null;
            try
            {
                pjDo = (CJavaProject) CDaoClient.getIntf().getDo(GID.build(CJavaProject.class, projectUuid));
            } catch (Exception exp)
            {
                ToolUtilities.throwRuntimeException(exp);
            }
            if (pjDo == null)
                throw new RuntimeException(SrvRes.getString("Can't find project") + " : " + projectUuid);
            else
                throw new RuntimeException(SrvRes.getString("Please reopen project") + " : " + pjDo.getName());
        }
        return builder;
    }

    // dependType CJavaConst.TYPEXXXXX
    public CJavaDebugPkg prepareLocalDebugPkg(CJavaCode code, int dependType) throws Exception
    {
        CJavaPJBuilder builder = null;
        try
        {
            // 系统工程或调试野代码如JavaTool，都按照临时野代码调试
            if (isSystemProject(code.getProjectUuid()))
                throw new Exception("Debug this as wild code");

            builder = getBuilder_Force(code.getProjectUuid());
        } catch (Throwable err)
        {
            // 如果获取本地工程失败，当做野代码调试（当做脚本执行）
            CJavaDebugPkg pkg = new CJavaDebugPkg();
            pkg.setCode(code);
            pkg.setDependType(CJavaConst.DEPEND_PLUGIN);
            CJavaPJBuilder bd = CJavaPJBuilder.newTempBuilder(CJavaConst.DEPEND_PLUGIN);
            for (ClassFile clsFile : bd.compileExtendCode(code).getOneResult().getClassFiles())
            {
                pkg.addExtClasses(LvJavac.compoundChar2String(clsFile.getCompoundName(), "."), clsFile.getBytes());
            }
            return pkg;
        }

        CJavaDebugPkg pkg = new CJavaDebugPkg();
        pkg.setProject(builder.getProject());
        pkg.setCode(code);
        pkg.setDependType(dependType);

        // 加入工程自己的jar
        File[] myJars = builder.getAllJarPaths();
        if (myJars != null)
            for (File myJar : myJars)
                pkg.addClassPath(myJar.getCanonicalPath());

        // 处理扩展lib目录下的jar/zip，以及依赖工程中的jar
        List<CJavaProject> lstAllDep = getAllDependProjects(builder.getProject());
        if (lstAllDep != null)
            for (CJavaProject depPJ : lstAllDep)
            {
                // 将依赖工程编译输出jar包到临时目录
                CJavaPJBuilder depBuilder = getBuilder_Force(depPJ.getUuid());
                pkg.addClassPath(ToolUtilities.getCanonicalPath(depBuilder.getDstDependPath()));

                // 找出依赖工程里的所有jar包，copy到目标目录
                List<File> libJars = depBuilder.getAllJarPaths(false);
                if (libJars != null)
                    for (File libJar : libJars)
                        pkg.addClassPath(libJar.getCanonicalPath());
            }

        // 加入本地临时编译目录
        List<File> lstPaths = builder.prepareDstPath(true);
        for (File f : lstPaths)
            pkg.addClassPath(f.getCanonicalPath());

        // 临时代码、系统源码
//        if (isSystemProject(code.getProjectUuid()))
//        {
//            Pair<Class, LvCompileResult> pair = builder.compileAndLoadClass(code);
//            pkg.addExtClasses(pair.getKey().getName(), LvJavac.saveClassFile(pair.getValue().getOneResult().getClassFiles()[0], pair.getKey().getName()+".java"));
//        }

        return pkg;
    }

    // 不能及时清理，因为前台靠轮询拿调试信息，所以只能用排队抛弃的缓存机制
    LRUCache<String, CJavaDebugger> _mapDebugger = new LRUCache(MppContext.getInt(CJavaConst.CONF_DEBUGER_CACHE_SIZE, CJavaConst.DEFAULT_DEBUGER_CACHE_SIZE));

    LRUCache<String, String> _mapRubbish = new LRUCache(MppContext.getInt(CJavaConst.CONF_DEBUGER_CACHE_SIZE, CJavaConst.DEFAULT_DEBUGER_CACHE_SIZE));
    
    public final static long DEBUGGER_EXPIRE = 60000;
    LazyPool<CJavaLocalDebuger> _lazyClearDebugger = new LazyPool<CJavaLocalDebuger>("Lazy Clear Local Debugger", DEBUGGER_EXPIRE)
    {
        public void handle(List<CJavaLocalDebuger> lstData)
        {
            long now = System.currentTimeMillis();
            for (CJavaLocalDebuger dbg : Nulls.get(lstData))
            {
                if (now > dbg.getQuitTime()+ DEBUGGER_EXPIRE)
                {
                    dbg.clearCache();
                }else
                    _lazyClearDebugger.add(dbg); // 还没超时的再压回去
            }
        }
        
    };
    // 返回
    public String startDebugInLocal(CJavaCode code, int dependType) throws Exception
    {
        // 本地分配
        CJavaLocalDebuger dbg = new CJavaLocalDebuger() {

            // 成功执行完毕
            public void OnQuit()
            {
                super.OnQuit();
                
                _lazyClearDebugger.add(this);
            }
        };
        _mapDebugger.put(dbg.getUuid(), dbg);

        // 本地启动
        CJavaDebugPkg pkg = prepareLocalDebugPkg(code, dependType);
        dbg.startDebug(pkg);

        return dbg.getUuid();
    }

    public String startDebugRpc(CJavaCode code, HostPort agent, int dependType) throws Exception
    {
        CJavaRpcDebuger dbg = new CJavaRpcDebuger(agent.getHost(), agent.getPort());
        String rmtKey = dbg.startDebug(code, dependType);

        _mapDebugger.put(rmtKey, dbg);
        return rmtKey;
    }

    public String startDebugRpc(CJavaCode code, URI agentUri, int dependType) throws Exception
    {
        CJavaRpcDebuger dbg = new CJavaRpcDebuger(agentUri);
        String rmtKey = dbg.startDebug(code, dependType);

        _mapDebugger.put(rmtKey, dbg);
        return rmtKey;
    }

    public CJavaDebugger getDebuger(String debugKey)
    {
        return _mapDebugger.get(debugKey);
    }

    public String startDebug(CJavaCode code, HostPort agent) throws Exception
    {
        int depType = getCodeDependType(code);

        return startDebug(code, agent, depType);
    }

    public int getCodeDependType(CJavaCode code) throws Exception
    {
        try (CDao dao = newDao())
        {
            if (CJavaConst.isSysCode(code.getUuid()))
                return CJavaConst.DEPEND_PLUGIN;

            return ToolUtilities.getInteger(dao.queryFieldValue(CJavaProject.class, Cnd.where(CDoBasic.UUID, "=", code.getProjectUuid()), CJavaProject.DependType), CJavaConst.DEPEND_PLUGIN);
        }
    }

    public String startDebug(CJavaCode code, URI agentUri) throws Exception
    {
        int depType = getCodeDependType(code);

        return startDebug(code, agentUri, depType);
    }

    public String startDebug(CJavaCode code, HostPort agent, int dependType) throws Exception
    {
        if (agent == null)
        {
            return startDebugInLocal(code, dependType);
        } else
        {
            // 远程调试时，统统都改为依赖全系统插件
            return startDebugRpc(code, agent, CJavaConst.DEPEND_PLUGIN);
        }
    }

    public String startDebug(CJavaCode code, URI agentUri, int dependType) throws Exception
    {
        if (agentUri == null)
        {
            return startDebugInLocal(code, dependType);
        } else
        {
            // 远程调试时，统统都改为依赖全系统插件
            return startDebugRpc(code, agentUri, CJavaConst.DEPEND_PLUGIN);
        }
    }

    public void terminateDebug(String debugKey, long killTime)
    {
        CJavaDebugger dbg = _mapDebugger.get(debugKey);
        if (dbg != null)
        {
            dbg.terminateDebug(killTime);
        }
    }

    public List<CodeDeclareInfo> querySyntaxTree(CJavaCode code) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).querySyntaxTree(code);
    }

    // 单独增量式编译一个代码，并加载类，返回其主类
    // 这个类对象只存在于后端临时加载器，不可返回给前台
    public Pair<Class, LvCompileResult> compileAndLoadClass(CJavaCode code) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).compileAndLoadClass(code);
    }

    public CodeDeclareInfo searchDeclaration(CJavaCode code, String selString, int currPos) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).searchDeclaration(code, selString, currPos);
    }

    public SrvProgressIntf<List<CodeDeclareInfo>> searchSyntaxReference(CJavaCode code, String selString, int currPos) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).searchSyntaxReference(code, selString, currPos);
    }

    public String generateMethodCode(String pjUuid, String classN, String funcName, List<Pair<String, String>> lstParam) throws Exception
    {
        return getBuilder_Force(pjUuid).generateMethodCode(classN, funcName, lstParam);
    }

    public CodeDeclareInfo getSyntaxBindingType(CJavaCode code, int currPos) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).getSyntaxBindingType(code, currPos);
    }

    public CodeDeclareInfo getSyntaxMeaning(CJavaCode code, int currPos) throws Exception
    {
        return getBuilder_Force(code.getProjectUuid()).getSyntaxMeaning(code, currPos);
    }

    public SrvProgressIntf<List<CodeDeclareInfo>> searchText(String projectUuid, String text) throws Exception
    {
        return getBuilder_Force(projectUuid).searchText(text);
    }

    public CJavaCode getJavaCode(String codeUuid) throws Exception
    {
        if (CJavaConst.isSysCode(codeUuid))
            return getBuilder_Force(getSysProject().getUuid()).getCodeByRDN(codeUuid);

        CJavaCodeDo code = (CJavaCodeDo) CDaoClient.getIntf().queryDo(GID.build(CJavaCodeDo.class, codeUuid), CJavaCodeDo.MasterKey, CJavaCodeDo.MainClass, CJavaCodeDo.JavaPackage);
        if (code == null)
            return null;

        return getJavaCode(code.getProjectUuid(), code.getFullClassName());
    }

    public CJavaCode getJavaCode(String projectUuid, String fullClassName) throws Exception
    {
        fullClassName = LvJavac.getMainClassName(fullClassName);
        return getBuilder_Force(projectUuid).getCode(fullClassName);
    }

    public String[] getCodePath(String pjUuid, String fullClassName) throws Exception
    {
        CJavaCode code = getJavaCode(pjUuid, fullClassName);
        if (code == null)
            return null;

        return code.getCodePath();
    }

    public String getLog()
    {
        return "CJava Project Center";
    }

    public CJavaDebugger prepareDebuger(String key) throws NoDebuggerException
    {
        CJavaDebugger dbg = _mapDebugger.get(key);
        if (dbg == null)
            throw new NoDebuggerException();
        return dbg;
    }

    public int getDebugStatus(String debugKey) throws NoDebuggerException
    {
        return prepareDebuger(debugKey).getStatus();
    }

    public Object getDebugResult(String debugKey) throws NoDebuggerException
    {
        return prepareDebuger(debugKey).getResult();
    }

    public String getDebugResultText(String debugKey) throws NoDebuggerException
    {
        return prepareDebuger(debugKey).getResultText();
    }

    public List<String> popDebugTrace(String debugKey) throws NoDebuggerException
    {
        return prepareDebuger(debugKey).popTrace();
    }

    // onlyAlive ：只获取还活着的，正在运行或准备运行的，已结束、出错、消失等的都不返回
    public List<CJavaDebuggerDto> getAllDebugger(boolean onlyAlive)
    {
        List<CJavaDebuggerDto> lst = new LinkedList<CJavaDebuggerDto>();
        for (Entry<String, CJavaDebugger> ent : _mapDebugger.getAll())
        {
            CJavaDebugger dbg = ent.getValue();

            int status = CJavaConst.STATUS_ERROR;
            String errMsg = _mapRubbish.get(dbg.getUuid());
            if (errMsg == null) // 说明不是失联对象
            {
                try
                {
                    // 尝试远程访问，获取状态
                    status = dbg.getStatus();

                    if (dbg.isException())
                        errMsg = dbg.getResultText();
                } catch (Throwable err)
                {
                    status = CJavaConst.STATUS_ERROR;
                    errMsg = ToolUtilities.getExceptionStatck(err);

                    // 失联的，加入垃圾缓存
                    if (CRpcUtil.isDisconnectedException(err))
                        _mapRubbish.put(dbg.getUuid(), errMsg);
                }
            }

            // 过滤掉结束或出错的
            if (onlyAlive)
            {
                if (status == CJavaConst.STATUS_ERROR || status == CJavaConst.STATUS_FINISHED)
                    continue;
            }

            CJavaDebuggerDto dto = new CJavaDebuggerDto();
            dto.setUuid(dbg.getUuid());
            dto.setName(dbg.getName());
            if (dbg instanceof CJavaRpcDebuger)
                dto.setRunningOn(((CJavaRpcDebuger) dbg).getHostPort());
            else
                dto.setRunningOn(new HostPort().setHost(ToolBasic.getCurrentIP()).setPort(CRpcServer.getNioPort()));

            dto.setStartTime(dbg.getStartTime());
            dto.setClientInfo(dbg.getClientInfo());
            dto.setStatus(status);
            dto.setErrorMsg(errMsg);
            lst.add(dto);
        }

        return lst;
    }

    public CResFileDo addResFile(GID pjGid, CResFileDo resDo) throws Exception
    {
        try (CDao dao = newDao())
        {
            resDo.setMaster(pjGid, CJavaProject.LstRes);
            resDo.updateFileInfo();
            resDo = dao.createDo(resDo);

            CJavaPJBuilder builder = getBuilder(pjGid.getUuid());
            if (builder != null && !builder.getProject().isClosed())
                builder.saveResFile(resDo); // 存到构建路径

            // 成功存入builder中，再提交
            dao.commit();
            return resDo;
        }
    }

    public void deleteResFile(GID resGid) throws Exception
    {
        try (CDao dao = newDao())
        {
            CResFileDo fileDo = (CResFileDo) dao.queryDo(resGid, CResFileDo.FIELDS_BRIEF);
            if (fileDo == null)
                return;

            dao.deleteDo(resGid);

            CJavaPJBuilder builder = getBuilder(fileDo.getProjectUuid());
            if (builder != null)
                builder.deleteResFile(fileDo.getFolder(), fileDo.getPhysicalPath());

            // 先删除builder中的再提交
            dao.commit();
        }
    }

    public CJarFile addJarFile(GID pjGid, CJarFile jarDo) throws Exception
    {
        try (CDao dao = newDao())
        {
            jarDo.setMaster(pjGid, CJavaProject.JarFiles);
            jarDo.updateMd5();
            jarDo = dao.createDo(jarDo);

            CJavaPJBuilder builder = getBuilder(jarDo.getProjectUuid());
            if (builder != null && !builder.getProject().isClosed())
                builder.saveJarFile(jarDo);

            // 成功存入builder中，再提交
            dao.commit();
            return jarDo;
        }
    }

    public List<CJarFile> getJarFiles(String projectUuid, boolean onlyBrief) throws Exception
    {
        if (CJavaConst.isSysProject(projectUuid))
            return new LinkedList();
        else
            return CDaoClient.getIntf().queryDoList(CJarFile.class.getName(), Cnd.where(CJarFile.MasterKey, "=", projectUuid), onlyBrief ? CJarFile.FIELDS_BRIEF : null);
    }

    public CJarFile getJarFile(String projectUuid, String fileName) throws Exception
    {
        if (CJavaConst.isSysProject(projectUuid))
            return null;

        try (CDao dao = newDao())
        {
            return dao.queryDo(CJarFile.class, Cnd.where(CJarFile.MasterKey, "=", projectUuid).and(CJarFile.Name, "=", fileName), CJarFile.FIELDS_BRIEF);
        }
    }

    public void deleteJarFile(GID jarGid) throws Exception
    {
        try (CDao dao = newDao())
        {
            CJarFile fileDo = (CJarFile) dao.queryDo(jarGid, CJarFile.FIELDS_BRIEF);
            if (fileDo == null)
                return;

            dao.deleteDo(jarGid);

            CJavaPJBuilder builder = getBuilder(fileDo.getProjectUuid());
            if (builder != null)
                builder.deleteJarFile(fileDo);

            // 先删除builder中的再提交
            dao.commit();
        }
    }

    public boolean hasJarFiles(String pjUuid) throws Exception
    {
        if (CJavaConst.isSysProject(pjUuid))
            return false;

        try (CDao dao = newDao())
        {
            return dao.queryDo(CJarFile.class, Cnd.where(CJarFile.MasterKey, "=", pjUuid), CDoBasic.UUID) != null;
        }
    }

    // folderUuid可以不传，不传则表示不区分目录
    public List<CResFileDo> getResFiles(String projectUuid, String filterFolderUuid, boolean onlyBrief) throws Exception
    {
        if (CJavaConst.isSysProject(projectUuid))
            return new LinkedList();
        else
        {
            Cnd cnd = Cnd.where(CResFileDo.MasterKey, "=", projectUuid);
            if (!CmnUtil.isStringEmpty(filterFolderUuid))
                cnd.and(CResFileDo.Owner, "=", filterFolderUuid);
            return CDaoClient.getIntf().queryDoList(CResFileDo.class.getName(), cnd, onlyBrief ? CResFileDo.FIELDS_BRIEF : null);
        }
    }

    /**
     * 查询某工程下的资源文件
     * 
     * @param filterFolderUuid
     *            ： 给定源码目录过滤，传空表示不过滤，所有源码目录都要
     * @param pkg
     *            ：给定包名，传空则表示只查询无包名的资源文件，传值则按包名过滤，如果传入“*”表示不过滤包名
     * @param onlyBrief
     *            ：是否只取摘要字段
     */
    public List<CResFileDo> queryResFiles(String projectUuid, String filterFolderUuid, String pkg, boolean onlyBrief) throws Exception
    {
        if (CJavaConst.isSysProject(projectUuid))
            return new LinkedList();
        else
        {
            Cnd cnd = Cnd.where(CResFileDo.MasterKey, "=", projectUuid);
            if (!CmnUtil.isStringEmpty(filterFolderUuid))
                cnd.and(CResFileDo.Owner, "=", filterFolderUuid);

            if (!"*".equals(pkg))
            {
                if (CmnUtil.isStringEmpty(pkg))
                    cnd.and(new SqlExpressionGroup().or(CResFileDo.FilePackage, "=", "").orIsNull(CResFileDo.FilePackage));
                else
                    cnd.and(CResFileDo.FilePackage, "=", pkg);
            }

            return CDaoClient.getIntf().queryDoList(CResFileDo.class.getName(), cnd, onlyBrief ? CResFileDo.FIELDS_BRIEF : null);
        }
    }

    public CResFileDo getResFile(String projectUuid, String filePath, boolean onlyBrief) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return getResFile(dao, projectUuid, filePath, onlyBrief);
        }
    }

    public static CResFileDo getResFile(IDao dao, String projectUuid, String filePath, boolean onlyBrief) throws Exception
    {
        if (CJavaConst.isSysProject(projectUuid))
            return null;

        String pkgPath = ToolBasic.getDirectory(filePath);
        if (!CmnUtil.isStringEmpty(pkgPath))
            pkgPath = CmnUtil.filePath2JavaPackage(pkgPath);// 转换成包名

        String name = ToolBasic.getPureFileName(filePath);

        return dao.queryDo(CResFileDo.class, Cnd.where(CResFileDo.MasterKey, "=", projectUuid).and(CResFileDo.FilePackage, "=", pkgPath).and(CResFileDo.FileName, "=", name), onlyBrief ? CResFileDo.FIELDS_BRIEF : null);
    }

    public CPluginProjectDto exportProject2Plugin(String projectUuid, String dstPluginProjectName, boolean includeSubJars) throws Exception
    {
        return exportProject2Plugin(projectUuid, dstPluginProjectName, includeSubJars, true);
    }

    public CPluginProjectDto exportProject2Plugin(String projectUuid, String dstPluginProjectName, boolean includeSubJars, boolean ignoreCompileError) throws CodeCompileException, Exception
    {
        CJavaPJBuilder builder = getBuilder_Force(projectUuid);
        if (dstPluginProjectName == null)
            dstPluginProjectName = builder.getProject().getName();

        builder.assertNotVirtual();
        if (builder.getProject().isUdfLib())
            throw new Exception("Can not export UDF library to plugin");

        // 导出到插件时，不要导出依赖工程的jar
        List<CPluginJarDto> lstJars = builder.exportJar(false, ignoreCompileError);

        CPluginProjectDto pluginProject = new CPluginProjectDto();
        pluginProject.setName(dstPluginProjectName);

        CPluginExportPackage pkg = new CPluginExportPackage();
        pkg.setProject(pluginProject).setLstJars(lstJars);
        pkg.setJavaProjectKey(builder.getProject().getUuid());

        return ClassFactory.exportPublishPlugin(pkg, true);
    }

    // 将工程在开发中心上直接设置到全局，一旦插件更新，就会冲掉
//    public LvClassLoader grayPublish(String projectUuid) throws CodeCompileException, Exception
//    {
//        if (true)
//            return grayPublish(projectUuid, false);
//        
//        CJavaPJBuilder builder = getBuilder_Force(projectUuid);
//
//        if (builder.getProject().isUdfLib())
//            throw new Exception("Can not export UDF library to plugin");
//
//        LvCompileSingleResult rs = builder.rebuildAll();
//        if (rs.hasErrors())
//            throw new CodeCompileException("Solve all compile error first");
//        
//        // 排除当前灰度发布的工程对应的插件文件
//        Set<String> excludeJars = new HashSet<String>();
//        Set<String> excludePj = ClassFactory.getGraySet();
//        excludePj.add(projectUuid);
//        for (String pj : excludePj)
//        {
//            CJavaProject pjDo = getProject(pj);
//            if (pjDo == null)
//                continue;
//            
//            Map<String, CJavaFolder> folders = getFolderMap(pj);
//            for (CJavaFolder fd : folders.values())
//            {
//                excludeJars.add(CJavaUtil.toJarFileName(pjDo.getName(), fd.getName()));
//            }
//        }
//        
//        // 新的临时loader做灰度发布
//        GrayPackage pkg = new GrayPackage(projectUuid, rs.getByteMap(), rs.getListResFiles());
//        ClassFactory.grayPublish(pkg, excludeJars);
//        
//        // 每次灰发，以最新灰发后的全量类信息来重新加载CELL
//        BasiceClassInfoLoader infoLoader = new BasiceClassInfoLoader();
//        infoLoader.parseClassLoader(ClassFactory.getValidClassLoader());
//        CellServerFactory.getMe().replaceCellMap(infoLoader, ClassFactory.getValidClassLoader());
//        ToolUtilities.warnAndOutput(LOG, "Gray publish : " + ClassFactory.getValidClassLoader());
//        return ClassFactory.getValidClassLoader();
//    }
//    

    /**
     * 灰度发布工程，将若干灰度发布的工程编译结果汇总暂存于灰度目录下，并以特殊类加载器加载
     * 然后接管ClassFactory，是所有类构建统统桥接到灰度库
     * 
     * 仅在开发机进程内，临时生效（以projectUuid为key），会自动清理垃圾类
     * 当真正的插件发布时，会清空灰度发布的内容，抛弃旧的灰度发布的类加载器及相关文件
     * 
     * @param rebuildAll
     *            ：发布之前，是否全量编译该工程
     */
    ReentrantLock _lockGray = new ReentrantLock();

    public LvClassLoader grayPublish(String projectUuid, boolean rebuild) throws CodeCompileException, Exception
    {
        try (AutoLock lc = AutoLock.lock(_lockGray))
        {
            CJavaPJBuilder builder = getBuilder_Force(projectUuid);

            builder.assertNotVirtual();
            if (builder.getProject().isUdfLib())
                throw new Exception("Can not export UDF library to plugin");

            // 刚巧正在全量编译的话，可省去编译
            boolean rebuilding = false;
            while (builder.isLockRebuildAll())
            {
                rebuilding = true;
                ToolUtilities.sleep(10);
            }

            if (rebuild && !rebuilding)
            {
                LvCompileSingleResult rs = builder.rebuildAll();
                if (rs.hasErrors())
                    throw new CodeCompileException("Solve all compile error first");
            } else
            {
                if (builder.hasError())
                    throw new CodeCompileException("Some compile error remains, please try rebuild all");
            }

            long tag = System.currentTimeMillis();
            String pjUuid = builder.getProject().getUuid();
            String targetFolder = ClassFactory.GRAY_LIB_FOLDER + pjUuid + "_" + tag + "/";

            // 拷贝文件去灰发区
            Set<String> srcFolders = getFolderUuids(pjUuid);
            for (String fd : Nulls.get(srcFolders))
            {
                ToolUtilities.copyFile(builder.getDstPath(fd), targetFolder, false);
            }

            // 排除当前灰度发布的工程对应的插件文件
            Set<String> excludeJars = new HashSet<String>();
            Set<String> excludePj = ClassFactory.getGraySet();
            excludePj.add(projectUuid);
            for (String pj : excludePj)
            {
                CJavaProject pjDo = getProject(pj);
                if (pjDo == null)
                    continue;

                Map<String, CJavaFolder> folders = getFolderMap(pj);
                for (CJavaFolder fd : folders.values())
                {
                    excludeJars.add(CJavaUtil.toJarFileName(pjDo.getName(), fd.getName()));
                }
            }

            LvClassLoader newLoader = ClassFactory.grayPublish(pjUuid, targetFolder, excludeJars);

            // 每次灰发，以最新灰发后的全量类信息来重新加载CELL
            _lazyRebuildCell.add(newLoader);

            return newLoader;
        }
    }

    LazyPool<LvClassLoader> _lazyRebuildCell = new LazyPool<LvClassLoader>("Parse CELL from gray publish", 100)
    {
        public void handle(List<LvClassLoader> lstData)
        {
            if (lstData == null || lstData.isEmpty())
                return;

            // 取最新的
            LvClassLoader loader = lstData.get(lstData.size() - 1);

            try (AutoLock lc = AutoLock.lock(_lockGray))
            {
                BasiceClassInfoLoader infoLoader = new BasiceClassInfoLoader();
                Set<Class> setCls = CellFinder.getAllCellClasses(loader);
                CellServerFactory.getMe().replaceCellMap(setCls, loader);
                ToolUtilities.warnAndOutput(LOG, "Gray publish : " + loader);
            } catch (Throwable err)
            {
                ToolUtilities.error(LOG, "Failed to update CELLS after gray publish");
            }
        }
    };

    /**
     * 流式带进度导出整个工程
     */
    public void streamExportProject(IProgress<byte[]> prog, String projectUuid, Set<String> srcFolderNames, CSession session) throws Exception
    {
        try
        {
            byte[] data = exportProject(new ChildProgress(0, 30, prog), projectUuid, srcFolderNames, session);
            if (data == null)
                return;

            ByteBuffer bf = new ByteBuffer(data);

            int totalK = bf.size() / 1024; // K
            int page = 64 * 1024;

            while (bf.isReadable())
            {
                IProgressUtil.assertCancel(prog);

                int per = IProgressUtil.calcPercent(30, bf.getIndex() / 1024, totalK);
                IProgressUtil.sendProcess(prog, per, "Transfer data bytes : " + ToolUtilities.fileSize2String(bf.getIndex()), true);
                IProgressUtil.sendDataFrame(prog, bf.read(page));
            }
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    /**
     * 按照给定的源码目录UUID，导出工程（给外部Eclipse等） 给定目录的部分，输出源代码，其它的部分输出公共jar包
     * 另外会将平台的所有lib/lib_ui，插件中的公共包（除源码之外）
     */
    public byte[] exportProject(ProgressControllerFEIntf prog, String projectUuid, Set<String> srcFolderNames, CSession session) throws Exception
    {
        CJavaPJBuilder builder = getBuilder_Force(projectUuid);
        String name = builder.getProject().getName();

        byte[] bt = null;
        String tmpDstFolder = "temp/export/export_project_" + ToolUtilities.allockUUIDWithUnderline();
        try
        {
            try
            {
                ToolUtilities.copyFile("conf/version.conf", tmpDstFolder + "/" + CJavaConst.PATH_EXPORT_Conf, true);
            } catch (Throwable err)
            {
                // 忽略，BAP平台没有此文件，DNS才需要
            }

            // 导出平台自身lib/lib_ui的所有jar
            if (!builder.getProject().isIsolate())
            {
                IProgressUtil.sendProcess(prog, 0, "Export platform library", true);
                List<File> lstFiles = ToolUtilities.getAllChildFileObject(new File("lib"));
                ToolUtilities.combineList(lstFiles, ToolUtilities.getAllChildFileObject(new File("lib_ui")));
                for (File fl : lstFiles)
                {
                    if (fl.isFile())
                        ToolUtilities.saveFile(tmpDstFolder + "/" + CJavaConst.PATH_EXPORT_Platform + "/" + fl.getName(), ToolUtilities.readFile(fl.getAbsolutePath()), false);
                }
            }

            // 导出项目自身引入的包
            IProgressUtil.assertCancel(prog);
            IProgressUtil.sendProcess(prog, 10, "Export project private library", true);
            List<CJarFile> lstJars = getJarFiles(projectUuid, false);
            if (lstJars != null)
                for (CJarFile jar : lstJars)
                {
                    ToolUtilities.saveFile(tmpDstFolder + "/" + CJavaConst.PATH_EXPORT_Project + "/" + jar.getName(), jar.getFileBin(), false);
                }

            // 导出插件（只提供非私有的)
            if (builder.getProject().isDependPlugin() || builder.getProject().isUdfLib())
            {
                IProgressUtil.assertCancel(prog);
                IProgressUtil.sendProcess(prog, 30, "Export plugin library", true);
                long pluginTag = ClassFactory.getPluginTag();

                // 排除源码对应的jar
                Set<String> excludeJars = new HashSet<String>();
                if (!CmnUtil.isObjectEmpty(srcFolderNames))
                {
                    for (String fdUuid : srcFolderNames)
                        excludeJars.add(CJavaUtil.toJarFileName(name, fdUuid));
                }

                Map<String, byte[]> mapPlugin = ClassFactory.downloadPlugin(true, excludeJars);
                if (mapPlugin != null)
                {
                    for (Entry<String, byte[]> ent : mapPlugin.entrySet())
                        ToolUtilities.saveFile(tmpDstFolder + "/" + CJavaConst.PATH_EXPORT_Plugin + "/" + ent.getKey(), ent.getValue(), false);
                }
                ToolUtilities.saveFile(tmpDstFolder + "/" + CJavaConst.PATH_EXPORT_PLUGIN_TAG_PATH, "" + pluginTag, "UTF-8", false);
            }

            // 导出所有自定义模型
            if (!builder.getProject().isIsolate())
            {
                IProgressUtil.assertCancel(prog);
                IProgressUtil.sendProcess(prog, 50, "Export DAO library", true);
                long moTag = CDaoClient.getMe().exportJar(tmpDstFolder + "/" + CJavaConst.PATH_EXPORT_DAO_JAR_PATH);
                ToolUtilities.saveFile(tmpDstFolder + "/" + CJavaConst.PATH_EXPORT_DAO_TAG_PATH, "" + moTag, "UTF-8", false);
            }

            // 导出工程源码（有源码的会去删掉对应的plugin下的jar）
            builder.exportSourceFiles(tmpDstFolder, srcFolderNames);

            // 导出开源包
            File srcZip = prepareOpenSrcZip();
            if (srcZip != null)
                ToolUtilities.copyFile(srcZip.getAbsolutePath(), tmpDstFolder + "/" + CJavaConst.PATH_EXPORT_Open_Src, true);

            IProgressUtil.assertCancel(prog);
            IProgressUtil.sendProcess(prog, 60, "Zip data", true);
            String zipFile = tmpDstFolder + "/project.zip";
            ZipUtils.zip(tmpDstFolder, zipFile, "UTF-8");
            return ToolUtilities.readFile(zipFile);
        } finally
        {
            ToolUtilities.deleteFileFolder(tmpDstFolder);
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    public Set<String> streamExportPlatformJars(IProgress<byte[]> prog, Map<String, String> mapMd5) throws Exception
    {
        try
        {
            Pair<byte[], Set<String>> data = exportPlatformJars(new ChildProgress(0, 30, prog), mapMd5);
            if (data == null)
                return null;

            // 有数据需要上传的，则用流式上传
            if (!CmnUtil.isObjectEmpty(data.left))
            {
                ByteBuffer bf = new ByteBuffer(data.left);

                int totalK = bf.size() / 1024; // K
                int page = 64 * 1024;

                while (bf.isReadable())
                {
                    IProgressUtil.assertCancel(prog);

                    int per = IProgressUtil.calcPercent(30, bf.getIndex() / 1024, totalK);
                    IProgressUtil.sendProcess(prog, per, "Transfer data bytes : " + ToolUtilities.fileSize2String(bf.getIndex()), true);
                    IProgressUtil.sendDataFrame(prog, bf.read(page));
                }
            }

            return data.right;
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    /**
     * 增量导出平台自身的所有jar包，项目本身引入的jar包（lib/lib_ui的所有jar），主要用于增量更新
     *
     * @param mapMd5
     *            ： 只包含远端（Eclipse开发端）lib/platform目录下所有文件（纯文件名不含路径）对应的md5码
     * @return 差异压缩包（包含新增和修改的），以及不存在的名字列表
     */
    public Pair<byte[], Set<String>> exportPlatformJars(ProgressControllerFEIntf prog, Map<String, String> mapMd5) throws Exception
    {
        try (TempFile tmpFolder = new TempFile("export_platform_jars"))
        {
            IProgressUtil.sendProcess(prog, 0, "Scan platform library files", true);
            File libRoot = new File("lib");
            List<File> lstFiles = ToolUtilities.getAllChildFileObject(libRoot);
            ToolUtilities.combineList(lstFiles, ToolUtilities.getAllChildFileObject(new File("lib_ui")));
            Set<String> setChecked = new HashSet(); // lstFiles里有大量重名的，处理过就不再处理了
            for (File fl : lstFiles)
            {
                if (!fl.isFile())
                    continue;

                // 按照文件名，比对MD5码，存在且相同的则忽略掉（不做导出）
                String fileKeyName = fl.getName();
                if (setChecked.contains(fileKeyName))
                    continue;

                setChecked.add(fileKeyName);
                if (mapMd5.containsKey(fileKeyName))
                {
                    String rmtMd5 = mapMd5.remove(fileKeyName);

                    String thisMd5 = MD5Util.encode(ToolUtilities.readFile(fl.getAbsolutePath()));
                    if (ToolUtilities.isStringEqual(rmtMd5, thisMd5))
                        continue;
                }

                IProgressUtil.sendProcess(prog, 4, "Load platform library file : " + fileKeyName, true);
                ToolUtilities.saveFile(tmpFolder.getAbsolutePath() + "/" + CJavaConst.PATH_EXPORT_Platform + "/" + fileKeyName, ToolUtilities.readFile(fl.getAbsolutePath()), false);
            }

            IProgressUtil.sendProcess(prog, 50, "Zip file package", true);
            byte[] bt = null;
            if (tmpFolder.exists())
            {
                try (TempFile tmpZip = new TempFile("export_project_zip"))
                {
                    ZipUtils.zip(tmpFolder.getAbsolutePath(), tmpZip.getAbsolutePath(), "UTF-8");
                    bt = ToolUtilities.readFile(tmpZip.getAbsolutePath());
                }
            }

            return new Pair(bt, new HashSet(mapMd5.keySet()));
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    /**
     * 导出项目本身引入的jar包（lib/project目录下的），主要用于增量更新
     *
     * @param mapMd5
     *            ： 只包含远端（Eclipse开发端）lib/project目录下所有文件（纯文件名不含路径）对应的md5码
     * @return 差异压缩包（包含新增和修改的），以及不存在的名字列表
     */
    public Pair<byte[], Set<String>> exportProjectJars(String pjUuid, Map<String, String> mapMd5) throws Exception
    {
        try (TempFile tmpFolder = new TempFile("export_project_jars"))
        {
            List<CJarFile> lstJars = getJarFiles(pjUuid, false);
            if (lstJars != null)
                for (CJarFile jar : lstJars)
                {
                    // 按照文件名，比对MD5码，存在且相同的则忽略掉（不做导出）
                    if (mapMd5.containsKey(jar.getName()))
                    {
                        String rmtMd5 = mapMd5.remove(jar.getName());

                        String thisMd5 = MD5Util.encode(jar.getFileBin());
                        if (ToolUtilities.isStringEqual(rmtMd5, thisMd5))
                            continue;
                    }

                    ToolUtilities.saveFile(tmpFolder.getAbsolutePath() + "/" + CJavaConst.PATH_EXPORT_Project + "/" + jar.getName(), jar.getFileBin(), false);
                }

            byte[] bt = null;
            if (tmpFolder.exists())
            {
                try (TempFile tmpZip = new TempFile("export_project_zip"))
                {
                    ZipUtils.zip(tmpFolder.getAbsolutePath(), tmpZip.getAbsolutePath(), "UTF-8");
                    bt = ToolUtilities.readFile(tmpZip.getAbsolutePath());
                }
            }

            return new Pair(bt, new HashSet(mapMd5.keySet()));
        }
    }

    // 为外部工程导出DAO模型文件以及TAG
    public byte[] exportModelFile(long daoTag) throws Exception
    {
        long thisTag = CDaoClient.getMe().getClassTimeTag();
        if (thisTag == daoTag)
            return null;

        try (TempFile tmpFolder = new TempFile("export_dao_model_jar"))
        {
            thisTag = CDaoClient.getMe().exportJar(tmpFolder.getAbsolutePath() + "/" + CJavaConst.PATH_EXPORT_DAO_JAR_PATH);
            ToolUtilities.saveFile(tmpFolder.getAbsolutePath() + "/" + CJavaConst.PATH_EXPORT_DAO_TAG_PATH, "" + thisTag, "UTF-8", false);

            try (TempFile tmpZip = new TempFile("export_plugin_zip"))
            {
                ZipUtils.zip(tmpFolder.getAbsolutePath(), tmpZip.getAbsolutePath(), "UTF-8");
                return ToolUtilities.readFile(tmpZip.getAbsolutePath());
            }
        }
    }

    // 为外部Eclipse工程导出插件Jar以及TAG文件，同时排除给定名字的源码目录对应的jar包
    public byte[] exportPluginJars(long pluginTag, String projectUuid, Collection<String> srcFolderName) throws Exception
    {
        long thisTag = ClassFactory.getPluginTag();
        if (thisTag == pluginTag)
            return null;

        Set<String> excludeJars = new HashSet<String>();
        if (!CmnUtil.isObjectEmpty(srcFolderName))
        {
            CJavaPJBuilder builder = getBuilder_Force(projectUuid);
            String pjName = builder.getProject().getName();
            for (String srcFolder : srcFolderName)
                excludeJars.add(CJavaUtil.toJarFileName(pjName, srcFolder));
        }

        // 导出所有plugin
        try (TempFile tmpFolder = new TempFile("export_plugin_jar"))
        {
            Map<String, byte[]> mapPlugin = ClassFactory.downloadPlugin(true, excludeJars);
            if (mapPlugin != null)
                for (Entry<String, byte[]> ent : mapPlugin.entrySet())
                {
                    if (!excludeJars.contains(ent.getKey()))
                        ToolUtilities.saveFile(tmpFolder.getAbsolutePath() + "/" + CJavaConst.PATH_EXPORT_Plugin + "/" + ent.getKey(), ent.getValue(), false);
                }
            ToolUtilities.saveFile(tmpFolder.getAbsolutePath() + "/" + CJavaConst.PATH_EXPORT_PLUGIN_TAG_PATH, "" + thisTag, "UTF-8", false);

            try (TempFile tmpZip = new TempFile("export_plugin_zip"))
            {
                ZipUtils.zip(tmpFolder.getAbsolutePath(), tmpZip.getAbsolutePath(), "UTF-8");
                return ToolUtilities.readFile(tmpZip.getAbsolutePath());
            }
        }
    }

    // [新]为外部Eclipse工程导出差异化插件Jar以及TAG文件，同时排除给定名字的源码目录对应的jar包
    // 此方法按MD5比对更新jar文件, 不会全量发送
    /**
     * [新]为外部Eclipse工程导出差异化插件Jar以及TAG文件，同时排除给定名字的源码目录对应的jar包 此方法按MD5比对更新jar文件,
     * 不会全量发送 传入clientFileMd5为jar文件名对应MD5码
     */
    public FileUpdatePackage exportPluginJars(Map<String, String> clientFileMd5, String projectUuid, Collection<String> srcFolderName) throws Exception
    {
        long nowTag = ClassFactory.getPluginTag();

        Set<String> excludeJars = new HashSet<String>();
        if (!CmnUtil.isObjectEmpty(srcFolderName))
        {
            CJavaPJBuilder builder = getBuilder_Force(projectUuid);
            String pjName = builder.getProject().getName();
            for (String srcFolder : srcFolderName)
                excludeJars.add(CJavaUtil.toJarFileName(pjName, srcFolder));
        }

        // 导出所有plugin
        List<String> lstDelete = new LinkedList();
        try (TempFile tmpFolder = new TempFile("export_plugin_jar"))
        {
            Map<String, byte[]> mapPlugin = ClassFactory.downloadPlugin(true, excludeJars);
            if (mapPlugin != null)
            {
                for (Entry<String, byte[]> ent : mapPlugin.entrySet())
                {
                    if (!excludeJars.contains(ent.getKey()))
                    {
                        // 比对MD5, 如果一致则忽略此文件
                        String clientMd5 = clientFileMd5.get(ent.getKey());
                        if (clientFileMd5 != null)
                        {
                            String myMd5 = MD5Util.encode(ent.getValue());
                            if (ToolUtilities.isStringEqual(clientMd5, myMd5))
                                continue;
                        }

                        ToolUtilities.saveFile(tmpFolder.getAbsolutePath() + "/" + CJavaConst.PATH_EXPORT_Plugin + "/" + ent.getKey(), ent.getValue(), false);
                    }
                }
            }
            ToolUtilities.saveFile(tmpFolder.getAbsolutePath() + "/" + CJavaConst.PATH_EXPORT_PLUGIN_TAG_PATH, "" + nowTag, "UTF-8", false);

            // 反向遍历查找客户端存在哪些脏文件(需要删除)
            for (String clientFile : clientFileMd5.keySet())
            {
                if (clientFile.equals(CJavaConst.PATH_EXPORT_PLUGIN_TAG_FILE))
                    continue;
                if (mapPlugin ==null || !mapPlugin.containsKey(clientFile))
                    lstDelete.add(clientFile);
            }

            try (TempFile tmpZip = new TempFile("export_plugin_zip"))
            {
                ZipUtils.zip(tmpFolder.getAbsolutePath(), tmpZip.getAbsolutePath(), "UTF-8");
                byte[] zipBin = ToolUtilities.readFile(tmpZip.getAbsolutePath());
                FileUpdatePackage pkgRet = new FileUpdatePackage().setZipContent(zipBin);
                pkgRet.setDeleteList(lstDelete);
                return pkgRet;
            }
        }
    }

    // 获取src.zip，如果不存在则压缩一个，如果目录都不存在则返回空
    public static File prepareOpenSrcZip()
    {
        if (!new File(CJavaConst.PATH_EXPORT_Open_Src).exists())
            return null;

        File file = new File(CJavaConst.PATH_EXPORT_Open_Src + "/" + CJavaConst.Open_Src_File);
        if (!file.exists())
        {
            // 如果没有src.zip，则马上压缩生成一个
            ZipUtils.zip(CJavaConst.PATH_EXPORT_Open_Src, file.getAbsolutePath(), "UTF-8");
        }

        return file;
    }

    // 导出开源代码包
    public byte[] exportOpenSource(String md5) throws Exception
    {
        File srcZip = prepareOpenSrcZip();
        if (srcZip == null)
            return null;

        String localMd5 = null;
        byte[] bt = null;

        // 看看有无缓存的md5码，解析一次还挺慢的所以需要缓存
        File fMd5 = new File(CJavaConst.PATH_EXPORT_Open_Src, CJavaConst.Open_Src_Md5_File);
        if (fMd5.exists() && fMd5.canRead())
        {
            localMd5 = ToolUtilities.readFile(fMd5.getAbsolutePath(), "UTF-8", false).toString();
        } else
        {
            bt = ToolUtilities.readFile(srcZip.getAbsolutePath());
            localMd5 = bt == null ? null : MD5Util.encode(bt);
            ToolUtilities.saveFileUtf8(fMd5.getAbsolutePath(), localMd5, false);
        }

        if (CmnUtil.isStringEqual(localMd5, md5))
            return null;

        if (bt == null)
            bt = ToolUtilities.readFile(srcZip.getAbsolutePath());

        return bt;
    }

    /**
     * 主要用于和本地java文件对比，所以只返回文件的摘要信息以及路径的形式
     * 
     * 以文件路径为key的形式，返回某个文件夹下所有java代码的简要信息，MD5码等
     */
    public Map<String, JavaDto> queryCodeFileMap(String projectUuid, String folderName) throws NoFolderException, Exception
    {

        CJavaPJBuilder builder = getBuilder_Force(projectUuid);

        try (IDao dao = IDaoService.newIDao())
        {
            Map<String, JavaDto> map = new HashMap<String, JavaDto>();
            CJavaFolder fd = builder.queryFolderDo(dao, folderName);
            if (fd == null)
                throw new NoFolderException();

            int pos = 0;
            for (;;)
            {
                Class codeCls = builder.isVirtual() ? CJavaVirtualCodeDo.class : CJavaCodeDo.class;
                MultiPageResult<CJavaCodeDo> page = dao.cqueryDoPage(codeCls, Cnd.where(CJavaCodeDo.MasterKey, "=", projectUuid).and(CJavaCodeDo.Owner, "=", fd.getUuid()), CPager.build(pos, 100), CJavaCodeDo.JavaPackage,
                        CJavaCodeDo.MainClass, CJavaCodeDo.Code, CJavaCodeDo.LastWriter);
                if (!page.hasData())
                    break;
                pos += 100;

                for (CJavaCodeDo o : page.getListData())
                {
                    String path = LvJavac.getClassFilePath(o.getFullClassName());
                    JavaDto dto = new JavaDto(path, null);
                    dto.setFullClass(o.getFullClassName());
                    dto.setMd5(MD5Util.encode(o.getCode()));
                    dto.setLastWriter(o.getLastWriter());
                    map.put(path, dto);
                }
            }

            return map;
        }
    }

    public static CJavaFolder queryFolderDo(IDao dao, String pjUuid, String folderName)
    {
        return dao.queryDo(CJavaFolder.class, Cnd.where(CJavaFolder.MasterKey, "=", pjUuid).and(CJavaFolder.Name, "=", folderName));
    }

    /**
     * 主要用于和本地文件对比，所以只返回文件的摘要信息以及路径的形式
     * 
     * 以文件路径为key的形式，返回某个文件夹下所有资源文件的简要信息，MD5码等
     */
    public Map<String, FileDto> queryResFileMap(String projectUuid, String folderName) throws NoFolderException, Exception
    {

        try (IDao dao = IDaoService.newIDao())
        {
            CJavaFolder fd = queryFolderDo(dao, projectUuid, folderName);
            if (fd == null)
                throw new NoFolderException();

            Map<String, FileDto> map = new HashMap<String, FileDto>();
            int pos = 0;
            for (;;)
            {
                MultiPageResult<CResFileDo> page = dao.cqueryDoPage(CResFileDo.class, Cnd.where(CJavaCodeDo.MasterKey, "=", projectUuid).and(CJavaCodeDo.Owner, "=", fd.getUuid()), CPager.build(pos, 100),
                        CResFileDo.FilePackage, CResFileDo.FileName, CResFileDo.FileMd5, CResFileDo.LastWriter);
                if (!page.hasData())
                    break;
                pos += 100;

                for (CResFileDo o : page.getListData())
                {
                    FileDto dto = new FileDto(o.getPhysicalPath(), null);
                    dto.setMd5(o.getFileMd5());
                    dto.setLastWriter(o.getLastWriter());
                    map.put(dto.getPath(), dto);
                }
            }

            return map;
        }
    }

    public Map<String, FileDto> queryAllFileMap(String projectUuid, String folderName) throws NoFolderException, Exception
    {
        Map<String, FileDto> mapAll = new HashMap<String, FileDto>();

        Map<String, FileDto> mapRes = queryResFileMap(projectUuid, folderName);
        if (mapRes != null)
            mapAll.putAll(mapRes);

        Map<String, JavaDto> mapCode = queryCodeFileMap(projectUuid, folderName);
        if (mapCode != null)
            mapAll.putAll(mapCode);

        return mapAll;
    }

    /**
     * 提交代码，给出要覆盖写入的代码，以及要删除的代码类名列表
     * 
     * 文件夹传入的是名字（非UUID）
     */
    public void commitCode(String projectUuid, CommitPackage pkg) throws Exception
    {
        getBuilder_Force(projectUuid).commitCode(pkg);
    }

    public List<VersionNode> queryProjectHistory(String projectUuid) throws Exception
    {
        return CVerMgr.get().queryVersionList(projectUuid);
    }

    public List<VersionNode> queryFileHistory(String projectUuid, String fullClassName) throws Exception
    {
        return CVerMgr.get().queryNodeLog(projectUuid, fullClassName);
    }

    public CJavaCode getHistoryCode(String versionNodeUuid) throws Exception
    {
        VersionNode node = CVerMgr.get().getNode(versionNodeUuid, true);

        CJavaCode code = new CJavaCode();
        code.setJavaPackage(LvJavac.getPackageFromFullClass(node.getKey()));
        code.setMainClass(LvJavac.getSimpleName(node.getKey()));
        code.setLastWriter(node.getCommiter());
        code.setCode(new String(node.getDataBin(), "UTF-8"));
        return code;
    }

    public CResFileDto getHistoryFile(String versionNodeUuid) throws Exception
    {
        VersionNode node = CVerMgr.get().getNode(versionNodeUuid, true);

        CResFileDto f = new CResFileDto();
        f.setFilePackage(CmnUtil.filePath2JavaPackage(node.getKey()));
        f.setFileName(ToolBasic.getPureFileName(node.getKey()));
        f.setLastWriter(node.getCommiter());
        f.setFileBin(node.getDataBin());
        return f;
    }

    // 查询所有在册Cell实现类（通常为服务类）在DAO里存的动态配置（不仅限于插件CELL，静态系统CELL的配置也支持动态配）
    public Map<String, CellConfig> queryCellDaoConfig() throws Exception
    {
        Map<String, CellConfig> mapRet = new HashMap<String, CellConfig>();

        Map<String, CellBuilderIntf> mapAll = new HashMap();
        mapAll.putAll(CellServerFactory.getMe().getLocalCellMap());
        mapAll.putAll(CellServerFactory.getMe().getPluginCellMap());

        List<CellConfigDo> lstDos = null;
        try (CDao dao = newDao())
        {
            lstDos = dao.queryDoList(CellConfigDo.class, null);
        }

        for (Entry<String, CellBuilderIntf> ent : mapAll.entrySet())
        {
            String cellImpl = ent.getValue().getImplementClass();
            if (CmnUtil.isStringEmpty(cellImpl))
                continue;

            try
            {
                Class clsImpl = ClassFactory.loadClass(cellImpl);
                if (clsImpl.isInterface() || !CmnUtil.isInheritFrom(clsImpl, ServiceCellIntf.class))
                    continue;

                if (clsImpl.getAnnotation(Config.class) == null)
                    continue;

                CellConfig cfg = null;
                if (lstDos != null)
                {
                    for (CellConfigDo o : lstDos)
                    {
                        if (clsImpl.getName().equals(o.getCellClass()))
                        {
                            String xml = o.getConfigContent();
                            if (!CmnUtil.isStringEmpty(xml))
                            {
                                Map<String, String> props = CellConfigAdapter.fromXml(ToolUtilities.xmlString2Element(xml));

                                cfg = ConfigFactory.buildDefaultConfig(clsImpl);
                                ConfigFactory.assembleConfig(cfg, props);
                            }
                            break;
                        }
                    }
                }

                mapRet.put(clsImpl.getName(), cfg);
            } catch (ClassNotFoundException no)
            {
                // ignore
            }
        }

        return mapRet;
    }

    public void saveCellDaoConfig(Map<String, CellConfig> mapCfg) throws Exception
    {
        try (CDao dao = newDao())
        {
            dao.clear(CellConfigDo.class, null);

            if (mapCfg != null)
                for (Entry<String, CellConfig> ent : mapCfg.entrySet())
                {
                    if (CmnUtil.isStringEmpty(ent.getKey()) || ent.getValue() == null)
                        continue;

                    CellConfigDo o = new CellConfigDo();
                    o.setCellClass(ent.getKey());
                    String xml = ToolUtilities.xmlElement2String(CellConfigAdapter.toXml(ent.getKey(), ent.getValue()), "UTF-8");
                    xml = CmnUtil.formatXml(xml);
                    o.setConfigContent(xml);
                    o.setModifier(CDaoUtil.getRpcUserCode());
                    o.setModifyTime(System.currentTimeMillis());
                    dao.createDo(o);
                }

            dao.commit();
        }
    }

    public Set<String> queryPackage(String projectUuid, String folderUuid) throws Exception
    {
        Set<String> setPkg = getBuilder_Force(projectUuid).getAllPackages(folderUuid);
        if (setPkg == null)
            setPkg = new HashSet<String>();

        try (CDao dao = newDao())
        {
            String sql = "select distinct($F_Pacakge) as pkg_name from $T_ResFile where $F_MasterKey=@PJ_UUID and $F_Owner=@FolderUUID";
            Vars vars = new Vars();
            vars.add("F_Pacakge", CResFileDo.FilePackage).add("T_ResFile", CResFileDo.TABLE);
            vars.add("F_MasterKey", CResFileDo.MasterKey).add("F_Owner", CResFileDo.Owner);

            Params params = new Params().add("PJ_UUID", projectUuid).add("FolderUUID", folderUuid);

            MultiPageResult<DataRow> rows = dao.queryRows(sql, vars, params, 0, Integer.MAX_VALUE);
            if (rows.hasData())
                for (DataRow row : rows.getListData())
                {
                    String pkg = row.getFirstString(null);
                    if (!CmnUtil.isStringEmpty(pkg))
                        setPkg.add(pkg);
                }
        }

        return setPkg;
    }

    public ArtifactDefine saveArtifactInfo(ArtifactDefine def) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            if (!def.isValidUuid())
            {
                def = dao.createDo(def);
            } else
            {
                dao.updateDo(def);
            }

            dao.commit();
            
            // 专门记录一下日志
            logSaveArtifactInfo(def);
            return def;
        }
    }
    
    public final String CenterOpLog = "logs/java_center_operate.log";
    public void logSaveArtifactInfo(ArtifactDefine def)
    {
        String log = "---SAVE ARTIFACT INFO---(" + CDaoUtil.getRpcUserCode() + ") - " + ToolUtilities.getCurrentTime(true)+":";

        try
        {
            log += "\n\t"+GsonUtil.toJson(def);
            log += "\n";

            ToolUtilities.saveFileUtf8(CenterOpLog, log, true);
        } catch (Throwable err)
        {
            ToolUtilities.fatal(LOG, "Failed to save artifact info log:\n" + log, err);
        }
    }
    
    public void logDeleteProject(GID pjGid)
    {
        String log = "---DELETE PROJECT---(" + CDaoUtil.getRpcUserCode() + ") - " + ToolUtilities.getCurrentTime(true)+":";

        try
        {
            log += "\n\t"+pjGid;
            log += "\n\t"+ToolUtilities.getCurrentStack();
            log += "\n";

            ToolUtilities.saveFileUtf8(CenterOpLog, log, true);
        } catch (Throwable err)
        {
            ToolUtilities.fatal(LOG, "Failed to save artifact info log:\n" + log, err);
        }
    }
    
    public void logUpdateProject(CJavaProject pj, Map<String, Object> mapV)
    {
        String log = "---UPDATE PROJECT---(" + CDaoUtil.getRpcUserCode() + ") - " + ToolUtilities.getCurrentTime(true)+":";

        try
        {
            log += "\n\t"+pj.getName()+"("+pj.getUuid()+")";
            log += "\n\t"+GsonUtil.toJson(mapV);
            log += "\n";

            ToolUtilities.saveFileUtf8(CenterOpLog, log, true);
        } catch (Throwable err)
        {
            ToolUtilities.fatal(LOG, "Failed to save artifact info log:\n" + log, err);
        }
    }

    public GlobalDependSetting queryGlobalDepends() throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            GlobalDependSetting set = dao.getOrCreateSingleton(GlobalDependSetting.class);
            set.setLstDependArtifact(queryAllDepend());
            set.setLstImportArtifact(queryInstalledArtifacts(false));
            set.setExcludeArtifactList(loadArtifactExcludeList());

            // 查工程和Define的对应关系
            Cnd cndPjDefine = Cnd.where(Cnd.exps(ArtifactDefine.ForeignClass, "=", CJavaProject.class.getName()).and(Exps.isStringNotBlank(ArtifactDefine.ForeignKey)));
            List<ArtifactDefine> lstPjDef = dao.queryDoList(ArtifactDefine.class, cndPjDefine, ArtifactDefine.UUID, ArtifactDefine.ForeignKey);
            Map<String, String> mapProject2Define = new HashMap<String, String>();
            for (ArtifactDefine pjDef : NullUtil.get(lstPjDef))
            {
                String pjUuid = pjDef.getForeignKey();
                mapProject2Define.put(pjUuid, pjDef.getUuid());
            }

            // 查出工程对象放入map
            if (!CmnUtil.isObjectEmpty(mapProject2Define))
            {
                Map<String, CJavaProject> mapDef2Project = new HashMap<String, CJavaProject>();
                List<CJavaProject> lstProject = dao.queryDoList(CJavaProject.class, Cnd.where(Exps.inStr(CJavaProject.UUID, mapProject2Define.keySet())));
                for (CJavaProject pj : NullUtil.get(lstProject))
                {
                    String defineUuid = mapProject2Define.get(pj.getUuid());
                    mapDef2Project.put(defineUuid, pj);
                    set.setMapProject(mapDef2Project);
                }
            }

            return set;
        }
    }

    /**
     * 查询出本地工程依赖哪些云组件（Artifact）
     * 
     * 默认是要规避与本地工程冲突的组件
     */
    public List<ArtifactDefine> queryAllDepend() throws Exception
    {
        return queryAllDepend(true);
    }

    /**
     * 查询出本地工程依赖哪些云组件（Artifact） 即所有本地工程的组件定义中设定的依赖对象
     * 
     * @param excludeLocalArtifact
     *            : 是否排除本地工程正在开发的组件
     * 
     *            注：本地工程正在开发的组件会导出到插件参与调试，与之冲突的云组件将不会被导入
     */
    public List<ArtifactDefine> queryAllDepend(boolean excludeLocalArtifact) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            // 同时又是作为slave挂在别人DependTo字段下的从表，则确定是依赖定义
            // 没有forergnKey=不是挂在project下对project的define
            SqlExpressionGroup exp = Exps.begin().and(ArtifactDefine.MasterField, "=", ArtifactDefine.DependTo);
            exp.and(Exps.isStringNotBlank(ArtifactDefine.MasterKey));
            exp.and(Exps.isStringBlank(ArtifactDefine.ForeignKey));

            if (excludeLocalArtifact)
                exp.andNotInBySql(ArtifactDefine.ArtifactId, "select %s from %s where %s='%s'", ArtifactDefine.ArtifactId, ArtifactDefine.TABLE, ArtifactDefine.ForeignClass, CJavaProject.class.getName());

            return dao.queryDoList(ArtifactDefine.class, Cnd.where(exp));
        }
    }

    // 查询安装的组件（从云仓库单独导入的）
    public List<ArtifactDefine> queryInstalledArtifacts(boolean excludeLocalArtifact) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            // 直接挂在GlobaDependSetting下的，就是显式导入的包
            SqlExpressionGroup exp = Exps.begin().and(ArtifactDefine.ForeignClass, "=", GlobalDependSetting.class.getName());

            if (excludeLocalArtifact)
                exp.andNotInBySql(ArtifactDefine.ArtifactId, "select %s from %s where %s='%s'", ArtifactDefine.ArtifactId, ArtifactDefine.TABLE, ArtifactDefine.ForeignClass, CJavaProject.class.getName());

            return dao.queryDoList(ArtifactDefine.class, Cnd.where(exp));
        }
    }

    public boolean isInstalledArtifacts(String groupId, String artifactId) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            // 直接挂在GlobaDependSetting下的，就是显式导入的包
            SqlExpressionGroup exp = Exps.begin().and(ArtifactDefine.ForeignClass, "=", GlobalDependSetting.class.getName());

            exp.and(ArtifactDefine.GroupId, "=", groupId).and(ArtifactDefine.ArtifactId, "=", artifactId);

            return dao.exists(ArtifactDefine.class, Cnd.where(exp));
        }
    }

    public ArtifactDefine queryInstalledArtifact(String groupId, String artifactId) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            // 直接挂在GlobaDependSetting下的，就是显式导入的包
            SqlExpressionGroup exp = Exps.begin().and(ArtifactDefine.ForeignClass, "=", GlobalDependSetting.class.getName());

            exp.and(ArtifactDefine.GroupId, "=", groupId).and(ArtifactDefine.ArtifactId, "=", artifactId);

            return dao.queryDo(ArtifactDefine.class, Cnd.where(exp));
        }
    }

    /**
     * 全量保存安装的应用列表
     */
    public void saveInstalledArts(IDao dao, List<ArtifactDefine> lstArts) throws Exception
    {
        dao.deleteDos(ArtifactDefine.class.getName(), Cnd.where(ArtifactDefine.ForeignClass, "=", GlobalDependSetting.class.getName()));

        for (ArtifactDefine def : lstArts)
        {
            def.setUuid(null);
            GlobalDependSetting globalSetting = dao.getOrCreateSingleton(GlobalDependSetting.class);
            def.setForeignGid(globalSetting.getGid());
            dao.createDo(def);
        }
    }

    // Key ：artifact ID， Value ： ArtifactDefine
    public Map<String, ArtifactDefine> queryLocalProjectArtifactMap() throws Exception
    {
        // 查工程和Define的对应关系
        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cndPjDefine = Cnd.where(Cnd.exps(ArtifactDefine.ForeignClass, "=", CJavaProject.class.getName()).and(Exps.isStringNotBlank(ArtifactDefine.ForeignKey)));
            List<ArtifactDefine> lstPjDef = dao.queryDoList(ArtifactDefine.class, cndPjDefine, ToolUtilities.append(ArtifactDefine.FIELDS_BRIEF, ArtifactDefine.ForeignKey));
            Map<String, ArtifactDefine> mapProject2Define = new HashMap();
            for (ArtifactDefine pjDef : NullUtil.get(lstPjDef))
            {
                String pjUuid = pjDef.getForeignKey();
                mapProject2Define.put(pjDef.getArtifactId(), pjDef);
            }
            return mapProject2Define;
        }
    }

    public CPluginProjectDto saveGlobalDepend(IProgress prog, GlobalDependSetting globalDep) throws Exception
    {
        return saveGlobalDepend(prog, globalDep, null);
    }

    // 保存全局依赖设定，主要是存储偏好设定，并全量重新下载云组件发布到插件中
    /**
     * 保存全局依赖偏好设定，下载云组件+模型等，导入模型、发布插件
     */
    public CPluginProjectDto saveGlobalDepend(IProgress prog, GlobalDependSetting globalDep, GlobalDependObserver observer) throws Exception
    {
        List<CPluginJarDto> lstJars = new LinkedList<CPluginJarDto>();

        List<CDoModel> lstModels = new LinkedList<CDoModel>();

        // 先保存全局排除列表
        saveArtifactExcludeFile(globalDep.getExcludeArtifactList());

        try (IDao dao = IDaoService.newIDao())
        {
            // 存入偏好设定
            dao.updateDo(globalDep);

            // 存入显式导入设定
            List<ArtifactDefine> lstImports = ArtifactUtil.mergeConflictList(globalDep.getLstImportArtifact(), globalDep.getPreferConfigMap());
            saveInstalledArts(dao, lstImports);

            // 从云端下载发布包极其模型（如果排除列表中存在则忽略）
            IProgressUtil.sendProcess(prog, 0, "Begin download depend artifact", true);
            List<ArtifactDefine> lstDependDef = ToolUtilities.mergLists(queryAllDepend(), lstImports); // 合并工程依赖
                                                                                                       // +
                                                                                                       // 显式导入依赖
            ArtifactGraph depGraph = null;
            if (!CmnUtil.isObjectEmpty(lstDependDef))
            {
                // 将第一层依赖，查出整个递归依赖图谱，并去重
                depGraph = ArtifactUtil.queryDependGraph(lstDependDef);
                List<ArtifactWare> lstAllDependWare = depGraph == null ? new LinkedList() : new LinkedList(NullUtil.get(depGraph.getArtifacts().values()));

                // 查出本地工程对应的Art，需要排除依赖项
                Map<String, ArtifactDefine> mapLocalPjArt = queryLocalProjectArtifactMap();

                // 整合冲突后，一个个下载release包、模型包等
                lstAllDependWare = ArtifactUtil.mergeConflictList((List) lstAllDependWare, globalDep.getPreferConfigMap());
                for (int i = 0; i < lstAllDependWare.size(); i++)
                {
                    ArtifactWare yunArt = lstAllDependWare.get(i);
                    IProgressUtil.assertCancel(prog);
                    int per = i * 70 / lstAllDependWare.size();
                    IProgressUtil.sendProcess(prog, per, "Process artifact : " + yunArt, true);

                    boolean isLocalProject = mapLocalPjArt.containsKey(yunArt.getArtifactId());
                    boolean isDuplicateNameWithLocalProject = globalDep.isLocalProject(yunArt);
                    boolean isExcludeInSetting = globalDep.isExcludeArtifact(yunArt);

                    // 只要本地项目与Artifact冲突的则排除
                    if (isLocalProject)
                    {
                        IProgressUtil.sendProcess(prog, per, "Ignore depend artifact with conflict local project : " + yunArt, true);
                        ToolUtilities.warnAndOutput(LOG, "Ignore depend artifact with conflict local project : " + yunArt);
                        continue;
                    }

                    // 只要本地项目名字与Artifact冲突的也排除
                    if (isDuplicateNameWithLocalProject)
                    {
                        IProgressUtil.sendProcess(prog, per, "Ignore depend artifact with same name of local project : " + yunArt, true);
                        ToolUtilities.warnAndOutput(LOG, "Ignore depend artifact with same name of local project : " + yunArt);
                        continue;
                    }

                    // 只要组件名-Artifact ID相同则排除
                    if (isExcludeInSetting)
                    {
                        IProgressUtil.sendProcess(prog, per, "Exclude depend artifact (In Exclude List) : " + yunArt, true);
                        ToolUtilities.infoAndOutput(LOG, "Exclude depend artifact (In Exclude List) : " + yunArt);
                        continue;
                    }

                    // 读取附件
                    List<CDoAttach> lstFiles = YunStoreAgent.getIntf().queryReleasePackage(yunArt.getUuid());
                    if (!CmnUtil.isObjectEmpty(lstFiles))
                    {
                        for (CDoAttach att : lstFiles)
                        {
                            CPluginJarDto jar = new CPluginJarDto();
                            jar.setName(att.getName());
                            jar.setFileBin(att.getContentBin());
                            lstJars.add(jar);
                        }
                    }

                    // 读取模型
                    List<CDoModel> pkgModels = YunStoreAgent.getIntf().queryModelPackage(yunArt.getUuid());
                    ToolUtilities.combineList(lstModels, pkgModels);

                    // 触发观察者
                    if (observer != null)
                        observer.preloadPackage(dao, depGraph, yunArt, lstJars, pkgModels);
                }
            }

            // 导出到插件包
            IProgressUtil.sendProcess(prog, 85, "Publish to local plugin", true);

            if (observer != null)
                observer.beforeImport(dao, depGraph, globalDep, lstJars, lstModels);

            CPluginProjectDto newPluginRoot = importArtifact2Plugin(lstJars); // 会立即发布
            if (observer != null)
                observer.afterImport2Plugin(dao, newPluginRoot.getTimeTag());

            // 导入模型（发布成功后）
            if (!CmnUtil.isObjectEmpty(lstModels))
            {
                IProgressUtil.sendProcess(prog, 90, "Upgrade DAO models", true);
                long modelTag = IDaoService.get().importModels(new ChildProgress(90, 100, prog), lstModels, null);
                if (observer != null)
                    observer.afterImportModels(dao, modelTag);
            }

            // 全都成功后才提交
            dao.commit();
            if (observer != null)
                observer.afterCommit(dao);

            return newPluginRoot;
        } finally
        {
            IProgressUtil.finish(prog);
        }
    }

    /**
     * 从云仓库下载，并安装指定版本的预制件
     * 
     * 返回true，表示新安装或者变更了版本 返回false，表示本来就安装了，什么动作都没做
     */
    ReentrantLock _lockInstallArt = new ReentrantLock();

    public boolean installArtifact(IProgress prog, ArtifactDefine art, long waitPublish) throws Exception
    {
        try (AutoLock lc = AutoLock.lock(_lockInstallArt))
        {
            // 到仓库核实预制件
            ArtifactWare artWare = YunStoreAgent.getIntf().queryArtifact(art.getGroupId(), art.getArtifactId(), art.getVersion(), false, ArtifactDefine.FIELDS_BRIEF);
            if (artWare == null)
                throw new Exception("Failed to get artifact from store : " + art.getKey());

            art = artWare.toDefine();
            ArtifactDefine exist = queryInstalledArtifact(art.getGroupId(), art.getArtifactId());
            if (exist != null)
            {
                // 如果版本也相同，则直接返回true
                if (exist.getVersion() == art.getVersion())
                    return false;
            }

            List<ArtifactDefine> lst = queryInstalledArtifacts(false);
            ArtifactUtil.removeDefine(lst, art.getGroupId(), art.getArtifactId());
            lst.add(art);

            GlobalDependSetting newDepnd = queryGlobalDepends();
            newDepnd.setLstImportArtifact(lst);

            if (waitPublish > 0)
            {
                CPluginProjectDto newPlugin = saveGlobalDepend(new ChildProgress(0, 70, prog), newDepnd);
                long time = System.currentTimeMillis();
                while (CPluginClient.getLocalTagID() < newPlugin.getTimeTag())
                {
                    IProgressUtil.sendProcess(prog, 90, "Synchronize plugin : " + ToolUtilities.time2String(CPluginClient.getLocalTagID(), false) + " -> " + ToolUtilities.time2String(newPlugin.getTimeTag(), false),
                            true);
                    ToolUtilities.sleep(500);
                    if (System.currentTimeMillis() - time > waitPublish)
                        throw new TimeoutException("Timed out to wait for Global Publish");
                }
            } else
            {
                saveGlobalDepend(prog, newDepnd);
            }
            return true;
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    /**
     * 卸载单独安装部署的应用组件
     * 
     * 返回是否删除彻底了，有些包虽然没有显式导入，但被人依赖，也是不能删的，会返回false
     */
    public boolean uninstallArtifact(IProgress prog, ArtifactDefine art, long waitPublish) throws Exception
    {
        try
        {
            List<ArtifactDefine> lstArts = queryInstalledArtifacts(false);
            ArtifactDefine found = null;
            for (Iterator<ArtifactDefine> it = lstArts.iterator(); it.hasNext();)
            {
                ArtifactDefine art1 = it.next();
                if (CmnUtil.isStringEqual(art.getGroupId(), art1.getGroupId()) && CmnUtil.isStringEqual(art.getArtifactId(), art1.getArtifactId()))
                {
                    found = art1;
                    it.remove();
                }
            }

            if (found == null)
                throw new Exception("Artifact no found exception");

            GlobalDependSetting orgSetting = queryGlobalDepends();
            GlobalDependSetting newSetting = ToolUtilities.clone(orgSetting);
            newSetting.setLstImportArtifact(lstArts);

            if (waitPublish > 0)
            {
                CPluginProjectDto newPlugin = saveGlobalDepend(new ChildProgress(20, 80, prog), newSetting);
                long time = System.currentTimeMillis();
                while (CPluginClient.getLocalTagID() < newPlugin.getTimeTag())
                {
                    IProgressUtil.sendProcess(prog, 90, "Synchronize plugin : " + ToolUtilities.time2String(CPluginClient.getLocalTagID(), false) + " -> " + ToolUtilities.time2String(newPlugin.getTimeTag(), false),
                            true);
                    ToolUtilities.sleep(500);
                    if (System.currentTimeMillis() - time > waitPublish)
                        throw new TimeoutException("Timed out to wait for Global Publish");
                }
            } else
            {
                saveGlobalDepend(prog, newSetting);
            }

            List<ArtifactDefine> lstNowArts = queryAllDepend();

            return ArtifactUtil.findDefine(lstNowArts, art.getGroupId(), art.getArtifactId()) == null;
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    // 从云端获取artifact，导入到插件，并发布
    public CPluginProjectDto importArtifact2Plugin(List<CPluginJarDto> lstJars) throws Exception
    {
        CPluginProjectDto pluginProject = new CPluginProjectDto();
        pluginProject.setName(ArtifactConst.GLOBAL_DEPEND_ARTIFACT_PLUGIN);

        CPluginExportPackage pkg = new CPluginExportPackage();
        pkg.setDeleteFirst(true);
        pkg.setProject(pluginProject).setLstJars(lstJars);

        return ClassFactory.exportPublishPlugin(pkg, true);
    }

    public ArtifactDefine getArtifactInfo(String pjUuid) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            ArtifactDefine def = dao.queryDo(ArtifactDefine.class, Cnd.where(ArtifactDefine.ForeignKey, "=", pjUuid));
            if (def != null)
            {
                List<ArtifactDefine> lstDep = dao.querySlaveTable(def.getGid(), ArtifactDefine.DependTo);
                if (lstDep != null)
                    def.setDependTo(SlaveTable.build(lstDep));
            }

            return def;
        }
    }

    // 将本地lib库里的文件导出到指定目录
    public void exportLibFiles(String pjUuid, String dstPath) throws Exception
    {
        try (CDao dao = newDao())
        {
            List<CJarFile> lstJars = dao.queryDoList(CJarFile.class, Cnd.where(CJarFile.MasterKey, "=", pjUuid));
            for (CJarFile jar : lstJars)
            {
                byte[] bt = jar.getFileBin();
                String sPath = dstPath + "/" + jar.getName();
                ToolUtilities.saveFile(sPath, bt, false);
            }
        }
    }

    /**
     * 根据独狼配置，将本地文件夹打包返回
     * 
     * 通过进度回传打包的zip文件
     */
    public LoneWolfConfig exportLoneWolfFiles(IProgress<byte[]> prog) throws Exception
    {
        try (TempFile tmpFd = new TempFile("Export_Lone_Wolf"))
        {
            IProgressUtil.send(prog, 0, "Prepare Zip File", true);

            ToolUtilities.createFolder(tmpFd.getAbsolutePath());
            List<String> lstFolders = LoneWolfConfig.get().getLstFolders();
            for (String s : NullUtil.get(lstFolders))
            {
                ToolUtilities.copyFile(s, tmpFd.getAbsolutePath() + "/", true);
            }

            IProgressUtil.send(prog, 20, "Begin transport ... ", true);
            byte[] btZip = ZipUtils.zipByte(tmpFd.getAbsolutePath(), "UTF-8");
            // 有数据需要上传的，则用流式上传
            if (!CmnUtil.isObjectEmpty(btZip))
            {
                ByteBuffer bf = new ByteBuffer(btZip);

                int totalK = bf.size() / 1024; // K
                int page = 64 * 1024;

                while (bf.isReadable())
                {
                    IProgressUtil.assertCancel(prog);

                    int per = IProgressUtil.calcPercent(20, bf.getIndex() / 1024, totalK);
                    IProgressUtil.send(prog, per, "Transfer data bytes : " + ToolUtilities.fileSize2String(bf.getIndex()), true);
                    IProgressUtil.sendDataFrame(prog, bf.read(page));
                }
            }

            return LoneWolfConfig.get();
        } finally
        {
            IProgressUtil.finish(prog);
        }
    }

    // 将工程发布上传到云仓库去
    public void publishYunStore(String pjUuid, UserPassword yunUser) throws Exception
    {
        // 先尝试登陆一下云仓库，校验连通性以及用户等，然后再准备打包发布
        YunStoreAgent.getIntf().login(yunUser);

        CJavaPJBuilder builder = getBuilder_Force(pjUuid);

        // 打包发布前，全量编译一次
        LvCompileSingleResult buildRs = builder.rebuildAll();
        if (buildRs.hasErrors())
            throw new Exception(BapGuiUtil.getString("There are some compilation errors. Please solve them first.") + "\n" + ToolUtilities.logString(buildRs.getErrors(), 10, true));

        CJavaProject pj = builder.getProject();

        try (IDao dao = IDaoService.newIDao())
        {
            ArtifactDefine def = dao.queryDo(ArtifactDefine.class, Cnd.where(ArtifactDefine.ForeignKey, "=", pjUuid));
            CmnUtil.assertNotNull(def, "Please define artifact info for project");

            ArtifactPackage pkg = new ArtifactPackage();
            pkg.setArtifactDefine(def);

            // 设置依赖列表
            List<ArtifactDefine> lstDeps = dao.querySlaveTable(def.getGid(), ArtifactDefine.DependTo);
            if (lstDeps != null)
                def.setDependTo(SlaveTable.build(lstDeps));

            try (TempFile dstFolder = new TempFile("PublishYunStore_"))
            {
                String pjJson = CJson.toJson(pj);
                ToolUtilities.saveFileUtf8(dstFolder.getAbsolutePath() + "/" + CJavaConst.FILE_Project_Json, pjJson, false);

                // 导出所有源码
                builder.exportSourceFiles(dstFolder.getAbsolutePath());

                // 本地引入的lib库也导出
                exportLibFiles(pjUuid, dstFolder.getAbsolutePath() + "/" + CJavaConst.PATH_EXPORT_Lib);

                // 压缩输出工程包
                byte[] bt = ZipUtils.zipByte(dstFolder.getAbsolutePath(), "UTF-8");
                CDoAttach projectPkg = new CDoAttach();
                projectPkg.setName(ArtifactConst.PROJECT_ZIP).setDirty(true);
                projectPkg.setBin(bt); // Project ZIP
                pkg.setProjectPkg(projectPkg);

                // 输出发布包文件列表
                List<CJavaFolder> lstFolders = getFolders(pj.getUuid());
                for (CJavaFolder fd : NullUtil.get(lstFolders))
                {
                    byte[] bin = builder.exportOneJar(fd);
                    CDoAttach oneFile = new CDoAttach();
                    oneFile.setName(ArtifactUtil.toJarFileName(def.getArtifactId(), def.getVersion(), fd.getName()));
                    oneFile.setBin(bin).setDirty(true);
                    pkg.addReleasePkg(oneFile);
                }

                try
                {
                    SJsonList lstMd = def.getExclusiveModelList();
                    for (String md : NullUtil.get(lstMd))
                    {
                        CDoAttach oneMdJson = new CDoAttach().setDirty(true);
                        oneMdJson.setName(md);

                        CDoModel usrModel = dao.queryModel(md);
                        if (usrModel != null)
                        {
                            String mdJson = CJson.toJson(usrModel);
                            oneMdJson.setText(mdJson);
                        } else
                        {
                            Class cls = dao.prepareModelClass(md);
                            oneMdJson.setBin(ToolUtilities.serialize(cls));
                        }
                        pkg.addModelPkg(oneMdJson);
                    }
                } catch (Throwable err)
                {
                    throw new Exception("Failed to package exclusive model", err);
                }
            }

            // 调用云仓库接口，发布组件
            YunStoreAgent.get().getIntf().publishArtifact(pkg, yunUser);
        }
    }

    /**
     * 从项目工程包（zip文件）中解压，并导入创建为新工程 导入内容包括源代码、工程设定等 纯数据库操作，且未提交 如果遇到重名的工程，直接替换覆盖
     * 
     * @param dao
     * @param projectName
     * @param zipBytes
     * @return
     * @throws Exception
     */
    public static CJavaProject importProjectZip(IDao dao, String projectName, byte[] zipBytes) throws Exception
    {
        CJavaProject existPj = (CJavaProject) dao.queryDo(CJavaProject.class.getName(), Cnd.where(CJavaProject.Name, "=", projectName));
        if (existPj != null)
        {
            // 先删掉原有工程相关内容，再重新导入（会话之外处理，涉及到大量编译缓存、临时文件清理等，比较干净）
            getMe().deleteProject(existPj.getGid());
        }

        CJavaProject pj = new CJavaProject();

        // 保留老的UUID，以便和各个开发环境里的保持一致
        if (existPj != null)
            pj.setUuid(existPj.getUuid());

        pj.setName(projectName);
        pj.setDependType(CJavaConst.DEPEND_PLUGIN);
        pj = dao.createDo(pj);

        if (CmnUtil.isObjectEmpty(zipBytes))
            return pj;

        try (TempFile tmpFolder = new TempFile("ImportYunProject_" + projectName))
        {
            String zipFile = tmpFolder.getAbsolutePath() + "/project.zip";
            ToolUtilities.saveFile(zipFile, zipBytes, false);
            ZipUtils.unzip(zipFile, tmpFolder.getAbsolutePath());

            File fdSrc = new File(tmpFolder.getAbsolutePath(), CJavaConst.PATH_EXPORT_Src);
            for (File srcF : NullUtil.toList(fdSrc.listFiles()))
            {
                if (!srcF.isDirectory())
                    continue;

                // 创建源码目录
                CJavaFolder fd = new CJavaFolder();
                fd.setMaster(pj.getGid());
                fd.setName(srcF.getName());
                dao.createDo(fd);

                // 导入源码以及资源文件
                List<File> lstFiles = ToolUtilities.getAllChildFileObject(srcF);
                for (File f : NullUtil.get(lstFiles))
                {
                    if (f.isDirectory())
                        continue;

                    if (CJavaUtil.isJavaFile(f.getName()))
                    {
                        // 导入源码
                        String relPath = ToolUtilities.getRelatedPath(f.getAbsolutePath(), srcF.getAbsolutePath()); // 相对于src目录的相对路径
                        String fullClass = LvJavac.getMainClassFromFileName(relPath);

                        CJavaCodeDo code = new CJavaCodeDo();
                        code.setMaster(pj.getGid(), CJavaProject.LstCode);
                        code.setOwner(fd.getUuid());
                        code.setJavaPackage(LvJavac.getPackageFromFullClass(fullClass));
                        code.setMainClass(LvJavac.getSimpleName(fullClass));
                        code.setCode(ToolBasic.readFileUtf8(f.getPath()));
                        code.setLastWriter(CDaoUtil.getRpcSession());
                        code.updateSaveInfo();
                        code = dao.createDo(code);
                    } else
                    {
                        // 导入资源文件
                        String dir = f.getParentFile().getAbsolutePath();
                        String relPath = CmnUtil.getRelatedPath(dir, srcF.getAbsolutePath()); // 资源文件只取父目录的相对路径，用以转换为包名

                        CResFileDo resFile = new CResFileDo();
                        resFile.setMaster(pj.getGid(), CJavaProject.LstRes);
                        resFile.setOwner(fd.getUuid());
                        resFile.setFilePackage(CmnUtil.filePath2JavaPackage(relPath));
                        resFile.setFileName(f.getName());
                        resFile.setFileBin(ToolUtilities.readFile(f.getAbsolutePath()));
                        resFile.updateFileInfo();
                        resFile = dao.createDo(resFile);
                    }
                }
            }

            // 导入lib
            File fdLib = new File(tmpFolder.getAbsolutePath(), CJavaConst.PATH_EXPORT_Lib);
            for (File f : NullUtil.toList(fdLib.listFiles()))
            {
                if (f.isDirectory())
                    continue;

                CJarFile jarDo = new CJarFile();
                jarDo.setMaster(pj.getGid(), CJavaProject.JarFiles);
                jarDo.setFile(f.getName(), ToolUtilities.readFile(f.getAbsolutePath()));
                jarDo = dao.createDo(jarDo);
            }
        }

        return pj;
    }

    public static CJavaVirtualProject importVirtualProjectZip(IDao dao, String projectName, byte[] zipBytes) throws Exception
    {
        CJavaVirtualProject existPj = (CJavaVirtualProject) dao.queryDo(CJavaVirtualProject.class.getName(), Cnd.where(CJavaVirtualProject.Name, "=", projectName));
        if (existPj != null)
        {
            // 先删掉原有工程相关内容，再重新导入（会话之外处理，涉及到大量编译缓存、临时文件清理等，比较干净）
            getMe().deleteProject(existPj.getGid());
        }

        CJavaVirtualProject pj = new CJavaVirtualProject();

        // 保留老的UUID，以便和各个开发环境里的保持一致
        if (existPj != null)
            pj.setUuid(existPj.getUuid());

        pj.setName(projectName);
        pj.setDependType(CJavaConst.DEPEND_PLUGIN);
        pj = dao.createDo(pj);

        if (CmnUtil.isObjectEmpty(zipBytes))
            return pj;

        try (TempFile tmpFolder = new TempFile("ImportYunProject_" + projectName))
        {
            String zipFile = tmpFolder.getAbsolutePath() + "/project.zip";
            ToolUtilities.saveFile(zipFile, zipBytes, false);
            ZipUtils.unzip(zipFile, tmpFolder.getAbsolutePath());

            File fdSrc = new File(tmpFolder.getAbsolutePath(), CJavaConst.PATH_EXPORT_Src);
            for (File srcF : NullUtil.toList(fdSrc.listFiles()))
            {
                if (!srcF.isDirectory())
                    continue;

                // 创建源码目录
                CJavaFolder fd = new CJavaFolder();
                fd.setMaster(pj.getGid());
                fd.setName(srcF.getName());
                dao.createDo(fd);

                // 导入源码以及资源文件
                List<File> lstFiles = ToolUtilities.getAllChildFileObject(srcF);
                for (File f : NullUtil.get(lstFiles))
                {
                    if (f.isDirectory())
                        continue;

                    if (CJavaUtil.isJavaFile(f.getName()))
                    {
                        // 导入源码
                        String relPath = ToolUtilities.getRelatedPath(f.getAbsolutePath(), srcF.getAbsolutePath()); // 相对于src目录的相对路径
                        String fullClass = LvJavac.getMainClassFromFileName(relPath);

                        CJavaVirtualCodeDo code = new CJavaVirtualCodeDo(); // 这句最特殊,
                                                                            // 导入的是虚拟源码(不全局限制唯一)
                        code.setMaster(pj.getGid(), CJavaProject.LstCode);
                        code.setOwner(fd.getUuid());
                        code.setJavaPackage(LvJavac.getPackageFromFullClass(fullClass));
                        code.setMainClass(LvJavac.getSimpleName(fullClass));
                        code.setCode(ToolBasic.readFileUtf8(f.getPath()));
                        code.setLastWriter(CDaoUtil.getRpcSession());
                        code.updateSaveInfo();
                        code = dao.createDo(code);
                    } else
                    {
                        // 导入资源文件
                        String dir = f.getParentFile().getAbsolutePath();
                        String relPath = CmnUtil.getRelatedPath(dir, srcF.getAbsolutePath()); // 资源文件只取父目录的相对路径，用以转换为包名

                        CResFileDo resFile = new CResFileDo();
                        resFile.setMaster(pj.getGid(), CJavaProject.LstRes);
                        resFile.setOwner(fd.getUuid());
                        resFile.setFilePackage(CmnUtil.filePath2JavaPackage(relPath));
                        resFile.setFileName(f.getName());
                        resFile.setFileBin(ToolUtilities.readFile(f.getAbsolutePath()));
                        resFile.updateFileInfo();
                        resFile = dao.createDo(resFile);
                    }
                }
            }

            // 导入lib
            File fdLib = new File(tmpFolder.getAbsolutePath(), CJavaConst.PATH_EXPORT_Lib);
            for (File f : NullUtil.toList(fdLib.listFiles()))
            {
                if (f.isDirectory())
                    continue;

                CJarFile jarDo = new CJarFile();
                jarDo.setMaster(pj.getGid(), CJavaProject.JarFiles);
                jarDo.setFile(f.getName(), ToolUtilities.readFile(f.getAbsolutePath()));
                jarDo = dao.createDo(jarDo);
            }
        }

        return pj;
    }

    /**
     * 导入工程成功以后，会自动导入相关模型（存在失败的风险），此时需人工介入，看看模型为啥不兼容，无法导入
     * 
     * 而且由于要外部自行导入相关依赖包，所以建议外部滞后触发一次rebuild all
     */
    public CJavaProject importYunProject(IProgress prog, ArtifactWare artWare, UserPassword yunUser) throws Exception
    {
        return YunProjectImporter.importYunProject(prog, artWare, yunUser);
    }

    public static CJavaProject createYunProject(IDao dao, ArtifactWare artWare, byte[] projectZip, List<CDoModel> lstModel) throws Exception
    {
        // 新建工程（重名则删掉新建）
        CJavaProject pj = importProjectZip(dao, artWare.getArtifactId(), projectZip);

        // 设置工程的Art信息
        ArtifactDefine def = new ArtifactDefine();
        def.setForeignGid(pj.getGid());
        def.setDefine(artWare);
        def.setDependTo(artWare.getDependTo());
        // copy模型列表
        if (!CmnUtil.isObjectEmpty(lstModel))
        {
            SJsonList lstMd = new SJsonList();
            for (CDoModel md : lstModel)
                lstMd.add(md.getFullClassName());
            def.setExclusiveModelList(lstMd);
        }
        def = dao.createDo(def);

        return pj;
    }

    public static class TestModelObserver implements ModelObserver
    {
        ArtifactWare artWare;

        byte[] projectZip;

        List<CDoModel> lstModel;

        public TestModelObserver(ArtifactWare artWare, byte[] projectZip, List<CDoModel> lstModel)
        {
            this.artWare = artWare;
        }

        public void beforeCommit(IProgress prog, ModelContext ctx)
        {
            try
            {
                for (int i = 0; i < 100; i++)
                {
                    IProgressUtil.send(prog, i, "Test : " + i);
                    ToolUtilities.sleep(500);
                }
            } catch (Throwable err)
            {
                CmnUtil.throwRuntimeException(err);
            } finally
            {
                IProgressUtil.finish(prog);
            }
        }
    }

    public CodeMeta getCodeMeta(String cls) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return CJavaUtil.queryCodeMeta(dao, cls);
        }
    }

    // UDF比较特殊，每次都需要结合UDF编译结果 + ResFile整合出最新的Meta
    public UdfMeta queryUdfMeta(String pjUuid, String cls) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            CJavaCode code = getBuilder_Force(pjUuid).getCode(cls);
            CmnUtil.assertNotNull(code, "Code of class is removed : " + cls);

            try (LvClassLoader tmpLoader = ClassFactory.newValidClassLoader())
            {
                UdfMeta cmpMeta = CUdfUtil.compileAndLoadCode(tmpLoader, code);
                CodeMeta doMeta = CJavaUtil.queryCodeMeta(dao, cls);
                if (doMeta != null)
                    CUdfUtil.mergeMeta(cmpMeta, doMeta);

                return cmpMeta;
            }
        }
    }

    // 通过代码类名，保存meta do(资源文件)，不会触发编译
    // meta的文件DO会设置强依赖于所属文件，同生同死
    public CResFileDo saveCodeMeta(String className, CodeMeta meta, boolean rebuild) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            CJavaCodeDo code = CJavaUtil.queryCode(dao, className, true);
            CmnUtil.assertNotNull(code, "Code of class doesn't exist : " + className);

            GID pjGid = code.getMaster();
            String folderUuid = code.getOwner();

            String pkg = CmnUtil.getPackageFromFullClass(className);
            String cls = CmnUtil.getSimpleClassName(className);
            String fileName = cls + "." + CJavaConst.CODE_META_FILE_EXT;

            CResFileDo resFile = new CResFileDo();
            resFile.setFilePackage(pkg);
            resFile.setFileName(fileName);
            resFile.setFileBin(meta.getMeta().getBytes("UTF-8"));
            resFile.setMaster(pjGid, CJavaProject.LstRes);
            resFile.setOwner(folderUuid);

            CResFileDo exist = dao.queryDo(CResFileDo.class, Cnd.where(CResFileDo.MasterKey, "=", pjGid.getUuid()).and(CJavaUtil.queryMetaExp(className)), CResFileDo.FIELDS_BRIEF);
            if (exist != null)
            {
                resFile.setUuid(exist.getUuid());
            }

            resFile = getBuilder_Force(pjGid.getUuid()).saveResFile(dao, resFile);
            dao.commit();

            if (rebuild)
                getBuilder_Force(pjGid.getUuid()).rebuildAll();

            return resFile;
        }
    }

    public List<String> scanLocalFiles(String... folder)
    {
        List<String> lstRet = new LinkedList<String>();
        for (String fd : folder)
        {
            List<File> lstFiles = ToolUtilities.getAllChildFileObject(new File(fd));
            for (File f : NullUtil.get(lstFiles))
            {
                if (f.isFile())
                    lstRet.add(f.getName());
            }
        }

        Collections.sort(lstRet);
        return lstRet;
    }

    // 与本地jar冲突的组件名列表，这里将不会下载其jar包发布到插件（以免冲突）
    // 这里主要针对第三方开源jar，如果内涵模型也一并排除
    public final static String FILE_ARTIFACT_EXCLUDE = "conf/artifactExclude.list";

    public void saveArtifactExcludeFile(Set<String> lstExclude) throws UnsupportedEncodingException, IOException
    {
        StringBuffer sb = new StringBuffer();
        for (String s : NullUtil.get(lstExclude))
            sb.append(s).append("\n");

        ToolUtilities.saveFileUtf8(FILE_ARTIFACT_EXCLUDE, sb.toString(), false);
    }

    public Set<String> loadArtifactExcludeList() throws IOException
    {
        Set<String> setRet = new HashSet<String>();

        File confFile = new File(FILE_ARTIFACT_EXCLUDE);
        if (confFile.exists())
        {
            String s = ToolUtilities.readFileUtf8(confFile.getAbsolutePath());
            if (s != null)
            {
                List<String> lst = ToolUtilities.getSplitedString(s, "\n", true);
                setRet.addAll(NullUtil.get(lst));
            }
        }
        return setRet;
    }

    // 返回导入的整个依赖树
    public String publishMavenArtifact(IProgress prog, MvnArt mvnArt, UserPassword yunUser) throws Exception
    {
        try
        {
            MavenAgent mvn = new MavenAgent();

            MvnArtTreeNode artNode = mvn.downloadArtifactAndDependency(new ChildProgress(0, 40, prog), mvnArt, true);
            IProgressUtil.sendProcess(prog, 40, "Finish Download\n" + artNode.toLog(), true);
            IProgressUtil.assertCancel(prog);

            CmnUtil.err(artNode.toLog());
            MavenToYun.publishYunStore(new ChildProgress(41, 100, prog), artNode, yunUser);
            return artNode.toLog();
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }
}
