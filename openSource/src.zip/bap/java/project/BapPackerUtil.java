package bap.java.project;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;

import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.nutz.dao.Cnd;

import com.cdao.CDaoConst;
import com.cdao.mgr.CDaoClient;
import com.cdao.model.CDoAttach;
import com.cdao.model.CDoModel;
import com.google.common.io.Files;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ZipUtils;
import com.leavay.common.util.ProgressCtrl.ChildProgress;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.leavay.common.util.ProgressCtrl.crpc.IProgressUtil;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.dfc.gui.CTraceProgress;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.starter.StarterConf;
import com.leavay.starter.StarterItem;
import com.leavay.starter.StarterMain;

import bap.cells.CellConfig;
import bap.cells.CellConfigAdapter;
import bap.cells.annotation.Config;
import bap.java.CJavaConst;
import bap.md.java.CJavaProject;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import bap.plugin.CPluginJarDto;
import bap.yun.ArtifactUtil;
import bap.yun.YunStoreAgent;
import cmn.util.NullUtil;
import cmn.util.Nulls;
import ms.cmn.util.TempFile;

/**
 * 
 * 应用打包工具，根据配置打包输出应用工程 只能运行在主控（或开发中心上）（运行在哪里，就以哪里的基础目录为复制基础）
 * 
 * 配置文件样例： conf/SampleDeploy.xml
 * CDaoConst.INIT_MODEL_JAR_CONF="conf/dao/initModelJar.conf"
 * 
 */
public class BapPackerUtil implements Serializable
{
    private static final long serialVersionUID = -4168630853434617480L;

    public final static String ADV_CONF_FILE = "conf/base_advance.conf";

    public final static String XML_FOLDER = "folder";

    public final static String XML_PROJECT = "project";

    public final static String XML_DAO_MODEL = "dao_model";

    public final static String XML_CONFIG = "config";

    public final static String XML_STARTERS = "starters";

    public final static String XML_STARTER_TEMPLATE = "starter_template";

    public final static String XML_ARTIFACTS = "artifacts";

    public final static String XML_ART_GROUP= "groupId";
    public final static String XML_ART_ARTID = "artifactId";
    
    public final static String XML_ART_INCLUDE = "include";

    public final static String XML_ART_EXCLUDE = "exclude";

    public List<String> lstFolders = new ArrayList<String>();

    public List<String> lstProjects = new ArrayList<String>();

    public List<String> lstModels = new ArrayList<String>();

    // 通过XML_STARTER_TEMPLATE可指定starter模板文件
    String starterTemplateFile = null;

    public Map<String, StarterItem> mapStarter = new HashMap<String, StarterItem>();

    public List<ArtifactDefine> lstArts = new LinkedList<ArtifactDefine>();

    public List<String> lstExcludeArts = new LinkedList<String>();

    public Properties propConf = new Properties();

    public List<String> getLstFolders()
    {
        return lstFolders;
    }

    // 可以单独加前缀
    public String getProjectJarName(String dftName)
    {
        return "project_" + dftName;
    }

    // dstFolder : 导出根目录
    public String getModelFilePath()
    {
        return "lib/dao_model.jar";
    }

    public void addFolder(String folder)
    {
        lstFolders = ToolUtilities.addToList(lstFolders, folder);
    }

    public BapPackerUtil(String xml) throws DocumentException, IOException
    {
        Element eleRoot = ToolUtilities.xmlString2Dom4j(xml);
        List<Element> lst = eleRoot.elements(XML_FOLDER);
        for (Element eleFolder : NullUtil.get(lst))
        {
            String s = eleFolder.getTextTrim();
            addFolder(s);
        }

        lst = eleRoot.elements(XML_PROJECT);
        for (Element ele : NullUtil.get(lst))
        {
            String s = ele.attributeValue("name");
            lstProjects.add(s);
        }

        lst = eleRoot.elements(XML_DAO_MODEL);
        for (Element ele : NullUtil.get(lst))
        {
            String s = ele.attributeValue("name");
            lstModels.add(s);
        }

        lst = eleRoot.elements(XML_STARTERS);
        for (Element ele : NullUtil.get(lst))
        {
            starterTemplateFile = ele.attributeValue(XML_STARTER_TEMPLATE);
            for (Element eleSt : Nulls.get((List<Element>) ele.elements(StarterConf.XML_STARTER)))
            {
                StarterItem item = StarterMain.loadItem(eleSt);
                mapStarter.put(item.getKey(), item);
            }
        }

        lst = eleRoot.elements(XML_CONFIG);
        for (Element ele : NullUtil.get(lst))
        {
            for (Element eleSt : Nulls.get((List<Element>) ele.elements()))
            {
                String v = eleSt.attributeValue("value");
                if (CmnUtil.isStringEmpty(v))
                {
                    CmnUtil.err("Invalid config with NULL value : " + eleSt.getName());
                    continue;
                }
                propConf.put(eleSt.getName(), v);
            }
        }

        Element ele = eleRoot.element(XML_ARTIFACTS);
        if (ele != null)
        {
            for (Element eleSt : Nulls.get((List<Element>) ele.elements(XML_ART_INCLUDE)))
            {
                String grpid = eleSt.attributeValue(XML_ART_GROUP, "");
                String artId = CmnUtil.assertNotEmpty(eleSt.attributeValue(XML_ART_ARTID), "Invalid artifact name : " + ele);
                ArtifactDefine def = new ArtifactDefine();
                def.setGroupId(grpid);
                def.setArtifactId(artId);
                def.setVersion(eleSt.attributeValue("version"));
                lstArts.add(def);
            }

            for (Element eleSt : Nulls.get((List<Element>) ele.elements(XML_ART_EXCLUDE)))
            {
                String excName = eleSt.attributeValue("name");
                lstExcludeArts.add(CmnUtil.assertNotEmpty(excName, "Invalid artifact exclude name : " + ele));
            }
        }
    }

    public CJavaProject exportOneProject(IProgress prog, String pj, String dstPath) throws Exception
    {
        List<CJavaProject> lstPjs = CJavaCenter.getMe().queryProject(Cnd.where(CJavaProject.Name, "=", pj));
        CmnUtil.assertNotEmpty(lstPjs, "There isn't this project : " + pj);

        CJavaProject pjDto = lstPjs.get(0);
        Set<String> lstFolders = CJavaCenter.getMe().getFolderNames(pjDto.getUuid());

        CJavaPJBuilder builder = CJavaCenter.getMe().getBuilder_Force(pjDto.getUuid());
        IProgressUtil.send(prog, 0, "Compile and export : " + pj);
        List<CPluginJarDto> lstJars = builder.exportJar(true, false);
        for (int i = 0; i < lstJars.size(); i++)
        {
            CPluginJarDto jar = lstJars.get(i);
            String dstFile = getProjectJarName(jar.getName());

            IProgressUtil.send(prog, 50 + (i * 50 / lstJars.size()), "Export project jar : " + dstFile);
            ToolUtilities.saveFile(dstPath + "/lib/" + dstFile, jar.getFileBin(), false);
        }

        return pjDto;
    }

    public void pack(IProgress prog, String dstFolder) throws Exception
    {
        try
        {
            // Copy 基础文件夹
            IProgressUtil.send(prog, 0, "Copy Folder", true);
            int cnt = lstFolders.size();
            ChildProgress subProg = new ChildProgress(0, 30, prog);
            for (int i = 0; i < cnt; i++)
            {
                String folder = lstFolders.get(i);

                IProgressUtil.send(subProg, i * 100 / cnt, "Copy Folder : " + folder, true);
                ToolUtilities.copyFile(folder, dstFolder, true);
            }

            // 整合基础配置
            IProgressUtil.send(prog, 31, "Combine basic config", true);
            assemblePropConf(dstFolder);

            // 生成Cell Config
            IProgressUtil.send(prog, 32, "Export cell config", true);
            exportCellConfig(dstFolder);

            // 整合Starter Conf
            IProgressUtil.send(prog, 34, "Assemble starter config", true);
            assembleStarterConf(dstFolder);

            // 导出工程（自动编译）
            List<ArtifactDefine> lstDependYun = new LinkedList<ArtifactDefine>(lstArts);
            Set<String> expModels = new HashSet<String>();
            cnt = lstProjects.size();
            subProg = new ChildProgress(35, 50, prog);
            for (int i = 0; i < cnt; i++)
            {
                String pj = lstProjects.get(i);
                int pos = i * 100 / cnt;

                IProgressUtil.send(subProg, pos, "Export Project : " + pj, true);
                try
                {
                    CJavaProject pjDo = exportOneProject(new ChildProgress(pos, pos + 1, subProg), pj, dstFolder);
                    ArtifactDefine artDef = CJavaCenter.getMe().getArtifactInfo(pjDo.getUuid());
                    if (artDef != null)
                    {
                        // 工程依赖模型包
                        expModels.addAll(Nulls.get(artDef.getExclusiveModelList()));

                        // 工程依赖的云包
                        lstDependYun.addAll(artDef.getDependTo());
                    }
                } catch (Throwable err)
                {
                    throw new Exception("Failed to export project : " + pj, err);
                }
            }
            
            // 创建模型初始配置文件
            ToolUtilities.saveFileUtf8(dstFolder + "/" + CDaoConst.INIT_MODEL_JAR_CONF, "", false);

            // 导出云包（云组件的模型需要内存编译生成DAO的包）
            subProg = new ChildProgress(50, 70, prog);
            List<CDoModel> yunModel = exportYunArts(subProg, dstFolder, lstDependYun);
            if (!CmnUtil.isObjectEmpty(yunModel))
            {
                // 编译生成云的DAO模型包
                String dstFile = "lib/yun_dao_model.jar";
                exportYunModels(dstFolder+"/"+dstFile, yunModel);
                
                ToolUtilities.saveFileUtf8(dstFolder + "/" + CDaoConst.INIT_MODEL_JAR_CONF, dstFile+"\n", true);
                IProgressUtil.send(prog, 70, "Export Artifact Related Dao Models : " + ToolUtilities.logString(yunModel, false), true);
                
                // 确保工程模型不会和云组件模型冲突
                for (CDoModel md : yunModel)
                    expModels.remove(md.getFullClassName());
            }

            // 导出工程模型包（工程的模型以本地DAO为准）
            expModels.addAll(lstModels);
            if (!CmnUtil.isObjectEmpty(expModels))
            {
                IProgressUtil.send(prog, 71, "Export Dao Models : " + ToolUtilities.logString(expModels, false), true);
                String modelJarFile = getModelFilePath();
                CDaoClient.getMe().exportJar(dstFolder + "/" + modelJarFile, expModels);

                ToolUtilities.saveFileUtf8(dstFolder + "/" + CDaoConst.INIT_MODEL_JAR_CONF, modelJarFile+"\n", true);
            }

        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    // 返回相关模型的包
    public List<CDoModel> exportYunArts(IProgress prog, String dstFolder, List<ArtifactDefine> yunArts) throws Exception
    {
        List<CDoModel> retModel = new LinkedList<CDoModel>();
        GlobalDependSetting globalDepSetting = CJavaCenter.getMe().queryGlobalDepends();

        // 将第一层依赖，查出整个递归依赖图谱，并去重
        List<ArtifactWare> lstAllDependWare = ArtifactUtil.queryAllDependWare(yunArts);

        // 整合冲突后，一个个下载release包、模型包等
        lstAllDependWare = ArtifactUtil.mergeConflictList((List) lstAllDependWare, globalDepSetting.getPreferConfigMap());
        for (int i = 0; i < lstAllDependWare.size(); i++)
        {
            ArtifactWare yunArt = lstAllDependWare.get(i);
            IProgressUtil.assertCancel(prog);
            int per = i * 70 / lstAllDependWare.size();

            boolean exclude = false;
            String artName = (yunArt.getGroupId() + "." + yunArt.getArtifactId()).toLowerCase();
            for (String ex : Nulls.get(lstExcludeArts))
            {
                if (artName.contains(ex.toLowerCase()))
                {
                    exclude = true;
                    break;
                }
            }

            // 在排除列表，或者全局设定中排除的，只要组件名-Artifact ID相同则排除
            if (exclude || globalDepSetting.isExcludeArtifact(yunArt))
            {
                IProgressUtil.sendProcess(prog, per, "Exclude artifact : " + yunArt, true);
                continue;
            }

            IProgressUtil.sendProcess(prog, per, "Download artifact : " + yunArt, true);
            // 读取附件
            List<CDoAttach> lstFiles = YunStoreAgent.getIntf().queryReleasePackage(yunArt.getUuid());
            if (!CmnUtil.isObjectEmpty(lstFiles))
            {
                for (CDoAttach att : lstFiles)
                {
                    CPluginJarDto jar = new CPluginJarDto();
                    jar.setName(att.getName());
                    jar.setFileBin(att.getContentBin());

                    ToolUtilities.saveFile(dstFolder + "/lib/" + att.getName(), att.getContentBin(), false);
                }
            }

            // 读取模型
            ToolUtilities.combineList(retModel, YunStoreAgent.getIntf().queryModelPackage(yunArt.getUuid()));
        }

        return retModel;
    }

    // 导出云组件附带的模型
    public void exportYunModels(String dstFile, Collection<CDoModel> models) throws Exception
    {

        // 模型去重
        Map<String, CDoModel> map = new HashMap<String, CDoModel>();
        for (CDoModel md : Nulls.get(models))
            map.put(md.getFullClassName(), md);
        models = map.values();

        // 独立编译这些模型包，不要依赖现有库里的动态模型
        Map<String, byte[]> mapCls = CDaoClient.getIntf().batchCompileModels(models, false, false);

        // 无论有无自定义模型，都必须输出一个文件，以免下载到非法jar包
        try (FileOutputStream flOut = new FileOutputStream(dstFile);)
        {
            try (JarOutputStream jarOut = new JarOutputStream(flOut))
            {
                JarEntry entryTag = new JarEntry(CJavaConst.PATH_EXPORT_DAO_TAG_FILE);
                jarOut.putNextEntry(entryTag);
                jarOut.write(("0").getBytes());
                jarOut.closeEntry();

                for (CDoModel md : models)
                {
                    byte[] bt = mapCls.get(md.getFullClassName());
                    CmnUtil.assertNotNull(bt, "Invalid dao model class = NULL : " + md.getFullClassName());

                    String classPath = ToolUtilities.replaceAll(md.getFullClassName(), ".", "/");
                    while (classPath.startsWith("/"))
                        classPath = classPath.substring(1);

                    JarEntry entry1 = new JarEntry(classPath + ".class");
                    jarOut.putNextEntry(entry1);
                    jarOut.write(bt);
                    jarOut.closeEntry();
                }
            }
        }
    }

    // 打包成zip，exportStarter是否输出同名starter配置文件（用于代理自动部署）
    public void packZip(IProgress prog, String targetFile, boolean exportStarter) throws Exception
    {
        String dir = ToolUtilities.getDirectory(targetFile);
        String pureName = ToolUtilities.getFileNameWithoutExt(targetFile);
        try (TempFile tmpFolder = new TempFile())
        {
            pack(new ChildProgress(0, 70, prog), tmpFolder.getAbsolutePath());

            IProgressUtil.sendProcess(prog, 71, "Zip target file : " + targetFile, true);
            ZipUtils.zip(tmpFolder.getAbsolutePath(), targetFile, "UTF-8");
            if (exportStarter)
                Files.copy(new File(tmpFolder + "/" + StarterMain.CONF), new File(dir, pureName + ".xml"));
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    public void assemblePropConf(String dstFolder) throws IOException
    {
        if (propConf.isEmpty())
            return;

        Properties props = new Properties();
        try
        {
            props = ToolUtilities.readPropertyFile(dstFolder + "/" + ADV_CONF_FILE);
        } catch (Throwable exp)
        {
            // ignore no file or other error
//            exp.printStackTrace();
        }

        props.putAll(propConf);
        ToolUtilities.saveProperty(dstFolder + "/" + ADV_CONF_FILE, props);

    }

    // starterTemplateFile ：启动配置的样板文件（默认取主控的，外部可指定为任意）
    public void assembleStarterConf(String dstFolder) throws Exception
    {
        // 加载、覆盖
        String file = dstFolder + "/conf/starter.xml";
        if (!CmnUtil.isStringEmpty(starterTemplateFile))
        {
            ToolUtilities.deleteFileFolder(file);
            Files.copy(new File(starterTemplateFile), new File(file));
        }

        StarterConf conf = StarterMain.loadConfig(file);
        conf.getMapItems().putAll(mapStarter);

        // 自动校验、排序后，覆盖存盘
        ToolUtilities.saveFileUtf8(file, StarterMain.saveConfigAdv(conf), false);
    }

    public void exportCellConfig(String dstFolder) throws Exception
    {
        Map<String, CellConfig> mapConf = CJavaCenter.getMe().queryCellDaoConfig();
        if (CmnUtil.isObjectEmpty(mapConf))
            return;

        String confXml = CellConfigAdapter.saveConfigXml(mapConf);

        // 生成注释区（默认的配置作为参考）
        String example = "";
        for (Entry<String, CellConfig> ent : Nulls.get(mapConf).entrySet())
        {
            if (ent.getValue() != null)
                continue;

            // 默认为空，则生成默认但是要注释掉
            Class clsImpl = ClassFactory.loadClass(ent.getKey());
            if (clsImpl == null || clsImpl.getAnnotation(Config.class) == null)
                continue;

            Class cfgCls = ((Config) clsImpl.getAnnotation(Config.class)).value();
            CellConfig cfg = (CellConfig) ToolUtilities.newObject(cfgCls);
            example += ToolUtilities.xmlDom4j2String(CellConfigAdapter.toXml(clsImpl.getName(), cfg)) + "\n";
        }
        if (!example.isEmpty())
            confXml = confXml + "\n\n" + "<!-- [Other Default Config] \n" + example + "\n-->";

        ToolUtilities.saveFileUtf8(dstFolder + "/" + CellConfigAdapter.FILE_CONFIG, confXml, false);
    }

    public static void testSample(String dstFolder) throws Exception
    {
        String conf = new String(ToolUtilities.readResourceFile("bap/java/SamplePackerBom.xml"), "UTF-8");
        BapPackerUtil packer = new BapPackerUtil(conf);

        packer.pack(new CTraceProgress(), dstFolder);
    }

    public static void testSampleAgent(String dstFile) throws Exception
    {
        String conf = new String(ToolUtilities.readResourceFile("bap/java/SampleAgentBom.xml"), "UTF-8");
        BapPackerUtil packer = new BapPackerUtil(conf);

        packer.packZip(new CTraceProgress(), dstFile, true);
    }
}
