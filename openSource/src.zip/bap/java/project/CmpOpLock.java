package bap.java.project;

import java.util.Collection;

import com.leavay.common.util.StringLock;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.ToolUtilities;

import bap.java.CJavaCode;

public class CmpOpLock
{
    boolean _lock_rebuildAll = false;
    
    StringLock _lock_one_code = new StringLock();
    public synchronized void lockRebuildAll()
    {
        assertNotCompileOneCode();
        
        _lock_rebuildAll = true;
    }
    
    public synchronized void unlockRebuildAll()
    {
        _lock_rebuildAll = false;
    }
    
    public synchronized boolean isLockRebuildAll()
    {
        return _lock_rebuildAll;
    }
    
    public synchronized void assertNotRebuildAll()
    {
        if (isLockRebuildAll())
            throw new RuntimeException("The project is rebuilding");
    }
    
    public synchronized void assertNotCompileOneCode()
    {
        if (_lock_one_code.hasLock())
            throw new RuntimeException("Some code is compiling");
    }
    
    public synchronized void lockCode(String fullClassName) throws TimeoutException
    {
        assertNotRebuildAll();
        
        _lock_one_code.lockDN(fullClassName);
    }
    
    public synchronized void unlockCode(String fullClassName)
    {
        _lock_one_code.unlockIfExist(fullClassName);
    }
    
    public synchronized void lockCodes(Collection<CJavaCode> codes)
    {
        try
        {
            for (CJavaCode code : codes)
            {
                lockCode(code.getFullClassName());
            }
        } catch (Throwable err)
        {
            unlockCodes(codes);
            ToolUtilities.throwRuntimeException(err);
        }
    }
    
    public synchronized void unlockCodes(Collection<CJavaCode> codes)
    {
        for (CJavaCode code : codes)
        {
            try
            {
                unlockCode(code.getFullClassName());
            } catch (Throwable err)
            {

            }
        }
    }
    
    public synchronized void assertCanChangeJarRes()
    {
        assertNotCompileOneCode();
        assertNotRebuildAll();
    }
}
