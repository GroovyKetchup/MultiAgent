package bap.java.project;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import org.dom4j.Element;

import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import cmn.util.NullUtil;

public class LoneWolfConfig implements Serializable
{
    private static final long serialVersionUID = -4168630853434617480L;

    public final static String CONF_FILE = "conf/LoneWolf.xml";
    
    public List<String> lstFolders;
    
    public List<LaunchItem> lstLaunchItems;
    
    private static LoneWolfConfig _me;
    public synchronized static LoneWolfConfig get()
    {
        if (_me == null)
        {
            _me = new LoneWolfConfig();
        }
        return _me;
    }
    
    public List<String> getLstFolders()
    {
        return lstFolders;
    }

    public void addFolder(String folder)
    {
        lstFolders = ToolUtilities.addToList(lstFolders, folder);
    }
    
    public String readConf() throws IOException
    {
        return ToolUtilities.readFile(CONF_FILE, "UTF-8");
    }

    protected LoneWolfConfig()
    {
        try
        {
            String xml = readConf();
            Element eleRoot = ToolUtilities.xmlString2Dom4j(xml);
            List<Element> lst = eleRoot.elements("folder");
            for (Element eleFolder : NullUtil.get(lst))
            {
                String s = eleFolder.getTextTrim();
                addFolder(s);
            }
            
            List<Element> lstLaunch = eleRoot.elements("launch");
            for (Element eleLaunch : NullUtil.get(lstLaunch))
            {
                LaunchItem i = new LaunchItem();
                i.setName(eleLaunch.attributeValue("name"));
                i.setMainType(eleLaunch.attributeValue("mainType"));
                i.setVmArguments(eleLaunch.attributeValue("vmArg", ""));
                i.setProgramArguments(eleLaunch.attributeValue("programArg", ""));
                addLaunchItem(i);
            }
        } catch (IOException noFile)
        {
            
        } catch (Throwable err)
        {
            throw new RuntimeException("Failed to load Lone Wolf Config : " + CONF_FILE);
        }
    }
    
    public static LoneWolfConfig create(final String confXml)
    {
        return new LoneWolfConfig() {
            public String readConf()
            {
                return confXml;
            }
        };
    }

    public List<LaunchItem> getLstLaunchItems()
    {
        return lstLaunchItems;
    }

    public void setLstLaunchItems(List<LaunchItem> lstLaunchItems)
    {
        this.lstLaunchItems = lstLaunchItems;
    }

    public void setLstFolders(List<String> lstFolders)
    {
        this.lstFolders = lstFolders;
    }
    
    public void addLaunchItem(LaunchItem item)
    {
        lstLaunchItems = CmnUtil.addToList(lstLaunchItems, item);
    }
    
}
