package bap.java.project;

import java.io.Serializable;

public class CJavaHint implements Serializable
{
    private static final long serialVersionUID = -7665258241488466490L;
    
    // CodeDeclareInfo
    public final static int BASE_TYPE = 0;  // int, long, char, double .....
    public final static int TYPE = 1;
    public final static int FIELD = 2;
    public final static int METHOD = 3;
    public final static int ARGUMENT = 4;
    public final static int VARIALBE = 5;
    public final static int INITIAL_BLOCK = 6;
    public final static int OTHER = 10000;
            
    String text; // 通常用于输出游标处的字符，匹配实时输入的key以及回车后直接带入代码的部分
    String displayText; // 在提示菜单中显示的完整信息（通常还带有一些注解、说明等）
    String className; // 完整的类名（方法、字段的申明类，类的含包名可用于导入）
    
    int startPos=0; // 用于回车后替换原文件的起始位置
    int endPos=0;
    
    int type=OTHER;

    public String getText()
    {
        return text;
    }

    public void setText(String text)
    {
        this.text = text;
    }

    public String getDisplayText()
    {
        return displayText;
    }

    public void setDisplayText(String displayText)
    {
        this.displayText = displayText;
    }

    public String getClassName()
    {
        return className;
    }

    public void setClassName(String className)
    {
        this.className = className;
    }

    public int getStartPos()
    {
        return startPos;
    }

    public void setStartPos(int startPos)
    {
        this.startPos = startPos;
    }

    public int getEndPos()
    {
        return endPos;
    }

    public void setEndPos(int endPos)
    {
        this.endPos = endPos;
    }

    public int getType()
    {
        return type;
    }

    public void setType(int type)
    {
        this.type = type;
    }
    
    public String toString()
    {
        return getText()+"("+getStartPos()+", "+getEndPos()+")";
    }
}
