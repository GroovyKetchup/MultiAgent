package bap.java.project;

import org.nutz.dao.Cnd;
import org.nutz.dao.util.cri.SqlExpression;

import com.cdao.mgr.listener.CDaoAction;
import com.cdao.mgr.listener.CDaoSyncAdapter;
import com.leavay.common.util.ToolUtilities;

import bap.java.CJavaUtil;
import bap.md.java.CJavaCodeDo;
import bap.md.java.CResFileDo;
import cell.cdao.IDao;
import cell.cdao.IDaoService;

public class CJavaCodeDeleteListener extends CDaoSyncAdapter
{
    public static volatile boolean debug = true;
    private static final long serialVersionUID = -6614087682898753597L;

    public void action(IDao dao, CDaoAction action) throws Exception
    {
        CJavaCodeDo delCode = null;
        try (IDao daoOutside = IDaoService.newIDao())
        {
            delCode = (CJavaCodeDo) daoOutside.queryDo(action.getGid(), CJavaCodeDo.JavaPackage, CJavaCodeDo.MainClass);
        }
        
        // 事务内清除相关的meta
        if (delCode != null)
        {
            SqlExpression filter = CJavaUtil.queryMetaExp(delCode.getFullClassName());
            int i = dao.deleteDos(CResFileDo.class.getName(), Cnd.where(filter));
            if (i >0 && debug)
                ToolUtilities.infoAndOutput("Java Code Delete Listener", "Delete meta code of "+delCode.getFullClassName()+" : rows="+i);
        }
    }

}
