package bap.java.project;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

import org.dom4j.Element;
import org.eclipse.jdt.core.compiler.CategorizedProblem;
import org.eclipse.jdt.internal.compiler.ClassFile;
import org.eclipse.jdt.internal.compiler.CompilationResult;
import org.eclipse.jdt.internal.compiler.ast.ASTNode;
import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
import org.eclipse.jdt.internal.compiler.ast.AbstractVariableDeclaration;
import org.eclipse.jdt.internal.compiler.ast.Argument;
import org.eclipse.jdt.internal.compiler.ast.Block;
import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
import org.eclipse.jdt.internal.compiler.ast.Statement;
import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
import org.eclipse.jdt.internal.compiler.lookup.Binding;
import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
import org.nutz.dao.Cnd;

import com.cdao.impl.entity.field.GID;
import com.cdao.mgr.CDao;
import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoUtil;
import com.cdao.mgr.ClassInheritNode;
import com.cdao.model.CDoBasic;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.Exception.MultipleException;
import com.leavay.common.util.IntRange;
import com.leavay.common.util.ListMap;
import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ValuePair;
import com.leavay.common.util.EventNotify.EvtNotifySender;
import com.leavay.common.util.ProgressCtrl.ProgressControllerFEIntf;
import com.leavay.common.util.ProgressCtrl.ProgressCtrlUtil;
import com.leavay.common.util.ProgressCtrl.SrvProgressImpl;
import com.leavay.common.util.ProgressCtrl.SrvProgressIntf;
import com.leavay.common.util.ProgressCtrl.rpc.CRpcProgressImpl;
import com.leavay.common.util.ProgressCtrl.rpc.CRpcProgressWrapper;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.CodeCompileException;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.common.util.javac.CodeUtil;
import com.leavay.common.util.javac.CodeUtil.BasiceClassInfoLoader;
import com.leavay.common.util.javac.CompileStastic;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.LvCompileSingleResult;
import com.leavay.common.util.javac.LvCompileUnit;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.common.util.javac.LvJavac.LvCompileResult;
import com.leavay.common.util.javac.LvProblem;
import com.leavay.dfc.gui.AllSrvEvents;
import com.leavay.dfc.mgr.javaDev.ClassNameInfoExt;
import com.leavay.dfc.mgr.javaDev.ClassSearchEngine;
import com.leavay.ms.tool.CmnUtil;

import bap.client.BapGuiUtil;
import bap.java.BapMgr;
import bap.java.CJavaCode;
import bap.java.CJavaConst;
import bap.java.CJavaUtil;
import bap.java.CommitPackage;
import bap.md.CJarFile;
import bap.md.java.CJavaCodeDo;
import bap.md.java.CJavaFolder;
import bap.md.java.CJavaProject;
import bap.md.java.CJavaVirtualProject;
import bap.md.java.CResFileDo;
import bap.plugin.CPluginJarDto;
import bap.version.CVerMgr;
import cell.UdfIntf;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import cmn.util.NullUtil;
import cmn.util.Nulls;
import cplugin.ms.dto.CResFileDto;
import dr.rice.cs.drjava.model.compiler.JavacCompiler;
import ms.cmn.util.MD5Util;

public class CJavaPJBuilder extends BapMgr
{
    public final static String LOG = "Java Project Builder";

    CJavaProject _project = null;

    public final static String BUILD_TMP_PATH = "temp/java_build_temp";

    // 代码、包树的锁
    ReentrantLock _codeLock = new ReentrantLock();

    // key : class full name
    Map<String, CJavaCode> _cache = new TreeMap<String, CJavaCode>();

    // map 套 map
    // 第一级是 : 目录UUID ==> pkg map
    // 第二级是 : pkg全名 ==> 类名(不含包名)
    Map<String, Map<String, Set<String>>> _pkgFolderMap = new TreeMap<String, Map<String, Set<String>>>();

    // compiler锁，可以锁编译器、DST目录、lib目录等编译所需数据
    CmpOpLock _opLock = new CmpOpLock();

    ReentrantReadWriteLock _lockJarRes = new ReentrantReadWriteLock();

    ReadLock _r_jar_res = _lockJarRes.readLock();

    WriteLock _w_jar_res = _lockJarRes.writeLock();

    // compiler结果锁，可以锁编译结果、统计结果等
    BasiceClassInfoLoader _jarClassInfoLoader = new BasiceClassInfoLoader(); // 存放导入的jar包涉及到的所有类信息，主要用于代码辅助

    ReentrantLock _cmpResultLock = new ReentrantLock();

    LvCompileSingleResult _cResult = new LvCompileSingleResult();

    // map 套 map
    // 第一级是目录RDN =对= 统计map
    // 第二级是全名（类全名或包名） =对= 统计值
    Map<String, Map<String, CompileStastic>> _stastic = new TreeMap<String, Map<String, CompileStastic>>();

    Map<String, CompileStastic> _folderStastic = new TreeMap<String, CompileStastic>();

    ListMap<LvCompileResult> _cmpCache = new ListMap<LvCompileResult>(50);

    public CJavaPJBuilder(CJavaProject pjDo)
    {
        assert (pjDo != null);
        _project = pjDo;
    }

    public static CJavaPJBuilder newTempBuilder(int dependType)
    {
        CJavaProject tmpPj = new CJavaProject();
        tmpPj.setDependType(dependType);
        CJavaPJBuilder bd = new CJavaPJBuilder(tmpPj);
        return bd;
    }

    public synchronized void updateProjectDo(CJavaProject pjDo)
    {
        assert (pjDo != null);
        _project = pjDo;
    }

    public CJavaProject getProject()
    {
        return _project;
    }

    public void reloadCache() throws Exception
    {
        lock(_codeLock);
        try
        {
            _cache.clear();
            _pkgFolderMap.clear();

            List<CJavaCodeDo> allCodes = CJavaCenter.getAllCodeDos(getProject().getGid());
            for (CJavaCodeDo o : allCodes)
            {
                addCode2Cache(o);
            }

            // 如果有持久化的编译结果，可加载
            try
            {
                loadCompileResult();
            } catch (Throwable err)
            {
                ToolUtilities.error(LOG, "Failed to load compile result of " + getProject().getName(), err);
                cleanBuild();
            }

            // 如果jar文件已经落地，可初始化jar文件中的类信息
            try
            {
                File[] jarFile = getAllJarPaths();
                if (jarFile != null)
                    for (File fl : jarFile)
                    {
                        CodeUtil.ananyseClass(fl.getAbsolutePath(), _jarClassInfoLoader);
                    }
            } catch (Exception exp)
            {
                ToolUtilities.error(LOG, "Failed to load jar file of " + getProject().getName(), exp);
            }
        } finally
        {
            _codeLock.unlock();
        }
    }

    protected CJavaCode addCode2Cache(CJavaCodeDo codeDo) throws Exception
    {
        CmnUtil.assertNotEmpty(codeDo.getMainClass(), "Please define main class in java code : " +codeDo);
        
        lock(_codeLock);
        try
        {
            CJavaCode o = CJavaUtil.fromDo(codeDo);
            _cache.put(o.getFullClassName(), o);

            // 无目录的不加入目录包名map
            if (!codeDo.hasOwner())
                return o;

            String folderUuid = codeDo.getOwner();
            Map<String, Set<String>> pkgMap = _pkgFolderMap.get(folderUuid);
            if (pkgMap == null)
            {
                pkgMap = new HashMap<String, Set<String>>();
                _pkgFolderMap.put(folderUuid, pkgMap);
            }

            Set<String> set = pkgMap.get(o.getPackage());
            if (set == null)
            {
                set = new TreeSet<String>();
                pkgMap.put(o.getPackage(), set);
            }
            set.add(o.getMainClass());
            return o;
        } finally
        {
            _codeLock.unlock();
        }
    }

    protected void removeFrmCodeCache(String fullClass)
    {
        lock(_codeLock);
        try
        {
            CJavaCode code = _cache.get(fullClass);
            _cache.remove(fullClass);

            String sPkg = LvJavac.getPackageFromFullClass(fullClass);
            String sCls = LvJavac.getClassNameFromFull(fullClass);

            // 维护代码=包的映射缓存
            if (code != null && code.hasOwner())
            {
                Map<String, Set<String>> pkgMap = _pkgFolderMap.get(code.getOwner());
                if (pkgMap != null)
                {
                    Set<String> setClass = pkgMap.get(sPkg);
                    if (setClass != null)
                    {
                        setClass.remove(sCls);
                        if (setClass.isEmpty())
                            pkgMap.remove(sPkg);
                    }

                    if (pkgMap.isEmpty())
                        _pkgFolderMap.remove(code.getOwner());
                }
            }
        } finally
        {
            _codeLock.unlock();
        }
    }

    // 调这个函数非常慢，是遍历，只限于读虚拟的代码，系统开源的那种
    public CJavaCode getCodeByRDN(String codeUuid)
    {
        lock(_codeLock);
        try
        {
            for (CJavaCode code : _cache.values())
                if (ToolUtilities.isStringEqual(code.getUuid(), codeUuid))
                    return code;
        } finally
        {
            _codeLock.unlock();
        }

        return null;
    }

    public CJavaCode getCode(String fullClassName)
    {
        lock(_codeLock);
        try
        {
            return _cache.get(fullClassName);
        } finally
        {
            _codeLock.unlock();
        }
    }

    public CJavaCode getCodeByFileName(String classFileName)
    {
        String clsName = LvJavac.getMainClassFromFileName(classFileName);

        return getCode(clsName);
    }

    public Set<String> getAllFolders()
    {
        lock(_codeLock);
        try
        {
            return new TreeSet<String>(_pkgFolderMap.keySet());
        } finally
        {
            _codeLock.unlock();
        }
    }

    public Set<String> getAllPackages(String folderUuid)
    {
        lock(_codeLock);
        try
        {
            Map<String, Set<String>> pkgMap = _pkgFolderMap.get(folderUuid);
            if (pkgMap == null)
                return null;
            return new HashSet<String>(pkgMap.keySet());
        } finally
        {
            _codeLock.unlock();
        }
    }

    // 如果要搜索无包类，那么需要传入""进行搜索
    public List<CJavaCode> getChildCode(String sPackage)
    {
        List<CJavaCode> lst = new ArrayList();
        lock(_codeLock);
        try
        {
            for (Map<String, Set<String>> pkgMap : _pkgFolderMap.values())
            {
                Set<String> classN = pkgMap.get(sPackage);
                if (!ToolUtilities.isObjectEmpty(classN))
                {
                    for (String s : classN)
                    {
                        CJavaCode code = _cache.get(LvJavac.getFullClassName(sPackage, s));
                        lst.add(code);
                    }
                }
            }
            return lst;
        } finally
        {
            _codeLock.unlock();
        }
    }

    // 如果要搜索无包类，那么需要传入""进行搜索
    // 返回的是摘要信息，不含源码
    public List<CJavaCode> getChildCodeBrief(String folderRDN, String sPackage)
    {
        List<CJavaCode> lst = new ArrayList();
        lock(_codeLock);
        try
        {
            Map<String, Set<String>> pkgMap = _pkgFolderMap.get(folderRDN);
            if (pkgMap != null)
            {
                Set<String> classN = pkgMap.get(sPackage);
                if (!ToolUtilities.isObjectEmpty(classN))
                {
                    for (String s : classN)
                    {
                        CJavaCode code = _cache.get(LvJavac.getFullClassName(sPackage, s));
                        lst.add(code.newBrief());
                    }
                }
            }
            return lst;
        } finally
        {
            _codeLock.unlock();
        }
    }

    public List<CJavaCode> getAllCode()
    {
        lock(_codeLock);
        try
        {
            return new ArrayList(_cache.values());
        } finally
        {
            _codeLock.unlock();
        }
    }

    public Map<String, CJavaCode> getAllCodeMap()
    {
        lock(_codeLock);
        try
        {
            return new TreeMap(_cache);
        } finally
        {
            _codeLock.unlock();
        }
    }

//
//    public CJavaCode createJavaCode(CJavaCode code, boolean autoCompile) throws Exception
//    {
//        CJavaCode existName = getCode(code.getFullClassName());
//        if (existName != null)
//            throw new Exception(SrvRes.getString("Found duplicate class in project"));
//
//        JavaCodeMo mo = code.toMo();
//        mo.setPDN(getProject().getRDN());
//        MDMgrConn conn = getMoMgr();
//        try
//        {
//            mo = (JavaCodeMo) createMo(mo);
//            conn.commit();
//
//            JavaCode newCode = addCode2Cache(mo);
//
//            if (autoCompile)
//                rebuildOneCodeLater(newCode);
//            return newCode;
//        } catch (Throwable err)
//        {
//            conn.rollback();
//            ToolUtilities.throwException(err);
//            return null;
//        } finally
//        {
//            releaseMoMgr(conn);
//        }
//    }
//
//    // 这个和普通的保存有些不同，这个不是通过RDN来判断是新增还是修改，而是通过全路径类名
//    // 所以和save的实现不同
//    public void importJavaCode(CJavaCode impCode) throws Exception
//    {
//        CJavaCode existCode = getCode(impCode.getFullClassName());
//        if (existCode == null)
//        {
//            createJavaCode(impCode, false);
//        } else
//        {
//            if (!ToolUtilities.isStringEqual(impCode.getOwner(), existCode.getOwner()))
//                throw new Exception("Found duplicate class in another folder" + getMoName(existCode.getOwner()));
//
//            saveJavaCode(existCode.getUuid(), impCode.getCode(), false);
//        }
//    }
//
//    // 这个实现较为复杂，是因为支持变更包名甚至类名，所以是通过RDN来找老的code，并删除老code的缓存，新增新的code
//    // 所以传入参数的rdn就很重要了
//    public JavaCode saveJavaCode(JavaCode newCode, boolean autoCompile) throws Exception
//    {
//        JavaCodeMo orgCodeMo = (JavaCodeMo) getMo(newCode.getRDN());
//        if (orgCodeMo == null)
//            return createJavaCode(newCode, autoCompile);
//
//        JavaCode orgCode = JavaCode.fromMo(orgCodeMo);
//        orgCode = getCode(orgCode.getFullClassName());
//        if (orgCode == null)
//            throw new Exception("Can not find class in project : " + newCode.getFullClassName());
//
//        JavaCodeMo newCodeMo = (JavaCodeMo) orgCodeMo.clone();
//        newCodeMo.setPackage(newCode.getPackage());
//        newCodeMo.setMainClass(newCode.getMainClass());
//        newCodeMo.setCode(newCode.getCodeS());
//        newCodeMo.setDoc(newCode.getDoc());
//        MDMgrConn conn = getMoMgr();
//        try
//        {
//            newCodeMo = (JavaCodeMo) updateMo(newCodeMo);
//            conn.commit();
//
//            deleteClassFile(orgCode.getFullClassName());
//            removeFrmCodeCache(orgCode.getFullClassName());
//            newCode = addCode2Cache(newCodeMo);
//
//            // rebuild
//            if (autoCompile)
//                rebuildOneCodeLater(newCode);
//
//            return newCode;
//        } catch (Throwable err)
//        {
//            conn.rollback();
//            ToolUtilities.throwException(err);
//            return null;
//        } finally
//        {
//            releaseMoMgr(conn);
//        }
//    }
//
//    public JavaCode saveJavaCode(String codeUuid, String code, boolean autoCompile) throws Exception
//    {
//        JavaCodeMo orgCodeMo = (JavaCodeMo) getMo(codeRDN);
//        if (orgCodeMo == null)
//            throw new Exception("Code doesn't exist");
//
//        orgCodeMo = (JavaCodeMo) orgCodeMo.clone();
//        orgCodeMo.setCode(code);
//        return saveJavaCode(JavaCode.fromMo(orgCodeMo), autoCompile);
//    }
//
//    public boolean removeCode(String fullClass, boolean autoCompile) throws Exception
//    {
//        CJavaCode existCode = getCode(fullClass);
//        if (existCode == null)
//            return false;
//
//        Map<String, CJavaCode> affectedCode = getAllAffectedCode(ToolUtilities.array2List(new CJavaCode[] { existCode }));
//        affectedCode.remove(existCode.getFullClassName());
//
//        deleteMo(existCode.getRDN());
//        deleteClassFile(fullClass);
//        removeFrmCodeCache(fullClass);
//
//        if (autoCompile)
//            rebuildPartiallyLater(affectedCode.values());
//
//        EvtNotifySender.getInstance().fireNotification(AllSrvEvents.JAVA_CODE_DELETED, existCode.getRDN());
//        return true;
//    }
//
//    public boolean removeCode(Set<String> fullClass) throws Exception
//    {
//        Map<String, CJavaCode> affectedCode = getAllAffectedCodeByName(fullClass);
//
//        for (String delClassName : fullClass)
//        {
//            affectedCode.remove(delClassName);
//            removeCode(delClassName, false);
//        }
//
//        if (!ToolUtilities.isObjectEmpty(affectedCode))
//            rebuildPartiallyLater(affectedCode.values());
//        return true;
//    }
//
//    public void deleteFolder(String folderUuid) throws Exception
//    {
//        JavaFolderMo folder = (JavaFolderMo) getMo(folderUuid);
//        // 搜集一个目录下的所有类代码
//        Set<CJavaCode> allCodes = new TreeSet<CJavaCode>();
//        Map<String, Set<String>> pkgMap = _pkgFolderMap.get(folderUuid);
//        if (pkgMap != null)
//        {
//            for (Entry<String, Set<String>> entryPkg : pkgMap.entrySet())
//            {
//                String sPkg = entryPkg.getKey();
//                Set<String> classes = entryPkg.getValue();
//                if (classes != null)
//                    for (String oneClass : classes)
//                    {
//                        String sClass = LvJavac.getFullClassName(sPkg, oneClass);
//                        CJavaCode code = getCode(sClass);
//                        if (code != null)
//                            allCodes.add(code);
//                    }
//            }
//        }
//
//        Map<String, CJavaCode> affCodes = getAllAffectedCode(allCodes);
//
//        // 删除mo，强依赖的JavaMo也会自动删掉，但是缓存还有残留
//        deleteMo(folderUuid);
//
//        // 清理缓存
//        for (CJavaCode code : allCodes)
//            removeCode(code.getFullClassName(), false);
//
//        // 编译受影响的
//        if (!ToolUtilities.isObjectEmpty(affCodes))
//            rebuildPartiallyLater(affCodes.values());
//    }

    public static String getDstPath(CJavaProject project)
    {
        String srdn = project.getUuid();
        srdn = ToolUtilities.replaceAll(srdn, "=", "__");
        return BUILD_TMP_PATH + "/" + srdn;
    }

    public String getDstPath()
    {
        return getDstPath(getProject());
    }

    public final static String DependPath = "Depend";

    public String getDstDependPath()
    {
        return getDstPath(getProject()) + "/" + DependPath;
    }

    public String getDstPath(CJavaCode code)
    {
        return getDstPath(code.getFolder());
    }

    public String getDstPath(String folderUuid)
    {
        return getDstPath(getProject()) + File.separator + folderUuid;
    }

    public static String getJarPath(CJavaProject project)
    {
        String srdn = project.getUuid();
        srdn = ToolUtilities.replaceAll(srdn, "=", "__");
        return BUILD_TMP_PATH + "/" + srdn + "_lib";
    }

    public String getJarPath()
    {
        return getJarPath(getProject());
    }

    public List<ICompilationUnit> getCompileUnit(boolean privateOwn) throws Exception
    {
        List<ICompilationUnit> lst = new ArrayList<ICompilationUnit>();
        lock(_codeLock);
        try
        {
            Map<String, CJavaFolder> mapFolder = getAllFolderMap();
            for (CJavaCode code : _cache.values())
            {
                if (!mapFolder.containsKey(code.getFolder()))
                    continue;

                CJavaFolder fd = mapFolder.get(code.getFolder());
                if (fd.isPrivateOwn() != privateOwn)
                    continue;

                ICompilationUnit unit = new LvCompileUnit(code.getCode().toCharArray(), code.getFilePath()+".java", code.getFileEncoding());
                lst.add(unit);
            }

            return lst;
        } finally
        {
            _codeLock.unlock();
        }
    }

    // 不区分私有/公开，获取所有编译单元
    public List<ICompilationUnit> getCompileUnit() throws Exception
    {
        List<ICompilationUnit> lst = new ArrayList<ICompilationUnit>();
        lock(_codeLock);
        try
        {
            for (CJavaCode code : _cache.values())
            {
                ICompilationUnit unit = new LvCompileUnit(code.getCode().toCharArray(), code.getFilePath(), code.getFileEncoding());
                lst.add(unit);
            }
            return lst;
        } finally
        {
            _codeLock.unlock();
        }
    }

    public int checkAutoImport(CJavaCode code, String impClass) throws Exception
    {
        LvCompileResult result = doCompileSingleCode(code, false);
        if (result.getLvJavac().hasImport(impClass))
            return -1;

        return result.getLvJavac().getLastImportPosition();
    }

    public Map<String, CJavaFolder> getAllFolderMap() throws Exception
    {
        return CJavaCenter.getMe().getFolderMap(getProject().getUuid());
    }

    public Set<String> queryPrivateFolder() throws Exception
    {
        Set<String> set = new HashSet<String>();
        try (CDao dao = newDao())
        {
            List<CJavaFolder> lstFolder = dao.queryDoList(CJavaFolder.class, Cnd.where(CJavaFolder.MasterKey, "=", getProject().getUuid()), CDoBasic.UUID, CJavaFolder.PrivateOwner);
            if (lstFolder != null)
                for (CJavaFolder fd : lstFolder)
                    if (fd.isPrivateOwn())
                        set.add(fd.getUuid());
            return set;
        }
    }

    public boolean isFolderPrivate(String folderUuid) throws Exception
    {
        try (CDao dao = newDao())
        {
            return !CmnUtil.isStringEmpty(CmnUtil.getString(dao.queryFieldValue(GID.build(CJavaFolder.class, folderUuid), CJavaFolder.PrivateOwner), null));
        }
    }

    protected void clearStastic()
    {
        lock(_cmpResultLock);
        try
        {
            _stastic.clear();
            _folderStastic.clear();
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    final static long TIME_OUT_LOCK = 5000;

    public static void lock(ReentrantLock lock)
    {
        try
        {
            if (!lock.tryLock(TIME_OUT_LOCK, TimeUnit.MILLISECONDS))
                throw new RuntimeException("Other operation is locked");
        } catch (InterruptedException exp)
        {
            ToolUtilities.throwRuntimeException(exp);
        }
    }

    public void cleanBuild()
    {
        ToolUtilities.deleteFileFolder(getDstPath());
        _jarClassInfoLoader.clear();

        lock(_cmpResultLock);
        try
        {
            deleteCompileResultFile();
            _cResult.clear();
            clearStastic();
        } finally
        {
            _cmpResultLock.unlock();
        }

        _cmpCache.clearAll();
    }

    // 外面不允许调用，因为有加写锁，比较危险，万一外面又加了读锁就会死
    protected Map<String, CompileStastic> getStastics_Force(String folderUuid)
    {
        lock(_cmpResultLock);
        try
        {
            Map<String, CompileStastic> map = _stastic.get(folderUuid);
            if (map == null)
            {
                map = new TreeMap<String, CompileStastic>();
                _stastic.put(folderUuid, map);
            }

            return map;
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    // 这里不加锁是因为调用它的地方必须加锁
    private void addFolderErrorOrWarn(String folderUuid, boolean isError)
    {
        lock(_cmpResultLock);
        try
        {
            CompileStastic stastic = _folderStastic.get(folderUuid);
            if (stastic == null)
            {
                stastic = new CompileStastic(folderUuid);
                _folderStastic.put(folderUuid, stastic);
            }

            if (isError)
                stastic.increaseError();
            else
                stastic.increaseWarn();
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    // 这里不加锁是因为调用它的地方必须加锁
    private void addError(String folderUuid, String sKey)
    {
        CompileStastic stastic = getStastics_Force(folderUuid).get(sKey);
        if (stastic == null)
        {
            stastic = new CompileStastic(sKey);
            getStastics_Force(folderUuid).put(sKey, stastic);
        }
        stastic.increaseError();
    }

    // 这里不加锁是因为调用它的地方必须加锁
    private void addWarn(String folderUuid, String sKey)
    {
        CompileStastic stastic = getStastics_Force(folderUuid).get(sKey);
        if (stastic == null)
        {
            stastic = new CompileStastic(sKey);
            getStastics_Force(folderUuid).put(sKey, stastic);
        }
        stastic.increaseWarn();
    }

    // 把DB中的jar存到临时编译目录生成实体jar文件
    public List<String> saveJar2File() throws Exception
    {
        List<String> lstJarFile = new ArrayList<String>();
        ToolUtilities.cleanFolder(getJarPath(), true);

        try (CDao dao = newDao())
        {
            List<CJarFile> lstJars = dao.queryDoList(CJarFile.class, Cnd.where(CJarFile.MasterKey, "=", getProject().getUuid()));
            for (CJarFile jar : lstJars)
            {
                byte[] bt = jar.getFileBin();
                String sPath = getJarPath() + "/" + jar.getName();
                ToolUtilities.saveFile(sPath, bt, false);
                lstJarFile.add(sPath);

                CodeUtil.ananyseClass(sPath, _jarClassInfoLoader);
            }
            return lstJarFile;
        }
    }

    public void saveJarFile(CJarFile jarMo) throws Exception
    {
        _opLock.assertCanChangeJarRes();

        _w_jar_res.lock();
        try
        {
            deleteJarFile(jarMo);

            try (CDao dao = newDao())
            {
                byte[] bt = jarMo.getFileBin();
                String sPath = getJarPath() + "/" + jarMo.getName();
                ToolUtilities.saveFile(sPath, bt, false);
                CodeUtil.ananyseClass(sPath, _jarClassInfoLoader);
            }
        } finally
        {
            _w_jar_res.unlock();
        }
    }

    public void deleteJarFile(CJarFile jarFile) throws Exception
    {
        _opLock.assertCanChangeJarRes();

        _w_jar_res.lock();
        try
        {
            File file = new File(getJarPath(), jarFile.getName());
            if (!ToolBasic.deleteFileIfExist(file))
                throw new Exception("Can not delete file : " + jarFile.getName());
        } finally
        {
            _w_jar_res.unlock();
        }
    }

    public List<String> saveAllResFiles() throws Exception
    {
        List<String> lstResFile = new ArrayList<String>();

        List<CResFileDo> lstRes = CJavaCenter.getMe().getResFiles(getProject().getUuid(), null, false);
        if (lstRes != null)
            for (CResFileDo resFile : lstRes)
            {
                byte[] bt = resFile.getFileBin();
                String sPath = getDstPath(resFile.getFolder()) + "/" + resFile.getPhysicalPath();
                ToolUtilities.saveFile(sPath, bt, false);
                lstResFile.add(sPath);
            }
        return lstResFile;
    }

    public void saveResFile(CResFileDo resDo) throws Exception
    {
        _opLock.assertCanChangeJarRes();

        _w_jar_res.lock();
        try
        {
            deleteResFile(resDo.getFolder(), resDo.getPhysicalPath());

            String sPath = getDstPath(resDo.getFolder()) + "/" + resDo.getPhysicalPath();
            ToolUtilities.saveFile(sPath, resDo.getFileBin(), false);
        } finally
        {
            _w_jar_res.unlock();
        }
    }

    // 删除编译路径下的资源文件（物理删除），传入物理路径
    public void deleteResFile(String folderUuid, String filePath) throws Exception
    {
        _opLock.assertCanChangeJarRes();

        _w_jar_res.lock();
        try
        {
            File file = new File(getDstPath(folderUuid), filePath);
            if (!ToolBasic.deleteFileIfExist(file))
                throw new Exception("Can not delete file : " + filePath);
        } finally
        {
            _w_jar_res.unlock();
        }
    }

    public LvCompileSingleResult rebuildAll() throws Exception
    {
        LvCompileResult result = null;
        LvCompileResult resultPrivate = null;

        _opLock.lockRebuildAll();
        try
        {
            _w_jar_res.lock();
            try
            {
                cleanBuild();
                reloadCache();

                List<String> lstResFiles;
                if (getProject().isUdfLib())
                {
                    // 生成资源文件
                    lstResFiles = saveAllResFiles();

                    // UDF工程的编译逻辑非常特殊，一个文件一个文件的编译，不联合编译
                    // 先编译公开代码
                    List<ICompilationUnit> cmpUnits = getCompileUnit();
                    for (ICompilationUnit unit : cmpUnits)
                    {
                        LvJavac cmpUdf = new LvJavac();
                        cmpUdf.optIsGenerateClass = false;
                        LvCompileResult resultUdf = cmpUdf.compile(unit);
                        if (result == null)
                            result = resultUdf;
                        else
                            result.addResults(resultUdf.getResults());

                        // 保存class文件
                        Map<String, CompilationResult> rssPrv = resultUdf.getResults();
                        for (Entry<String, CompilationResult> entry : rssPrv.entrySet())
                        {
                            String fileName = entry.getKey();
                            CJavaCode code = getCodeByFileName(fileName);
                            CompilationResult rs = entry.getValue();
                            LvJavac.saveClassFile(getDstPath(code), rs, code.getUuid());
                        }
                    }
                } else // 以下是正常的工程编译逻辑（非UDF模式）
                {
                    // 工程内lib中的jar文件要存到编译路径下的实体文件
                    List<String> jarFiles = saveJar2File();
                    File[] jars = getAllJarPaths_IncludeDepend();

                    // 生成资源文件
                    lstResFiles = saveAllResFiles();

                    // 加载类
                    try (LvClassLoader classLoader = newClassLoader())
                    {
                        // 先编译公开代码
                        Map<String, byte[]> mapBytes = new HashMap<String, byte[]>();
                        List<ICompilationUnit> cmpUnits = getCompileUnit(false);
                        LvJavac compiler = new LvJavac();
                        compiler.optIsGenerateClass = false;
                        prepareDstPath(classLoader, false);

                        if (jars != null)
                            for (File jarFile : jars)
                                classLoader.addFilePath(jarFile.getAbsolutePath());

                        compiler.setClassLoader(classLoader);
                        result = compiler.compile(cmpUnits);
                        // 保存class文件
                        Map<String, CompilationResult> rss = result.getResults();
                        for (Entry<String, CompilationResult> entry : rss.entrySet())
                        {
                            String fileName = entry.getKey();
                            CJavaCode code = getCodeByFileName(fileName);
                            CompilationResult rs = entry.getValue();
                            LvJavac.saveClassFile(getDstPath(code), rs, code.getUuid());

                            for (ClassFile clsFile : rs.getClassFiles())
                            {
                                mapBytes.put(LvJavac.compoundChar2String(clsFile.getCompoundName(), "."), LvJavac.saveClassFile(clsFile, code.getUuid()));
                            }
                        }

                        // 公开代码不可依赖私有代码，分批编译以校验此强约束
                        List<ICompilationUnit> prvUnits = getCompileUnit(true);
                        if (!CmnUtil.isObjectEmpty(prvUnits))
                        {
                            LvJavac cmpPriv = new LvJavac();
                            cmpPriv.optIsGenerateClass = false;
                            cmpPriv.setClassLoader(classLoader);
                            resultPrivate = cmpPriv.compile(prvUnits);

                            // 保存class文件
                            Map<String, CompilationResult> rssPrv = resultPrivate.getResults();
                            for (Entry<String, CompilationResult> entry : rssPrv.entrySet())
                            {
                                String fileName = entry.getKey();
                                CJavaCode code = getCodeByFileName(fileName);
                                CompilationResult rs = entry.getValue();
                                LvJavac.saveClassFile(getDstPath(code), rs, code.getUuid());
                                
                                for (ClassFile clsFile : rs.getClassFiles())
                                {
                                    mapBytes.put(LvJavac.compoundChar2String(clsFile.getCompoundName(), "."), LvJavac.saveClassFile(clsFile, code.getUuid()));
                                }
                            }
                        }

                        _cResult.setListResFiles(lstResFiles);
                        _cResult.setByteMap(classLoader.getCachedClassData());
                        _cResult.getByteMap().putAll(mapBytes); // 这一步很重要，用新编译出来的，覆盖原有可能的（灰度发布的byte内容可能残留在里面）
                    }
                }
            } finally
            {
                _w_jar_res.unlock();
            }

            lock(_cmpResultLock);
            try
            {
                if (result != null)
                {
                    Map<String, CompilationResult> rss = result.getResults();
                    _cResult.addResults(rss.values());
                    _cResult.setImportCache(result.getImportCache());
                }

                if (resultPrivate != null)
                {
                    Map<String, CompilationResult> rssPrv = resultPrivate.getResults();
                    _cResult.addResults(rssPrv.values());
                    _cResult.setImportCache(resultPrivate.getImportCache());
                }

                // 统计错误、警告
                recalculateStastic();

                saveCompileResult();
                
                return _cResult;
            } finally
            {
                _cmpResultLock.unlock();
            }
        } finally
        {
            _opLock.unlockRebuildAll();
        }
    }
    
    public boolean isLockRebuildAll()
    {
        return _opLock.isLockRebuildAll();
    }

    public void saveCompileResult() throws IOException
    {
        lock(_cmpResultLock);
        try
        {
            Element eleXml = LvCompileSingleResult.toXml(_cResult);
            String sXml = ToolUtilities.xmlDom4j2String(eleXml, "UTF-8");
            ToolUtilities.saveFile(getCompileResutlPath(), sXml, "UTF-8", false);
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    public void loadCompileResult() throws Exception
    {
        lock(_cmpResultLock);
        try
        {
            File file = new File(getCompileResutlPath());
            if (file.exists() && file.canRead())
            {
                String sXml = new String(ToolUtilities.readFile(getCompileResutlPath()), "UTF-8");
                _cResult = LvCompileSingleResult.fromXml(ToolUtilities.xmlString2Dom4j(sXml));

                recalculateStastic();
            }
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    public static final String XML_RESULT_FILE = "CompileResult.xml";

    public String getCompileResutlPath()
    {
        return getDstPath() + "/" + XML_RESULT_FILE;
    }

    protected void deleteCompileResultFile()
    {
        ToolUtilities.deleteFileFolder(getCompileResutlPath());
    }

    public Set<String> getSubClasses(String sFullClass)
    {
        lock(_cmpResultLock);
        try
        {
            return _cResult.getChildClass(sFullClass);
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    protected void deleteClassFile(CJavaCode code)
    {
        Set<String> subClasses = getSubClasses(code.getFullClassName());
        ToolUtilities.deleteFileFolder(getDstPath(code) + "/" + code.getFullClassName().replace('.', '/') + ".class");
        if (subClasses != null)
        {
            for (String subClass : subClasses)
                ToolUtilities.deleteFileFolder(getDstPath(code) + "/" + subClass.replace('.', '/') + ".class");
        }
    }

    protected void deleteAndSaveClassFile(CJavaCode code, CompilationResult rs) throws IOException
    {
        deleteClassFile(code);
        LvJavac.saveClassFile(getDstPath(code), rs, code.getUuid());
    }

    public Map<String, List<LvProblem>> getCacheProblems()
    {
       
        lock(_cmpResultLock);
        try
        {
            return new HashMap(_cResult.getAllProblems());
        } finally
        {
            _cmpResultLock.unlock();
        }
    }
    
    public boolean hasError()
    {
        lock(_cmpResultLock);
        try
        {
            return _cResult.hasErrors();
        } finally
        {
            _cmpResultLock.unlock();
        }
    }
    
    public void recalculateStastic()
    {
        lock(_cmpResultLock);
        try
        {
            clearStastic();
            Map<String, List<LvProblem>> allProbs = _cResult.getAllProblems();
            for (Entry<String, List<LvProblem>> entry : allProbs.entrySet())
            {
                String sMainClass = entry.getKey();
                String pkgName = LvJavac.getPackageFromFullClass(sMainClass);
                List<LvProblem> lstProb = entry.getValue();
                CJavaCode code = getCode(sMainClass);
                if (code != null && !ToolUtilities.isObjectEmpty(lstProb))
                {
                    for (LvProblem pb : lstProb)
                    {
                        if (pb.isError())
                        {
                            addFolderErrorOrWarn(code.getOwner(), true);
                            addError(code.getOwner(), sMainClass);
                            addError(code.getOwner(), pkgName);
                        } else if (pb.isWarning())
                        {
                            addFolderErrorOrWarn(code.getOwner(), false);
                            addWarn(code.getOwner(), sMainClass);
                            addWarn(code.getOwner(), pkgName);
                        }
                    }
                }
            }
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    LazyPool<CJavaCode> _rebuildPool = new LazyPool<CJavaCode>("CJava Project Builder", 700)
    {
        public void handle(List<CJavaCode> objects)
        {
            Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
            try
            {
                rebuildPartially(objects, false);
            } catch (Exception exp)
            {
                ToolUtilities.error(LOG, exp);
            }
        }
    };

    public void rebuildPartiallyLater(Set<String> classNames)
    {
        Collection<CJavaCode> lst = new ArrayList<CJavaCode>();
        for (String s : classNames)
        {
            CJavaCode code = getCode(s);
            lst.add(code);
        }

        if (!ToolUtilities.isObjectEmpty(lst))
            rebuildPartiallyLater(lst);
    }

    public void rebuildPartiallyLater(Collection<CJavaCode> lstCode)
    {
        _rebuildPool.add(lstCode);
    }

    public void rebuildOneCode(CJavaCode oneCode) throws Exception
    {
        Map<String, CJavaCode> affected = getAllAffectedCode(ToolUtilities.newArrayList(oneCode));

        LvCompileResult rs = rebuildPartially(ToolUtilities.newArrayList(oneCode), false);
        if (affected != null)
            rebuildPartiallyLater(affected.values());

        _cmpCache.add(oneCode.getFullClassName(), rs);
    }

    public void rebuildOneCodeLater(CJavaCode oneCode) throws Exception
    {
        // 先编译自身
        LvCompileResult rs = rebuildPartially(ToolUtilities.newArrayList(oneCode), false);
        _cmpCache.add(oneCode.getFullClassName(), rs);

        // 延迟编译受影响的代码
        Map<String, CJavaCode> affected = getAllAffectedCode(ToolUtilities.newArrayList(oneCode));
        affected.remove(oneCode.getFullClassName());
        if (affected != null)
            rebuildPartiallyLater(affected.values());
    }

    // 将一堆代码，按照目录的公开和私有分到两堆
    // 公开的代码全部放一堆，私有代码按照目录的UUID单独放置
    public void dividCompilePackage(Collection<CJavaCode> lstCode, List<CJavaCode> lstPublic, Map<String, List<CJavaCode>> mapPrivate) throws Exception
    {
        Map<String, CJavaFolder> folders = getAllFolderMap();
        for (CJavaCode code : lstCode)
        {
            CJavaFolder fd = folders.get(code.getFolder());
            if (fd == null)
                continue;

            if (fd.isPrivateOwn())
                CmnUtil.putMapList(mapPrivate, fd.getUuid(), code);
            else
                lstPublic.add(code);
        }
    }

    protected LvCompileResult rebuildPartially(Collection<CJavaCode> lstCode, boolean isAutoRebuildAffected) throws Exception
    {
        List<ICompilationUnit> lstUnits = null;
        LvCompileResult result;

        if (isAutoRebuildAffected)
            lstCode = getAllAffectedCode(lstCode).values();

        _opLock.lockCodes(lstCode);
        try
        {
            // 开始编译，要锁住jar和class文件不能被修改
            _r_jar_res.lock();
            try
            {
                LvJavac compiler = new LvJavac();
                compiler.optIsGenerateClass = false;

                List<CJavaCode> lstPublic = new LinkedList<CJavaCode>();
                Map<String, List<CJavaCode>> mapPrivate = new HashMap();
                dividCompilePackage(lstCode, lstPublic, mapPrivate);

                LvClassLoader classLoader = newClassLoader();
                prepareDstPath(classLoader, true, "NO PRIVATE");

                File[] jarFiles = getAllJarPaths_IncludeDepend();
                if (jarFiles != null)
                    for (File jarFile : jarFiles)
                        classLoader.addFilePath(jarFile.getAbsolutePath());
                compiler.setClassLoader(classLoader);

                // 先处理公开代码
                lstUnits = new ArrayList<ICompilationUnit>();
                for (CJavaCode code : lstPublic)
                {
                    ICompilationUnit unit = new LvCompileUnit(code.getCode().toCharArray(), code.getFilePath(), code.getFileEncoding());
                    lstUnits.add(unit);
                }
                result = compiler.compile(lstUnits);

                // 再一个个目录的编译私有代码，私有代码之间是不相干
                for (Entry<String, List<CJavaCode>> ent : mapPrivate.entrySet())
                {
                    String thisFolder = ent.getKey();
                    List<CJavaCode> lstPrivateCode = ent.getValue();

                    try (LvClassLoader tmpLoader = new LvClassLoader(classLoader))
                    {
                        LvJavac cmpPrivate = new LvJavac();
                        prepareDstPath(tmpLoader, true, thisFolder);
                        cmpPrivate.setClassLoader(tmpLoader);
                        List<ICompilationUnit> lstTmpUnits = new LinkedList<ICompilationUnit>();
                        for (CJavaCode code : lstPrivateCode)
                        {
                            ICompilationUnit unit = new LvCompileUnit(code.getCode().toCharArray(), code.getFilePath(), code.getFileEncoding());
                            lstTmpUnits.add(unit);
                        }
                        LvCompileResult rsPrivate = cmpPrivate.compile(lstTmpUnits);
                        lstUnits.addAll(lstTmpUnits);
                        result.importResults(rsPrivate);
                    }
                }

                classLoader.close();
            } finally
            {
                _r_jar_res.unlock();
            }

            // 开始写入class文件，这个要加写锁了
            _w_jar_res.lock();
            try
            {
                // 删除编译结果、清理相关class文件
                Set<CJavaCode> setOldClasses = new HashSet();
                for (CJavaCode code : lstCode)
                {
                    _cmpCache.remove(code.getFullClassName());
                    setOldClasses.add(code);
                }

                for (Entry<String, CompilationResult> entry : result.getResults().entrySet())
                {
                    // 替换保存class 文件，自带删除老文件
                    String className = LvJavac.getMainClassFromFileName(entry.getKey());
                    CJavaCode code = getCode(className);
                    deleteClassFile(code);
                    LvJavac.saveClassFile(getDstPath(code), entry.getValue(), code.getUuid());
                    setOldClasses.remove(code);
                }

                // 只删除失效的（脏的），新编译出来的上一步会覆盖，不能删
                for (CJavaCode dirtyClass : setOldClasses)
                    deleteClassFile(dirtyClass);
            } finally
            {
                _w_jar_res.unlock();
            }

            Map<String, CompilationResult> rss = result.getResults();

            lock(_cmpResultLock);
            try
            {
                // 合并到老的编译结果中
                _cResult.addResults(rss.values());

                // 重新 统计错误、警告
                recalculateStastic();

                // 整合import关系网
                for (ICompilationUnit unit : lstUnits)
                {
                    String sclassName = LvJavac.getMainClassFromFileName(new String(unit.getFileName()));
                    Set<String> newImports = result.getImportCache().getImport(sclassName);
                    _cResult.getImportCache().saveImportRelation(sclassName, newImports);
                }

                // 持久化保存编译结果
                deleteCompileResultFile();
                saveCompileResult();
            } finally
            {
                _cmpResultLock.unlock();
            }

            EvtNotifySender.getInstance().fireNotification(AllSrvEvents.JAVA_CODE_COMPILE_FINISHED, getProject().getUuid());
            return result;
        } finally
        {
            _opLock.unlockCodes(lstCode);
        }
    }

    public void getAllAffectedClassFromResult(String srcClass, Set<String> affected)
    {
        lock(_cmpResultLock);
        try
        {
            _cResult.getImportCache().getAllAffectedClass(srcClass, affected);
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    public Map<String, CJavaCode> getAllAffectedCodeByName(Collection<String> classes)
    {
        Collection<CJavaCode> codes = new ArrayList<CJavaCode>();
        for (String className : classes)
        {
            CJavaCode code = getCode(className);
            if (code != null)
                codes.add(code);
        }

        return getAllAffectedCode(codes);
    }

    // 包含传进来的code
    public Map<String, CJavaCode> getAllAffectedCode(Collection<CJavaCode> lstCode)
    {
        Map<String, CJavaCode> mapRet = new TreeMap<String, CJavaCode>();
        for (CJavaCode code : lstCode)
        {
            mapRet.put(code.getFullClassName(), code);

            Set<String> setAff = new TreeSet<String>();
            getAllAffectedClassFromResult(code.getFullClassName(), setAff);
            setAff.add(LvJavac.getPackageFromFullClass(code.getFullClassName()) + ".*");
            for (String aff : setAff)
            {
                if (aff.endsWith(".*"))
                {
                    String sPkg = LvJavac.getPackageFromFullClass(aff);
                    List<CJavaCode> lstCodes = getChildCode(sPkg);
                    for (CJavaCode cc : lstCodes)
                        mapRet.put(cc.getFullClassName(), cc);
                } else
                {
                    CJavaCode affectCode = getCode(aff);
                    if (affectCode == null)
                    {
                        // 有可能是某个类的子类，那么尝试去掉后一节，也一并加入
                        String parentClass = LvJavac.getPackageFromFullClass(aff);
                        affectCode = getCode(aff);
                    }

                    if (affectCode != null)
                        mapRet.put(affectCode.getFullClassName(), affectCode);
                }
            }
        }
        return mapRet;
    }

    public CompileStastic getFolderStastic(String folderUuid)
    {
        lock(_cmpResultLock);
        try
        {
            return _folderStastic.get(folderUuid);
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    // 查某个目录下，某个包/类的编译统计，key : 类名或包名的完整名
    public CompileStastic getStastic(String folderUuid, String sKey)
    {
        lock(_cmpResultLock);
        try
        {
            Map<String, CompileStastic> map = _stastic.get(folderUuid);
            if (map == null)
                return null;

            return map.get(sKey);
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    public List<LvProblem> getProblems(String className)
    {
        lock(_cmpResultLock);
        try
        {
            return _cResult.getProblems(className);
        } finally
        {
            _cmpResultLock.unlock();
        }
    }

    public List<LvProblem> compileSingleCode(CJavaCode code, boolean useCache) throws Exception
    {
        List<LvProblem> lstRet = new ArrayList();
        LvCompileResult result = doCompileSingleCode(code, useCache);
        List<CategorizedProblem> lstProbs = result.getAllProblems();
        if (lstProbs != null)
            for (CategorizedProblem pb : lstProbs)
            {
                lstRet.add(new LvProblem(pb));
            }
        return lstRet;
    }

    public File[] getAllJarPaths() throws Exception
    {
        List<File> lstJars = getAllJarPaths(false);
        if (ToolUtilities.isObjectEmpty(lstJars))
            return new File[] {};

        return ToolUtilities.list2Array(lstJars, new File[lstJars.size()]);
    }

    // 会递归查找所有依赖工程的jar
    public File[] getAllJarPaths_IncludeDepend() throws Exception
    {
        List<File> lstJars = getAllJarPaths(true);
        if (ToolUtilities.isObjectEmpty(lstJars))
            return new File[] {};

        return ToolUtilities.list2Array(lstJars, new File[lstJars.size()]);
    }

    public CJavaPJBuilder prepareDependBuilder(String depRdn) throws Exception
    {
        CJavaPJBuilder depBuilder = CJavaCenter.getMe().getBuilder(depRdn);
        if (depBuilder == null)
        {
//            JavaProjectMo pjDep = (JavaProjectMo) getMo(depRdn);
//            if (pjDep == null)
//                throw new Exception(SrvRes.getString("Depended project doesn't exist")+" : "+ depRdn);
//            if (pjDep.isClosed())
//                throw new Exception(SrvRes.getString("Depended project was closed")+ " : " +pjDep.getName());
//            else
//                throw new Exception(SrvRes.getString("Please rebuild depended project first")+ " : " +pjDep.getName());
        }

        return depBuilder;
    }

    public List<File> getAllJarPaths(boolean includeDepend) throws Exception
    {
        List<File> lstFiles = new ArrayList();
        File folder = new File(getJarPath());
        if (folder.exists())
        {
            lstFiles.addAll(ToolUtilities.array2List(folder.listFiles()));
        }

        if (includeDepend)
        {
            List<String> lstDepends = CJavaCenter.getMe().getDependProjects(getProject());
            if (!ToolUtilities.isObjectEmpty(lstDepends))
            {
                for (String depRdn : lstDepends)
                {
                    if (ToolUtilities.isStringEqual(getProject().getUuid(), depRdn))
                        continue;
                    CJavaPJBuilder depBuilder = prepareDependBuilder(depRdn);
                    lstFiles.addAll(depBuilder.getAllJarPaths(false));
                }
            }
        }

        return lstFiles;
    }

    // isDependLocalTempClassFile : 是否联合本地临时class文件编译，仅用于部分编译
    // limitPrivateFolder ： 传入null表示不区分公私，传入字符串表示过滤一部分私有，公有都要，传入一个乱七八糟字符表示只要公不要私
    public void prepareDstPath(LvClassLoader cloader, boolean isDependLocalTempClassFile, String... limitPrivateFolder) throws Exception
    {
        List<File> lstPaths = prepareDstPath(isDependLocalTempClassFile, limitPrivateFolder);
        for (File f : lstPaths)
            cloader.addFilePath(f.getAbsolutePath());
    }

    // limitPrivateFolder : 传入需要哪些私有目录，如果传入null，则所有目录都要，如果不为null，则按此过滤
    // 公共目录全返回
    public List<File> prepareDstPath(boolean isDependLocalTempClassFile, String... limitPrivateFolder) throws Exception
    {
        List<File> lstRet = new ArrayList();

        // 编译部分代码时，需要加载已经存在的class文件
        if (isDependLocalTempClassFile)
        {
            lstRet.add(new File(getDstDependPath() + "/"));

            // 按目录私有与否，结合过滤器，返回
            Map<String, CJavaFolder> allFolder = getAllFolderMap();
            for (CJavaFolder fd : allFolder.values())
            {
                if (!CmnUtil.isObjectEmpty(limitPrivateFolder) && fd.isPrivateOwn())
                {
                    if (!ToolBasic.contains(limitPrivateFolder, fd.getUuid()))
                        continue;
                }

                lstRet.add(new File(getDstPath(fd.getUuid())));
            }
        }

        // 处理依赖工程的
        List<String> lstDepends = CJavaCenter.getMe().getDependProjects(getProject());
        if (ToolUtilities.isObjectEmpty(lstDepends))
            return lstRet;

        for (String depRdn : lstDepends)
        {
            if (ToolUtilities.isStringEqual(getProject().getUuid(), depRdn))
                continue;
            CJavaPJBuilder depBuilder = prepareDependBuilder(depRdn);

            lstRet.add(new File(depBuilder.getDstDependPath() + "/"));
        }

        return lstRet;
    }

    public void collectClassInfo_FromJar(Map<String, Object> setKey, String sPreFix, boolean includeJDK, boolean includeDsp, boolean includeDependProject) throws Exception
    {
        try
        {
            List<ClassNameInfo> lstClasses = ClassSearchEngine.getInstance().searchClass(sPreFix, includeJDK, includeDsp, _jarClassInfoLoader);
            for (Iterator<ClassNameInfo> it = lstClasses.iterator(); it.hasNext();)
            {
                ClassNameInfo className = it.next();
                if (LvJavac.isVisibleClass(className))
                    setKey.put(className.classFullName, className);
            }
        } catch (Throwable err)
        {
            err.printStackTrace();
        }

        // 处理依赖工程的
        if (includeDependProject)
        {
            List<String> lstDepends = CJavaCenter.getMe().getDependProjects(getProject());
            if (!ToolUtilities.isObjectEmpty(lstDepends))
            {
                for (String depRdn : lstDepends)
                {
                    if (depRdn.equals(getProject().getUuid()))
                        continue;

                    CJavaPJBuilder depBuilder = prepareDependBuilder(depRdn);

                    depBuilder.collectClassInfo_FromJar(setKey, sPreFix, false, false, false);
                }
            }
        }
    }

    public void collectClassInfo_FromDao(Map<String, Object> setKey, String sPreFix) throws Exception
    {
        ClassInheritNode rootNode = CDaoClient.getMe().getInheritTreeRoot();
        rootNode.searchClass(setKey, sPreFix);
    }

    public void collectClassInfo_InPlugin(Map<String, Object> setKey, String sPreFix)
    {
        BasiceClassInfoLoader infoLoader = ClassFactory.getPluginClassInfoLoader();
        if (infoLoader == null)
            return;

        List<ClassNameInfo> lstInfo = infoLoader.searchClass(sPreFix);
        if (lstInfo != null)
            for (ClassNameInfo info : lstInfo)
                setKey.put(info.getClassFullName(), info);
    }

    public void collectClassInfo_FromCode(Map<String, Object> setKey, String sPreFix, boolean includeDependProject) throws Exception
    {
        lock(_codeLock);
        try
        {
            String sPreFixLower = sPreFix.toLowerCase();
            for (Entry<String, CJavaCode> entry : _cache.entrySet())
            {
                String fullClass = entry.getKey();
                CJavaCode jcode = entry.getValue();

                if (jcode.getMainClass().toLowerCase().startsWith(sPreFixLower) && LvJavac.isVisibleClass(jcode.getMainClass()))
                    setKey.put(jcode.getFullClassName(), new ClassNameInfo(jcode.getMainClass(), jcode.getFullClassName(), jcode.getFilePath()));
            }
        } finally
        {
            _codeLock.unlock();
        }

        // 处理依赖工程的
        if (includeDependProject)
        {
            List<String> lstDepends = CJavaCenter.getMe().getDependProjects(getProject());
            if (!ToolUtilities.isObjectEmpty(lstDepends))
            {
                for (String depRdn : lstDepends)
                {
                    if (depRdn.equals(getProject().getUuid()))
                        continue;

                    CJavaPJBuilder depBuilder = prepareDependBuilder(depRdn);

                    depBuilder.collectClassInfo_FromCode(setKey, sPreFix, false);
                }
            }
        }

    }

    public LvCompileResult doCompileSingleCode(CJavaCode code, boolean useCache) throws Exception
    {
        _opLock.assertNotRebuildAll();

        if (useCache)
        {
            LvCompileResult cached = _cmpCache.get(code.getFullClassName());
            if (cached != null)
                return cached;
        }

        _r_jar_res.lock();
        try
        {
            LvJavac tmpCompiler = new LvJavac();
            tmpCompiler.optIsGenerateClass = false;

            // 添加class路径、依赖工程的jar包及代码、自身jar包等
            boolean isPrivate = isFolderPrivate(code.getFolder());
            LvClassLoader tmpLoader = prepareRunnableClassLoader(isPrivate ? code.getFolder() : null);

            List<ICompilationUnit> lst = new ArrayList<ICompilationUnit>();
            ICompilationUnit unit = new LvCompileUnit(code.getCode().toCharArray(), code.getFilePath(), code.getFileEncoding());
            lst.add(unit);

            tmpCompiler.setClassLoader(tmpLoader);
            LvCompileResult result = tmpCompiler.compile(false, lst);
            tmpLoader.close();

            if (useCache)
                _cmpCache.add(code.getFullClassName(), result);

            return result;
        } finally
        {
            _r_jar_res.unlock();
        }
    }

    public LvCompileResult compileExtendCode(CJavaCode code) throws Exception
    {
        _opLock.assertNotRebuildAll();

        _r_jar_res.lock();
        try
        {
            LvJavac tmpCompiler = new LvJavac();
            tmpCompiler.optIsGenerateClass = false;

            // 添加class路径、依赖工程的jar包及代码、自身jar包等
            LvClassLoader tmpLoader = prepareRunnableClassLoader(code.getFolder());

            List<ICompilationUnit> lst = new ArrayList<ICompilationUnit>();
            ICompilationUnit unit = new LvCompileUnit(code.getCode().toCharArray(), code.getFilePath(), code.getFileEncoding());
            lst.add(unit);

            tmpCompiler.setClassLoader(tmpLoader);
            LvCompileResult result = tmpCompiler.compile(false, lst);
            tmpLoader.close();

            return result;
        } finally
        {
            _r_jar_res.unlock();
        }
    }

    public LvClassLoader prepareRunnableClassLoader(String... limitPrivateFolders) throws Exception
    {
        // 添加class路径
        LvClassLoader tmpLoader = newClassLoader();
        prepareDstPath(tmpLoader, true, limitPrivateFolders);

        // 添加jar路径
        File[] jars = getAllJarPaths_IncludeDepend();
        if (jars != null)
            for (File jar : jars)
                tmpLoader.addFilePath(jar.getAbsolutePath());

        return tmpLoader;
    }

    public List<CodeDeclareInfo> querySyntaxTree(CJavaCode code) throws Exception
    {
        LvCompileResult rs = doCompileSingleCode(code, true);
        if (rs == null)
            return null;

        return rs.getLvJavac().getSyntaxTree(false);
    }

    // 单独增量式编译一个代码，并加载类，返回其主类
    public Pair<Class, LvCompileResult> compileAndLoadClass(CJavaCode code) throws Exception
    {
        LvCompileResult rs = doCompileSingleCode(code, true);
        if (rs == null)
            return null;

        try (LvClassLoader loader = prepareRunnableClassLoader())
        {
            for (ClassFile clsFile : rs.getOneResult().getClassFiles())
            {
                loader.addClassByte(LvJavac.compoundChar2String(clsFile.getCompoundName(), "."), LvJavac.saveClassFile(clsFile, code.getUuid()));
            }

            return new Pair<>(loader.loadClass(code.getFullClassName()), rs);
        }
    }

    public LvClassLoader newClassLoader()
    {
        // 开发工程时，是不能加载插件的，因为插件中很可能存在本工程已经发布的插件包，会导致很多奇奇怪怪的问题
        if (getProject().isDependPlugin() || getProject().isUdfLib())
            return ClassFactory.newValidClassLoader(); // 避开灰度发布的内容，以免冲突
        else if (getProject().isDependPlatform())
            return new LvClassLoader(ClassFactory.getBasicClassLoader());
        else
            return new LvClassLoader(CodeUtil.getJDKClassLoader());
    }

    public List<ClassNameInfoExt> searchCode(String sKey, boolean searchInJar, int countLimit)
    {
        // 从代码中获取类列表
        lock(_codeLock);
        try
        {
            // 搜源码
            String sPreFixLower = sKey.toLowerCase();
            String sReg = ToolUtilities.convertString2Regular(sKey, true);
            List<ClassNameInfoExt> lstRet = new ArrayList<ClassNameInfoExt>();
            for (Entry<String, CJavaCode> entry : _cache.entrySet())
            {
                if (countLimit > 0 && lstRet.size() > countLimit)
                    break;

                CJavaCode jcode = entry.getValue();

                boolean match = false;
                String sFullClass = jcode.getFullClassName().toLowerCase();
                if (sFullClass.startsWith(sPreFixLower))
                    match = true;
                else if (sReg != null && sFullClass.matches(sReg))
                    match = true;

                if (!match)
                {
                    String sMainClass = jcode.getMainClass().toLowerCase();
                    if (sMainClass.startsWith(sPreFixLower))
                        match = true;
                    else if (sReg != null && sMainClass.matches(sReg))
                        match = true;
                }

                if (match)
                {
                    ClassNameInfoExt info = new ClassNameInfoExt(jcode.getMainClass(), jcode.getFullClassName(), jcode.getFilePath(), getProject().getName());
                    info.setCodeRDN(jcode.getUuid());
                    lstRet.add(0, info);
                }
            }

            // 搜jar包
            if (searchInJar)
            {
                List<ClassNameInfo> lstClasses = ClassSearchEngine.getInstance().searchClass(sPreFixLower, true, getProject().isDependPlatform(), _jarClassInfoLoader);
                for (Iterator<ClassNameInfo> it = lstClasses.iterator(); it.hasNext();)
                {
                    ClassNameInfo className = it.next();
                    lstRet.add(ClassNameInfoExt.convert(className, getProject().getName()));
                }
            }

            return lstRet;
        } finally
        {
            _codeLock.unlock();
        }
    }

    public CodeDeclareInfo searchDeclaration(CJavaCode code, String selString, int currPos) throws Exception
    {
        LvCompileResult result = doCompileSingleCode(code, false);

        Pair<Object, Binding> pair = result.getLvJavac().getSyntaxBinding(currPos);
        if (pair == null)
            return null;

        CodeDeclareInfo info = LvJavac.convertBinding2LocateInfo(pair.right);
        return info;
    }

    public CodeDeclareInfo getSyntaxBindingType(CJavaCode code, int currPos) throws Exception
    {
        LvCompileResult result = doCompileSingleCode(code, false);

        Pair<Object, Binding> pair = result.getLvJavac().getSyntaxBinding(currPos);
        if (pair == null || !(pair.right instanceof Binding))
            return null;

        return CodeDeclareInfo.convert(pair.right);
    }

    public CodeDeclareInfo getSyntaxMeaning(CJavaCode code, int currPos) throws Exception
    {
        LvCompileResult result = doCompileSingleCode(code, false);

        Pair<Object, Binding> pair = result.getLvJavac().getSyntaxBinding(currPos);
        if (pair == null || !(pair.left instanceof ASTNode))
            return null;

        return LvJavac.convertAstNode2LocateInfo((ASTNode) pair.left);
    }

    public SrvProgressIntf<List<CodeDeclareInfo>> searchSyntaxReference(CJavaCode code, String selString, int currPos) throws Exception
    {
        LvCompileResult result = doCompileSingleCode(code, true);

        Pair<Object, Binding> pair = result.getLvJavac().getSyntaxBinding(currPos);
        if (pair == null)
            return null;

        IntRange range = null;
        if (pair.right instanceof LocalVariableBinding)
        {
            AbstractMethodDeclaration dec = result.getLvJavac().getMethodAt(currPos);
            if (dec != null)
                range = new IntRange(dec.declarationSourceStart, dec.declarationSourceEnd);
        }
        return searchSyntaxReference(code, pair.right, range);
    }

    public String generateMethodCode(String classN, String funcName, List<Pair<String, String>> lstParam) throws Exception
    {

        LvClassLoader classLoader = newClassLoader();
        prepareDstPath(classLoader, true, "NO PRIVATE");
        Class clazz = classLoader.loadClass(classN);

        // 筹备参数类型，寻找函数
        Class[] paramClss = null;
        if (!ToolUtilities.isObjectEmpty(lstParam))
        {
            paramClss = new Class[lstParam.size()];
            for (int i = 0; i < lstParam.size(); i++)
            {
                try
                {
                    String dType = lstParam.get(i).left;
                    if (ToolUtilities.isSimpleDataType(dType))
                        paramClss[i] = ToolUtilities.simpleDataType2Class(dType);
                    else
                        paramClss[i] = ToolUtilities.getClassLoader().loadClass(lstParam.get(i).left);
                } catch (Throwable err)
                {
                    paramClss[i] = Object.class;
                }
            }
        }

        Method method = null;
        try
        {
            method = clazz.getDeclaredMethod(funcName, paramClss);
        } catch (Throwable err)
        {

        }
        if (method == null)
        {
            ValuePair<Method, Class[]> res = ToolUtilities.getBestMethod_ByClass(clazz, funcName, paramClss);
            if (res != null)
                method = res.left;
        }

        if (method == null)
            return null;

        String code = "\n" + LvJavac.method2Code(method, lstParam) + "\n{";
        if (method.getReturnType() != null && !method.getReturnType().getName().equals("void"))
            code += "\n    return null;";
        code += "\n}";

        return code;
    }

    // 按照给定的前缀搜索类，主要用于代码自动带出类名
    public Map<String, Object> searchClass(CJavaCode code, String sPreFix, int iCurrentPos) throws Exception
    {
        Map<String, Object> setKey = new TreeMap();
        for (String keyW : JavacCompiler.JAVA_KEYWORDS)
            setKey.put(keyW, keyW);

        // Get All Class from JDK and DSP
        boolean includePlatform = getProject().isDependPlatform() || getProject().isDependPlugin() || getProject().isUdfLib();
        collectClassInfo_FromJar(setKey, sPreFix, true, includePlatform, true);

        // 从CDao中获取
        collectClassInfo_FromDao(setKey, sPreFix);

        // 从代码中获取类列表
        if (!getProject().isUdfLib())
            collectClassInfo_FromCode(setKey, sPreFix, true);

        // 从插件中搜索匹配类信息
        if (getProject().isDependPlugin() || getProject().isUdfLib())
            collectClassInfo_InPlugin(setKey, sPreFix);

        // 准备编译
        LvJavac tmpCompiler = new LvJavac(Default_Assistent_JDK);
        List<LvProblem> lstRet = new ArrayList();
        tmpCompiler.optIsGenerateClass = false;

        // 添加class路径
        LvClassLoader tmpLoader = newClassLoader();
        prepareDstPath(tmpLoader, true);

        // 添加jar路径
        File[] jars = getAllJarPaths_IncludeDepend();
        if (jars != null)
            for (File jar : jars)
                tmpLoader.addFilePath(jar.getAbsolutePath());

        List<ICompilationUnit> lstUnits = new ArrayList<ICompilationUnit>();
        ICompilationUnit unit = new LvCompileUnit(code.getCode().toCharArray(), code.getFilePath(), code.getFileEncoding());
        lstUnits.add(unit);

        tmpCompiler.setClassLoader(tmpLoader);
        LvCompileResult result = tmpCompiler.compile(lstUnits);
        tmpLoader.close();

        List lstStack = new ArrayList();
        if (!tmpCompiler.analyseSyntaxTree(iCurrentPos, lstStack))
            return setKey;

        for (Object obj : lstStack)
        {
            if (obj instanceof TypeDeclaration)
            {
                // 解析类本身
                String typeClass = new String(((TypeDeclaration) obj).getCompilationUnitDeclaration().getMainTypeName());
                if (typeClass.toLowerCase().startsWith(sPreFix.toLowerCase()))
                {
                    String filePath = new String(((TypeDeclaration) obj).compilationResult().getFileName());
                    String fullClass = LvJavac.getFullClassName(LvJavac.convertPackageName(((TypeDeclaration) obj).compilationResult().packageName), typeClass);
                    setKey.put(typeClass, new ClassNameInfo(typeClass, fullClass, filePath));
                }

                // 先拿其父类的所有成员
                List lstSuperMembers = new ArrayList();
                LvJavac.getMemberOf(lstSuperMembers, ((TypeDeclaration) obj).superclass, false, true);
                for (Object superMem : lstSuperMembers)
                {
                    if (superMem instanceof FieldBinding)
                        setKey.put(LvJavac.getMemberReadableName(superMem), new CodeDeclareInfo(LvJavac.getMemberReadableName(superMem), LvJavac.getMemberCode(superMem), CodeDeclareInfo.FIELD));
                    else if (superMem instanceof MethodBinding)
                        setKey.put(LvJavac.getMemberReadableName(superMem), new CodeDeclareInfo(LvJavac.getMemberReadableName(superMem), LvJavac.getMemberCode(superMem), CodeDeclareInfo.METHOD));
                }

                FieldDeclaration[] fields = ((TypeDeclaration) obj).fields;
                if (fields != null)
                    for (FieldDeclaration field : fields)
                    {
                        if (field.name == null)
                            continue;

                        CodeDeclareInfo info = new CodeDeclareInfo(LvJavac.getMemberReadableName(field), LvJavac.getMemberCode(field), CodeDeclareInfo.FIELD);
                        setKey.put(info.getName(), info);
                    }

                AbstractMethodDeclaration[] meths = ((TypeDeclaration) obj).methods;
                if (meths != null)
                    for (AbstractMethodDeclaration meth : meths)
                    {
                        CodeDeclareInfo info = new CodeDeclareInfo(LvJavac.getMemberReadableName(meth), LvJavac.getMemberCode(meth), CodeDeclareInfo.METHOD);
                        setKey.put(info.getName(), info);
                    }
            } else if (obj instanceof AbstractMethodDeclaration)
            {
                AbstractMethodDeclaration currMeth = (AbstractMethodDeclaration) obj;
                CodeDeclareInfo info = new CodeDeclareInfo(LvJavac.getMemberReadableName(currMeth), LvJavac.getMemberCode(currMeth), CodeDeclareInfo.METHOD);
                setKey.put(info.getName(), info);

                Argument[] args = currMeth.arguments;
                if (args != null)
                    for (Argument arg : args)
                    {
                        CodeDeclareInfo infoA = new CodeDeclareInfo(LvJavac.getMemberReadableName(arg), LvJavac.getMemberCode(arg), CodeDeclareInfo.ARGUMENT);
                        setKey.put(infoA.getName(), infoA);
                    }

                Statement[] stats = currMeth.statements;
                if (stats != null)
                    for (Statement st : stats)
                    {
                        // 当前正在写的变量（未完成可能是编译不过的missing要素，需要去掉）
                        if (st instanceof AbstractVariableDeclaration)
                        {
                            if (((AbstractVariableDeclaration) st).type.resolvedType instanceof ProblemReferenceBinding)
                                continue;

                            CodeDeclareInfo infoV = new CodeDeclareInfo(LvJavac.getMemberReadableName(st), LvJavac.getMemberCode(st), CodeDeclareInfo.VARIALBE);
                            setKey.put(infoV.getName(), infoV);
                        }
                    }
            } else if (obj instanceof Block)
            {
                Block block = (Block) obj;
                Statement[] stats = block.statements;
                if (stats != null)
                    for (Statement st : stats)
                    {
                        if (st instanceof AbstractVariableDeclaration)
                        {
                            if (((AbstractVariableDeclaration) st).type.resolvedType instanceof ProblemReferenceBinding)
                                continue;

                            CodeDeclareInfo infoV = new CodeDeclareInfo(LvJavac.getMemberReadableName(st), LvJavac.getMemberCode(st), CodeDeclareInfo.VARIALBE);
                            setKey.put(infoV.getName(), infoV);
                        }
                    }
            }
        }

        return setKey;
    }

    // 因为坑爹的lambda表达式会导致后续代码语法解析失败，完全解不出后面的语法帮助
    public static final String Default_Assistent_JDK = "1.8";

    public static interface MemberMatcher
    {
        public boolean accept(Object memberObj);
    }

    public Map<String, Object> searchMethodField(CJavaCode code, String sTotalPreword, int iCurrentPos) throws Exception
    {
        return searchMethodField(code, sTotalPreword, iCurrentPos, null);
    }

    public Map<String, Object> searchMethodField(CJavaCode code, String sTotalPreword, int iCurrentPos, MemberMatcher matcher) throws Exception
    {
        int iPos = iCurrentPos - 1;
        Map<String, Object> keySet = new TreeMap<String, Object>();

        boolean blConstrcutor = false;
        if (sTotalPreword.startsWith("new "))
            blConstrcutor = true;

        Map mapLocalVars = new TreeMap();

        // Try runtime syntax
        boolean blVar = false; // True : this is an object. False : This is a

        // 准备编译
        // 两段测试代码，测试变量类型以及类名类型
        String tmpCode = "\n{\nObject tmpVar_" + ToolUtilities.allockUUIDWithUnderline() + "=" + sTotalPreword + ";\n";
        String tmpCode2 = "\nClass tmpVar_" + ToolUtilities.allockUUIDWithUnderline() + "=" + sTotalPreword + ".class;\n";
        int iTmpCodePos = 0;
        int iTmpCodePos2 = 0;

        // 再整两段测试代码，测试前一前缀的类型以及类名类型，如：
        // ToolUtilities.allock，片段需要侦测的是ToolUtilities而不是allock
        String sPrePreWord = LvJavac.getPrevPrevWord(sTotalPreword.toCharArray(), sTotalPreword.length() - 1, false, false);
        String tmpCode3 = "";
        String tmpCode4 = "}\n";
        if (!ToolUtilities.isStringEmpty(sPrePreWord))
        {
            tmpCode3 = "\nObject tmpVar_" + ToolUtilities.allockUUIDWithUnderline() + "=" + sPrePreWord + ";\n";
            tmpCode4 = "\nClass tmpVar_" + ToolUtilities.allockUUIDWithUnderline() + "=" + sPrePreWord + ".class;}\n}";
        }
        int iTmpCodePos3 = 0;
        int iTmpCodePos4 = 0;

        LvJavac tmpCompiler = new LvJavac(Default_Assistent_JDK);
        LvCompileResult result = null;
        LvClassLoader tmpLoader = newClassLoader();
        try
        {
            List<LvProblem> lstRet = new ArrayList();
            tmpCompiler.optIsGenerateClass = false;

            // 添加class路径
            prepareDstPath(tmpLoader, true);

            // 添加jar路径
            File[] jars = getAllJarPaths_IncludeDepend();
            if (jars != null)
                for (File jar : jars)
                    tmpLoader.addFilePath(jar.getAbsolutePath());

            List<ICompilationUnit> lst = new ArrayList<ICompilationUnit>();
            // 在当前pos补一个分号，以避免后续代码干扰当前
            String sCode = code.getCode();
            // 直接取到上一条语句的末尾
            int iInsertPos = LvJavac.getSyntaxStart(sCode, iCurrentPos - 1);
            int iInsertLineEnd = sCode.indexOf("\n", iCurrentPos);
            String sFront = sCode.substring(0, iInsertPos);
            // 去掉结尾的.
            if (sFront.endsWith("."))
            {
                sFront = sFront.substring(0, sFront.length() - 1);
                iPos--; // 由于去掉了末尾的. 则pos也需要前移一位
            }

            // String sTail = sCode.substring(iCurrentPos, sCode.length());
            // iTmpCodePos = iCurrentPos;
            String sTail = tmpCode + tmpCode2 + tmpCode3 + tmpCode4 + sCode.substring(iInsertLineEnd, sCode.length());
            iTmpCodePos = iInsertPos + tmpCode.length() - 1;
            iTmpCodePos2 = iTmpCodePos + tmpCode2.length();
            iTmpCodePos3 = iTmpCodePos2 + tmpCode3.length();
            iTmpCodePos4 = iTmpCodePos3 + tmpCode4.length();
            iCurrentPos = iInsertPos + tmpCode.length() + tmpCode2.length() + tmpCode3.length() + tmpCode4.length() + 1;

            LvCompileUnit unit = new LvCompileUnit((sFront + "\n" + sTail).toCharArray(), code.getFilePath(), code.getFileEncoding());
            lst.add(unit);

            tmpCompiler.setClassLoader(tmpLoader);
            result = tmpCompiler.compile(false, lst);

//            Object forTest  = tmpCompiler.getParser().compilationUnit;  // for test
            Object currObj = null;
            boolean isClass = false;
            // 先看测试代码（变量的），如果不是一个可用变量，再试是不是一个类
            currObj = tmpCompiler.getValidTypeOfTestCode(iTmpCodePos, false);
            if (currObj == null)
            {
                currObj = tmpCompiler.getValidTypeOfTestCode(iTmpCodePos2, true);
                if (currObj != null)
                    isClass = true;
            }

            // 上一轮没侦测到，就该试试前一个关键字前缀的侦测了
            if (!ToolUtilities.isStringEmpty(sPrePreWord) && !LvJavac.isValidBinding(currObj))
            {
                currObj = tmpCompiler.getValidTypeOfTestCode(iTmpCodePos3, false);
                if (currObj == null)
                {
                    currObj = tmpCompiler.getValidTypeOfTestCode(iTmpCodePos4, true);
                    if (currObj != null)
                        isClass = true;
                }
            }

            // 传统通过解析语法树获取类型，极其不靠谱
            // if (currObj == null)
            // {
            // currObj = tmpCompiler.findMatchestClassByName(sTotalPreword,
            // lstStack, iPos, null);
            // if (currObj == null)
            // currObj = tmpCompiler.getSyntaxClassAt(lstStack, iPos);
            // }

            // super关键字有点不一样，没办法通过测试代码检测出来
            // 处理也不难，只要拿到当前type，取到其父class即可
            if (ToolUtilities.isStringEqual(sTotalPreword, "super"))
            {
                // 沿着当前路径往上追溯，最近的一个TypeDeclaration应该就是了
                TypeDeclaration currType = null;
                List stack = new ArrayList();
                tmpCompiler.analyseSyntaxTree(iInsertPos, stack);
                for (int i = stack.size() - 1; i >= 0; i--)
                {
                    Object o = stack.get(i);
                    if (o instanceof TypeDeclaration)
                    {
                        currType = (TypeDeclaration) o;
                        break;
                    }
                }
                if (currType != null)
                {
                    isClass = false;
                    currObj = currType.superclass;
                }
            }

            Class clazz = null;
            if (currObj != null)
            {
                if (currObj instanceof Class)
                {
                    Class clzz = (Class) currObj;
                    currObj = tmpCompiler._compiler.lookupEnvironment.getType(LvJavac.string2CompoundChar(clzz.getName(), "."));
                }

                List lstMems = new ArrayList();
                LvJavac.getMemberOf(lstMems, currObj, isClass, true);
                for (Object member : lstMems)
                {
                    if (matcher != null && !matcher.accept(member))
                        continue;

                    try
                    {
                        CodeDeclareInfo info = CodeDeclareInfo.convert(currObj, member);
                        if (info != null)
                            keySet.put(info.getCodeText(), info);
                    } catch (Throwable err)
                    {
                        ToolUtilities.error(LOG, err);
                    }
                }

                return keySet;
            }

            // if (clazz == null)
            // clazz = Object.class;
            //
            // if (blConstrcutor)
            // {
            // // 构造函数
            // Constructor[] constructs = clazz.getConstructors();
            // for (Constructor cons : constructs)
            // {
            // String s = LvJavac.getConstructorDesc(cons, true, true);
            // keySet.put(s, cons);
            // }
            // } else
            // {
            // // 静态函数
            // Method[] methods = clazz.getMethods();
            // if (methods != null)
            // {
            // for (int i = 0; i < methods.length; ++i)
            // {
            // boolean blStatic = Modifier.isStatic(methods[i].getModifiers());
            //
            // if ((blVar && !blStatic) || (!blVar && blStatic))
            // {
            // CodeDeclareInfo decInfo = CodeDeclareInfo.convert(methods[i]);
            // String s = LvJavac.getMemberReadableName(methods[i]);
            // keySet.put(decInfo.getName(), decInfo);
            // }
            // }
            // }
            //
            // // Add length function for "Array"
            // if (clazz.isArray())
            // {
            // keySet.put("length", "length");
            // }
            //
            // // Add member fields
            // Field[] field = clazz.getDeclaredFields();
            // if (field != null)
            // {
            // for (int i = 0; i < field.length; ++i)
            // {
            // CodeDeclareInfo decInfo = CodeDeclareInfo.convert(field[i]);
            // keySet.put(decInfo.getName(), decInfo);
            // }
            // }
            // }

            return keySet;
        } finally
        {
            tmpLoader.close();
        }
    }

    // 按照给定源码目录（UUID）导出工程源码，如果是别人的专属代码则忽略
    public void exportSourceFiles(String dir, Set<String> srcFolderNames) throws Exception
    {
        Map<String, CJavaFolder> folders = getAllFolderMap();
        for (CJavaFolder fd : folders.values())
        {
            if (srcFolderNames.contains(fd.getName()))
            {
                // 即使是空目录也要创建出来
                ToolUtilities.createFolder(dir + "/" + CJavaConst.PATH_EXPORT_Src + "/" + fd.getName());

                // 源码目录范围内的，输出源码+去除jar包
                try (CDao dao = newDao())
                {
                    List<CJavaCodeDo> lstCode = dao.queryDoList(CJavaCodeDo.class, Cnd.where(CJavaCodeDo.Owner, "=", fd.getUuid()));
                    for (CJavaCodeDo code : lstCode)
                    {
                        String codePath = LvJavac.getClassFilePath(code.getFullClassName());
                        ToolUtilities.saveFile(dir + "/" + CJavaConst.PATH_EXPORT_Src + "/" + fd.getName() + "/" + codePath, code.getCode(), "UTF-8", false);
                    }

                    List<CResFileDo> lstRes = dao.queryDoList(CResFileDo.class, Cnd.where(CJavaCodeDo.Owner, "=", fd.getUuid()));
                    if (lstRes != null)
                        for (CResFileDo res : lstRes)
                        {
                            ToolUtilities.saveFile(dir + "/" + CJavaConst.PATH_EXPORT_Src + "/" + fd.getName() + "/" + res.getPhysicalPath(), res.getFileBin(), false);
                        }
                }

                // 这一步是删除lib目录中，该文件夹对应的jar包，以名字匹配
                ToolUtilities.deleteFileIfExist(new File(dir + "/" + CJavaConst.PATH_EXPORT_Plugin + "/" + CJavaUtil.toJarFileName(getProject().getName(), fd.getName())));
            } else
            {
                // 指定目录以外的，统统不输出，协作依靠发布插件，只有唯一的共享方式就是发布到插件
                // 脱离插件，直接将源码输出成jar包会导致和插件冲突，且没有实际意义，因为整个系统联调都只会认插件，而不会使用工程内未发布的源码

                // 给定目录以外的，输出jar包，私有目录连jar包都不给
//                if (fd.isPrivateOwn())
//                    continue;
//                
//                byte[] bt = exportOneJar(getDstPath(fd.getUuid()));
//                ToolUtilities.saveFile(dir+"/"+CJavaConst.PATH_EXPORT_Plugin+"/"+CJavaUtil.toJarFileName(getProject().getName(), fd.getName()), bt, false);
            }
        }
    }

    public void exportSourceFiles(String dir) throws Exception
    {
        Map<String, CJavaFolder> folders = getAllFolderMap();
        for (CJavaFolder fd : folders.values())
        {
            // 即使是空目录也要创建出来
            ToolUtilities.createFolder(dir + "/" + CJavaConst.PATH_EXPORT_Src + "/" + fd.getName());

            // 源码目录范围内的，输出源码+去除jar包
            try (CDao dao = newDao())
            {
                List<CJavaCodeDo> lstCode = dao.queryDoList(CJavaCodeDo.class, Cnd.where(CJavaCodeDo.Owner, "=", fd.getUuid()));
                for (CJavaCodeDo code : lstCode)
                {
                    String codePath = LvJavac.getClassFilePath(code.getFullClassName());
                    ToolUtilities.saveFile(dir + "/" + CJavaConst.PATH_EXPORT_Src + "/" + fd.getName() + "/" + codePath, code.getCode(), "UTF-8", false);
                }

                List<CResFileDo> lstRes = dao.queryDoList(CResFileDo.class, Cnd.where(CJavaCodeDo.Owner, "=", fd.getUuid()));
                if (lstRes != null)
                    for (CResFileDo res : lstRes)
                    {
                        ToolUtilities.saveFile(dir + "/" + CJavaConst.PATH_EXPORT_Src + "/" + fd.getName() + "/" + res.getPhysicalPath(), res.getFileBin(), false);
                    }
            }
        }
    }

    // 打包给插件，生成CPluginJarDto对象
    public List<CPluginJarDto> exportJar(boolean includeDepend, boolean ignoreError) throws CodeCompileException, Exception
    {
        LvCompileSingleResult cmpResult =  rebuildAll();
        if (!ignoreError)
        {
            Map<String, List<LvProblem>> mapError = cmpResult.getErrors();
            if (!mapError.isEmpty())
                throw new CodeCompileException("Compilation Error : \n" + LvCompileSingleResult.problemTreeToString(mapError));
        }

        List<CPluginJarDto> lstRet = new LinkedList<CPluginJarDto>();
        Map<String, CJavaFolder> folders = getAllFolderMap();
        for (CJavaFolder fd : folders.values())
        {
            byte[] bt = exportOneJar(fd);
            CPluginJarDto jar = new CPluginJarDto();
            jar.setName(CJavaUtil.toJarFileName(getProject().getName(), fd.getName()));
            jar.setFileBin(bt);
            jar.setPrivateOwn(fd.isPrivateOwn());

            lstRet.add(jar);
        }

        if (includeDepend)
        {
            byte[] btDep = exportOneJar(getDstDependPath(), null);
            if (!CmnUtil.isObjectEmpty(btDep))
            {
                CPluginJarDto jar = new CPluginJarDto();
                jar.setName(getProject().getName() + "__" + DependPath + ".jar");
                jar.setFileBin(btDep);
                lstRet.add(jar);
            }
        }

        return lstRet;
    }
    
    public Set<String> getExportJars(boolean includeDepend) throws Exception
    {
        Set<String> setRet = new HashSet<String>();
        
        Map<String, CJavaFolder> folders = getAllFolderMap();
        for (CJavaFolder fd : folders.values())
        {
            setRet.add(CJavaUtil.toJarFileName(getProject().getName(), fd.getName()));
        }
        
        if (includeDepend)
        {
            setRet.add(getProject().getName() + "__" + DependPath + ".jar");
        }

        return setRet;
    }

    public byte[] exportOneJar(CJavaFolder folder) throws Exception
    {
        String folderPath = getDstPath(folder.getUuid());

        List<Pair<JarEntry, byte[]>> addEntry = new LinkedList();
        if (!folder.isPrivateOwn())
        {
            // 附带源码
            for (CJavaCode code : getAllCode())
            {
                if (!CmnUtil.isStringEqual(folder.getUuid(), code.getOwner()))
                    continue;

                String srcPath = LvJavac.getClassFilePath(code.getFullClassName());

                addEntry.add(new Pair(new JarEntry(srcPath), code.getCode().getBytes()));
            }
        }

        return exportOneJar(folderPath, addEntry);
    }

    // addEntry : 额外需要写入Jar的内容（如源码）
    public byte[] exportOneJar(String folderPath, List<Pair<JarEntry, byte[]>> addEntry) throws Exception
    {
        List<String> allClassFiles = ToolUtilities.getAllChildFile(new File(folderPath));
        if (allClassFiles == null)
            return null;

        String absDstPath = new File(folderPath).getCanonicalPath();

        File newTmp = new File("temp/exportjar_" + ToolUtilities.allockUUID() + ".jar");
        ToolUtilities.createFile(newTmp.getAbsolutePath(), "");
        try (FileOutputStream flOut = new FileOutputStream(newTmp.getAbsolutePath());)
        {
            Manifest manifest = new Manifest();  
            manifest.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");  
            try (JarOutputStream jarOut = new JarOutputStream(flOut, manifest))
            {
                for (String fn : allClassFiles)
                {
                    File fl = new File(fn);
                    if (!fl.isFile())
                        continue;

                    String relPath = fl.getCanonicalPath();
                    relPath = ToolUtilities.getRelatedPath(relPath, absDstPath);
                    relPath = CmnUtil.replaceAll(relPath, "\\", "/");
                    while (relPath.startsWith("/"))
                        relPath = relPath.substring(1);
                    byte[] bt = ToolUtilities.readFile(fl.getAbsolutePath());
                    JarEntry entry1 = new JarEntry(relPath);
                    jarOut.putNextEntry(entry1);
                    jarOut.write(bt);
                    jarOut.closeEntry();
                }

                for (Pair<JarEntry, byte[]> p : Nulls.get(addEntry))
                {
                    jarOut.putNextEntry(p.getKey());
                    jarOut.write(p.getValue());
                    jarOut.closeEntry();
                }
            }

            return ToolUtilities.readFile(newTmp.getAbsolutePath());
        } finally
        {
            ToolUtilities.deleteFileFolder(newTmp);
        }

//        List<Pair<JarEntry, byte[]>> lstEntry = new LinkedList();
//      for (String fn : allClassFiles)
//      {
//          File fl = new File(fn);
//          if (!fl.isFile())
//              continue;
//
//          // 转换文件路径为合法jar entry路径（尤其含子类的情况）
//          String relPath = fl.getCanonicalPath();
//          relPath = ToolUtilities.replaceAll(relPath, absDstPath, "");
//          relPath = relPath.replace('\\', '/');
//          while (relPath.startsWith("/"))
//              relPath = relPath.substring(1);
//          byte[] bt = ToolUtilities.readFile(fl.getAbsolutePath());
//          lstEntry.add(new Pair(new JarEntry(relPath), bt));
//      }

//        try (ByteArrayOutputStream btOut = new ByteArrayOutputStream())
//        {
//            try (JarOutputStream jarOut = new JarOutputStream(btOut))
//            {
//                for (Pair<JarEntry, byte[]> p : lstEntry)
//                {
//                    jarOut.putNextEntry(p.getKey());
//                    jarOut.write(p.getValue());
//                    jarOut.closeEntry();
//                }
//                return btOut.toByteArray();
//            }
//        }
    }

    public CodeDeclareInfo getCurrentMethodDec(CJavaCode currCode, int currPos) throws Exception
    {
        LvCompileResult result = doCompileSingleCode(currCode, true);
        Pair<Object, Binding> pair = result.getLvJavac().getSyntaxBinding(currPos);
        if (pair == null)
            return null;

        CodeDeclareInfo dec = LvJavac.convertBinding2LocateInfo(pair.right);
        CodeDeclareInfo methDec = null;
        if (dec.isMethod())
            methDec = dec;
        else if (dec.isType() && dec.hasChildren())
        {
            CodeDeclareInfo obj = dec.getChildren().get(0);
            if (obj != null && obj.isMethod())
                methDec = obj;
        }
        if (methDec == null)
            return null;
        // 设置侦测点位置
        methDec.setSourceStart(ToolUtilities.getInteger(ToolUtilities.getFieldValue(pair.left, LvJavac.key_sourceStart), -1));
        methDec.setSourceEnd(ToolUtilities.getInteger(ToolUtilities.getFieldValue(pair.left, LvJavac.key_sourceEnd), -1));

        return methDec;
    }

    public SrvProgressIntf<CodeDeclareInfo> searchCallHierarchy(String currCodeFullClass, CodeDeclareInfo methDec) throws RemoteException
    {
        CRpcProgressImpl<CodeDeclareInfo> srvProg = new CRpcProgressImpl<CodeDeclareInfo>();
        ToolUtilities.asynCallFunction(this, "doSearchCallHierarchy", srvProg, currCodeFullClass, methDec);

        return CRpcProgressWrapper.buildInServer(srvProg.getKey());
    }

    public void doSearchCallHierarchy(SrvProgressImpl<CodeDeclareInfo> srvProg, String currCodeFullClass, CodeDeclareInfo methDec) throws Exception
    {
        try
        {
            // 对于接口，或是有些间接调用的，用getAllAffectedCode找不全
            CJavaCode currCode = getCode(currCodeFullClass);
            List lstCode = null;
            if (currCode == null)
            {
                lstCode = getAllCode();
            } else
            {
                Map<String, CJavaCode> affts = getAllAffectedCode(ToolUtilities.newArrayList(currCode));
                if (ToolUtilities.isObjectEmpty(affts))
                    return;

                lstCode = new ArrayList(affts.values());
            }

            List lstResult = new ArrayList<CodeDeclareInfo>();
            int iCnt = lstCode.size();
            for (int i = 0; i < iCnt; i++)
            {
                ProgressCtrlUtil.assertCancel(srvProg);
                CJavaCode code = (CJavaCode) lstCode.get(i);
                ProgressCtrlUtil.sendProcess(srvProg, i * 100 / iCnt, "Analyse : " + code.getFullClassName(), true);
                List<CodeDeclareInfo> lstData = searchCaller(code, methDec);
                if (!ToolUtilities.isObjectEmpty(lstData))
                    lstResult.addAll(lstData);
            }

            methDec.setChildren(lstResult);
            srvProg.setResult(methDec);
        } catch (Throwable err)
        {
            srvProg.setException(err);
        } finally
        {
            ProgressCtrlUtil.sendFinishProcess(srvProg);
        }
    }

    public List<CodeDeclareInfo> searchCaller(CJavaCode code, CodeDeclareInfo dec) throws Exception
    {
        CodeDeclareInfo methDec = null;
        if (dec.isMethod())
            methDec = dec;
        else if (dec.isType() && dec.hasChildren())
        {
            CodeDeclareInfo obj = dec.getChildren().get(0);
            if (obj != null && obj.isMethod())
                methDec = obj;
        }

        if (methDec == null)
            return null;

        if (code.getCode().indexOf(methDec.getDeclarationName()) < 0)
            return null;

        LvCompileResult rs = doCompileSingleCode(code, true);
        List<CodeDeclareInfo> lstData = rs.getLvJavac().searchCallHierarchy(code.getCode(), dec);
        if (lstData != null)
            for (CodeDeclareInfo data : lstData)
            {
                // 底下没分析出来的，在这里强制加一个，但是要小心不要覆盖了嵌套子类的类信息
                if (ToolUtilities.isStringEmpty(data.getDeclareClass()))
                    data.setDeclareClass(code.getFullClassName());
            }

        return lstData;
    }

    public List<CodeDeclareInfo> searchOneSyntaxRefer(ProgressControllerFEIntf prog, CJavaCode code, Binding binding, IntRange range) throws Exception
    {
        String methName = LvJavac.getBindingDeclareName(binding);
        if (code.getCode().indexOf(methName) < 0)
            return null;

        LvCompileResult rs = doCompileSingleCode(code, true);
        List<CodeDeclareInfo> lstData = rs.getLvJavac().searchSyntaxRefered(prog, code.getCode(), binding, range);
        if (lstData != null)
            for (CodeDeclareInfo data : lstData)
                data.setDeclareClass(code.getFullClassName());

        return lstData;
    }

    public SrvProgressIntf<List<CodeDeclareInfo>> searchSyntaxReference(CJavaCode currCode, Binding binding, IntRange range) throws RemoteException
    {
        CRpcProgressImpl<List<CodeDeclareInfo>> prog = new CRpcProgressImpl();

        ToolUtilities.asynCallFunction(this, "doSearchSyntaxRefer", prog, currCode, binding, range);

        return CRpcProgressWrapper.buildInServer(prog.getKey());
    }

    public void doSearchSyntaxRefer(CRpcProgressImpl<List<CodeDeclareInfo>> srvProg, CJavaCode currCode, Binding binding, IntRange range) throws Exception
    {
        try
        {
            ProgressCtrlUtil.sendProcess(srvProg, 0, "" + currCode.getFullClassName(), true);
            List lstResult = new ArrayList<CodeDeclareInfo>();

            List<CJavaCode> lstCode = getAllCode();
            int iCnt = lstCode.size();
            int iPos = 0;
            for (CJavaCode code : lstCode)
            {
                ProgressCtrlUtil.assertCancel(srvProg);
                ProgressCtrlUtil.sendProcess(srvProg, iPos++ * 100 / iCnt, "Analyse : " + code.getFullClassName(), true);
                List<CodeDeclareInfo> lstData = searchOneSyntaxRefer(srvProg, code, binding, range);
                if (!ToolUtilities.isObjectEmpty(lstData))
                    lstResult.addAll(lstData);
            }

            srvProg.setResult(lstResult);
        } catch (Throwable err)
        {
            srvProg.setException(err);
        } finally
        {
            ProgressCtrlUtil.sendFinishProcess(srvProg);
        }
    }

    public SrvProgressIntf<List<CodeDeclareInfo>> searchText(String text) throws RemoteException
    {
        CRpcProgressImpl<List<CodeDeclareInfo>> srvProg = new CRpcProgressImpl<List<CodeDeclareInfo>>();
        ToolUtilities.asynCallFunction(this, "doSearchText", srvProg, text);
        return CRpcProgressWrapper.buildInServer(srvProg);
    }

    public void doSearchText(CRpcProgressImpl<List<CodeDeclareInfo>> srvProg, String text) throws Exception
    {
        try
        {
            List<CodeDeclareInfo> lstRet = new ArrayList<CodeDeclareInfo>();
            List<CJavaCode> allCode = getAllCode();
            if (ToolUtilities.isObjectEmpty(allCode))
                return;

            int iCnt = allCode.size();
            for (int i = 0; i < iCnt; i++)
            {
                ProgressCtrlUtil.assertCancel(srvProg);

                CJavaCode code = allCode.get(i);
                String sCode = code.getCode();
                ProgressCtrlUtil.sendProcess(srvProg, i * 100 / iCnt, "" + code.getFullClassName(), true);

                int iPos = -1;
                while ((iPos = sCode.indexOf(text, iPos + 1)) > 0)
                {
                    CodeDeclareInfo info = new CodeDeclareInfo("", text, CodeDeclareInfo.OTHER);
                    info.setDeclareClass(code.getFullClassName());
                    info.setSourceStart(iPos);
                    info.setSourceEnd(iPos + text.length());
                    lstRet.add(info);
                }
            }

            srvProg.setResult(lstRet);
        } catch (Throwable err)
        {
            srvProg.setException(err);
        } finally
        {
            ProgressCtrlUtil.sendFinishProcess(srvProg);
        }
    }

    public CDao newDao() throws Exception
    {
        return CDaoClient.newDao();
    }

    public String getString(String s)
    {
        return s;
    }

    public CJavaCode createJavaCode(CJavaCode code, boolean autoCompile) throws Exception
    {
        CJavaCode existName = getCode(code.getFullClassName());
        if (existName != null)
            throw new Exception(getString("Found duplicate class in project"));
        
        // 预判类名冲突
        Exception conflictError = assertCodeConflictProject(code.getFullClassName());
        if (conflictError != null)
            throw conflictError;

        try (CDao dao = newDao())
        {
            CJavaCodeDo codeDo = CDaoUtil.convertDo(code);
            codeDo.setMaster(getProject().getGid(), CJavaProject.LstCode);
            codeDo.setLastWriter(CDaoUtil.getRpcSession());
            codeDo = dao.createDo(codeDo);
            dao.commit();

            CJavaCode newCode = addCode2Cache(codeDo);

            if (autoCompile)
                rebuildOneCodeLater(newCode);
            return newCode;
        }
    }
    
    public boolean isVirtual()
    {
        return getProject() instanceof CJavaVirtualProject;
    }
    
    // 有些操作不支持虚拟工程
    public void assertNotVirtual()
    {
        CmnUtil.assertTrue(!isVirtual(), "Virtual project doesn't support this operation");
    }
    
    public void assertNotSystem()
    {
        CmnUtil.assertTrue(!CJavaCenter.isSystemProject(getProject()), "System project is read-only");
    }

    // 这个实现较为复杂，是因为支持变更包名甚至类名，所以是通过RDN来找老的code，并删除老code的缓存，新增新的code
    // 所以传入参数的rdn就很重要了
    // 不会存储元数据（默认也不会加载元数）
    public CJavaCode saveJavaCode(CJavaCode newCode, boolean autoCompile) throws Exception
    {
        assertNotVirtual();
        assertNotSystem();
        
        CmnUtil.assertNotEmpty(newCode.getMainClass(), "Please define main class in java code : " +newCode);
        CJavaConst.assertReservedClassName(newCode.getFullClassName()); // 检查系统保留的java类名
        ToolBasic.assertValidClassName(newCode.getMainClass());

        CmnUtil.assertTrue(ToolUtilities.isValidPackage(newCode.getJavaPackage()), "Please provide a correct package name : " +newCode.getJavaPackage());
        
        try (CDao dao = newDao())
        {
            CJavaCodeDo orgCodeDo = (CJavaCodeDo) dao.queryDo(newCode.getGid());
            if (orgCodeDo == null)
                return createJavaCode(newCode, autoCompile);

            CJavaCode orgCode = getCode(orgCodeDo.getFullClassName());
            if (orgCode == null)
                throw new Exception("Can not find class in project : " + orgCodeDo.getFullClassName());

            orgCodeDo.setJavaPackage(newCode.getJavaPackage());
            orgCodeDo.setMainClass(newCode.getMainClass());
            orgCodeDo.setCode(newCode.getCode());
            orgCodeDo.setLastWriter(CDaoUtil.getRpcSession());
            orgCodeDo.updateSaveInfo();

            dao.updateDo(orgCodeDo);
            dao.commit();

            if (getProject().isUdfLib() && UdfIntf.isUdfPackage(orgCode.getPackage()))
                fireUdfSaved();

            deleteClassFile(orgCode);
            removeFrmCodeCache(orgCode.getFullClassName());
            newCode = addCode2Cache(orgCodeDo);

            // rebuild
            if (autoCompile)
            {
                rebuildOneCodeLater(newCode);
            }

            return newCode;
        }
    }

    public CResFileDo createResFile(IDao dao, CResFileDo resFile) throws Exception
    {
        resFile.setSize((long) ToolUtilities.getObjectSize(resFile.getFileBin()));
        resFile.setFileMd5(MD5Util.encode(resFile.getFileBin()));

        resFile.setMaster(getProject().getGid(), CJavaProject.LstRes);
        resFile.setLastWriter(CDaoUtil.getRpcSession());
        return dao.createDo(resFile);
    }

    public CResFileDo saveResFile(CResFileDo resFile, boolean autoCompile) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            CResFileDo fileDo = saveResFile(dao, resFile);
            dao.commit();

            // rebuild
            if (autoCompile)
            {
                rebuildAll();
            }

            return fileDo;
        }
    }

    public CResFileDo saveResFile(IDao dao, CResFileDo resFile) throws Exception
    {
        CResFileDo orgFile = (CResFileDo) dao.queryDo(resFile.getGid());
        if (orgFile == null)
            return createResFile(dao, resFile);

        orgFile.setFilePackage(resFile.getFilePackage());
        orgFile.setFileName(resFile.getFileName());
        orgFile.setFileBin(resFile.getFileBin());
        orgFile.updateFileInfo();
        orgFile.setOwner(resFile.getOwner());
        orgFile.setLastWriter(CDaoUtil.getRpcSession());

        dao.updateDo(orgFile);
        return orgFile;
    }

    public boolean deleteCode(String fullClass, boolean autoCompile) throws Exception
    {
        assertNotVirtual();
        assertNotSystem();
        
        CJavaCode existCode = getCode(fullClass);
        if (existCode == null)
            return false;

        Map<String, CJavaCode> affectedCode = getAllAffectedCode(ToolUtilities.array2List(new CJavaCode[] { existCode }));
        affectedCode.remove(existCode.getFullClassName());

        try (CDao dao = newDao())
        {
            dao.deleteDo(existCode.getGid());
            deleteClassFile(existCode);
            removeFrmCodeCache(fullClass);

            dao.commit();

            // 广播UDF删除事件
            if (getProject().isUdfLib() && UdfIntf.isUdfPackage(existCode.getPackage()))
                fireUdfDeleted();
        }

        if (autoCompile)
            rebuildPartiallyLater(affectedCode.values());

        return true;
    }

    protected void fireUdfDeleted()
    {
        IDaoService.get().putCenterCache(CJavaConst.DAO_NOTIFY_DELETED_UDF_TIME, System.currentTimeMillis());
    }

    protected void fireUdfSaved()
    {
        IDaoService.get().putCenterCache(CJavaConst.DAO_NOTIFY_SAVED_UDF_TIME, System.currentTimeMillis());
    }

    public boolean deleteCode(Set<String> fullClass) throws Exception
    {
        assertNotVirtual();
        assertNotSystem();
        
        Map<String, CJavaCode> affectedCode = getAllAffectedCodeByName(fullClass);

        for (String delClassName : fullClass)
        {
            affectedCode.remove(delClassName);
            deleteCode(delClassName, false);
        }

        if (!ToolUtilities.isObjectEmpty(affectedCode))
            rebuildPartiallyLater(affectedCode.values());
        return true;
    }

    public String getLog()
    {
        return LOG;
    }

    // 批量提交、删改代码，需加锁，批量操作完后统一rebuild
    ReentrantLock _lockBatch = new ReentrantLock();

    public CJavaCodeDo queryCodeDo(IDao dao, String fullClassName)
    {
        return dao.queryDo(CJavaCodeDo.class, Cnd.where(CJavaCodeDo.MasterKey, "=", getProject().getUuid()).and(CJavaCodeDo.JavaPackage, "=", LvJavac.getPackageFromFullClass(fullClassName)).and(CJavaCodeDo.MainClass,
                "=", LvJavac.getSimpleName(fullClassName)));
    }

    public CJavaFolder queryFolderDo(IDao dao, String folderName)
    {
        return CJavaCenter.queryFolderDo(dao, getProject().getUuid(), folderName);
    }

    public boolean deleteFolderByName(String folderName) throws Exception
    {
        assertNotVirtual();
        try (CDao dao = newDao())
        {
            CJavaFolder fd = dao.queryDo(CJavaFolder.class, Cnd.where(CJavaFolder.MasterKey, "=", getProject().getUuid()).and(CJavaFolder.Name, "=", folderName));
            if (fd == null)
                return false;

            deleteFolder(dao, fd);
        }
        return true;
    }

    public boolean deleteFolder(String folderUuid) throws Exception
    {

        assertNotVirtual();
        try (CDao dao = newDao())
        {
            CJavaFolder fd = (CJavaFolder) dao.queryDo(GID.build(CJavaFolder.class, folderUuid));
            if (fd == null)
                return false;

            deleteFolder(dao, fd);
        }
        return true;
    }

    // 内部会提交了，而且不是强事务，删除代码成功一个提交一个，最后再删目录
    public void deleteFolder(CDao dao, CJavaFolder fd) throws Exception
    {
        assertNotVirtual();
        
        // 搜集一个目录下的所有类代码
        Set<CJavaCode> allCodes = new HashSet<CJavaCode>();
        Map<String, Set<String>> pkgMap = _pkgFolderMap.get(fd.getUuid());
        if (pkgMap != null)
        {
            for (Entry<String, Set<String>> entryPkg : pkgMap.entrySet())
            {
                String sPkg = entryPkg.getKey();
                Set<String> classes = entryPkg.getValue();
                if (classes != null)
                    for (String oneClass : classes)
                    {
                        String sClass = LvJavac.getFullClassName(sPkg, oneClass);
                        CJavaCode code = getCode(sClass);
                        if (code != null)
                            allCodes.add(code);
                    }
            }
        }

        Map<String, CJavaCode> affCodes = getAllAffectedCode(allCodes);

        // 先删代码（内部会逐一提交，且会删除编译class文件）
        for (CJavaCode code : allCodes)
            deleteCode(code.getFullClassName(), false);

        // 删除DO
        dao.deleteDo(fd);
        dao.commit();

        // 编译受影响的
        if (!ToolUtilities.isObjectEmpty(affCodes))
            rebuildPartiallyLater(affCodes.values());
    }
    
    public Exception assertCodeConflictProject(String fullClassName) throws Exception
    {
        List<CJavaCode> conflictCode = CJavaCenter.getMe().searchCode(fullClassName);
        for (CJavaCode exist : Nulls.get(conflictCode))
        {
            if (getProject().getUuid().equals(exist.getProjectUuid()))
                continue;
            
            if (CJavaCenter.isSystemProject(exist.getProjectUuid()))
                return new Exception(BapGuiUtil.getString("Conflict class with platform")+" : " + fullClassName);
            else
            {
                CJavaProject pj = CJavaCenter.getProject(exist.getProjectUuid());
                return new Exception(BapGuiUtil.getString("Conflict class with other project")+" : " + pj.getName() + " - " + fullClassName);
            }
        }
        
        return null;
    }

    public void commitCode(CommitPackage pkg) throws Exception
    {
        assertNotSystem();
        assertNotVirtual();
        
        _lockBatch.lock();
        try
        {
            boolean saveUdf = false;
            boolean deleteUdf = false;

            try (IDao dao = IDaoService.newIDao())
            {
                List<CJavaCodeDo> lstCmtCode = new LinkedList<CJavaCodeDo>();
                if (pkg.getMapFolder2Codes() != null)
                {
                    // 提交源代码
                    MultipleException mulExp = new MultipleException(BapGuiUtil.getString("Failed to commit some code file"));
                    for (Entry<String, List<CJavaCode>> ent : pkg.getMapFolder2Codes().entrySet())
                    {
                        String folder = ent.getKey();
                        List<CJavaCode> lstCode = ent.getValue();
                        for (CJavaCode code : lstCode)
                        {
                            CmnUtil.assertNotEmpty(code.getMainClass(), "Please define main class in java code : " + code);
                            
                            // 提交文件夹（如果不存在)
                            CJavaFolder fd = queryFolderDo(dao, folder);
                            if (fd == null)
                            {
                                fd = new CJavaFolder();
                                fd.setMaster(getProject().getGid());
                                fd.setName(folder);
                                fd = dao.createDo(fd);
                            }

                            CJavaCodeDo exist = queryCodeDo(dao, code.getFullClassName());
                            if (exist != null)
                            {
                                exist.setCode(code.getCode());
                                exist.setOwner(fd.getUuid()); // 有可能移动文件夹
                                exist.setLastWriter(CDaoUtil.getRpcSession());
                                exist.updateSaveInfo();
                                dao.updateDo(exist);
                                lstCmtCode.add(exist);

                                if (UdfIntf.isUdfPackage(exist.getPackage()))
                                    saveUdf = true;
                            } else
                            {
                                // 预判类名冲突
                                Exception conflictError = assertCodeConflictProject(code.getFullClassName());
                                if (conflictError != null)
                                {
                                    mulExp.addException(conflictError);
                                    continue;
                                }

                                CJavaCodeDo codeDo = CDaoUtil.convertDo(code);
                                codeDo.setMaster(getProject().getGid(), CJavaProject.LstCode);
                                codeDo.setOwner(fd.getUuid());
                                codeDo.setLastWriter(CDaoUtil.getRpcSession());
                                codeDo.updateSaveInfo();

                                codeDo = dao.createDo(codeDo);
                                lstCmtCode.add(codeDo);

                                if (UdfIntf.isUdfPackage(codeDo.getPackage()))
                                    saveUdf = true;
                            }
                        }
                    }
                    
                    mulExp.tryThrowException();
                }

                List<CJavaCode> lstDel = new LinkedList<CJavaCode>();
                for (Entry<String, Set<String>> ent : NullUtil.getEntry(pkg.getDeleteCodeMap()))
                    for (String s : NullUtil.get(ent.getValue()))
                    {
                        CJavaCode exist = getCode(s);
                        if (exist != null)
                        {
                            dao.deleteDo(exist.getGid());
                            lstDel.add(exist);

                            if (UdfIntf.isUdfPackage(exist.getPackage()))
                                deleteUdf = true;
                        }
                    }

                // 入版本库
                CVerMgr.get().commitCode(dao, getProject(), pkg.getComments(), lstCmtCode, lstDel);

                // =================== 处理资源文件 ======================
                // 提交资源文件
                List<CResFileDo> lstCmtFile = new LinkedList<CResFileDo>();
                if (pkg.getMapFolder2Files() != null)
                    for (Entry<String, List<CResFileDto>> ent : pkg.getMapFolder2Files().entrySet())
                    {
                        String folder = ent.getKey();
                        List<CResFileDto> lstFiles = ent.getValue();
                        for (CResFileDto fileDto : lstFiles)
                        {
                            // 提交文件夹（如果不存在)
                            CJavaFolder fd = queryFolderDo(dao, folder);
                            if (fd == null)
                            {
                                fd = new CJavaFolder();
                                fd.setMaster(getProject().getGid());
                                fd.setName(folder);
                                fd = dao.createDo(fd);
                            }

                            CResFileDo exist = CJavaCenter.getResFile(dao, getProject().getUuid(), fileDto.getPhysicalPath(), true);
                            if (exist != null)
                            {
                                exist.setFileBin(fileDto.getFileBin());
                                exist.setOwner(fd.getUuid()); // 有可能移动文件夹
                                exist.setLastWriter(CDaoUtil.getRpcSession());
                                exist.updateFileInfo();
                                dao.updateDo(exist);
                                lstCmtFile.add(exist);
                            } else
                            {
                                CResFileDo fileDo = CDaoUtil.convertDo(fileDto);
                                fileDo.setMaster(getProject().getGid(), CJavaProject.LstRes);
                                fileDo.setOwner(fd.getUuid());
                                fileDo.setLastWriter(CDaoUtil.getRpcSession());
                                fileDo.updateFileInfo();
                                fileDo = dao.createDo(fileDo);
                                lstCmtFile.add(fileDo);
                            }
                        }
                    }

                List<CResFileDo> lstDelFiles = new LinkedList<CResFileDo>();
                for (Entry<String, Set<String>> ent : NullUtil.getEntry(pkg.getDeleteFileMap()))
                    for (String filePath : NullUtil.get(ent.getValue()))
                    {
                        CResFileDo exist = CJavaCenter.getResFile(dao, getProject().getUuid(), filePath, true);
                        if (exist != null)
                        {
                            dao.deleteDo(exist.getGid());
                            lstDelFiles.add(exist);
                        }
                    }

                // 入版本库
                CVerMgr.get().commitFile(dao, getProject(), pkg.getComments(), lstCmtFile, lstDelFiles);

                // 一起提交
                dao.commit();

                if (getProject().isUdfLib())
                {
                    if (saveUdf)
                        fireUdfSaved();
                    if (deleteUdf)
                        fireUdfDeleted();
                }
            }

            lazyRebuildAll();
        } finally
        {
            _lockBatch.unlock();
        }
    }
    
    public void lazyRebuildAll()
    {
        _lazyRebuildAll.add(0);
    }
    
    LazyPool<Integer> _lazyRebuildAll = new LazyPool<Integer>(100){

        @Override
        public void handle(List<Integer> lstData)
        {
            try
            {
                rebuildAll();
            } catch (Exception exp)
            {
                ToolUtilities.info(LOG, "Error on rebuild all : " +ToolUtilities.getExceptionStackMessage(exp));
            }
        }
    };
}
