package bap.java.project;

import java.io.Serializable;

public class LaunchItem implements Serializable
{
    private static final long serialVersionUID = -6368344541989209808L;
    
    public String name;
    public String mainType;
    public String vmArguments;
    public String programArguments;
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public String getMainType()
    {
        return mainType;
    }
    public void setMainType(String mainType)
    {
        this.mainType = mainType;
    }
    public String getVmArguments()
    {
        return vmArguments;
    }
    public void setVmArguments(String vmArguments)
    {
        this.vmArguments = vmArguments;
    }
    public String getProgramArguments()
    {
        return programArguments;
    }
    public void setProgramArguments(String programArguments)
    {
        this.programArguments = programArguments;
    }
    
    
    
}
