package bap.java;

import com.leavay.common.util.javac.CompileStastic;

// 主要用于界面（树）上的DTO对象，可以含有编译统计信息的对象，例如：代码DTO、包DTO等等
public interface CJavaGuiCompilable
{
    public void setCompileStastic(CompileStastic compileStastic);
    public CompileStastic getCompileStastic();
}
