package bap.java;

import java.io.Serializable;

/**
 * 作为源码文件的元数据，与元数据存在同目录同名，后缀.meta的方式储存
 * 
 * 以全局监听器的方式，对代码删除动作做了同时的删除meta的联动 : CJavaCodeDeleteListener
 * 
 * 在主控端，其为资源文件的方式存放
 * 在Eclipse端或者导出包中，以.meta的文件形式存放
 *
 */
public class CodeMeta implements Serializable
{
    private static final long serialVersionUID = 2078058549569797479L;
    
    public String meta;

    public String getMeta()
    {
        return meta;
    }

    public void setMeta(String meta)
    {
        this.meta = meta;
    }

    public String toString()
    {
        return getMeta();
    }
}
