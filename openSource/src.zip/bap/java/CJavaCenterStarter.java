package bap.java;

import com.leavay.dfc.mgr.starter.CDaoStarter;
import com.leavay.starter.CStarter;

import bap.ServletInitRegister;
import bap.java.project.CJavaCenter;
import bap.web.servlet.CellInvokeServlet;
import bap.web.servlet.JavaToolServlet;
import bap.web.servlet.MvelToolServlet;

public class CJavaCenterStarter implements CStarter
{
    public void init() throws Exception
    {
        ServletInitRegister.get().initRegistServlet(JavaToolServlet.SERVLET_CONTEXT_PATH, JavaToolServlet.class);
        ServletInitRegister.get().initRegistServlet(CellInvokeServlet.SERVLET_CONTEXT_PATH, CellInvokeServlet.class);
        ServletInitRegister.get().initRegistServlet(MvelToolServlet.SERVLET_CONTEXT_PATH, MvelToolServlet.class);
    }

    public void before(CStarter other) throws Exception
    {
        if (other instanceof CDaoStarter)
            CJavaCenter.getMe().initBeforeDao();
    }

    public void start() throws Exception
    {
        CJavaCenter.getMe().start();
    }

}
