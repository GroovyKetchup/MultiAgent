package bap.java;

import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassInfoQuery;
import com.leavay.common.util.javac.LvClassLoader;
import com.project.gui.Javac.JavaGuiCompiler;

public abstract class CJavaGuiCompiler extends JavaGuiCompiler
{
    public ClassInfoQuery getClassInfoQuery()
    {
        return ClassFactory.getClassInfoQuery();
    }
    
    public LvClassLoader newValidClassLoader()
    {
        return ClassFactory.newValidClassLoader();
    }
}
