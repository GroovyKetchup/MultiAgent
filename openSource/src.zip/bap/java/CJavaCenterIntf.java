package bap.java;

import java.net.URI;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.Cnd;

import com.cdao.dto.CPager;
import com.cdao.impl.entity.field.GID;
import com.cdao.mgr.CSession;
import com.leavay.common.util.Pair;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ProgressCtrl.SrvProgressIntf;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.CodeCompileException;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.common.util.javac.CompileStastic;
import com.leavay.common.util.javac.LvProblem;
import com.leavay.dfc.mgr.javaDev.ClassNameInfoExt;

import art.mvn.MvnArt;
import bap.cells.CellConfig;
import bap.dev.FileDto;
import bap.dev.JavaDto;
import bap.java.debug.CJavaDebugCenterIntf;
import bap.java.project.GlobalDependObserver;
import bap.java.project.LoneWolfConfig;
import bap.md.java.CResFileDo;
import bap.md.ver.VersionNode;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import bap.plugin.CPluginProjectDto;
import bap.udf.UdfMeta;
import bap.yun.ArtifactPackage;
import cell.bap.yun.ArtifactGraph;
import cmn.security.dto.UserPassword;
//import code.maven.MvnArt;
import cplugin.ms.dto.CJarFileDto;
import cplugin.ms.dto.CResFileDto;
import ms.cmn.HostPort;

public interface CJavaCenterIntf extends CJavaDebugCenterIntf
{

    // 建立第一版1.1: 增加了差异化(MD5)方式到处插件jar包的接口
    public final static float VER_1_1 = 1.1f;
    
    // 增加虚拟工程相关功能(用于查看历史版本代码等)
    // 增加VersionNode的分页批量查询(用于提高代码比较的速度)
    public final static float VER_1_2 = 1.2f;
    
    /**
     * 这是一个写死的接口版本号, 用于外部根据版本适配不同接口
     */
    public default float getCodeVersion() {
        return VER_1_2;
    }
    
    public CSession login(String user, String pwd) throws Exception;
    
    public long getDaoTag();
    
    public long getPluginTag() throws Exception;
    
    // dependType : CJavaConst.DEPEND_TYPE
    public CJavaProjectDto createProject(String name, int dependType) throws Exception;
    
    public CJavaProjectDto createProject(String name, int dependType, String withNewFolder) throws Exception;

    public void deleteProject(GID pjGid) throws Exception;
    
    public CJavaProjectDto updateProject(GID pjGid, Map<String, Object> mapV) throws Exception;
    
    public CJavaFolderDto createFolder(GID pjGid, String name) throws Exception;
    
    // 如果真实存在，且删除成功，返回true，不存在则返回false，存在但删除出错则抛异常
    public boolean deleteFolder(String pjUuid, String folderUuid) throws Exception;

    // 如果真实存在，且删除成功，返回true，不存在则返回false，存在但删除出错则抛异常
    public boolean deleteFolderByName(String pjUuid, String folderName) throws Exception;
    
    // 有就直接返回，没有就创建
    public CJavaFolderDto saveFolder(GID pjGid, String name) throws Exception;

    /**
     * 设置某个源码文件夹为某人专属，如果设置为null则视为共享代码
     * @param privateOwner : 用户的Code（维码）
     */
    public void setFolderPrivate(GID folderGid, String privateOwner) throws Exception;
    
    public void rebuildAll(String projectUuid) throws Exception;
    
    // 返回的代码对象是不含源码的摘要信息
    public List<CJavaCode> searchCode(String fullClass) throws Exception;

    // 根据前缀、搜索条件，搜索类信息
    public List<ClassNameInfoExt> searchCode(String sKey, boolean searchInJar, int countLimit) throws Exception;
    
    public CJavaCode saveJavaCode(CJavaCode newCode, boolean autoCompile) throws Exception;
    
    // 编译单个源文件（在工程中增量式编译）
    public List<LvProblem> compileSingleCode(CJavaCode code, boolean useCache) throws Exception;
    
    // 给前缀搜索类，用于自动补全
    public Map<String, Object> searchClass(CJavaCode code, String sPreFix, int iCurrentPos) throws Exception;

    // 根据前缀搜字符、方法名，用于自动补全
    public Map<String, Object> searchMethodField(CJavaCode code, String sTotalPreword, int iCurrentPos) throws Exception;
    
    public boolean deleteCode(String pjUuid, String fullClass, boolean autoCompile) throws Exception;
    
    public boolean deleteCode(String pjUuid, Set<String> fullClass) throws Exception;
    
    /**
     * 编译分析代码中的语法树 （主要是变量、函数等申明）
     */
    public List<CodeDeclareInfo> querySyntaxTree(CJavaCode code) throws Exception;
    

    /**
     * 搜索代码中所选字符部分的类型申明信息
     * 主要用于F3跳转到申明处
     */
    public CodeDeclareInfo searchDeclaration(CJavaCode code, String selString, int currPos) throws Exception;
    

    /**
     * 搜索代码中选中的语法字根被引用的地方，类似Ctrl+G功能
     */
    public SrvProgressIntf<List<CodeDeclareInfo>>  searchSyntaxReference(CJavaCode code, String selString, int currPos) throws Exception;
    
    /**
     * 指定工程代码中搜索字符串
     */
    public SrvProgressIntf<List<CodeDeclareInfo>> searchText(String projectUuid, String text) throws Exception;
    
    /**
     * 获取所选未知语法符号对应的类型，主要用于自动cast类型转换识别
     */
    public CodeDeclareInfo getSyntaxBindingType(CJavaCode code, int currPos) throws Exception;
    
    /**
     * 获取所选符号的意义，用于强制cast、断点位置识别等
     */
    public CodeDeclareInfo getSyntaxMeaning(CJavaCode code, int currPos) throws Exception;
    
    public CJavaCode getJavaCode(String projectUuid, String fullClassName) throws Exception;
    
    /**
     * 给定code的Uuid，搜索获取其对象
     */
    public CJavaCode getJavaCode(String codeUuid) throws Exception;
    
    // 获取代码对应的树路径（工程/目录/包名/代码）
    public String[] getCodePath(String pjUuid, String fullClassName) throws Exception;
    
    public CJavaProjectDto getProject(String uuid) throws Exception;
    
    public List<CJavaProjectDto> queryProject(Cnd cnd) throws Exception;
    
    public List<CJavaProjectDto> getAllProjects() throws Exception;
    
    // 查工程的源码文件夹下所有包名
    public Set<String> getAllPackages(String projectUuid, String folderUuid) throws Exception;
    
    // 查某个工程下有多少源码目录
    public List<CJavaFolderDto> getFolders(String pjUuid) throws Exception;
    
    // 查工程下某个目录下的某个包下的所有代码，包名可以为“”也可以为null，代表查那种无包的类
    // 返回的是摘要信息，不含源码
    public List<CJavaCode> getChildCodeBrief(String projectUuid, String folderUuid, String sPackage);
    
    // 查询某个工程下，某个目录的编译统计
    public CompileStastic getFolderStastic(String projectUuid, String folderUuid);
    
    // 查某个目录下，某个包/类的编译统计，nameOfPackageOrClass : 类名或包名的完整名
    public CompileStastic getStastic(String projectUuid, String folderUuid, String nameOfPackageOrClass);
    
    /**
     * 将java工程快速编译打包发布成插件
     * 
     * 不指定dstPluginProjectName，表示随JAVA工程的名字
     * 默认：忽略编译错
     */
    public CPluginProjectDto exportProject2Plugin(String projectUuid, String dstPluginProjectName, boolean includeSubJars) throws Exception;
    
    /**
     * 将java工程快速编译打包发布成插件
     * 
     * 不指定dstPluginProjectName，表示随JAVA工程的名字
     */
    public CPluginProjectDto exportProject2Plugin(String projectUuid, String dstPluginProjectName, boolean includeSubJars, boolean ignoreCompileError) throws CodeCompileException, Exception;
    
    /**
     * 灰度发布工程，将若干灰度发布的工程编译结果汇总暂存于灰度目录下，并以特殊类加载器加载
     * 然后接管ClassFactory，是所有类构建统统桥接到灰度库
     * 
     * 仅在开发机进程内，临时生效（以projectUuid为key），会自动清理垃圾类
     * 当真正的插件发布时，会清空灰度发布的内容，抛弃旧的灰度发布的类加载器及相关文件
     * 
     * @param rebuildAll ：发布之前，是否全量编译该工程
     */
    public void grayPublish(String projectUuid, boolean rebuildAll) throws CodeCompileException, Exception;
    
    /**
     * 往java工程中导入JAR包（ZIP、或其他任何文件包），参与编译以及打包插件
     */
    public CJarFileDto importJarFile(GID pjGid, CJarFileDto jar) throws Exception;
    
    /**
     * 往java工程中导入资源文件，参与编译以及打包插件
     */
    public CResFileDto importResFile(GID pjGid, CResFileDto file) throws Exception;


    /**
     * 删除资源文件（包含删除编译路径下的物理文件）
     */
    public void deleteResFile(GID resGid) throws Exception;
    

    /**
     * 查询某个工程下的资源文件，可以根据源码目录UUID过滤，也可以不过滤
     * 
     * filterFolderUuid : 源码目录UUID，可传NULL表示查询工程下所有
     */
    public List<CResFileDto> getResFiles(String projectUuid, String filterFolderUuid, boolean onlyBrief) throws Exception;

    
    /**
     * 获取某个资源文件对象，传入的文件全路径名，不包含源码目录
     * 例如：src/core/com/test/AAA.xml，这个资源文件，传入com/test/AAA.xml即可
     * 
     * @param projectUuid
     * @param filePath : 
     */
    public CResFileDto getResFile(String projectUuid, String filePath, boolean onlyBrief) throws Exception;
    
    /**
     * 查询某工程下的资源文件
     * 
     * @param filterFolderUuid ： 给定源码目录过滤，传空表示不过滤，所有源码目录都要
     * @param pkg ：给定包名，传空则表示只查询无包名的资源文件，传值则按包名过滤，如果传入“*”表示不过滤包名
     * @param onlyBrief ：是否只取摘要字段
     */
    public List<CResFileDto> queryResFiles(String projectUuid, String filterFolderUuid, String pkg, boolean onlyBrief) throws Exception;
    
    
    /**
     * 查询某个工程下的所有JAR包（含Zip等，任何格式不限）
     */
    public List<CJarFileDto> getJarFiles(String projectUuid) throws Exception;

    /**
     * 某工程下是否有jar包
     */
    public boolean hasJarFiles(String pjUuid) throws Exception;
    
    /**
     * 删除jar
     */
    public void deleteJarFile(GID jarGid) throws Exception;


    /**
     * 中心提供代码调试功能，会自动根据所在工程的特性来处理依赖Classloader的选择问题
     */
    public String startDebugJava(CJavaCode code, HostPort agent) throws Exception;
    
    public String startDebugJava(CJavaCode code, URI agentUri) throws Exception;
    
    /**
     * 导出工程(For Eclipse)，并zip成包，返回字节流
     * 
     * 给出源码目录的名字，导出源码，否则都已jar包输出
     */
    public byte[] exportProject(String projectUuid, Set<String> srcFolderName) throws Exception;

    /**
     * 流式带进度导出整个工程
     * 此调用过程有可能阻塞很久，在客户端如果出现超时，可以设置一下调用临时超时时长，例如：CRpcAdapter.setTempTimeout(30*60*1000); // 单次调用超时设置长一点，以免下载过慢
     * 

     * IProgress 对象用CProgressProxy来传入即可，同时可接收数据，样例如下：
        DefaultOutputProgress prog = new DefaultOutputProgress();
        CProgressProxy proxy = new CProgressProxy<byte[]>(prog){
            public void sendDataFrame(byte[] data)
            {
                if (data != null)
                {
                    LvUtil.trace(data.length);
                }
            }
        };
            
        CJavaCenter.getMe().streamExportProject(proxy, uuid, setFd, null);
     *
     */
    public void streamExportProject(IProgress<byte[]> prog, String projectUuid, Set<String> srcFolderNames, CSession session) throws Exception;
    
    
    /**
     * 返回Eclipse插件端，默认的管理工具启动类
     */
    public String getDevAdminTool();
    
    /**
     * 给出函数名参数等，找到并补全未实现的方法体
     */
    public String generateMethodCode(String pjUuid, String classN, String funcName, List<Pair<String, String>> lstParam) throws Exception;

    /**
     * 以文件路径为key的形式，返回某个文件夹下所有java代码
     */
    public Map<String, JavaDto> queryCodeFile(String projectUuid, String folderName) throws NoFolderException, Exception;
    

    /**
     * 以文件路径为key的形式，返回某个源码目录下所有的文件，包含源码和资源文件
     * 
     * Value为JavaDto或者FileDto
     */
    public Map<String, FileDto> queryAllFileMap(String projectUuid, String folderName) throws NoFolderException, Exception;
    

    /**
     * 批量提交代码到服务端，提交完会重编译整个工程
     * 提交整体成功或者整体失败，但无关编译结果
     * 
     * @param mapFolder2Codes : 要新增或覆盖的代码（以文件夹+类名为依据）
     * @param deleteList : 要删除的类名列表
     * @param comments : 此次提交的备注信息
     */
    public void commitCode(String projectUuid, CommitPackage pkg) throws Exception;
    
    public CodeMeta getCodeMeta(String cls) throws Exception;
    
    // 通过代码类名，保存meta (可以存CodeMeta也可以存UdfMeta)
    public CResFileDo saveCodeMeta(String className, CodeMeta meta, boolean rebuild) throws Exception;

    // 获取UDF 的Meta（和普通CodeMeta处理不同，还需要编译整合之后返回）
    public UdfMeta queryUdfMeta(String pjUuid, String cls) throws Exception;

    /**
     * 导出DAO模型jar以及TAG文件，以ZIP包输出
     * 如果tag一致，返回NULL
     */
    public byte[] exportModelFile(long tag) throws Exception;

    /**
     * 为外部工程导出插件Jar以及TAG文件，同时排除给定名字的源码目录对应的jar包，以ZIP包输出
     */
    public byte[] exportPluginJars(long pluginTag, String projectUuid, Collection<String> srcFolderName) throws Exception;
    

    /**
     *  [新]为外部Eclipse工程导出差异化插件Jar以及TAG文件，同时排除给定名字的源码目录对应的jar包
        此方法按MD5比对更新jar文件, 不会全量发送
        传入clientFileMd5为jar文件名对应MD5码
     */
    public FileUpdatePackage exportPluginJars(Map<String, String> clientFileMd5, String projectUuid, Collection<String> srcFolderName) throws Exception;
    
    /**
     * 增量导出平台自身的所有jar包，项目本身引入的jar包（lib/lib_ui的所有jar），主要用于增量更新
     *
     * @param mapMd5 ： 只包含远端（Eclipse开发端）lib/platform目录下所有文件（纯文件名不含路径）对应的md5码
     * @return 差异压缩包（包含新增和修改的），以及不存在的名字列表
     */
    public Pair<byte[], Set<String>> exportPlatformJars(Map<String, String> mapMd5) throws Exception;
    
    
    /**
     * 导出独狼模式所需的包
     * 主要包括构建本地独立运行环境所需的文件内容
     * 
     * 通过进度回传zip文件
     */
    public LoneWolfConfig exportLoneWolfFiles(IProgress<byte[]> prog) throws Exception;

    /**
     * 增量导出平台自身的所有jar包，项目本身引入的jar包（lib/lib_ui的所有jar），主要用于增量更新
     *
     * @param mapMd5 ： 只包含远端（Eclipse开发端）lib/platform目录下所有文件（纯文件名不含路径）对应的md5码
     * @return 不存在的名字列表，同时通过进度流式回传差异包（压缩）
     */
    public Set<String> streamExportPlatformJars(IProgress<byte[]> prog, Map<String, String> mapMd5) throws Exception;
    

    /**
     * 导出项目本身引入的jar包（lib/project目录下的），主要用于增量更新
     *
     * @param mapMd5 ： 只包含lib/project目录下所有文件（纯文件名不含路径）对应的md5码
     * @return 差异压缩包（包含新增和修改的），以及不存在的名字列表
     */
    public Pair<byte[], Set<String>> exportProjectJars(String pjUuid, Map<String, String> mapMd5) throws Exception;
  

    /**
     * 导出开源代码包，根据远端MD5判断是否真的需要返回文件内容
     */
    public byte[] exportOpenSource(String md5) throws Exception;
    

    /**
     * 查询工程下，源码的版本记录（仅提交操作才会产生，普通save动作会绕开版本记录）
     * @param projectUuid : 项目的外部Key（例如：JavaProject的UUID）
     * @param fullClassName
     */
    public List<VersionNode> queryFileHistory(String projectUuid, String fullClassName) throws Exception;
    

    /**
     * 获取某代码的历史版本
     * 
     * @param versionNodeUuid ： 版本节点的UUID
     */
    public CJavaCode getHistoryCode(String versionNodeUuid) throws Exception;
    

    /**
     * 获取某资源文件的历史版本
     *  
     * @param versionNodeUuid ： 版本节点的UUID
     */
    public CResFileDto getHistoryFile(String versionNodeUuid) throws Exception;
    
    /**
     * 查工程的所有变更历史记录
     * 
     * 按照版本号规约化，一个版本号一条记录，只拿到简要信息、时间、注解、提交人等信息
     * 
     * 返回的信息不是真实的版本节点，故不含uuid等精准数据
     * 
     * @param extProjectKey : 项目的外部Key（例如：JavaProject的UUID）
     */
    public List<VersionNode> queryVersionList(String extProjectKey) throws Exception;
    

    /**
     * 查询某个具体版本号对应提交的变更记录
     * 
     * @param extProjectKey : 项目的外部Key（例如：JavaProject的UUID）
     * @param versionNo ：版本号
     * @param withData ：是否查出提交的具体数据内容
     */
    public List<VersionNode> queryVersionDetail(String extProjectKey, long versionNo, boolean withData) throws Exception;
    

    /**
     * 查询所有在册Cell实现类（通常为服务类）在DAO里存的动态配置（不仅限于插件CELL，静态系统CELL的配置也支持动态配）
     * 
     * 返回Key=Cell实现类的类名，Value=DAO中存的动态配置对象
     */
    public Map<String, CellConfig> queryCellDaoConfig() throws Exception;
    
    /**
     * 保存CELL的动态配置（支持静态CELL以及插件CELL），但不会立即生效，只是入库
     * 要生效，必须重启某个服务，或者重新发布插件（触发服务全重启）
     */
    public void saveCellDaoConfig(Map<String, CellConfig> mapCfg) throws Exception;
    

    /**
     * 获取工程的制成品信息（用于发布到云仓库）
     */
    public ArtifactDefine getArtifactInfo(String pjUuid) throws Exception;

    /**
     * 编辑工程的制成品信息（用于发布到云仓库）
     *
     * ArtifactDefine 内slaveTable保存依赖目标 
     */
    public ArtifactDefine saveArtifactInfo(ArtifactDefine def) throws Exception;
    
    public String getYunStoreUri() throws Exception;
    
    /**
     * 将工程（JAVA）发布到云仓库中，成为仓库公共组件
     * 默认的云仓库的URI配置在YunStoreConst中定义
     * 
     * @param yunUser : 云仓库的用户（云仓库的用户才有权发布云组件）
     */
    public void publishYunStore(String pjUuid, UserPassword yunUser) throws Exception;
    

    /**
     * 直接调用云仓库接口, 发布云组件
     */
    public void publishYunArtifact(ArtifactPackage pkg, UserPassword yunUser) throws Exception;
    
    /**
     * 查询云端组件
     */
    public MultiPageResult<ArtifactWare> queryYunArtifact(Cnd cnd, CPager pager, String ... fields) throws Exception;
    
    /**
     * 查询云端组件
     * 
     * includeDepend ： 是否查出依赖，并加入到slaveTable里
     * fields : 默认传ArtifactWare.FIELDS_BRIEF
     */
    public ArtifactWare queryYunArtifact(String groupId, String artifactId, String version, boolean includeDepend, String ... fields) throws Exception;
    
    /**
     *  在云仓库中查询整颗依赖树，关系中src -> dst代表 A 依赖于 B
     *  例如：TestRedis -> IRedis
     *  
     *  @param querySourceArtifact : 是否顺带把源端对象也查出来，默认建议一同查出
     */
    public ArtifactGraph queryYunDependGraph(Set<String> leafArts, boolean querySourceArtifact) throws Exception;
    
    /**
     * 查询全局依赖设定（对云仓库的依赖）
     */
    public GlobalDependSetting queryGlobalDepends() throws Exception;
    
    /**
     * 全量存储全局依赖列表（对云仓库的依赖）
     */
    public void saveGlobalDepend(IProgress prog, GlobalDependSetting globalDep) throws Exception;

    /**
     * 全量存储全局依赖列表（对云仓库的依赖）
     */
    public CPluginProjectDto saveGlobalDepend(IProgress prog, GlobalDependSetting globalDep, GlobalDependObserver observer) throws Exception;
    
    /**
     * 查询显式安装（导入）的云组件（挂在全局插件root下）
     */
    public List<ArtifactDefine> queryInstalledArtifacts(boolean excludeLocalArtifact) throws Exception;

    /**
     * 查询是否安装了某个应用（显式安装） 
     */
    public boolean isInstalledArtifacts(String groupId, String artifactId) throws Exception;

    /**
     * 从云仓库下载，并安装指定版本的预制件
     * 
     * 返回true，表示新安装或者变更了版本
     * 返回false，表示本来就安装了，什么动作都没做
     * 
     * waitPublish : 等待发布完成的超时时长（ms），如果为<=0则表示不等待，立即返回
     */
    public boolean installArtifact(IProgress prog, ArtifactDefine art, long waitPublish) throws Exception;
    
    /**
     * 卸载已安装的云组件
     * 
     * 返回是否卸载干净（如果该组件被别人依赖，那么只会删掉显式导入的记录，而实际存在于插件包中）
     * 
     * 返回false：没有卸载干净（从显式安装转为隐含导入了）
     * 返回true：表示卸载干净
     * 
     * waitPublish : 等待发布完成的超时时长（ms），如果为<=0则表示不等待，立即返回
     */
    public boolean uninstallArtifact(IProgress prog, ArtifactDefine art, long waitPublish) throws Exception;
    
    /**
     * 从云仓库中下载并创建为本地工程（不自动重建全局依赖，需外部自行处理）
     * 
     * 导入工程成功以后，会自动导入相关模型（存在失败的风险），此时需人工介入，看看模型为啥不兼容，无法导入
     */
    public CJavaProjectDto importYunProject(IProgress prog, ArtifactWare artWare, UserPassword yunUser) throws Exception;

    public CSession loginYunStore(UserPassword yunUser) throws Exception;
    
    public List<String> scanLocalFiles(String ... folder);
    
    /**
     * 利用MAVEN下载组件包（含依赖包），然后发布到云仓库中
     * 主控所在环境需要安装maven客户端才行
     * 
     * @param prog ：进度
     * @param mvnArt ：需要下载的maven组件描述
     * @param yunUser ：云仓库的用户密码
     * @return 返回导入的组件依赖树信息
     */
    public String downloadMavenArtifact(IProgress prog, MvnArt mvnArt, UserPassword yunUser) throws Exception;
    
    public List<CJavaVirtualProjectDto> getAllVirtualProjects() throws Exception;
    
    // 从云端导入工程到虚拟工程里(仅供查看/比对)
    public CJavaVirtualProjectDto importYunVirtualProject(IProgress prog, ArtifactWare artWare, UserPassword yunUser) throws Exception;
    
    /**
     * 复杂条件查询批量版本数据
     * 样例如下:
     *   Cnd cnd = Cnd.where(VersionNode.ForeignKey, "=", pj.getUuid());
            cnd.and(VersionNode.Key, "=", nodeKey);
            cnd.desc(VersionNode.VersionNo);
     */
    public MultiPageResult<VersionNode> queryNodeLogs(String extProjectKey, Cnd cndWhere, CPager pager, String ... fields) throws Exception;
    

    /**
     * 扫描平台启动jar（ClassPath）中的类
     * 和当前插件包加载的类，有哪些冲突的，返回冲突的列表，key为类全名，value为冲突类的来源
     */
    public Map<String, List<ClassNameInfo>> scanConflictPluginClass(IProgress prog) throws Exception;
}
