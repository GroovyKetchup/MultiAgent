package bap.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;

import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.IntRange;
import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.SrvProgressIntf;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.common.util.javac.LvCompileUnit;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.common.util.javac.LvJavac.LvCompileResult;

import bap.client.BapClient;

public abstract class CJavaRpcCompiler extends CJavaGuiCompiler
{
    volatile LvCompileResult _tmpCResult = null;
    ReentrantLock _localCmpLock = new ReentrantLock();
    protected volatile boolean _requireLocalBuild = true;
    LazyPool _lazyLocalCmp = new LazyPool(500)
    {
        public void handle(List objects)
        {
            localTmpCompile();
        }
    };
    
    
    public long getAutoCompileInterval()
    {
        return Long.MAX_VALUE;
    }
    
    public void localTmpCompile()
    {
        _localCmpLock.lock();
        try
        {
            if (!_requireLocalBuild)
                return;
            
            _compiler = new LvJavac();
            _compiler.setClassLoader(ClassFactory.newValidClassLoader());
            List<ICompilationUnit> lst = new ArrayList<ICompilationUnit>();
            LvCompileUnit unit = new LvCompileUnit(getCode().toCharArray(), getOriginalCode().getFilePath(), "UTF-8");
            lst.add(unit);
            _tmpCResult = _compiler.compile(false, lst);
        } catch (Throwable err)
        {
            err.printStackTrace();
        }finally
        {
            _requireLocalBuild = false;

            _localCmpLock.unlock();
        }
    }
    
    public void requireCompile()
    {
        super.requireCompile();
        
        updateChangeTime();
    }
    
    protected void updateChangeTime()
    {
        _localCmpLock.lock();
        try
        {
            _requireLocalBuild = true;
        }finally
        {
            _localCmpLock.unlock();
        }
//        
//        _lazyLocalCmp.add(System.currentTimeMillis());
    }
    
    public boolean hasImport(ClassNameInfo classInfo)
    {
        localTmpCompile();
        
        if (_compiler != null)
            return _compiler.hasImport(classInfo);
        
        // 默认true，是为了不让随便自动新增import
        return true;
    }
    
    public int checkAutoImport(ClassNameInfo classInfo)
    {
        if (hasImport(classInfo))
            return 0;

        return getLastImportPosition();
    }
    
    // 返回最后一行导入语句的末尾位置。如果没有导入语句则返回package定义的行尾。如果也没有则返回0。
    public int getLastImportPosition()
    {
        return _compiler.getLastImportPosition();
    }
    
    public void forceCompile()
    {
        // 不做任何事，调用这里都是界面有输入需要带出的地方
        // 这里的机制在带出计算时内部会编译，所以不能强制编译两次
    }
    
    protected synchronized void doCompile() throws Throwable
    {
        try
        {
            callOnBeginCompile();

            CJavaCode newCode = ToolUtilities.clone(getOriginalCode());
            String sCode = getCode();
            newCode.setCode(sCode);
            
            // 这里是用来编译界面临时修改的代码的最新结果，不能用缓存也不入缓存
            List lstProbs = BapClient.getJavaIntf().compileSingleCode(newCode, false);
            _isCompiledOK = true;
            callOnCompileFinished(lstProbs);
        } catch (Throwable err)
        {
            err.printStackTrace();
        }
    }
    
    public abstract CJavaCode getOriginalCode();
    
    public Map<String, Object> searchClass(int iLineStart, String sPreFix, int iCurrentPos)
    {
        try
        {
            CJavaCode newCode = ToolUtilities.clone(getOriginalCode());
            newCode.setCode(getCode());
            return BapClient.getJavaIntf().searchClass(newCode, sPreFix, iCurrentPos);
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }
    
    public Map<String, Object> searchMethodField(int iLineStartPos, int iCurrentPos, String sPreFix, final String sTotalPreword)
    {
        try
        {
            CJavaCode newCode = ToolUtilities.clone(getOriginalCode());
            String sCode = getCode();
            newCode.setCode(sCode);
            return BapClient.getJavaIntf().searchMethodField(newCode, sTotalPreword, iCurrentPos);
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }
    
    public List<CodeDeclareInfo> querySyntaxTree() throws Exception
    {
        try
        {
            CJavaCode newCode = ToolUtilities.clone(getOriginalCode());
            newCode.setCode(getCode());
            return BapClient.getJavaIntf().querySyntaxTree(newCode);
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }
    
    public CodeDeclareInfo searchDeclaration(String selString, int currPos)
    {
        try
        {
            CJavaCode newCode = ToolUtilities.clone(getOriginalCode());
            newCode.setCode(getCode());
            return BapClient.getJavaIntf().searchDeclaration(newCode, selString, currPos);
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }
    
    public  SrvProgressIntf<List<CodeDeclareInfo>> searchSyntaxReference(String selString, int currPos)
    {
        try
        {
            CJavaCode newCode = ToolUtilities.clone(getOriginalCode());
            newCode.setCode(getCode());
            return BapClient.getJavaIntf().searchSyntaxReference(newCode, selString, currPos);
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }

    public String generateMethodCode(String classN, String funcName, List<Pair<String, String>> lstParam) throws Exception
    {
        return BapClient.getJavaIntf().generateMethodCode(getOriginalCode().getProjectUuid(), classN, funcName, lstParam);
    }

    public CodeDeclareInfo getSyntaxBindingType(int currPos)
    {
        try
        {
            CJavaCode newCode = ToolUtilities.clone(getOriginalCode());
            String sCode = getCode();
            newCode.setCode(sCode);
//            return dfcutil.getDfcIntf().getSyntaxBindingType(newCode, currPos);
            return null;
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }
    
    public CodeDeclareInfo getSyntaxMeaning(int currPos)
    {
        try
        {
            CJavaCode newCode = ToolUtilities.clone(getOriginalCode());
            String sCode = getCode();
            newCode.setCode(sCode);
//            return dfcutil.getDfcIntf().getSyntaxMeaning(newCode, currPos);
            return null;
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }
    
    public IntRange locateDeclaration(CodeDeclareInfo dec)
    {
        localTmpCompile();
        
        return _compiler.locateDeclaration(dec, true);
    }
}
