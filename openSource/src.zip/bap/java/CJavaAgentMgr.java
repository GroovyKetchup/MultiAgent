package bap.java;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import org.eclipse.jdt.internal.compiler.ClassFile;
import org.eclipse.jdt.internal.compiler.CompilationResult;
import org.nutz.repo.cache.simple.LRUCache;

import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.LvCompileUnit;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.common.util.javac.LvJavac.LvCompileResult;
import com.leavay.nio.crpc.CRpcServer;

import bap.java.debug.CJavaDebugCenterIntf;
import bap.java.debug.CJavaDebugger;
import bap.java.debug.CJavaLocalDebuger;
import bap.java.debug.NoDebuggerException;
import ms.cmn.HostPort;

/**
 * 专用于在代理端，提供JAVA开发、远程调试等服务功能，主要是调试
 * 代理端内部也会和CJavaCenter类似管理一堆调试Key和调试器的mapping，并完成调试启动、信息查询等工作 
 *
 */
public class CJavaAgentMgr implements CJavaDebugCenterIntf
{
    protected static CJavaAgentMgr _me;
    public static synchronized CJavaAgentMgr getMe()
    {
        if (_me == null)
            _me = new CJavaAgentMgr();
        return _me;
    }
    
    protected CJavaAgentMgr()
    {
        
    }
    
    public void start()
    {
        CRpcServer.registService(CJavaDebugCenterIntf.class, this);
    }
    
    public String startDebugJava(CJavaCode code, HostPort agent) throws Exception
    {
        return ToolUtilities.allockUUID();
    }

    
    public int getStatus(String debugKey) throws NoDebuggerException
    {
        return prepareDebuger(debugKey).getStatus();
    }

    public boolean isException(String debugKey) throws NoDebuggerException
    {
        return prepareDebuger(debugKey).isException();
    }
    
    public Object getResult(String debugKey) throws NoDebuggerException
    {
        return prepareDebuger(debugKey).getResult();
    }

    public String getResultText(String debugKey) throws NoDebuggerException
    {
        return prepareDebuger(debugKey).getResultText();
    }

    public List<String> popTrace(String debugKey) throws NoDebuggerException
    {
        return prepareDebuger(debugKey).popTrace();
    }

    // 不能及时清理，因为前台考轮询拿调试信息，所以只能用排队抛弃的缓存机制
    LRUCache<String, CJavaLocalDebuger> _mapDebugger = new LRUCache(100);
    
    // 代理上执行，只会重新编译单个传入的code，其它类沿用插件包的二进制
    // 所以有可能和在主控上的工程环境下调试不一样的效果
    public String startDebugJava(CJavaCode code, HostPort agent, int dependType) throws Exception
    {
        // 本地分配
        CJavaLocalDebuger dbg = new CJavaLocalDebuger();
        _mapDebugger.put(dbg.getUuid(), dbg);
        
        // 根据调试依赖类型，决定使用哪个ClassLoader用于调试
        LvClassLoader loader;
        switch (dependType)
        {
        case CJavaConst.DEPEND_ISOLATE:
            loader = new LvClassLoader();
            break;
        case CJavaConst.DEPEND_PLUGIN:
            loader = ClassFactory.newValidClassLoader();
            break;
        case CJavaConst.DEPEND_PLATFORM:
            loader = new LvClassLoader(ClassFactory.getBasicClassLoader());
            break;
        default:
            loader = ClassFactory.newValidClassLoader();
        }

        // 本地编译、启动
        loader = compileOneCode(code, loader);
        dbg.startDebug(code, loader, dbg);
        
        return dbg.getUuid();
    }
    
    public LvClassLoader compileOneCode(CJavaCode code, LvClassLoader loader) throws IOException
    {
        LvJavac compiler = new LvJavac();
        compiler.setClassLoader(loader);
        LvCompileResult result = compiler.compile(new LvCompileUnit(code.getCode().toCharArray(), code.getFilePath(), code.getFileEncoding()));

        // 开始写入class文件，这个要加写锁了
        for (Entry<String, CompilationResult> entry : result.getResults().entrySet())
        {
            for (ClassFile clsFile : entry.getValue().getClassFiles())
            {
                loader.addClassByte(LvJavac.compoundChar2String(clsFile.getCompoundName(), "."), LvJavac.saveClassFile(clsFile, code.getUuid()));
            }
        }
        
        return loader;
    }
    
    public CJavaDebugger prepareDebuger(String key) throws NoDebuggerException
    {
        CJavaDebugger dbg = _mapDebugger.get(key);
        if (dbg == null)
            throw new NoDebuggerException();
        return dbg;
    }

    public void terminateDebug(String debugKey, long killTime) throws Exception
    {
        CJavaDebugger dbg = _mapDebugger.get(debugKey);
        if (dbg != null)
        {
            dbg.terminateDebug(killTime);
        }
    }
    
    // 代理侧只存在本地调试器，不会再次桥接到Rmt调试，所以这里的处理相对Center上简单一些，只考虑CJavaLocalDebuger
    public List<CJavaDebuggerDto> getAllDebugger(boolean onlyAlive)
    {
        List<CJavaDebuggerDto> lst = new LinkedList<CJavaDebuggerDto>();
        for (Entry<String, CJavaLocalDebuger> ent : _mapDebugger.getAll())
        {
            CJavaDebugger dbg = ent.getValue();
            
            int status = dbg.getStatus();
            
            // 过滤掉结束或出错的
            if (onlyAlive)
            {
                if (status == CJavaConst.STATUS_ERROR || status == CJavaConst.STATUS_FINISHED)
                    continue;
            }
            

            CJavaDebuggerDto dto = new CJavaDebuggerDto();
            dto.setUuid(dbg.getUuid());
            dto.setName(dbg.getName());
            dto.setStartTime(dbg.getStartTime());
            dto.setRunningOn(new HostPort().setHost(ToolBasic.getCurrentIP()).setPort(CRpcServer.getNioPort()));
            dto.setClientInfo(dbg.getClientInfo());
            dto.setStatus(status);
            
            if (dbg.isException())
                dto.setErrorMsg(dbg.getResultText());
            lst.add(dto);
        }
        
        return lst;
    }
}
