package bap.java;

import com.leavay.jmxfw.util.STApplication;

import bap.java.project.CJavaCenter;
import bap.plugin.mgr.CPluginCenter;

// 用于在DNS平台启动JAVA Center（不支持新的插件中心CPlugin Center）
public class CJavaCenterApp extends STApplication
{
    public CJavaCenterApp(String name)
    {
        super(name);
    }
    
    protected void initService() throws Exception
    {
        super.initService();
        
        
        // 这里比较特殊，在DNS中只能初始化模型，不可以启动CPluginCenter
        CPluginCenter.initDaoModel();
        
        CJavaCenter.getMe().initBeforeDao();
        
        // 当做调试代理启动调试管理器
        CJavaAgentMgr.getMe().start();
    }
    
    protected void startService() throws Exception
    {
        CJavaCenter.getMe().start();
    }
}
