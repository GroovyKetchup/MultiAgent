package bap.java;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.net.URI;
import java.util.List;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.text.BadLocationException;

import org.eclipse.jdt.core.compiler.CategorizedProblem;
import org.mvel2.ast.Pos;

import com.leavay.client.util.EventQ.GuiEvent;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.IntRange;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.ProgressControllerFEImpl;
import com.leavay.common.util.ProgressCtrl.ProgressCtrlUtil;
import com.leavay.common.util.ProgressCtrl.SrvProgressIntf;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.common.util.javac.LvBreakpoint;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.dfc.gui.AllGuiEvents;
import com.leavay.dfc.gui.javaDev.SyntaxReferenceTree;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.NoServiceSupportException;
import com.project.gui.Javac.JavaEditor;
import com.project.gui.Javac.JavaGuiCompiler;
import com.project.gui.MvelEditor.ide.JOutputPanel;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import bap.client.BapClient;
import bap.client.BapGuiConst;
import bap.client.BapGuiUtil;
import bap.java.debug.CJavaDebugClient;
import bap.java.debug.CJavaDebugGuiIntf;
import tiny.service.client.TsAgentMgrPanel;
import tiny.service.md.TsAgentDo;

public class CJavaEditor extends JavaEditor implements ActionAdapter, CJavaDebugGuiIntf
{
    private static final long serialVersionUID = 9000815025972387296L;

    protected JMenuItem jMItem_ShowInTree = GuiUtil.createMenuItem(GuiUtil.getString("Select On Tree"), GuiResource.getIcon("dfc/synchronize.png"), this);
    protected JMenuItem jMItem_Debug = GuiUtil.createMenuItem(GuiUtil.getString("Execute"), GuiResource.getIcon("dev/run.png"), this);
    protected JMenuItem jMItem_DebugInLast = GuiUtil.createMenuItem(GuiUtil.getString("Execute(Last Agent)"), GuiResource.getIcon("dev/run.png"), this);
    protected JMenuItem jMItem_Stop = GuiUtil.createMenuItem(GuiUtil.getString("Terminate"), GuiResource.getIcon("stop_16.png"), this);
    
    public CJavaEditor(JavaGuiCompiler compiler)
    {
        super(ClassFactory.getClassInfoQuery(), compiler);
    }
    
    boolean _isNew = false;
    public boolean isNew()
    {
        return _isNew;
    }
    
    public void setIsNew(boolean isNew)
    {
        this._isNew = isNew;
    }

    public CJavaEditor()
    {
        super(ClassFactory.getClassInfoQuery(), null);
        
        setCompiler(new CJavaRpcCompiler()
        {
            protected void OnCompileFinish(List<CategorizedProblem> problems)
            {
                CJavaEditor.this.OnCompileFinish(problems);
            }
            
            public void OnBeginCompile()
            {
                
            }
            
            public CJavaCode getOriginalCode()
            {
                return CJavaEditor.this.getOrignalCode();
            }
        });
        jbInit();
    }
    
    public void OnCompileFinish(List<CategorizedProblem> problems)
    {
        super.OnCompileFinish(problems);
        
        boolean hasError = false;
        boolean hasWarn = false;
        for (CategorizedProblem p : problems)
        {
            if (p.isError())
            {
                hasError = true;
                break;
            }else if (p.isWarning())
                hasWarn = true;
        }

        if (hasError)
            getDockKey().setIcon(GuiResource.getIcon("dev/java_error.png"));
        else if (hasWarn)
            getDockKey().setIcon(GuiResource.getIcon("dev/java_warn.png"));
        else
            getDockKey().setIcon(GuiResource.getIcon("dev/java.png"));
    }
    
    protected void jbInit()
    {
        super.jbInit();
        getDockKey().setCloseEnabled(true);
    }

    public void initGuiEventLsnr()
    {
        super.initGuiEventLsnr();
        BapGuiUtil.removeGuiListenerOfComponent(this);

        BapGuiUtil.addListener(BapGuiConst.SHOW_JAVA_DECLARATION, this, "OnEvtShowDeclaration");
        BapGuiUtil.addListener(BapGuiConst.SELECT_CJAVA_CODE, this, "OnEvtSelectCode");
        BapGuiUtil.addListener(BapGuiConst.SHOW_CJAVA_LINE, this, "OnEvtShowLine");
        
        GuiUtil.setGlobalKeyAction(this, KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK, new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                OnSave();
            }
        });
    }
    
    public boolean isLineBreakPoint(int iLine)
    {
        return false;
    }
    
    URI _lastSelAgent = null;
    public boolean preparePopupMenu(JPopupMenu popMenu)
    {
        if (popMenu.getComponentCount() <= 0)
        {
            popMenu.add(jMItem_ShowInTree);
            popMenu.addSeparator();
            popMenu.add(jMItem_Debug);
            if (_lastSelAgent != null)
            {
                jMItem_DebugInLast.setText(GuiUtil.getString("Execute On")+"("+_lastSelAgent+")");
                popMenu.add(jMItem_DebugInLast);
            }
        }
        else
        {
            popMenu.add(jMItem_ShowInTree, popMenu.getComponentCount() - 1);
            popMenu.add(new JPopupMenu.Separator(), popMenu.getComponentCount() - 1);
            popMenu.add(jMItem_Debug, popMenu.getComponentCount() - 1);
            if (_lastSelAgent != null)
            {
                jMItem_DebugInLast.setText(GuiUtil.getString("Execute On")+"("+_lastSelAgent+")");
                popMenu.add(jMItem_DebugInLast, popMenu.getComponentCount() - 1);
            }
            if (_code != null && hasDebuggerKey())
                popMenu.add(jMItem_Stop, popMenu.getComponentCount() - 1);
            popMenu.add(new JPopupMenu.Separator(), popMenu.getComponentCount() - 1);
        }
        
        return true;
    }

    public void OnToggleBreakpoint(String fullCl, int iLineNo, boolean isNewBP)
    {
        try
        {
            LvBreakpoint bk = createBreakpoint(iLineNo);
            
//            if (isNewBP)
//                JavaGuiDebugger.getInstance().addBreakpoint(bk);
//            else
//                JavaGuiDebugger.getInstance().removeBreakpoint(bk);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
        }
    }
    
    public LvBreakpoint createBreakpoint(int iLineNo)
    {
        LvBreakpoint bk = new LvBreakpoint(getMainClass(), iLineNo, getSourceKey());

        try
        {
            // 分析是否内嵌类，并拿到内嵌类信息
            int pos = jCodePanel.getDefiDoc()._getLineStartByLineNum(iLineNo);
            CodeDeclareInfo codeDef = getCompiler().getSyntaxMeaning(pos);
            if (codeDef != null && codeDef.getDeclareClass() != null)
            {
                String absClass = codeDef.getDeclareClass();
                if (!ToolUtilities.isStringEqual(getMainClass(), absClass) 
                        && (absClass.startsWith(getMainClass() + "$") || absClass.startsWith(getMainClass() + "#")))
                    bk.setNestedClass(absClass);
            }
        } catch (Throwable err)
        {
            err.printStackTrace();
        }

        return bk;
    }
    
    public void OnKeyF6(KeyEvent e)
    {
        OnStepOut();
    }
    
    public void OnKeyF7(KeyEvent e)
    {
        OnStepInto();
    }
    
    public void OnKeyF8(KeyEvent e)
    {
        OnStepOver();
    }
    

    public void OnKeyF9(KeyEvent e)
    {
        if (OnResumeDebug(e.isControlDown())) // 基本废弃
            return;
        
        startDebugOnCenter();
    }
    
    public void OnKeyF10(KeyEvent e)
    {
        try
        {
            startDebug(false);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
        }
    }
    
    public void OnKeyF11(KeyEvent e)
    {
        try
        {
            startDebug(true);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
        }
    }
    
    public void OnKeyF4(KeyEvent e)
    {
        try
        {
            startDebug(true);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
        }
    }
    
    public void startDebugOnCenter()
    {
        try
        {
            CJavaCode code = getCodeFromGui();
            startDebugOn(code, null);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
        }
    }
    
    public void startDebug(boolean forceSelectAgent) throws Exception
    {
        List<TsAgentDo> lstSel = null;
        if (forceSelectAgent || _lastSelAgent == null)
        {
            try
            {
                TsAgentMgrPanel agtPanel = new TsAgentMgrPanel() {
                    public void OnDbclickTable()
                    {
                        // 双击触发选择OK
                        JSimpleDialog dlg = (JSimpleDialog) GuiUtil.getWindowForComponent(this);
                        dlg.OnBtnOK();
                    }
                };
                agtPanel.getToolBar().setVisible(false);
                
                JSimpleDialog dlg = GuiUtil.createSimpleDialog(agtPanel, this);
                dlg.setTitle("Select debug target agent. None selection means center server.");
                dlg.pack();
                if (!dlg.showModel(true))
                    return;

                lstSel = agtPanel.getSelectAgents();
                if (CmnUtil.isObjectEmpty(lstSel))
                    _lastSelAgent = null;
                else
                    _lastSelAgent = CmnUtil.buildWsUri(lstSel.get(0).getMyUri());
            } catch (Throwable err)
            {
                if (!ToolBasic.isCausedBy(err, NoServiceSupportException.class))
                    DetailErrorMsg.showError(this, "Failed to load MS agent list! Will excecute on center server!", err);
            }
        }
        
        CJavaCode code = getCodeFromGui();
        if (CmnUtil.getObjectSize(lstSel) <= 1)
            startDebugOn(code, _lastSelAgent);
        else
        {
            if (!GuiUtil.showConfirmWarn(this, "Do you want to start debug on all selected agents?", "Warning"))
                return;
            
            for (TsAgentDo agt : lstSel)
            {
                startDebugOn(code, CmnUtil.buildWsUri(agt.getMyUri()));
            }
        }
    }
    
    // null 表示主控
    public void startDebugOn(CJavaCode code, URI selectAgentUri) throws Exception
    {
        setDebuggerKey(CJavaDebugClient.getMe().startDebugJava(this, code, selectAgentUri));
    }
    
    public CJavaCode getCodeFromGui() throws Exception
    {
        CJavaCode code = _code!=null?ToolUtilities.clone(_code):new CJavaCode();
        code.setCode(getCode());
        code.setMainClass(getMainClass());
        
        return code;
    }
    
    CJavaCode _code;
    
    public void showCode(String pjUuid, String fullClassName) throws Exception
    {
        CJavaCode code = BapClient.getJavaIntf().getJavaCode(pjUuid, fullClassName);
        showCode(code);
    }
    
    public void showCode(CJavaCode code)
    {
        _code = code;
        
        getDockKey().setKey(code.getUuid());
        getDockKey().setName(code.getMainClass());
        
        setCode(code.getKey(), code.getCode());
        setMainClass(code.getMainClass());
    }
    
    public CJavaCode getOrignalCode()
    {
        return _code;
    }
    
    public void OnStepOut()
    {
        if (!hasDebuggerKey())
            return;
        try
        {
//            JavaGuiDebugger.getInstance().stepOut( getDebugKey());
        } catch (Throwable err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    public void OnStepInto()
    {
        if (!hasDebuggerKey())
            return;
        try
        {
//            JavaGuiDebugger.getInstance().stepInto( getDebugKey());
        } catch (Throwable err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    public void OnStepOver()
    {
        if (!hasDebuggerKey())
            return;
        try
        {
//            JavaGuiDebugger.getInstance().stepOver( getDebugKey());
        } catch (Throwable err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    public boolean OnResumeDebug(boolean resumeAll)
    {
        if (!hasDebuggerKey())
            return false;
        
        try
        {
//            if (resumeAll)
//                JavaGuiDebugger.getInstance().resumeAll(getDebugKey());
//            else
//                JavaGuiDebugger.getInstance().resume( getDebugKey());
        }catch(Throwable err)
        {
            DetailErrorMsg.showError(err);
        }
        return true;
    }

    public void OnKeyF12(KeyEvent e)
    {
//        OnSelectDebugTree();
    }
    
    volatile int debugFrameID = -1;
    public int getDebugFrameID()
    {
        return debugFrameID;
    }

    public void setDebugFrameID(int debugFrameID)
    {
        this.debugFrameID = debugFrameID;
    }

//    static JDebugValuePanel inspectPanel = new JDebugValuePanel();
//    public void OnInspectValue(boolean isCtrlDown)
//    {
//        String dbgKey =  getDebugKey();
//        if (dbgKey == null)
//            return;
//        
//        int frameID = getDebugFrameID();
//        
//        String exp = jCodePanel.getSelectedText();
//        int start = jCodePanel.getSelectionStart();
//        int end = jCodePanel.getSelectionEnd();
//        int line = jCodePanel.getCurrentLine();
//        if (start < 0 || end <= start || line < 0 || ToolBasic.isStringEmpty(exp))
//            return;
//        
//        try
//        {
//            if (isCtrlDown)
//                inspectPanel = new JDebugValuePanel();
//            
//            String vKey = JavaGuiDebugger.getInstance().inspectValue(dbgKey, frameID, exp, new LvClassLine(getMainClass(), line), getCode());
//           
//            inspectPanel.showValue(dbgKey, vKey, exp, true);
//     
//
//            if (!isCtrlDown)
//            {
//                inspectPanel.showPopup(this);
//            } else
//            {
//                JSimpleDialog dlg = GuiUtil.createSimpleDialog(inspectPanel, this, true);
//                dlg.pack();
//                dlg.showModel(true);
//            }
//        }catch(Throwable err)
//        {
//            DetailErrorMsg.showError(err);
//        }
//    }
    
//    public void OnSelectDebugTree()
//    {
//        ((DevMainFrame)CNClientUtil.getTopoWindow()).OnOpenJavaDebugTree();
//        
//        dfcutil.fireAsyncGuiEvent(AllGuiEvents.SHOW_JAVA_DEBUG_STACK, getDebugKey(), debugFrameID);
//    }

    public void showRunLine(String debugKey, int line, int frameID) 
    {
        setDebuggerKey(debugKey);
        setDebugFrameID(frameID);
        jCodePanel.showRunPoint(line);
    }
    
    public void clearRunLine()
    {
        setDebugFrameID(-1);
        jCodePanel.showRunPoint(-1);
    }

    public void OnOpenDeclaration() throws Exception
    {
        int currPos = getCodePanel().getCaretPosition();
        int selStart = getCodePanel().getSelectionStart();
        if (selStart >= 0)
            currPos = selStart;
        
        String sSelString = getCodePanel().getSelectedText();
        if (ToolUtilities.isStringEmpty(sSelString))
        {
            Pos posText = getTextWordAtPos(currPos);

            try
            {
                if (posText != null)
                    sSelString = getCodePanel().getText(posText.getStart(), posText.getEnd() - posText.getStart());
            } catch (BadLocationException exp)
            {
                return;
            }
        }

        CodeDeclareInfo dec = getCompiler().searchDeclaration(sSelString, currPos);
        if (dec == null)
            return;

        CJavaCode code=null;
        if (!dec.isType())
        {
            // 除了本地已经打开的之外，不可能了
            code = getOrignalCode();
        } else
        {
            String sFullClassName = dec.getName();
            sFullClassName = LvJavac.getMainClassName(sFullClassName);
            if (ToolUtilities.isStringEqual(sFullClassName, getMainClass()))
            {
                code = getOrignalCode();
            }
            else
            {
                List<CJavaCode> lstCode= BapClient.getJavaIntf().searchCode(sFullClassName);
                if (!ToolUtilities.isObjectEmpty(lstCode))
                {
                    code = lstCode.get(0);
                }
            }
        }
        

        if (code != null)
        {
            BapGuiUtil.openCode(code.getProjectUuid(), code.getFullClassName());
            BapGuiUtil.fireAsyncGuiEvent(BapGuiConst.SHOW_JAVA_DECLARATION, code.getUuid(), dec);
        }
        else
            OpenExtDeclaration(dec);
        
    }
    
    public void OpenExtDeclaration(CodeDeclareInfo dec) throws Exception
    {
//        SvGuiUtil.gotoJavaDeclaration(dec); 
//        JOptionPane.showMessageDialog(this, dec.toLogString());
    }
    
    public String getMainClass()
    {
        return _code.getMainClass();
    }
    
    public String getSourceKey()
    {
        return _code.getKey();
    }

    public String getConsoleKey()
    {
        return _code.getFullClassName();
    }
    
    public void trace(List<String> lstTrace)
    {
        if (CmnUtil.isObjectEmpty(lstTrace))
            return;
        
        StringBuffer sb = new StringBuffer();
        for (String s : lstTrace)
            sb.append(s).append("\n");
        
        BapGuiUtil.fireAsyncGuiEvent(AllGuiEvents.PRINT_DEBUG_CONSOLE, getConsoleKey(), sb.toString(), JOutputPanel.MSG_TYPE_TRACE);
    }

    public void OnFinish(String key, Object result)
    {
        BapGuiUtil.fireAsyncGuiEvent(AllGuiEvents.PRINT_DEBUG_CONSOLE, getConsoleKey(), "\nRETURN : " + ToolUtilities.logString(result, 100, false), JOutputPanel.MSG_TYPE_NORMAL);
    }

    public void OnError(String key, Throwable err)
    {
        BapGuiUtil.fireAsyncGuiEvent(AllGuiEvents.PRINT_DEBUG_CONSOLE, getConsoleKey(), ToolUtilities.getExceptionStatck(err, true), JOutputPanel.MSG_TYPE_ERROR);
    }

    public void OnBegin(String key)
    {
        BapGuiUtil.fireAsyncGuiEvent(AllGuiEvents.CLEAR_DEBUG_CONSOLE, getConsoleKey());
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jMItem_Stop)
            OnStopDebug();
        else if (e.getSource() == jMItem_DebugInLast)
            startDebug(false);
        else if (e.getSource() == jMItem_Debug)
            startDebug(true);
        else if (e.getSource() == jMItem_ShowInTree)
            showInTree();
    }
    
    public void OnStopDebug() throws Exception
    {
        if (!hasDebuggerKey())
            return;
        
        BapClient.getJavaIntf().terminateDebug(getDebugKey(), 5000);
    }
    
    public void showInTree()
    {
        BapGuiUtil.fireAsyncGuiEvent(BapGuiConst.SHOW_CJAVA_CODE_IN_TREE, getOrignalCode().getCodePath());
    }
    
    public void OnKeyCtrl_G(KeyEvent e)
    {
        try
        {
            OnSearchSyntax();
        } catch (Throwable exp)
        {
            DetailErrorMsg.showError(exp);
        }
    }
    
    public void OnKeyCtrl_Alt_F(KeyEvent e)
    {
        Cursor orgCursor = jCodePanel.getCursor();
        GuiUtil.setWaitCursor(jCodePanel);
        try
        {
            CJavaEditor.this.OnSearchText();
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(this, exp);
        }finally
        {
            jCodePanel.setCursor(orgCursor);
        }
    }
    
    public void OnSearchSyntax() throws Exception
    {
        int currPos = getCodePanel().getCaretPosition();
        int selStart = getCodePanel().getSelectionStart();
        if (selStart >= 0)
            currPos = selStart;

        String sSelString = getCodePanel().getSelectedText();
        if (!ToolUtilities.isStringEmpty(sSelString))
            return;

        Pos posText = getTextWordAtPos(currPos);

        try
        {
            if (posText != null)
                sSelString = getCodePanel().getText(posText.getStart(), posText.getEnd() - posText.getStart());
        } catch (BadLocationException exp)
        {
            return;
        }

        ProgressCtrlUtil.getInstance().startProgressDialog(CJavaEditor.this, "", CJavaEditor.this, "_doSearchReference", sSelString, currPos);
    }
    
    public void _doSearchReference(ProgressControllerFEImpl guiProg, String sSelString, int currPos) throws Exception
    {
        SrvProgressIntf<List<CodeDeclareInfo>>  srvProg = getCompiler().searchSyntaxReference(sSelString, currPos);
        List<CodeDeclareInfo> result = (List<CodeDeclareInfo>) ProgressCtrlUtil.startPollingServerProgress(srvProg, guiProg);
        if (!srvProg.isResultOK())
            DetailErrorMsg.showError(srvProg.getException());
        else
        {
            SyntaxReferenceTree tree = new SyntaxReferenceTree();
            tree.showData(getCodeUuid(), result);
            JSimpleDialog dlg = GuiUtil.createSimpleDialog(tree, this);
            dlg.pack();
            dlg.setAlwaysOnTop(true);
            dlg.showModel(false);
        }
    }
    
    public void OnSearchText() throws Exception
    {
        int currPos = getCodePanel().getCaretPosition();
        int selStart = getCodePanel().getSelectionStart();
        if (selStart >= 0)
            currPos = selStart;
        
        
        String sSelString = getCodePanel().getSelectedText();
        if (ToolUtilities.isStringEmpty(sSelString))
        {
            Pos posText = getTextWordAtPos(currPos);

            try
            {
                if (posText != null)
                    sSelString = getCodePanel().getText(posText.getStart(), posText.getEnd() - posText.getStart());
            } catch (BadLocationException exp)
            {
                return;
            }
        }
        
        BapGuiUtil.fireAsyncGuiEvent(BapGuiConst.SEARCH_TEXT_IN_CJAVA_CODE, getOrignalCode().getProjectUuid(), sSelString);
    }
    

    public String getCodeUuid()
    {
        return getOrignalCode()==null?null:getOrignalCode().getUuid();
    }
    
    public void OnEvtShowDeclaration(GuiEvent evt)
    {
        String sUuid = evt.getString(0);
        if (getOrignalCode() != null && !ToolUtilities.isStringEqual(getOrignalCode().getUuid(), sUuid))
            return;
        
        CodeDeclareInfo info = (CodeDeclareInfo) evt.getParam(1);
        if (info == null)
            return;
        
        IntRange iRange = getCompiler().locateDeclaration(info);
        if (iRange == null)
            return;
        
        iRange.setEnd(iRange.getEnd()+1);
        if (false) selectRange(iRange);
        GuiUtil.invokeLater(this, "selectRange", iRange);
    }
    
    public void OnEvtShowLine(GuiEvent evt)
    {
        String sRDN = evt.getString(0);
        if (!ToolUtilities.isStringEqual(getCodeUuid(), sRDN))
            return;
        
        int line = evt.getInt(1);
        selectLine(line);
    }
    
    public void OnEvtSelectCode(GuiEvent evt)
    {
        String sRDN = evt.getString(0);
        if (!ToolUtilities.isStringEqual(getCodeUuid(), sRDN))
            return;
        
        IntRange range = (IntRange) evt.getParam(1);
        if (range == null)
            return;
        
        if (false) selectRange(range);
        GuiUtil.invokeLater(this, "selectRange", range);
    }
    
    public void OnSave() throws Exception
    {
        CJavaCode code = getCodeFromGui();
        _code = BapClient.getJavaIntf().saveJavaCode(code, true);
        
        BapGuiUtil.fireAsyncGuiEvent(BapGuiConst.JAVA_CODE_SAVED, _code);
        if (isNew())
        {
            BapGuiUtil.fireAsyncGuiEvent(BapGuiConst.SHOW_CJAVA_CODE_IN_TREE, _code.getCodePath());
            setIsNew(false);
        }
    }
    
    public void OnExit(String key)
    {
        if (CmnUtil.isStringEqual(key, getDebugKey()))
            setDebuggerKey(null);
    }
}
