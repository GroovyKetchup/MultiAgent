package bap.java;

/**
 * 用来作为UDF的错误信息缓存，省得一个出错的UDF总是反反复复进行编译试做 
 */
public class CUdfErrorBean extends CUdfBean
{
    private static final long serialVersionUID = -8104513420488703188L;
    
    Throwable _error;
    
    public CUdfErrorBean(Throwable err)
    {
        _error = err;
    }

    public Throwable getError()
    {
        return _error;
    }

    public void setError(Throwable error)
    {
        this._error = error;
    }
}
