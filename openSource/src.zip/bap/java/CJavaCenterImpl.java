package bap.java;

import java.net.URI;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.Cnd;

import com.cdao.dto.CPager;
import com.cdao.impl.entity.field.GID;
import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoUtil;
import com.cdao.mgr.CSession;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ProgressCtrl.ChildProgress;
import com.leavay.common.util.ProgressCtrl.ProgressCtrlUtil;
import com.leavay.common.util.ProgressCtrl.SrvProgressIntf;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.CodeCompileException;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.common.util.javac.CodeUtil;
import com.leavay.common.util.javac.CompileStastic;
import com.leavay.common.util.javac.LvProblem;
import com.leavay.common.util.javac.CodeUtil.BasiceClassInfoLoader;
import com.leavay.common.util.javac.CodeUtil.ClassInfoLoader;
import com.leavay.dfc.mgr.javaDev.ClassNameInfoExt;

import art.mvn.MvnArt;
import bap.cells.CellConfig;
import bap.dev.FileDto;
import bap.dev.JavaDto;
import bap.java.debug.NoDebuggerException;
import bap.java.project.CJavaCenter;
import bap.java.project.GlobalDependObserver;
import bap.java.project.LoneWolfConfig;
import bap.java.project.YunProjectImporter;
import bap.md.java.CJavaProject;
import bap.md.java.CJavaVirtualProject;
import bap.md.java.CResFileDo;
import bap.md.ver.VersionNode;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import bap.plugin.CPluginProjectDto;
import bap.plugin.mgr.CPluginCenter;
import bap.udf.UdfMeta;
import bap.version.CVerMgr;
import bap.yun.ArtifactPackage;
import bap.yun.YunStoreAgent;
import cell.bap.yun.ArtifactGraph;
import cmn.security.dto.UserPassword;
import cmn.util.Nulls;
import cplugin.ms.dto.CJarFileDto;
import cplugin.ms.dto.CResFileDto;
import ms.cmn.HostPort;

public class CJavaCenterImpl implements CJavaCenterIntf
{
    private static CJavaCenterImpl _me;
    public synchronized static CJavaCenterImpl get()
    {
        if (_me == null)
            _me = new CJavaCenterImpl();
        return _me;
    }
    
    private CJavaCenterImpl()
    {
        
    }
    public long getDaoTag()
    {
        return CDaoClient.getMe().getClassTimeTag();
    }
    
    public long getPluginTag() throws Exception
    {
        return CPluginCenter.getMe().getPluginTag();
    }
    
    public List<LvProblem> compileSingleCode(CJavaCode code, boolean useCache) throws Exception
    {
        return CJavaCenter.getMe().compileSingleCode(code, useCache);
    }

    public void rebuildAll(String projectUuid) throws Exception
    {
        CJavaCenter.getMe().rebuildAll(projectUuid);
    }

    public List<CJavaCode> searchCode(String fullClass) throws Exception
    {
        return CJavaCenter.getMe().searchCode(fullClass);
    }
    
    public CJavaCode saveJavaCode(CJavaCode newCode, boolean autoCompile) throws Exception
    {
        return CJavaCenter.getMe().saveJavaCode(newCode, autoCompile);
    }

    public Map<String, Object> searchClass(CJavaCode code, String sPreFix, int iCurrentPos) throws Exception
    {
        return CJavaCenter.getMe().searchClass(code, sPreFix, iCurrentPos);
    }
    
    public Map<String, Object> searchMethodField(CJavaCode code, String sTotalPreword, int iCurrentPos) throws Exception
    {
        return CJavaCenter.getMe().searchMethodField(code, sTotalPreword, iCurrentPos);
    }

    public String startDebugJava(CJavaCode code, HostPort agent, int dependType) throws Exception
    {
        return CJavaCenter.getMe().startDebug(code, agent, dependType);
    }

    public List<CodeDeclareInfo> querySyntaxTree(CJavaCode code) throws Exception
    {
        return CJavaCenter.getMe().querySyntaxTree(code);
    }

    public CodeDeclareInfo searchDeclaration(CJavaCode code, String selString, int currPos) throws Exception
    {
        return CJavaCenter.getMe().searchDeclaration(code, selString, currPos);
    }

    public SrvProgressIntf<List<CodeDeclareInfo>> searchSyntaxReference(CJavaCode code, String selString, int currPos) throws Exception
    {
        return CJavaCenter.getMe().searchSyntaxReference(code, selString, currPos);
    }

    public String generateMethodCode(String pjUuid, String classN, String funcName, List<Pair<String, String>> lstParam) throws Exception
    {
        return CJavaCenter.getMe().generateMethodCode(pjUuid, classN, funcName, lstParam);
    }

    public CodeDeclareInfo getSyntaxBindingType(CJavaCode code, int currPos) throws Exception
    {
        return CJavaCenter.getMe().getSyntaxBindingType(code, currPos);
    }

    public CodeDeclareInfo getSyntaxMeaning(CJavaCode code, int currPos) throws Exception
    {
        return CJavaCenter.getMe().getSyntaxMeaning(code, currPos);
    }

    public SrvProgressIntf<List<CodeDeclareInfo>> searchText(String projectUuid, String text) throws Exception
    {
        return CJavaCenter.getMe().searchText(projectUuid, text);
    }

    public CJavaCode getJavaCode(String projectUuid, String fullClassName) throws Exception
    {
        return CJavaCenter.getMe().getJavaCode(projectUuid, fullClassName);
    }

    public String[] getCodePath(String pjUuid, String fullClassName) throws Exception
    {
        return CJavaCenter.getMe().getCodePath(pjUuid, fullClassName);
    }
    
    public Set<String> getAllPackages(String projectUuid, String folderUuid) throws Exception
    {
        return CJavaCenter.getMe().queryPackage(projectUuid, folderUuid);
    }

    public List<CJavaCode> getChildCodeBrief(String projectUuid, String folderUuid, String sPackage)
    {
        return CJavaCenter.getMe().getBuilder_Force(projectUuid).getChildCodeBrief(folderUuid, ToolUtilities.getString(sPackage, ""));
    }

    public CompileStastic getFolderStastic(String projectUuid, String folderUuid)
    {
        return CJavaCenter.getMe().getBuilder_Force(projectUuid).getFolderStastic(folderUuid);
    }

    public CompileStastic getStastic(String projectUuid, String folderUuid, String nameOfPackageOrClass)
    {
        return CJavaCenter.getMe().getBuilder_Force(projectUuid).getStastic(folderUuid, nameOfPackageOrClass);
    }

    public CPluginProjectDto exportProject2Plugin(String projectUuid, String dstPluginProjectName, boolean includeSubJars) throws Exception
    {
        return CJavaCenter.getMe().exportProject2Plugin(projectUuid, dstPluginProjectName, includeSubJars);
    }

    public CPluginProjectDto exportProject2Plugin(String projectUuid, String dstPluginProjectName, boolean includeSubJars, boolean ignoreCompileError) throws CodeCompileException, Exception
    {
        return CJavaCenter.getMe().exportProject2Plugin(projectUuid, dstPluginProjectName, includeSubJars, ignoreCompileError);
    }


    public void grayPublish(String projectUuid, boolean rebuildAll) throws CodeCompileException, Exception
    {
        CJavaCenter.getMe().grayPublish(projectUuid, rebuildAll);
    }
    
    public int getStatus(String debugKey) throws NoDebuggerException
    {
        return CJavaCenter.getMe().getDebugStatus(debugKey);
    }

    public Object getResult(String debugKey) throws NoDebuggerException
    {
        return CJavaCenter.getMe().getDebugResult(debugKey);
    }

    public String getResultText(String debugKey) throws NoDebuggerException
    {
        return CJavaCenter.getMe().getDebugResultText(debugKey);
    }

    public List<String> popTrace(String debugKey) throws NoDebuggerException
    {
        return CJavaCenter.getMe().popDebugTrace(debugKey);
    }

    public void terminateDebug(String debugKey, long killTime) throws Exception
    {
        CJavaCenter.getMe().terminateDebug(debugKey, killTime);
    }

    public List<CJavaProjectDto> getAllProjects() throws Exception
    {
        return CDaoUtil.convertDtos((List)CJavaCenter.getMe().getAllProjects(), CJavaProjectDto.class);
    }

    public List<CJavaFolderDto> getFolders(String pjUuid) throws Exception
    {
        return CDaoUtil.convertDtos((List)CJavaCenter.getMe().getFolders(pjUuid), CJavaFolderDto.class);
    }
    
    public boolean deleteFolder(String pjUuid, String folderUuid) throws Exception
    {
        return CJavaCenter.getMe().deleteFolder(pjUuid, folderUuid);
    }

    public boolean deleteFolderByName(String pjUuid, String folderName) throws Exception
    {
        return CJavaCenter.getMe().deleteFolderByName(pjUuid, folderName);
    }
    
    public boolean deleteCode(String pjUuid, String fullClass, boolean autoCompile) throws Exception
    {
        return CJavaCenter.getMe().getBuilder_Force(pjUuid).deleteCode(fullClass, autoCompile);
    }
    
    public boolean deleteCode(String pjUuid, Set<String> fullClass) throws Exception
    {
        return CJavaCenter.getMe().getBuilder_Force(pjUuid).deleteCode(fullClass);
    }

    public List<CJavaDebuggerDto> getAllDebugger(boolean onlyAlive)
    {
        return CJavaCenter.getMe().getAllDebugger(onlyAlive);
    }

    public boolean isException(String dbgKey) throws NoDebuggerException
    {
        return CJavaCenter.getMe().prepareDebuger(dbgKey).isException();
    }

    public CJavaProjectDto createProject(String name, int dependType) throws Exception
    {
        return CDaoUtil.convertDto(CJavaCenter.getMe().createProject(name, dependType), CJavaProjectDto.class);
    }
    
    public CJavaProjectDto createProject(String name, int dependType, String withNewFolder) throws Exception
    {
        return CDaoUtil.convertDto(CJavaCenter.getMe().createProject(name, dependType, withNewFolder), CJavaProjectDto.class);
    }

    public CJavaFolderDto createFolder(GID pjGid, String name) throws Exception
    {
        return CDaoUtil.convertDto(CJavaCenter.getMe().createFolder(pjGid, name), CJavaFolderDto.class);
    }
    
    public CJavaFolderDto saveFolder(GID pjGid, String name) throws Exception
    {
        return CDaoUtil.convertDto(CJavaCenter.getMe().saveFolder(pjGid, name), CJavaFolderDto.class);
    }

    public void setFolderPrivate(GID folderGid, String privateOwner) throws Exception
    {
        CJavaCenter.getMe().setFolderPrivate(folderGid, privateOwner);
    }
    
    public void deleteProject(GID pjGid) throws Exception
    {
        CJavaCenter.getMe().deleteProject(pjGid);
    }

    public CJavaProjectDto updateProject(GID pjGid, Map<String, Object> mapV) throws Exception
    {
        return CDaoUtil.convertDto(CJavaCenter.getMe().updateProject(pjGid, mapV), CJavaProjectDto.class);
    }

    public List<ClassNameInfoExt> searchCode(String sKey, boolean searchInJar, int countLimit) throws Exception
    {
        return CJavaCenter.getMe().searchCode(sKey, searchInJar, countLimit);
    }

    public CJavaCode getJavaCode(String codeUuid) throws Exception
    {
        return CJavaCenter.getMe().getJavaCode(codeUuid);
    }

    public CJarFileDto importJarFile(GID pjGid, CJarFileDto jar) throws Exception
    {
        return CDaoUtil.convertDto(CJavaCenter.getMe().addJarFile(pjGid, CDaoUtil.convertDo(jar)), CJarFileDto.class);
    }
    
    public CResFileDto importResFile(GID pjGid, CResFileDto file) throws Exception
    {
        return CDaoUtil.convertDto(CJavaCenter.getMe().addResFile(pjGid, CDaoUtil.convertDo(file)), CResFileDto.class);
    }

    public List<CJarFileDto> getJarFiles(String projectUuid) throws Exception
    {
        return CDaoUtil.convertDtos((List)CJavaCenter.getMe().getJarFiles(projectUuid, true), CJarFileDto.class);
    }

    public boolean hasJarFiles(String pjUuid) throws Exception
    {
        return CJavaCenter.getMe().hasJarFiles(pjUuid);
    }

    public void deleteJarFile(GID jarGid) throws Exception
    {
        CJavaCenter.getMe().deleteJarFile(jarGid);
    }

    public String startDebugJava(CJavaCode code, HostPort agent) throws Exception
    {
        return CJavaCenter.getMe().startDebug(code, agent);
    }
    
    public String startDebugJava(CJavaCode code, URI agentUri) throws Exception
    {
        return CJavaCenter.getMe().startDebug(code, agentUri);
    }

    public byte[] exportProject(String projectUuid, Set<String> srcFolderName) throws Exception
    {
        return CJavaCenter.getMe().exportProject(null, projectUuid, srcFolderName, CDaoUtil.getRpcSession());
    }
    
    public void streamExportProject(IProgress<byte[]> prog, String projectUuid, Set<String> srcFolderNames, CSession session) throws Exception
    {
        CJavaCenter.getMe().streamExportProject(prog, projectUuid, srcFolderNames, session);
    }

    public Map<String, JavaDto> queryCodeFile(String projectUuid, String folderName) throws NoFolderException, Exception
    {
        return CJavaCenter.getMe().queryCodeFileMap(projectUuid, folderName);
    }

    public Map<String, FileDto> queryAllFileMap(String projectUuid, String folderName) throws NoFolderException, Exception
    {
        return CJavaCenter.getMe().queryAllFileMap(projectUuid, folderName);
    }
    
    public void commitCode(String projectUuid, CommitPackage pkg) throws Exception
    {
        CJavaCenter.getMe().commitCode(projectUuid, pkg);
    }

    public CSession login(String user, String pwd) throws Exception
    {
        return CDaoClient.loginWithSession(user, pwd);
    }

    public byte[] exportModelFile(long tag) throws Exception
    {
        return CJavaCenter.getMe().exportModelFile(tag);
    }

    public byte[] exportPluginJars(long pluginTag, String projectUuid, Collection<String> srcFolderName) throws Exception
    {
        return CJavaCenter.getMe().exportPluginJars(pluginTag, projectUuid, srcFolderName);
    }

    public FileUpdatePackage exportPluginJars(Map<String, String> clientFileMd5, String projectUuid, Collection<String> srcFolderName) throws Exception
    {
        return CJavaCenter.getMe().exportPluginJars(clientFileMd5, projectUuid, srcFolderName);
    }

    public Pair<byte[], Set<String>> exportPlatformJars(Map<String, String> mapMd5) throws Exception
    {
        return CJavaCenter.getMe().exportPlatformJars(null, mapMd5);
    }
    
    public Set<String> streamExportPlatformJars(IProgress<byte[]> prog, Map<String, String> mapMd5) throws Exception
    {
        return CJavaCenter.getMe().streamExportPlatformJars(prog, mapMd5);
    }

    public Pair<byte[], Set<String>> exportProjectJars(String pjUuid, Map<String, String> mapMd5) throws Exception
    {
        return CJavaCenter.getMe().exportProjectJars(pjUuid, mapMd5);
    }

    public byte[] exportOpenSource(String md5) throws Exception
    {
        return CJavaCenter.getMe().exportOpenSource(md5);
    }

    public List<VersionNode> queryFileHistory(String projectUuid, String fullClassName) throws Exception
    {
        return CJavaCenter.getMe().queryFileHistory(projectUuid, fullClassName);
    }

    public CJavaCode getHistoryCode(String versionNodeUuid) throws Exception
    {
        return CJavaCenter.getMe().getHistoryCode(versionNodeUuid);
    }

    public CResFileDto getHistoryFile(String versionNodeUuid) throws Exception
    {
        return CJavaCenter.getMe().getHistoryFile(versionNodeUuid);
    }

    public List<VersionNode> queryVersionList(String extProjectKey) throws Exception
    {
        return CVerMgr.get().queryVersionList(extProjectKey);
    }

    public List<VersionNode> queryVersionDetail(String extProjectKey, long versionNo, boolean withData) throws Exception
    {
        return CVerMgr.get().queryVersionDetail(extProjectKey, versionNo, withData);
    }

    public List<CResFileDto> getResFiles(String projectUuid, String filterFolderUuid, boolean onlyBrief) throws Exception
    {
        return CDaoUtil.convertDtos((List)CJavaCenter.getMe().getResFiles(projectUuid, filterFolderUuid, onlyBrief), CResFileDto.class);
    }
    
    public CResFileDto getResFile(String projectUuid, String filePath, boolean onlyBrief) throws Exception
    {
        return CDaoUtil.convertDto(CJavaCenter.getMe().getResFile(projectUuid, filePath, onlyBrief), CResFileDto.class);
    }
    
    public List<CResFileDto> queryResFiles(String projectUuid, String filterFolderUuid, String pkg, boolean onlyBrief) throws Exception
    {
        return CDaoUtil.convertDtos((List)CJavaCenter.getMe().queryResFiles(projectUuid, filterFolderUuid, pkg, onlyBrief), CResFileDto.class);
    }

    public CJavaProjectDto getProject(String uuid) throws Exception
    {
        CJavaProject pjDo = CJavaCenter.getProject(uuid);
        if (pjDo instanceof CJavaVirtualProject)
            return CDaoUtil.convertDto(CJavaCenter.getProject(uuid), CJavaVirtualProjectDto.class);
        else
            return CDaoUtil.convertDto(CJavaCenter.getProject(uuid), CJavaProjectDto.class);
    }

    public List<CJavaProjectDto> queryProject(Cnd cnd) throws Exception
    {
        return CDaoUtil.convertDtos(CJavaCenter.queryProject(cnd), CJavaProjectDto.class);
    }

    public Map<String, CellConfig> queryCellDaoConfig() throws Exception
    {
        return CJavaCenter.getMe().queryCellDaoConfig();
    }

    public void saveCellDaoConfig(Map<String, CellConfig> mapCfg) throws Exception
    {
        CJavaCenter.getMe().saveCellDaoConfig(mapCfg);
    }

    public void deleteResFile(GID resGid) throws Exception
    {
        CJavaCenter.getMe().deleteResFile(resGid);
    }

    public void publishYunStore(String pjUuid, UserPassword yunUser) throws Exception
    {
        CJavaCenter.getMe().publishYunStore(pjUuid, yunUser);
    }

    @Override
    public void publishYunArtifact(ArtifactPackage pkg, UserPassword yunUser) throws Exception
    {
        // 先尝试登陆一下云仓库，校验连通性以及用户等，然后再准备打包发布
        YunStoreAgent.getIntf().login(yunUser);
        
        // 调用云仓库接口，发布组件
        YunStoreAgent.get().getIntf().publishArtifact(pkg, yunUser);
    }

    public ArtifactDefine getArtifactInfo(String pjUuid) throws Exception
    {
        return CJavaCenter.getMe().getArtifactInfo(pjUuid);
    }

    public ArtifactDefine saveArtifactInfo(ArtifactDefine def) throws Exception
    {
        return CJavaCenter.getMe().saveArtifactInfo(def);
    }

    public MultiPageResult<ArtifactWare> queryYunArtifact(Cnd cnd, CPager pager, String ... fields) throws Exception
    {
        return YunStoreAgent.getIntf().queryArtifact(cnd, pager, fields);
    }

    public ArtifactWare queryYunArtifact(String groupId, String artifactId, String version, boolean includeDepend, String ... fields) throws Exception
    {
        return YunStoreAgent.get().getIntf().queryArtifact(groupId, artifactId, version, includeDepend, fields);
    }

    public ArtifactGraph queryYunDependGraph(Set<String> leafArts, boolean querySourceArtifact) throws Exception
    {
        return YunStoreAgent.get().getIntf().queryDependGraph(leafArts, querySourceArtifact);
    }

    public GlobalDependSetting queryGlobalDepends() throws Exception
    {
        return CJavaCenter.getMe().queryGlobalDepends();
    }

    public void saveGlobalDepend(IProgress prog, GlobalDependSetting globalDep) throws Exception
    {
        CJavaCenter.getMe().saveGlobalDepend(prog, globalDep);
    }

    public CPluginProjectDto saveGlobalDepend(IProgress prog, GlobalDependSetting globalDep, GlobalDependObserver observer) throws Exception
    {
        return CJavaCenter.getMe().saveGlobalDepend(prog, globalDep, observer);
    }
    
    public boolean isInstalledArtifacts(String groupId, String artifactId) throws Exception
    {
        return CJavaCenter.getMe().isInstalledArtifacts(groupId, artifactId);
    }

    public CJavaProjectDto importYunProject(IProgress prog, ArtifactWare artWare, UserPassword yunUser) throws Exception
    {
        return CDaoUtil.convertDto(CJavaCenter.getMe().importYunProject(prog, artWare, yunUser), CJavaProjectDto.class);
    }
    
    public List<ArtifactDefine> queryInstalledArtifacts(boolean excludeLocalArtifact) throws Exception
    {
        return CJavaCenter.getMe().queryInstalledArtifacts(excludeLocalArtifact);
    }

    public boolean installArtifact(IProgress prog, ArtifactDefine art, long waitPublish) throws Exception
    {
        return CJavaCenter.getMe().installArtifact(prog, art, waitPublish);
    }
    
    public boolean uninstallArtifact(IProgress prog, ArtifactDefine art, long waitPublish) throws Exception
    {
        return CJavaCenter.getMe().uninstallArtifact(prog, art, waitPublish);
    }

    public CodeMeta getCodeMeta(String cls) throws Exception
    {
        return CJavaCenter.getMe().getCodeMeta(cls);
    }

    public CResFileDo saveCodeMeta(String className, CodeMeta meta, boolean rebuild) throws Exception
    {
        return CJavaCenter.getMe().saveCodeMeta(className, meta, rebuild);
    }

    public UdfMeta queryUdfMeta(String pjUuid, String cls) throws Exception
    {
        return CJavaCenter.getMe().queryUdfMeta(pjUuid, cls);
    }

    public String getYunStoreUri() throws Exception
    {
        return YunStoreAgent.getConfigUri();
    }
    
    public List<String> scanLocalFiles(String ... folder)
    {
        return CJavaCenter.getMe().scanLocalFiles(folder);
    }

    public String downloadMavenArtifact(IProgress prog, MvnArt mvnArt, UserPassword yunUser) throws Exception
    {
        return CJavaCenter.getMe().publishMavenArtifact(prog, mvnArt, yunUser);
    }

    public LoneWolfConfig exportLoneWolfFiles(IProgress<byte[]> prog) throws Exception
    {
        return CJavaCenter.getMe().exportLoneWolfFiles(prog);
    }

    public String getDevAdminTool()
    {
        return MppContext.getString(CJavaConst.CONF_DEV_ADMIN_TOOL, CJavaConst.DFT_DEV_ADMIN_TOOL);
    }

    public CSession loginYunStore(UserPassword yunUser) throws Exception
    {
        // 先尝试登陆一下云仓库，校验连通性以及用户等，然后再准备打包发布
        return YunStoreAgent.getIntf().login(yunUser);
    }

    @Override
    public List<CJavaVirtualProjectDto> getAllVirtualProjects() throws Exception
    {
        return CDaoUtil.convertDtos(CJavaCenter.getMe().getAllVirtualProjects(), CJavaVirtualProjectDto.class);
    }
    
    public CJavaVirtualProjectDto importYunVirtualProject(IProgress prog, ArtifactWare artWare, UserPassword yunUser) throws Exception
    {
        CJavaVirtualProject pj = YunProjectImporter.importVirtualProject(prog, artWare, yunUser);
        return CDaoUtil.convertDto(pj, CJavaVirtualProjectDto.class);
    }

    public MultiPageResult<VersionNode> queryNodeLogs(String extProjectKey, Cnd cndWhere, CPager pager, String ... fields) throws Exception
    {
        return CVerMgr.get().queryNodeLogs(extProjectKey, cndWhere, pager, fields);
    }

    @Override
    public Map<String, List<ClassNameInfo>> scanConflictPluginClass(IProgress prog) throws Exception
    {
        try
        {
            // 扫描系统的
            ClassInfoLoader loader = new BasiceClassInfoLoader()
            {
                public void addClass(String classKey, String classFullName, String srcPath)
                {
                    super.addClass(classFullName, classFullName, srcPath);
                }
            };
            CodeUtil.ananysJVMClass(new ChildProgress(0, 15, prog), loader);

            Map<String, List<ClassNameInfo>> mapConflict = new HashMap<>();
            Map<String, List<ClassNameInfo>> mapSys = loader.getAll();
            Map<String, List<ClassNameInfo>> mapPlugin = ClassFactory.getPluginClassInfoLoader().getAll();
            Collection<List<ClassNameInfo>> allPluginClasses = Nulls.get(mapPlugin).values();
            int pos = 0;
            int cnt = allPluginClasses.size();
            ChildProgress compareProg = new ChildProgress(16, 100, prog);
            for (List<ClassNameInfo> lstCls : Nulls.get(mapPlugin).values())
            {
                ProgressCtrlUtil.assertCancel(prog);
                ProgressCtrlUtil.sendProcess(compareProg, pos++ * 100 / cnt, "Compare class : " + ToolUtilities.logString(lstCls, false), true);

                for (ClassNameInfo pluginCls : Nulls.get(lstCls))
                {
                    if (mapSys.containsKey(pluginCls.getClassFullName()))
                    {
                        // 发现冲突
                        mapConflict.put(pluginCls.getClassFullName(), mapSys.get(pluginCls.getClassFullName()));
                        ToolUtilities.putMapList(mapConflict, pluginCls.getClassFullName(), pluginCls);
                    }
                }
            }

            return mapConflict;
        } finally
        {
            ProgressCtrlUtil.sendFinishProcess(prog);
        }
    }

}

 
