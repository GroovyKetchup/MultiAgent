package bap.java.debug;

import java.net.URI;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import bap.client.BapClient;
import bap.java.CJavaCode;
import bap.java.CJavaConst;
import ms.cmn.HostPort;

public class CJavaDebugClient
{
    private static CJavaDebugClient _me;
    public synchronized static CJavaDebugClient getMe()
    {
        if (_me == null)
        {
            _me = new CJavaDebugClient();
        }
        return _me;
    }
    
    protected CJavaDebugClient()
    {
        
    }
    
    static ConcurrentHashMap<String, CJavaDebugGuiIntf> _mapGui = new ConcurrentHashMap();
    public static String startDebugJava(CJavaDebugGuiIntf guiIntf, CJavaCode code, HostPort agent) throws Exception
    {
        String key = BapClient.getJavaIntf().startDebugJava(code, agent);
        _mapGui.put(key, guiIntf);
        
        new PollingThread(key, guiIntf).start();
        
        return key;
    }
    
    public static String startDebugJava(CJavaDebugGuiIntf guiIntf, CJavaCode code, URI agentUri) throws Exception
    {
        String key = BapClient.getJavaIntf().startDebugJava(code, agentUri);
        _mapGui.put(key, guiIntf);
        
        new PollingThread(key, guiIntf).start();
        
        return key;
    }
    
    static class PollingThread extends Thread
    {
        String key;
        CJavaDebugGuiIntf gui;
        public PollingThread(String key, CJavaDebugGuiIntf gui)
        {
            this.key = key;
            this.gui = gui;
        }
        
        public void popTrace() throws NoDebuggerException
        {
            List<String> lstTrace = BapClient.getJavaIntf().popTrace(key);
            if (!CmnUtil.isObjectEmpty(lstTrace))
                gui.trace(lstTrace);
        }
        
        public void run()
        {
            
            try
            {
                // 通知界面，调试开始
                gui.OnBegin(key);
                
                for (;;)
                {
                    try
                    {
                        // 弹出trace信息
                        popTrace();
                        
                        int status = BapClient.getJavaIntf().getStatus(key);
                        if (status == CJavaConst.STATUS_ERROR)
                        {
                            Throwable err;
                            try
                            {
                                err = (Throwable) BapClient.getJavaIntf().getResult(key);
                            }catch(Throwable exp)
                            {
                                err = new Exception(BapClient.getJavaIntf().getResultText(key));
                            }
                            popTrace();
                            gui.OnError(key, err);
                            return;
                        }else if (status == CJavaConst.STATUS_FINISHED)
                        {
                            Object res;
                            try
                            {
                                res = BapClient.getJavaIntf().getResult(key);
                            }catch(Throwable exp)
                            {
                                res = BapClient.getJavaIntf().getResultText(key);
                            }
                            
                            popTrace();
                            gui.OnFinish(key, res);
                            return;
                        }
                    } 
                    catch (Throwable err)
                    {
                        gui.OnError(key, err);

                        // 当远端无调试器或调试器消失，则退出轮询
                        if (ToolUtilities.isCausedBy(err, NoDebuggerException.class))
                            return;
                    }
                    
                    ToolUtilities.sleep(300);
                }
            } finally
            {
                _mapGui.remove(key);
                gui.OnExit(key);
            }
        }
    }
}
