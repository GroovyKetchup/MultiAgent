package bap.java.debug;

import java.util.List;

/**
 * 单实例调试服务接口，只专注于单次调试调用的控制
 *
 * 实现类主要有两个，本地、远程（桥接）
 */
public interface CJavaDebugger
{
    // 调试KEY（RPC的则是RMT UUID）
    public String getUuid();
    
    // 调试器名字，便于界面显示追踪
    public String getName();
    
    // 获取当前调试状态
    public int getStatus();
    
    // 启动调试的时间
    public long getStartTime();
    
    // 发起调试的客户端地址等信息
    public String getClientInfo();
    
    // 获取调试结果（成功则是返回值，出错则可获取到异常对象）
    public Object getResult();
    
    // 判断是否已经跑出异常
    public boolean isException();
    
    // 如果返回结果不是可序列化的，那么前端还可以通过此方法获取到结果转换成的字符串
    public String getResultText();
    
    // 弹出trace信息，并清空
    public List<String> popTrace();
    
    // 强制停止调试
    // forceKillTime : 多少毫秒后对线程采取强制停止动作
    public void terminateDebug(long forceKillTime);
    
}
