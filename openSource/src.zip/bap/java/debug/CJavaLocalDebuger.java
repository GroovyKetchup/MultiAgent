package bap.java.debug;

import java.io.File;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.mvel2.TraceListener;
import org.nutz.repo.cache.simple.LRUCache;

import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ZipUtils;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.dfc.gui.LvUtil;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcServer;

import bap.java.CJavaCode;
import bap.java.CJavaConst;

public class CJavaLocalDebuger implements CJavaDebugger, TraceListener
{
    public String uuid = CmnUtil.allocUUIDWithUnderline();
    
    protected String _clientInfo = null;
    
    protected long _quitTime = -1;
    
    public CJavaLocalDebuger()
    {
        try
        {
            // 如果是通过远程启动（通常都是），则记录发起端地址信息
            _clientInfo = ""+CRpcServer.getCurrentRemoteAddress();
        }catch(Throwable err)
        {
            _clientInfo = "";
        }
    }
    
    public String getUuid()
    {
        return uuid;
    }
    
    protected String _fullClass = null;
    public void startDebug(CJavaDebugPkg dbgPkg) throws Exception
    {
        _fullClass = dbgPkg.getCode().getFullClassName();
        
        // 根据调试依赖类型，决定使用哪个ClassLoader用于调试
        LvClassLoader loader;
        switch (dbgPkg.getDependType())
        {
        case CJavaConst.DEPEND_ISOLATE:
            loader = new LvClassLoader();
            break;
        case CJavaConst.DEPEND_PLUGIN:
            loader = ClassFactory.newValidClassLoader();
            break;
        case CJavaConst.DEPEND_PLATFORM:
            loader = new LvClassLoader(ClassFactory.getBasicClassLoader());
            break;
        case CJavaConst.UDF_LIB:
            loader = ClassFactory.newValidClassLoader();
            break;
        default:
            loader = ClassFactory.newValidClassLoader();
        }
        
        if (dbgPkg.getClassPath() != null)
            for (String path : dbgPkg.getClassPath())
                loader.addFilePath(path+"/");
        
        final File tmpJarFolder = new File("tmp/JAVA_DEBUG_" + ToolUtilities.allockUUID());
        byte[] bin = dbgPkg.getExtJarBin();
        if (bin != null)
        {
            ToolUtilities.createFolder(tmpJarFolder.getAbsolutePath());
            File tmpFile = new File("tmp/JAVA_DEBUG_"+ToolUtilities.allockUUID()+".zip");
            ToolUtilities.saveFile(tmpFile.getAbsolutePath(), bin, false);
            try
            {
                ZipUtils.unzip(tmpFile.getAbsolutePath(), tmpJarFolder.getAbsolutePath());
            } finally
            {
                ToolUtilities.deleteFileFolder(tmpFile);
            }
            
            loader.addFolder(tmpJarFolder.getAbsolutePath());
        }
        
        // 附加的class 文件
        Map<String, byte[]> extClasses = dbgPkg.getExtClasses();
        if (!ToolUtilities.isObjectEmpty(extClasses))
            for (Entry<String, byte[]> ent : extClasses.entrySet())
            {
                loader.addClassByte(ent.getKey(), ent.getValue());
            }

        startDebug(dbgPkg.getCode(), loader, this);
    }
    
    private Thread _debugThread;
    protected long _startTime=-1;
    public void startDebug(CJavaCode code, LvClassLoader loader, TraceListener tc)
    {
        _startTime = System.currentTimeMillis();
        _debugThread = new Thread()
        {
            public void run()
            {
                LvUtil.setCurrentThreadTraceListener(tc);
                try
                {
                    setStatus(CJavaConst.STATUS_PREPARE_RUNNING);
                    OnPrepareRunning();

                    String mainClass = code.getFullClassName();
              
                    Class mainCls = loader.loadClass(mainClass);
                    Method mainMth = null;
                    Method[] mths = mainCls.getMethods();
                    for (Method mth : mths)
                    {
                        if (mth.getName().equals("main"))
                            if (LvJavac.isMemberStatic(mth))
                            {
                                mainMth = mth;
                                break;
                            }
                    }
                    
                    if (mainMth == null)
                        throw new Exception("Please declare 'public static void main()' function in " + mainClass);

                    setStatus(CJavaConst.STATUS_RUNNING);
                    OnBeginRunning();
                    
                    Object objRes = null;
                    if (ToolUtilities.isObjectEmpty(mainMth.getParameterTypes()))
                        objRes = mainMth.invoke(mainCls);
                    else
                        objRes = mainMth.invoke(mainCls, (String)null);

                    setResult(objRes);
                    setStatus(CJavaConst.STATUS_FINISHED);
                    OnFinish();
                } catch (Throwable exp)
                {
//                    exp.printStackTrace();
                    setResult(exp);
                    setStatus(CJavaConst.STATUS_ERROR);
                }finally
                {
                    LvClassLoader.clearThreadRC();
                    
                    OnQuit();
                }
            }
        };
        _debugThread.setContextClassLoader(loader);
        _debugThread.setName("DEBUG : " + code.getFullClassName());
        _debugThread.start();
    }
    
    public long getQuitTime()
    {
        return _quitTime;
    }

    public void terminateDebug(long forceKillTime)
    {
        if (_debugThread != null)
            ToolUtilities.killThread(_debugThread, forceKillTime);
    }
    
    // 准备Run
    public void OnPrepareRunning() {
        
    }
    
    // 开始Run
    public void OnBeginRunning() {
        
    }
    
    // 成功执行完毕
    public void OnFinish()
    {
    }
    
    // 即将退出运行线程
    public void OnQuit()
    {
        _quitTime = System.currentTimeMillis();
        
        if (_debugThread != null)
            _debugThread.setContextClassLoader(null);
    }
    
    int _status = CJavaConst.STATUS_PREPARE_RUNNING;
    protected void setStatus(int s)
    {
        _status = s;
    }
    
    public int getStatus()
    {
        return _status;
    }
    
    Object _result = null;
    // 设置结果
    public void setResult(Object result)
    {
        _result = result;
    }
    
    public Object getResult()
    {
        return _result;
    }
    
    public String getResultText()
    {
        if (_result instanceof Throwable)
            return ToolBasic.getExceptionStatck((Throwable) _result);
        else
            return CmnUtil.getString(_result, "");
    }

    public List<String> popTrace()
    {
        synchronized (_traceCache)
        {
            List<String> lstRet = new LinkedList<String>();
            for (;;)
            {
                Entry<Long, String> ent = _traceCache.pop();
                if (ent == null)
                    break;
                else
                    lstRet.add(ent.getValue());
            }
            return lstRet;
        }
    }
    
    
    // 打印Trace
    LRUCache<Long, String> _traceCache = new LRUCache<Long, String>(1000);
    public void trace(String sMsg) throws RemoteException
    {
        synchronized (_traceCache)
        {
            _traceCache.put(System.currentTimeMillis()+System.nanoTime(), sMsg);
        }
    }
    
    public void clearCache()
    {
        synchronized (_traceCache)
        {
            _traceCache.clear();
        }
    }

    public String getFullClassName()
    {
        return CmnUtil.getString(_fullClass, "");
    }
    
    public String getName()
    {
        return getFullClassName()+" [LOCAL]";
    }

    public long getStartTime()
    {
        return _startTime;
    }

    public String getClientInfo()
    {
        return _clientInfo;
    }

    public boolean isException()
    {
        return ToolBasic.isValidObject(getResult(), Throwable.class);
    }
}
