package bap.java.debug;

import java.util.List;

import com.leavay.nio.crpc.Pingable;

import bap.java.CJavaCode;
import bap.java.CJavaDebuggerDto;
import ms.cmn.HostPort;

/**
 * Debug Center提供的是管理多个Debug Key，其中包含本地和远程调试 
 *
 */
public interface CJavaDebugCenterIntf extends Pingable
{
    /**
     * 启动调试，返回调试码
     * 
     * @param agent : 指定调试目标机地址信息，传空表示在主控内
     * @param dependType : 指定依赖平台、插件还是全不依赖，CJavaConst. TYPE XXXXX
     */
    public String startDebugJava(CJavaCode code, HostPort agent, int dependType) throws Exception;
    
    /**
     * 查询当前缓存的调试器，包含本地和远程
     * 
     * @param : onlyAlive表示只查询当前正在运行（健康存活）的，已结束、出错、消失的都不返回
     */
    public List<CJavaDebuggerDto> getAllDebugger(boolean onlyAlive);
    
    /**
     * 给出调试Key，强停，等待数秒后会尝试强杀调试线程
     * killTime : 超出多少毫秒则采取强停
     */
    public void terminateDebug(String debugKey, long killTime) throws Exception;
    
    
    // 获取当前调试状态
    public int getStatus(String debugKey) throws NoDebuggerException;
    
    public boolean isException(String dbgKey) throws NoDebuggerException;
    
    // 获取调试结果（成功则是返回值，出错则可获取到异常对象）
    public Object getResult(String debugKey) throws NoDebuggerException;
    
    // 如果返回结果不是可序列化的，那么前端还可以通过此方法获取到结果转换成的字符串
    public String getResultText(String debugKey) throws NoDebuggerException;
    
    // 弹出trace信息，并清空
    public List<String> popTrace(String debugKey) throws NoDebuggerException;
    
}
