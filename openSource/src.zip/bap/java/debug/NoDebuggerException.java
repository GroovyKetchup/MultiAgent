package bap.java.debug;

public class NoDebuggerException extends Exception
{

    private static final long serialVersionUID = -5643762846418951025L;

}
