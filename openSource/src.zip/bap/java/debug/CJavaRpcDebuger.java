package bap.java.debug;

import java.net.URI;
import java.util.List;

import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;
import com.leavay.nio.crpc.CRpcServer;

import bap.java.CJavaCode;
import ms.cmn.HostPort;

/**
 * 在主控上执行，对远程代理进行调试的桥接器
 * 主要负责维护远程接口，透传调用指令
 *
 */
public class CJavaRpcDebuger implements CJavaDebugger
{
    CRpcClientWrapper<CJavaDebugCenterIntf> _rmt = new CRpcClientWrapper<CJavaDebugCenterIntf>(CJavaDebugCenterIntf.class)
    {
        public CRpcAdapter getAdapter()
        {
            return CRpcAdapter.getInstance();
        }
        
        public long getConnTimeout()
        {
            return 2000;
        }
    };
    
    public String rmtUuid; 
    protected String _clientInfo = null;
    
    public CJavaRpcDebuger(String host, int port)
    {
        _rmt.init(host, port);
        
        try
        {
            // 如果是通过远程启动（通常都是），则记录发起端地址信息
            _clientInfo = ""+CRpcServer.getCurrentRemoteAddress();
        }catch(Throwable err)
        {
            _clientInfo = "";
        }
    }
    
    public CJavaRpcDebuger(URI uri)
    {
        _rmt.init(uri);
        
        try
        {
            // 如果是通过远程启动（通常都是），则记录发起端地址信息
            _clientInfo = ""+CRpcServer.getCurrentRemoteAddress();
        }catch(Throwable err)
        {
            _clientInfo = "";
        }
    }
    
    protected CJavaDebugCenterIntf getIntf()
    {
        return _rmt.getIntf(true);
    }
    
    public String getHost()
    {
        return _rmt.getHost();
    }

    public int getPort()
    {
        return _rmt.getPort();
    }
    
    public HostPort getHostPort()
    {
        return new HostPort().setHost(getHost()).setPort(getPort());
    }

    public String getRmtUuid()
    {
        return rmtUuid;
    }

    public int getStatus()
    {
        try
        {
            return getIntf().getStatus(getRmtUuid());
        } catch (NoDebuggerException exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return 0;
        }
    }

    public Object getResult()
    {
        try
        {
            return getIntf().getResult(getRmtUuid());
        } catch (NoDebuggerException exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }
    
    public boolean isException()
    {
        try
        {
            return getIntf().isException(getUuid());
        } catch (NoDebuggerException exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return true;
        }
    }

    public String getResultText()
    {
        try
        {
            return getIntf().getResultText(getRmtUuid());
        } catch (NoDebuggerException exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }

    public List<String> popTrace()
    {
        try
        {
            return getIntf().popTrace(getRmtUuid());
        } catch (NoDebuggerException exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }

    public void terminateDebug(long forceKillTime)
    {
        try
        {
            getIntf().terminateDebug(getRmtUuid(), forceKillTime);
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
        }
    }

    protected String _fullClass = null;
    protected long _startTime=-1;
    public String startDebug(CJavaCode code, int dependType) throws Exception
    {
        _startTime = System.currentTimeMillis();
        _fullClass = code.getFullClassName();
        
        rmtUuid = getIntf().startDebugJava(code, null, dependType);
        return rmtUuid;
    }
    
    public String getFullClassName()
    {
        return CmnUtil.getString(_fullClass, "");
    }
    
    public String getName()
    {
        return getFullClassName()+" [AGENT]";
    }

    public long getStartTime()
    {
        return _startTime;
    }

    public String getClientInfo()
    {
        return _clientInfo;
    }

    public String getUuid()
    {
        return getRmtUuid();
    }

}
