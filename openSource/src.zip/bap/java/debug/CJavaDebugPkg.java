package bap.java.debug;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.mvel2.rmtLaunch.RmtLaunchAgent;

import bap.java.CJavaCode;
import bap.java.CJavaConst;
import bap.md.java.CJavaProject;

public class CJavaDebugPkg extends RmtLaunchAgent implements Serializable
{
    CJavaProject project;
    CJavaCode code;
    List<String> clsPath;
    Map<String, byte[]> extClassFile;
    byte[] extJar;
    
    public int dependType = CJavaConst.DEPEND_PLUGIN;
    
    public CJavaProject getProject()
    {
        return project;
    }
    public void setProject(CJavaProject project)
    {
        this.project = project;
    }
    public CJavaCode getCode()
    {
        return code;
    }
    public void setCode(CJavaCode code)
    {
        this.code = code;
    }
    public synchronized List<String> getClassPath()
    {
        return clsPath;
    }
    public synchronized void setClassPath(List<String> clsPath)
    {
        this.clsPath = clsPath;
    }
    
    public synchronized void addClassPath(String absPath)
    {
        if (clsPath == null)
            clsPath = new ArrayList();
        
        clsPath.add(absPath);
    }
    
    public synchronized Map<String, byte[]> getExtClasses()
    {
        return extClassFile;
    }
    
    public synchronized void setExtClasses(Map<String, byte[]> extClasses)
    {
        this.extClassFile = extClasses;
    }
    
    public synchronized void addExtClasses(String fullCalss, byte[] clsFile)
    {
        if (extClassFile == null)
            extClassFile = new TreeMap();
        
        extClassFile.put(fullCalss, clsFile);
    }
    
    public byte[] getExtJarBin()
    {
        return extJar;
    }
    
    public void setExtJarBin(byte[] extJar)
    {
        this.extJar = extJar;
    }
    
    public int getDependType()
    {
        return dependType;
    }
    
    public void setDependType(int dependType)
    {
        this.dependType = dependType;
    }
    
    
}
