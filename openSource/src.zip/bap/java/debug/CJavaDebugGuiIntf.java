package bap.java.debug;

import java.util.List;

public interface CJavaDebugGuiIntf
{
    public void trace(List<String> lstTrace);
    
    public void OnBegin(String key);
    
    public void OnFinish(String key, Object result); // 成功执行完
    
    public void OnError(String key, Throwable err); // 出错
    
    public void OnExit(String key); // 彻底退出
}
