package bap;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Properties;

import com.leavay.common.nio.ws.CWsUtil;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.ReleaseInfoParser;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.Utils;
import com.leavay.dfc.gui.LvUtil;
import com.leavay.model.utils.LcUserUtil;
import com.leavay.model.utils.LicenseApplyInfo;
import com.leavay.model.utils.LicenseGenIntf;
import com.leavay.model.utils.SystemInfo;
import com.leavay.model.utils.SystemInfo.OutReason;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.starter.StarterMain;
/**
 * LICENSE自动申请并启动服务
 * @author chenxb
 *
 */
public class AutoLicStarterMain extends StarterMain{

	public static void main(String[] args)
    {
		//连接License服务器，生成授权许可
        try
        {
        	boolean isLicValid = false;
        	try {
	        	File licDataFile = new File("./conf/license.data");
	        	if(licDataFile.exists()) {
	        		licDataFile.delete();
	        	}
//	        	OutReason ourReason = LcUserUtil.statrtCheck();
//	        	if(ourReason == OutReason.SUCCESS)
//	        		isLicValid = true;
        	}catch (Throwable e) {
        		e.printStackTrace();
			}
        	if(!isLicValid) {
				byte[] bytes = LcUserUtil.loadLcLib();
				LcUserUtil.loadSysLoader(bytes);
				String systemId = LcUserUtil.getSystemID();
				generateLicense(systemId);
        	}
        } catch (Throwable exp)
        {
            ToolUtilities.fatal("System", exp);
            System.exit(0);
        }
        try
        {
            getMe().start(args);
        } catch (Throwable exp)
        {
            ToolUtilities.fatal("System", exp);
            System.exit(0);
        }
    }
	
	public static Properties readProperties(File file) throws IOException {
//		String encode = MppContext.getString("ISO-8859-1");
		Properties props = ToolUtilities.readPropertyFile(file.getAbsolutePath());
//		Properties newProps = new Properties();
//		for(Object key : props.keySet()) {
//			String value = new String(props.getProperty((String)key).getBytes(encode));
//			newProps.put(key, value);
//		}
		return props;
	}
	
	public static void generateLicense(String systemId) throws Exception {
		
		File licPropFile = new File("./conf/license.properties");
		if(!licPropFile.exists()) {
			throw new Exception("File is not exist!" + licPropFile.getAbsolutePath());
		}
		String serviceVersion = ReleaseInfoParser.getInstance().getServerVersion();
		
        Properties props = readProperties(licPropFile);
        props.put(SystemInfo.HostInfo, systemId);
        props.put(SystemInfo.ServiceVersion, serviceVersion);
        String expectedDate = props.getProperty(SystemInfo.ExpectedDate);
        if(CmnUtil.isStringEmpty(expectedDate)) {
        	SimpleDateFormat sdf = new SimpleDateFormat(SystemInfo.YYYYMMDD_dash);
            long expectedDateMills = System.currentTimeMillis() + 180 * 24 * 60 * 60 * 1000L;
            String expTime = sdf.format(expectedDateMills);
            props.put(SystemInfo.ExpectedDate, expTime);
            props.put(SystemInfo.ServiceDate, "" + expectedDateMills);
        }
        
        String licenseServer = props.getProperty("server");
        if(CmnUtil.isStringEmpty(licenseServer)) {
        	throw new Exception("license server is not configed!");
        }
//        int licensePort = CmnUtil.getInteger(props.getProperty("license.port"),-1);
//        if(licensePort == -1) {
//        	throw new Exception("license.port is not configed!");
//        }
        
        //申请人
        String applicant = props.getProperty("applicant");
        //审批人
        String approver = props.getProperty("approver");
        //标题
        String title = props.getProperty("title");
        
        // 最后特殊判断处理
        String licenseContent = generateLicense(licenseServer, applicant,
        		approver, title, props);
        File licDataFile = new File("./conf/license.data");
        licDataFile.delete();
        LvUtil.trace("Delete license.data.");
        Utils.writeFile(licDataFile, licenseContent.getBytes());
        
    }

    public static String generateLicense(String wsUrl, String applicant, String approver, String title,
                                         Properties props) throws Exception {
    	int retryTimes = MppContext.getInt("autolic.retryTimes", 3);
    	int licenseServiceTimeOut = MppContext.getInt("autolic.connect.timeout", 10) * 1000;
    	while(true) {
    		try {
		    	LvUtil.trace("===============Generate License ================");
		    	LvUtil.trace("===============License Server [" + wsUrl +"] ================");
		    	LvUtil.trace("===============applicant [" + applicant+"] ================");
		    	LvUtil.trace("===============approver [" + approver+"] ================");
		    	LvUtil.trace("===============title [" + title+"] ================");
		    	LvUtil.trace("===============props [" + props+"] ================");
		        CRpcAdapter adp = new CRpcAdapter();
		        URI uri = CWsUtil.buildURI(wsUrl);
		        LicenseGenIntf intf = (LicenseGenIntf) adp.openService(uri, LicenseGenIntf.class, licenseServiceTimeOut);
		        LicenseApplyInfo info = new LicenseApplyInfo();
		        info.setUser(approver);
		        info.setApplicant(applicant);
		        info.setApprover(approver);
		        info.setTitle(title);
		        return intf.generateLicense(info, props);
    		}catch (Exception e) {
    			retryTimes--;
				if(retryTimes<=0) {
					throw e;
				}
				LvUtil.trace("license服务请求失败,尝试重新请求！\n"+ToolUtilities.getFullExceptionStack(e, true));
			}
    	}
    }
}
