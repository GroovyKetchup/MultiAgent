package bap.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdao.mgr.CDaoUtil;
import com.leavay.common.reflect.TypeToken;
import com.leavay.common.util.GsonUtil;
import com.leavay.common.util.javac.CodeCompileException;

import bap.java.CJavaCode;
import bap.java.CJavaConst;
import bap.java.CJavaProjectDto;
import bap.java.project.CJavaCenter;
import bap.md.java.CJavaFolder;
import bap.md.java.CJavaProject;
import bap.plugin.CPluginProjectDto;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import ms.cmn.HostPort;

/**
 * JavaTool调试Servlet
 * 用于编译执行Java代码的main方法，以及工程管理、插件发布等功能。
 * 
 * API端点：
 * - POST /api/javatool/debug - 启动调试执行
 * - POST /api/javatool/execute - 启动执行
 * - GET /api/javatool/status/{debugId} - 获取执行状态
 * - GET /api/javatool/result/{debugId} - 获取执行结果
 * - GET /api/javatool/trace/{debugId} - 获取执行日志
 * - GET /api/javatool/terminate/{debugId} - 终止执行
 * 
 * 工程管理：
 * - POST /api/javatool/project/create - 创建工程
 * - GET /api/javatool/project/get/{uuid} - 获取工程信息
 * - GET /api/javatool/project/list - 列出所有工程
 * 
 * 代码管理：
 * - POST /api/javatool/code/save - 保存Java代码
 * - GET /api/javatool/code/get - 获取Java代码
 * 
 * 插件发布：
 * - POST /api/javatool/plugin/export - 发布工程为插件
 * - POST /api/javatool/plugin/publish - 全量发布所有插件
 */
public class JavaToolServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    public static final String SERVLET_CONTEXT_PATH = "/api/javatool/*";
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    private void processRequest(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/") || pathInfo.isEmpty()) {
            error(response, "缺少操作路径");
            return;
        }
        
        String[] paths = pathInfo.substring(1).split("/");
        String action = paths[0];
        
        try {
            if ("project".equals(action)) {
                handleProject(request, response, paths);
            } else if ("code".equals(action)) {
                handleCode(request, response, paths);
            } else if ("plugin".equals(action)) {
                handlePlugin(request, response, paths);
            } else {
                switch (action) {
                    case "debug":
                        handleDebug(request, response, paths);
                        break;
                    case "execute":
                        handleExecute(request, response, paths);
                        break;
                    case "status":
                        handleStatus(request, response, paths);
                        break;
                    case "result":
                        handleResult(request, response, paths);
                        break;
                    case "trace":
                        handleTrace(request, response, paths);
                        break;
                    case "terminate":
                        handleTerminate(request, response, paths);
                        break;
                    default:
                        error(response, "未知操作: " + action);
                }
            }
        } catch (Exception e) {
            error(response, "执行失败: " + e.getMessage());
        }
    }
    
    // ==================== 工程管理 ====================
    
    private void handleProject(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        if (paths.length < 2) {
            error(response, "缺少工程操作路径");
            return;
        }
        
        String subAction = paths[1];
        switch (subAction) {
            case "create":
                handleProjectCreate(request, response);
                break;
            case "get":
                handleProjectGet(request, response, paths);
                break;
            case "list":
                handleProjectList(request, response);
                break;
            default:
                error(response, "未知工程操作: " + subAction);
        }
    }
    
    private void handleProjectCreate(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        String body = readRequestBody(request);
        Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
        Map<String, Object> params = GsonUtil.fromJson(body, type);
        
        String name = getStringParam(params, "name", null);
        if (name == null || name.trim().isEmpty()) {
            error(response, "缺少工程名称");
            return;
        }
        
        int dependType = getIntParam(params, "dependType", 0);
        String folderName = getStringParam(params, "folderName", "core");
        
        CJavaProject project = CJavaCenter.getMe().createProject(name, dependType, folderName);
        
        Map<String, Object> result = new HashMap<>();
        result.put("uuid", project.getUuid());
        result.put("name", project.getName());
        result.put("dependType", project.getDependType());
        success(response, result);
    }
    
    private void handleProjectGet(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        if (paths.length < 3) {
            error(response, "缺少工程UUID");
            return;
        }
        
        String uuid = paths[2];
        CJavaProject project = CJavaCenter.getMe().getProject(uuid);
        
        if (project == null) {
            error(response, "工程不存在: " + uuid);
            return;
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("uuid", project.getUuid());
        result.put("name", project.getName());
        result.put("dependType", project.getDependType());
        success(response, result);
    }
    
    private void handleProjectList(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        List<CJavaProject> projects = CJavaCenter.getMe().getAllProjects();
        
        java.util.List<Map<String, Object>> list = new java.util.ArrayList<>();
        for (CJavaProject pj : projects) {
            Map<String, Object> item = new HashMap<>();
            item.put("uuid", pj.getUuid());
            item.put("name", pj.getName());
            item.put("dependType", pj.getDependType());
            list.add(item);
        }
        
        success(response, list);
    }
    
    // ==================== 代码管理 ====================
    
    private void handleCode(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        if (paths.length < 2) {
            error(response, "缺少代码操作路径");
            return;
        }
        
        String subAction = paths[1];
        switch (subAction) {
            case "save":
                handleCodeSave(request, response);
                break;
            case "get":
                handleCodeGet(request, response);
                break;
            case "update":
                handleCodeUpdate(request, response);
                break;
            case "delete":
                handleCodeDelete(request, response);
                break;
            default:
                error(response, "未知代码操作: " + subAction);
        }
    }
    
    private void handleCodeSave(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        String body = readRequestBody(request);
        Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
        Map<String, Object> params = GsonUtil.fromJson(body, type);
        
        String projectUuid = getStringParam(params, "projectUuid", null);
        if (projectUuid == null || projectUuid.trim().isEmpty()) {
            error(response, "缺少工程UUID");
            return;
        }
        
        String javaPackage = getStringParam(params, "javaPackage", "com.example");
        String mainClass = getStringParam(params, "mainClass", "Main");
        String codeContent = getStringParam(params, "code", null);
        String folderName = getStringParam(params, "folderName", "core");
        
        if (codeContent == null || codeContent.trim().isEmpty()) {
            error(response, "缺少代码内容");
            return;
        }
        
        // 获取指定名称的源码目录
        String folderUuid = null;
        try (IDao dao = IDaoService.newIDao()) {
            CJavaFolder folder = CJavaCenter.queryFolderDo(dao, projectUuid, folderName);
            if (folder == null) {
                // 如果指定目录不存在，尝试获取第一个目录
                List<CJavaFolder> folders = CJavaCenter.getMe().getFolders(projectUuid);
                if (folders != null && !folders.isEmpty()) {
                    folderUuid = folders.get(0).getUuid();
                }
            } else {
                folderUuid = folder.getUuid();
            }
            dao.commit();
        }
        
        if (folderUuid == null) {
            error(response, "工程没有源码目录，请先创建目录");
            return;
        }
        
        CJavaCode code = new CJavaCode();
        code.setProjectUuid(projectUuid);
        code.setJavaPackage(javaPackage);
        code.setMainClass(mainClass);
        code.setCode(codeContent);
        code.setOwner(folderUuid);
        
        CJavaCode saved = CJavaCenter.getMe().saveJavaCode(code, true);
        
        Map<String, Object> result = new HashMap<>();
        result.put("uuid", saved.getUuid());
        result.put("fullClassName", saved.getFullClassName());
        result.put("projectUuid", saved.getProjectUuid());
        result.put("folderUuid", folderUuid);
        success(response, result);
    }
    
    private void handleCodeGet(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        String projectUuid = request.getParameter("projectUuid");
        String fullClassName = request.getParameter("fullClassName");
        String codeUuid = request.getParameter("uuid");
        
        CJavaCode code = null;
        if (codeUuid != null && !codeUuid.isEmpty()) {
            code = CJavaCenter.getMe().getJavaCode(codeUuid);
        } else if (projectUuid != null && fullClassName != null) {
            code = CJavaCenter.getMe().getJavaCode(projectUuid, fullClassName);
        } else {
            error(response, "缺少查询参数: uuid 或 (projectUuid + fullClassName)");
            return;
        }
        
        if (code == null) {
            Map<String, Object> result = new HashMap<>();
            result.put("exists", false);
            result.put("projectUuid", projectUuid);
            result.put("fullClassName", fullClassName);
            result.put("uuid", codeUuid);
            result.put("message", "代码不存在");
            success(response, result);
            return;
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("exists", true);
        result.put("uuid", code.getUuid());
        result.put("projectUuid", code.getProjectUuid());
        result.put("javaPackage", code.getJavaPackage());
        result.put("mainClass", code.getMainClass());
        result.put("fullClassName", code.getFullClassName());
        result.put("code", code.getCode());
        success(response, result);
    }
    
    private void handleCodeUpdate(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        String body = readRequestBody(request);
        Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
        Map<String, Object> params = GsonUtil.fromJson(body, type);
        
        String projectUuid = getStringParam(params, "projectUuid", null);
        String fullClassName = getStringParam(params, "fullClassName", null);
        String codeContent = getStringParam(params, "code", null);
        
        if (projectUuid == null || projectUuid.trim().isEmpty()) {
            error(response, "缺少工程UUID");
            return;
        }
        
        if (fullClassName == null || fullClassName.trim().isEmpty()) {
            error(response, "缺少类全名");
            return;
        }
        
        if (codeContent == null || codeContent.trim().isEmpty()) {
            error(response, "缺少代码内容");
            return;
        }
        
        // 获取已有代码
        CJavaCode existCode = CJavaCenter.getMe().getJavaCode(projectUuid, fullClassName);
        if (existCode == null) {
            error(response, "代码不存在: " + fullClassName);
            return;
        }
        
        // 更新代码
        existCode.setCode(codeContent);
        
        CJavaCode saved = CJavaCenter.getMe().saveJavaCode(existCode, true);
        
        Map<String, Object> result = new HashMap<>();
        result.put("uuid", saved.getUuid());
        result.put("fullClassName", saved.getFullClassName());
        result.put("projectUuid", saved.getProjectUuid());
        result.put("message", "代码更新成功");
        success(response, result);
    }
    
    private void handleCodeDelete(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        String projectUuid = request.getParameter("projectUuid");
        String fullClassName = request.getParameter("fullClassName");
        String confirm = request.getParameter("confirm");
        
        // 安全检查：必须明确确认
        if (!"yes".equals(confirm)) {
            error(response, "删除操作需要确认，请添加 confirm=yes 参数");
            return;
        }
        
        if (projectUuid == null || projectUuid.trim().isEmpty()) {
            error(response, "缺少工程UUID");
            return;
        }
        
        if (fullClassName == null || fullClassName.trim().isEmpty()) {
            error(response, "缺少类全名");
            return;
        }
        
        // 通过CJavaCenter删除代码
        boolean deleted = CJavaCenter.getMe().getBuilder_Force(projectUuid).deleteCode(fullClassName, true);
        
        Map<String, Object> result = new HashMap<>();
        result.put("fullClassName", fullClassName);
        result.put("deleted", deleted);
        result.put("message", deleted ? "代码删除成功" : "代码删除失败或代码不存在");
        success(response, result);
    }
    
    // ==================== 插件发布 ====================
    
    private void handlePlugin(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        if (paths.length < 2) {
            error(response, "缺少插件操作路径");
            return;
        }
        
        String subAction = paths[1];
        switch (subAction) {
            case "export":
                handlePluginExport(request, response);
                break;
            case "publish":
                handlePluginPublish(request, response);
                break;
            case "loadclass":
                handlePluginLoadClass(request, response);
                break;
            default:
                error(response, "未知插件操作: " + subAction);
        }
    }
    
    private void handlePluginExport(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        String body = readRequestBody(request);
        Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
        Map<String, Object> params = GsonUtil.fromJson(body, type);
        
        String projectUuid = getStringParam(params, "projectUuid", null);
        if (projectUuid == null || projectUuid.trim().isEmpty()) {
            error(response, "缺少工程UUID");
            return;
        }
        
        String pluginName = getStringParam(params, "pluginName", "");
        boolean includeSubJars = getBooleanParam(params, "includeSubJars", false);
        boolean ignoreCompileError = getBooleanParam(params, "ignoreCompileError", true);
        
        try {
            CPluginProjectDto plugin = CJavaCenter.getMe().exportProject2Plugin(
                projectUuid, pluginName, includeSubJars, ignoreCompileError);
            
            Map<String, Object> result = new HashMap<>();
            result.put("compiled", true);
            result.put("uuid", plugin.getUuid());
            result.put("name", plugin.getName());
            result.put("timeTag", plugin.getTimeTag());
            success(response, result);
        } catch (CodeCompileException e) {
            Map<String, Object> result = new HashMap<>();
            result.put("compiled", false);
            result.put("compileError", e.getMessage());
            result.put("projectUuid", projectUuid);
            result.put("pluginName", pluginName);
            success(response, result);
        }
    }
    
    private void handlePluginPublish(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        long newTag = bap.plugin.mgr.CPluginCenter.getMe().publish(false);
        
        Map<String, Object> result = new HashMap<>();
        result.put("newTag", newTag);
        result.put("message", "插件发布成功");
        success(response, result);
    }
    
    private void handlePluginLoadClass(HttpServletRequest request, HttpServletResponse response) 
            throws Exception {
        String className = request.getParameter("className");
        if (className == null || className.trim().isEmpty()) {
            error(response, "缺少className参数");
            return;
        }
        
        try {
            Class<?> clazz = Class.forName(className);
            
            Map<String, Object> result = new HashMap<>();
            result.put("className", className);
            result.put("loaded", true);
            result.put("classLoader", clazz.getClassLoader().getClass().getName());
            
            // 如果是Cell接口，尝试获取实例
            if (cell.bap.opm.simulator.IOpmCollectorSimulator.class.isAssignableFrom(clazz)) {
                Object instance = bap.cells.Cells.get(clazz);
                if (instance != null) {
                    result.put("cellInstance", true);
                    if (instance instanceof cell.bap.opm.simulator.IOpmCollectorSimulator) {
                        cell.bap.opm.simulator.IOpmCollectorSimulator sim = 
                            (cell.bap.opm.simulator.IOpmCollectorSimulator) instance;
                        result.put("simulatorName", sim.getSimulatorName());
                        result.put("targetCollectorKey", sim.getTargetCollectorKey());
                    }
                }
            }
            
            success(response, result);
        } catch (ClassNotFoundException e) {
            Map<String, Object> result = new HashMap<>();
            result.put("className", className);
            result.put("loaded", false);
            result.put("error", "类未找到: " + e.getMessage());
            success(response, result);
        } catch (Exception e) {
            Map<String, Object> result = new HashMap<>();
            result.put("className", className);
            result.put("loaded", false);
            result.put("error", e.getMessage());
            success(response, result);
        }
    }
    
    // ==================== 调试执行 ====================
    
    private void handleDebug(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        CJavaCode code = buildCJavaCode(request);
        String debugId = CJavaCenter.getMe().startDebug(code, (HostPort) null);
        
        Map<String, Object> result = new HashMap<>();
        result.put("debugId", debugId);
        result.put("fullClassName", code.getFullClassName());
        success(response, result);
    }
    
    private void handleExecute(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        CJavaCode code = buildCJavaCode(request);
        String debugId = CJavaCenter.getMe().startDebug(code, (HostPort) null);
        
        Map<String, Object> result = new HashMap<>();
        result.put("debugId", debugId);
        result.put("fullClassName", code.getFullClassName());
        result.put("message", "执行已启动");
        success(response, result);
    }
    
    private void handleStatus(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        if (paths.length < 2) {
            error(response, "缺少debugId参数");
            return;
        }
        
        String debugId = paths[1];
        int status = CJavaCenter.getMe().getDebugStatus(debugId);
        String statusText = getStatusText(status);
        
        Map<String, Object> result = new HashMap<>();
        result.put("debugId", debugId);
        result.put("status", status);
        result.put("statusText", statusText);
        success(response, result);
    }
    
    private void handleResult(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        if (paths.length < 2) {
            error(response, "缺少debugId参数");
            return;
        }
        
        String debugId = paths[1];
        int status = CJavaCenter.getMe().getDebugStatus(debugId);
        String resultText = CJavaCenter.getMe().getDebugResultText(debugId);
        
        Map<String, Object> result = new HashMap<>();
        result.put("debugId", debugId);
        result.put("status", status);
        result.put("statusText", getStatusText(status));
        result.put("result", resultText);
        result.put("isError", status == CJavaConst.STATUS_ERROR);
        try {
            List<String> traces = CJavaCenter.getMe().popDebugTrace(debugId);
            result.put("traces", traces);
        } catch (Throwable ignore) {
        }
        success(response, result);
    }
    
    private void handleTrace(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        if (paths.length < 2) {
            error(response, "缺少debugId参数");
            return;
        }
        
        String debugId = paths[1];
        List<String> traces = CJavaCenter.getMe().popDebugTrace(debugId);
        int status = CJavaCenter.getMe().getDebugStatus(debugId);
        
        Map<String, Object> result = new HashMap<>();
        result.put("debugId", debugId);
        result.put("status", status);
        result.put("statusText", getStatusText(status));
        result.put("traces", traces);
        success(response, result);
    }
    
    private void handleTerminate(HttpServletRequest request, HttpServletResponse response, String[] paths) 
            throws Exception {
        if (paths.length < 2) {
            error(response, "缺少debugId参数");
            return;
        }
        
        String debugId = paths[1];
        CJavaCenter.getMe().terminateDebug(debugId, 5000);
        
        Map<String, Object> result = new HashMap<>();
        result.put("debugId", debugId);
        result.put("message", "已发送终止指令");
        success(response, result);
    }
    
    private String getStatusText(int status) {
        switch (status) {
            case 0:
                return "准备中";
            case 1:
                return "运行中";
            case 2:
                return "已完成";
            case 3:
                return "执行出错";
            default:
                return "未知状态";
        }
    }
    
    private CJavaCode buildCJavaCode(HttpServletRequest request) throws IOException {
        String body = readRequestBody(request);
        Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
        Map<String, Object> params = GsonUtil.fromJson(body, type);
        
        CJavaCode code = new CJavaCode();
        
        String projectUuid = getStringParam(params, "projectUuid", CJavaConst.SYSTEM_PROJECT_UUID);
        String codeUuid = getStringParam(params, "uuid", CDaoUtil.allocUuid());
        String javaPackage = getStringParam(params, "javaPackage", "com.debug.tool");
        String mainClass = getStringParam(params, "mainClass", "JavaTool");
        String codeContent = getStringParam(params, "code", getDefaultCode(javaPackage, mainClass));
        String folder = getStringParam(params, "folder", "");
        String name = getStringParam(params, "name", mainClass);
        
        code.setProjectUuid(projectUuid);
        code.setUuid(codeUuid);
        code.setJavaPackage(javaPackage);
        code.setMainClass(mainClass);
        code.setCode(codeContent);
        code.setOwner(folder);
        code.setName(name);
        
        String encoding = getStringParam(params, "fileEncoding", "UTF-8");
        code.setFileEncoding(encoding);
        
        return code;
    }
    
    private String readRequestBody(HttpServletRequest request) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        java.io.BufferedReader reader = request.getReader();
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        return sb.toString();
    }
    
    private String getStringParam(Map<String, Object> params, String key, String defaultValue) {
        if (params == null) return defaultValue;
        Object value = params.get(key);
        if (value == null) return defaultValue;
        return value.toString();
    }
    
    private int getIntParam(Map<String, Object> params, String key, int defaultValue) {
        if (params == null) return defaultValue;
        Object value = params.get(key);
        if (value == null) return defaultValue;
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
    
    private boolean getBooleanParam(Map<String, Object> params, String key, boolean defaultValue) {
        if (params == null) return defaultValue;
        Object value = params.get(key);
        if (value == null) return defaultValue;
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        return Boolean.parseBoolean(value.toString());
    }
    
    private String getDefaultCode(String pkg, String className) {
        StringBuilder sb = new StringBuilder();
        if (pkg != null && !pkg.isEmpty()) {
            sb.append("package ").append(pkg).append(";\n\n");
        }
        sb.append("public class ").append(className).append(" {\n\n");
        sb.append("    public static void main(String[] args) {\n");
        sb.append("        System.out.println(\"Hello from JavaTool!\");\n");
        sb.append("    }\n");
        sb.append("}\n");
        return sb.toString();
    }
    
    private void success(HttpServletResponse response, Object data) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("data", data);
        out.print(GsonUtil.toJson(result));
        out.flush();
    }
    
    private void error(HttpServletResponse response, String message) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();
        result.put("success", false);
        result.put("error", message);
        out.print(GsonUtil.toJson(result));
        out.flush();
    }
}
