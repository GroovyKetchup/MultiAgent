package bap.web.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mvel2.CompileException;
import org.mvel2.MVEL;
import org.mvel2.ParserContext;

import com.leavay.common.reflect.TypeToken;
import com.leavay.common.util.GsonUtil;
import com.leavay.common.util.ToolUtilities;

import bap.opm.OpmCollectResult;
import bap.opm.OpmCenter;
import bap.md.opm.sys.OpmSysMetricDo;

/**
 * MVEL脚本执行Servlet。
 * 用于远程执行MVEL脚本，支持编译错误和运行时错误的详细信息返回。
 */
public class MvelToolServlet extends HttpServlet
{
    private static final long serialVersionUID = 1L;

    public static final String SERVLET_CONTEXT_PATH = "/api/mveltool/*";

    protected static ParserContext createParserContext()
    {
        ParserContext ctx = new ParserContext();
        ctx.addImport(OpmCollectResult.class);
        ctx.addImport(OpmCenter.class);
        ctx.addImport(OpmSysMetricDo.class);
        return ctx;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        processRequest(req, resp);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        processRequest(req, resp);
    }

    private void processRequest(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        String pathInfo = req.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/") || pathInfo.isEmpty())
        {
            error(resp, "缺少操作路径");
            return;
        }

        String action = pathInfo.substring(1);
        if (action.endsWith("/"))
            action = action.substring(0, action.length() - 1);

        try
        {
            if ("execute".equals(action))
            {
                handleExecute(req, resp);
            }
            else if ("compile".equals(action))
            {
                handleCompile(req, resp);
            }
            else
            {
                error(resp, "未知操作: " + action);
            }
        }
        catch (Exception e)
        {
            error(resp, "执行失败: " + e.getMessage());
        }
    }

    private void handleExecute(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        String body = readRequestBody(req);
        Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
        Map<String, Object> params = GsonUtil.fromJson(body, type);

        String script = getStringParam(params, "script", null);
        if (script == null || script.trim().isEmpty())
        {
            error(resp, "缺少script参数");
            return;
        }

        Map<String, Object> vars = getMapParam(params, "vars");
        if (vars == null)
            vars = new HashMap<String, Object>();

        Serializable compiled;
        try
        {
            ParserContext ctx = createParserContext();
            compiled = MVEL.compileExpression(script, ctx);
        }
        catch (CompileException e)
        {
            errorCompile(resp, e);
            return;
        }

        try
        {
            Object result = MVEL.executeExpression(compiled, vars);
            Map<String, Object> data = new HashMap<String, Object>();
            data.put("result", result);
            data.put("resultType", result == null ? "null" : result.getClass().getName());
            success(resp, data);
        }
        catch (Exception e)
        {
            errorRuntime(resp, e);
        }
    }

    private void handleCompile(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        String body = readRequestBody(req);
        Type type = new TypeToken<HashMap<String, Object>>(){}.getType();
        Map<String, Object> params = GsonUtil.fromJson(body, type);

        String script = getStringParam(params, "script", null);
        if (script == null || script.trim().isEmpty())
        {
            error(resp, "缺少script参数");
            return;
        }

        try
        {
            ParserContext ctx = createParserContext();
            MVEL.compileExpression(script, ctx);

            Map<String, Object> data = new HashMap<String, Object>();
            data.put("valid", true);
            data.put("message", "编译成功");
            success(resp, data);
        }
        catch (CompileException e)
        {
            errorCompile(resp, e);
        }
    }

    private String readRequestBody(HttpServletRequest req) throws IOException
    {
        StringBuilder sb = new StringBuilder();
        String line;
        BufferedReader reader = req.getReader();
        while ((line = reader.readLine()) != null)
        {
            sb.append(line);
        }
        return sb.toString();
    }

    private String getStringParam(Map<String, Object> params, String key, String defaultValue)
    {
        if (params == null)
            return defaultValue;
        Object value = params.get(key);
        if (value == null)
            return defaultValue;
        return value.toString();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> getMapParam(Map<String, Object> params, String key)
    {
        if (params == null)
            return null;
        Object value = params.get(key);
        if (value instanceof Map)
            return (Map<String, Object>) value;
        return null;
    }

    private void success(HttpServletResponse resp, Object data) throws IOException
    {
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", true);
        result.put("data", data);
        out.print(GsonUtil.toJson(result));
        out.flush();
    }

    private void error(HttpServletResponse resp, String message) throws IOException
    {
        resp.setContentType("application/json;charset=UTF-8");
        resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        PrintWriter out = resp.getWriter();
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", false);
        result.put("error", message);
        out.print(GsonUtil.toJson(result));
        out.flush();
    }

    private void errorCompile(HttpServletResponse resp, CompileException e) throws IOException
    {
        resp.setContentType("application/json;charset=UTF-8");
        resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        PrintWriter out = resp.getWriter();

        Map<String, Object> errorInfo = new HashMap<String, Object>();
        errorInfo.put("type", "compile");
        errorInfo.put("message", e.getMessage());
        errorInfo.put("line", e.getLineNumber());
        errorInfo.put("column", e.getColumn());
        errorInfo.put("codeNear", e.getCodeNear());

        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", false);
        result.put("error", errorInfo);
        out.print(GsonUtil.toJson(result));
        out.flush();
    }

    private void errorRuntime(HttpServletResponse resp, Exception e) throws IOException
    {
        resp.setContentType("application/json;charset=UTF-8");
        resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        PrintWriter out = resp.getWriter();

        Map<String, Object> errorInfo = new HashMap<String, Object>();
        errorInfo.put("type", "runtime");
        errorInfo.put("message", e.getMessage());
        errorInfo.put("exceptionClass", e.getClass().getName());
        errorInfo.put("stackTrace", ToolUtilities.getExceptionStatck(e, false));

        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", false);
        result.put("error", errorInfo);
        out.print(GsonUtil.toJson(result));
        out.flush();
    }
}