package bap.web.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Parameter;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.leavay.common.reflect.TypeToken;
import com.leavay.common.util.GsonUtil;

import bap.cells.Cells;
import bap.web.servlet.CellInvokeServlet.ParameterExampleGenerator;
import cell.CellIntf;

/**
 * Cell万能反射调用Servlet 支持通过反射调用任意Cell接口的方法，自动进行参数类型转换
 * 
 * API格式： POST /api/cell/invoke
 * 
 * 请求体： { "className": "com.example.IMyCell", // Cell接口全限定名 "methodName":
 * "doSomething", // 方法名 "params": [ // 参数列表 "字符串参数", {"key": "value"}, // 复杂对象
 * [1, 2, 3], // 数组/集合 123 // 基本类型 ] }
 * 
 * 响应体： { "success": true, "data": { ... } // 方法返回值，复杂对象自动转JSON }
 */
public class CellInvokeServlet extends HttpServlet
{

    private static final long serialVersionUID = 1L;

    public static final String SERVLET_CONTEXT_PATH = "/api/cell/invoke/*";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        processRequest(request, response);
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/") || pathInfo.isEmpty())
        {
            error(response, "缺少操作路径");
            return;
        }

        String[] paths = pathInfo.substring(1).split("/");
        String action = paths[0];

        try
        {
            switch (action)
            {
            case "invoke":
                handleInvoke(request, response);
                break;
            case "methods":
                handleListMethods(request, response);
                break;
            default:
                error(response, "未知操作: " + action);
            }
        } catch (Exception e)
        {
            error(response, "执行失败: " + e.getMessage(), e);
        }
    }

    /**
     * 处理方法调用请求
     */
    private void handleInvoke(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        String body = readRequestBody(request);
        Type type = new TypeToken<HashMap<String, Object>>()
        {
        }.getType();
        Map<String, Object> params = GsonUtil.fromJson(body, type);

        String className = getStringParam(params, "className", null);
        String methodName = getStringParam(params, "methodName", null);
        List<Object> paramList = (List<Object>) params.get("params");

        if (className == null || className.isEmpty())
        {
            error(response, "缺少className参数");
            return;
        }

        if (methodName == null || methodName.isEmpty())
        {
            error(response, "缺少methodName参数");
            return;
        }

        if (paramList == null)
        {
            paramList = new ArrayList<Object>();
        }

        Class<?> cellClass = null;
        try
        {
            cellClass = Class.forName(className);
        } catch (ClassNotFoundException e)
        {
            error(response, "找不到类: " + className);
            return;
        }

        if (!CellIntf.class.isAssignableFrom(cellClass))
        {
            error(response, "类 " + className + " 不是Cell接口的实现");
            return;
        }

        Object cellInstance = null;
        try
        {
            cellInstance = Cells.get((Class<? extends CellIntf>) cellClass);
        } catch (Exception e)
        {
            error(response, "获取Cell实例失败: " + e.getMessage(), e);
            return;
        }

        if (cellInstance == null)
        {
            error(response, "Cell实例为空，可能未注册: " + className);
            return;
        }

        Method matchedMethod = null;
        Object[] convertedParams = null;
        StringBuilder matchLog = new StringBuilder();

        List<Method> candidateMethods = new ArrayList<Method>();
        for (Method m : cellClass.getMethods())
        {
            if (m.getName().equals(methodName))
            {
                candidateMethods.add(m);
            }
        }

        if (candidateMethods.isEmpty())
        {
            error(response, "找不到方法: " + methodName + " (类: " + className + ")");
            return;
        }

        List<String> matchErrors = new ArrayList<String>();

        for (Method method : candidateMethods)
        {
            Parameter[] parameters = method.getParameters();
            Object[] tempParams = new Object[parameters.length];
            boolean matchSuccess = true;
            List<String> currentErrors = new ArrayList<String>();

            int providedCount = paramList.size();
            int requiredCount = parameters.length;

            if (providedCount != requiredCount)
            {
                matchErrors.add(String.format("候选方法 %s 参数数量不匹配: 需要%d个, 实际提供%d个", methodToString(method), requiredCount, providedCount));
                continue;
            }

            for (int i = 0; i < parameters.length; i++)
            {
                Parameter param = parameters[i];
                Object inputValue = paramList.get(i);

                try
                {
                    tempParams[i] = TypeConverter.convert(inputValue, param.getType(), param.getParameterizedType());
                } catch (TypeConversionException e)
                {
                    matchSuccess = false;
                    String detailedError = e.getDetailedMessage();
                    currentErrors.add(String.format("参数%d(%s)转换失败:\n    %s", i + 1, param.getName(), detailedError.replace("\n", "\n    ")));
                    break;
                } catch (Exception e)
                {
                    matchSuccess = false;
                    currentErrors.add(String.format("参数%d(%s)转换异常: %s", i + 1, param.getName(), e.getMessage()));
                    break;
                }
            }

            if (matchSuccess)
            {
                matchedMethod = method;
                convertedParams = tempParams;
                break;
            } else
            {
                matchErrors.add(String.format("候选方法 %s: %s", methodToString(method), String.join("; ", currentErrors)));
            }
        }

        if (matchedMethod == null)
        {
            StringBuilder errorMsg = new StringBuilder();
            errorMsg.append("找不到匹配的方法。");
            errorMsg.append("方法名: ").append(methodName).append(", ");
            errorMsg.append("参数数量: ").append(paramList.size()).append("\n");
            errorMsg.append("候选方法匹配详情:\n");
            for (String err : matchErrors)
            {
                errorMsg.append("  - ").append(err).append("\n");
            }

            if (!candidateMethods.isEmpty())
            {
                errorMsg.append("\n建议的调用格式:\n");
                int suggestionCount = 0;
                for (Method m : candidateMethods)
                {
                    if (suggestionCount >= 3)
                        break;
                    String example = ParameterExampleGenerator.generateCallExample(className, m);
                    errorMsg.append("\n").append(example).append("\n");
                    suggestionCount++;
                }
            }

            error(response, errorMsg.toString());
            return;
        }

        Object result = null;
        try
        {
            matchedMethod.setAccessible(true);
            result = matchedMethod.invoke(cellInstance, convertedParams);
        } catch (Exception e)
        {
            Throwable cause = e.getCause();
            if (cause != null)
            {
                error(response, "方法执行异常: " + cause.getMessage(), cause);
            } else
            {
                error(response, "方法调用失败: " + e.getMessage(), e);
            }
            return;
        }

        Object jsonResult = TypeConverter.toJsonSerializable(result);

        Map<String, Object> response_data = new HashMap<String, Object>();
        response_data.put("className", className);
        response_data.put("methodName", methodName);
        response_data.put("method", methodToString(matchedMethod));
        response_data.put("result", jsonResult);
        response_data.put("resultType", result == null ? "null" : result.getClass().getName());

        success(response, response_data);
    }

    /**
     * 列出Cell接口的所有方法
     */
    private void handleListMethods(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        String body = readRequestBody(request);
        Type type = new TypeToken<HashMap<String, Object>>()
        {
        }.getType();
        Map<String, Object> params = GsonUtil.fromJson(body, type);

        String className = getStringParam(params, "className", null);

        if (className == null || className.isEmpty())
        {
            error(response, "缺少className参数");
            return;
        }

        Class<?> cellClass = null;
        try
        {
            cellClass = Class.forName(className);
        } catch (ClassNotFoundException e)
        {
            error(response, "找不到类: " + className);
            return;
        }

        List<Map<String, Object>> methods = new ArrayList<Map<String, Object>>();

        for (Method method : cellClass.getMethods())
        {
            int modifiers = method.getModifiers();
            if (Modifier.isStatic(modifiers) || method.getDeclaringClass() == Object.class)
            {
                continue;
            }

            Map<String, Object> methodInfo = new HashMap<String, Object>();
            methodInfo.put("name", method.getName());
            methodInfo.put("returnType", method.getReturnType().getName());
            methodInfo.put("signature", methodToString(method));

            List<Map<String, Object>> paramList = new ArrayList<Map<String, Object>>();
            Parameter[] parameters = method.getParameters();
            for (Parameter param : parameters)
            {
                Map<String, Object> paramInfo = new HashMap<String, Object>();
                paramInfo.put("name", param.getName());
                paramInfo.put("type", param.getType().getName());
                paramList.add(paramInfo);
            }
            methodInfo.put("parameters", paramList);

            methods.add(methodInfo);
        }

        Map<String, Object> response_data = new HashMap<String, Object>();
        response_data.put("className", className);
        response_data.put("methods", methods);
        response_data.put("count", methods.size());

        success(response, response_data);
    }

    /**
     * 方法签名转字符串
     */
    private static String methodToString(Method method)
    {
        StringBuilder sb = new StringBuilder();
        sb.append(method.getReturnType().getSimpleName()).append(" ");
        sb.append(method.getName()).append("(");

        Parameter[] params = method.getParameters();
        for (int i = 0; i < params.length; i++)
        {
            if (i > 0)
                sb.append(", ");
            sb.append(params[i].getType().getSimpleName());
            sb.append(" ").append(params[i].getName());
        }

        sb.append(")");
        return sb.toString();
    }

    /**
     * 读取请求体
     */
    private String readRequestBody(HttpServletRequest request) throws IOException
    {
        StringBuilder sb = new StringBuilder();
        String line;
        BufferedReader reader = request.getReader();
        while ((line = reader.readLine()) != null)
        {
            sb.append(line);
        }
        return sb.toString();
    }

    /**
     * 获取字符串参数
     */
    private String getStringParam(Map<String, Object> params, String key, String defaultValue)
    {
        if (params == null)
            return defaultValue;
        Object value = params.get(key);
        if (value == null)
            return defaultValue;
        return value.toString();
    }

    /**
     * 返回成功响应
     */
    private void success(HttpServletResponse response, Object data) throws IOException
    {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", true);
        result.put("data", data);
        out.print(GsonUtil.toJson(result));
        out.flush();
    }

    /**
     * 返回错误响应
     */
    private void error(HttpServletResponse response, String message) throws IOException
    {
        error(response, message, null);
    }

    /**
     * 返回错误响应（带异常堆栈）
     */
    private void error(HttpServletResponse response, String message, Throwable e) throws IOException
    {
        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", false);
        result.put("error", message);

        if (e != null)
        {
            result.put("exception", e.getClass().getName());
            result.put("stackTrace", getStackTraceString(e));
        }

        out.print(GsonUtil.toJson(result));
        out.flush();
    }

    /**
     * 获取异常堆栈字符串
     */
    private String getStackTraceString(Throwable e)
    {
        StringBuilder sb = new StringBuilder();
        sb.append(e.toString()).append("\n");

        StackTraceElement[] stackTrace = e.getStackTrace();
        int maxLines = Math.min(stackTrace.length, 10);
        for (int i = 0; i < maxLines; i++)
        {
            sb.append("    at ").append(stackTrace[i].toString()).append("\n");
        }

        if (stackTrace.length > maxLines)
        {
            sb.append("    ... ").append(stackTrace.length - maxLines).append(" more\n");
        }

        if (e.getCause() != null)
        {
            sb.append("Caused by: ").append(getStackTraceString(e.getCause()));
        }

        return sb.toString();
    }

    /**
     * 类型转换工具类 支持基本类型、复杂对象、集合、数组、枚举等类型的转换
     */
    public static class TypeConverter
    {

        /**
         * 将输入值转换为目标类型
         * 
         * @param value
         *            输入值（通常是JSON解析后的对象）
         * @param targetType
         *            目标类型
         * @param genericType
         *            泛型类型（用于获取集合元素类型）
         * @return 转换后的值
         * @throws TypeConversionException
         *             转换失败时抛出
         */
        public static Object convert(Object value, Class<?> targetType, Type genericType) throws TypeConversionException
        {
            if (value == null)
            {
                if (targetType.isPrimitive())
                {
                    throw new TypeConversionException("null不能转换为基本类型: " + targetType.getName());
                }
                return null;
            }

            if (targetType.isAssignableFrom(value.getClass()))
            {
                return value;
            }

            if (value instanceof Number)
            {
                return convertNumber((Number) value, targetType);
            }

            if (value instanceof String)
            {
                return convertString((String) value, targetType);
            }

            if (value instanceof Boolean)
            {
                return convertBoolean((Boolean) value, targetType);
            }

            if (value instanceof Map)
            {
                return convertMap((Map<?, ?>) value, targetType, genericType);
            }

            if (value instanceof List)
            {
                return convertList((List<?>) value, targetType, genericType);
            }

            if (targetType.isArray())
            {
                return convertToArray(value, targetType);
            }

            if (Collection.class.isAssignableFrom(targetType))
            {
                return convertToCollection(value, targetType, genericType);
            }

            if (targetType.isEnum())
            {
                return convertToEnum(value, targetType);
            }

            if (Date.class.isAssignableFrom(targetType))
            {
                return convertToDate(value, targetType);
            }

            try
            {
                return convertToBean(value, targetType);
            } catch (Exception e)
            {
                throw new TypeConversionException(String.format("无法将 %s 转换为 %s: %s", value.getClass().getName(), targetType.getName(), e.getMessage()), e);
            }
        }

        /**
         * 数值类型转换
         */
        private static Object convertNumber(Number value, Class<?> targetType) throws TypeConversionException
        {
            if (targetType == int.class || targetType == Integer.class)
            {
                return value.intValue();
            }
            if (targetType == long.class || targetType == Long.class)
            {
                return value.longValue();
            }
            if (targetType == double.class || targetType == Double.class)
            {
                return value.doubleValue();
            }
            if (targetType == float.class || targetType == Float.class)
            {
                return value.floatValue();
            }
            if (targetType == short.class || targetType == Short.class)
            {
                return value.shortValue();
            }
            if (targetType == byte.class || targetType == Byte.class)
            {
                return value.byteValue();
            }
            if (targetType == BigDecimal.class)
            {
                return new BigDecimal(value.toString());
            }
            if (targetType == BigInteger.class)
            {
                if (value instanceof Double || value instanceof Float)
                {
                    return new BigDecimal(value.toString()).toBigInteger();
                }
                return BigInteger.valueOf(value.longValue());
            }
            if (targetType == String.class)
            {
                return value.toString();
            }
            if (targetType == boolean.class || targetType == Boolean.class)
            {
                throw new TypeConversionException("数值不能转换为布尔类型", value, targetType, "布尔类型应传入: true/false, \"true\"/\"false\", 或 1/0");
            }

            throw new TypeConversionException(String.format("不支持从 %s 转换为 %s", value.getClass().getName(), targetType.getName()), value, targetType, null);
        }

        /**
         * 字符串类型转换
         */
        private static Object convertString(String value, Class<?> targetType) throws TypeConversionException
        {
            if (targetType == String.class || targetType == CharSequence.class)
            {
                return value;
            }

            if (targetType == int.class || targetType == Integer.class)
            {
                try
                {
                    return Integer.parseInt(value.trim());
                } catch (NumberFormatException e)
                {
                    throw new TypeConversionException("字符串无法解析为整数: " + value, value, targetType, "整数字符串示例: \"123\"");
                }
            }

            if (targetType == long.class || targetType == Long.class)
            {
                try
                {
                    return Long.parseLong(value.trim());
                } catch (NumberFormatException e)
                {
                    throw new TypeConversionException("字符串无法解析为长整数: " + value, value, targetType, "长整数字符串示例: \"123456789\"");
                }
            }

            if (targetType == double.class || targetType == Double.class)
            {
                try
                {
                    return Double.parseDouble(value.trim());
                } catch (NumberFormatException e)
                {
                    throw new TypeConversionException("字符串无法解析为浮点数: " + value, value, targetType, "浮点数字符串示例: \"123.45\"");
                }
            }

            if (targetType == float.class || targetType == Float.class)
            {
                try
                {
                    return Float.parseFloat(value.trim());
                } catch (NumberFormatException e)
                {
                    throw new TypeConversionException("字符串无法解析为浮点数: " + value, value, targetType, "浮点数字符串示例: \"123.45\"");
                }
            }

            if (targetType == short.class || targetType == Short.class)
            {
                try
                {
                    return Short.parseShort(value.trim());
                } catch (NumberFormatException e)
                {
                    throw new TypeConversionException("字符串无法解析为短整数: " + value, value, targetType, "短整数字符串示例: \"123\"");
                }
            }

            if (targetType == byte.class || targetType == Byte.class)
            {
                try
                {
                    return Byte.parseByte(value.trim());
                } catch (NumberFormatException e)
                {
                    throw new TypeConversionException("字符串无法解析为字节: " + value, value, targetType, "字节字符串示例: \"123\"");
                }
            }

            if (targetType == boolean.class || targetType == Boolean.class)
            {
                String lower = value.trim().toLowerCase();
                if ("true".equals(lower) || "1".equals(lower) || "yes".equals(lower) || "on".equals(lower))
                {
                    return Boolean.TRUE;
                }
                if ("false".equals(lower) || "0".equals(lower) || "no".equals(lower) || "off".equals(lower))
                {
                    return Boolean.FALSE;
                }
                throw new TypeConversionException("字符串无法解析为布尔值: " + value, value, targetType, "布尔字符串示例: \"true\", \"false\", \"1\", \"0\", \"yes\", \"no\"");
            }

            if (targetType == BigDecimal.class)
            {
                try
                {
                    return new BigDecimal(value.trim());
                } catch (NumberFormatException e)
                {
                    throw new TypeConversionException("字符串无法解析为BigDecimal: " + value, value, targetType, "BigDecimal字符串示例: \"123.45\"");
                }
            }

            if (targetType == BigInteger.class)
            {
                try
                {
                    return new BigInteger(value.trim());
                } catch (NumberFormatException e)
                {
                    throw new TypeConversionException("字符串无法解析为BigInteger: " + value, value, targetType, "BigInteger字符串示例: \"1234567890\"");
                }
            }

            if (targetType == char.class || targetType == Character.class)
            {
                if (value.length() == 1)
                {
                    return value.charAt(0);
                }
                throw new TypeConversionException("字符串长度不为1，无法转换为字符: " + value, value, targetType, "字符字符串示例: \"A\"");
            }

            if (Date.class.isAssignableFrom(targetType))
            {
                return parseDate(value);
            }

            if (targetType.isEnum())
            {
                return convertToEnum(value, targetType);
            }

            if (value.isEmpty())
            {
                if (targetType.isPrimitive())
                {
                    throw new TypeConversionException("空字符串不能转换为基本类型: " + targetType.getName(), value, targetType, "基本类型需要具体的值");
                }
                return null;
            }

            try
            {
                return GsonUtil.fromJson(value, targetType);
            } catch (Exception e)
            {
                String suggestion = buildSuggestion(targetType);
                throw new TypeConversionException(String.format("字符串无法转换为目标类型 %s: %s", targetType.getName(), value), value, targetType, suggestion);
            }
        }

        /**
         * 布尔类型转换
         */
        private static Object convertBoolean(Boolean value, Class<?> targetType) throws TypeConversionException
        {
            if (targetType == boolean.class || targetType == Boolean.class)
            {
                return value;
            }
            if (targetType == String.class)
            {
                return value.toString();
            }
            if (targetType == int.class || targetType == Integer.class)
            {
                return value ? 1 : 0;
            }
            if (targetType == long.class || targetType == Long.class)
            {
                return value ? 1L : 0L;
            }

            throw new TypeConversionException(String.format("不支持从 Boolean 转换为 %s", targetType.getName()));
        }

        /**
         * Map转换为对象
         */
        private static Object convertMap(Map<?, ?> value, Class<?> targetType, Type genericType) throws TypeConversionException
        {
            if (Map.class.isAssignableFrom(targetType))
            {
                return value;
            }

            return convertToBean(value, targetType);
        }

        /**
         * List转换为数组或集合
         */
        private static Object convertList(List<?> value, Class<?> targetType, Type genericType) throws TypeConversionException
        {
            if (targetType.isArray())
            {
                return convertToArray(value, targetType);
            }

            if (Collection.class.isAssignableFrom(targetType))
            {
                return convertToCollection(value, targetType, genericType);
            }

            if (targetType == String.class)
            {
                return GsonUtil.toJson(value);
            }

            throw new TypeConversionException(String.format("List无法转换为 %s", targetType.getName()));
        }

        /**
         * 转换为数组
         */
        private static Object convertToArray(Object value, Class<?> targetType) throws TypeConversionException
        {
            Class<?> componentType = targetType.getComponentType();

            if (value instanceof List)
            {
                List<?> list = (List<?>) value;
                Object array = Array.newInstance(componentType, list.size());

                for (int i = 0; i < list.size(); i++)
                {
                    Object element = list.get(i);
                    Object converted = convert(element, componentType, null);
                    Array.set(array, i, converted);
                }

                return array;
            }

            if (value.getClass().isArray())
            {
                int length = Array.getLength(value);
                Object array = Array.newInstance(componentType, length);

                for (int i = 0; i < length; i++)
                {
                    Object element = Array.get(value, i);
                    Object converted = convert(element, componentType, null);
                    Array.set(array, i, converted);
                }

                return array;
            }

            if (value instanceof String)
            {
                String str = (String) value;
                try
                {
                    List<?> list = GsonUtil.fromJson(str, new TypeToken<List<Object>>()
                    {
                    }.getType());
                    return convertToArray(list, targetType);
                } catch (Exception e)
                {
                    throw new TypeConversionException("字符串无法解析为数组: " + str);
                }
            }

            Object array = Array.newInstance(componentType, 1);
            Object converted = convert(value, componentType, null);
            Array.set(array, 0, converted);
            return array;
        }

        /**
         * 转换为集合
         */
        @SuppressWarnings({ "unchecked", "rawtypes" })
        private static Object convertToCollection(Object value, Class<?> targetType, Type genericType) throws TypeConversionException
        {
            Collection collection = createCollection(targetType);

            Class<?> elementType = Object.class;
            if (genericType instanceof java.lang.reflect.ParameterizedType)
            {
                java.lang.reflect.ParameterizedType pt = (java.lang.reflect.ParameterizedType) genericType;
                Type[] actualTypes = pt.getActualTypeArguments();
                if (actualTypes.length > 0 && actualTypes[0] instanceof Class)
                {
                    elementType = (Class<?>) actualTypes[0];
                }
            }

            if (value instanceof List)
            {
                for (Object item : (List<?>) value)
                {
                    collection.add(convert(item, elementType, null));
                }
            } else if (value.getClass().isArray())
            {
                int length = Array.getLength(value);
                for (int i = 0; i < length; i++)
                {
                    collection.add(convert(Array.get(value, i), elementType, null));
                }
            } else
            {
                collection.add(convert(value, elementType, null));
            }

            return collection;
        }

        /**
         * 创建集合实例
         */
        @SuppressWarnings("rawtypes")
        private static Collection createCollection(Class<?> targetType) throws TypeConversionException
        {
            if (targetType.isInterface() || Modifier.isAbstract(targetType.getModifiers()))
            {
                if (List.class.isAssignableFrom(targetType))
                {
                    return new ArrayList();
                }
                if (Set.class.isAssignableFrom(targetType))
                {
                    return new HashSet();
                }
                if (Collection.class.isAssignableFrom(targetType))
                {
                    return new ArrayList();
                }
                throw new TypeConversionException("不支持的集合接口: " + targetType.getName());
            }

            try
            {
                return (Collection) targetType.newInstance();
            } catch (Exception e)
            {
                throw new TypeConversionException("无法创建集合实例: " + targetType.getName());
            }
        }

        /**
         * 转换为枚举
         */
        @SuppressWarnings({ "unchecked", "rawtypes" })
        private static Object convertToEnum(Object value, Class<?> targetType) throws TypeConversionException
        {
            String strValue = value.toString();

            try
            {
                return Enum.valueOf((Class<Enum>) targetType, strValue);
            } catch (IllegalArgumentException e)
            {
            }

            Enum[] constants = ((Class<Enum>) targetType).getEnumConstants();
            for (Enum constant : constants)
            {
                if (constant.name().equalsIgnoreCase(strValue))
                {
                    return constant;
                }
                if (String.valueOf(constant.ordinal()).equals(strValue))
                {
                    return constant;
                }
            }

            StringBuilder available = new StringBuilder();
            for (Enum constant : constants)
            {
                if (available.length() > 0)
                    available.append(", ");
                available.append(constant.name());
            }

            String suggestion = String.format("枚举 %s 的可用值: [%s]", targetType.getSimpleName(), available.toString());
            throw new TypeConversionException(String.format("'%s' 不是有效的枚举值", strValue), value, targetType, suggestion);
        }

        /**
         * 转换为日期
         */
        private static Object convertToDate(Object value, Class<?> targetType) throws TypeConversionException
        {
            if (value instanceof Date)
            {
                return value;
            }

            if (value instanceof Number)
            {
                return new Date(((Number) value).longValue());
            }

            if (value instanceof String)
            {
                return parseDate((String) value);
            }

            String suggestion = "支持的日期格式: yyyy-MM-dd HH:mm:ss, yyyy-MM-dd, 时间戳等";
            throw new TypeConversionException(String.format("无法将 %s 转换为 Date", value.getClass().getName()), value, targetType, suggestion);
        }

        /**
         * 解析日期字符串
         */
        private static Date parseDate(String value) throws TypeConversionException
        {
            String[] patterns = { "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm:ss.SSS", "yyyy-MM-dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd", "yyyyMMddHHmmss", "yyyyMMdd", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss'Z'",
                    "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'" };

            for (String pattern : patterns)
            {
                try
                {
                    SimpleDateFormat sdf = new SimpleDateFormat(pattern);
                    return sdf.parse(value.trim());
                } catch (ParseException e)
                {
                }
            }

            try
            {
                long timestamp = Long.parseLong(value.trim());
                return new Date(timestamp);
            } catch (NumberFormatException e)
            {
            }

            String suggestion = "支持的格式: yyyy-MM-dd HH:mm:ss, yyyy-MM-dd, 时间戳(毫秒)等";
            throw new TypeConversionException("无法解析日期字符串: " + value, value, Date.class, suggestion);
        }

        /**
         * 转换为JavaBean
         */
        private static Object convertToBean(Object value, Class<?> targetType) throws TypeConversionException
        {
            if (value instanceof Map)
            {
                try
                {
                    String json = GsonUtil.toJson(value);
                    return GsonUtil.fromJson(json, targetType);
                } catch (Exception e)
                {
                    String suggestion = buildSuggestion(targetType);
                    throw new TypeConversionException(String.format("Map转换为 %s 失败: %s", targetType.getName(), e.getMessage()), value, targetType, suggestion);
                }
            }

            if (value instanceof String)
            {
                String str = (String) value;
                if (str.trim().startsWith("{") || str.trim().startsWith("["))
                {
                    try
                    {
                        return GsonUtil.fromJson(str, targetType);
                    } catch (Exception e)
                    {
                        String suggestion = buildSuggestion(targetType);
                        throw new TypeConversionException(String.format("JSON字符串转换为 %s 失败: %s", targetType.getName(), e.getMessage()), value, targetType, suggestion);
                    }
                }
            }

            try
            {
                String json = GsonUtil.toJson(value);
                return GsonUtil.fromJson(json, targetType);
            } catch (Exception e)
            {
                String suggestion = buildSuggestion(targetType);
                throw new TypeConversionException(String.format("无法将 %s 转换为 %s: %s", value.getClass().getName(), targetType.getName(), e.getMessage()), value, targetType, suggestion);
            }
        }

        /**
         * 构建类型转换建议
         */
        private static String buildSuggestion(Class<?> targetType)
        {
            String example = ParameterExampleGenerator.generateParameterExample(targetType, null);

            return "正确格式示例: " + example;
        }

        /**
         * 将对象转换为可JSON序列化的格式
         */
        public static Object toJsonSerializable(Object value)
        {
            if (value == null)
            {
                return null;
            }

            if (value instanceof String || value instanceof Number || value instanceof Boolean)
            {
                return value;
            }

            if (value instanceof Map)
            {
                Map<Object, Object> result = new LinkedHashMap<Object, Object>();
                for (Map.Entry<?, ?> entry : ((Map<?, ?>) value).entrySet())
                {
                    result.put(entry.getKey().toString(), toJsonSerializable(entry.getValue()));
                }
                return result;
            }

            if (value instanceof List)
            {
                List<Object> result = new ArrayList<Object>();
                for (Object item : (List<?>) value)
                {
                    result.add(toJsonSerializable(item));
                }
                return result;
            }

            if (value instanceof Set)
            {
                List<Object> result = new ArrayList<Object>();
                for (Object item : (Set<?>) value)
                {
                    result.add(toJsonSerializable(item));
                }
                return result;
            }

            if (value.getClass().isArray())
            {
                int length = Array.getLength(value);
                List<Object> result = new ArrayList<Object>(length);
                for (int i = 0; i < length; i++)
                {
                    result.add(toJsonSerializable(Array.get(value, i)));
                }
                return result;
            }

            if (value instanceof Date)
            {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return sdf.format((Date) value);
            }

            if (value instanceof Enum)
            {
                return ((Enum<?>) value).name();
            }

            try
            {
                String json = GsonUtil.toJson(value);
                return GsonUtil.fromJson(json, Map.class);
            } catch (Exception e)
            {
                return value.toString();
            }
        }
    }

    /**
     * 参数示例生成器 根据方法签名生成正确的JSON参数调用示例
     */
    /**
     * 参数示例生成器（通过反射动态生成）
     */
    public static class ParameterExampleGenerator
    {

        private static Set<String> processedClasses = new HashSet<String>();

        private static final int MAX_DEPTH = 3;

        /**
         * 生成完整的方法调用示例
         */
        public static String generateCallExample(String className, Method method)
        {
            StringBuilder sb = new StringBuilder();
            sb.append("方法签名: ").append(methodToString(method)).append("\n");
            sb.append("调用示例:\n");
            sb.append("```bash\n");
            sb.append("curl -X POST http://localhost:8090/api/cell/invoke/invoke \\\n");
            sb.append("  -H \"Content-Type: application/json\" \\\n");
            sb.append("  -d '{\n");
            sb.append("    \"className\": \"").append(className).append("\",\n");
            sb.append("    \"methodName\": \"").append(method.getName()).append("\",\n");
            sb.append("    \"params\": [");

            Parameter[] params = method.getParameters();
            if (params.length > 0)
            {
                sb.append("\n");
                processedClasses.clear();
                for (int i = 0; i < params.length; i++)
                {
                    String paramExample = generateParameterExample(params[i].getType(), params[i].getParameterizedType(), 0);
                    sb.append("      ").append(paramExample);
                    if (i < params.length - 1)
                    {
                        sb.append(",");
                    }
                    sb.append("  // ").append(params[i].getType().getSimpleName()).append(" ").append(params[i].getName()).append("\n");
                }
                sb.append("    ");
            }

            sb.append("]\n");
            sb.append("  }'\n");
            sb.append("```\n");

            return sb.toString();
        }

        /**
         * 生成单个参数的JSON示例（动态生成）
         */
        public static String generateParameterExample(Class<?> type, Type genericType)
        {
            return generateParameterExample(type, genericType, 0);
        }

        /**
         * 生成单个参数的JSON示例（带深度控制）
         */
        public static String generateParameterExample(Class<?> type, Type genericType, int depth)
        {
            if (depth > MAX_DEPTH)
            {
                return "\"...\"";
            }

            if (type == null)
            {
                return "null";
            }

            // 基本类型
            if (type == String.class || type == CharSequence.class)
            {
                return "\"示例字符串\"";
            }
            if (type == int.class || type == Integer.class)
            {
                return "123";
            }
            if (type == long.class || type == Long.class)
            {
                return "1234567890123";
            }
            if (type == double.class || type == Double.class)
            {
                return "123.45";
            }
            if (type == float.class || type == Float.class)
            {
                return "123.45";
            }
            if (type == boolean.class || type == Boolean.class)
            {
                return "true";
            }
            if (type == char.class || type == Character.class)
            {
                return "\"A\"";
            }
            if (type == short.class || type == Short.class)
            {
                return "123";
            }
            if (type == byte.class || type == Byte.class)
            {
                return "123";
            }
            if (type == BigDecimal.class)
            {
                return "\"123.45\"";
            }
            if (type == BigInteger.class)
            {
                return "\"12345678901234567890\"";
            }
            if (type == Date.class || type == java.sql.Date.class || type == java.sql.Timestamp.class)
            {
                return "\"2024-01-01 12:00:00\"";
            }
            if (type == Class.class)
            {
                return "\"java.lang.String\"";
            }
            if (type == Object.class)
            {
                return "\"任意类型\"";
            }

            // 数组
            if (type.isArray())
            {
                return generateArrayExample(type.getComponentType(), depth);
            }

            // 集合
            if (Collection.class.isAssignableFrom(type))
            {
                return generateCollectionExample(genericType, depth);
            }

            // Map
            if (Map.class.isAssignableFrom(type))
            {
                return generateMapExample(genericType, depth);
            }

            // 枚举
            if (type.isEnum())
            {
                return generateEnumExample(type);
            }

            // 复杂对象（通过反射动态生成）
            return generateObjectExample(type, depth);
        }

        /**
         * 生成数组示例
         */
        private static String generateArrayExample(Class<?> componentType, int depth)
        {
            if (componentType == byte.class)
            {
                return "\"base64编码字符串\"";
            }

            String elementExample = generateParameterExample(componentType, null, depth + 1);
            return "[" + elementExample + ", " + elementExample + "]";
        }

        /**
         * 生成集合示例
         */
        private static String generateCollectionExample(Type genericType, int depth)
        {
            if (genericType instanceof java.lang.reflect.ParameterizedType)
            {
                java.lang.reflect.ParameterizedType pt = (java.lang.reflect.ParameterizedType) genericType;
                Type[] actualTypes = pt.getActualTypeArguments();
                if (actualTypes.length > 0)
                {
                    Class<?> elementType = extractClass(actualTypes[0]);
                    if (elementType != null)
                    {
                        String elementExample = generateParameterExample(elementType, actualTypes[0], depth + 1);
                        return "[" + elementExample + ", " + elementExample + "]";
                    }
                }
            }
            return "[\"item1\", \"item2\"]";
        }

        /**
         * 生成Map示例
         */
        private static String generateMapExample(Type genericType, int depth)
        {
            if (genericType instanceof java.lang.reflect.ParameterizedType)
            {
                java.lang.reflect.ParameterizedType pt = (java.lang.reflect.ParameterizedType) genericType;
                Type[] actualTypes = pt.getActualTypeArguments();
                if (actualTypes.length >= 2)
                {
                    Class<?> valueType = extractClass(actualTypes[1]);
                    if (valueType != null)
                    {
                        String valueExample = generateParameterExample(valueType, actualTypes[1], depth + 1);
                        return "{\"key1\": " + valueExample + ", \"key2\": " + valueExample + "}";
                    }
                }
            }
            return "{\"key1\": \"value1\", \"key2\": \"value2\"}";
        }

        /**
         * 生成枚举示例
         */
        private static String generateEnumExample(Class<?> enumType)
        {
            try
            {
                Object[] constants = enumType.getEnumConstants();
                if (constants != null && constants.length > 0)
                {
                    return "\"" + ((Enum<?>) constants[0]).name() + "\"";
                }
            } catch (Exception e)
            {
            }
            return "\"ENUM_VALUE\"";
        }

        /**
         * 生成对象示例（核心：通过反射动态构建）
         */
        private static String generateObjectExample(Class<?> type, int depth)
        {
            String className = type.getName();

            // 避免循环引用
            if (processedClasses.contains(className))
            {
                return "{\"...\": \"循环引用\"}";
            }

            processedClasses.add(className);

            // 尝试直接创建实例并序列化
            try
            {
                Object instance = tryCreateInstance(type);
                if (instance != null)
                {
                    processedClasses.remove(className);
                    return GsonUtil.toJson(instance);
                }
            } catch (Exception e)
            {
            }

            // 通过反射获取字段生成示例
            StringBuilder sb = new StringBuilder();
            sb.append("{\n");

            java.lang.reflect.Field[] fields = getAllFields(type);
            int fieldCount = 0;
            int maxFields = 10;

            for (java.lang.reflect.Field field : fields)
            {
                if (Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers()))
                {
                    continue;
                }

                if (fieldCount >= maxFields)
                {
                    sb.append("        // ... 更多字段省略 ...\n");
                    break;
                }

                try
                {
                    field.setAccessible(true);
                    String fieldName = field.getName();
                    Class<?> fieldType = field.getType();
                    Type genericFieldType = field.getGenericType();

                    String fieldValue = generateParameterExample(fieldType, genericFieldType, depth + 1);

                    if (fieldCount > 0)
                    {
                        sb.append(",\n");
                    }

                    sb.append("        \"").append(fieldName).append("\": ").append(fieldValue);
                    sb.append("  // ").append(fieldType.getSimpleName());

                    fieldCount++;
                } catch (Exception e)
                {
                }
            }

            sb.append("\n      }");

            processedClasses.remove(className);

            return sb.toString();
        }

        /**
         * 尝试创建实例
         */
        private static Object tryCreateInstance(Class<?> type)
        {
            try
            {
                if (Modifier.isAbstract(type.getModifiers()) || Modifier.isInterface(type.getModifiers()))
                {
                    return null;
                }

                String typeName = type.getName();
                // 跳过无法简单实例化的类型
                if (typeName.contains("CSession") || typeName.contains("IDao") || typeName.contains("Connection") || typeName.contains("Statement") || typeName.contains("InputStream") || typeName.contains("OutputStream")
                        || typeName.contains("Socket") || typeName.contains("Thread"))
                {
                    return null;
                }

                // 尝试无参构造
                try
                {
                    Constructor<?> noArgConstructor = type.getDeclaredConstructor(new Class[0]);
                    noArgConstructor.setAccessible(true);
                    return noArgConstructor.newInstance(new Object[0]);
                } catch (NoSuchMethodException e)
                {
                }

                // 尝试有参构造（使用默认值）
                Constructor<?>[] constructors = type.getDeclaredConstructors();
                for (Constructor<?> constructor : constructors)
                {
                    try
                    {
                        constructor.setAccessible(true);
                        Class<?>[] paramTypes = constructor.getParameterTypes();
                        Object[] params = new Object[paramTypes.length];
                        for (int i = 0; i < paramTypes.length; i++)
                        {
                            params[i] = getDefaultValue(paramTypes[i]);
                        }
                        return constructor.newInstance(params);
                    } catch (Exception e)
                    {
                        // 继续尝试下一个构造函数
                    }
                }

            } catch (Exception e)
            {
            }

            return null;
        }

        /**
         * 获取类型的默认值
         */
        private static Object getDefaultValue(Class<?> type)
        {
            if (type == boolean.class)
                return Boolean.FALSE;
            if (type == int.class)
                return Integer.valueOf(0);
            if (type == long.class)
                return Long.valueOf(0L);
            if (type == double.class)
                return Double.valueOf(0.0);
            if (type == float.class)
                return Float.valueOf(0.0f);
            if (type == short.class)
                return Short.valueOf((short) 0);
            if (type == byte.class)
                return Byte.valueOf((byte) 0);
            if (type == char.class)
                return Character.valueOf('\0');
            return null;
        }

        /**
         * 获取类的所有字段（包括继承的）
         */
        private static java.lang.reflect.Field[] getAllFields(Class<?> type)
        {
            List<java.lang.reflect.Field> fieldList = new ArrayList<java.lang.reflect.Field>();

            Class<?> currentClass = type;
            while (currentClass != null && currentClass != Object.class)
            {
                try
                {
                    java.lang.reflect.Field[] fields = currentClass.getDeclaredFields();
                    for (java.lang.reflect.Field field : fields)
                    {
                        fieldList.add(field);
                    }
                } catch (Exception e)
                {
                }
                currentClass = currentClass.getSuperclass();
            }

            return (java.lang.reflect.Field[]) fieldList.toArray(new java.lang.reflect.Field[0]);
        }

        /**
         * 从Type中提取Class
         */
        private static Class<?> extractClass(Type type)
        {
            if (type instanceof Class)
            {
                return (Class<?>) type;
            }

            if (type instanceof java.lang.reflect.ParameterizedType)
            {
                Type rawType = ((java.lang.reflect.ParameterizedType) type).getRawType();
                if (rawType instanceof Class)
                {
                    return (Class<?>) rawType;
                }
            }

            return null;
        }

        /**
         * 生成详细的参数说明文档
         */
        public static String generateParameterDocumentation(Method method)
        {
            StringBuilder sb = new StringBuilder();
            sb.append("参数说明:\n");

            Parameter[] params = method.getParameters();
            if (params.length == 0)
            {
                sb.append("  无参数\n");
                return sb.toString();
            }

            for (int i = 0; i < params.length; i++)
            {
                Parameter param = params[i];
                sb.append("  参数").append(i + 1).append(": ").append(param.getName()).append("\n");
                sb.append("    类型: ").append(param.getType().getName()).append("\n");
                sb.append("    示例: ").append(generateParameterExample(param.getType(), param.getParameterizedType(), 0)).append("\n");
                sb.append("\n");
            }

            return sb.toString();
        }
    }

    /**
     * 生成CDo对象示例
     */
    private static String generateCDoExample(Class<?> type)
    {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("        // ").append(type.getSimpleName()).append(" 对象示例\n");
        sb.append("        \"uuid\": \"对象UUID\",\n");

        if (type.getName().contains("CDoBasic"))
        {
            sb.append("        \"owner\": \"所有者UUID\",\n");
        }

        sb.append("        // 请根据实际模型添加其他字段...\n");
        sb.append("        \"name\": \"示例名称\",\n");
        sb.append("        \"status\": 1\n");
        sb.append("      }");

        return sb.toString();
    }

    /**
     * 生成GID示例
     */
    private static String generateGIDExample()
    {
        return "{\n" + "        // GID格式: {\"className\": \"模型类名\", \"uuid\": \"对象UUID\"}\n" + "        \"className\": \"com.example.Order\",\n" + "        \"uuid\": \"order-uuid-123\"\n" + "      }";
    }

    /**
     * 生成Cnd条件示例
     */
    private static String generateCndExample()
    {
        return "{\n" + "        // Cnd条件对象，通常用于数据库查询\n" + "        // 方式1: 使用JSON字符串（推荐）\n" + "        \"cnd\": \"where('status', '=', 1).orderBy('createTime', 'desc')\",\n" + "        \n"
                + "        // 方式2: 使用Map构建简单条件\n" + "        // 注意: Cnd是复杂对象，建议使用字符串或null\n" + "        \"hint\": \"传递null或空字符串表示无条件\"\n" + "      }";
    }

    /**
     * 生成CPager分页示例
     */
    private static String generateCPagerExample()
    {
        return "{\n" + "        // CPager分页参数\n" + "        \"offset\": 0,      // 起始位置（从0开始）\n" + "        \"pageSize\": 20   // 每页数量\n" + "      }";
    }

    /**
     * 生成复杂对象示例
     */
    private static String generateComplexObjectExample(Class<?> type)
    {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("        // ").append(type.getName()).append(" 对象示例\n");

        try
        {
            java.lang.reflect.Field[] fields = type.getDeclaredFields();
            int fieldCount = 0;
            for (java.lang.reflect.Field field : fields)
            {
                if (Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers()))
                {
                    continue;
                }

                if (fieldCount >= 5)
                {
                    sb.append("        // ... 其他字段 ...\n");
                    break;
                }

                String fieldExample = generateFieldValueExample(field.getType());
                sb.append("        \"").append(field.getName()).append("\": ").append(fieldExample);
                sb.append("  // ").append(field.getType().getSimpleName()).append("\n");
                fieldCount++;
            }
        } catch (Exception e)
        {
            sb.append("        // 无法获取字段列表，请查看类定义\n");
        }

        sb.append("      }");
        return sb.toString();
    }

    /**
     * 生成字段值示例
     */
    private static String generateFieldValueExample(Class<?> type)
    {
        if (type == String.class)
            return "\"示例\"";
        if (type == int.class || type == Integer.class)
            return "0";
        if (type == long.class || type == Long.class)
            return "0";
        if (type == double.class || type == Double.class)
            return "0.0";
        if (type == boolean.class || type == Boolean.class)
            return "false";
        if (type.isEnum())
            return ParameterExampleGenerator.generateEnumExample(type);
        return "null";
    }

    /**
     * 生成详细的参数说明文档
     */
    public static String generateParameterDocumentation(Method method)
    {
        StringBuilder sb = new StringBuilder();
        sb.append("参数说明:\n");

        Parameter[] params = method.getParameters();
        if (params.length == 0)
        {
            sb.append("  无参数\n");
            return sb.toString();
        }

        for (int i = 0; i < params.length; i++)
        {
            Parameter param = params[i];
            sb.append("  参数").append(i + 1).append(": ").append(param.getName()).append("\n");
            sb.append("    类型: ").append(param.getType().getName()).append("\n");

            String description = getTypeDescription(param.getType(), param.getParameterizedType());
            sb.append("    说明: ").append(description).append("\n");
            sb.append("    示例: ").append(ParameterExampleGenerator.generateParameterExample(param.getType(), param.getParameterizedType())).append("\n");
            sb.append("\n");
        }

        return sb.toString();
    }

    /**
     * 获取类型说明
     */
    private static String getTypeDescription(Class<?> type, Type genericType)
    {
        if (type.isPrimitive() || type.getName().startsWith("java.lang"))
        {
            return "基本类型";
        }

        if (type.isArray())
        {
            return "数组类型，元素类型: " + type.getComponentType().getSimpleName();
        }

        if (Collection.class.isAssignableFrom(type))
        {
            if (genericType instanceof java.lang.reflect.ParameterizedType)
            {
                java.lang.reflect.ParameterizedType pt = (java.lang.reflect.ParameterizedType) genericType;
                Type[] actualTypes = pt.getActualTypeArguments();
                if (actualTypes.length > 0)
                {
                    return "集合类型，元素类型: " + actualTypes[0].getTypeName();
                }
            }
            return "集合类型";
        }

        if (Map.class.isAssignableFrom(type))
        {
            return "Map类型";
        }

        if (type.isEnum())
        {
            Object[] constants = type.getEnumConstants();
            if (constants != null)
            {
                StringBuilder sb = new StringBuilder("枚举类型，可选值: ");
                for (int i = 0; i < Math.min(constants.length, 5); i++)
                {
                    if (i > 0)
                        sb.append(", ");
                    sb.append(((Enum<?>) constants[i]).name());
                }
                if (constants.length > 5)
                    sb.append("...");
                return sb.toString();
            }
            return "枚举类型";
        }

        if (type.getName().contains("CSession"))
        {
            return "会话对象，需要通过登录获取。建议: 使用其他无需会话的方法，或先调用loginWithSession获取会话";
        }

        if (type.getName().contains("GID"))
        {
            return "对象标识符，格式: {\"className\": \"类名\", \"uuid\": \"UUID\"}";
        }

        if (type.getName().contains("Cnd"))
        {
            return "查询条件对象。建议: 传递null表示无条件，或使用JSON字符串格式";
        }

        return "复杂对象，请参考示例JSON结构";
    }

    /**
     * 类型转换异常
     */
    public static class TypeConversionException extends Exception
    {
        private static final long serialVersionUID = 1L;

        private Object inputValue;

        private Class<?> targetType;

        private String suggestion;

        public TypeConversionException(String message)
        {
            super(message);
        }

        public TypeConversionException(String message, Throwable cause)
        {
            super(message, cause);
        }

        public TypeConversionException(String message, Object inputValue, Class<?> targetType)
        {
            super(message);
            this.inputValue = inputValue;
            this.targetType = targetType;
        }

        public TypeConversionException(String message, Object inputValue, Class<?> targetType, String suggestion)
        {
            super(message);
            this.inputValue = inputValue;
            this.targetType = targetType;
            this.suggestion = suggestion;
        }

        public Object getInputValue()
        {
            return inputValue;
        }

        public Class<?> getTargetType()
        {
            return targetType;
        }

        public String getSuggestion()
        {
            return suggestion;
        }

        /**
         * 获取详细的错误信息，包含建议
         */
        public String getDetailedMessage()
        {
            StringBuilder sb = new StringBuilder();
            sb.append(getMessage());

            if (inputValue != null)
            {
                sb.append("\n  输入值类型: ").append(inputValue.getClass().getName());
                sb.append("\n  输入值: ").append(formatValue(inputValue));
            }

            if (targetType != null)
            {
                sb.append("\n  目标类型: ").append(targetType.getName());
                sb.append("\n  期望格式: ").append(ParameterExampleGenerator.generateParameterExample(targetType, null));
            }

            if (suggestion != null)
            {
                sb.append("\n  建议: ").append(suggestion);
            }

            return sb.toString();
        }

        private String formatValue(Object value)
        {
            if (value == null)
                return "null";

            String strValue = value.toString();
            if (strValue.length() > 100)
            {
                return strValue.substring(0, 100) + "...(长度: " + strValue.length() + ")";
            }
            return strValue;
        }
    }
}
