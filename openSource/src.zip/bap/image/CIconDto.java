package bap.image;

import com.cdao.dto.DaoDto;

public class CIconDto extends DaoDto
{
    private static final long serialVersionUID = -7633995495056207666L;
    @Override
    protected String initDaoClass()
    {
        return "com.cdao.model.CDoIcon";
    }
    
    // 用作标识取的是资源文件
    public final static String RES_PREFIX = "res://";
    
    String code;
    String md5;
    byte[] image;
    long updateTime;
    
    boolean isResource = false;

    public String getCode()
    {
        return code;
    }
    public void setCode(String code)
    {
        this.code = code;
    }
    public String getMd5()
    {
        return md5;
    }
    public void setMd5(String md5)
    {
        this.md5 = md5;
    }
    public byte[] getImage()
    {
        return image;
    }
    public void setImage(byte[] image)
    {
        this.image = image;
    }
    public long getUpdateTime()
    {
        return updateTime;
    }
    public void setUpdateTime(long updateTime)
    {
        this.updateTime = updateTime;
    }
    public boolean isResource()
    {
        return isResource;
    }
    public void setResource(boolean isResource)
    {
        this.isResource = isResource;
    }
}
