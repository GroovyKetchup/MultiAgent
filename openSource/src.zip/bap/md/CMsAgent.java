package bap.md;

import org.nutz.dao.entity.annotation.Table;

import com.cdao.model.CDoBasic;

@Table("cms_agent")
public class CMsAgent extends CDoBasic
{

    private static final long serialVersionUID = 8485292177485649540L;

}
