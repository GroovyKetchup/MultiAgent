package bap.md;

import java.util.List;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Slave;
import com.cdao.model.CDoNamed;
import com.leavay.dfc.microService.MsRegAgentPath;
import com.leavay.dfc.microService.MsRegEntryInfo;
import com.leavay.model.exception.McValidationException;

@Comment("微服务注册表")
@Table("cms_reg_entry")
public class CMsRegEntry extends CDoNamed
{
    private static final long serialVersionUID = 3239094103684526150L;

    public final static String Label = "label";
    @Column
    @Comment("标签")
    @ColDefine(width=256)
    protected String label;
    

    public final static String Description = "description";
    @Column
    @Comment("说明")
    @ColDefine(width=2000)
    protected String description;

    public final static String Version = "version";
    @Column
    @Comment("版本")
    @ColDefine(width=128)
    protected String version;

    public final static String Implement = "implement";
    @Column
    @Comment("实现类")
    @ColDefine(width=2000)
    protected String implement;

    public final static String LocalSimulator = "localSimulator";
    @Column
    @Comment("本地仿真器")
    @ColDefine(width=2000)
    protected String localSimulator;
    
    public final static String RestfulPermission = "restfulPermission";
    @Column
    @Comment("RESTful权限")
    @ColDefine(width=2000)
    protected String restfulPermission;

    public final static String IncludeList = "includeList";
    @Comment("路由白名单")
    @Slave(CMsEntryInclude.class)
    public List<CMsEntryInclude> includeList;


    public final static String ExcludeList = "excludeList";
    @Comment("路由黑名单")
    @Slave(CMsEntryExclude.class)
    public List<CMsEntryExclude> excludeList;
    
    public final static String[] FIELDS_UPDATABLE = new String[] {Label, Description, Version, Implement, LocalSimulator, RestfulPermission};

    public String getLabel()
    {
        return label;
    }


    public void setLabel(String label)
    {
        this.label = label;
    }


    public String getDescription()
    {
        return description;
    }


    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getVersion()
    {
        return version;
    }

    public void setVersion(String version)
    {
        this.version = version;
    }


    public String getImplement()
    {
        return implement;
    }


    public void setImplement(String implement)
    {
        this.implement = implement;
    }


    public String getLocalSimulator()
    {
        return localSimulator;
    }


    public void setLocalSimulator(String localSimulator)
    {
        this.localSimulator = localSimulator;
    }


    public String getRestfulPermission()
    {
        return restfulPermission;
    }


    public void setRestfulPermission(String restfulPermission)
    {
        this.restfulPermission = restfulPermission;
    }
    
    public List<CMsEntryInclude> getIncludeList()
    {
        return includeList;
    }


    public void setIncludeList(List<CMsEntryInclude> includeList)
    {
        this.includeList = includeList;
    }

    public List<CMsEntryExclude> getExcludeList()
    {
        return excludeList;
    }


    public void setExcludeList(List<CMsEntryExclude> excludeList)
    {
        this.excludeList = excludeList;
    }


    public void setServiceKey(String key) throws McValidationException
    {
        setName(key);
    }
    
    public MsRegEntryInfo toInfo(List<MsRegAgentPath> includeAgents, List<String> excludeAgents)
    {
        MsRegEntryInfo info = new MsRegEntryInfo();
        info.setRegRdn(getUuid());
        info.setServiceKey(getName());
        info.setServiceLabel(getLabel());
        info.setDesc(getDescription());
        info.setServiceVersion(getVersion());
        info.setServiceImplement(getImplement());
        info.setLocalSimulator(getLocalSimulator());
        
        info.setRouteTable(includeAgents);
        info.setExcludeAgents(excludeAgents);

        info.setRestfulPerm(getRestfulPermission());
        return info;
    }
    
    public void setByInfo(MsRegEntryInfo info) throws McValidationException
    {
        setServiceKey(info.getServiceKey());
        setLabel(info.getServiceLabel());
        setDescription(info.getDesc());
        setVersion(info.getServiceVersion());
        setImplement(info.getServiceImplement());
        setLocalSimulator(info.getLocalSimulator());
        setRestfulPermission(info.getRestfulPerm());
    }
}
