package bap.md.ver;
import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Authorizable;
import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.Nullable;
import com.cdao.entity.annotation.UserType;

@Comment("版本项目")
@Table(VersionProject.TABLE)
@Authorizable(value=false)
@TableIndexes({
          @Index(name="uniExtKey",fields={"externalKey"},unique=true)})
public class VersionProject extends com.cdao.model.CDoBasic
{
 private static final long serialVersionUID = -1929676125L;

 public static final String TABLE = "md_ver_versionproject";
 
 public static final String ProjectName="projectName";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=128)
 @Nullable(false)
 @Comment("项目名")
 public String projectName;
 public String getProjectName(){return projectName;}
 public VersionProject setProjectName(String v){this.projectName=v;return this;}

 public static final String Comments="comments";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=2000)
 @Comment("说明")
 public String comments;
 public String getComments(){return comments;}
 public VersionProject setComments(String v){this.comments=v;return this;}

 public static final String CreateTime="createTime";
 @Column
 @ColDefine(type=ColType.INT,width=20)
 @Comment("创建时间")
 @UserType(com.cdao.model.type.CDtTime.class)
 public Long createTime;
 public Long getCreateTime(){return createTime;}
 public VersionProject setCreateTime(Long v){this.createTime=v;return this;}

 public static final String Maker="maker";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=128)
 @Comment("创建人")
 @Dimension(value=com.cdao.model.CDoUser.class, isAuth=false,exemptMe=true)
 public String maker;
 public String getMaker(){return maker;}
 public VersionProject setMaker(String v){this.maker=v;return this;}

 public static final String ExternalKey="externalKey";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=512)
 @Comment("外部Key")
 public String externalKey;
 public String getExternalKey(){return externalKey;}
 public VersionProject setExternalKey(String v){this.externalKey=v;return this;}


}