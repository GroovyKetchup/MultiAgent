package bap.md.ver;
import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Authorizable;
import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;
import com.cdao.entity.annotation.Nullable;
import com.cdao.entity.annotation.UserType;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

/**
 * 
 * 作为外键子表挂在VersionProject下
 */
@Comment("版本节点")
@Table(VersionNode.TABLE)
@Foreign({@ForeignClass(VersionProject.class)})
@Authorizable(value=false)
@TableIndexes({
          @Index(name="master_key",fields={"masterKey"},unique=false), 
          @Index(name="uniVerKey",fields={"foreignKey","versionNo","key"},unique=true), 
          @Index(name="uniVerSeq",fields={"foreignKey","versionNo","seqNo"},unique=true)})
public class VersionNode extends com.cdao.model.CDoSlave
{
 private static final long serialVersionUID = 1762638520L;

 public static final String TABLE = "md_ver_versionnode";
 
 public static final String VersionNo="versionNo";
 @Column
 @ColDefine(type=ColType.INT,width=20)
 @Nullable(false)
 @Comment("版本号")
 public Long versionNo;
 public Long getVersionNo(){return versionNo;}
 public VersionNode setVersionNo(Long v){this.versionNo=v;return this;}

 public static final String SeqNo="seqNo";
 @Column
 @ColDefine(type=ColType.INT,width=20)
 @Comment("变更序号")
 public Long seqNo;
 public Long getSeqNo(){return seqNo;}
 public VersionNode setSeqNo(Long v){this.seqNo=v;return this;}

 public static final String Key="key";
 @Column (wrap = true) // Oceanbase(Mysql)关键字冲突
 @ColDefine(type=ColType.VARCHAR,width=512)
 @Comment("节点Key")
 public String key;
 public String getKey(){return key;}
 public VersionNode setKey(String v){this.key=v;return this;}

 public static final String DataBin="dataBin";
 @Column
 @ColDefine(type=ColType.BINARY)
 @Comment("数据")
 public byte[] dataBin;
 public byte[] getDataBin(){return dataBin;}
 public VersionNode setDataBin(byte[] v){this.dataBin=v;return this;}

 public static final String DataType="dataType";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=512)
 @Comment("数据类型")
 public String dataType;
 public String getDataType(){return dataType;}
 public VersionNode setDataType(String v){this.dataType=v;return this;}

 public static final String DeleteFlag="deleteFlag";
 @Column
 @Comment("删除标记")
 public Boolean deleteFlag = false;
 public Boolean getDeleteFlag(){return deleteFlag;}
 public VersionNode setDeleteFlag(Boolean v){this.deleteFlag=v;return this;}
 public boolean isDeleteFlag(){return deleteFlag!=null?deleteFlag:false;}

 public static final String Comments="comments";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=2000)
 @Comment("备注")
 public String comments;
 public String getComments(){return comments;}
 public VersionNode setComments(String v){this.comments=v;return this;}

 public static final String Commiter="commiter";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=128)
 @Comment("提交人")
 @Dimension(value=com.cdao.model.CDoUser.class, isAuth=false,exemptMe=true)
 public String commiter;
 public String getCommiter(){return commiter;}
 public VersionNode setCommiter(String v){this.commiter=v;return this;}

 public static final String CommitTime="commitTime";
 @Column
 @ColDefine(type=ColType.INT,width=20)
 @Comment("提交时间")
 @UserType(com.cdao.model.type.CDtTime.class)
 public Long commitTime= -1L;
 public Long getCommitTime(){return commitTime;}
 public VersionNode setCommitTime(Long v){this.commitTime=v;return this;}

 public String toString()
 {
     return String.format("%5d ", getVersionNo())+ " > "+ (isDeleteFlag()?"[DELETE]":"")+ToolUtilities.getString(getKey(), "")+" " +CmnUtil.time2String(getCommitTime())+ " : " + getComments()+"  (Commit by : " + getCommiter()+")";
 }

}