package bap.md;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Nullable;
import com.cdao.model.CDoBasic;
import com.cdao.model.CDoSlave;
import com.leavay.ms.tool.CmnUtil;

// 插件文件包（没发布的），作为从表挂在Plugin工程下
// 同时Owner可以挂在Root下
// 这样的双重强依赖设计，方便搜索以及双联动删除

@Table("cplugin_jar")
@TableIndexes({@Index(name="master_cls",fields={CDoSlave.MasterClass},unique=false)
    ,@Index(name="master_key",fields={CDoSlave.MasterKey},unique=false)
    ,@Index(name="master_field",fields={CDoSlave.MasterField},unique=false)
//    ,@Index(name="plugin_name_u",fields={CDoBasic.Owner, CPluginJar.Name},unique=true) // 在同一个Root父下，名称唯一
    ,@Index(name="pluginjar_name_in_project_u",fields={CPluginJar.MasterKey, CPluginJar.Name},unique=true) // 修改为在同一个工程下保持唯一，那么全局可允许重名，等到真正发布插件时再去做取舍
})
public class CPluginJar extends CJarFile
{
    private static final long serialVersionUID = -6087416132571346538L;

    public final static String[] FIELDS_BRIEF = CmnUtil.append2String(CJarFile.FIELDS_BRIEF, CPluginJar.PrivateOwn);

    public static final String PrivateOwn="privateOwn";
    @Column
    @Comment("私有的")
    public Boolean privateOwn;
    public Boolean getPrivateOwn(){return privateOwn;}
    public CPluginJar setPrivateOwn(Boolean v){this.privateOwn=v;return this;}
    public boolean isPrivateOwn(){return privateOwn!=null?privateOwn:false;}
    
    @Override
    public CDoBasic setOwner(String owner)
    {
        return super.setOwner(owner);
    }
}
