package bap.md;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.model.CDoSlave;

@Table("cms_entry_exclude")
public class CMsEntryExclude extends CDoSlave
{
    private static final long serialVersionUID = -4040362291942489421L;

    public final static String LinkAgent = "linkAgent";
    @Column
    @Comment("代理标识（名）") // 带[EXTEND]
    @ColDefine(width=1024)
    protected String linkAgent;

    public String getLinkAgent()
    {
        return linkAgent;
    }

    public void setLinkAgent(String linkAgent)
    {
        this.linkAgent = linkAgent;
    }

    public String toString()
    {
        return getLinkAgent();
    }
}
