package bap.md;
import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Authorizable;
import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.UserType;

@Table(CellConfigDo.TABLE)
@Authorizable(value=false)
public class CellConfigDo extends com.cdao.model.CDoBasic
{
 private static final long serialVersionUID = -589493664L;

 public static final String TABLE = "bap_md_cellconfig";
 
 public static final String CellClass="cellClass";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=1024)
 @Comment("细胞类名（通常为实现类）")
 public String cellClass;
 public String getCellClass(){return cellClass;}
 public CellConfigDo setCellClass(String v){this.cellClass=v;return this;}

 public static final String ConfigContent="configContent";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=3999)
 @Comment("配置内容（JSON）")
 public String configContent;
 public String getConfigContent(){return configContent;}
 public CellConfigDo setConfigContent(String v){this.configContent=v;return this;}

 public static final String Modifier="modifier";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=128)
 @Comment("修改人")
 @Dimension(value=com.cdao.model.CDoUser.class, isAuth=false,exemptMe=false)
 public String modifier;
 public String getModifier(){return modifier;}
 public CellConfigDo setModifier(String v){this.modifier=v;return this;}

 public static final String ModifyTime="modifyTime";
 @Column
 @ColDefine(type=ColType.INT,width=20)
 @Comment("修改时间")
 @UserType(com.cdao.model.type.CDtTime.class)
 public Long modifyTime;
 public Long getModifyTime(){return modifyTime;}
 public CellConfigDo setModifyTime(Long v){this.modifyTime=v;return this;}


}