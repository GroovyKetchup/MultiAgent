package bap.md;

import java.util.List;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Slave;
import com.cdao.model.CDaoSingleton;
import com.cdao.model.CDoBasic;
import com.leavay.common.util.ToolUtilities;

@Table("cplugin_root")
public class CPluginRoot extends CDoBasic implements CDaoSingleton
{
    private static final long serialVersionUID = 2337226219776507852L;

    // 就是创建或修改的时间
    public static final String TimeTag = "timeTag";

    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("时间戳")
    public Long timeTag;

    public Long getTimeTag()
    {
        return timeTag;
    }

    public CPluginRoot setTimeTag(Long timeTag)
    {
        this.timeTag = timeTag;
        return this;
    }

    // Root下挂真正发布了的Jar包文件
    public static final String JarFiles = "jarFiles";

    @Slave(CPluginJarPublished.class)
    public List<CPluginJarPublished> jarFiles;
    
    public List<CPluginJarPublished> getJarFiles()
    {
        return jarFiles;
    }

    public void setJarFiles(List<CPluginJarPublished> jarFiles)
    {
        this.jarFiles = jarFiles;
    }

    public static final String DirtyFlag = "dirtyFlag";

    @Column
    @Comment("未发布脏标记")
    public Boolean dirtyFlag;

    public Boolean getDirtyFlag()
    {
        return dirtyFlag;
    }

    public CPluginRoot setDirtyFlag(Boolean v)
    {
        this.dirtyFlag = v;
        if (v == null || !v)
            setDirtyMessage(null);
        return this;
    }

    public CPluginRoot setDirty(String message)
    {
        setDirtyFlag(true);
        setDirtyMessage(message);
        return this;
    }

    public boolean isDirty()
    {
        return dirtyFlag != null ? dirtyFlag : false;
    }
    

    public static final String DirtyMessage="dirtyMessage";
    @Column
    @ColDefine(type=ColType.VARCHAR,width=2000)
    @Comment("脏标记注解")
    public String dirtyMessage;
    public String getDirtyMessage(){return dirtyMessage;}
    public CPluginRoot setDirtyMessage(String v){this.dirtyMessage=v;return this;}


    public void initSingleton()
    {
        setTimeTag((long) -1);
        setDirtyFlag(false);
    }
    
}
