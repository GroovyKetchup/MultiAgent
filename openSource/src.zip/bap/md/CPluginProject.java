package bap.md;

import java.util.List;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Description;
import com.cdao.entity.annotation.Slave;
import com.cdao.entity.annotation.UserType;
import com.cdao.model.CDoNamed;

// 就是个目录，从表里挂JAR
// Owner指向Root

@Comment("插件工程")
@Table("cplugin_project")
public class CPluginProject extends CDoNamed
{

    private static final long serialVersionUID = 4459841991858760476L;
    
    // 单步之下挂子流程
    public static final String JarFiles = "jarFiles";
    @Slave(CPluginJar.class)
    public List<CPluginJar> jarFiles;

    public List<CPluginJar> getJarFiles()
    {
        return jarFiles;
    }

    public void setJarFiles(List<CPluginJar> jarFiles)
    {
        this.jarFiles = jarFiles;
    }
    

    public static final String TimeTag="timeTag";
    @Column
    @ColDefine(type=ColType.INT,width=20)
    @Comment("时间戳（非必要）")
    @Description("仅对于类似集群上层桥接插件等可能需要")
    @UserType(com.cdao.model.type.CDtTime.class)
    public Long timeTag;
    public Long getTimeTag(){return timeTag;}
    public CPluginProject setTimeTag(Long v){this.timeTag=v;return this;}

}
