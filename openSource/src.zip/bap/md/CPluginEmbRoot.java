package bap.md;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.mgr.CDaoUtil;
import com.cdao.model.CDaoSingleton;
import com.leavay.ms.tool.CmnUtil;

import bap.plugin.mgr.CPluginCenter;

// 虚拟的上一级插件工程
@Table("cplugin_emb_root")
@Comment("承接上一级分发的插件挂载点")
@TableIndexes({@Index(name="uniqu_plugin_emb_root", fields= {CPluginEmbRoot.ParentTimeTag}, unique= true)})
public class CPluginEmbRoot extends CPluginProject implements CDaoSingleton
{
    private static final long serialVersionUID = 2337226219776507852L;

    // 就是创建或修改的时间
    public static final String ParentTimeTag = "parentTimeTag";

    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("上一级时间戳")
    public Long parentTimeTag;

    public Long getParentTimeTag()
    {
        return parentTimeTag;
    }

    public void setParentTimeTag(Long parentTimeTag)
    {
        this.parentTimeTag = parentTimeTag;
    }

    public void initSingleton() throws Exception
    {
        setName(CDaoUtil.getString("Embed upper plugin"));
        setOwner(CPluginCenter.getMe().getRoot().getUuid());
    }
    
    public String toString()
    {
        if (getParentTimeTag() > 0)
            return getName() + " ("+CDaoUtil.getString("Publish Time") + " : " + CmnUtil.time2String(getParentTimeTag(), true)+")";
        else
            return getName();
    }
}
