package bap.md.yun;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Authorizable;
import com.cdao.model.CDaoSingleton;
import com.cdao.model.CDoBasic;
import com.leavay.common.util.SJsonList;
import com.leavay.common.util.SJsonMap;

import bap.md.java.CJavaProject;
import cmn.util.Nulls;

/**
 * 全局唯一Singleton，存储整个服务对外的依赖的偏好设定
 */
@Comment("全局依赖设定")
@Table(GlobalDependSetting.TABLE)
@Authorizable(value = false)
public class GlobalDependSetting extends CDoBasic implements CDaoSingleton
{
    private static final long serialVersionUID = -2008082229L;

    public static final String TABLE = "bap_md_yun_globaldependsetting";
    
    // 此非DO字段，不入库
    // 用于前后端交互，单独显式导入的云组件设定（会以外键挂接的方式挂在GlobalDependSetting下）
    List<ArtifactDefine> lstImportArtifact;
    
    // 此为非DO存储字段，只是用于传递数据（后端吐给前端使用）
    // 从后台查询时，通过搜索各个工程的设定获取依赖
    List<ArtifactDefine> lstDependArtifact;
    
    // 本地配置文件存储了静态排除列表，防止下载重复的云组件
    Set<String> excludeArtifactList;
    
    // 此非DO存储字段，只是用于传递相关的JAVA工程信息
    // Key=ArtifactDefine的UUID，对应依赖项的masterKey（而并非工程自身UUID），Value是所属工程
    Map<String, CJavaProject> mapProject;
    
    // 这个偏好设定，精确到具体某个依赖包的优先或是排除的设定 SJsonMap
    public static final String PreferConfig = "preferConfig";
    @Column
    @ColDefine(type=ColType.VARCHAR,width=3000)
    public String preferConfig;
    public String getPreferConfig()
    {
        return preferConfig;
    }
    public GlobalDependSetting setPreferConfig(String v)
    {
        this.preferConfig = v;
        return this;
    }
    public SJsonMap getPreferConfigMap()
    {
        return SJsonMap.from(getPreferConfig());
    }
    
    public void setPreferConfig(SJsonMap map)
    {
        setPreferConfig(map==null?null:map.toJson());
    }

    public void initSingleton() throws Exception
    {

    }
    
    public List<ArtifactDefine> getLstDependArtifact()
    {
        return lstDependArtifact;
    }
    
    public void setLstDependArtifact(List<ArtifactDefine> lstDependArtifact)
    {
        this.lstDependArtifact = lstDependArtifact;
    }
    
    public List<ArtifactDefine> getLstImportArtifact()
    {
        return lstImportArtifact;
    }
    
    public void setLstImportArtifact(List<ArtifactDefine> lstImportArtifact)
    {
        this.lstImportArtifact = lstImportArtifact;
    }
    
    public void addImportArtifact(ArtifactDefine def)
    {
        if (lstImportArtifact == null)
            lstImportArtifact = new LinkedList<ArtifactDefine>();
        
        lstImportArtifact.add(def);
    }
    
    public Map<String, CJavaProject> getMapProject()
    {
        return mapProject;
    }
    
    public void setMapProject(Map<String, CJavaProject> mapProject)
    {
        this.mapProject = mapProject;
    }
    
    public boolean isLocalProject(ArtifactDefine art)
    {
        for (CJavaProject pj  : Nulls.get(mapProject).values())
        {
            if (pj.getName().equals(art.getArtifactId()))
                return true;
        }
        
        return false;
    }
    
    public Set<String> getExcludeArtifactList()
    {
        return excludeArtifactList;
    }
    
    public void setExcludeArtifactList(Set<String> excludeArtifactList)
    {
        this.excludeArtifactList = excludeArtifactList;
    }

    public boolean isExcludeArtifact(ArtifactDefine art)
    {
        return isExcludeArtifact(art.getArtifactId());
    }
    
    public boolean isExcludeArtifact(String artifactId)
    {
        return excludeArtifactList==null?false:excludeArtifactList.contains(artifactId);
    }
    
}