package bap.md.yun;
import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Attach;
import com.cdao.entity.annotation.Authorizable;
import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.FieldOrder;
import com.cdao.entity.annotation.UserType;
import com.cdao.model.CDoUser;
import com.cdao.model.type.AttachBrief;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import bap.yun.ArtifactUtil;

/**
 * 发布在云仓库中的组件对象实体（内涵发布包、工程文件、文档、模型文件等等）
 * 
 * 以DoLink关联到依赖的目标artifact，这个依赖暂定为很弱的
 * 虽派生于ArtifactDefine，只是为了共性字段，DependTo无用
 * 
 */
@Comment("云组件")
@Table(ArtifactWare.TABLE)
@Authorizable(value=false)
@TableIndexes(value = {
    @Index(name="uni_art_ver",fields={ArtifactWare.ArtifactId, ArtifactWare.Version},unique=true)}, inheritSuperIndexs = true) // 直接以Artifact+Version为唯一标识，不同组织也不允许整同名Artifact
@FieldOrder({ArtifactWare.GroupId, ArtifactWare.ArtifactId, ArtifactWare.Version, ArtifactWare.VersionSeq, ArtifactWare.UUID, ArtifactWare.Owner, ArtifactWare.ForeignClass, ArtifactWare.ForeignKey})
public class ArtifactWare extends ArtifactDefine
{
 private static final long serialVersionUID = 484564510L;

 public static final String TABLE = "md_yun_store_storeware";

 public static final String ProjectPkg="projectPkg";
 @Column
 @Comment("工程包(ZIP)")
 @Attach
 @UserType(com.cdao.model.type.CDtAttachSingle.class)
 public AttachBrief projectPkg;
 public AttachBrief getProjectPkg(){return projectPkg;}
 public ArtifactWare setProjectPkg(AttachBrief v){this.projectPkg=v;return this;}

 public static final String ReleasePkg="releasePkg";
 @Column
 @Comment("发布包")
 @Attach
 public AttachBrief releasePkg;
 public AttachBrief getReleasePkg(){return releasePkg;}
 public ArtifactWare setReleasePkg(AttachBrief v){this.releasePkg=v;return this;}

 // 附件名都为无后缀的全类名
 // 如果是动态模型（默认），以json格式TEXT附件的形式存储
 // 也允许静态模型（暂时无用），以二进制附件存储
 public static final String ModelPkg="modelPkg";
 @Column
 @Comment("模型定义包")
 @Attach
 public AttachBrief modelPkg;
 public AttachBrief getModelPkg(){return modelPkg;}
 public ArtifactWare setModelPkg(AttachBrief v){this.modelPkg=v;return this;}
 
 public static final String PublishTime="publishTime";
 @Column
 @ColDefine(type=ColType.INT,width=20)
 @Comment("发布时间")
 @UserType(com.cdao.model.type.CDtTime.class)
 public Long publishTime;
 public Long getPublishTime(){return publishTime;}
 public ArtifactWare setPublishTime(Long v){this.publishTime=v;return this;}
 

 public static final String Commiter="commiter";
 @Column
 @ColDefine(type=ColType.VARCHAR,width=2000)
 @Comment("提交人")
 @Dimension(value=CDoUser.class)
 public String commiter;
 public String getCommiter(){return commiter;}
 public ArtifactWare setCommiter(String v){this.commiter=v;return this;}
 

 public final static String[] FIELDS_BRIEF = CmnUtil.append(ArtifactDefine.FIELDS_BRIEF, PublishTime, Commiter);
 
 public String getArtifactKey()
 {
     return ArtifactUtil.getKey(getArtifactId(), getVersion());
 }
 
 public ArtifactDefine toDefine()
 {
     try
    {
        return ToolUtilities.copyFields(this, new ArtifactDefine(), false);
    } catch (Exception exp)
    {
        ToolUtilities.throwRuntimeException(exp);
        return null;
    }
 }
 
 public String toString()
 {
     return getArtifactId()+ " - " + getVersion()+ "   ["+getGroupId()+"]";
 }
 
}