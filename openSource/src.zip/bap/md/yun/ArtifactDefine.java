package bap.md.yun;

import java.util.List;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Authorizable;
import com.cdao.entity.annotation.FieldOrder;
import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;
import com.cdao.entity.annotation.Slave;
import com.cdao.entity.annotation.UserType;
import com.cdao.impl.entity.field.SlaveTable;
import com.cdao.model.CDoSlave;
import com.leavay.common.util.SJsonList;
import com.leavay.common.util.SJsonMap;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import bap.md.java.CJavaProject;
import bap.yun.ArtifactUtil;
import bap.yun.InvalidArtifactVersionException;

/**
 * 外键挂接： 1、挂在JAVA工程下，代表该工程自身的定义，每一个Java Project下唯一一个
 * 2、挂在GlobalDependSetting（根）下，作为人为设定显式导入的云组件（如买入的组件）
 * 
 * 当没有设定Foreign Key时： 1、可作为从表挂在另一个AritfactDefine，作为其依赖设定
 * 
 * 内含对依赖目标的定义从表（无关联，纯字符串定义）
 * 
 */

@Table(ArtifactDefine.TABLE)
@Foreign({ @ForeignClass(CJavaProject.class), @ForeignClass(GlobalDependSetting.class) })
@Authorizable(value = false)
@TableIndexes({ @Index(name = "unique_projectKey", fields = { ArtifactDefine.ForeignKey, ArtifactDefine.GroupId, ArtifactDefine.ArtifactId }, unique = true) })
@FieldOrder({ ArtifactDefine.GroupId, ArtifactDefine.ArtifactId, ArtifactDefine.Version, ArtifactDefine.VersionSeq, ArtifactDefine.Description, ArtifactDefine.MainPage, ArtifactDefine.ExclusiveModel })
public class ArtifactDefine extends CDoSlave
{
    private static final long serialVersionUID = -52863136019101156L;

    public static final String TABLE = "bap_md_yun_artifactdefine";

    public static final String GroupId = "groupId";

    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("组织编码")
    public String groupId;

    public String getGroupId()
    {
        return groupId;
    }

    public ArtifactDefine setGroupId(String v)
    {
        this.groupId = v;
        return this;
    }

    public static final String ArtifactId = "artifactId";

    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("组件编号")
    public String artifactId;

    public String getArtifactId()
    {
        return artifactId;
    }

    public ArtifactDefine setArtifactId(String v)
    {
        this.artifactId = v;
        return this;
    }

    /**
     * 版本的格式必须是 xx.xx.xx_??? 以左边序第一个下划线（如果有）作为分隔，左边是版本号、右边是标注
     * 版本号格式：必须不能多余四级版本号，每一级版本最大值不得大于9999，也就是最大版本号9999.9999.9999.9999_xxx
     * 最右的标注字段作为String被纳入排序，一般以版本号为排序
     * 
     * 版本号会被转义补零5位数，成为可排序的版本序列号，以便数据库自动排序：0001.0035.0003.0000_xxx
     */
    public static final int MAX_VER_NUM = 99999;

    public static final int MAX_VER_CNT = 4; // 以“.”作为分段的最大分段数

    public static final String VER_FORMATER = "%05d";

    public static final String Version = "version";

    @Column
    @ColDefine(type = ColType.VARCHAR, width = 64)
    @Comment("版本")
    public String version;

    public String getVersion()
    {
        return version;
    }

    public ArtifactDefine setVersion(String v) throws InvalidArtifactVersionException
    {
        setVersionSeq(version2Seq(v));
        this.version = v;
        return this;
    }

    public final static String version2Seq(String ver) throws InvalidArtifactVersionException
    {
        if (CmnUtil.isStringEmpty(ver))
            return null;

        String mark = null;
        int dashPos = ver.indexOf("_");
        if (dashPos < 0)
            dashPos = ver.indexOf("-");

        if (dashPos > 0)
        {
            mark = ver.substring(dashPos + 1);
            ver = ver.substring(0, dashPos);
        }

        List<String> lstVer = ToolUtilities.getSplitedString(ver, ".", false);
        if (lstVer.size() > MAX_VER_CNT)
            throw new InvalidArtifactVersionException(ver, "Amount of version should be less than " + MAX_VER_CNT);

        String seq = "";
        for (int i = 0; i < MAX_VER_CNT; i++)
        {
            // 可以是数字，也可是任意字符
            String sec = "";

            if (i < lstVer.size())
            {
                sec = lstVer.get(i);

                if (CmnUtil.isInteger(sec))
                {
                    // 转换数字、补零
                    int intV = Integer.parseInt(lstVer.get(i));
                    if (intV < 0 || intV > MAX_VER_NUM)
                        throw new InvalidArtifactVersionException(ver, "Illegal format of version, should be integer between 0 - " + MAX_VER_NUM + " : " + intV);

                    // 数字需补零
                    sec = String.format(VER_FORMATER, intV);
                }
            } else
                sec = String.format(VER_FORMATER, 0); // 缺少的section则强行补全零，以确保排序正确

            if (!seq.isEmpty())
                seq += ".";
            seq += sec;
        }

        if (!CmnUtil.isStringEmpty(mark))
            seq += "_" + mark;

        return seq;
    }

    public static final String VersionSeq = "versionSeq";

    @Column
    @ColDefine(type = ColType.VARCHAR, width = 64)
    @Comment("版本序列号")
    public String versionSeq;

    public String getVersionSeq()
    {
        return versionSeq;
    }

    protected ArtifactDefine setVersionSeq(String v)
    {
        this.versionSeq = v;
        return this;
    }
    

    public static final String VersionComments="versionComments";
    @Column
    @ColDefine(type=ColType.VARCHAR,width=1024)
    @Comment("版本说明")
    public String versionComments;
    public String getVersionComments(){return versionComments;}
    public ArtifactDefine setVersionComments(String v){this.versionComments=v;return this;}


    public static final String IconImg="iconImg";
    @Column
    @Comment("图标")
    @ColDefine(type=ColType.BINARY)
    @UserType(com.cdao.model.type.CDtImage.class)
    public byte[] iconImg;
    public byte[] getIconImg(){return iconImg;}
    public ArtifactDefine setIconImg(byte[] v){this.iconImg=v;return this;}
    
    public static final String Description = "description";

    @Column
    @ColDefine(type = ColType.VARCHAR, width = 2048)
    @Comment("描述")
    public String description;

    public String getDescription()
    {
        return description;
    }

    public ArtifactDefine setDescription(String v)
    {
        this.description = v;
        return this;
    }

    public static final String MainPage = "mainPage";

    @Column
    @ColDefine(type = ColType.BINARY)
    @Comment("主页")
    @UserType(com.cdao.model.type.CDtRichDocument.class)
    public byte[] mainPage;

    public byte[] getMainPage()
    {
        return mainPage;
    }

    public ArtifactDefine setMainPage(byte[] v)
    {
        this.mainPage = v;
        return this;
    }

    public static final String ExclusiveModel = "exclusiveModel";

    @Column
    @ColDefine(type = ColType.VARCHAR, width = 10000)
    @Comment("专属模型")
    public String exclusiveModel;

    public String getExclusiveModel()
    {
        return exclusiveModel;
    }

    public ArtifactDefine setExclusiveModel(String v)
    {
        this.exclusiveModel = v;
        return this;
    }

    public SJsonList getExclusiveModelList()
    {
        return SJsonList.from(getExclusiveModel());
    }

    public ArtifactDefine setExclusiveModelList(SJsonList lst)
    {
        setExclusiveModel(SJsonList.toJson(lst));
        return this;
    }

    public static final String DependTo = "dependTo";

    @Slave(ArtifactDefine.class)
    @Comment("依赖列表")
    public SlaveTable<ArtifactDefine> dependTo;

    public SlaveTable<ArtifactDefine> getDependTo()
    {
        return dependTo;
    }

    public ArtifactDefine setDependTo(SlaveTable<ArtifactDefine> v)
    {
        this.dependTo = v;
        return this;
    }
    

    public static final String ExtendData = "extendData";

    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("扩展属性表")
    public String extendData;
    
    public String getExtendData()
    {
        return extendData;
    }

    public ArtifactDefine setExtendData(String extendData)
    {
        this.extendData = extendData;
        return this;
    }
    
    public SJsonMap getExtendDataMap()
    {
        return SJsonMap.from(getExtendData());
    }

    public String getArtifactKey()
    {
        return ArtifactUtil.getKey(getArtifactId(), getVersion());
    }

    public final static String[] FIELDS_BRIEF = CmnUtil.append(FIELDS_BASIC, GroupId, ArtifactId, Version, Description);

    public ArtifactDefine setDefine(ArtifactDefine other)
    {
        setGroupId(other.getGroupId());
        setArtifactId(other.getArtifactId());
        setVersion(other.getVersion());
        setDescription(other.getDescription());
        setIconImg(other.getIconImg());
        setMainPage(other.getMainPage());
        setExclusiveModelList(other.getExclusiveModelList());
        setExtendData(other.getExtendData());
        return this;
    }

    public static ArtifactDefine build(String groupId, String artifactId, String version)
    {
        return new ArtifactDefine().setGroupId(groupId).setArtifactId(artifactId).setVersion(version);
    }
    
    // 比较ArtifactID+Version是否一致
    public boolean isDefineSame(ArtifactDefine other)
    {
        return other != null && CmnUtil.isStringEqual(getArtifactId(), other.getArtifactId()) && CmnUtil.isStringEqual(getVersion(), other.getVersion());
    }

    public String getName()
    {
        return getGroupId() + "-" + getArtifactId();
    }

    public String toString()
    {
        return getGroupId() + "-" + getArtifactId() + " [" + getVersion() + "]";
    }
}