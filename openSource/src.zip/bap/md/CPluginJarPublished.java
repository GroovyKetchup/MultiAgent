package bap.md;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Nullable;
import com.cdao.model.CDoBasic;
import com.cdao.model.CDoSlave;
import com.leavay.ms.tool.CmnUtil;

// 真正发布的插件包（平行存储在root下）
// 作为从表挂在Root下 （Master指向root）

@Comment("已发布插件包")
@Table("cplugin_jar_pub")
@TableIndexes({@Index(name="master_cls",fields={CDoSlave.MasterClass},unique=false)
    ,@Index(name="master_key",fields={CDoSlave.MasterKey},unique=false)
    ,@Index(name="master_field",fields={CDoSlave.MasterField},unique=false)
//    ,@Index(name="plugin_name_u",fields={CDoBasic.Owner, CPluginJarPublished.Name},unique=true) // 在同一个Root父下，名称唯一
    ,@Index(name="plugin_pub_name_u",fields={CPluginJarPublished.MasterKey, CPluginJarPublished.Name},unique=true) // 在同一个Root父下，名称唯一
})
public class CPluginJarPublished extends CDoSlave
{

    private static final long serialVersionUID = -6087416132571346538L;

    public static final String Name="name";

    public static final String ProjectClass="projectClass";
    public static final String ProjectUuid="projectUuid";
    
    public static final String Size="size";
    public static final String FileMd5 = "fileMd5";
    public static final String FileBin="fileBin";
    
    public final static String[] FIELDS_BRIEF = CmnUtil.append(CDoSlave.MasterFields, UUID, Owner, Name, Size, FileMd5);
    
    @Column
    @Comment("名字")
    @ColDefine(width=256)
    protected String name;
    
    @Column
    @Comment("来源项目UUID")
    protected String projectUuid;
    

    @Column
    @Comment("来源项目类型")
    @ColDefine(width=1024)
    protected String projectClass;
    
    public String getName()
    {
        return name;
    }

    public CPluginJarPublished setName(String name)
    {
        this.name = name;
        return this;
    }

    public String getProjectClass()
    {
        return projectClass;
    }

    public void setProjectClass(String projectClass)
    {
        this.projectClass = projectClass;
    }

    public String getProjectUuid()
    {
        return projectUuid;
    }

    public void setProjectUuid(String projectUuid)
    {
        this.projectUuid = projectUuid;
    }


    @Column
    @ColDefine(type=ColType.INT,width=18)
    @Comment("大小(字节数）")
    public Long size;
    
    public Long getSize()
    {
        return size;
    }

    public CPluginJarPublished setSize(Long size)
    {
        this.size = size;
        return this;
    }
    
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Nullable(false)
    @Comment("MD5码")
    public String fileMd5;


    public String getFileMd5()
    {
        return fileMd5;
    }

    public void setFileMd5(String fileMd5)
    {
        this.fileMd5 = fileMd5;
    }

    @Column
    @ColDefine(type=ColType.BINARY)
    protected byte[] fileBin;

    public byte[] getFileBin()
    {
        return fileBin;
    }

    public void setFileBin(byte[] fileBin)
    {
        this.fileBin = fileBin;
    }
    
    public static final String PrivateOwn="privateOwn";
    @Column
    @Comment("私有的")
    public Boolean privateOwn;
    public Boolean getPrivateOwn(){return privateOwn;}
    public CPluginJarPublished setPrivateOwn(Boolean v){this.privateOwn=v;return this;}
    public boolean isPrivateOwn(){return privateOwn!=null?privateOwn:false;}
}
