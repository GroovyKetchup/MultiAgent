package bap.md.opm.cpu;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmMetricExtDo;
import bap.md.opm.OpmMetricMainDo;

@Comment("OPM CPU采集附表")
@Table(OpmCpuMetricDo.TABLE)
@Foreign({ @ForeignClass(OpmMetricMainDo.class) })
public class OpmCpuMetricDo extends OpmMetricExtDo
{
    private static final long serialVersionUID = -1748221205759951808L;

    public static final String TABLE = "opm_cpu_metric";

    public static final String HostName = "hostName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("主机名")
    public String hostName;

    public static final String OsName = "osName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("操作系统")
    public String osName;

    public static final String Provider = "provider";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集实现")
    public String provider;

    public static final String CpuUsageRate = "cpuUsageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("CPU总使用率")
    public Double cpuUsageRate;

    public static final String UserRate = "userRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("用户态CPU占比")
    public Double userRate;

    public static final String SystemRate = "systemRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("内核态CPU占比")
    public Double systemRate;

    public static final String IdleRate = "idleRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("CPU空闲占比")
    public Double idleRate;

    public static final String TopProcCount = "topProcCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("Top进程数")
    public Integer topProcCount;

    public static final String TopProcName = "topProcName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("Top进程名称")
    public String topProcName;

    public static final String TopProcCpuRate = "topProcCpuRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("Top进程CPU占比")
    public Double topProcCpuRate;

    public static final String DetailJson = "detailJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("详细JSON")
    public String detailJson;
}
