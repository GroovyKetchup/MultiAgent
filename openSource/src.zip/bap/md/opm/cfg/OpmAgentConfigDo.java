package bap.md.opm.cfg;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Authorizable;
import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;
import com.cdao.entity.annotation.UserType;
import com.cdao.model.CDoBasic;

import tiny.service.md.TsAgentDo;

@Comment("OPM代理配置")
@Table(OpmAgentConfigDo.TABLE)
@Foreign({ @ForeignClass(TsAgentDo.class) })
@Authorizable(value = false)
@TableIndexes({ @Index(name = "opm_cfg_agent_fk_u", fields = { OpmAgentConfigDo.ForeignKey }, unique = true) })
public class OpmAgentConfigDo extends CDoBasic
{
    private static final long serialVersionUID = -8474623856433939539L;

    public static final String TABLE = "opm_agent_config";

    public static final String AgentCode = "agentCode";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("代理编码")
    @Dimension(value = TsAgentDo.class, isAuth = false, exemptMe = true)
    public String agentCode;

    public static final String AgentName = "agentName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("代理名称")
    public String agentName;

    public static final String MyUri = "myUri";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 1024)
    @Comment("进程URI")
    public String myUri;

    public static final String UpdateTime = "updateTime";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("更新时间")
    @UserType(com.cdao.model.type.CDtTime.class)
    public Long updateTime;

    public static final String ConfigJson = "configJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("配置文本(JSON)")
    public String configJson;
}
