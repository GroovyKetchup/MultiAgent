package bap.md.opm.pg;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmMetricExtDo;
import bap.md.opm.OpmMetricMainDo;

@Comment("PG数据库监控指标")
@Table(OpmPgMetricDo.TABLE)
@Foreign({ @ForeignClass(OpmMetricMainDo.class) })
public class OpmPgMetricDo extends OpmMetricExtDo
{
    private static final long serialVersionUID = 1L;

    public static final String TABLE = "opm_pg_metric";

    public static final String DbName = "dbName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("数据库名")
    public String dbName;

    public static final String LongSqlCount = "longSqlCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("长时SQL数量")
    public Integer longSqlCount;

    public static final String MaxSqlDurationSec = "maxSqlDurationSec";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("最长SQL时长(秒)")
    public Double maxSqlDurationSec;

    public static final String BlockedSqlCount = "blockedSqlCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("阻塞SQL数量")
    public Integer blockedSqlCount;

    public static final String DbSizeBytes = "dbSizeBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("数据库大小(字节)")
    public Long dbSizeBytes;

    public static final String TablespaceUsageRate = "tablespaceUsageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("表空间使用率")
    public Double tablespaceUsageRate;

    public static final String GrowthRateBytesPerHour = "growthRateBytesPerHour";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("空间增长速率(字节/小时)")
    public Double growthRateBytesPerHour;

    public static final String LockWaitCount = "lockWaitCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("锁等待数量")
    public Integer lockWaitCount;

    public static final String MaxLockWaitSec = "maxLockWaitSec";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("最大锁等待时长(秒)")
    public Double maxLockWaitSec;

    public static final String LongLockCount = "longLockCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("长时锁会话数量")
    public Integer longLockCount;

    public static final String MaxLongLockSec = "maxLongLockSec";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("最长持锁时长(秒)")
    public Double maxLongLockSec;

    public static final String DeadlockCount = "deadlockCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("死锁数量(累计)")
    public Integer deadlockCount;

    public static final String DeadlockDeltaCount = "deadlockDeltaCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("死锁数量增量")
    public Integer deadlockDeltaCount;

    public static final String TotalConnCount = "totalConnCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("总连接数")
    public Integer totalConnCount;

    public static final String ActiveConnCount = "activeConnCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("活动连接数")
    public Integer activeConnCount;

    public static final String IdleConnCount = "idleConnCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("空闲连接数")
    public Integer idleConnCount;

    public static final String IdleInTxnConnCount = "idleInTxnConnCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("空闲事务连接数")
    public Integer idleInTxnConnCount;

    public static final String MaxConnLimit = "maxConnLimit";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("最大连接数限制")
    public Integer maxConnLimit;

    public static final String ConnUsageRate = "connUsageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("连接使用率")
    public Double connUsageRate;

    public static final String TxnCommitCount = "txnCommitCount";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("事务提交数(累计)")
    public Long txnCommitCount;

    public static final String TxnRollbackCount = "txnRollbackCount";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("事务回滚数(累计)")
    public Long txnRollbackCount;

    public static final String ReplicationRole = "replicationRole";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 32)
    @Comment("复制角色(primary/standby)")
    public String replicationRole;

    public static final String ReplicationLagSec = "replicationLagSec";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("复制延迟(秒)")
    public Double replicationLagSec;

    public static final String ReplicationState = "replicationState";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 64)
    @Comment("复制状态")
    public String replicationState;

    public static final String ReplicationConnCount = "replicationConnCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("复制连接数")
    public Integer replicationConnCount;

    public static final String DetailJson = "detailJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("详细JSON")
    public String detailJson;
}
