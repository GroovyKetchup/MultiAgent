package bap.md.opm.pg;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;
import com.cdao.model.CDoBasic;

@Comment("PG长时SQL详情")
@Table(OpmPgSqlDetailDo.TABLE)
@Foreign({ @ForeignClass(OpmPgMetricDo.class) })
public class OpmPgSqlDetailDo extends CDoBasic
{
    private static final long serialVersionUID = 1L;

    public static final String TABLE = "opm_pg_sql_detail";

    public static final String Pid = "pid";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("PG进程PID")
    public Integer pid;

    public static final String QueryText = "queryText";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 4000)
    @Comment("SQL文本(截断)")
    public String queryText;

    public static final String QueryState = "queryState";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 32)
    @Comment("状态")
    public String queryState;

    public static final String DurationSec = "durationSec";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("执行时长(秒)")
    public Double durationSec;

    public static final String WaitEventType = "waitEventType";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 64)
    @Comment("等待事件类型")
    public String waitEventType;

    public static final String WaitEvent = "waitEvent";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 64)
    @Comment("等待事件")
    public String waitEvent;

    public static final String ApplicationName = "applicationName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("应用名称")
    public String applicationName;

    public static final String ClientAddr = "clientAddr";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("客户端地址")
    public String clientAddr;
}