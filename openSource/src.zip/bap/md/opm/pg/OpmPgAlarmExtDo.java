package bap.md.opm.pg;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmAlarmExtDo;
import bap.md.opm.OpmAlarmRefDo;

@Comment("PG告警扩展信息")
@Table(OpmPgAlarmExtDo.TABLE)
@Foreign({ @ForeignClass(OpmAlarmRefDo.class) })
public class OpmPgAlarmExtDo extends OpmAlarmExtDo
{
    private static final long serialVersionUID = 1L;

    public static final String TABLE = "opm_pg_alarm_ext";

    public static final String AlarmType = "alarmType";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 64)
    @Comment("告警类型")
    public String alarmType;

    public static final String MetricName = "metricName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("指标名称")
    public String metricName;

    public static final String CurrentValue = "currentValue";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("当前值")
    public Double currentValue;

    public static final String ThresholdValue = "thresholdValue";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("阈值")
    public Double thresholdValue;

    public static final String DurationSec = "durationSec";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("持续时间(秒)")
    public Integer durationSec;

    public static final String TriggerLevel = "triggerLevel";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 32)
    @Comment("触发级别")
    public String triggerLevel;

    public static final String SqlText = "sqlText";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 4000)
    @Comment("SQL文本")
    public String sqlText;

    public static final String Pid = "pid";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("进程PID")
    public Integer pid;

    public static final String DbName = "dbName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("数据库名")
    public String dbName;
}