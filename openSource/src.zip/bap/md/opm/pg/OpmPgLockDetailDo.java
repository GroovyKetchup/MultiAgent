package bap.md.opm.pg;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;
import com.cdao.model.CDoBasic;

@Comment("PG锁等待详情")
@Table(OpmPgLockDetailDo.TABLE)
@Foreign({ @ForeignClass(OpmPgMetricDo.class) })
public class OpmPgLockDetailDo extends CDoBasic
{
    private static final long serialVersionUID = 1L;

    public static final String TABLE = "opm_pg_lock_detail";

    public static final String BlockedPid = "blockedPid";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("被阻塞PID")
    public Integer blockedPid;

    public static final String BlockedQuery = "blockedQuery";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("被阻塞SQL")
    public String blockedQuery;

    public static final String BlockingPid = "blockingPid";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("阻塞源PID")
    public Integer blockingPid;

    public static final String BlockingQuery = "blockingQuery";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("阻塞源SQL")
    public String blockingQuery;

    public static final String WaitSec = "waitSec";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("等待时长(秒)")
    public Double waitSec;

    public static final String LockType = "lockType";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 64)
    @Comment("锁类型")
    public String lockType;

    public static final String LockMode = "lockMode";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 64)
    @Comment("锁模式")
    public String lockMode;
}
