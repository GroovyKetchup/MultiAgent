package bap.md.opm;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;
import com.cdao.entity.annotation.UserType;
import com.cdao.model.CDoBasic;

import tiny.service.md.TsAgentDo;

@Comment("OPM采集扩展基类")
@Table(OpmMetricExtDo.TABLE)
@Foreign({ @ForeignClass(OpmMetricMainDo.class) })
public class OpmMetricExtDo extends CDoBasic
{
    private static final long serialVersionUID = 6106963147347445976L;

    public static final String TABLE = "opm_metric_ext";

    public static final String CollectorKey = "collectorKey";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集器标识")
    public String collectorKey;

    public static final String CollectorLabel = "collectorLabel";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("采集器名称")
    public String collectorLabel;

    public static final String AgentCode = "agentCode";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("代理编码")
    @Dimension(value = TsAgentDo.class, isAuth = false, exemptMe = true)
    public String agentCode;

    public static final String AgentName = "agentName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("代理名称冗余")
    public String agentName;

    public static final String MyUri = "myUri";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 1024)
    @Comment("进程URI")
    public String myUri;

    public static final String CollectTime = "collectTime";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("采集时间")
    @UserType(com.cdao.model.type.CDtTime.class)
    public Long collectTime;

    public static final String Summary = "summary";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 4000)
    @Comment("结构化摘要")
    public String summary;

    public String getCollectorKey()
    {
        return collectorKey;
    }

    public OpmMetricExtDo setCollectorKey(String collectorKey)
    {
        this.collectorKey = collectorKey;
        return this;
    }

    public String getCollectorLabel()
    {
        return collectorLabel;
    }

    public OpmMetricExtDo setCollectorLabel(String collectorLabel)
    {
        this.collectorLabel = collectorLabel;
        return this;
    }

    public String getAgentCode()
    {
        return agentCode;
    }

    public OpmMetricExtDo setAgentCode(String agentCode)
    {
        this.agentCode = agentCode;
        return this;
    }

    public String getAgentName()
    {
        return agentName;
    }

    public OpmMetricExtDo setAgentName(String agentName)
    {
        this.agentName = agentName;
        return this;
    }

    public String getMyUri()
    {
        return myUri;
    }

    public OpmMetricExtDo setMyUri(String myUri)
    {
        this.myUri = myUri;
        return this;
    }

    public Long getCollectTime()
    {
        return collectTime;
    }

    public OpmMetricExtDo setCollectTime(Long collectTime)
    {
        this.collectTime = collectTime;
        return this;
    }

    public String getSummary()
    {
        return summary;
    }

    public OpmMetricExtDo setSummary(String summary)
    {
        this.summary = summary;
        return this;
    }

    /**
     * 统一绑定采集主表外键关系，并同步冗余主键字段
     */
    public OpmMetricExtDo bindMain(OpmMetricMainDo main)
    {
        if (main == null)
        {
            setForeignClass(null);
            setForeignKey(null);
        } else
        {
            setForeignGid(main.getGid());
        }
        return this;
    }
}
