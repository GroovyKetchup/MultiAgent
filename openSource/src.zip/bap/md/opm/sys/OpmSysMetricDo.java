package bap.md.opm.sys;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmMetricExtDo;
import bap.md.opm.OpmMetricMainDo;

@Comment("OPM系统采集附表")
@Table(OpmSysMetricDo.TABLE)
@Foreign({ @ForeignClass(OpmMetricMainDo.class) })
public class OpmSysMetricDo extends OpmMetricExtDo
{
    private static final long serialVersionUID = -3795712338108790284L;

    public static final String TABLE = "opm_sys_metric";

    public static final String HostName = "hostName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("主机名")
    public String hostName;

    public static final String OsName = "osName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("操作系统")
    public String osName;

    public static final String Provider = "provider";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集实现")
    public String provider;

    public static final String CpuUsageRate = "cpuUsageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("CPU使用率")
    public Double cpuUsageRate;

    public static final String MemUsageRate = "memUsageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("内存使用率")
    public Double memUsageRate;

    public static final String DiskMaxUsageRate = "diskMaxUsageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("磁盘最大使用率")
    public Double diskMaxUsageRate;

    public static final String DiskCount = "diskCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("磁盘数")
    public Integer diskCount;

    public static final String IoReadRate = "ioReadRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("IO读速率Bps")
    public Double ioReadRate;

    public static final String IoWriteRate = "ioWriteRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("IO写速率Bps")
    public Double ioWriteRate;

    public static final String IoTotalRate = "ioTotalRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("IO总速率Bps")
    public Double ioTotalRate;

    public static final String NetRxRate = "netRxRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("网络下行Bps")
    public Double netRxRate;

    public static final String NetTxRate = "netTxRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("网络上行Bps")
    public Double netTxRate;

    public static final String NetTotalRate = "netTotalRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("网络总吞吐Bps")
    public Double netTotalRate;

    public static final String DetailJson = "detailJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("详细JSON")
    public String detailJson;
}
