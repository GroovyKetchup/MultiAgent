package bap.md.opm.sys;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmAlarmExtDo;
import bap.md.opm.OpmAlarmRefDo;

@Comment("OPM系统告警扩展")
@Table(OpmSysAlarmExtDo.TABLE)
@Foreign({ @ForeignClass(OpmAlarmRefDo.class) })
public class OpmSysAlarmExtDo extends OpmAlarmExtDo
{
    private static final long serialVersionUID = -4891626289607049340L;

    public static final String TABLE = "opm_sys_alarm_ext";

    public static final String MetricName = "metricName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("指标名称")
    public String metricName;

    public static final String CurrentRate = "currentRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("当前值比例")
    public Double currentRate;

    public static final String TriggerLevel = "triggerLevel";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 32)
    @Comment("触发级别")
    public String triggerLevel;

    public static final String ThresholdRate = "thresholdRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("触发阈值")
    public Double thresholdRate;

    public static final String DurationSec = "durationSec";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("持续时间(秒)")
    public Integer durationSec;

    public static final String WarnRate = "warnRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("预警阈值")
    public Double warnRate;

    public static final String CriticalRate = "criticalRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("严重阈值")
    public Double criticalRate;

    public String getMetricName()
    {
        return metricName;
    }

    public OpmSysAlarmExtDo setMetricName(String metricName)
    {
        this.metricName = metricName;
        return this;
    }

    public Double getCurrentRate()
    {
        return currentRate;
    }

    public OpmSysAlarmExtDo setCurrentRate(Double currentRate)
    {
        this.currentRate = currentRate;
        return this;
    }

    public String getTriggerLevel()
    {
        return triggerLevel;
    }

    public OpmSysAlarmExtDo setTriggerLevel(String triggerLevel)
    {
        this.triggerLevel = triggerLevel;
        return this;
    }

    public Double getThresholdRate()
    {
        return thresholdRate;
    }

    public OpmSysAlarmExtDo setThresholdRate(Double thresholdRate)
    {
        this.thresholdRate = thresholdRate;
        return this;
    }

    public Integer getDurationSec()
    {
        return durationSec;
    }

    public OpmSysAlarmExtDo setDurationSec(Integer durationSec)
    {
        this.durationSec = durationSec;
        return this;
    }

    public Double getWarnRate()
    {
        return warnRate;
    }

    public OpmSysAlarmExtDo setWarnRate(Double warnRate)
    {
        this.warnRate = warnRate;
        return this;
    }

    public Double getCriticalRate()
    {
        return criticalRate;
    }

    public OpmSysAlarmExtDo setCriticalRate(Double criticalRate)
    {
        this.criticalRate = criticalRate;
        return this;
    }
}