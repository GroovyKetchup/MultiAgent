package bap.md.opm;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;
import com.cdao.entity.annotation.UserType;
import com.cdao.model.CDoBasic;

import tiny.service.md.TsAgentDo;

@Comment("OPM告警扩展基础表")
@Table(OpmAlarmExtDo.TABLE)
@Foreign({ @ForeignClass(OpmAlarmRefDo.class) })
public class OpmAlarmExtDo extends CDoBasic
{
    private static final long serialVersionUID = -8344186857667465933L;

    public static final String TABLE = "opm_alarm_ext";

    public static final String AlarmRequestId = "alarmRequestId";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("告警请求ID")
    public String alarmRequestId;

    public static final String AlarmRefUuid = "alarmRefUuid";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("告警索引UUID")
    public String alarmRefUuid;

    public static final String MetricMainUuid = "metricMainUuid";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集主表UUID")
    public String metricMainUuid;

    public static final String CollectorKey = "collectorKey";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集器标识")
    public String collectorKey;

    public static final String CollectorLabel = "collectorLabel";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("采集器名称")
    public String collectorLabel;

    public static final String RuleKey = "ruleKey";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("规则标识")
    public String ruleKey;

    public static final String RuleLabel = "ruleLabel";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("规则名称")
    public String ruleLabel;

    public static final String AlarmLevel = "alarmLevel";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("告警级别")
    public Integer alarmLevel;

    public static final String AlarmTime = "alarmTime";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("告警时间")
    @UserType(com.cdao.model.type.CDtTime.class)
    public Long alarmTime;

    public static final String AgentCode = "agentCode";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("代理编码")
    @Dimension(value = TsAgentDo.class, isAuth = false, exemptMe = true)
    public String agentCode;

    public static final String AgentName = "agentName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("代理名称")
    public String agentName;

    public static final String MyUri = "myUri";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 1024)
    @Comment("进程URI")
    public String myUri;

    public static final String Message = "message";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 4000)
    @Comment("告警摘要")
    public String message;

    public static final String DetailJson = "detailJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("告警细节JSON")
    public String detailJson;
}
