package bap.md.opm;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Authorizable;
import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.UserType;
import com.cdao.model.CDoBasic;

import tiny.service.md.TsAgentDo;

@Comment("OPM采集主表")
@Table(OpmMetricMainDo.TABLE)
@Authorizable(value = false)
public class OpmMetricMainDo extends CDoBasic
{
    private static final long serialVersionUID = -5610807781310233555L;

    public static final String TABLE = "opm_metric_main";

    public static final String CollectorKey = "collectorKey";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集器标识")
    public String collectorKey;

    public static final String CollectorLabel = "collectorLabel";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("采集器名称")
    public String collectorLabel;

    public static final String AgentCode = "agentCode";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("代理编码")
    @Dimension(value = TsAgentDo.class, isAuth = false, exemptMe = true)
    public String agentCode;

    public static final String AgentName = "agentName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("代理名称冗余")
    public String agentName;

    public static final String MyUri = "myUri";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 1024)
    @Comment("进程URI")
    public String myUri;

    public static final String CollectTime = "collectTime";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("采集时间")
    @UserType(com.cdao.model.type.CDtTime.class)
    public Long collectTime;

    public static final String Status = "status";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("状态")
    public Integer status;

    public static final String AlarmUuid = "alarmUuid";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("触发告警UUID冗余")
    public String alarmUuid;

    public static final String StatusDetail = "statusDetail";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("状态详情JSON")
    public String statusDetail;

    public static final String CollectCostMs = "collectCostMs";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("采集耗时毫秒")
    public Long collectCostMs;

    public static final String Summary = "summary";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 4000)
    @Comment("摘要")
    public String summary;

    public static final String MetricClass = "metricClass";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("附表模型类")
    public String metricClass;

    public static final String MetricUuid = "metricUuid";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("附表数据UUID")
    public String metricUuid;

    public String getCollectorKey()
    {
        return collectorKey;
    }

    public OpmMetricMainDo setCollectorKey(String collectorKey)
    {
        this.collectorKey = collectorKey;
        return this;
    }

    public String getCollectorLabel()
    {
        return collectorLabel;
    }

    public OpmMetricMainDo setCollectorLabel(String collectorLabel)
    {
        this.collectorLabel = collectorLabel;
        return this;
    }

    public String getAgentCode()
    {
        return agentCode;
    }

    public OpmMetricMainDo setAgentCode(String agentCode)
    {
        this.agentCode = agentCode;
        return this;
    }

    public String getAgentName()
    {
        return agentName;
    }

    public OpmMetricMainDo setAgentName(String agentName)
    {
        this.agentName = agentName;
        return this;
    }

    public String getMyUri()
    {
        return myUri;
    }

    public OpmMetricMainDo setMyUri(String myUri)
    {
        this.myUri = myUri;
        return this;
    }

    public Long getCollectTime()
    {
        return collectTime;
    }

    public OpmMetricMainDo setCollectTime(Long collectTime)
    {
        this.collectTime = collectTime;
        return this;
    }

    public Integer getStatus()
    {
        return status;
    }

    public OpmMetricMainDo setStatus(Integer status)
    {
        this.status = status;
        return this;
    }

    public Long getCollectCostMs()
    {
        return collectCostMs;
    }

    public OpmMetricMainDo setCollectCostMs(Long collectCostMs)
    {
        this.collectCostMs = collectCostMs;
        return this;
    }

    public String getAlarmUuid()
    {
        return alarmUuid;
    }

    public OpmMetricMainDo setAlarmUuid(String alarmUuid)
    {
        this.alarmUuid = alarmUuid;
        return this;
    }

    public String getStatusDetail()
    {
        return statusDetail;
    }

    public OpmMetricMainDo setStatusDetail(String statusDetail)
    {
        this.statusDetail = statusDetail;
        return this;
    }

    public String getSummary()
    {
        return summary;
    }

    public OpmMetricMainDo setSummary(String summary)
    {
        this.summary = summary;
        return this;
    }

    public String getMetricClass()
    {
        return metricClass;
    }

    public OpmMetricMainDo setMetricClass(String metricClass)
    {
        this.metricClass = metricClass;
        return this;
    }

    public String getMetricUuid()
    {
        return metricUuid;
    }

    public OpmMetricMainDo setMetricUuid(String metricUuid)
    {
        this.metricUuid = metricUuid;
        return this;
    }
}
