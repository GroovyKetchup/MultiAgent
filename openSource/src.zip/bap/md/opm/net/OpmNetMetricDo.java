package bap.md.opm.net;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmMetricExtDo;
import bap.md.opm.OpmMetricMainDo;

@Comment("OPM网络采集附表")
@Table(OpmNetMetricDo.TABLE)
@Foreign({ @ForeignClass(OpmMetricMainDo.class) })
public class OpmNetMetricDo extends OpmMetricExtDo
{
    private static final long serialVersionUID = -5730531196617987747L;

    public static final String TABLE = "opm_net_metric";

    public static final String HostName = "hostName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("主机名")
    public String hostName;

    public static final String OsName = "osName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("操作系统")
    public String osName;

    public static final String Provider = "provider";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集实现")
    public String provider;

    public static final String SampleMillis = "sampleMillis";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("采样毫秒")
    public Long sampleMillis;

    public static final String TotalRxBytes = "totalRxBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("总接收字节")
    public Long totalRxBytes;

    public static final String TotalTxBytes = "totalTxBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("总发送字节")
    public Long totalTxBytes;

    public static final String RxRate = "rxRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("接收速率Bps")
    public Double rxRate;

    public static final String TxRate = "txRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("发送速率Bps")
    public Double txRate;

    public static final String TotalRate = "totalRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("总吞吐速率Bps")
    public Double totalRate;

    public static final String DetailJson = "detailJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("详细JSON")
    public String detailJson;
}
