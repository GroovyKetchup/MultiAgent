package bap.md.opm.focus;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmMetricExtDo;
import bap.md.opm.OpmMetricMainDo;

@Comment("OPM重点进程监控附表")
@Table(OpmFocusMetricDo.TABLE)
@Foreign({ @ForeignClass(OpmMetricMainDo.class) })
public class OpmFocusMetricDo extends OpmMetricExtDo
{
    private static final long serialVersionUID = 1L;

    public static final String TABLE = "opm_focus_metric";

    public static final String HostName = "hostName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("主机名")
    public String hostName;

    public static final String OsName = "osName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("操作系统")
    public String osName;

    public static final String Provider = "provider";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集实现")
    public String provider;

    public static final String FocusProcessCount = "focusProcessCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("重点进程数")
    public Integer focusProcessCount;

    public static final String TopCpuProcessName = "topCpuProcessName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("CPU最高进程名")
    public String topCpuProcessName;

    public static final String TopCpuProcessRate = "topCpuProcessRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("CPU最高进程使用率")
    public Double topCpuProcessRate;

    public static final String TopMemoryProcessName = "topMemoryProcessName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("内存最高进程名")
    public String topMemoryProcessName;

    public static final String TopMemoryProcessBytes = "topMemoryProcessBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("内存最高进程字节数")
    public Long topMemoryProcessBytes;

    public static final String TopIoProcessName = "topIoProcessName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("IO最高进程名")
    public String topIoProcessName;

    public static final String TopIoProcessRate = "topIoProcessRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("IO最高进程速率")
    public Double topIoProcessRate;

    public static final String DetailJson = "detailJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("详细JSON")
    public String detailJson;
}