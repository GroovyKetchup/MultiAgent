package bap.md.opm.memory;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmMetricExtDo;
import bap.md.opm.OpmMetricMainDo;

@Comment("OPM内存采集附表")
@Table(OpmMemoryMetricDo.TABLE)
@Foreign({ @ForeignClass(OpmMetricMainDo.class) })
public class OpmMemoryMetricDo extends OpmMetricExtDo
{
    private static final long serialVersionUID = 1L;

    public static final String TABLE = "opm_memory_metric";

    public static final String HostName = "hostName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("主机名")
    public String hostName;

    public static final String OsName = "osName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("操作系统")
    public String osName;

    public static final String Provider = "provider";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集实现")
    public String provider;

    public static final String TotalBytes = "totalBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("内存总量字节")
    public Long totalBytes;

    public static final String UsedBytes = "usedBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("内存已使用字节")
    public Long usedBytes;

    public static final String FreeBytes = "freeBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("内存空闲字节")
    public Long freeBytes;

    public static final String UsageRate = "usageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("内存使用率")
    public Double usageRate;

    public static final String SwapTotalBytes = "swapTotalBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("交换区总量字节")
    public Long swapTotalBytes;

    public static final String SwapUsedBytes = "swapUsedBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("交换区已使用字节")
    public Long swapUsedBytes;

    public static final String SwapFreeBytes = "swapFreeBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("交换区空闲字节")
    public Long swapFreeBytes;

    public static final String SwapUsageRate = "swapUsageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("交换区使用率")
    public Double swapUsageRate;

    public static final String DetailJson = "detailJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("详细JSON")
    public String detailJson;
}
