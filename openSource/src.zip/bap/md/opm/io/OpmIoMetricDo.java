package bap.md.opm.io;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmMetricExtDo;
import bap.md.opm.OpmMetricMainDo;

@Comment("OPM IO采集附表")
@Table(OpmIoMetricDo.TABLE)
@Foreign({ @ForeignClass(OpmMetricMainDo.class) })
public class OpmIoMetricDo extends OpmMetricExtDo
{
    private static final long serialVersionUID = -3080300602511781773L;

    public static final String TABLE = "opm_io_metric";

    public static final String HostName = "hostName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("主机名")
    public String hostName;

    public static final String OsName = "osName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("操作系统")
    public String osName;

    public static final String Provider = "provider";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集实现")
    public String provider;

    public static final String SampleMillis = "sampleMillis";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("采样毫秒")
    public Long sampleMillis;

    public static final String TopProcCount = "topProcCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("Top进程数")
    public Integer topProcCount;

    public static final String TopProcName = "topProcName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("Top进程名称")
    public String topProcName;

    public static final String TopProcReadRate = "topProcReadRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("Top进程读速率Bps")
    public Double topProcReadRate;

    public static final String TopProcWriteRate = "topProcWriteRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("Top进程写速率Bps")
    public Double topProcWriteRate;

    public static final String DetailJson = "detailJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("详细JSON")
    public String detailJson;
}
