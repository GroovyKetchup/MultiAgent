package bap.md.opm.disk;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Foreign;
import com.cdao.entity.annotation.ForeignClass;

import bap.md.opm.OpmMetricExtDo;
import bap.md.opm.OpmMetricMainDo;

@Comment("OPM磁盘采集附表")
@Table(OpmDiskMetricDo.TABLE)
@Foreign({ @ForeignClass(OpmMetricMainDo.class) })
public class OpmDiskMetricDo extends OpmMetricExtDo
{
    private static final long serialVersionUID = 6863916117330475812L;

    public static final String TABLE = "opm_disk_metric";

    public static final String HostName = "hostName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("主机名")
    public String hostName;

    public static final String OsName = "osName";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("操作系统")
    public String osName;

    public static final String Provider = "provider";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 128)
    @Comment("采集实现")
    public String provider;

    public static final String DiskCount = "diskCount";
    @Column
    @ColDefine(type = ColType.INT, width = 10)
    @Comment("磁盘分区数量")
    public Integer diskCount;

    public static final String TotalBytes = "totalBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("磁盘总容量字节")
    public Long totalBytes;

    public static final String TotalUsedBytes = "totalUsedBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("磁盘总已使用字节")
    public Long totalUsedBytes;

    public static final String TotalFreeBytes = "totalFreeBytes";
    @Column
    @ColDefine(type = ColType.INT, width = 20)
    @Comment("磁盘总空闲字节")
    public Long totalFreeBytes;

    public static final String TotalUsageRate = "totalUsageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("磁盘总体使用率")
    public Double totalUsageRate;

    public static final String MaxUsageRate = "maxUsageRate";
    @Column
    @ColDefine(type = ColType.FLOAT, width = 24)
    @Comment("最高分区使用率")
    public Double maxUsageRate;

    public static final String MaxUsageMount = "maxUsageMount";
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 512)
    @Comment("最高分区挂载点")
    public String maxUsageMount;

    public static final String DetailJson = "detailJson";
    @Column
    @ColDefine(type = ColType.TEXT)
    @Comment("详细JSON")
    public String detailJson;
}
