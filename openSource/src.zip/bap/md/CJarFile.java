package bap.md;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Nullable;
import com.cdao.model.CDoSlave;
import com.leavay.ms.tool.CmnUtil;

import ms.cmn.util.MD5Util;

/**
 * 可以作为从表挂在CJavaProject下
 * 
 * 派生的对象也可以作为从表挂在插件工程下
 */
@Table("cjar_file")
@TableIndexes({@Index(name="master_cls",fields={CDoSlave.MasterClass},unique=false)
        ,@Index(name="master_key",fields={CDoSlave.MasterKey},unique=false)
        ,@Index(name="master_field",fields={CDoSlave.MasterField},unique=false),
        @Index(name="uni_name",fields={CDoSlave.MasterKey, CJarFile.Name},unique=true)})
public class CJarFile extends CDoSlave
{
    private static final long serialVersionUID = -2070800304640267198L;
    
    public static final String Name="name";
    public static final String Size="size";

    public static final String FileMd5 = "fileMd5";

    public static final String FileBin="fileBin";
    
    public final static String[] FIELDS_BRIEF = CmnUtil.append2String(MasterFields, FIELDS_BASIC, Name, FileMd5, Size);
    

    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Nullable(false)
    @Comment("MD5码")
    public String fileMd5;
    
    @Column
    @Comment("名字")
    @ColDefine(width=256)
    protected String name;
    
    public String getName()
    {
        return name;
    }

    public CJarFile setName(String name)
    {
        this.name = name;
        return this;
    }

    @Column
    @ColDefine(type=ColType.INT,width=18)
    @Comment("大小(字节数）")
    public Long size;
    
    public Long getSize()
    {
        return size;
    }

    public CJarFile setSize(Long size)
    {
        this.size = size;
        return this;
    }
    
    @Column
    @ColDefine(type=ColType.BINARY)
    protected byte[] fileBin;

    public byte[] getFileBin()
    {
        return fileBin;
    }

    public void setFileBin(byte[] fileBin)
    {
        this.fileBin = fileBin;
    }
    
    // 不论是作为从表挂在Java工程下还是插件工程下，都是MasterKey
    public String getProjectUuid()
    {
        return getMasterKey();
    }
    
    public String getFileMd5()
    {
        return fileMd5;
    }

    public void setFileMd5(String fileMd5)
    {
        this.fileMd5 = fileMd5;
    }
    
    public void updateMd5() throws Exception
    {
        setFileMd5(MD5Util.encode(getFileBin()));
    }
    

    public void setFile(String name, byte[] bin) throws Exception
    {
        setName(name);
        setFileBin(bin);
        setSize((long) (bin==null?0:bin.length));
        updateMd5();
    }
}
