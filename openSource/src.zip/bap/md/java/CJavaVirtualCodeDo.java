package bap.md.java;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Authorizable;
import com.cdao.entity.annotation.Description;

@Comment("虚拟工程源码")
@Description("只用于导入源码用于查看比较等, 不用于开发/发布插件(所以允许类名包名不唯一)")
@Table(CJavaVirtualCodeDo.TABLE)
@Authorizable(value=false)
@TableIndexes({
          @Index(name="master_cls",fields={"masterClass"},unique=false), 
          @Index(name="master_key",fields={"masterKey"},unique=false), 
          @Index(name="master_field",fields={"masterField"},unique=false), 
          @Index(name="pj_pkg_name_unique",fields={"masterKey","javaPackage","mainClass"},unique=true)})
public class CJavaVirtualCodeDo extends bap.md.java.CJavaCodeDo
{
 private static final long serialVersionUID = -355792592L;

 public static final String TABLE = "bap_md_java_cjavavirtualcodedo";
 

}