package bap.md.java;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Depend;
import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.Nullable;
import com.cdao.mgr.CSession;
import com.cdao.model.CDoBasic;
import com.cdao.model.CDoSlave;
import com.cdao.model.CDoUser;
import com.leavay.ms.tool.CmnUtil;

import ms.cmn.util.MD5Util;


/**
 * 作为从表挂在CJavaProject下
 * 
 * 同时Owner又可以挂到目录下面以组成文件夹从属关系
 * 
 * 双重依赖既可以联动被目录删除，也可以方便在工程下搜索
 */

@Comment("资源文件")
@Table(CResFileDo.TABLE)

@TableIndexes({@Index(name="master_key",fields={CDoSlave.MasterKey},unique=false)
                                ,@Index(name="uni_path",fields={CDoSlave.MasterKey, CResFileDo.FilePackage, CResFileDo.FileName},unique=true)})//工程下，资源文件名唯一
public class CResFileDo extends CDoSlave
{
    private static final long serialVersionUID = -7549493948256346656L;

    public final static String TABLE="cres_file";

    public static final String FilePackage="filePackage";
    @Column
    @Comment("包名")
    @ColDefine(type = ColType.VARCHAR, width=1024)
    protected String filePackage;
    
    public static final String FileName="fileName";
    @Column
    @Comment("文件名")
    @ColDefine(type = ColType.VARCHAR, width=256)
    protected String fileName;
    
    public static final String Size="size";
    @Column
    @ColDefine(type=ColType.INT,width=18)
    @Comment("大小(字节数）")
    public Long size;

    public Long getSize()
    {
        return size;
    }

    public CResFileDo setSize(Long size)
    {
        this.size = size;
        return this;
    }
    
    public static final String FileMd5 = "fileMd5";   
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Nullable(false)
    @Comment("MD5码")
    public String fileMd5;
    public String getFileMd5()
    {
        return fileMd5;
    }

    public CResFileDo setFileMd5(String fileMd5)
    {
        this.fileMd5 = fileMd5;
        return this;
    }

    public static final String FileBin="fileBin";
    @Column
    @ColDefine(type=ColType.BINARY)
    protected byte[] fileBin;

    public byte[] getFileBin()
    {
        return fileBin;
    }

    public CResFileDo setFileBin(byte[] fileBin)
    {
        this.fileBin = fileBin;
        return this;
    }
    
    public static final String FileEncoding="fileEncoding";
    @Column
    @Comment("字符编码")
    @ColDefine(type = ColType.VARCHAR, width=128)
    protected String fileEncoding = "UTF-8";
    
    public static final String ReadOnly="readOnly";
    @Column
    @Comment("只读")
    protected Boolean readOnly=false;
    
    public static final String LastWriter="lastWriter";
    @Column
    @ColDefine(type=ColType.VARCHAR,width=128)
    @Comment("最近作者")
    @Dimension(value=CDoUser.class)
    public String lastWriter;

 
    public String getFileEncoding()
    {
        return fileEncoding;
    }

    public void setFileEncoding(String fileEncoding)
    {
        this.fileEncoding = fileEncoding;
    }

    public Boolean getReadOnly()
    {
        return readOnly;
    }

    public void setReadOnly(Boolean readOnly)
    {
        this.readOnly = readOnly;
    }
    
 
    public String getProjectUuid()
    {
        return getMasterKey();
    }
    
    public String getFolder()
    {
        return getOwner();
    }
    
    public String getLastWriter()
    {
        return lastWriter;
    }

    public CResFileDo setLastWriter(String lastWriter)
    {
        this.lastWriter = lastWriter;
        return this;
    }
    
    public CResFileDo setLastWriter(CSession session)
    {
        return setLastWriter((String)(session==null?null:session.getUserCode()));
    }

    public String getFilePackage()
    {
        return filePackage;
    }

    public CResFileDo setFilePackage(String filePackage)
    {
        this.filePackage = filePackage;
        return this;
    }

    public String getFileName()
    {
        return fileName;
    }
    
    public String getName()
    {
        return getPhysicalPath();
    }

    public CResFileDo setFileName(String fileName)
    {
        this.fileName = fileName;
        return this;
    }
    
    // 返回包路径名 : com.test.AAAA.xml
    public String getPackagePath()
    {
        return CmnUtil.getFullClassName(getFilePackage(), getFileName());
    }
    
    // 返回物理文件路径名：com/test/AAA.xml
    public String getPhysicalPath()
    {
        if (CmnUtil.isStringEmpty(getFilePackage()))
            return getFileName();
        else
            return CmnUtil.javaPath2File(getFilePackage())+"/"+getFileName();
    }
    
    public void updateFileInfo() throws Exception
    {
        setSize((long)CmnUtil.getObjectSize(getFileBin()));
        setFileMd5(MD5Util.encode(getFileBin()));
    }
    
    public final static String[] FIELDS_BRIEF = CmnUtil.append(CmnUtil.append(CDoBasic.FIELDS_BASIC, CmnUtil.append(CDoSlave.MasterFields)), FilePackage, FileName, Size, FileMd5, ReadOnly, LastWriter) ;
    
    public String toString()
    {
        return getPackagePath()+"("+getUuid()+")";
    }
}
