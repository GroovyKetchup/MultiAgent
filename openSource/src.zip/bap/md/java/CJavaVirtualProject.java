package bap.md.java;

import java.util.List;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Slave;
import com.cdao.impl.entity.field.SlaveTable;
import com.cdao.model.CDoNamed;
import com.leavay.ms.tool.CmnUtil;

import bap.java.CJavaConst;
import bap.md.CJarFile;

/**
 * JAVA 项目对象
 *
 * 其下可以挂一个ArtifactDefine来标识自身的发布信息
 */
@Comment("JAVA虚拟工程")
@Table(CJavaVirtualProject.TABLE)
public class CJavaVirtualProject extends CJavaProject
{

    private static final long serialVersionUID = -8816889101718062174L;

    public final static String TABLE="cjava_virtual_project";
    
    
    @Slave(CJavaVirtualCodeDo.class)
    public List<CJavaVirtualCodeDo> lstCode;
    
    @Override
    public List<CJavaCodeDo> getLstCode()
    {
        return (List)lstCode;
    }

    public void setLstCode(List<CJavaCodeDo> lstCode)
    {
        this.lstCode = (List)lstCode;
    }

}
