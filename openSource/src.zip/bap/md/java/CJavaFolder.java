package bap.md.java;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Dimension;
import com.cdao.impl.entity.field.GID;
import com.cdao.model.CDoSlave;
import com.cdao.model.CDoUser;
import com.leavay.ms.tool.CmnUtil;


/**
 * 作为从表挂在CJavaProject下
 */
@Table("cjava_folder")
@TableIndexes({@Index(name="master_cls",fields={CDoSlave.MasterClass},unique=false)
                                ,@Index(name="master_key",fields={CDoSlave.MasterKey},unique=false)
                                ,@Index(name="master_field",fields={CDoSlave.MasterField},unique=false)
                                ,@Index(name="unique_name",fields={CDoSlave.MasterKey, CJavaFolder.Name},unique=true)}) // 同一个工程下，目录名需唯一
public class CJavaFolder extends CDoSlave
{
    private static final long serialVersionUID = -7759625138579640922L;
    
    public final static String Name = "name";
    @Column
    @Comment("名字")
    @ColDefine(width=256)
    protected String name;
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String toString()
    {
        return getName();
    }
    

    public static final String PrivateOwner="privateOwner";
    @Column
    @ColDefine(type=ColType.VARCHAR,width=128)
    @Comment("专属人")
    @Dimension(value=CDoUser.class, isAuth=true,exemptMe=true)
    public String privateOwner;
    public String getPrivateOwner(){return privateOwner;}
    public CJavaFolder setPrivateOwner(String v){this.privateOwner=v;return this;}

    public boolean isPrivateOwn()
    {
        return !CmnUtil.isStringEmpty(getPrivateOwner());
    }
    
    public void setMaster(GID pjGid)
    {
        setMaster(pjGid, CJavaProject.LstFolder);
    }
}
