package bap.md.java;

import java.util.List;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Table;

import com.cdao.entity.annotation.Slave;
import com.cdao.impl.entity.field.SlaveTable;
import com.cdao.model.CDoNamed;
import com.leavay.ms.tool.CmnUtil;

import bap.java.CJavaConst;
import bap.md.CJarFile;

/**
 * JAVA 项目对象
 *
 * 其下可以挂一个ArtifactDefine来标识自身的发布信息
 */
@Comment("JAVA工程")
@Table(CJavaProject.TABLE)
public class CJavaProject extends CDoNamed
{
    private static final long serialVersionUID = -6143465029867311370L;

    public final static String TABLE="cjava_project";
    
    public final static String LstCode = "lstCode";
    public final static String LstRes = "lstRes";
    public final static String LstFolder = "lstFolder";
    public final static String JarFiles = "jarFiles";
    
    public static final String DependType="dependType";
    @Column
    @ColDefine(type=ColType.INT,width=10)
    @Comment("工程依赖类型")
    public Integer dependType  = CJavaConst.DEPEND_PLATFORM;
    public Integer getDependType(){return dependType;}
    public CJavaProject setDependType(Integer v){this.dependType=v;return this;}
    
    // 可以被界面修改的属性
    public final static String[] FIELDS_GUI_MODIFYABLE = new String[] {Name, DependType};
    
    // 修改后需要重新编译的字段
    public final static String[] FIELDS_REBUILD_ON_CHANGE= new String[] {DependType};
    
    @Slave(CJavaCodeDo.class)
    public List<CJavaCodeDo> lstCode;
    
    @Slave(CResFileDo.class)
    public SlaveTable<CResFileDo> lstRes;
    
    @Slave(CJavaFolder.class)
    public List<CJavaFolder> lstFolder;
    
    @Slave(CJarFile.class)
    public List<CJarFile> jarFiles;
    
    public List<CJavaCodeDo> getLstCode()
    {
        return lstCode;
    }

    public void setLstCode(List<CJavaCodeDo> lstCode)
    {
        this.lstCode = lstCode;
    }

    public static String getLstres()
    {
        return LstRes;
    }
    
    public List<CJavaFolder> getLstFolder()
    {
        return lstFolder;
    }

    public void setLstFolder(List<CJavaFolder> lstFolder)
    {
        this.lstFolder = lstFolder;
    }

    public List<CJarFile> getJarFiles()
    {
        return jarFiles;
    }

    public void setJarFiles(List<CJarFile> jarFiles)
    {
        this.jarFiles = jarFiles;
    }
    
    public boolean isIsolate()
    {
        return CmnUtil.isEqual(CJavaConst.DEPEND_ISOLATE, getDependType());
    }
    
    // 编译时是否依赖工程（主要是依赖ClassFactory里的Basic包（CDAO包））
    public boolean isDependPlatform()
    {
        return CmnUtil.isEqual(CJavaConst.DEPEND_PLATFORM, getDependType());
    }
    
    // 依赖插件，这种情况非常少见，可能只用于一些特殊工程（自身不会发布为插件的，如测试类工程）
    // 一旦依赖插件，则肯定依赖平台，上面的isDependPlatform变得无意义
    public boolean isDependPlugin()
    {
        return CmnUtil.isEqual(CJavaConst.DEPEND_PLUGIN, getDependType());
    }
    
    // UDF库工程，代码之间独立编译，但是依赖平台和插件
    public boolean isUdfLib()
    {
        return CmnUtil.isEqual(CJavaConst.UDF_LIB, getDependType());
    }
    
    public boolean isClosed()
    {
        return false;
    }
}
