package bap.md.java;

import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.cmn.DtoIntf;

public class CJavaLibFolderDto implements DtoIntf
{
    private static final long serialVersionUID = 2407338376074284901L;
    String vUuid = ToolUtilities.allockUUID();
    
    public String getKey()
    {
        return vUuid;
    }
    
    public String toString()
    {
        return "lib";
    }
}
