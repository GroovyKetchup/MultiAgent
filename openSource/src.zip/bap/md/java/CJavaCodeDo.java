package bap.md.java;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Index;
import org.nutz.dao.entity.annotation.Table;
import org.nutz.dao.entity.annotation.TableIndexes;

import com.cdao.entity.annotation.Attach;
import com.cdao.entity.annotation.Depend;
import com.cdao.entity.annotation.Dimension;
import com.cdao.entity.annotation.UserType;
import com.cdao.mgr.CSession;
import com.cdao.model.CDoBasic;
import com.cdao.model.CDoSlave;
import com.cdao.model.CDoUser;
import com.cdao.model.type.AttachBrief;
import com.leavay.ms.tool.CmnUtil;

import ms.cmn.util.MD5Util;


/**
 * 作为从表挂在CJavaProject下
 * 
 * 同时Owner又可以挂到目录下面以组成文件夹从属关系
 * 
 * 双重依赖既可以联动被目录删除，也可以方便在工程下搜索
 */

@Comment("JAVA源码")
@Table(CJavaCodeDo.TABLE)

@TableIndexes(value={@Index(name="master_cls",fields={CDoSlave.MasterClass},unique=false)
                                ,@Index(name="master_key",fields={CDoSlave.MasterKey},unique=false)
                                ,@Index(name="master_field",fields={CDoSlave.MasterField},unique=false)
                                ,@Index(name="class_name_uni",fields={CJavaCodeDo.JavaPackage, CJavaCodeDo.MainClass},unique=true)}, inheritSuperIndexs = true)
public class CJavaCodeDo extends CDoSlave
{
    private static final long serialVersionUID = -7549493948256346656L;

    public final static String TABLE="cjava_code";
    

    // 强制约束物主为文件夹
    @Column
    @Comment("物主")
    @Depend(dstClass = CJavaFolder.class)
    protected String owner;
    
    public static final String JavaPackage="javaPackage";
    @Column
    @Comment("包名")
    @ColDefine(type = ColType.VARCHAR, width=3000)
    protected String javaPackage;
    
    public static final String MainClass="mainClass";
    @Column
    @Comment("类名")
    @ColDefine(type = ColType.VARCHAR, width=256)
    protected String mainClass;
    
    public static final String Code="code";
    @Column
    @Comment("源码")
    @ColDefine(type = ColType.TEXT)
    protected String code;

    public static final String FileEncoding="fileEncoding";
    @Column
    @Comment("字符编码")
    @ColDefine(type = ColType.VARCHAR, width=128)
    protected String fileEncoding = "UTF-8";
    
    public static final String ReadOnly="readOnly";
    @Column
    @Comment("只读")
    protected Boolean readOnly=false;
    
    public static final String LastWriter="lastWriter";
    @Column
    @ColDefine(type=ColType.VARCHAR,width=128)
    @Comment("最近作者")
    @Dimension(value=CDoUser.class)
    public String lastWriter;
    
    public static final String CodeMd5 = "codeMd5";   
    @Column
    @ColDefine(type = ColType.VARCHAR, width = 256)
    @Comment("MD5码")
    public String codeMd5;
    

    public static final String SaveTime="saveTime";
    @Column
    @ColDefine(type=ColType.INT,width=20)
    @Comment("保存时间")
    @UserType(com.cdao.model.type.CDtTime.class)
    public Long saveTime;

    public static final String MetaDocuments="metaDocuments";
    @Column
    @Comment("文档")
    @Attach
    public AttachBrief metaDocuments;
    public AttachBrief getMetaDocuments(){return metaDocuments;}
    public CJavaCodeDo setMetaDocuments(AttachBrief v){this.metaDocuments=v;return this;}

    public final static String[] FIELDS_BRIEF = CmnUtil.append(CmnUtil.append(CDoBasic.FIELDS_BASIC, CmnUtil.append(CDoSlave.MasterFields)), JavaPackage, MainClass, ReadOnly, CodeMd5, SaveTime, LastWriter) ;
    
    public String getCode()
    {
        return code;
    }
    
    public void setCode(String code)
    {
        this.code = code;
    }

    public String getJavaPackage()
    {
        return javaPackage;
    }

    public CJavaCodeDo setJavaPackage(String javaPackage)
    {
        this.javaPackage = javaPackage;
        return this;
    }

    public String getMainClass()
    {
        return mainClass;
    }

    public CJavaCodeDo setMainClass(String mainClass)
    {
        this.mainClass = mainClass;
        return this;
    }

    public String getFileEncoding()
    {
        return fileEncoding;
    }

    public void setFileEncoding(String fileEncoding)
    {
        this.fileEncoding = fileEncoding;
    }

    public Boolean getReadOnly()
    {
        return readOnly;
    }

    public void setReadOnly(Boolean readOnly)
    {
        this.readOnly = readOnly;
    }
    
    public String getFullClassName()
    {
        if (CmnUtil.isStringEmpty(getJavaPackage()))
            return getMainClass();
        else
            return getJavaPackage()+"."+getMainClass();
    }
    
    public String getPackage()
    {
        return CmnUtil.getString(getJavaPackage(), "");
    }
    
    public boolean hasPackage()
    {
        return !CmnUtil.isStringEmpty(getJavaPackage());
    }
    
    public String getFilePath()
    {
        return getPackage().replace('.', '/') + "/" + getMainClass();
    }
    
    public String getProjectUuid()
    {
        return getMasterKey();
    }
    
    public String getFolder()
    {
        return getOwner();
    }
    
    public String getLastWriter()
    {
        return lastWriter;
    }

    public CJavaCodeDo setLastWriter(String lastWriter)
    {
        this.lastWriter = lastWriter;
        return this;
    }
    
    public CJavaCodeDo setLastWriter(CSession session)
    {
        return setLastWriter((String)(session==null?null:session.getUserCode()));
    }

    public String getCodeMd5()
    {
        return codeMd5;
    }

    public CJavaCodeDo setCodeMd5(String codeMd5)
    {
        this.codeMd5 = codeMd5;
        return this;
    }

    public Long getSaveTime()
    {
        return saveTime;
    }

    public CJavaCodeDo setSaveTime(Long saveTime)
    {
        this.saveTime = saveTime;
        return this;
    }
    
    public void updateSaveInfo() throws Exception
    {
        setCodeMd5(MD5Util.encode(getCode().getBytes()));
        setSaveTime(System.currentTimeMillis());
    }

    public String toString()
    {
        return getFullClassName()+"("+getUuid()+")";
    }
}
