package bap.yun.util;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.cdao.mgr.CSession;
import com.cdao.model.CDoAttach;
import com.cdao.model.CDoModel;
import com.cdao.model.type.AttachBrief;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.ChildProgress;
import com.leavay.common.util.ProgressCtrl.crpc.COutputProgress;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.leavay.common.util.ProgressCtrl.crpc.IProgressUtil;
import com.leavay.common.util.cjson.CJson;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.dfc.gui.LvUtil;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;

import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.yun.ArtifactPackage;
import bap.yun.ArtifactUtil;
import bap.yun.YunStoreAgent;
import cell.bap.yun.ArtifactGraph;
import cell.bap.yun.IYunStore;
import cmn.security.dto.UserPassword;
import cmn.util.Nulls;

public class ArtWareMigrationTool
{

    CRpcAdapter _adapter = new CRpcAdapter();

    CRpcClientWrapper<IYunStore> _srcClient;

    CRpcClientWrapper<IYunStore> _dstClient;

    UserPassword srcUser;

    UserPassword dstUser;

    // 默认遇到已经存在的就跳过（会跳过其依赖对象）
    boolean ignoreExisted = true;

    public ArtWareMigrationTool(URI src, URI dst)
    {
        _srcClient = new CRpcClientWrapper<IYunStore>(IYunStore.class)
        {
            public CRpcAdapter getAdapter()
            {
                return _adapter;
            }
        };
        _srcClient.init(src);

        _dstClient = new CRpcClientWrapper<IYunStore>(IYunStore.class)
        {
            public CRpcAdapter getAdapter()
            {
                return _adapter;
            }
        };
        _dstClient.init(dst);
    }

    public ArtWareMigrationTool(CRpcClientWrapper<IYunStore> srcClient, CRpcClientWrapper<IYunStore> dstClient)
    {
        _srcClient = srcClient;
        _dstClient = dstClient;
    }

    public UserPassword getSrcUser()
    {
        return srcUser;
    }

    public ArtWareMigrationTool setSrcUser(UserPassword srcUser)
    {
        this.srcUser = srcUser;
        return this;
    }

    public UserPassword getDstUser()
    {
        return dstUser;
    }

    public ArtWareMigrationTool setDstUser(UserPassword dstUser)
    {
        this.dstUser = dstUser;
        return this;
    }

    IYunStore _srcIntf = null;

    CSession _srcSession = null;

    public synchronized IYunStore getSrcIntf() throws Exception
    {
        if (_srcIntf == null || _srcSession == null)
        {
            IYunStore intf = _srcClient.getIntf();
            _srcSession = intf.login(getSrcUser());
            _srcIntf = intf;
        }
        return _srcIntf;
    }

    IYunStore _dstIntf = null;

    CSession _dstSession = null;

    public synchronized IYunStore getDstIntf() throws Exception
    {
        if (_dstIntf == null || _dstSession == null)
        {
            IYunStore intf = _dstClient.getIntf();
            _dstSession = intf.login(getDstUser());
            _dstIntf = intf;
        }
        return _dstIntf;
    }

    public boolean isIgnoreExisted()
    {
        return ignoreExisted;
    }

    public ArtWareMigrationTool setIgnoreExisted(boolean ignoreExisted)
    {
        this.ignoreExisted = ignoreExisted;
        return this;
    }

    protected ArtifactWare migrateSingleWare(String groupId, String artifactId, String version) throws Exception
    {
        ArtifactWare ware = getSrcIntf().queryArtifact(groupId, artifactId, version, true);

        ArtifactPackage pkg = new ArtifactPackage();
        pkg.setArtifactDefine(ware.toDefine());

        // 导模型定义
        List<CDoModel> lstModels = getSrcIntf().queryModelPackage(ware.getUuid());
        for (CDoModel md : Nulls.get(lstModels))
        {
            CDoAttach oneMdJson = new CDoAttach().setDirty(true);
            oneMdJson.setName(md.getFullClassName());

            String mdJson = CJson.toJson(md);
            oneMdJson.setText(mdJson);
            pkg.addModelPkg(oneMdJson);
        }

        CDoAttach pjPkg = getSrcIntf().queryProjectPackage(ware.getUuid());
        if (pjPkg != null)
        {
            pjPkg.setDirty(true);
            pkg.setProjectPkg(pjPkg);
        }

        List<CDoAttach> releasePkg = getSrcIntf().queryReleasePackage(ware.getUuid());
        for (CDoAttach rls : Nulls.get(releasePkg))
        {
            pkg.addReleasePkg(rls.setDirty(true));
        }

        getDstIntf().publishArtifact(pkg, getDstUser());
        return getDstIntf().queryArtifact(groupId, artifactId, version, false);
    }

    public ArtifactPackage loadFilePackage(String file) throws Exception
    {
        return (ArtifactPackage) ClassFactory.unserialize(ToolUtilities.readFile(file));
    }

    public void exportSingleFile(File dstFile, String groupId, String artifactId, String version) throws Exception
    {
        ArtifactPackage pkg = exportSingleWare(groupId, artifactId, version);
        byte[] bt = ClassFactory.serialObject(pkg);
        ToolUtilities.saveFile(dstFile.getAbsolutePath(), bt, false);
    }

    public ArtifactPackage exportSingleWare(String groupId, String artifactId, String version) throws Exception
    {
        ArtifactWare ware = getSrcIntf().queryArtifact(groupId, artifactId, version, true);

        ArtifactPackage pkg = new ArtifactPackage();
        pkg.setArtifactDefine(ware.toDefine());

        // 导模型定义
        List<CDoModel> lstModels = getSrcIntf().queryModelPackage(ware.getUuid());
        for (CDoModel md : Nulls.get(lstModels))
        {
            CDoAttach oneMdJson = new CDoAttach().setDirty(true);
            oneMdJson.setName(md.getFullClassName());

            String mdJson = CJson.toJson(md);
            oneMdJson.setText(mdJson);
            pkg.addModelPkg(oneMdJson);
        }

        CDoAttach pjPkg = getSrcIntf().queryProjectPackage(ware.getUuid());
        if (pjPkg != null)
        {
            pjPkg.setDirty(true);
            pkg.setProjectPkg(pjPkg);
        }

        List<CDoAttach> releasePkg = getSrcIntf().queryReleasePackage(ware.getUuid());
        for (CDoAttach rls : Nulls.get(releasePkg))
        {
            pkg.addReleasePkg(rls.setDirty(true));
        }

        return pkg;
    }

    protected void migrateWareWithDepends(ArtifactGraph graph, String currentUuid, Set<String> doneListKeys) throws Exception
    {
        Set<String> depends = graph.getRelations().getTarget(currentUuid);
        for (String depend : Nulls.get(depends))
        {
            // 有依赖的优先导入依赖的
            migrateWareWithDepends(graph, depend, doneListKeys);
        }

        // 依赖项都导完了才能导入自己
        ArtifactWare currWare = graph.getArtifacts().get(currentUuid);
        if (doneListKeys.contains(currWare.getArtifactKey()))
            return; // 避免重复导入

        if (ignoreExisted)
        {
            ArtifactWare existed = getDstIntf().queryArtifact(currWare.getGroupId(), currWare.getArtifactId(), currWare.getVersion(), false, ArtifactWare.FIELDS_BRIEF);
            if (existed != null)
            {
                trace("Ignore existed : " + existed.getArtifactKey());
                return;
            }
        }

        // 导入单个
        currWare = migrateSingleWare(currWare.getGroupId(), currWare.getArtifactId(), currWare.getVersion());
        doneListKeys.add(currWare.getArtifactKey());
        trace("Migrated : " + currWare);
    }

    public void verifyWareWithDepends(String groupId, String artId, String version) throws Exception
    {

        ArtifactWare srcWare = getSrcIntf().queryArtifact(groupId, artId, version, false, ArtifactWare.FIELDS_BRIEF);
        ArtifactGraph srcGraph = getSrcIntf().queryDependGraph(ToolUtilities.newHashSet(srcWare.getUuid()), true);

        verifyWareWithDepends(srcGraph, srcWare.getUuid(), new HashSet<String>());
    }

    protected void verifyWareWithDepends(ArtifactGraph graph, String currentUuid, Set<String> doneListKeys) throws Exception
    {
        Set<String> depends = graph.getRelations().getTarget(currentUuid);
        for (String depend : Nulls.get(depends))
        {
            // 有依赖的优先导入依赖的
            verifyWareWithDepends(graph, depend, doneListKeys);
        }

        ArtifactWare currWare = graph.getArtifacts().get(currentUuid);
        if (doneListKeys.contains(currWare.getArtifactKey()))
            return; // 避免重复校验

        trace("Compare : " + currWare);
        ArtifactWare src = getSrcIntf().queryArtifact(currWare.getGroupId(), currWare.getArtifactId(), currWare.getVersion(), false);// 查全部字段
        CmnUtil.assertNotNull(src, "Invalid source artifact : " + currWare);

        ArtifactWare dst = getDstIntf().queryArtifact(currWare.getGroupId(), currWare.getArtifactId(), currWare.getVersion(), false);// 查全部字段
        CmnUtil.assertNotNull(dst, "Invalid target artifact : " + currWare);

        // 基本上两边都存在就差不多了，在比对一些细节
        verifyArtifactDetail(src, dst);

        doneListKeys.add(currWare.getArtifactKey());
    }

    // 比对两个组件的摘要信息，版本序号等，如需进一步比对附件详情可自行重载
    protected void verifyArtifactDetail(ArtifactWare art1, ArtifactWare art2) throws Exception
    {
        if (ToolUtilities.compareString(art1.getVersionSeq(), art2.getVersionSeq()) != 0)
            throw new Exception("Version seq is different : " + art1);

        if (art1.getReleasePkg() != null)
            if (!compareAttachInfo(art1.getReleasePkg(), art2.getReleasePkg()))
                throwAttachDiff("Release package is different", art1, art1.getReleasePkg(), art2, art2.getReleasePkg());

        if (art1.getModelPkg() != null)
            if (!compareAttachInfo(art1.getModelPkg(), art2.getModelPkg()))
            {
                // 如果存在系统模型（二进制）被加入了发布包，那么是会被抛弃的，所以再次导入时会不一致
//              throwAttachDiff("Model package is different", art1, art1.getModelPkg(), art2, art2.getModelPkg());
                trace("WARN:Model package is different(%s): \n%s\n--------\n%s\n--------\n", art1.getKey(), art1.getModelPkg().getInfo(), art2.getModelPkg().getInfo());
            }

        if (art1.getProjectPkg() != null)
            if (!compareAttachInfo(art1.getProjectPkg(), art2.getProjectPkg()))
                throwAttachDiff("Project package is different", art1, art1.getProjectPkg(), art2, art2.getProjectPkg());
//        art1.getProjectPkg();
    }

    protected void throwAttachDiff(String msg, ArtifactWare art1, AttachBrief a1, ArtifactWare art2, AttachBrief a2) throws Exception
    {
        throw new Exception(msg + "(" + art1 + ") : \n" + a1 + "\n-----<>-----\n" + a2 + "\n-----\n");
    }

    protected boolean compareAttachInfo(AttachBrief a1, AttachBrief a2)
    {
        if (a1 == null && a2 == null)
            return true;
        if (a1 == null || a2 == null)
            return false;

        if (ToolUtilities.isStringEqual(a1.getInfo(), a2.getInfo()))
            return true;

        List<String> l1 = ToolUtilities.getSplitedString(a1.getInfo(), "\n");
        List<String> l2 = ToolUtilities.getSplitedString(a2.getInfo(), "\n");
        if (ToolUtilities.getObjectSize(l1) != ToolUtilities.getObjectSize(l2))
            return false;
        for (String s1 : Nulls.get(l1))
        {
            if (!l2.contains(s1))
                return false;
        }
        return true;
    }

    public Set<String> migrateWareWithDepends(String groupId, String artifactId, String version) throws Exception
    {
        ArtifactWare ware = getSrcIntf().queryArtifact(groupId, artifactId, version, false, ArtifactWare.FIELDS_BRIEF);
        CmnUtil.assertNotNull(ware, "Unknown artifact ware: " + groupId + "." + artifactId + "(" + version + ")");

        ArtifactGraph graph = getSrcIntf().queryDependGraph(ToolUtilities.newHashSet(ware.getUuid()), true);
        printRelationGraph(graph);

        HashSet<String> doneList = new HashSet<String>();
        migrateWareWithDepends(graph, ware.getUuid(), doneList);
        return doneList;
    }

    public final static String EXPORT_GRAPH_FILE = "graph.bin";

    public final static String EXPORT_GRAPH_TXT_FILE = "depend_relation.txt";

    public final static String EXPORT_DATA_DIR = "data";

    /**
     * 将指定Artifact（列表）导出到目标文件夹，会生成关系图对象(重要）
     * 
     * @param dstFolder
     *            : 结果生成目标目录
     * @param artifacts
     *            ：要导出的组件列表（主要包含groupId，artifactId和version即可）
     */
    public Set<String> exportWareWithDepends(IProgress prog, File dstFolder, HashSet<ArtifactDefine> artifacts) throws Exception
    {
        try
        {
            IProgressUtil.sendProcess(prog, 0, "Query Artifacts ... ", true);
            HashSet<String> artUuids = new HashSet<String>();
            for (ArtifactDefine def : artifacts)
            {
                ArtifactWare ware = getSrcIntf().queryArtifact(def.getGroupId(), def.getArtifactId(), def.getVersion(), false, ArtifactWare.FIELDS_BRIEF);
                CmnUtil.assertNotNull(ware, "Unknown artifact ware: " + def);
                artUuids.add(ware.getUuid());
            }

            IProgressUtil.sendProcess(prog, 5, "Query Depends Graph ... ", true);
            ArtifactGraph graph = getSrcIntf().queryDependGraph(artUuids, true);
            ToolUtilities.saveFile(dstFolder.getAbsolutePath() + "/" + EXPORT_GRAPH_FILE, ClassFactory.serialObject(graph), false);
            ToolUtilities.saveFileUtf8(dstFolder.getAbsolutePath() + "/" + EXPORT_GRAPH_TXT_FILE, graph.getDependText(), false);
            printRelationGraph(graph);

            HashSet<String> doneList = new HashSet<String>();
            int pos = 0;
            for (String artUuid : artUuids)
            {
                IProgressUtil.assertCancel(prog);

                exportWareWithDepends(new ChildProgress(pos, ++pos, artUuids.size(), prog), new File(dstFolder, EXPORT_DATA_DIR), graph, artUuid, doneList);
            }
            return doneList;
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    protected void exportWareWithDepends(IProgress prog, File dstFolder, ArtifactGraph graph, String currentUuid, Set<String> doneListKeys) throws Exception
    {
        Set<String> depends = graph.getRelations().getTarget(currentUuid);
        int pos = 0;
        for (String depend : Nulls.get(depends))
        {
            IProgressUtil.assertCancel(prog);

            // 有依赖的优先导入依赖的
            exportWareWithDepends(new ChildProgress(pos, ++pos, depends.size(), prog), dstFolder, graph, depend, doneListKeys);
        }

        // 依赖项都导完了才能导自己
        ArtifactWare currWare = graph.getArtifacts().get(currentUuid);
        if (doneListKeys.contains(currWare.getArtifactKey()))
            return; // 避免重复导入

        File dstFile = new File(dstFolder, getExportFileName(currWare));
        if (checkIgnoreExport(currWare, dstFile))
            return;

        // 导出单个
        exportSingleFile(dstFile, currWare.getGroupId(), currWare.getArtifactId(), currWare.getVersion());
        doneListKeys.add(currWare.getArtifactKey());
        IProgressUtil.sendProcess(prog, 100, "Exported : " + currWare, true);
    }

    // 是否要忽略导出该组件，返回True则忽略
    protected boolean checkIgnoreExport(ArtifactWare art, File dstFile) throws Exception
    {
        if (ignoreExisted)
        {
            if (ToolUtilities.isFileReadable(dstFile.getAbsolutePath()))
            {
                trace("Ignore existed : " + dstFile);
                return true;
            }
        }

        return false;
    }

    //
    /**
     * 从文件夹中导入Artifact（整个依赖图谱），该文件夹中包含关系图对象（重要），然后有独立导出到目标文件夹，会生成关系图对象，组件二进制以及依赖包目录等
     * 返回的是导入的源头组件列表
     */
    public List<ArtifactWare> importArtifactWareDir(IProgress prog, File artFolder) throws ClassNotFoundException, IOException, Exception
    {
        ArtifactGraph graph = (ArtifactGraph) ClassFactory.unserialize(ToolUtilities.readFile(artFolder.getAbsolutePath() + "/" + EXPORT_GRAPH_FILE));
        try
        {
            if (graph.getRelations().size() <= 0)
            {
                // 无关系的孤立组件
                List<ArtifactWare> lstRet = new LinkedList<ArtifactWare>();
                int pos = 0;
                for (String startUuid : graph.getArtifacts().keySet())
                {
                    IProgressUtil.assertCancel(prog);

                    ArtifactWare ware = importArtifactWare(new ChildProgress(pos, ++pos, graph.getArtifacts().size(), prog), artFolder, graph, startUuid);
                    lstRet.add(ware);
                }
                return lstRet;
            } else
            {
                // 寻找依赖关系源头开始导
                Set<String> starts = graph.getRelations().searchStartNodes();
                List<ArtifactWare> lstRet = new LinkedList<ArtifactWare>();
                int pos = 0;
                for (String startUuid : starts)
                {
                    IProgressUtil.assertCancel(prog);

                    ArtifactWare ware = importArtifactWare(new ChildProgress(pos, ++pos, starts.size(), prog), artFolder, graph, startUuid);
                    lstRet.add(ware);
                }
                return lstRet;

            }
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    // artUuid是Graph中记录的uuid
    public ArtifactWare importArtifactWare(IProgress prog, File rootFolder, ArtifactGraph graph, String artUuid) throws Exception
    {
        ArtifactWare fileArt = graph.getArtifacts().get(artUuid);
        CmnUtil.assertNotNull(fileArt, "Invalid artifact UUID : " + artUuid);
        fileArt.setUuid(artUuid);
        IProgressUtil.sendProcess(prog, 0, "Import artifact : " + fileArt, true);

        // 判断是否忽略重复导入（如果存在且返回对象，则忽略后续操作）
        ArtifactWare existed = checkIgnoreImport(fileArt);
        if (existed != null)
            return existed;

        File binFile = new File(new File(rootFolder, EXPORT_DATA_DIR), getExportFileName(fileArt));
        if (!ToolUtilities.isFileReadable(binFile.getAbsolutePath()))
            throw new Exception("Data file is invalid : " + binFile);

        // 优先导入依赖项
        Set<String> targets = graph.getRelations().getTarget(fileArt.getUuid());
        int pos = 0;
        for (String depUuid : Nulls.get(targets))
        {
            IProgressUtil.assertCancel(prog);

            ArtifactWare depFileArt = graph.getArtifacts().get(depUuid);
            CmnUtil.assertNotNull(fileArt, "Invalid artifact UUID : " + depUuid);
            depFileArt.setUuid(depUuid);

            // 递归调用自己进行导入
            ChildProgress childProg = new ChildProgress(pos, ++pos, targets.size(), prog);
            ArtifactWare depWare = importArtifactWare(childProg, rootFolder, graph, depUuid);
        }

        // 依赖都导入后再导入自己
        ArtifactPackage pkg = (ArtifactPackage) ClassFactory.unserialize(ToolUtilities.readFile(binFile.getAbsolutePath()));

//      getDstIntf().publishArtifact(pkg, dstUser); // 这是要校验版本的
        getDstIntf().importArtifact(pkg, dstUser); // 这是强制导入, 不校验版本的

        return getDstIntf().queryArtifact(fileArt.getGroupId(), fileArt.getArtifactId(), fileArt.getVersion(), false);
    }

    // 返回ArtifactWare已存在的对象，如果为空则不需要跳过
    protected ArtifactWare checkIgnoreImport(ArtifactWare art) throws Exception
    {
        if (ignoreExisted)
        {
            ArtifactWare existed = getDstIntf().queryArtifact(art.getGroupId(), art.getArtifactId(), art.getVersion(), false, ArtifactWare.FIELDS_BRIEF);
            if (existed != null)
            {
                trace("Ignore existed : " + existed.getArtifactKey());
                return existed;
            }
        }

        return null;
    }

    public static String getExportFileName(String artId, String ver)
    {
        return ArtifactUtil.getKey(artId, ver) + ".bin";
    }

    public static String getExportFileName(ArtifactDefine artDef)
    {
        return getExportFileName(artDef.getArtifactId(), artDef.getVersion());
    }

    protected void printRelationGraph(ArtifactGraph graph)
    {
        trace(graph.getDependText());
    }

    protected void trace(Object obj, Object... params)
    {
        LvUtil.trace(String.format(obj + "", params));
    }

    public void exportSingleJars(File dstFile, String groupId, String artifactId, String version) throws Exception
    {
        ArtifactWare ware = getSrcIntf().queryArtifact(groupId, artifactId, version, false);
        CmnUtil.assertNotNull(ware, "Invalid artifact ware : " + groupId + "." + artifactId + "(" + version + ")");

        List<CDoAttach> releasePkg = getSrcIntf().queryReleasePackage(ware.getUuid());
        for (CDoAttach rls : Nulls.get(releasePkg))
        {
            ToolUtilities.saveFile(dstFile.getAbsolutePath() + "/" + rls.getName(), rls.getContentBin(), false);
        }

    }

    protected void exportJarsWithDepends(IProgress prog, File dstFolder, ArtifactGraph graph, String currentUuid, Set<String> doneListKeys) throws Exception
    {
        Set<String> depends = graph.getRelations().getTarget(currentUuid);
        int pos = 0;
        for (String depend : Nulls.get(depends))
        {
            IProgressUtil.assertCancel(prog);

            // 有依赖的优先导入依赖的
            exportJarsWithDepends(new ChildProgress(pos, ++pos, depends.size(), prog), dstFolder, graph, depend, doneListKeys);
        }

        // 依赖项都导完了才能导自己
        ArtifactWare currWare = graph.getArtifacts().get(currentUuid);
        if (doneListKeys.contains(currWare.getArtifactKey()))
            return; // 避免重复导入

        // 导出单个
        exportSingleJars(dstFolder, currWare.getGroupId(), currWare.getArtifactId(), currWare.getVersion());
        doneListKeys.add(currWare.getArtifactKey());
        IProgressUtil.sendProcess(prog, 100, "Exported : " + currWare, true);
    }

    public Set<String> exportJarsWithDepends(IProgress prog, File dstFolder, Collection<ArtifactDefine> artifacts) throws Exception
    {
        try
        {
            IProgressUtil.sendProcess(prog, 0, "Query Artifacts ... ", true);
            HashSet<String> artUuids = new HashSet<String>();
            for (ArtifactDefine def : artifacts)
            {
                ArtifactWare ware = getSrcIntf().queryArtifact(def.getGroupId(), def.getArtifactId(), def.getVersion(), false, ArtifactWare.FIELDS_BRIEF);
                CmnUtil.assertNotNull(ware, "Unknown artifact ware: " + def);
                artUuids.add(ware.getUuid());
            }

            IProgressUtil.sendProcess(prog, 5, "Query Depends Graph ... ", true);
            ArtifactGraph graph = getSrcIntf().queryDependGraph(artUuids, true);
            printRelationGraph(graph);

            HashSet<String> doneList = new HashSet<String>();
            int pos = 0;
            for (String artUuid : artUuids)
            {
                IProgressUtil.assertCancel(prog);

                exportJarsWithDepends(new ChildProgress(pos, ++pos, artUuids.size(), prog), dstFolder, graph, artUuid, doneList);
            }
            return doneList;
        } finally
        {
            IProgressUtil.sendFinishProcess(prog);
        }
    }

    public static void main(String[] args)
    {
        testImportAloneArt();
        if (true)
            return;
        
        try
        {
//            ArtWareMigrationTool tool = new ArtWareMigrationTool(new URI(YunStoreAgent.getConfigUri()), null);
//            ArtWareMigrationTool tool = new ArtWareMigrationTool(null, new URI("ws://localhost:2020"));
            ArtWareMigrationTool tool = new ArtWareMigrationTool(new URI(YunStoreAgent.getConfigUri()), new URI("ws://localhost:2020"));
            tool.setSrcUser(new UserPassword().setUser("ck").setPassword("ck"));
            tool.setDstUser(new UserPassword().setUser("ck2").setPassword("public"));

            String grp = "free.open";
            String art = "bi_fe";
            String ver = "1.0.0";

//              测试导出单个文件
//            String key = ArtifactUtil.getKey(art, ver);
//            String tmpFile = "D://test_export_artifact/" + key + ".bin"; //
//            tool.exportSingleFile(new File(tmpFile), grp, art, ver); //
//            ArtifactPackage pkg = tool.loadFilePackage(tmpFile); //
//            CmnUtil.out("" + pkg);

                // 测试导出jar
//            HashSet<ArtifactDefine> setArts = new HashSet<ArtifactDefine>();   
//            setArts.add(ArtifactDefine.build("free.open", "cmn_util", "1.0.5")); // 故意加一个依赖重复的
//            setArts.add(ArtifactDefine.build(grp, art, ver));
//            setArts.add(ArtifactDefine.build("free.open", "cmn_util_fe", "1.0.8")); // 故意加一个依赖重复的
//            tool.exportJarsWithDepends(new COutputProgress(), new File("D://test_export_jars"), setArts);

            // 测试导出文件,及导入文件(含依赖项)
            if (true)
            {
                tool.setIgnoreExisted(true);// (默认true）设为false则强制覆盖已存在的，一般用于覆盖同版本问题包或修复残缺的依赖树，会比较慢，因为所有存在的都会重新写入一遍

                HashSet<ArtifactDefine> setArts = new HashSet<ArtifactDefine>();
                setArts.add(ArtifactDefine.build("jdf", "fe_core", "4.22.0")); // 故意加一个依赖重复的
                setArts.add(ArtifactDefine.build(grp, art, ver));
                setArts.add(ArtifactDefine.build("jdf", "fe_core", "4.20.0")); // 故意加一个依赖重复的

                File targetDir = new File("D://test_export_artifacts");
                tool.exportWareWithDepends(new COutputProgress(), targetDir, setArts);

                List<ArtifactWare> lstImports = tool.importArtifactWareDir(new COutputProgress(), targetDir);
                CmnUtil.out("Imported : " + ToolUtilities.logString(lstImports, false));

                // 校验比对两个库的差异 tool.verifyWareWithDepends(grp, art, ver);
                tool.verifyWareWithDepends("free.open", "cmn_util_fe", "1.0.8");
                tool.verifyWareWithDepends("free.open", "bi_fe", "1.0.0");
            }

            
            // 测试内存里导出导入（Migration）
            if (false)
            {
//            tool.setIgnoreExisted(false);
                String[][] arts = new String[][] {{"free.open", "bi_fe", "1.0.0"}
                                                                        ,{"free.open", "fe_util", "1.3.2"}
                                                                        ,{"free.open", "cmn_util_fe", "1.0.8"}
                                                                        ,{"free.open", "cmn_util_fe", "1.0.5"}
                                                                        , {"free.open", "fe_util", "1.3.9-RC1"}
                                                                        , {"free.open", "fe_util", "1.3.7"}
                                                                        , {"free.open", "fe_util", "1.3.6"}
                                                                        , {"free.open", "fe_util", "1.3.3"}
                                                                        , {"free.open", "ai_mentor_service", "1.0.1"}
                                                                        , {"org.jeasy", "easy-rules-mvel", "4.1.0"}};
                for (String[] one : arts)
                {
                    tool.migrateWareWithDepends(one[0], one[1], one[2]);
                }
                
                for (String[] one : arts)
                {
                    tool.verifyWareWithDepends(one[0], one[1], one[2]);
                }
            }

        } catch (Throwable err)
        {
            err.printStackTrace();
        }

        System.exit(0);
    }
    

    // 测试导入单个孤立（无依赖）的组件
    public static void testImportAloneArt()
    {
        try
        {
//            ArtWareMigrationTool tool = new ArtWareMigrationTool(new URI(YunStoreAgent.getConfigUri()), null);
//            ArtWareMigrationTool tool = new ArtWareMigrationTool(null, new URI("ws://localhost:2020"));
            ArtWareMigrationTool tool = new ArtWareMigrationTool(new URI(YunStoreAgent.getConfigUri()), new URI("wss://localhost:2020"));
            tool.setSrcUser(new UserPassword().setUser("ck").setPassword("ck"));
            tool.setDstUser(new UserPassword().setUser("ck2").setPassword("public"));

            String grp = "free.open";
            String art = "test_fe";
            String ver = "1.0.2";
            // 测试导出文件,及导入文件(含依赖项)
            if (true)
            {
                tool.setIgnoreExisted(true);// (默认true）设为false则强制覆盖已存在的，一般用于覆盖同版本问题包或修复残缺的依赖树，会比较慢，因为所有存在的都会重新写入一遍

                HashSet<ArtifactDefine> setArts = new HashSet<ArtifactDefine>();
                setArts.add(ArtifactDefine.build("free.open", "test_fe", "1.0.2")); // 孤立无依赖的组件

                File targetDir = new File("D://test_export_artifacts");
                tool.exportWareWithDepends(new COutputProgress(), targetDir, setArts);

                List<ArtifactWare> lstImports = tool.importArtifactWareDir(new COutputProgress(), targetDir);
                CmnUtil.out("Imported : " + ToolUtilities.logString(lstImports, false));

                // 校验比对两个库的差异 tool.verifyWareWithDepends(grp, art, ver);
//                tool.verifyWareWithDepends("free.open", "cmn_util_fe", "1.0.8");
//                tool.verifyWareWithDepends("free.open", "bi_fe", "1.0.0");
            }

        } catch (Throwable err)
        {
            err.printStackTrace();
        }

        System.exit(0);
    }
}
