package bap.yun;

import java.io.IOException;
import java.net.URI;
import java.util.Properties;

import com.leavay.common.nio.CNioConnectionException;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;

import cell.bap.yun.IYunStore;

/**
 * 作为客户端连接云Store的适配器
 * 通过此适配器，远程调用云Store中心服务 
 *
 */
public class YunStoreAgent
{
    CRpcAdapter _adapter = new CRpcAdapter();
    CRpcClientWrapper<IYunStore> _intf = new CRpcClientWrapper<IYunStore>(IYunStore.class)
    {
        public CRpcAdapter getAdapter()
        {
            return _adapter;
        }
        
    };
    public static YunStoreAgent _me;
    public synchronized static YunStoreAgent get()
    {
        if (_me == null)
            _me = new YunStoreAgent();
        
        return _me;
    }
    
    protected YunStoreAgent()
    {
        try
        {
            String srvUri = getConfigUri();
            
            _intf.init(new URI(srvUri));
        } catch (Throwable exp)
        {
            ToolUtilities.throwRuntimeException(exp);
        }
    }
    
    static Properties confProps = null;
    public static synchronized Properties getConfProp()
    {
        if (confProps == null)
        {
            confProps = new Properties();
            try
            {
                confProps.load(ToolBasic.getClassLoader().getResourceAsStream(ArtifactConst.CONF_YUN_STORE_FILE_PATH));
            } catch (IOException exp)
            {
                CmnUtil.throwRuntimeException(exp);
            }
        }
        return confProps;
    }
    
    // 当BapClient连接后端时会自动初始化此值，从而使后端URI成为主导
    protected static String URI_FROM_BAP_SERVER = null;
    public static void initStoreUri(String serverUri)
    {
        URI_FROM_BAP_SERVER = serverUri;   
    }
    
    public static String getConfigUri()
    {
        // 如果有连接后端，且后端有特定的仓库配置，则以后端为准
        if (CmnUtil.isStringNotEmpty(URI_FROM_BAP_SERVER))
            return URI_FROM_BAP_SERVER;
        
        // 优先获取环境变量的设定
        String envUri = System.getenv(ArtifactConst.CONF_YUN_STORE_URI);
        if (!CmnUtil.isStringEmpty(envUri))
            return envUri;
        
        // 加载内嵌配置文件的 : Core\bap\resources\bap\yun\YunStoreConfig.prop
        String confUri = getConfProp().getProperty(ArtifactConst.CONF_YUN_STORE_URI);
        
        // 如果全局配置有,则以mppContext的为准
        String srvUri = MppContext.getString(ArtifactConst.CONF_YUN_STORE_URI, confUri);

        return srvUri;
    }
    
    public static IYunStore getIntf()
    {
        try
        {
            return get()._intf.getIntf();
        }catch (Throwable err)
        {
            if (ToolUtilities.isCausedBy(err, CNioConnectionException.class))
            {
                throw new RuntimeException(CmnUtil.getString("Please check if your network can connect to the cloud repository.\n"
                        +"You can also use a configuration file or environment variable to specify the address of a private repository, such as :\n        yun.store.server.uri=ws://xx.xx.xx.xx:2020"), err); 
            }else
                ToolUtilities.throwRuntimeException(err);
            
            return null;
        }
    }
    
    public CRpcClientWrapper<IYunStore> getIntfWrapper()
    {
        return _intf;
    }
}

    