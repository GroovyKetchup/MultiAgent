package bap.yun;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

import com.cdao.model.CDoModel;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import bap.java.project.CJavaCenter;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import cell.bap.yun.ArtifactGraph;
import cmn.util.NullUtil;
import cmn.util.Nulls;

public class ArtifactUtil
{
    // 这个KEY通常被看做artifact的唯一标识，用以排它，groupID不作为唯一标识，也就是说不同groupID也不允许artifact一模一样
    public static String getKey(String artifactId, String version)
    {
        return artifactId+ArtifactConst.RELEASE_VERSION_SEP+version;
    }
    
    public static String toJarFileName(String artifactId, String version, String fd)
    {
        return artifactId+ArtifactConst.RELEASE_NAME_SEP+fd+ArtifactConst.RELEASE_VERSION_SEP+version+".jar";
    }
    
    /**
     * 假设版本号以英文句点为分割，从高位开始比对，以字符串大小为比对依据，决定哪个版本更高
     * 
     * 3.2.1 高于 2.3.5
     * 3.3.1 高于 3.2.7
     * 
     * 如果v1=v2，返回0
     * 如果v1 高于 v2，返回1
     * 如果v1 低于 v2，返回-1
     */
    public static int compareVersion(String v1, String v2)
    {
        // 最新的实现(较为严格)
        try
        {
            return YunVersion.compare(v1, v2);
        }catch (Throwable err)
        {
            // ignore
        }
        
        // 老的土办法(比较宽松, 但对于复杂后缀只能简单的按照字符串排序)
        if (v1 == null || v2 == null)
            return CmnUtil.compareString(v1, v2);
        
        if (v1.equals(v2))
            return 0;
        
        List<String> lst1 = CmnUtil.getSplitedString(v1, ".", true);
        List<String> lst2 = CmnUtil.getSplitedString(v2, ".", true);
        for (int i=0; i< Math.min(lst1.size(), lst2.size()); i++)
        {
            String char1 = lst1.get(i);
            String char2 = lst2.get(i);
            
            // 尝试比对数字
            int res = 0;
            double num1 = ToolUtilities.getDouble(char1, -1);
            double num2 = ToolUtilities.getDouble(char2, -1);
            if (num1 > 0 && num2 >0)
            {
                // 尝试以数字比对大小
                res = Double.compare(num1, num2);
            }
            else
            {
                // 有一方非数字，则以字符串比对大小
                res = CmnUtil.compareString(char1, char2, true);
            }
            
            // 由左到右，只要比出大小则返回，否则继续比对低位
            if (res != 0)
                return res;
        }
        
        // 最终无法分出胜负，则以字符串比对
        return CmnUtil.compareString(v1, v2, true);
    }
    
    public static String getPreferType(String artifactKey, Map<String, String> prefMap)
    {
        return prefMap==null?null:prefMap.get(artifactKey);
    }
    
    public static boolean isPreferPrior(String artifactKey, Map<String, String> prefMap)
    {
        return isPreferPrior(getPreferType(artifactKey, prefMap));
    }
    
    public static boolean isPreferPrior(String type)
    {
        return ArtifactConst.PREFER_TYPE_PRIOR.equalsIgnoreCase(type);
    }
    
    public static boolean isPreferExclude(String artifactKey, Map<String, String> prefMap)
    {
        return isPreferExclude(getPreferType(artifactKey, prefMap));
    }
    
    public static boolean isPreferExclude(String type)
    {
        return ArtifactConst.PREFER_TYPE_EXCLUDE.equalsIgnoreCase(type);
    }
    
    @Test
    public void test()
    {
        String[][] ver = new String[] [] {{"3.2.1", "3.7.7_beta"}
        ,{"1.3.9-RC3", "1.3.10"}
        ,{"1.3.9", "1.3.10"}
        ,{"1.3.9-RC3", "1.4.1"}
        ,{"2.2.1", "2.7.2"}
        , {"5.2.4", "5.1.4"}
        ,{"7.8.3", "7.8.2"}
        ,{"1.1.3", "1.1.0"}};
        
        for (String[] p : ver)
        {
            CmnUtil.out(p[0]+"->"+p[1]+" = "+compareVersion(p[0], p[1]));
        }
    }
    
    // 按照特定算法，去除重复、冲突（自动取版本更高、以及结合prefSetting）计算最终列表
    public static List<ArtifactDefine> mergeConflictList(List<ArtifactDefine> lstArts, Map<String, String> prefSetting)
    {
        Map<String, ArtifactDefine> mapRet = new HashMap<String, ArtifactDefine>();
        for (ArtifactDefine art : Nulls.get(lstArts))
        {
            ArtifactDefine exist= mapRet.get(art.getArtifactId());
            if (exist == null)
            {
                mapRet.put(art.getArtifactId(), art);
                continue;
            }
            
            boolean nowPri = isPreferPrior(art.getArtifactKey(), prefSetting);
            boolean existPri = isPreferPrior(exist.getArtifactKey(), prefSetting);
            
            // 优先的，无条件替换非优先的
            if (nowPri && !existPri)
            {
                mapRet.put(art.getArtifactId(), art);
                continue;
            }

            // 原本优先，现在不优先，则无条件抛弃
            if (!nowPri && existPri)
                continue;
            
            // 剩下的就是需要公平比较版本的了
            if (compareVersion(art.getVersion(), exist.getVersion())> 0)
            {
                mapRet.put(art.getArtifactId(), art);
            }
        }
        
        return new LinkedList<ArtifactDefine>(mapRet.values());
    }
    
    public static <T extends ArtifactDefine> T findDefine(Collection<T> lst, String artifactID)
    {
        for (T def : lst)
        {
            if (CmnUtil.isStringEqual(def.getArtifactId(), artifactID))
                return def;
        }
        return null;
    }
    
    public static <T extends ArtifactDefine> T findDefine(Collection<T> lst, String groupId, String artifactID)
    {
        for (T def : lst)
        {
            if (CmnUtil.isStringEqual(def.getGroupId(), groupId) && CmnUtil.isStringEqual(def.getArtifactId(), artifactID))
                return def;
        }
        return null;
    }
    
    public static <T extends ArtifactDefine> T removeDefine(Collection<T> lst, String groupId, String artifactID)
    {
        for (Iterator<T> it = lst.iterator(); it.hasNext(); )
        {
            T def = it.next();
            if (CmnUtil.isStringEqual(def.getGroupId(), groupId) && CmnUtil.isStringEqual(def.getArtifactId(), artifactID))
            {
                it.remove();
                return def;
            }
        }
        
        return null;
    }
    
    // 寻找同名artifactID替换掉，没有则加入到队尾
    public static <T extends ArtifactDefine> void addOrReplaceDefine(List<T> lst, T def)
    {
        for (int i=0; i<lst.size(); i++)
        {
            T t = lst.get(i);
            if (CmnUtil.isStringEqual(t.getArtifactId(), def.getArtifactId()))
            {
                lst.remove(i);
                lst.add(i, def);
                return;
            }
        }
        
        lst.add(def);
    }
    
    // 比对两个组件列表是否发生了变化
    public static boolean isArtifactListSame(List<ArtifactDefine> lst1, List<ArtifactDefine> lst2)
    {
        if (CmnUtil.getObjectSize(lst1) != CmnUtil.getObjectSize(lst2))
            return false;
        
        for (ArtifactDefine a1 : lst1)
        {
            boolean found = false;
            for (ArtifactDefine a2 : lst2)
            {
                if (a1.isDefineSame(a2))
                {
                    found = true;
                    break;
                }
            }
            if (!found)
                return false;
        }
        
        for (ArtifactDefine a2 : lst2)
        {
            boolean found = false;
            for (ArtifactDefine a1 : lst1)
            {
                if (a2.isDefineSame(a1))
                {
                    found = true;
                    break;
                }
            }
            if (!found)
                return false;
        }
        
        return true;
    }

    public static ArtifactGraph queryDependGraph(Collection<ArtifactDefine> firstLayerDepend) throws Exception
    {
        if (firstLayerDepend == null)
            return null;

        // 将第一层依赖，查出整个递归依赖图谱，并去重
        Set<String> setArts = new HashSet<String>();
        Map<String, ArtifactWare> mapArtWare = new HashMap<String, ArtifactWare>();
        for (ArtifactDefine def : firstLayerDepend)
        {
            ArtifactWare yunArt = YunStoreAgent.getIntf().queryArtifact(def.getGroupId(), def.getArtifactId(), def.getVersion(), false, ArtifactWare.FIELDS_BRIEF);
            CmnUtil.assertNotNull(yunArt, "There isn't valid artifact in yun store : " + def);
            mapArtWare.put(yunArt.getUuid(), yunArt);
        }
        return YunStoreAgent.getIntf().queryDependGraph(new HashSet<String>(mapArtWare.keySet()), true);
    }

    // 查询出所有依赖的云组件（递归查出所有）
    public static List<ArtifactWare> queryAllDependWare(Collection<ArtifactDefine> firstLayerDepend) throws Exception
    {
        ArtifactGraph graph = queryDependGraph(firstLayerDepend);
        if (graph == null)
            return new LinkedList<ArtifactWare>();
        return new LinkedList(NullUtil.get(graph.getArtifacts().values()));
    }
    
    // 查询出某个云组件依赖的所有模型（递归找依赖的所有组件的相关模型）
    // ignoreGlobalExclude ：是否忽略全局依赖设定中的排除列表的模型
    public static List<CDoModel> queryAllDependModel(ArtifactWare ware, boolean ignoreGlobalExclude) throws Exception
    {
        List<CDoModel> lstModel = new LinkedList<CDoModel>();
        
        // 查全局依赖
        GlobalDependSetting globalDepSetting = null;
        if (ignoreGlobalExclude)
            globalDepSetting = CJavaCenter.getMe().queryGlobalDepends();

        // 查出依赖图谱，包括自己
        List<ArtifactWare> lstDepWares = queryAllDependWare(ToolUtilities.newArrayList(ware));
        for (ArtifactWare w : NullUtil.get(lstDepWares))
        {
            // 设置了排除的Art，忽略其模型
            if (ignoreGlobalExclude && globalDepSetting != null && globalDepSetting.isExcludeArtifact(w))
                continue;
            
            List<CDoModel> lstMd = YunStoreAgent.getIntf().queryModelPackage(w.getUuid());
            ToolBasic.combineList(lstModel, lstMd);
//            ToolUtilities.infoAndOutput("ArtifactUtil", "Query Depend Models ==="+w+"===\n"+ToolUtilities.logString(lstMd, true));
        }
        
        return lstModel;
    }
}
