package bap.yun;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

/**
用java实现一个完整的比对版本号大小的逻辑.要求如下: 主版本号以三个数字用.分割, 如: 2.54.23 尾部可追加小版本号, 用下划线或横杠分割,
如: 2.3.5-Rc6, 2.3.5_beta3 优先比对主版本号大小, 主版本号相同时则比对小版本号,
如果有+号分割, 有+号的大于没+号的,
而小版本号英文标识(不区分大小写)又按照: 无小版本>rc>beta>alpha的规则比对大小 版本号比对规则样例:
1.0.0-alpha<1.0.0-beta<1.0.0-rc1<1.0.0<1.0.0+001 
1.6.0-SNAPSHOT<1.0.0 1.3.5 >
1.3.4, 2.0.0>1.99.99,
3.2.1-RC6>3.2.0, 
1.3.9-RC6 < 1.3.10,
1.3.9-RC23>1.3.9-RC06
 * 
 *
 */
public class YunVersion implements Comparable<YunVersion>
{
    private static final String VERSION_REGEX = "^([0-9]+)\\.([0-9]+)\\.([0-9]+)([-_+](RC|BETA|ALPHA|SNAPSHOT|[0-9A-Z]*[0-9]+)?)?$";

    private static final Pattern VERSION_PATTERN = Pattern.compile(VERSION_REGEX, Pattern.CASE_INSENSITIVE);

    // 优先权定义
    private static final Map<String, Integer> PRECEDENCE_MAP = new HashMap<>();
    
    static int DEFAULT_SUFIX = 10000; // 无后缀大于普通后缀, 小于+号后缀
    static
    {
        PRECEDENCE_MAP.put("+", Integer.MAX_VALUE); // +号版本大于无后缀
        PRECEDENCE_MAP.put("RC", 300);
        PRECEDENCE_MAP.put("BETA", 200);
        PRECEDENCE_MAP.put("ALPHA", 100);
    }

    private int major;

    private int minor;

    private int patch;

    private String suffix;

    private int suffixPrecedence;

    public YunVersion(String version)
    {
        Matcher matcher = VERSION_PATTERN.matcher(version);
        if (!matcher.matches())
        {
            throw new IllegalArgumentException("Invalid version format : " + version);
        }

        major = Integer.parseInt(matcher.group(1));
        minor = Integer.parseInt(matcher.group(2));
        patch = Integer.parseInt(matcher.group(3));
        suffix = matcher.group(4) != null ? matcher.group(4).substring(1).toUpperCase() : "";

        // 计算后缀优先级
        suffixPrecedence = PRECEDENCE_MAP.getOrDefault(suffix.replaceAll("[0-9]+", ""), DEFAULT_SUFIX);
    }
    
    public static void verify(String version) throws IllegalArgumentException
    {
        Matcher matcher = VERSION_PATTERN.matcher(version);
        if (!matcher.matches())
        {
            throw new IllegalArgumentException("Invalid version format : " + version);
        }
    }

    @Override
    public int compareTo(YunVersion o)
    {
        if (this.major != o.major)
        {
            return Integer.compare(this.major, o.major);
        }
        if (this.minor != o.minor)
        {
            return Integer.compare(this.minor, o.minor);
        }
        if (this.patch != o.patch)
        {
            return Integer.compare(this.patch, o.patch);
        }
        if (!this.suffix.equals(o.suffix))
        {
            int pComp = Integer.compare(this.suffixPrecedence, o.suffixPrecedence);
            if (pComp != 0)
            {
                return pComp;
            }
            return compareSuffixNum(this.suffix, o.suffix);
        }
        return 0;
    }
    
    // 比对后缀小版本号的数字部分
    protected int compareSuffixNum(String s1, String s2)
    {
        for (String s : PRECEDENCE_MAP.keySet())
        {
            s1 = ToolUtilities.replaceAll(s1, s, "");
            s2 = ToolUtilities.replaceAll(s2, s, "");
            try {
                return Integer.compare(ToolUtilities.getInteger(s1), ToolUtilities.getInteger(s2));
            }catch (Throwable err)
            {
                // 非数字或非法字符, 则按字符比对
                return s1.compareToIgnoreCase(s2);
            }
        }
        return s1.compareToIgnoreCase(s2);
    }

    @Override
    public String toString()
    {
        return "Version{" + "major=" + major + ", minor=" + minor + ", patch=" + patch + ", suffix='" + suffix + '\'' + ", suffixPrecedence=" + suffixPrecedence + '}';
    }

    public static int compare(String v1, String v2)
    {
        return new YunVersion(v1).compareTo(new YunVersion(v2));
    }

    public static void main(String[] args)
    {
        compare( "5.2.4-release1", "2024_0516");
        
        String[][] ver = new String[][] { 
            { "2.54.23", "2.54.23-Rc6" }, 
            { "1.0.0-alpha", "1.0.0-beta" }, 
            { "2.3.5-Rc6", "2.3.5_beta3" }, 
            { "2.3.5-Rc62", "2.3.5_beta3" }, 
            { "2.3.5-Rc6", "2.3.5_RC008" }, 
            { "3.2.1", "3.7.7_beta" }, 
            { "1.3.9-RC3", "1.3.10" }, 
            { "1.3.9", "1.3.10" }, 
            { "1.3.9-RC3", "1.4.1" }, 
            { "2.2.1", "2.7.2" }, 
            { "5.2.4", "5.1.4" }, 
            { "5.2.4-release1", "5.2.4-rc6" }, 
            { "5.2.4-release1", "5.2.4-release3" }, 
            { "5.2.4-release008", "5.2.4-release3" }, 
            { "5.2.4-rc3", "5.2.4-rc7" }, 
            { "5.2.4", "5.2.4+003" }, 
            { "5.2.5", "5.2.4+003" }, 
            { "5.2.4-rc3", "5.2.4-Rc003" }, 
            { "5.2.4+5", "5.2.4+008" }, 
            { "5.2.4+005", "5.2.4+3" }, 
            { "7.8.3", "7.8.2" },
            { "1.1.3", "1.1.0" } 
            };

        for (String[] p : ver)
        {
            int v = compare(p[0], p[1]);
            if (v > 0)
                CmnUtil.out(p[0] + " > " + p[1]);
            else if (v == 0)
                CmnUtil.out(p[0] + " = " + p[1]);
            else
                CmnUtil.out(p[1] + " > "+ p[0]);
        }
    }
}