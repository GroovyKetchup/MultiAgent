package bap.yun;

public class ArtifactConst
{
    // 作为偏好设定的标识
    public static String PREFER_TYPE_PRIOR = "prior";
    public static String PREFER_TYPE_EXCLUDE = "exclude";
  
    public final static String CONF_YUN_STORE_FILE_PATH="bap/yun/YunStoreConfig.prop";
    public final static String CONF_YUN_STORE_URI = "yun.store.server.uri";
    
    public final static String PROJECT_ZIP = "project.zip";
    
    public final static String RELEASE_NAME_SEP = "-";
    public final static String RELEASE_VERSION_SEP = "-";
    
    public final static String LINK_FLAG_DEPEND = "artifact_depend"; // SRC -> DST ：SRC依赖DST
    
    // 生成到插件系统的插件工程名
    public final static String GLOBAL_DEPEND_ARTIFACT_PLUGIN = "Global Dependency Artifacts";
}
