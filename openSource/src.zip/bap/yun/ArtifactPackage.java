package bap.yun;

import java.io.Serializable;
import java.util.List;

import com.cdao.model.CDoAttach;
import com.leavay.ms.tool.CmnUtil;

import bap.md.java.CJavaProject;
import bap.md.yun.ArtifactDefine;

public class ArtifactPackage implements Serializable
{
    private static final long serialVersionUID = -4302743535273853257L;
    
    CJavaProject project;
    
    ArtifactDefine artifactDefine;

    // 一个zip文件，包含源码、Lib库等
    CDoAttach projectPkg;
    
    // 源码编译出的发布包
    List<CDoAttach> releasePkg;
    
    // 附件名都为无后缀的全类名
    // 一般来说都是只会有动态模型，以json格式TEXT附件的形式存储
    // 也允许静态模型（暂时无用），以二进制附件存储
    List<CDoAttach> modelPkg;

    
    public CJavaProject getProject()
    {
        return project;
    }

    public void setProject(CJavaProject project)
    {
        this.project = project;
    }

    public ArtifactDefine getArtifactDefine()
    {
        return artifactDefine;
    }

    public void setArtifactDefine(ArtifactDefine artifactDefine)
    {
        this.artifactDefine = artifactDefine;
    }

    
    public CDoAttach getProjectPkg()
    {
        return projectPkg;
    }

    public void setProjectPkg(CDoAttach projectPkg)
    {
        this.projectPkg = projectPkg;
    }

    public List<CDoAttach> getReleasePkg()
    {
        return releasePkg;
    }

    public void setReleasePkg(List<CDoAttach> releasePkg)
    {
        this.releasePkg = releasePkg;
    }
    
    public void addReleasePkg(CDoAttach oneFile)
    {
        releasePkg = CmnUtil.addToList(releasePkg, oneFile);
    }

    public List<CDoAttach> getModelPkg()
    {
        return modelPkg;
    }

    public void setModelPkg(List<CDoAttach> modelPkg)
    {
        this.modelPkg = modelPkg;
    }

    public void addModelPkg(CDoAttach oneMd)
    {
        modelPkg = CmnUtil.addToList(modelPkg, oneMd);
    }
}
