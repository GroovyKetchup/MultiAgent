package bap.yun;

import com.leavay.ms.tool.CmnUtil;

public class InvalidArtifactVersionException extends RuntimeException
{

    /**
     * 
     */
    private static final long serialVersionUID = -3857959051136907225L;

    public InvalidArtifactVersionException(String ver, String cause)
    {
        super(CmnUtil.getString("Illegal version format of artifact") + " : " + ver + " - " + cause);
    }
}
