package bap.yun;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import org.nutz.dao.Cnd;

import com.cdao.impl.entity.field.SlaveTable;
import com.cdao.mgr.CDaoUtil;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.ms.tool.CmnUtil;

import bap.md.CPluginProject;
import bap.md.yun.ArtifactDefine;
import bap.plugin.CPluginExportPackage;
import bap.plugin.CPluginProjectDto;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import cmn.util.AutoLock;

/**
 * 与JavaCenter一起工作，自动收集JAVA 工程中的配置，联系云Store同步导入依赖包
 * 并发布到插件去 
 *
 * 全局默认的插件工程（云同步中心工程），有且唯一，由此模块负责维护
 */
public class YunSyncCenter
{
    protected static YunSyncCenter _me = null;
    public synchronized static YunSyncCenter get()
    {
        if (_me == null)
            _me = new YunSyncCenter();
        
        return _me;
    }
    
    public final static String YUN_SYNC_PROJECT_NAME = "YUN_SYNC_PROJECT_NAME";
    
    ReentrantLock _lcRoot = new ReentrantLock();
    protected CPluginProject _rootProject = null;
    public CPluginProject prepareYunProject() throws Exception
    {
        try (AutoLock lc = AutoLock.lock(_lcRoot))
        {
            if (_rootProject != null)
                return _rootProject;
            
            try (IDao dao = IDaoService.newIDao())
            {
                _rootProject = (CPluginProject) dao.queryDo(CPluginProject.class.getName(), Cnd.where(CPluginProject.Name, "=", YUN_SYNC_PROJECT_NAME));
                if (_rootProject == null)
                {
                    _rootProject = (CPluginProject) new CPluginProject().setName(YUN_SYNC_PROJECT_NAME);
                    _rootProject = dao.createDo(_rootProject);
                    dao.commit();
                }
                
                return _rootProject;
            }
        }
    }
    
    protected YunSyncCenter()
    {
        
    }

    public CPluginProject getYunProject()
    {
        try
        {
            return prepareYunProject();
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }
    
    // autoCombineVersion : true=则自动合并为高版本，false=遇到版本冲突则报错
    /**
     * 搜索所有项目的依赖，以ArtifactID为key，返回依赖包的Map
     * 并且会移除本地定义的工程，只导入对外部所需
     * 
     * ArtifactID是全局唯一的，可作为key
     * 
     * @param autoCombineVersion : true=则自动合并为高版本，false=遇到版本冲突则报错
     */
    public Map<String, ArtifactDefine> analyseAllDepend(boolean autoCombineVersion) throws Exception
    {
        Map<String, ArtifactDefine> mapDep = new HashMap<String, ArtifactDefine>();
        try (IDao dao = IDaoService.newIDao())
        {
            List<ArtifactDefine> lstDef = dao.queryDoList(ArtifactDefine.class, null);
            if (lstDef == null)
                return mapDep;
            
            // 查询所有工程依赖的目标Artifact
            for (ArtifactDefine pjDef : lstDef)
            {
                SlaveTable<ArtifactDefine> lstDepend = (SlaveTable<ArtifactDefine>) dao.querySlaveTable(pjDef.getGid(), ArtifactDefine.DependTo);
                if (!CmnUtil.isObjectEmpty(lstDepend))
                    continue;
                
                for (ArtifactDefine def : lstDepend)
                {
                    ArtifactDefine exist = mapDep.get(def.getArtifactId());
                    if (exist == null)
                    {
                        mapDep.put(def.getArtifactId(), def);
                    }
                    else
                    {
                        // 重复的，需检查版本
                        if (autoCombineVersion)
                        {
                            // 比较版本，自动选更高的版本
                            if (ArtifactUtil.compareVersion(def.getVersion(), exist.getVersion()) > 0)
                                mapDep.put(def.getArtifactId(), def);
                        }else
                        {
                            if (!CmnUtil.isStringEqual(exist.getVersion(), def.getVersion()))
                                throw new Exception("Found duplicate depend artifact : " + def+"<>"+exist);
                        }
                    }
                }
            }
            
            for (ArtifactDefine localDef : lstDef)
                mapDep.remove(localDef.getArtifactId());
        }
        
        return mapDep;
    }
    
    // 从云Store下载分析到的所有依赖，然后发布到本地插件体系中去（全量替换原来的插件）
    public void publishPlugin() throws Exception
    {
        Map<String, ArtifactDefine> allDepend = analyseAllDepend(true);

        CPluginProjectDto pluginProject = CDaoUtil.convertDto(getYunProject(), CPluginProjectDto.class);
        
        CPluginExportPackage pkg = new CPluginExportPackage();
        pkg.setProject(pluginProject);
        
        ClassFactory.exportPublishPlugin(pkg, true);
    }
}
