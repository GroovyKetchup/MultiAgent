package bap.debug;

import java.io.File;
import java.net.URI;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cdao.gui.JConnectPanel;
import com.leavay.client.util.CNClientUtil;
import com.leavay.common.Exception.UserCancelException;
import com.leavay.common.nio.ws.CWsUtil;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcServer;
import com.leavay.nio.crpc.CRpcStarter;
import com.leavay.nio.crpc.CallbackUtil;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import bap.cells.BasicUdf;
import bap.cells.CellBuilderIntf;
import bap.cells.CellClientFactory;
import bap.cells.CellConfig;
import bap.cells.ConfigFactory;
import bap.cells.EmptyCellBuilder;
import bap.cells.ServerCellService;
import bap.cells.SimpleCellBuilder;
import bap.debug.gui.BapDebugSettingPanel;
import bap.debug.gui.DevConf;
import bap.java.CJavaConst;
import bap.java.CJavaUtil;
import bap.java.CodeMeta;
import bap.plugin.mgr.CPluginClient;
import bap.udf.CUdfUtil;
import bap.udf.UdfInvokerCellBuilder;
import bap.udf.UdfMeta;
import cell.CellIntf;
import cmn.util.Nulls;

/**
 * 如果想要调试该类，需要设定工作目录到某一个云开发工程，然后设定本工程依赖那个工程
 */
public class BapDebugger
{
    protected volatile boolean _started = false;

    protected URI _uri;

    protected static BapDebugger _me = null;

    public static synchronized BapDebugger get()
    {
        if (_me == null)
        {
            _me = new BapDebugger();
        }
        return _me;
    }

    private BapDebugger()
    {

    }

    public boolean isStarted()
    {
        return _started;
    }

    public void startGui(URI uri, boolean downloadPlugin) throws Exception
    {
        startGui(false, uri, downloadPlugin);
    }

    // quietly 静默模式，则不会弹出过滤器设定，也不能对某个cell进行独立配置
    public void startGui(boolean quielty, URI uri, boolean downloadPlugin) throws Exception
    {
        uri = JConnectPanel.showDialog(CNClientUtil.getTopoWindow(), uri);
        if (uri == null)
            return;

        _uri = uri;

        start(quielty, uri, downloadPlugin);
    }

    public void start(boolean quielty, URI uri, boolean downloadPlugin) throws Exception
    {
        start(true, quielty, uri, downloadPlugin);
    }

    /**
     * 启动远程联调
     * 
     * @param enableLocalCells
     *            是否本地CELL生效，并attach到云端，如果false，则完全不走本地逻辑
     * @param quielty
     *            是否静默模式，如果是则不会蹦出配置框，默认全部attach
     * @param uri
     * @param downloadPlugin
     *            是否下载插件
     * @throws Exception
     */
    public void start(boolean enableLocalCells, boolean quielty, URI uri, boolean downloadPlugin) throws Exception
    {
        ToolUtilities.assertFalse(isStarted(), "Remote Debugger was already started!");
        _uri = uri;

        CellClientFactory.getMe().start(uri);

        // 连接插件系统，依赖于Client factory先要联通
        // 为啥需要连接插件系统？
        if (downloadPlugin)
            connectPluginCenter();

        if (enableLocalCells)
        {
            attachLocalUdfs(quielty);

            attachLocalCells(uri, quielty);

            attachTempCellsToRemote();
        }

        _started = true;
    }

    public String getHost()
    {
        return _uri == null ? null : _uri.getHost();
    }

    public int getPort()
    {
        return _uri == null ? -1 : _uri.getPort();
    }

    public void connectPluginCenter() throws Exception
    {
        URI pluginServer = CellClientFactory.getMe().getIntf().getPluginServer();

        CPluginClient.getMe().initInClient(pluginServer, false);
    }

    // 屏蔽项过滤屏蔽器，默认是全都参与调试，出现在这里的就屏蔽
    public final static String FILE_LOCAL_FILTER = ".debug.filter";

    // 禁用本地CELL的列表（与Attach到服务端互斥，如果禁用则一律不会在本地执行
    public final static String FILE_LOCAL_BLACKLIST = ".debug.local.blacklist";

    // 加载更多本地源码目录下的cell(扫描源码并不能加载类, 只是拿到文件名, 之后还是要从当前classloader中加载类)
    public final static String FILE_EXT_SOURCE_CODE_PATH = ".debug.ext.cell.src.path";

    public static Set<String> loadLocalFilter()
    {
        try
        {

            List<String> lst = ToolUtilities.readFileLines(FILE_LOCAL_FILTER, "UTF-8");
            if (CmnUtil.isObjectEmpty(lst))
                return new HashSet<String>();
            else
                return new HashSet<String>(lst);
        } catch (Throwable exp)
        {
            return null;
        }
    }

    public static Set<String> loadLocalBlacklist()
    {
        try
        {
            List<String> lst = ToolUtilities.readFileLines(FILE_LOCAL_BLACKLIST, "UTF-8");
            if (CmnUtil.isObjectEmpty(lst))
                return new HashSet<String>();
            else
                return new HashSet<String>(lst);
        } catch (Throwable exp)
        {
            return new HashSet<String>();
        }
    }

    public static Set<String> loadExtSrcPaths()
    {
        try
        {
            List<String> lst = ToolUtilities.readFileLines(FILE_EXT_SOURCE_CODE_PATH, "UTF-8");
            if (CmnUtil.isObjectEmpty(lst))
                return new HashSet<String>();
            else
                return new HashSet<String>(lst);
        } catch (Throwable exp)
        {
            return new HashSet<String>();
        }
    }

    public static void saveLocalFilter(Set<String> filter) throws Exception
    {
        StringBuffer sb = new StringBuffer();
        if (!CmnUtil.isObjectEmpty(filter))
            for (String s : filter)
                sb.append(s.trim()).append("\n");

        ToolUtilities.saveFile(FILE_LOCAL_FILTER, sb.toString(), "UTF-8", false);
    }

    public static void saveLocalBlacklist(Set<String> blacklist) throws Exception
    {
        StringBuffer sb = new StringBuffer();
        if (!CmnUtil.isObjectEmpty(blacklist))
            for (String s : blacklist)
                sb.append(s.trim()).append("\n");

        ToolUtilities.saveFile(FILE_LOCAL_BLACKLIST, sb.toString(), "UTF-8", false);
    }

    public void attachLocalUdfs(boolean quietly) throws Exception
    {
        Set<String> filter = loadLocalFilter();

        printConsole("Loading local udfs ...");
        Set<Class> lstUdfClass = CellSourceFinder.scanUdf(CJavaConst.PATH_EXPORT_Src);
        Set<String> extSrcPaths = loadExtSrcPaths();
        for (String pathInPj : Nulls.get(extSrcPaths))
        {
            printConsole("Loading extend udf in path : " + pathInPj + " ...");
            lstUdfClass.addAll(CellSourceFinder.scanUdfInSrc(new File(pathInPj)));
        }

        // 再根据情况决定是否Attach到服务端
        if (!quietly && !CmnUtil.isObjectEmpty(lstUdfClass))
        {
            BapDebugSettingPanel filterPanel = new BapDebugSettingPanel();
            filterPanel.showDdfs(lstUdfClass, filter);
            JSimpleDialog dlg = GuiUtil.createSimpleDialog(filterPanel, null, true);
            dlg.setTitle("Set Debug Filter For UDF");
            dlg.setIconImage(GuiResource.getImage("dev/function.png"));
            dlg.pack();
            GuiUtil.centerWindow(dlg);
            if (!dlg.showTopModel(true))
                throw new UserCancelException();

            // 现存过滤屏蔽设定到本地文件
            Set<String> setFilter = filterPanel.getFilterFromGui();
            saveLocalFilter(setFilter);

            Set<Class> setEnable = filterPanel.getEnabledCells();
            lstUdfClass = setEnable;
        }

        // 筛选后注册到远端
        if (lstUdfClass != null)
            for (Class clsUdf : lstUdfClass)
            {
                if (CmnUtil.isInheritFrom(clsUdf, BasicUdf.class))
                {
                    UdfMeta meta = CUdfUtil.tryLoadUdfMeta(clsUdf); // 尽量通过javassist获取（依赖Eclipse打开了参数信息的开关）
                    CodeMeta extMeta = CJavaUtil.getCodeMetaFromLoader(clsUdf.getClassLoader(), clsUdf.getName());
                    if (extMeta != null)
                        CUdfUtil.mergeMeta(meta, extMeta);

                    CellClientFactory.getMe().attachBuilderToServer(new UdfInvokerCellBuilder(clsUdf, meta));
                    printConsole("Attach local source code UDF to server : " + clsUdf);
                }
            }
    }

    public static void printConsole(String msg)
    {
        CmnUtil.out(msg);
    }

    // quietly 静默模式，则不会弹出过滤器设定，也不能对某个cell进行独立配置，默认全接管
    public void attachLocalCells(URI serverUri, boolean quietly) throws Exception
    {
        Set<String> filter = loadLocalFilter();
        Set<String> localBlacklist = loadLocalBlacklist(); // 本地CELL黑名单，本地CELL永不生效
        Map<String, String> confProp = ConfigFactory.loadConfigProps();

        // 本地源码CELL列表
        printConsole("Loading local cells ...");
        Set<Class> localSrcCells = CellSourceFinder.scanImplement(CJavaConst.PATH_EXPORT_Src);
        Set<String> extSrcPaths = loadExtSrcPaths();
        for (String pathInPj : Nulls.get(extSrcPaths))
        {
            printConsole("Loading extend cells in path : " + pathInPj + " ...");
            localSrcCells.addAll(CellSourceFinder.scanImplementInSrc(new File(pathInPj)));
        }

        Map<String, CellConfig> mapConf = new HashMap<String, CellConfig>();
        for (Class cls : localSrcCells)
        {
            CellConfig dftConf = ConfigFactory.buildDefaultConfig(cls);
            if (dftConf != null)
            {
                if (ConfigFactory.assembleConfig(dftConf, confProp))
                    mapConf.put(cls.getName(), dftConf);
            }
        }

        // 再根据情况决定是否Attach到服务端
        Set<String> setBlacklist = localBlacklist;
        Set<Class> guiAttach = localSrcCells;
        if (!quietly && !CmnUtil.isObjectEmpty(localSrcCells))
        {
            BapDebugSettingPanel filterPanel = new BapDebugSettingPanel();
            filterPanel.showCells(localSrcCells, filter, localBlacklist, mapConf);
            JSimpleDialog dlg = GuiUtil.createSimpleDialog(filterPanel, null, true);
            dlg.setTitle("Set Debug Filter For Cells. Server=" + serverUri);
            dlg.setIconImage(GuiResource.getImage("bap/cell16.png"));
            dlg.pack();
            GuiUtil.centerWindow(dlg);
            if (!dlg.showTopModel(true))
                throw new UserCancelException();

            // 现存过滤屏蔽设定到本地文件
            Set<String> setFilter = filterPanel.getFilterFromGui();
            saveLocalFilter(setFilter);

            setBlacklist = filterPanel.getLocalBlacklistFromGui();
            saveLocalBlacklist(setBlacklist);

            Map<String, CellConfig> confData = filterPanel.getConfigFromGui();
            if (!CmnUtil.isObjectEmpty(confData))
                ConfigFactory.saveConfigFile(confData);

            guiAttach = filterPanel.getEnabledCells();
        }

        /* 第一轮注册本地源码CELL */
        for (Class clsCell : localSrcCells)
        {
            if (setBlacklist.contains(clsCell.getName())) // 黑名单屏蔽本地cell注册
                continue;

            if (clsCell.isInterface())
            {
                CellClientFactory.getMe().registLocalBuilder(new EmptyCellBuilder(clsCell));
            }
        }

        // 注册本地源码的实现类（本地调用直接生效）到本地Factory，这样就有机会覆盖上一轮的空接口
        for (Class clsCell : localSrcCells)
        {
            if (setBlacklist.contains(clsCell.getName())) // 黑名单屏蔽本地cell注册
                continue;

            if (clsCell.isInterface())
                continue;
            Class intf = CallbackUtil.getCallbackInterface(clsCell);
            if (!CmnUtil.isInheritFrom(intf, CellIntf.class))
                continue;

            CellClientFactory.getMe().registLocalCell(intf, clsCell);
        }

        /* 第二轮注册接管云端的：界面选择接管的CELL */

        // 处理并注册Builder
        Map<String, CellBuilderIntf> mapBuilder = new HashMap();
        for (Class clsCell : guiAttach)
        {
            if (setBlacklist.contains(clsCell.getName()))
                continue;

            if (clsCell.isInterface())
            {
                if (!CmnUtil.isInheritFrom(clsCell, CellIntf.class))
                    continue;

                mapBuilder.put(clsCell.getName(), new EmptyCellBuilder(clsCell));
            }
        }

        // 注册管云端的CELL实现，这样就有机会覆盖上一轮的空接口
        for (Class clsCell : guiAttach)
        {
            if (localBlacklist != null && localBlacklist.contains(clsCell.getName()))
                continue;

            if (!clsCell.isInterface())
            {
                Class intf = CallbackUtil.getCallbackInterface(clsCell);
                if (!CmnUtil.isInheritFrom(intf, CellIntf.class))
                    continue;

                mapBuilder.put(intf.getName(), new SimpleCellBuilder(intf, clsCell));
            }
        }

        // 去重以后，注册到远端
        for (CellBuilderIntf builder : mapBuilder.values())
        {
            CellClientFactory.getMe().attachBuilderToServer(builder);
            printConsole("Attach local source code cell to server : " + builder);
        }
    }

    // 专用于挂接一些本地调试用的临时cell，一般不需要
    public void attachTempCellsToRemote() throws Exception
    {
        // 默认没有
        for (Pair<Class, Class> p : _locaTempCells)
            CellClientFactory.getMe().attachCellToServer(p.getKey(), p.getValue());
    }

    // 专用于挂接一些本地调试用的临时cell，例如某次调试专门需要临时挂接的接口（一般只用于测试）
    protected List<Pair<Class, Class>> _locaTempCells = new LinkedList();

    public void registLocalTempCells(Class intfCls, Class implCls)
    {
        _locaTempCells.add(new Pair(intfCls, implCls));
    }

    public static void initLocalNioPort(DevConf conf) throws Exception
    {
        JBapDebugLocalNioSetting panel = new JBapDebugLocalNioSetting();
        panel.showConf(conf);
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, null, true);
        dlg.setIconImage(GuiUtil.getIcon("bap/cell16.png").getImage());
        dlg.setTitle("Local Debug Setting");
        dlg.pack();
        if (!dlg.showModel(true))
            return;

        int port = panel.getLocalNioPort();
        conf.setLocalNioPort(port);

        // 存盘配置
        BapDebugUtil.saveConfig(conf, ToolUtilities.getCurrentDirectory());

        if (port > 0)
        {
            printConsole("Start local NIO service");
            MppContext.setProperty(CRpcServer.CONF_NIO_PORT, conf.getLocalNioPort());
            new CRpcStarter().start();

            // 对外提供CELL服务（本地Tester需要连过来）
            CRpcServer.registService(ServerCellService.class, CellClientFactory.getMe());
        }
    }

    public static void disableJPluginAgent()
    {
        try
        {
            Class cls = ClassFactory.loadClass("com.leavay.dfc.mgr.javaDev.JPluginAgentMgr");
            ToolUtilities.callFunction(cls, "setEnable", false);
        } catch (Throwable err)
        {
            // ignore
        }
    }

    public static void main(String[] args)
    {

        try
        {
            disableJPluginAgent();

            GuiUtil.setLookAndFeel_JDK6();

            BapDebugger dbg = new BapDebugger();

            if (CmnUtil.getObjectSize(args) >= 1)
            {
                // 启动参数传入URI
                String uri = args[0];
                dbg.start(false, new URI(uri), false);
            } else
            {
                // 加载本地配置URI
                DevConf conf = BapDebugUtil.loadConfigIfexist(ToolUtilities.getCurrentDirectory());
                if (conf == null)
                    dbg.startGui(false, CWsUtil.buildURI("localhost", 2020), false);
                else
                {
                    dbg.start(false, conf.getURIForDebug(), false);

                    initLocalNioPort(conf);
                }
            }
        } catch (UserCancelException cancel)
        {
            System.exit(0);
        } catch (Throwable exp)
        {
            DetailErrorMsg.showError(exp);
            System.exit(0);
        }
    }
}
