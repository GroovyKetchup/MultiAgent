package bap.debug;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.BasicUdf;
import bap.cells.Cells;
import bap.java.CJavaConst;
import bap.java.CJavaUtil;
import cell.CellIntf;
import cell.UdfIntf;

public class CellSourceFinder
{

    public static Set<Class> scanImplement(String pjPath)
    {
        Set<Class> setRet = new HashSet<Class>();

        File flSrc = new File(pjPath);
        if (!flSrc.exists() || !flSrc.isDirectory())
            return setRet;

        File[] folders = flSrc.listFiles();
        if (folders == null)
            return setRet;

        // 扫描源码目录
        for (File fd : folders)
        {
            setRet.addAll(scanImplementInSrc(fd));
        }
        return setRet;
    }

    // 传入的是真正的源码目录(而不是工程目录), 工程目录和真实源码目录之间还隔着一层(云工程里的Folder)
    public static Set<Class> scanImplementInSrc(File srcFolder)
    {
        Set<Class> setRet = new HashSet<Class>();
        File fCell = new File(srcFolder.getAbsolutePath(), Cells.CELL_PACKAGE);
        if (!fCell.exists() || !fCell.isDirectory())
            return setRet;

        List<File> lstCellFiles = ToolUtilities.getAllChildFileObject(fCell);
        for (File f : lstCellFiles)
        {
            if (!f.isFile() || !CJavaUtil.isJavaFile(f.getName()))
                continue;

            try
            {
                String relPath = ToolUtilities.getRelatedPath(f.getAbsolutePath(), srcFolder.getAbsolutePath());
                String className = LvJavac.getMainClassFromFileName(relPath);
                Class cls = ClassFactory.loadClass(className);
                if (CmnUtil.isInheritFrom(cls, CellIntf.class))
                {
                    setRet.add(cls);
                }
            } catch (Throwable err)
            {
                CmnUtil.err("Failed to analysis local source code : " + f.getAbsolutePath());
                err.printStackTrace();
            }
        }

        return setRet;
    }

    public static Set<Class> scanUdf(String path)
    {
      Set<Class> setRet = new HashSet<Class>();
        
        File flSrc = new File(CJavaConst.PATH_EXPORT_Src);
        if (!flSrc.exists() || !flSrc.isDirectory())
            return setRet;
        
        File[] folders = flSrc.listFiles();
        if (folders == null)
            return setRet;

        // 扫描源码目录
        for (File fd : folders)
        {
            setRet.addAll(scanUdfInSrc(fd));
        }
        return setRet;
    }
    
    // 传入的是真正的源码目录(而不是工程目录), 工程目录和真实源码目录之间还隔着一层(云工程里的Folder)
    public static Set<Class> scanUdfInSrc(File srcFolder)
    {
        Set<Class> setRet = new HashSet<Class>();

        File fdUdf = new File(srcFolder.getAbsolutePath(), UdfIntf.PACKAGE_PREFIX);
        if (!fdUdf.exists() || !fdUdf.isDirectory())
            return setRet;

        List<File> lstUdfFiles = ToolUtilities.getAllChildFileObject(fdUdf);
        for (File f : lstUdfFiles)
        {
            if (!f.isFile() || !CJavaUtil.isJavaFile(f.getName()))
                continue;

            try
            {
                String relPath = ToolUtilities.getRelatedPath(f.getAbsolutePath(), srcFolder.getAbsolutePath());
                String className = LvJavac.getMainClassFromFileName(relPath);
                Class cls = ClassFactory.loadClass(className);
                if (CmnUtil.isInheritFrom(cls, BasicUdf.class))
                {
                    setRet.add(cls);
                }
            } catch (Throwable err)
            {
                CmnUtil.err("Failed to analysis local source code : " + f.getAbsolutePath());
                err.printStackTrace();
            }
        }

        return setRet;
    }
}
