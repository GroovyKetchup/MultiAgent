package bap.debug;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.dom4j.Element;

import com.cdao.model.type.Password;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import bap.client.BapMainFrame;
import bap.debug.gui.DevConf;
import bap.java.CJavaConst;

public class BapDebugUtil
{
    public static DevConf loadConfigIfexist(String projectPath) throws Exception
    {
        try
        {
            return loadConfig(projectPath);
        }catch (FileNotFoundException ioExp)
        {
            return null;
        }
    }
    
    public static DevConf loadConfig(String projectPath) throws Exception
    {
        String xml = null;
        try
        {
            xml = ToolUtilities.readFileUtf8(projectPath+"/"+CJavaConst.PROJECT_DEVELOP_CONF_FILE);
        } catch (FileNotFoundException noFile)
        {
            return null;
        }
        
        Element eleRoot = ToolUtilities.xmlString2Element(xml);
        DevConf conf = new DevConf();
        conf.setProject(eleRoot.attributeValue("Project"));
        
        String uri = ToolUtilities.getString(eleRoot.attributeValue("Uri"), null);
        if (CmnUtil.isStringEmpty(uri))
        {
            conf.setUri(CmnUtil.buildWsUri(eleRoot.attributeValue("Host"), ToolBasic.getInteger(eleRoot.attributeValue("Port"))).toString());
        }else
        {
            conf.setUri(uri);
        }
        
        String debugUri = ToolUtilities.getString(eleRoot.attributeValue("DebugUri"), null);
        conf.setDebugUri(debugUri);

        conf.setAdminTool(ToolUtilities.getString(eleRoot.attributeValue("AdminTool"), BapMainFrame.class.getName()));
        conf.setUser(eleRoot.attributeValue("User"));
        conf.setPwd(Password.decode(eleRoot.attributeValue("Password")));
        
        int localNioPort = ToolUtilities.getInteger(eleRoot.attributeValue("LocalNioPort"), -1);
        conf.setLocalNioPort(localNioPort);
        
        return conf;
    }

    public static void saveConfig(DevConf conf, String projectPath) throws IOException
    {
        String path = projectPath+"/"+CJavaConst.PROJECT_DEVELOP_CONF_FILE;
        String s = saveConfig(conf);
        
        ToolUtilities.saveFileUtf8(path, s, false);
    }
    
    public static String saveConfig(DevConf conf) throws IOException
    {
        Element eleRoot = ToolUtilities.newDom4jRoot("Development");
        eleRoot.setAttributeValue("Project", conf.getProject());
        eleRoot.setAttributeValue("Uri", conf.getUri());
        eleRoot.setAttributeValue("DebugUri", conf.getDebugUri());
        eleRoot.setAttributeValue("AdminTool", conf.getAdminTool());
        eleRoot.setAttributeValue("User", conf.getUser());
        eleRoot.setAttributeValue("Password", conf.getPwd());

        eleRoot.setAttributeValue("LocalNioPort", ""+conf.getLocalNioPort());
        
        return ToolUtilities.XML_UTF8_HEADER+"\n"+ToolUtilities.xmlDom4j2String(eleRoot);
    }
}
