package bap.debug;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.leavay.client.util.MBox;
import com.leavay.common.util.ToolUtilities;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.project.gui.common.component.JTextField_Integer;

import bap.debug.gui.DevConf;

public class JBapDebugLocalNioSetting extends JPanel
{

    JCheckBox jChk = new JCheckBox("Enable/Disable local service on port : ");
    JTextField_Integer jTxt = new JTextField_Integer();
    
    public JBapDebugLocalNioSetting()
    {
        Box box = Box.createVerticalBox();
        
        jChk.setFocusable(false);
        jChk.addActionListener(new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                updateVisible();
            }
        });
        
        GuiUtil.setFocuseSelectAll(jTxt);
        GuiUtil.invokeLater(()->jTxt.grabFocus());
        GuiUtil.addKeyAdapterToComponent(new KeyAdapter()
        {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    JSimpleDialog dlg = GuiUtil.getParent(JBapDebugLocalNioSetting.this, JSimpleDialog.class);
                    if (dlg != null)
                        dlg.OnBtnOK();
                }
            }
        }, jTxt);
       
        
        box.add(MBox.VGlue());
        box.add(MBox.hBar(22, jChk));
        box.add(MBox.VGlue());
        box.add(MBox.hBar(22, MBox.HStrut(35), jTxt));
        box.add(MBox.VGlue());
        box.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        GuiUtil.setGridLayout(this, box);
        this.setPreferredSize(new Dimension(400, 120));
        updateVisible();
    }
    
    public void updateVisible()
    {
        jTxt.setVisible(jChk.isSelected());
        if (jChk.isVisible())
        {
            Integer i = jTxt.getValueInteger();
            if (i == null || i<=0)
                jTxt.setText(DevConf.DefaultLocalPort+"");
        }
        GuiUtil.updateUILater(this);
    }
    
    public void showConf(DevConf conf)
    {
        if (conf.getLocalNioPort() > 0)
        {
            jChk.setSelected(true);
            jTxt.setText(""+conf.getLocalNioPort());
        }else
        {
            jChk.setSelected(false);
            jTxt.setText("-1");
        }
        
        updateVisible();
    }
    
    public int getLocalNioPort()
    {
        if (jChk.isSelected())
        {
            return ToolUtilities.getInteger(jTxt.getValueInteger(), -1);
        }else
            return -1;
    }
    
    
}
