package bap.debug.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.swing.Box;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.DocumentEvent;
import javax.swing.table.DefaultTableCellRenderer;

import com.leavay.client.util.MBox;
import com.leavay.common.util.SortButtonRenderer;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CallbackUtil;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.project.gui.common.JWaitDialog;
import com.project.gui.common.component.JTextField_Hint;
import com.project.gui.common.component.TableCE_CheckBox;
import com.project.gui.common.component.TableCR_CheckBox;

import bap.cells.CellClientFactory;
import bap.cells.CellConfig;
import bap.cells.RmtCellBuilderInfo;
import bap.cells.annotation.Config;
import bap.client.BapGuiUtil;

public class BapDebugSettingPanel extends JPanel implements ActionAdapter
{

    static final int COL_CLASS = 0;

    static final int COL_ENABLE = 1;
    
    static final int COL_LOCAL_BLACKLIST = 2;

    static final int COL_CONFIG = 3;


    static final int COL_STATUS = 4;

    SortableModel _model = new SortableModel()
    {
        public boolean isCellEditable(int row, int column)
        {
            if (column == COL_CONFIG)
            {
                Class cls = (Class) _model.getValueAt(row, COL_CLASS);
                if (cls != null && cls.getAnnotation(Config.class) != null)
                    return true;
                return false;
            }

            return column == COL_ENABLE || column == COL_LOCAL_BLACKLIST;
        }
    };

    public class TableCR_Status extends DefaultTableCellRenderer
    {
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
        {
            final Color green = new Color(160, 255, 160, 128);
            final Color red = new Color(255, 160, 160, 128);
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (value != null)
            {
                setBackground(red);
                if (value instanceof Throwable)
                {
                    setText(ToolUtilities.getExceptionMessage((Throwable) value));
                } else if (value instanceof RmtCellBuilderInfo)
                {
                    setText(value+"");
                } else
                    setText("Unknown Client");
            }else
            {
                setBackground(green);
                setText("Available");
            }

            return this;
        }
    }

    JTable jTbl = new JTable(_model);

    JTextField_Hint jTxtFilter = new JTextField_Hint(BapGuiUtil.getString("Filter Class Name"));

    JButton jBtnSelectAll = GuiUtil.createButton(BapGuiUtil.getString("Attach All"), null, this);

    JButton jBtnDeselectAll = GuiUtil.createButton(BapGuiUtil.getString("Clear Selection"), null, this);
    
    JButton jBtnKickout = GuiUtil.createButton(BapGuiUtil.getString("Kick Out"), null, this);
    JButton jBtnKickoutForce = GuiUtil.createButton(BapGuiUtil.getString("Force Kick Out"), "GuiEntry/waning.png", this);

    class CE_Config extends DefaultCellEditor
    {
        JButton jBtn = new JButton("...");

        public CE_Config()
        {
            super(new JComboBox());

            jBtn.addActionListener(new ActionAdapter()
            {
                public void OnAction(ActionEvent e) throws Exception
                {
                    BapConfigPanel panel = new BapConfigPanel();
                    panel.showData(_cellClass, _conf);
                    JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, getParent());
                    dlg.pack();
                    if (dlg.showTopModel(true))
                    {
                        _conf = panel.getDataFromGui();
                    }
                }
            });
        }

        Class _cellClass;

        CellConfig _conf;

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
        {
            _conf = (CellConfig) value;
            _cellClass = (Class) table.getModel().getValueAt(row, COL_CLASS);

            return jBtn;
        }

        public Object getCellEditorValue()
        {
            return _conf;
        }
    }

    public BapDebugSettingPanel()
    {
        _model.addColumn(BapGuiUtil.getString("Local Cell"));
        _model.addColumn(BapGuiUtil.getString("Attach To Server"));
        _model.addColumn(BapGuiUtil.getString("Local Blacklist"));
        _model.addColumn(BapGuiUtil.getString("Config"));
        _model.addColumn(BapGuiUtil.getString("Attached By"));
        jTbl.setRowHeight(25);
        jTbl.setToolTipText(ToolUtilities.textToHtml(BapGuiUtil.getString("BapDebugSettingHelp")));

        GuiUtil.setCellRenderer(jTbl, COL_ENABLE, new TableCR_CheckBox());
        GuiUtil.setCellEditor(jTbl, COL_ENABLE, new TableCE_CheckBox());
        GuiUtil.setTableColumnMaxWidth(jTbl, COL_ENABLE, 100);
        
        GuiUtil.setCellEditor(jTbl, COL_CONFIG, new CE_Config());
        GuiUtil.setTableColumnMaxWidth(jTbl, COL_CONFIG, 100);
        
        GuiUtil.setCellRenderer(jTbl, COL_LOCAL_BLACKLIST, new TableCR_CheckBox());
        GuiUtil.setCellEditor(jTbl, COL_LOCAL_BLACKLIST, new TableCE_CheckBox());
        GuiUtil.setTableColumnMaxWidth(jTbl, COL_LOCAL_BLACKLIST, 100);
        
        GuiUtil.setCellRenderer(jTbl, COL_STATUS, new TableCR_Status());

        jTbl.addKeyListener(new KeyAdapter()
        {

            public void keyPressed(KeyEvent e)
            {
                if (e.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    JSimpleDialog pDlg = GuiUtil.getParent(BapDebugSettingPanel.this, JSimpleDialog.class);
                    if (pDlg != null)
                    {
                        e.consume();

                        pDlg.OnBtnOK();
                    }
                }
            }

            public void keyReleased(KeyEvent e)
            {
                if (e.getKeyCode() == KeyEvent.VK_SPACE)
                    OnKeySpace();
            }
        });

        SortButtonRenderer.setHeaderQuietly(jTbl);

        // 过滤器设定
        jTxtFilter.setIcon(GuiResource.getImage("search_16.png"));
        GuiUtil.setFocuseSelectAll(jTxtFilter);
        GuiUtil.addDocumentListener(jTxtFilter, (DocumentEvent e) -> onFilter());
        jTxtFilter.setMinimumSize(new Dimension(150, 22));

        Box mainBox = Box.createVerticalBox();
        mainBox.add(MBox.createHBar(22, jTxtFilter, jBtnSelectAll, jBtnDeselectAll, MBox.HGlue(), jBtnKickout, jBtnKickoutForce));
//        jBtnKickoff.setVisible(false);
        mainBox.add(new JScrollPane(jTbl));

        GuiUtil.setGridLayout(this, mainBox);
        setPreferredSize(new Dimension(1100, 450));
    }

    public void refreshRemoteInfo()
    {
        try
        {
            Map<String, Object> mapRet = CellClientFactory.getMe().queryRemoteBuilder();

            for (int i = 0; i < _model.getRowCount(); i++)
            {
                Class cls = (Class) _model.getValueAt(i, COL_CLASS);
                Class intf = null;
                if (cls.isInterface())
                    intf = cls;
                else
                    intf = CallbackUtil.getCallbackInterface(cls);

                Object info = mapRet.get(intf.getName());
                _model.setValueAt(info, i, COL_STATUS);
            }
        } catch (Throwable err)
        {
            err.printStackTrace();
        }
    }
    
    public Set<Class> getCheckedRow()
    {
        GuiUtil.stopTableEditor(jTbl);

        Set<Class> setSel = new HashSet();
        for (int i = 0; i < _model.getRowCount(); i++)
        {
            boolean enable = ToolUtilities.getBoolean(_model.getValueAt(i, COL_ENABLE), false);
            if (enable)
                setSel.add(((Class) _model.getValueAt(i, COL_CLASS)));
        }

        return setSel;
    }

    
    public void onKickout(boolean forceKick) throws Exception
    {
        Set<Class> selRows = getCheckedRow();
        if (selRows == null)
            return;
        
        for (Class cls : selRows)
        {
            Class intf = null;
            if (cls.isInterface())
                intf = cls;
            else
                intf = CallbackUtil.getCallbackInterface(cls);
            
            doKickout(intf, forceKick);
        }
        
        refreshRemoteInfo();
    }
    
    public boolean doKickout(final Class intf, boolean forceKick)
    {
        return JWaitDialog.showWaitDialog("Apply to kick out other user : " + intf, this, ()->{
            try
            {
                CellClientFactory.getMe().kickoutRemoteBuilder(intf.getName(), forceKick);
            } catch (Exception exp)
            {
                ToolUtilities.throwRuntimeException(exp);
            }
            return true;
        });
    }

    public void onFilter()
    {
        String sFilter = CmnUtil.getString(jTxtFilter.getText(), "").trim().toLowerCase();

        int rowHeight = 24;
        for (int i = 0; i < _model.getRowCount(); i++)
        {
            Class cls = (Class) _model.getValueAt(i, COL_CLASS);
            if (!sFilter.isEmpty() && cls.getName().toLowerCase().indexOf(sFilter) < 0)
            {
                try
                {
                    GuiUtil.unsafeHideTableRow(jTbl, i);
                } catch (Exception exp)
                {
                    exp.printStackTrace();
                }
            } else
                jTbl.setRowHeight(i, rowHeight);
//            jTbl.setRowHeight(i, rowHeight);
        }
    }

    // 可见的行设置
    public void setAllSelection(boolean select)
    {
        for (int i = 0; i < _model.getRowCount(); i++)
        {
            if (jTbl.getRowHeight(i) > 0)
                _model.setValueAt(select, i, COL_ENABLE);
        }
    }

    public void showCells(Set<Class> lstCells, Set<String> filter, Set<String> localBlacklist, Map<String, CellConfig> mapConf)
    {
        for (Class cls : lstCells)
        {
            boolean disable = filter == null ? false : filter.contains(cls.getName());
            boolean attach = !disable;
            boolean inBlacklist = localBlacklist == null? false : localBlacklist.contains(cls.getName());
            
            _model.addRow(new Object[] { cls, attach, inBlacklist, mapConf == null ? null : mapConf.get(cls.getName()) });
        }

        GuiUtil.adjustTableColumnWidth(jTbl, 300, false);

        try
        {
            _model.sortColumnData(COL_CLASS, SortButtonRenderer.UP);
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }

        refreshRemoteInfo();
    }

    public void showDdfs(Set<Class> lstCells, Set<String> filter)
    {
        for (Class cls : lstCells)
        {
            boolean disable = filter == null ? false : filter.contains(cls.getName());
            _model.addRow(new Object[] { cls, !disable });
        }

        GuiUtil.adjustTableColumnWidth(jTbl, 300, false);

        // 当用于UDF时，无配置选项
        jTbl.removeColumn(jTbl.getColumnModel().getColumn(COL_CONFIG));

        try
        {
            _model.sortColumnData(COL_CLASS, SortButtonRenderer.UP);
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }

        refreshRemoteInfo();
    }

    // 获取的是Filter，也就是禁用的列表
    public Set<String> getFilterFromGui()
    {
        GuiUtil.stopTableEditor(jTbl);

        Set<String> setFilter = new HashSet();
        for (int i = 0; i < _model.getRowCount(); i++)
        {
            boolean enable = ToolUtilities.getBoolean(_model.getValueAt(i, COL_ENABLE), false);
            if (!enable)
                setFilter.add(((Class) _model.getValueAt(i, COL_CLASS)).getName());
        }

        return setFilter;
    }
    
    public Set<Class> getEnabledCells()
    {
        Set<Class> setCls = new HashSet<Class>();
        for (int i = 0; i < _model.getRowCount(); i++)
        {
            boolean enable = ToolUtilities.getBoolean(_model.getValueAt(i, COL_ENABLE), false);
            if (enable)
                setCls.add((Class) _model.getValueAt(i, COL_CLASS));
        }
        return setCls;
    }
    
    public Set<String> getLocalBlacklistFromGui()
    {
        GuiUtil.stopTableEditor(jTbl);

        Set<String> set = new HashSet();
        for (int i = 0; i < _model.getRowCount(); i++)
        {
            boolean select = ToolUtilities.getBoolean(_model.getValueAt(i, COL_LOCAL_BLACKLIST), false);
            if (select)
                set.add(((Class) _model.getValueAt(i, COL_CLASS)).getName());
        }

        return set;
    }

    public Map<String, CellConfig> getConfigFromGui()
    {
        GuiUtil.stopTableEditor(jTbl);

        Map<String, CellConfig> mapConf = new HashMap<String, CellConfig>();
        for (int i = 0; i < _model.getRowCount(); i++)
        {
            Class cellClass = (Class) _model.getValueAt(i, COL_CLASS);
            CellConfig cfg = (CellConfig) _model.getValueAt(i, COL_CONFIG);
            if (cfg == null)
                continue;

            mapConf.put(cellClass.getName(), cfg);
        }

        return mapConf;
    }

    public void OnKeySpace()
    {
        int[] rows = jTbl.getSelectedRows();
        if (CmnUtil.isObjectEmpty(rows))
            return;

        boolean firstEnable = ToolUtilities.getBoolean(_model.getValueAt(rows[0], COL_ENABLE), false);

        for (int i : rows)
        {
            if (jTbl.getRowHeight(i) <= 0)
                continue;

            if (false)
                _model.setValueAt(!firstEnable, i, COL_ENABLE);
            GuiUtil.invokeLater(_model, "setValueAt", !firstEnable, i, COL_ENABLE);
        }
    }

    @Override
    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jBtnSelectAll)
            setAllSelection(true);
        else if (e.getSource() == jBtnDeselectAll)
            setAllSelection(false);
        else if (e.getSource() == jBtnKickout)
            onKickout(false);
        else if (e.getSource() == jBtnKickoutForce)
            onKickout(true);
    }
}
