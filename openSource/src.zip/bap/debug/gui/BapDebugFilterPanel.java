package bap.debug.gui;

import java.awt.Dimension;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.project.gui.common.component.TableCE_CheckBox;
import com.project.gui.common.component.TableCR_CheckBox;

public class BapDebugFilterPanel extends JPanel
{
    SortableModel _model = new SortableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return column == COL_ENABLE;
        }
    };
           
    JTable jTbl = new JTable(_model);

    static final int COL_CLASS= 0;
    static final int COL_ENABLE = 1;
    
    public BapDebugFilterPanel()
    {
        _model.addColumn("Local Cell");
        _model.addColumn("Enable Debug");
        
        GuiUtil.setCellRenderer(jTbl, COL_ENABLE, new TableCR_CheckBox());
        GuiUtil.setCellEditor(jTbl, COL_ENABLE, new TableCE_CheckBox());
        
        jTbl.addKeyListener(new KeyAdapter()
        {

            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    JSimpleDialog pDlg = GuiUtil.getParent(BapDebugFilterPanel.this, JSimpleDialog.class);
                    if (pDlg != null)
                    {
                        e.consume();
                        
                        pDlg.OnBtnOK();
                    }
                }
            }
            public void keyReleased(KeyEvent e) {
                
                if (e.getKeyCode() == KeyEvent.VK_SPACE)
                    OnKeySpace();
            }
        });
        
        GuiUtil.setGridLayout(this, new JScrollPane(jTbl));
        setPreferredSize(new Dimension(640, 450));
    }
    
    public void showData(Set<Class> lstCells, Set<String> filter)
    {
        for (Class cls : lstCells)
        {
            boolean disable = filter==null?false:filter.contains(cls.getName());
            _model.addRow(new Object[] {cls, !disable});
        }
    }

    public Set<Class> getEnabledCells()
    {
        Set<Class> setCls = new HashSet<Class>();
        for (int i=0;i<_model.getRowCount();i++)
        {
            boolean enable = ToolUtilities.getBoolean(_model.getValueAt(i, COL_ENABLE), false);
            if (enable)
                setCls.add((Class) _model.getValueAt(i,  COL_CLASS));
        }
        return setCls;
    }
    
    // 获取的是Filter，也就是禁用的列表
    public Set<String> getFilterFromGui()
    {
        Set<String> setFilter = new HashSet();
        for (int i=0;i<_model.getRowCount();i++)
        {
            boolean enable = ToolUtilities.getBoolean(_model.getValueAt(i, COL_ENABLE), false);
            if (!enable)
                setFilter.add(((Class) _model.getValueAt(i,  COL_CLASS)).getName());
        }
        
        return setFilter;
    }
    
    public void OnKeySpace()
    {
        int[] rows = jTbl.getSelectedRows();
        if (CmnUtil.isObjectEmpty(rows))
            return;
        
        
        boolean firstEnable = ToolUtilities.getBoolean(_model.getValueAt(rows[0], COL_ENABLE), false);
        
        for (int i : rows)
        {
            if (false) _model.setValueAt(!firstEnable, i, COL_ENABLE);
            GuiUtil.invokeLater(_model, "setValueAt", !firstEnable, i, COL_ENABLE);
        }
    }
}
