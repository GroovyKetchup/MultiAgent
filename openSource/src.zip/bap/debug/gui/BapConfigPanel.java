package bap.debug.gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.lang.reflect.Field;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

import com.leavay.client.util.MBox;
import com.leavay.common.util.SortButtonRenderer;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;

import bap.cells.CellConfig;
import bap.cells.ConfigFactory;

public class BapConfigPanel extends JPanel
{
    SortButtonRenderer.SortableModel model = new SortButtonRenderer.SortableModel(){
        public boolean isCellEditable(int row, int column)
        {
            return true;
        }
    };
    JTable jTable = new JTable(model);
    
    JCheckBox jChkEnable = new JCheckBox("Enable Local Config", false);

    public BapConfigPanel()
    {
        jbInit();
    }
    
    public void jbInit()
    {
        Box mainBox = Box.createVerticalBox();
        
        mainBox.add(MBox.hBar(22, jChkEnable, MBox.HGlue()));
        jChkEnable.addActionListener(new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                checkboxAction();
            }
        });
        
        Box boxCtx = Box.createVerticalBox();
        model.addColumn(GuiUtil.getString("Key"));
        model.addColumn(GuiUtil.getString("Value"));
        
        try
        {
            SortButtonRenderer.setHeader(jTable);
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }
        JScrollPane jScrTable = new JScrollPane(jTable);
        boxCtx.add(jScrTable);
        boxCtx.setBorder(BorderFactory.createTitledBorder(GuiUtil.getString("Configuration")));
        mainBox.add(boxCtx);
        
        this.setLayout(new GridLayout(1, 1));
        this.add(mainBox);
    }
    
    public void checkboxAction()
    {
        jTable.setEnabled(jChkEnable.isSelected());
    }
    
    TableModelListener tableChangeLsnr = new TableModelListener()
    {
        public void tableChanged(TableModelEvent e)
        {
            fireChanged();
        }
    };
    
    public void fireChanged()
    {
        
    }
    
    Class _cellClass;
    CellConfig _conf;
    
    public void showData(Class cellClass, CellConfig conf) throws Exception
    {
        _cellClass = cellClass;
        _conf = conf;
        model.removeTableModelListener(tableChangeLsnr);
        
        if (conf == null)
        {
            _conf = ConfigFactory.buildDefaultConfig(cellClass);
            jChkEnable.setSelected(false);
        } else
        {
            _conf = conf;
            jChkEnable.setSelected(true);
        }
        checkboxAction();
        
        if (_conf != null)
        {
            Field[] fs = _conf.getClass().getDeclaredFields();
            if (fs != null)
                for (Field f : fs)
                {
                    if (!ConfigFactory.isConfigField(f))
                        continue;
                    
                    String value = ToolUtilities.getString(ToolBasic.getFieldValue(_conf, f.getName()), "");
                    model.addRow(new Object[] {f.getName(), value});
                }
        }
        GuiUtil.adjustTableColumnWidth(jTable);
    }
    
    public CellConfig getDataFromGui() throws Exception
    {
        if (!jChkEnable.isSelected() || _conf == null)
            return null;
                
        GuiUtil.stopTableEditor(jTable);
        CellConfig conf = ToolBasic.clone(_conf);
        for (int i=0; i<model.getRowCount(); i++)
        {
            String key = (String) model.getValueAt(i, 0);
            String value = (String) model.getValueAt(i, 1);
            ConfigFactory.setValue(conf, ToolUtilities.getField(conf.getClass(), key), value);
        }
        return conf;
    }
}
