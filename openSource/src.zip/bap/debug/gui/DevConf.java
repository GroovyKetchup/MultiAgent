package bap.debug.gui;

import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;

import com.leavay.ms.tool.CmnUtil;

public class DevConf implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 1332764376399794053L;

    public final static int DefaultLocalPort = 3030;

    public String project;

    public String uri;
    
    // 此值一般都为空, 默认就以uri(主控)为调试目标
    // 但是当需要级联到本地调试器的时候, 则可以手工修改增加此配置, 使得联调实际是连到本地某进程上
    public String debugUri;

    public String user;

    public String pwd; // 密码明文

    public String adminTool; // 管理工具的启动类

    public int localNioPort = DefaultLocalPort;

    public String getProject()
    {
        return project;
    }

    public void setProject(String project)
    {
        this.project = project;
    }

    public String getUri()
    {
        return uri;
    }

    public void setUri(String uri)
    {
        this.uri = uri;
    }
    
    public String getDebugUri()
    {
        return debugUri;
    }

    public void setDebugUri(String debugUri)
    {
        this.debugUri = debugUri;
    }

    public void setAdminTool(String adminTool)
    {
        this.adminTool = adminTool;
    }

    public String getAdminTool()
    {
        return adminTool;
    }

    public String[] getLaunchParams() throws URISyntaxException
    {
        String[] p = new String[3];

        URI uri = getURI();
        if (uri == null)
            return p;

        p[0] = uri.getHost();
        if (CmnUtil.WSS.equalsIgnoreCase(uri.getScheme()))
            p[0] = CmnUtil.WSS + "://" + uri.getHost();

        p[1] = uri.getPort() + "";
        p[2] = CmnUtil.isStringEmpty(uri.getPath()) ? "\"\"" : uri.getPath();
        return p;
    }

    public void setURI(URI uri)
    {
        setUri(uri == null ? null : uri.toString());
    }

    public URI getURI() throws URISyntaxException
    {
        return new URI(getUri());
    }
    
    public URI getURIForDebug() throws URISyntaxException
    {
        if (!CmnUtil.isStringEmpty(getDebugUri(), true))
            return new URI(getDebugUri());
        else
            return new URI(getUri());
    }

    public String getUser()
    {
        return user;
    }

    public void setUser(String user)
    {
        this.user = user;
    }

    public String getPwd()
    {
        return pwd;
    }

    public void setPwd(String pwd)
    {
        this.pwd = pwd;
    }

    public int getLocalNioPort()
    {
        return localNioPort;
    }

    public void setLocalNioPort(int localNioPort)
    {
        this.localNioPort = localNioPort;
    }
    
    public URI getLocalUri() throws URISyntaxException
    {
        if (localNioPort <= 0)
            return null;
        
        return new URI("ws://127.0.0.1:"+localNioPort);
    }

    public String toString()
    {
        return getUri() + "(" + getUser() + ")";
    }
}
