package bap.debug.gui;

import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.RemoteException;

import com.cdao.mgr.CDaoUtil;
import com.cdao.mgr.CSession;
import com.leavay.ms.cmn.DtoIntf;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;

import bap.java.CJavaCenterIntf;

public class ProjectAgent implements DtoIntf
{
    protected String path = null;
    protected DevConf conf = null;
    protected CSession _session = null;
    
    protected CRpcClientWrapper<CJavaCenterIntf> _rmt;
    
    public ProjectAgent(String path, DevConf conf)
    {
        this.path = path;
        this.conf = conf;
    }
    
    public void connectAndLogin() throws Exception
    {
        if (_rmt != null)
            _rmt.shutdown();
        
        _rmt = new CRpcClientWrapper<CJavaCenterIntf>(CJavaCenterIntf.class, conf.getURI())
        {
            public CRpcAdapter getAdapter()
            {
                return CRpcAdapter.getInstance();
            }
        };

        try
        {
            getIntf().ping();
        } catch (Throwable err)
        {
            throw new Exception("Failed to connect server : " + conf, err);
        }

        try
        {
            _session = getIntf().login(conf.getUser(), conf.getPwd());
        } catch (Throwable err)
        {
            throw new Exception("Failed to login server witch " + conf.getUser(), err);
        }
        
    }
    
    public URI getUri() throws URISyntaxException
    {
        return conf.getURI();
    }

    public String getKey()
    {
        return getConf().getProject();
    }

    public String getPath()
    {
        return path;
    }

    public DevConf getConf()
    {
        return conf;
    }

    public void setConf(DevConf conf)
    {
        this.conf = conf;
    }
    
    public CJavaCenterIntf getIntf()
    {
        return _rmt.getIntf(true);
    }
    
    public boolean isConnected()
    {
        try
        {
            getIntf().ping();
            return true;
        } catch (Exception exp)
        {
            return false;
        }
    }
    
    public CSession getSession()
    {
        return _session;
    }
    
    public String getUserCode()
    {
        return _session==null?null:_session.getUserCode();
    }
    
    public void setToGlobalSession()
    {
        CDaoUtil.setGlobalSession(getSession());
    }
    
}
