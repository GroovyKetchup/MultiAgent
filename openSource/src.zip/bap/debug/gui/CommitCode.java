package bap.debug.gui;

import com.leavay.common.util.ToolBasic;

import bap.java.CJavaCode;

public class CommitCode extends CJavaCode
{
    private static final long serialVersionUID = 6475982670567240994L;

    String absPath;

    public CommitCode()
    {
        
    }
    
    public CommitCode(CJavaCode jCode, String absPath) throws Exception
    {
        ToolBasic.copyFields(jCode, this, false);
        setAbsPath(absPath);
    }
    
    public String getAbsPath()
    {
        return absPath;
    }

    public void setAbsPath(String absPath)
    {
        this.absPath = absPath;
    }
}
