package bap.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.cdao.model.type.Password;
import com.leavay.client.util.CNClientUtil;
import com.leavay.client.util.MBox;
import com.leavay.common.util.SJsonList;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.component.JTextField_Search;

public class BapLogonPanel extends JPanel
{
    public JComboBox<String> jCmb_URI = new JComboBox();
    public JTextField jTxt_User = new JTextField();
    public JPasswordField jTxt_Pwd = new JPasswordField();
    
    public JButton jBtn_login = new JButton(GuiUtil.getString("Log In"));
    public JButton jBtn_cancel = new JButton(GuiUtil.getString("Exit"));
    

    Box MoBox = Box.createVerticalBox();
    Box QoBox = Box.createVerticalBox();
    
    class LeftLabel extends JLabel
    {
        public LeftLabel(String sText)
        {
            super(sText);
            setPreferredSize(new Dimension(130, 22));
            setHorizontalAlignment(JLabel.RIGHT);
        }
    }
    
    public static String FILE_CACHE = ".login.cache";
    public static String CACHE_RECENT_URI = "recent_uri";
    public static String CACHE_URI = "uri";
    public static String CACHE_USER = "user";
    public static String CACHE_PWD = "pwd";
    public BapLogonPanel()
    {
        jbInit();
        
        loadFromFile();
    }
    
    public void loadFromFile()
    {
        try
        {
            Properties prop = ToolUtilities.readPropertyFile(FILE_CACHE);
            String cache = prop.getProperty(CACHE_URI);
            SJsonList lst = SJsonList.from(cache);
            if (CmnUtil.isObjectEmpty(lst))
                jCmb_URI.setSelectedItem("ws://localhost:2020");
            else
            {
                Collections.sort(lst);
                for (String s : lst)
                    jCmb_URI.addItem(s);
            }
            
            String recentUrl = prop.getProperty(CACHE_RECENT_URI);
            if (!CmnUtil.isObjectEmpty(recentUrl))
                jCmb_URI.setSelectedItem(recentUrl);
            
            jTxt_User.setText(ToolUtilities.getString(prop.getProperty(CACHE_USER), ""));
            
            String pwd = ToolUtilities.getString(prop.getProperty(CACHE_PWD), "");
            pwd = Password.decode(ToolBasic.hexCode2String(pwd));
            jTxt_Pwd.setText(pwd);
        } catch (Throwable exp)
        {
        }
    }
    
    public void saveFile()
    {
        try
        {
            Properties prop = new Properties();
            String currUrl = (String)jCmb_URI.getSelectedItem();
            Set<String> setAll = new HashSet<String>();
            setAll.add(currUrl);
            for (int i=0;i<jCmb_URI.getItemCount();i++)
                setAll.add(jCmb_URI.getItemAt(i));
            
            SJsonList lst = new SJsonList();
            lst.addAll(setAll);
            prop.setProperty(CACHE_RECENT_URI, currUrl);
            prop.setProperty(CACHE_URI, lst.toJson());
            prop.setProperty(CACHE_USER, jTxt_User.getText());
            
            String pwd = jTxt_Pwd.getText();
            pwd = ToolBasic.string2HexCode(Password.encode(pwd));
            prop.setProperty(CACHE_PWD, pwd);
            
            ToolUtilities.saveProperty(FILE_CACHE, prop);
        } catch (IOException exp)
        {
            exp.printStackTrace();
        }
    }
    

    public BapLogonPanel(URI uri)
    {
        this();
        jCmb_URI.setSelectedItem(uri==null?"ws://localhost:2020":(uri+""));
    }
    
    public void jbInit()
    {
        setOpaque(true);
        
        Box mainBox = Box.createVerticalBox();
        mainBox.setOpaque(false);
        jCmb_URI.setEditable(true);

//        Color c_border = new Color(35, 37, 47);
        Color c_border = Color.GRAY;
        GuiUtil.setFixedSize(jCmb_URI, 275, 18);
        jCmb_URI.setFont(new Font("Dialog", 0, 12));
        jCmb_URI.setBorder(BorderFactory.createLineBorder(c_border));
        
        GuiUtil.setFixedSize(jTxt_User, 140, 18);
        GuiUtil.setFixedSize(jTxt_Pwd, 128, 18);
        jTxt_User.setFont(new Font("Dialog", 0, 12));
        jTxt_Pwd.setFont(new Font("Dialog", 0, 12));
        jTxt_User.setBorder(BorderFactory.createLineBorder(c_border));
        jTxt_Pwd.setBorder(BorderFactory.createLineBorder(c_border));
        
        final Color labelColor = new Color(150, 150, 150);
        JLabel label1 = new JLabel(GuiUtil.getString("IP : Port")+"  ");
        label1.setFont(new Font("Dialog", Font.BOLD, 11));
        label1.setForeground(labelColor);
        
        JLabel label2 = new JLabel(GuiUtil.getString("User : Password")+"  ");
        label2.setFont(new Font("Dialog", Font.BOLD, 11));
        label2.setForeground(labelColor);
        
        GuiUtil.setFixedSize(jBtn_login, 80, 20);
        jBtn_login.setFont(new Font("Dialog", Font.BOLD, 11));
        jBtn_login.setForeground(new Color(80, 80, 140));

        GuiUtil.setFixedSize(jBtn_cancel, 80, 20);
        jBtn_cancel.setFont(new Font("Dialog", 0, 11));
        
        MoBox.add(MBox.VStrut(200));
        int iLeft = 345;
        MoBox.add(MBox.createHBar(17, MBox.HStrut(iLeft), label1));
        MoBox.add(MBox.createHBar(17, MBox.HStrut(iLeft), jCmb_URI, MBox.HStrut(15)));
        MoBox.add(MBox.VStrut(7));
        
        MoBox.add(MBox.createHBar(17, MBox.HStrut(iLeft), label2));
        MoBox.add(MBox.createHBar(17, MBox.HStrut(iLeft), jTxt_User, MBox.HStrut(2), new JLabel(":"), MBox.HStrut(2), jTxt_Pwd, MBox.HStrut(15)));
        MoBox.add(MBox.VStrut(20));
        MoBox.add(MBox.createHBar(16, MBox.HStrut(420), jBtn_login, MBox.HStrut(20), jBtn_cancel, MBox.HStrut(15)));
        MoBox.add(MBox.VStrut(5));
        
        mainBox.add(MBox.VStrut(15));
        mainBox.add(MoBox);
        mainBox.add(MBox.VStrut(15));
        
        if (isShowLastInfo())
        {
            jCmb_URI.setSelectedItem(CNClientUtil.getUri()+"");
            jTxt_User.setText(CNClientUtil.getUser());
            jTxt_Pwd.setText(CNClientUtil.getPassword());
        }
        
        GuiUtil.setFocuseSelectAll(jTxt_User);
        GuiUtil.setFocuseSelectAll(jTxt_Pwd);
        
        
        this.setLayout(new GridLayout(1,1));
        add(mainBox);
        this.setBorder(BorderFactory.createLineBorder(Color.black));
        
        jBtn_login.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {
                OnBtnLogin();
            }
        });
        jBtn_cancel.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {
                OnBtnCancel();
            }
        });
    }

    public static BapLogonPanel showLogonWindow(Component parent, BapLogonPanel lastPanel, boolean alwaysOnTop)
    {
        return showLogonWindow(parent, lastPanel, false, alwaysOnTop);
    }
    
    public void initConf(URI uri, String user, String pwd)
    {
        if (uri != null)
        {
            jCmb_URI.setSelectedItem(uri+"");
        }
        
        if (user != null)
            jTxt_User.setText(user);
        
        if (pwd != null)
            jTxt_Pwd.setText(pwd);
    }
    
    public static BapLogonPanel showLogonWindow(Component parent, BapLogonPanel lastPanel, boolean autoLogin, boolean alwaysOnTop)
    {
        BapLogonPanel logonPanel = new BapLogonPanel();
        if (lastPanel != null)
        {
            logonPanel.jCmb_URI.setSelectedItem(lastPanel.getUri()+"");
            logonPanel.jTxt_User.setText(lastPanel.getUser());
            logonPanel.jTxt_Pwd.setText(lastPanel.getPwd());
        }
        if (autoLogin)
            return logonPanel;
        
        JDialog dlg = null;
        if (parent != null)
        {
            Window p = GuiUtil.getWindowForComponent(parent);
            if (p instanceof Dialog)
                dlg = new JDialog((Dialog) p);
            else if (p instanceof Frame)
                dlg = new JDialog((Frame) p);
        }

        if (dlg == null)
            dlg = new JDialog();

        GuiUtil.addKeyAdapterToComponent(new ThisKeyAdapter(logonPanel), logonPanel, true);
        GuiUtil.setDialogUndecorated(dlg, true);
        
        if (alwaysOnTop)
            dlg.setAlwaysOnTop(alwaysOnTop);
        
        dlg.setResizable(false);
        dlg.setPreferredSize(new Dimension(640, 380));
        dlg.setContentPane(logonPanel);
        dlg.setModal(true);
        dlg.pack();
        GuiUtil.centerWindow(dlg);
        dlg.show(true);

        if (logonPanel._isOK)
            return logonPanel;
        else
            return null;
    }
    
    public URI getUri()
    {
        try
        {
            return CmnUtil.buildWsUri(""+jCmb_URI.getSelectedItem());
        } catch (URISyntaxException exp)
        {
            ToolUtilities.throwRuntimeException(exp);
            return null;
        }
    }
    
    public String getUser()
    {
        return jTxt_User.getText();
    }
    public String getPwd()
    {
        return jTxt_Pwd.getText();
    }
  
    static class ThisKeyAdapter extends KeyAdapter
    {
        BapLogonPanel _panel;
        ThisKeyAdapter(BapLogonPanel panel)
        {
            _panel = panel;
        }
        
        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ENTER)
            {
                e.consume();
                _panel.OnBtnLogin();
            }
            else if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
            {
                e.consume();
                _panel.OnBtnCancel();
            }
        }
    }
    protected boolean _isOK = false;
    public void OnBtnLogin()
    {
        saveFile();
        
        login();
    }
    
    public void login()
    {
        Dialog dlg = (Dialog) GuiUtil.getWindowForComponent(this);
        _isOK = true;
        dlg.setVisible(false);
    }

    public void OnBtnCancel()
    {
        Dialog dlg = (Dialog) GuiUtil.getWindowForComponent(this);
        _isOK = false;
        dlg.setVisible(false);
    }
    
    public boolean isOK()
    {
        return _isOK;
    }
    
    protected void paintComponent(Graphics g) 
    {
        Image img = GuiResource.getIcon("bap/background.png").getImage();
        try
        {
            File fl = new File(CNClientUtil.USER_LOGIN_FILE);
            if (fl.exists() && fl.canRead())
            {
                img = ImageIO.read(fl);
            }
        } catch (IOException exp)
        {
            exp.printStackTrace();
        }
        g.drawImage(img, 0, 0, null);
//        super.paintComponent(g);
    }
    
    public static String FILE_NO_INIT = "noinit";
    public boolean isShowLastInfo()
    {
        if (new File(FILE_NO_INIT).exists())
            return false;
        
        return true;
    }
}
