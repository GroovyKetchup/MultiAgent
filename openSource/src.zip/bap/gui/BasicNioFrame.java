package bap.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.net.URI;
import java.util.Properties;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import javax.swing.UIManager;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoUtil;
import com.cdao.mgr.CSession;
import com.cdao.model.CDoUser;
import com.leavay.client.util.CNClientUtil;
import com.leavay.client.util.MBox;
import com.leavay.client.util.EventQ.GuiEvent;
import com.leavay.common.Exception.UserCancelException;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.systemOut.MySystemOut;
import com.leavay.common.util.systemOut.MySystemOutMgr;
import com.leavay.dfc.SubjectView.gui.MainEditor.MainDevelopTabView;
import com.leavay.dfc.gui.AllGuiEvents;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.mgr.SourceKeyUtil;
import com.leavay.dfc.mgr.disCache.DCacheUtil;
import com.leavay.dfc.mgr.javaDev.JPluginAgentMgr;
import com.project.gui.MvelEditor.ide.JOutputPanel;
import com.project.gui.MvelEditor.ide.JOutputView;
import com.project.gui.common.DockMainFrame;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.vlsolutions.swing.docking.DockableState;
import com.vlsolutions.swing.docking.DockingConstants;

import bap.client.BapGuiUtil;

public class BasicNioFrame extends DockMainFrame
{

    public final static String ACT_CMD_VIEW_CONSOLE = ACT_CMD_VIEW_PREFIX + "CONSOLE";
    public final static String ACT_CMD_VIEW_MAIN_DEV_TAB_VIEW = ACT_CMD_VIEW_PREFIX + "MAIN_DEV_TAB_VIEW";

    public BasicNioFrame()
    {
        super();
        
        initAll();
        
        initGuiEvent();
    }
    

    public void OnPrintDebugConsole(GuiEvent evt)
    {
        String srcKey = evt.getString(0);
        String msg = evt.getString(1);
        int iMsgType = evt.getInt(2);
        boolean isActive = ToolUtilities.getBoolean(evt.getParam(3), false);

        printConsole(srcKey, msg, iMsgType);
        if (isActive)
        {
            JOutputView dftOutput = (JOutputView) openView(ACT_CMD_VIEW_CONSOLE);
            desktop.activateDockable(dftOutput);
        }
    }
    
    public void OnCloseDebugConsole(GuiEvent evt)
    {
        String srcKey = evt.getString(0);
        closeConsole(srcKey);
    }
    
    public void CanCloseDebugConsole(GuiEvent evt)
    {
        String srcKey = evt.getString(0);
        
        prepareCloseConsole(srcKey);
    }
    
    public void OnClearDebugConsole(GuiEvent evt)
    {
        String srcKey = evt.getString(0);
        
        clearConsole(srcKey);
    }
    
    public void OnPrintConsole(GuiEvent evt)
    {
        String msg = evt.getString(0);
        int iMsgType = evt.getInt(1);
        printConsole(msg, iMsgType);
    }
    
    protected void initGuiEvent()
    {
        BapGuiUtil.addListener(AllGuiEvents.PRINT_DEBUG_CONSOLE, this, "OnPrintDebugConsole");
        
        BapGuiUtil.addListener(AllGuiEvents.CLOSE_DEBUG_CONSOLE, this, "OnCloseDebugConsole");
        
        BapGuiUtil.addListener(AllGuiEvents.CAN_CLOSE_DEBUG_CONSOLE, this, "CanCloseDebugConsole");
        
        BapGuiUtil.addListener(AllGuiEvents.CLEAR_DEBUG_CONSOLE, this, "OnClearDebugConsole");
        
        BapGuiUtil.addListener(AllGuiEvents.PRINT_CONSOLE, this, "OnPrintConsole");
    }
    
    public void actionPerformed(ActionEvent e)
    {
        try
        {
            OnAction(e);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(this, exp);
        }
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if (ACT_CMD_LAYOUT_LOAD_DEFAULT.equals(e.getActionCommand()))
            loadDefaultLayout();
    }
    
    public boolean OnPostProcessKeyEvent(KeyEvent e)
    {
        return false;
    }

    public String getDefaultLookFeel()
    {
        return "com.jtattoo.plaf.aero.AeroLookAndFeel";
    }

    protected void initMainPanel(String sLayout)
    {
        desktop.addDockable(openView(ACT_CMD_VIEW_MAIN_DEV_TAB_VIEW));

        desktop.split(openView(ACT_CMD_VIEW_MAIN_DEV_TAB_VIEW), openView(ACT_CMD_VIEW_CONSOLE),
                DockingConstants.SPLIT_BOTTOM, (double) 0.75f);
    }

    protected void initViews() throws Exception
    {
        registView(ACT_CMD_VIEW_MAIN_DEV_TAB_VIEW, MainDevelopTabView.class, "dfc/info_edit.png");

        registView(ACT_CMD_VIEW_CONSOLE, DevOuputView.class, "com/ide/console.png");
    }

    protected void initMenuBar()
    {
        _menuBar = new JMenuBar();

        // File
        initMenu_File(_menuBar);

        // Tools
        initMenu_Tools(_menuBar);
    }

    public JMenu initMenu_File(JMenuBar bar)
    {
        JMenu menuFile = new JMenu(getString("File"));
        bar.add(menuFile);
        
        JMenuItem saveLayout = new JMenuItem(getString("Save My Layout"));
        saveLayout.setActionCommand(ACT_CMD_LAYOUT_SAVE);
        saveLayout.addActionListener(this);
        JMenuItem loadLayout = new JMenuItem(getString("Load My Layout"));
        loadLayout.setActionCommand(ACT_CMD_LAYOUT_LOAD);
        loadLayout.addActionListener(this);

        JMenuItem resetLayout = new JMenuItem(getString("Load Default Layout"));
        resetLayout.setActionCommand(ACT_CMD_LAYOUT_LOAD_DEFAULT);
        resetLayout.addActionListener(this);

        JMenuItem relogon = new JMenuItem(getString("Relogon"), GuiResource.getIcon("logout_16.png"));
        relogon.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
//                try
//                {
//                    relogon();
//                } catch (Exception exp)
//                {
//                    DetailErrorMsg.showError(MallMainFrame.this, exp);
//                }
            }
        });
        
        menuFile.add(saveLayout);
        menuFile.add(loadLayout);
        menuFile.add(resetLayout);
        menuFile.addSeparator();
        menuFile.add(relogon);
        JMenuItem mitemExit = new JMenuItem(getString("Exit"), GuiResource.getIcon("exit_16.png"));
        mitemExit.setActionCommand(ACT_CMD_EXIT);
        mitemExit.addActionListener(this);
        menuFile.add(mitemExit);
        
        return menuFile;
    }
    
    
    protected void initToolBar()
    {
        
    }

    protected void initStatusBar()
    {
        
    }

    public String getString(String s)
    {
        return s;
    }
    
    public JMenu initMenu_Tools(JMenuBar bar)
    {
        JMenu jToolMenu = new JMenu(getString("Tool"));
        bar.add(jToolMenu); 
   
        return jToolMenu;
    }
    
    public static void main(String[] args) throws Exception
    {
        JPluginAgentMgr.setEnable(false);
        UIManager.setLookAndFeel("com.jtattoo.plaf.aero.AeroLookAndFeel");
        
//        DBDatasource ds = new DBDatasource();
//        ds.setDriverClass("org.postgresql.Driver");
//        ds.setUrl("jdbc:postgresql://127.0.0.1:5432/cdao");
//        ds.setUserName("dfc");
//        ds.setPassword("dfc");
//        ds.setMinConns(2);
//        ds.setMaxConns(10);
//        CDaoMgr.getMe().init(ds);
        System.out.println(ToolUtilities.logString(System.getProperties(), true));
        
        CNClientUtil.setBEHost("127.0.0.1");
        CNClientUtil.setNioPort(10088);
//        CNClientUtil.setNioPort(13000);
        
        logon();

        BasicNioFrame frm = new BasicNioFrame();
        frm.showMainFrame();
    }
    
    public static boolean logon()
    {
        BapLogonPanel panel = null;
        for (;;)
        {
            try
            {
                panel = BapLogonPanel.showLogonWindow(CNClientUtil.getTopoWindow(), panel, false);
                if (panel == null || !panel.isOK())
                    return false;

                _logon(panel.getUri(), panel.getUser(), panel.getPwd());
                return true;
            } catch (UserCancelException cancel)
            {
                return false;
            } catch (Throwable err)
            {
                DetailErrorMsg.showError(err);
                continue;
            }
        }
//        KeyPair<String, Integer> kp = JConnectPanel.showDialog(CNClientUtil.getTopoWindow(), CNClientUtil.getBEHost(), CNClientUtil.getNioPort());
//        if (kp == null)
//            return false;
//        
//        String host = kp.getKey();
//        int port = kp.getValue();
//        
//        DCacheUtil.setAsClient();
//        CNClientUtil.setBEHost(host);
//        CNClientUtil.setNioPort(port);
//        
//        CDaoClient.getMe().initGuiClient(host, port).init();
//        return true;
    }
    public static boolean logon(URI uri, String user, String pwd)
    {
        try
        {
            _logon(uri, user, pwd);
            return true;
        } catch (UserCancelException cancel)
        {
            return false;
        } catch (Throwable err)
        {
            DetailErrorMsg.showError(err);
            return false;
        }
    }
        
    public static void _logon(URI uri, String user, String pwd) throws Exception
    {
        CDaoClient.getMe().initGuiClient(uri).init();
        CDoUser userDo = CDaoClient.loginWithUser(user, pwd);
        CDaoUtil.setGlobalSession(new CSession(userDo));

        DCacheUtil.setAsClient();
        CNClientUtil.setUri(uri);
    }
    
    public void showMainFrame() throws Exception
    {
        redirectIOStreams();
        
        setTitle(""+CNClientUtil.getUri());
        
        CNClientUtil.setTopoWindow(this);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(1400, 800)); //原来的1440-968在Mac机上会很大，这里适当调小
        pack();
        GuiUtil.centerWindow(this);
        setVisible(true);
    }
    

    protected static volatile boolean _printStdOut = false;
    public static void redirectIOStreams()
    {
        MySystemOut out = new MySystemOut(1, 20*1000*1000, true,GuiUtil.GUI_OUTPUT_PATH, GuiUtil.GUI_OUTPUT_FILE, MySystemOutMgr.systemOutName)
        {
            protected void printExt(String s, boolean newLine)
            {
                if (_printStdOut)
                    dfcutil.fireAsyncGuiEvent(AllGuiEvents.PRINT_CONSOLE, s+ (newLine?"\n":""), JOutputPanel.MSG_TYPE_NORMAL);
            }
        };
        MySystemOut err = new MySystemOut(1, 20*1000*1000, true,GuiUtil.GUI_OUTPUT_PATH, GuiUtil.GUI_ERROR_FILE, MySystemOutMgr.systemErrName)
        {
            protected void printExt(String s, boolean newLine)
            {
                if (_printStdOut)
                    dfcutil.fireAsyncGuiEvent(AllGuiEvents.PRINT_CONSOLE, s+ (newLine?"\n":""), JOutputPanel.MSG_TYPE_ERROR);
            }
        };
    }
    

    public final static String SYSTEM_DEFAULT_CONSOLE = "_SYSTEM_DEFAULT_CONSOLE";
    static SimpleAttributeSet _dftOutputAttrSet = new SimpleAttributeSet();
    static {
        StyleConstants.setBold(_dftOutputAttrSet, false);
        StyleConstants.setFontSize(_dftOutputAttrSet, 12);
        StyleConstants.setForeground(_dftOutputAttrSet, Color.blue);
    }
    static SimpleAttributeSet _dftWarnAttrSet = new SimpleAttributeSet();
    static {
        StyleConstants.setBold(_dftWarnAttrSet, false);
        StyleConstants.setFontSize(_dftWarnAttrSet, 12);
        StyleConstants.setForeground(_dftWarnAttrSet, Color.ORANGE);
    }
    static SimpleAttributeSet _dftErrputAttrSet = new SimpleAttributeSet();
    static {
        StyleConstants.setBold(_dftErrputAttrSet, false);
        StyleConstants.setFontSize(_dftErrputAttrSet, 12);
        StyleConstants.setForeground(_dftErrputAttrSet, Color.red);
    }
    
    public void printConsole(String sMsg, int msgType)
    {
        printConsole(SYSTEM_DEFAULT_CONSOLE, sMsg, msgType);
    }
    
    protected void printConsole(String key, String sMsg, int msgType)
    {
        if(false) printConsoleUnsafe(key, sMsg, msgType);
        GuiUtil.invokeLater(this, "printConsoleUnsafe", key, sMsg, msgType);
    }
    
    public void printConsoleUnsafe(String key, String sMsg, int msgType)
    {
        JOutputView dftOutput = (JOutputView) openView(ACT_CMD_VIEW_CONSOLE);
        if (msgType == JOutputPanel.MSG_TYPE_ERROR || msgType == JOutputPanel.MSG_TYPE_WARNING)
            desktop.activateDockable(dftOutput);
        dftOutput.printOutput(key, sMsg, msgType);
    }
 
    protected void prepareCloseConsole(String key)
    {
        JOutputView dftOutput = (JOutputView) openView(ACT_CMD_VIEW_CONSOLE);
        dftOutput.prepareCloseConsole(key);
    }
    
    protected void closeConsole(String key)
    {
        JOutputView dftOutput = (JOutputView) getView(ACT_CMD_VIEW_CONSOLE);
        if (dftOutput != null)
            dftOutput.closeOutputPanel(key);
    }
    
    
    protected void clearConsole(String key)
    {
        JOutputView dftOutput = (JOutputView) openView(ACT_CMD_VIEW_CONSOLE);
        dftOutput.clearConsole(key);
    }
    
    public static class DevOuputView extends JOutputView
    {
        private static final long serialVersionUID = 2040634452090118900L;

        public JCheckBox jChk_StdOutput;

        public DevOuputView()
        {
            super(dfcutil.getInstance());

            getDockKey().setCloseEnabled(false);
            getDockKey().setShowTitleBar(false); // 根据TB意见，隐藏标题栏以节省空间
        }

        public void initLocalToolBar()
        {
            jChk_StdOutput = new JCheckBox(dfcutil.getString("Enable standard output"), false);
            jToolBar = MBox.createToolBar(20, MBox.HStrut(2), jLab_Titile, MBox.HGlue(), jChk_StdOutput, MBox.HStrut(2), MBox.HSeperator(), jBtn_Clear, MBox.HSeperator(), jBtn_PinConsole, jBtn_Switch, jBtn_Popup, MBox.HStrut(3));
            jChk_StdOutput.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    _printStdOut = jChk_StdOutput.isSelected();
                }
            });
        }
        
        public void setEnableOutput(boolean enable)
        {
            jChk_StdOutput.setSelected(enable);
            _printStdOut = enable;
        }

        public String getWindowTitle(String key)
        {
            if (key.equals(SYSTEM_DEFAULT_CONSOLE))
                return dfcutil.getString(key);
            else
            {
                String moName = SourceKeyUtil.getMoDesc(key);
                String actionName = SourceKeyUtil.getAttrDesc(key);
                if (!ToolUtilities.isStringEmpty(moName))
                    return dfcutil.getString("Debug Console") + " : " + moName + "." + actionName;
                else
                    return dfcutil.getString("Debug Console") + " : " + key;
            }
        }

        public void OnShowThis(DockableState newState)
        {
            super.OnShowThis(newState);

            dfcutil.setHasConsole(true);

            // 必须配合没有标题栏的情况下，需要自行增加最大化和恢复按钮
            JToolBar miniBar = getMiniTitleBar();
            if (miniBar != null)
                jToolBar.add(miniBar);
            jToolBar.revalidate();
        }

        public void OnHideOrClose(DockableState newState)
        {
            super.OnHideOrClose(newState);

            dfcutil.setHasConsole(false);
        }
    }

    protected Properties saveWindowInfoProp()
    {
        Properties prop = super.saveWindowInfoProp();
        
        return prop;
    }
    
}
