package bap.gui;

import javax.swing.ImageIcon;

import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.graph.base.DefaultCell;
import com.project.gui.common.GuiResource;

public abstract class ImageCell extends DefaultCell
{
    // 重载父类
    public void setValue(Object value)
    {
        this.value = value;
        
        autoChangeSize();
    }

    public void autoChangeSize()
    {
//        if (getValue() == null)
//            return;
//        
//        if (getGeometry() == null)
//            return;
//        
//        String s = ""+getValue();
//        if (getGeometry() != null)
//            getGeometry().setWidth(s.length() * 7);
    }
    
    public ImageCell()
    {
        super();
        
        initCellStyle(s_DefaultLayoutVertical);
    }
    
    public ImageCell(String sName)
    {
        super(sName);
        
        initCellStyle(s_DefaultLayoutVertical);
    }
    
    public void initCellStyle(boolean blVertical)
    {
        setVertex(true);

        String iconPath = getUserIcon();
        if (ToolUtilities.isStringEmpty(iconPath))
            iconPath = getImagePath(blVertical);
        
        ImageIcon icon = GuiResource.getIconWithFullPath(iconPath);
        if (icon != null)
        {
            final int max = 98;
            final int min = 12;
            int iconW = icon.getIconWidth();
            int iconH = icon.getIconHeight();
            
            if (getGeometry() != null)
            {
                if (icon.getIconWidth() > max)
                    getGeometry().setWidth(Math.min(max, iconW));
                else if (icon.getIconWidth() < min)
                    getGeometry().setWidth(Math.max(min, iconW));
                else
                    getGeometry().setWidth(iconW);
        
                if (icon.getIconHeight() > max)
                    getGeometry().setHeight(Math.min(max, iconH));
                else if (icon.getIconHeight() < min)
                    getGeometry().setHeight(Math.max(min, iconH));
                else
                    getGeometry().setHeight(iconH);
        //          getGeometry().setWidth(120);
        //        getGeometry().setHeight(20);
                autoChangeSize();
            }
        }
        
        setIcon(getImagePath(blVertical), blVertical);
    }
    
    public abstract String getImagePath(boolean blVertical);

    public String getUserIcon()
    {
        return _iconRes;
    }
    
    public void setUserIcon(String userIcon)
    {
        _iconRes = userIcon;
    }
    
    protected String _iconRes = null;
    public void setIcon(String sIconRes, boolean blVertical)
    {
//        setStyle("yellowVertex");
        if (blVertical)
            setStyle("imageH;image=/" + sIconRes + ";shape=image" );
        else
            setStyle("image;image=/"+sIconRes+";shape=image");
    }

    public abstract String getToolTip();
}
