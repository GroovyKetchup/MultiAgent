package bap.gui.store;

import javax.swing.JFrame;
import javax.swing.JPanel;

import com.leavay.common.nio.ws.CWsUtil;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiUtil;

import bap.client.BapClient;
import cell.bap.dev.store.IBapStore;

public class WaresPanel extends JPanel
{
    public WaresPanel() throws Exception
    {
        CmnUtil.err(IBapStore.get().queryWares());
        
        GuiUtil.setPreferredSize(this, 860, 800);
    }
    
    public static void main(String[] args) throws Exception
    {
        BapClient.getMe().init(CWsUtil.buildURI("localhost", 2020), false);
        
        WaresPanel p = new WaresPanel();
        JFrame frm = new JFrame();
        frm.setContentPane(p);
        frm.pack();
        GuiUtil.centerWindow(frm);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.setVisible(true);
    }
}
