package bap.plugin;

import java.io.Serializable;
import java.util.List;

public class CPluginExportPackage implements Serializable
{
    private static final long serialVersionUID = -1051676713180884931L;
    
    // 导出到插件前是否删除已有的（默认增量式导出）
    boolean deleteFirst = false;
    
    CPluginProjectDto project;
    List<CPluginJarDto> lstJars;
    
    // 可选（对老平台，此无意义）
    String javaProjectKey;

    public CPluginProjectDto getProject()
    {
        return project;
    }
    
    public String getProjectName()
    {
        return getProject()==null?null:getProject().getName();
    }

    public CPluginExportPackage setProject(CPluginProjectDto project)
    {
        this.project = project;
        return this;
    }

    public List<CPluginJarDto> getLstJars()
    {
        return lstJars;
    }

    public CPluginExportPackage setLstJars(List<CPluginJarDto> lstJars)
    {
        this.lstJars = lstJars;
        return this;
    }

    public String getJavaProjectKey()
    {
        return javaProjectKey;
    }

    public CPluginExportPackage setJavaProjectKey(String javaProjectKey)
    {
        this.javaProjectKey = javaProjectKey;
        return this;
    }

    public boolean isDeleteFirst()
    {
        return deleteFirst;
    }

    public void setDeleteFirst(boolean deleteFirst)
    {
        this.deleteFirst = deleteFirst;
    }
    
}
