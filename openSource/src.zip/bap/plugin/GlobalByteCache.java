package bap.plugin;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 主要用于新老插件交替时，缓存移交的场景
 * 当插件发布，老服务关闭，新服务启动，可利用此全局二进制Map移交缓存
 * 通过新老ClassLoader的序列化和反序列化，可规避类冲突的问题
 *
 *
 * 一定要小心取走时清理垃圾，否则容易内存泄漏
 */
public class GlobalByteCache extends ConcurrentHashMap<String, byte[]>
{
    private static final long serialVersionUID = -3754826270755404356L;
    
    public static GlobalByteCache _me = null;
    public synchronized static GlobalByteCache getMe()
    {
        if (_me == null)
        {
            _me = new GlobalByteCache();
        }
        return _me;
    }
    
    private GlobalByteCache()
    {
    }
    
    public byte[] pop(String key)
    {
        return remove(key);
    }
}
