package bap.plugin;

import com.cdao.dto.DaoNameDto;
import com.leavay.ms.tool.CmnUtil;

public class CPluginProjectDto extends DaoNameDto
{
    private static final long serialVersionUID = -7380062492461465881L;

    public Long timeTag;
    protected String initDaoClass()
    {
        return "bap.md.CPluginProject";
    }
    public long getTimeTag()
    {
        return CmnUtil.getLong(timeTag, -1);
    }
    public void setTimeTag(Long timeTag)
    {
        this.timeTag = timeTag;
    }
    
    public String toString()
    {
        if (getTimeTag() > 0)
            return CmnUtil.getNameAndLabel(getName(), CmnUtil.time2String(getTimeTag()));
        else
            return getName();
    }
}
