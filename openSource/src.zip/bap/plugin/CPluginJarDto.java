package bap.plugin;

import com.cdao.dto.DaoDto;
import com.leavay.ms.tool.CmnUtil;

public class CPluginJarDto extends DaoDto
{

    private static final long serialVersionUID = 1787258686451955980L;

    public String name;

    public Long size;

    public byte[] fileBin;

    public boolean privateOwn = false;
    
    protected String initDaoClass()
    {
        return "bap.md.CPluginJar";
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Long getSize()
    {
        return size;
    }

    public void setSize(Long size)
    {
        this.size = size;
    }


    public byte[] getFileBin()
    {
        return fileBin;
    }

    public void setFileBin(byte[] fileBin)
    {
        this.fileBin = fileBin;
        setSize(fileBin == null ? null : (long) fileBin.length);
    }

    public boolean isPrivateOwn()
    {
        return privateOwn;
    }

    public void setPrivateOwn(boolean privateOwn)
    {
        this.privateOwn = privateOwn;
    }

    public String toString()
    {
        return getName()+" ("+CmnUtil.fileSize2String(CmnUtil.getLong(getSize(),0))+")";
    }
}
