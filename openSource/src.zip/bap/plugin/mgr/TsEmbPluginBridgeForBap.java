package bap.plugin.mgr;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.locks.ReentrantLock;

import org.nutz.dao.Cnd;

import com.cdao.mgr.CDaoClient;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.ms.tool.CmnUtil;

import bap.md.CPluginProject;
import bap.plugin.CPluginExportPackage;
import bap.plugin.CPluginJarDto;
import bap.plugin.CPluginProjectDto;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import cmn.util.Nulls;
import tiny.service.cmn.TsConst;
import tiny.service.cmn.TsHelper;
import tiny.service.cmn.member.TsMember;

/**
 *  只运行在DAO次集群主控内，专门用于桥接上层TinyService集群的插件到本地插件库
 *  【集群首领不启动该服务】【非DAO次主控也不启动】
 *  
 *  通过RPC尝试访问上层Servant（或Chief）获取插件，然后转接到本地插件库中，作为待发布插件库的一个子工程（Casecade Service Common Package）
 *
 */
public class TsEmbPluginBridgeForBap
{
    public final static String LOG = "TsEmbPluginBridgeForDns";

    // NIO
    ReentrantLock _lockMo = new ReentrantLock();
        
    public static TsEmbPluginBridgeForBap _me=null;
    public synchronized static TsEmbPluginBridgeForBap get()
    {
        if (_me == null)
            _me = new TsEmbPluginBridgeForBap();
        return _me;
    }
    
    // 只有DAO次集群主控，才需要启动该类
    // 集群首领也不需要启动该服务
    public boolean tryStartService()
    {
        if (TsHelper.isChief())
            return false;
        if (!CDaoClient.getMe().isCenterServer())
            return false;

        _mainThread.start();
        ToolUtilities.info(LOG, "Plugin bridge for tiny service started!");
        return true;
    }
    
    
    Thread _mainThread = new Thread("Auto upgrade emb plugin"){
        public void run()
        {
            for (;;)
            {
                try
                {
                    checkAndUpgradePlugin_Offline();
                } catch (Throwable err)
                {
                    ToolUtilities.error(LOG, "Failed to contact center of upper cluster", err);
                }
                
                ToolUtilities.sleep(TsConst.getSyncServantInterval());
            }
        }
    };
    
    public void checkAndUpgradePlugin_Offline() throws Exception
    {
        long srvNewTag = TsMember.getPluginTag();
        
        if (srvNewTag != queryLocalTagID())
        {
            // 父集群插件发生变化，需要更新
            ToolUtilities.warnAndOutput(LOG, "Found new plugin from Tiny Service Cluster : " + ToolUtilities.time2String(srvNewTag));
            rebuildLocalPlugin(srvNewTag);
        }
    }
    
    public long queryLocalTagID() throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            CPluginProject pj = dao.queryDo(CPluginProject.class, Cnd.where(CPluginProject.Name, "=", TsConst.TINY_SERVICE_CLUSTER_PLUGIN), CPluginProject.TimeTag);
            if (pj != null)
                return CmnUtil.getLong(pj.getTimeTag(), -1);
        }
        
        return -1;
    }
    
    // 下载并桥接插件到本地插件库
    protected void rebuildLocalPlugin(long newTag) throws Exception
    {
        Map<String, byte[]> libFiles = TsMember.downloadPluginFromServant();
        List<CPluginJarDto> lstJars = new LinkedList<CPluginJarDto>();
        for (Entry<String, byte[]> ent : Nulls.get(libFiles).entrySet())
        {
            CPluginJarDto jar = new CPluginJarDto();
            jar.setName(ent.getKey());
            jar.setFileBin(ent.getValue());
            lstJars.add(jar);
        }

        CPluginProjectDto pluginProject = new CPluginProjectDto();
        pluginProject.setName(TsConst.TINY_SERVICE_CLUSTER_PLUGIN);
        pluginProject.setTimeTag(newTag);

        CPluginExportPackage pkg = new CPluginExportPackage();
        pkg.setProject(pluginProject);
        pkg.setLstJars(lstJars);
        
        boolean autoPublis = MppContext.getBoolean(TsConst.CONF_AUTO_PUBLISH_AFTER_UPGRADE_PLUGIN, TsConst.DEFAULT_AUTO_PUBLISH_PLUGIN);
        
        // CPluginCenter都会随Dao主控启动
        ClassFactory.exportPublishPlugin(pkg, autoPublis);
    }
}
