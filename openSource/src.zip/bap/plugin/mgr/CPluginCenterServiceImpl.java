package bap.plugin.mgr;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.cdao.mgr.CDaoUtil;

import bap.plugin.CPluginExportPackage;
import bap.plugin.CPluginJarDto;
import bap.plugin.CPluginProjectDto;
import bap.plugin.CPluginRootDto;
import cell.function.IBiConsumer;
import cplugin.ms.CPluginCenterService;

/**
 * 基于DAO主控的Plugin Center，完全从库里获取插件相关发布
 */
public class CPluginCenterServiceImpl implements CPluginCenterService
{

    public long getPluginTag() throws Exception
    {
        return CPluginCenter.getMe().getPluginTag();
    }

    public Map<String, byte[]> downloadPlugin(boolean onlyPublic, Collection<String> excludeNames) throws Exception
    {
        return CPluginCenter.getMe().downloadPlugin(onlyPublic, excludeNames);
    }

    public void streamDownloadPlugin(IBiConsumer<String, byte[]> consumer, boolean onlyPublic, Collection<String> excludeNames) throws Exception
    {
        CPluginCenter.getMe().streamDownloadPlugin(consumer, onlyPublic, excludeNames);
    }
    
    public void ping() throws RemoteException
    {
        
    }

    public long publish(boolean forceFully) throws Exception
    {
        return CPluginCenter.getMe().publish(forceFully);
    }

    public CPluginRootDto getRootDto() throws Exception
    {
        return CPluginCenter.getMe().getRootDto();
    }

    public List<CPluginProjectDto> getProjects() throws Exception
    {
        return CPluginCenter.getMe().getProjects();
    }

    public CPluginProjectDto createProject(String name) throws Exception
    {
        return CDaoUtil.convertDto(CPluginCenter.getMe().createProject(name), CPluginProjectDto.class);
    }

    public List<CPluginJarDto> getJars(String projectUuid, boolean withBin) throws Exception
    {
        return CPluginCenter.getMe().getJars(projectUuid, withBin);
    }

    public void uploadJar(String projectUuid, List<CPluginJarDto> lstJars, boolean clearAll) throws Exception
    {
        CPluginCenter.getMe().uploadJar(projectUuid, lstJars, clearAll);
    }

    public CPluginProjectDto exportPublishPlugin(CPluginExportPackage pkg, boolean publishNow) throws Exception
    {
        return CPluginCenter.getMe().exportPublishPlugin(pkg, publishNow);
    }

    @Override
    public void setRootDirty(String dirtyMessage) throws Exception
    {
        CPluginCenter.getMe().setRootDirty(dirtyMessage);
    }

}
