package bap.plugin.mgr;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

import org.nutz.dao.Cnd;
import org.nutz.dao.Sqls;
import org.nutz.dao.util.cri.Exps;
import org.nutz.dao.util.cri.SqlExpressionGroup;

import com.cdao.CDaoConst;
import com.cdao.impl.entity.field.GID;
import com.cdao.mgr.CDao;
import com.cdao.mgr.CDaoCenter;
import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoUtil;
import com.cdao.model.CDoBasic;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.mgr.javaDev.JPluginAgentMgr;
import com.leavay.dfc.microService.MsHelper;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcServer;

import bap.client.BapGuiUtil;
import bap.java.BapMgr;
import bap.md.CJarFile;
import bap.md.CPluginEmbRoot;
import bap.md.CPluginJar;
import bap.md.CPluginJarPublished;
import bap.md.CPluginProject;
import bap.md.CPluginRoot;
import bap.md.CellConfigDo;
import bap.ms.BasicPluginIntf;
import bap.plugin.CPluginEmbRootDto;
import bap.plugin.CPluginExportPackage;
import bap.plugin.CPluginJarDto;
import bap.plugin.CPluginProjectDto;
import bap.plugin.CPluginRootDto;
import cell.function.IBiConsumer;
import cmn.util.AutoLock;
import cmn.util.NullUtil;
import cplugin.ms.CPluginCenterService;
import ms.cmn.util.MD5Util;
import tiny.service.cmn.TsConst;

public class CPluginCenter extends BapMgr
{

    // 只锁发布动作以及全局唯一Root节点的初始化动作
    ReentrantLock _lockRoot = new ReentrantLock();
    CPluginRoot _root = null;
    
    private static CPluginCenter _me;
    public static synchronized CPluginCenter getMe()
    {
        if (_me == null)
        {
            _me = new CPluginCenter();
        }
        
        return _me;
    }
    
    protected CPluginCenter()
    {
    }
    
    public void start() throws Exception
    {
        getRoot();
        
        // 这个类是在DAO的主控上启动，但由于DAO支持了多主控，所以不一定也是微服务的集群主控，不可以用CPluginClient去接管插件
        // 在主控上，也需要插件客户端来接管Class Factory，以便插件在主控内也生效
        // 在微代理上，还需要桥接微服务集群的统一分发插件
        CPluginClient.getMe().initInDaoCenter();
        
        // 初次启动，公告当前插件Tag
        broadcastPluginTag(getPluginTag());
    }
    

    public boolean isSupportDelta() {
        return true;
    }
    
    public void initBeforeDao()
    {
        JPluginAgentMgr.setEnable(false);

        CRpcServer.registService(BasicPluginIntf.class.getName(), this);
        CRpcServer.registService(CPluginCenterService.class, new CPluginCenterServiceImpl());
        
        initDaoModel();
    }
    
    public static void initDaoModel()
    {
        CDaoCenter.addInitModel(CPluginJarPublished.class);
        CDaoCenter.addInitModel(CPluginRoot.class);
        CDaoCenter.addInitModel(CJarFile.class);
        CDaoCenter.addInitModel(CPluginJar.class);
        CDaoCenter.addInitModel(CPluginProject.class);
        CDaoCenter.addInitModel(CPluginEmbRoot.class);
        CDaoCenter.addInitModel(CellConfigDo.class);
    }
    
    public CPluginRoot getRoot() throws Exception
    {
        _lockRoot.lock();
        try
        {
            if (_root == null)
            {
                try (CDao dao = newDao())
                {
                    _root = (CPluginRoot) dao.getOrCreateSingleton(CPluginRoot.class);
                }
            }
            
            return _root;
        } finally
        {
            _lockRoot.unlock();
        }
    }

    public long publish(boolean forceFully) throws Exception
    {
//        if (true)
//            return publishFully();
        
        if (forceFully)
            return publishFully();
        else
            return publishDelta();
    }
    
    public void setRootDirty(String dirtyMessage) throws Exception
    {
        try (AutoLock lc = AutoLock.lock(_lockRoot))
        {
            try (CDao dao = newDao())
            {
                dao.updateDoField(getRoot().getGid(), CPluginRoot.DirtyFlag, true);
                dao.updateDoField(getRoot().getGid(), CPluginRoot.DirtyMessage, dirtyMessage);
                
                dao.commit();
                _root = (CPluginRoot) dao.queryDo(getRoot().getGid());
            }
        }
    }
    
    // 全量式发布版本，删除所有已发布，更新所有Jar的版本标签和总的版本标签
    public long publishFully() throws Exception
    {
        _lockRoot.lock();
        try
        {
            final CPluginRoot root = getRoot();
            long newTag;
            do
            {
                newTag = System.currentTimeMillis();
            }
            while (newTag == root.getTimeTag());
            
            try (final CDao dao = newDao())
            {
                // 删掉所有现存的
                dao.deleteDos(CPluginJarPublished.class.getName(), Cnd.where(CPluginJarPublished.MasterKey, "=", root.getUuid()));
                
                // 将jar包复制并挂到root下，并删除原有的
                List<CPluginJar> lstJarInfo = dao.queryDoList(CPluginJar.class, Cnd.where(CPluginJar.Owner, "=", getRoot().getUuid()), CDoBasic.UUID, CPluginJar.MasterKey, CPluginJar.Name, CPluginJar.FileMd5);
                lstJarInfo = removeConflictJar(dao, lstJarInfo);
                
                if (!ToolBasic.isObjectEmpty(lstJarInfo))
                {
                    SqlExpressionGroup exp = new SqlExpressionGroup();
                    List<String> uuids = new LinkedList<>();
                    for (CPluginJar jar : lstJarInfo)
                        uuids.add(jar.getUuid());
                    
                    exp.andInStrList(CDoBasic.UUID, uuids);

                    int dbCount = dao.count(CPluginJar.class, Cnd.where(exp));
                    AtomicLong realCount = new AtomicLong();
                    AtomicLong totalSize = new AtomicLong();
                    dao.streamQueryDoPage(CPluginJar.class, Cnd.where(exp), 1, (jar) -> {
                        try
                        {
                            CPluginJarPublished jarPub = new CPluginJarPublished();

                            jarPub.setOwner(null);
                            jarPub.setMaster(root.getGid(), CPluginRoot.JarFiles);
                            jarPub.setProjectClass(jar.getMasterClass());
                            jarPub.setProjectUuid(jar.getMasterKey());

                            jarPub.setPrivateOwn(jar.isPrivateOwn());
                            jarPub.setName(jar.getName());
                            jarPub.setFileBin(jar.getFileBin());
                            jarPub.setSize((long) jar.getFileBin().length);
                            jarPub.setFileMd5(MD5Util.encode(jar.getFileBin()));

                            dao.createDo(jarPub);

                            realCount.incrementAndGet();
                            totalSize.addAndGet(jarPub.getSize());
//                            System.err.println("C=>>"+jarPub.getName());
                        } catch (Exception exp1)
                        {
                            ToolUtilities.throwRuntimeException(exp1);
                        }
                    });
                    CmnUtil.assertTrue(realCount.get()==dbCount, "Failed to publish plugin with unmatched size : " +realCount+"<>"+dbCount);
                    ToolUtilities.infoAndOutput(CPluginCenter.class.getName(), "Publish Plugin Jars : " + realCount+ " - "+ToolUtilities.fileSize2String(totalSize.get()));
                    
//                    List<CPluginJar> lstJars = dao.queryDoList(CPluginJar.class, Cnd.where(exp));
//                    for (CPluginJar jar : lstJars)
//                    {
//                        CPluginJarPublished jarPub = new CPluginJarPublished();
//
//                        jarPub.setOwner(null);
//                        jarPub.setMaster(root.getGid(), CPluginRoot.JarFiles);
//                        jarPub.setProjectClass(jar.getMasterClass());
//                        jarPub.setProjectUuid(jar.getMasterKey());
//                        
//                        jarPub.setPrivateOwn(jar.isPrivateOwn());
//                        jarPub.setName(jar.getName());
//                        jarPub.setFileBin(jar.getFileBin());
//                        jarPub.setSize((long)jar.getFileBin().length);
//                        jarPub.setFileMd5(MD5Util.encode(jar.getFileBin()));
//                        dao.createDo(jarPub);
//                    }

                }
                
                // 修改Root的时间戳
                CPluginRoot newRoot = ToolBasic.clone(root);
                newRoot.setTimeTag(newTag);
                newRoot.setDirtyFlag(false);
                dao.updateDo(newRoot, CPluginRoot.TimeTag);
                
                // 提交并存本地缓存
                dao.commit();
                _root = newRoot;

                // 广播插件变更
                broadcastPluginTag(newTag);
            }
            
            return newTag;
        }finally
        {
            _lockRoot.unlock();
        }
    }
    
    // 通过比对、增量式发布差异的部分
    // 注意：插件那边每次编译产生的jar，byte流都会发生变化，md5也会变化，但这正好也是需要发布的新包（至于为啥代码没变化编译出来的东西有差异，这个不得而知了）
    public long publishDelta() throws Exception
    {
        _lockRoot.lock();
        try
        {
            CPluginRoot root = getRoot();
            long newTag;
            do
            {
                newTag = System.currentTimeMillis();
            }
            while (newTag == root.getTimeTag());
            
            try (CDao dao = newDao())
            {
                // 比对已发布和未发布，找出MD5变化的以及增删的列表，进行增量式发布
                Set<String> setDel = new HashSet();
                Set<String> setOverwrite = new HashSet();
                comparePublishDifferent(dao, setDel, setOverwrite);
                
                // 增量删除变化的或者多余的
                if (!CmnUtil.isObjectEmpty(setDel))
                {
                    SqlExpressionGroup delExp = new SqlExpressionGroup();
                    delExp.and(CPluginJarPublished.MasterKey, "=", root.getUuid());
                    delExp.andInStrArray(CPluginJarPublished.Name, ToolUtilities.list2Array(setDel, String.class));
                    dao.deleteDos(CPluginJarPublished.class.getName(), Cnd.where(delExp));
                }
                
                // 将jar包复制并挂到root下，并删除原有的
                if (!CmnUtil.isObjectEmpty(setOverwrite))
                {
                    SqlExpressionGroup exp = new SqlExpressionGroup();
                    exp.and(CPluginJar.Owner, "=", getRoot().getUuid());
                    exp.andInStrArray(CPluginJar.Name, ToolUtilities.list2Array(setOverwrite, String.class));
                    List<CPluginJar> lstJars = dao.queryDoList(CPluginJar.class, Cnd.where(exp));
                    
                    // 去除父主控和本地的冲突
                    lstJars = removeConflictJar(dao, lstJars); 
                    
                    for (CPluginJar jar : lstJars)
                    {
                        CPluginJarPublished jarPub = new CPluginJarPublished();
                        jarPub.setOwner(null);
                        jarPub.setMaster(root.getGid(), CPluginRoot.JarFiles);
                        jarPub.setName(jar.getName());
                        jarPub.setProjectClass(jar.getMasterClass());
                        jarPub.setProjectUuid(jar.getMasterKey());
                        jarPub.setPrivateOwn(jar.isPrivateOwn());
                        
                        jarPub.setFileBin(jar.getFileBin());
                        jarPub.setSize((long) jar.getFileBin().length);
                        jarPub.setFileMd5(getMd5(jar.getFileBin()));
                        dao.createDo(jarPub);
                    }
                }
                
                // 修改Root的时间戳
                root = ToolBasic.clone(root);
                root.setTimeTag(newTag);
                root.setDirtyFlag(false);
                dao.updateDo(root, CPluginRoot.TimeTag);

                // 提交并存本地缓存
                dao.commit();
                _root = root;

                // 广播插件变更
                broadcastPluginTag(newTag);
            }
            
            return newTag;
        }finally
        {
            _lockRoot.unlock();
        }
    }
    
    public static String getMd5(byte[] bt) throws Exception
    {
        return MD5Util.encode(bt);
    }
    
    /**
     * 在发布插件时，做重名jar冲突检查
     * 当存在桥接子系统时，需要判断来自父主控的插件中是否存在和本地重名冲突的jar
     * 如果有，则去除父主控的，保留本地的
     * 
     * 注意：传入的lstJars中必须包含uuid，name，owner，masterKey这几个关键字段
     */
    public List<CPluginJar> removeConflictJar(CDao dao, List<CPluginJar> lstJars) throws Exception
    {
        CPluginProject prjBridge = dao.queryDo(CPluginProject.class, Cnd.where(CPluginProject.Name, "=", TsConst.TINY_SERVICE_CLUSTER_PLUGIN));
        if (prjBridge == null)
            return lstJars;

        // name map
        Map<String, CPluginJar> mapJars = new HashMap<>();
        for (CPluginJar jar : lstJars)
        {
            CPluginJar exist = mapJars.get(jar.getName());
            if (exist == null)
            {
                mapJars.put(jar.getName(), jar);
            } else
            {
                if (prjBridge.getUuid().equals(exist.getMasterKey()))
                {
                    // 发现冲突，覆盖父主控的插件包
                    mapJars.put(jar.getName(), jar);
                    ToolUtilities.warnAndOutput(getClass().getSimpleName(), "Ignore conflict plugin jar from cluster master : " + jar.getName());
                } else if (prjBridge.getUuid().equals(jar.getMasterKey()))
                {
                    // 父主控的jar与本地发生冲突，自动忽略
                    ToolUtilities.warnAndOutput(getClass().getSimpleName(), "Ignore conflict plugin jar from cluster master : " + jar.getName());
                }else
                {
                    // 工程间的冲突，需特别记录报错日志，并随机忽略冲突
                    String pjName1 = ""+dao.queryFieldValue(GID.build(CPluginProject.class, jar.getMasterKey()), CPluginJar.Name);
                    String pjName2 = ""+dao.queryFieldValue(GID.build(CPluginProject.class, exist.getMasterKey()), CPluginJar.Name);
                    ToolUtilities.warnAndError(getClass().getSimpleName(), "Found conflict plugin jar : " + jar.getName() + ":" + pjName1 + "->" + pjName2);
                }
            }
        }
        
        return new LinkedList<CPluginJar>(mapJars.values());
    }
    
    // 依据新老文件的MD5码以及文件名，找出需要新增和删除（覆盖）的插件文件
    // 对于同名文件，如果MD5变化了，则同时存入setDel、setOverwrite中
    // 如果是已经不需要的，则存入setDel
    // 如果是完全新增的文件名，则存入setOverwrite
    public void comparePublishDifferent(CDao dao, Set<String> setDel, Set<String> setOverwrite) throws Exception
    {
        List<CPluginJar> nowMd5 = dao.queryDoList(CPluginJar.class, Cnd.where(CPluginJar.Owner, "=", getRoot().getUuid()), CDoBasic.UUID, CPluginJar.MasterKey, CPluginJar.Name, CPluginJar.FileMd5);
        
        // 去除父主控和本地的冲突。虽然这里是按名字+MD5比对，也要去除冲突的再比对
        nowMd5 = removeConflictJar(dao, nowMd5);
        
        List<CPluginJarPublished> oldMd5 = dao.queryDoList(CPluginJarPublished.class, Cnd.where(CPluginJarPublished.MasterKey, "=", getRoot().getUuid()), CPluginJarPublished.Name, CPluginJarPublished.FileMd5);
        
        // 找出老的里面需要被删除、或者被覆盖的，都存入setDel里
        // 如果找到同名，但MD5不同，则也加入setDel里删除，同时也要存入setOverwrite中
        if (oldMd5 != null)
            for (CPluginJarPublished old : oldMd5)
            {
                boolean foundInNow = false;
                if (nowMd5 != null)
                    for (CPluginJar now : nowMd5)
                    {
                        if (CmnUtil.isStringEqual(now.getName(), old.getName()))
                        {
                            foundInNow = true;
                            
                            if (!ToolUtilities.isStringEqual(now.getFileMd5(), old.getFileMd5()))
                            {
                                setDel.add(old.getName());
                                setOverwrite.add(old.getName());
                            }
                            break;
                        }
                    }
                
                // 新的里面没有
                if (!foundInNow)
                    setDel.add(old.getName());
            }
        
        //再找出纯新增的文件名
        if (nowMd5 != null)
            for (CPluginJar now : nowMd5)
            {
                boolean foundInOld =false;
                if (oldMd5 != null)
                    for (CPluginJarPublished old : oldMd5)
                    {
                        if (CmnUtil.isStringEqual(old.getName(), now.getName()))
                        {
                            foundInOld = true;
                            break;
                        }
                    }
                
                if (!foundInOld)
                    setOverwrite.add(now.getName());
            }
    }
    
    public void uploadJar(String projectUuid, List<CPluginJarDto> lstJars, boolean clearAll) throws Exception
    {
        try (CDao dao = newDao())
        {
            if (clearAll)
                dao.deleteDos(CPluginJar.class.getName(), Cnd.where(CPluginJar.MasterKey, "=", projectUuid));

            for (CPluginJarDto jarDto : NullUtil.get(lstJars))
            {
                int size = ToolUtilities.getObjectSize(jarDto.getFileBin());
                try
                {
                    CPluginJar jar = CDaoUtil.convertDo(jarDto);

                    // 无条件先把同名删掉，确保全局无重名
                    if (!clearAll)
                        dao.deleteDos(CPluginJar.class.getName(), Cnd.where(CPluginJar.Name, "=", jar.getName()));

                    jar.setOwner(getRoot().getUuid());
                    jar.setMaster(GID.build(CPluginProject.class, projectUuid), CPluginProject.JarFiles);

                    jar.setSize((long) jarDto.getFileBin().length);
                    jar.setFileMd5(getMd5(jarDto.getFileBin()));
                    jar = (CPluginJar) dao.createDo(jar);
                } catch (Throwable err)
                {
                    throw new Exception("Failed to create jar data : " + jarDto.getName() + "(" + ToolUtilities.fileSize2String(size) + ")", err);
                }
            }

            dao.commit();
        }
    }

    public void ping()
    {
         // 基本接口
    }

    public long getPluginTag() throws Exception
    {
        return getRoot().getTimeTag();
    }

    // 默认是所有jar都要
    public Map<String, byte[]> downloadPlugin() throws Exception
    {
        return downloadPlugin(false, null);
    }
    
    // excludeNames，需要排除的jar包名，如：test2_aaa.jar
    public Map<String, byte[]> downloadPlugin(boolean onlyPublic, Collection<String> excludeNames) throws Exception
    {
        try (CDao dao = newDao())
        {
            Cnd cnd = Cnd.where(CPluginJarPublished.MasterKey, "=", getRoot().getUuid());
            if (!CmnUtil.isObjectEmpty(excludeNames))
                cnd.and(Exps.inStr(CPluginJarPublished.Name, excludeNames).setNot(true));
            
            // 只返回非私有的
            if (onlyPublic)
                cnd.and(new SqlExpressionGroup().orIsNull(CPluginJarPublished.PrivateOwn).or(CPluginJarPublished.PrivateOwn, "=", false));
            
            Map<String, byte[]> mapRet = new HashMap<String, byte[]>();
            
            List<CPluginJarPublished> allJars = dao.queryDoList(CPluginJarPublished.class, cnd);
            for (CPluginJarPublished jar : allJars)
            {
                mapRet.put(jar.getName(), jar.getFileBin());
            }

            return mapRet;
        }
    }
    
    public void streamDownloadPlugin(IBiConsumer<String, byte[]> consumer, boolean onlyPublic, Collection<String> excludeNames) throws Exception
    {
        try (CDao dao = newDao())
        {
            Cnd cnd = Cnd.where(CPluginJarPublished.MasterKey, "=", getRoot().getUuid());
            if (!CmnUtil.isObjectEmpty(excludeNames))
                cnd.and(Exps.inStr(CPluginJarPublished.Name, excludeNames).setNot(true));
            
            // 只返回非私有的
            if (onlyPublic)
                cnd.and(new SqlExpressionGroup().orIsNull(CPluginJarPublished.PrivateOwn).or(CPluginJarPublished.PrivateOwn, "=", false));
            
            Map<String, byte[]> mapRet = new HashMap<String, byte[]>();
            
            dao.streamQueryDoPage(CPluginJarPublished.class, cnd, 1, (jar) -> {
                consumer.accept(jar.getName(), jar.getFileBin());
            });
        }
    }
    
    public List<CPluginProjectDto> getProjects() throws Exception
    {
        try(CDao dao = newDao())
        {
            List lstRet = new LinkedList();

            // 集成插件点
            if (MsHelper.isStarted() && MsHelper.isMember())
                lstRet.add(CDaoUtil.convertDto(CMsPluginBridge.getMe().getEmbRoot(), CPluginEmbRootDto.class));
            
            List lstOther = CDaoUtil.convertDtos((List)dao.queryDoList(CPluginProject.class, Cnd.where(CPluginProject.Owner, "=", getRoot().getUuid())), CPluginProjectDto.class);
            ToolUtilities.combineList(lstRet, lstOther);
            
            return lstRet;
        }
    }
    
    public CPluginProject queryProject(String name) throws Exception
    {
        try (CDao dao = newDao())
        {
            return dao.queryDo(CPluginProject.class, Cnd.where(CPluginProject.Name, "=", name));
        }
    }
    
    public List<CPluginJarDto> getJars(String projectUuid, boolean withBin) throws Exception
    {
        try(CDao dao = newDao())
        {
            String[] fields = withBin?null:CPluginJar.FIELDS_BRIEF;
            return CDaoUtil.convertDtos((List)dao.queryDoList(CPluginJar.class, Cnd.where(CPluginJar.MasterKey, "=", projectUuid), fields), CPluginJarDto.class);
        }
    }

    public CPluginRootDto getRootDto() throws Exception
    {
        return CDaoUtil.convertDto(getRoot(), CPluginRootDto.class, false);
    }

    public CPluginProject createProject(String name) throws Exception
    {
        CPluginProject pj = new CPluginProject();
        pj.setOwner(getRoot().getUuid());
        pj.setName(name);
        
        return (CPluginProject) CDaoClient.getIntf().createDo(pj);
    }

    public CPluginProjectDto exportPublishPlugin(CPluginExportPackage pkg, boolean publishNow) throws Exception
    {
        // 上传到插件工程（或者新建）
        CPluginProject existPj = queryProject(pkg.getProject().getName());
        
        // 是否要先删除
        if (existPj != null && pkg.isDeleteFirst())
        {
            CDaoClient.getIntf().deleteDo(existPj);
            existPj = null;
        }
        
        // 是否需要新建
        if (existPj == null)
        {
            existPj = createProject(pkg.getProject().getName());
        }

        // 如果时间戳变化，则更新
        if (Long.compare(pkg.getProject().getTimeTag(), CmnUtil.getLong(existPj.getTimeTag(), -1)) != 0)
        {
            existPj.setTimeTag(pkg.getProject().getTimeTag());
            CDaoClient.getIntf().updateField(existPj.getGid(), CPluginProject.TimeTag, existPj.getTimeTag());
        }
        
        uploadJar(existPj.getUuid(), pkg.getLstJars(), true);
        if (publishNow)
            existPj.setTimeTag(publish(false));
        else
        {
            // 灰度发布
            setRootDirty(BapGuiUtil.getString("There are some dirty files need to be published!"));
        }
        
        return CDaoUtil.convertDto(existPj, CPluginProjectDto.class);
    }
    
    public void broadcastPluginTag(long newTag)
    {
        CDaoClient.getMe().putCenterCache(CDaoConst.DAO_PLUGIN_TAG, newTag);
    }
    
    public String getLog()
    {
        return "CPlugin Center";
    }
}
