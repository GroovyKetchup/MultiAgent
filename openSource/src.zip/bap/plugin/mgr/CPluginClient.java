package bap.plugin.mgr;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.SrvRes;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassFactoryIntf;
import com.leavay.common.util.javac.CodeUtil;
import com.leavay.common.util.javac.CodeUtil.BasiceClassInfoLoader;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.PluginAgentIntf;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;
import com.leavay.nio.crpc.CRpcLocalWrapper;
import com.leavay.nio.crpc.NoServiceSupportException;

import bap.client.BapGuiUtil;
import bap.ms.BasicPluginIntf;
import bap.plugin.CPluginExportPackage;
import bap.plugin.CPluginProjectDto;
import cell.function.CBiConsumer;
import cmn.util.AutoLock;
import cplugin.ms.CPluginCenterService;
import ms.cmn.util.MD5Util;
import ms.cmn.util.TempFile;

// 新的插件更新客户端（可以在微代理上，也可以在客户端，也可以在微代理DAO次主控上）
/**
 * 作为BAP平台基础插件类工厂，在DAO模型的下一层（插件会依赖DAO模型），作为ClassFactory的总类工厂，类似DNS中的JPluginAgentMgr
 * 负责从后台（或数据库）获取jar并装载到类工厂（不参与微服务集群插件的接入或桥接）
 * 
 * 只会启动在两种模式下：
 *  1、在客户端启动（GUI或一些测试、云调试客户端），会连接后台插件主控，桥接到客户端CDaoClient中，同时接管整个ClassFactory
 *  2、在DAO主控内（微服务集群主控或者次集群主控都一样）启动，直接用进程内的插件服务，直接本地插件库的功能
 *      
 * 以下非本类功能，是其它相关模式的介绍：
 *      1、如果在DAO仆从，是通过CPluginFollower从DB直接下载插件库，直接更新到总ClassFactory
 *          因为DAO仆从会从DAO主控拿插件，而DAO主控会找微服务主控拿插件
 *      
 *      2、如果在DAO次集群主控内，其内部会自动启动TsEmbPluginBridgeForBap去桥接（RPC方式）上层集群插件到本地库，这里不进行此逻辑处理
 *          通过创建桥接插件工程（Cluster Plugin For Tiny Service）来容纳上级插件
 * 
 *      3、如果在DNS中，还是以JPluginAgentMgr为主，而JPluginAgentMgr内的basicLoader会被Dao热替换
 *          所以上层插件只能是通过创建MO（Casecade Service Common Package级联到现有插件库里，借用DNS本身的插件发布分发下去）
 *          在DNS中的类TsEmbPluginBridgeForDns通过RPC找微服务集群Servant（或首领）获取插件，并桥接到本地MO的插件库中
 * 
 * 主控端：
 *      _currentLoader(装载了插件） -> basic（空/Default Factory） -> dao
 *      插件更替导致整个_currentLoader替换，内部依然指向旧的basic和dao
 *      
 *      
 */
public class CPluginClient implements ClassFactoryIntf, PluginAgentIntf
{
    public final static String LOG = "CPluginClient";
    public final static String LIB_PLUGIN_ROOT = "lib_emb_plugin";
    public final static String LIB_PLUGIN_EXT_ROOT = "lib_emb_plugin_ext"; // 用来塞入一些手工扩展的jar包，以及调试时的临时jar包等
    public final static String PLUGIN_TAG_FILE = "PluginTagID.finish";
    public final static String PLUGIN_MD5_FILE = "PluginFiles.md5";

    public final static String TMP_DOWNLOAD = "cplugin_download";
    
    volatile boolean inClient = false;
    volatile boolean inDaoCenter = false;
    
    // Local Plugin
    ReentrantLock _lockDirty = new ReentrantLock();
    Map<Long, LvClassLoader> _dirtyLoader = new TreeMap<Long, LvClassLoader>();
    ReentrantLock _lockUpdate = new ReentrantLock();
    volatile Exception _lockStack = null;
    
    // NIO
    ReentrantLock _lockCenter = new ReentrantLock();
    CRpcAdapter _proxyAdapter = new CRpcAdapter();
    
    public final static long INVALID_TAG_ID = -1;
    static volatile long _currTagID = INVALID_TAG_ID;
    volatile LvClassLoader _currentLoader = null;
    volatile BasiceClassInfoLoader _currInfoLoader = null;
    
    public static CPluginClient _instance=null;
    public synchronized static CPluginClient getMe()
    {
        if (_instance == null)
            _instance = new CPluginClient();
        return _instance;
    }
    
    protected CPluginClient()
    {
        try
        {
            tryLoadExistLocal();
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }
        
        try
        {
            if (!ToolUtilities.deleteDir(new File("temp/"+TMP_DOWNLOAD)))
                ToolUtilities.warning("Failed to clean plugin temp download folder : " + TMP_DOWNLOAD);
        }catch (Throwable err)
        {
            ToolUtilities.error(LOG, "Failed to clean plugin temp download folder : " + TMP_DOWNLOAD, err);
        }
    }
    
    public BasiceClassInfoLoader getClassInfoLoader()
    {
        return _currInfoLoader;
    }
    
    public void tryLoadExistLocal() throws Exception
    {
        lockUpdate();
        try
        {
            long localTagID = getLocalTagID();
//            if (!isValidTagID(localTagID))
//                return;

            BasiceClassInfoLoader infoLoader = new BasiceClassInfoLoader();
            List<String> lstJars = getPluginJars(localTagID);
            LvClassLoader loader = new LvClassLoader().setName("Exist Plugin File Loader").replaceBasic(getBasicClassLoader());
            if (lstJars != null)
                for (String jarPath : lstJars)
                {
                    CodeUtil.ananyseClass(jarPath, infoLoader);
                    loader.addFilePath(jarPath);
                }

            replaceLoader(localTagID, loader, infoLoader);
        } finally
        {
            unlockUpdate();
        }
    }
    
    // 通常是在客户端启动初始化
    // startDeamonThread 通常就要启动，自动更新插件，并可能扫描cell
    public void initInClient(URI uri, boolean startAutoUpgradPlugin) throws Exception
    {
        inClient = true;
        
        // Init remote
        setAsClient(uri);
        
        // init Class Factory
        ClassFactory.setMe(this, this);
        
        if (startAutoUpgradPlugin)
            startService();
    }
    
    // 跟随DAO主控（大、小主控皆可能）启动
    public void initInDaoCenter() throws Exception
    {
        inDaoCenter = true;
        
        // init Class Factory
        ClassFactory.setMe(this, this);
        
        startService();
    }
    
    public boolean isInClient()
    {
        return inClient;
    }

    public boolean isInDaoCenter()
    {
        return inDaoCenter;
    }

    public void startService() throws Exception
    {
        // 启动时强行清理缓存的垃圾插件包
        try
        {
            cleanDirtyFolder();
        } catch (IOException exp)
        {
            ToolUtilities.error(exp);
        }
        
        if (!_mainThread.isAlive())
            _mainThread.start();
    }
    
    Thread _mainThread = new Thread("Auto upgrade emb plugin"){
        public void run()
        {
            boolean firstStart = true;
            int noServiceTime = 3;
            
            for (;;)
            {
                try
                {
                    boolean realReload = checkAndUpgradePlugin_Offline();
                    if (!realReload && firstStart)
                    {
                        // 如果是初次加载，且并未下载插件（可能版本无变化等），则需要主动触发一次CELL分析
                        ClassFactory.dispatchAfterLoaded(getLocalTagID());
                    }

                    tryCleanDirtyLoader();
                    
                } catch (NoServiceSupportException noService)
                {
                    // 无服务很可能因为后台是DNS平台或者其它没有CPluginCenter的进程（非BAP）
                    // 且不是通讯故障
                    // 所以尝试几次便可放弃同步CPlugin了
                    if (noServiceTime -- < 0)
                        return;
                    ToolUtilities.error(LOG, noService);
                }
                catch (Throwable err)
                {
                    err.printStackTrace();
                    ToolUtilities.error(LOG, err);
                    
                    // 在主控上如果下载插件失败，是很严重的问题，需要设置中央标记为脏
                    if (isInDaoCenter())
                    {
                        try
                        {
                            BasicPluginIntf intf = openRmtIntf();
                            if (intf != null && intf instanceof CPluginCenterService)
                                ((CPluginCenterService) intf).setRootDirty(BapGuiUtil.getString("Failed to download plugin package")+" : " + ToolUtilities.getExceptionMessage(err, true));
                        } catch (Throwable err2)
                        {
                            ToolUtilities.error(LOG, err2);
                        }
                    }
                }finally {
                    firstStart = false;
                }

                ToolUtilities.sleep(5000);
            }
        }
    };
    
    public boolean isSupportDelta()
    {
        return _isSupportDelta;
    }
    
    private volatile boolean _isSupportDelta = false;
    private CRpcClientWrapper<BasicPluginIntf> _intfWrapper = null;
    private ReentrantLock _lockWrap = new ReentrantLock();
    public CRpcClientWrapper<BasicPluginIntf> getIntfWrapper()
    {
        try (AutoLock lck = new AutoLock(_lockWrap))
        {
            if (_intfWrapper != null)
                return _intfWrapper;

            // 默认用本地内部服务 （微服务主控，或无微服务的单机）
            _intfWrapper = new CRpcLocalWrapper(new CPluginCenterServiceImpl()) {
                public long getConnTimeout()
                {
                    return 30000L;
                }
            };

            return _intfWrapper;
        }
    }
    
    public BasicPluginIntf openRmtIntf() throws Exception
    {
        return getIntfWrapper().getIntf();
    }
    
    // 客户端初始化，强行将插件转向为后台远程接口
    protected void setAsClient(URI uri)
    {
        try (AutoLock lck = new AutoLock(_lockWrap))
        {
            // 如果是在客户端，则等待外部init时传入URI
            _intfWrapper = new CRpcClientWrapper(CPluginCenterService.class, uri)
            {
                public CRpcAdapter getAdapter()
                {
                    return _proxyAdapter;
                }

                protected void OnConnected(CPluginCenterService newIntf)
                {
                    try
                    {
                        _isSupportDelta = newIntf.isSupportDelta();
                    } catch (Throwable err)
                    {
                        // 老版本不支持方法：isSupportDelta
                    }
                }
            };
        }
    }

    // 默认就返回系统加载器
    // 预留万一再要级联上层基础包
    LvClassLoader _basicLoader = new LvClassLoader(CmnUtil.getSystemLoader()).setName("Default Empty Basic");
    public void setBasicLoader(LvClassLoader basicLoader) throws Exception
    {
        boolean changed = _basicLoader != basicLoader;
        if (changed && _basicLoader != null)
            LvClassLoader.destroyClassLoader(_basicLoader);
        
        lockUpdate();
        try
        {
            _basicLoader = basicLoader;
            if (changed)
            {
                if (_currentLoader != null)
                {
                    _currentLoader = _currentLoader.replaceBasic(basicLoader);
                    ClassFactory.CallBack_ReloadClass(this); // 只是替换模型包，无需reload所有cell了

                    if (_currInfoLoader != null)
                        _currInfoLoader.parseClassLoader(basicLoader);
                }
            }
        } finally
        {
            unlockUpdate();
        }
    }

    public LvClassLoader getBasicClassLoader()
    {
        return _basicLoader;
    }
    
    // 充当ClassFactory
    @Override
    public LvClassLoader getValidClassLoader()
    {
        //lvCls.loadClass("dao.md.wwwwww");
        LvClassLoader lvCls = getPluginClassLoader();
        if (lvCls != null)
            return lvCls;
        
        return new LvClassLoader(getBasicClassLoader());
    }
    

    // 充当ClassFactory
    @Override
    public LvClassLoader newValidClassLoader()
    {
        LvClassLoader lvCls = getPluginClassLoader();
        if (lvCls != null)
            return new LvClassLoader(lvCls);
        
        // 由于trace的信息必须依附于LvClassLoader，所以无论如何都要返回一个lv的
        return new LvClassLoader(getBasicClassLoader());
    }
    
    // 充当ClassFactory
    @Override
    public Object newInstance(String clsName) throws Exception
    {
        Class cls = getValidClassLoader().loadClass(clsName);
        return ToolBasic.newObject(cls);
    }

    // 充当ClassFactory
    @Override
    public <T> T  newInstance(Class<T> clazz) throws Exception
    {
        return (T) newInstance(clazz.getName());
    }

    // 充当ClassFactory
    @Override
    public <T> T  newInstance(Class<T> clazz, Object... params) throws Exception
    {
        return (T) newInstance(clazz.getName(), params);
    }

    // 充当ClassFactory
    @Override
    public Object newInstance(String className, Object... params) throws Exception
    {
        ClassLoader loader = getValidClassLoader();
        Class clazz = loader.loadClass(className);
        Constructor cc = ToolUtilities.getBestConstructor(clazz, params);
        return cc.newInstance(params);
    }
    
    protected LvClassLoader getPluginClassLoader()
    {
        cleanDirtyLater();
        if (isEnable())
            return _currentLoader;
        else
            return null;
    }
    

    @Override
    public long getClassLoaderTag()
    {
        if (isEnable())
            return _currentLoader.getTag();
        
        return -1;
    }
    
    LazyPool _lazyCleanDirty = new LazyPool(5000)
    {
        public void handle(List objects)
        {
           tryCleanDirtyLoader();
        }
    };
    
    public void cleanDirtyLater()
    {
        _lazyCleanDirty.add(ToolBasic.NULL_OBJECT);
    }
    
    public void clearCurrLoaderIfExist() throws TimeoutException, InterruptedException
    {
        if (_currentLoader != null)
        {
            clearCurrLoader();
        }
    }
    
    protected Map<Long, LvClassLoader> getDirtyLoader()
    {
        _lockDirty.lock();
        try
        {
            return new TreeMap(_dirtyLoader);
        }finally
        {
            _lockDirty.unlock();
        }
    }
    
    protected void tryCleanDirtyLoader()
    {
        Map<Long, LvClassLoader> allLoaders = getDirtyLoader();
        for (Entry<Long, LvClassLoader> entry : allLoaders.entrySet())
        {
            try
            {
                LvClassLoader loader = entry.getValue();
                loader.destroy();
            } catch (Throwable exp)
            {
                // 摧毁不掉，只能放弃
                ToolUtilities.warnAndError(LOG, "Failed to destroy plugin loader : " + entry.getKey() + "\n" + ToolUtilities.getExceptionStatck(exp));
            }
            
            try
            {
                forceCleanDirtyLoader(entry.getKey());
            } catch (Throwable err)
            {
                // 摧毁不掉，只能放弃
                ToolUtilities.warnAndError(LOG, "Failed to clean dirty plugin loader : " + entry.getKey() + "\n" + ToolUtilities.getExceptionStatck(err));
            }
        }
    }
    
    protected boolean forceCleanDirtyLoader(long tagID)
    {
        ToolUtilities.info(LOG, "Try to delete Dirty Loader : " + tagID);
        File fl = new File(getDstPath(tagID));
        ToolUtilities.deleteFileFolder(getDstPath(tagID));
        if (!fl.exists())
        {
            removeOneDirtyLoader(tagID);
            if (tagID == lockGetCurrentTagID())
            {
                try
                {
                    resetCurrLoader();
                } catch (Throwable exp)
                {
                    exp.printStackTrace();
                }
            }
            return true;
        }
        
        return false;
    }
    
    public long readLocalTagFile()
    {
        try
        {
            if (new File(getLocalTagFilePath()).exists())
                return ToolUtilities.getLong(ToolUtilities.readFileUtf8(getLocalTagFilePath()), -1);
        } catch (Throwable err)
        {
            return -1;
        }
        
        return -1;
    }
    
    // 无条件删除本地缓存的插件jar文件目录，不负责ClassLoader的销毁
    public void cleanDirtyFolder() throws IOException
    {
        File[] lst = new File(LIB_PLUGIN_ROOT).listFiles();
        if (CmnUtil.getObjectSize(lst) <= 2)
            return;

        String sTag = ""+readLocalTagFile();
        for (File f  : lst)
        {
            if (f.isDirectory() && !f.getName().equals(sTag))
            {
                try
                {
                    ToolUtilities.deleteFileFolder(f.getAbsolutePath());
                } catch (Throwable err)
                {
                    ToolUtilities.warning(LOG, "Failed to delete dirty plugin : " + f.getAbsolutePath(), err);
                }
            }
        }
    }
    

    protected void addDirtyLoader(long tag, LvClassLoader orgLoader)
    {
        if (orgLoader != null)
        {
            _lockDirty.lock();
            try
            {
                _dirtyLoader.put(tag, orgLoader);
            }finally
            {
                _lockDirty.unlock();
            }
        }
    }
    
    protected void removeOneDirtyLoader(long tagID)
    {
        LvClassLoader loader = null;
        _lockDirty.lock();
        try
        {
            loader = _dirtyLoader.remove(tagID);
            ToolUtilities.infoAndOutput(LOG, "Succeed to remove dirty plugin loader : " +tagID);
            
            loader.destroy();
        } catch (Throwable err)
        {
            ToolUtilities.warnAndOutput(LOG, "Failed to destroy dirty plugin ClassLoader : " + loader+"\n"+ToolUtilities.getExceptionStatck(err));
        }
        finally
        {
            _lockDirty.unlock();
        }
    }
    
    public void clearCurrLoader() throws TimeoutException, InterruptedException
    {
        if (_currentLoader != null)
        {
            _lockDirty.lock();
            try
            {
                _dirtyLoader.put(_currTagID, _currentLoader);
            }finally
            {
                _lockDirty.unlock();
            }
        }
       
        resetCurrLoader();
    }
    
    protected void lockUpdate() throws TimeoutException, InterruptedException
    {
        if (!_lockUpdate.tryLock(30, TimeUnit.SECONDS))
            throw new TimeoutException(SrvRes.getString("Timeout to wait for updating local plugin")+", Thread Stack : " + Thread.currentThread().getName()+" - " +getLockStackMsg());
        _lockStack = new Exception("Record Stack");
    }
    
    protected String getLockStackMsg()
    {
        if (_lockStack == null)
            return "";
        return ToolUtilities.getExceptionStatck(_lockStack, false);
    }
    
    protected void lockUpdate_NoError()
    {
        try
        {
            lockUpdate();
        } catch (Throwable exp)
        {
            ToolUtilities.throwRuntimeException(exp);
        }
    }
    
    public long lockGetCurrentTagID()
    {
        lockUpdate_NoError();
        try
        {
            return _currTagID;
        }finally
        {
            unlockUpdate();
        }
    }

    protected void unlockUpdate()
    {
        _lockUpdate.unlock();
        _lockStack = null;
    }
    
    public static String getLocalTagFilePath()
    {
        return LIB_PLUGIN_ROOT+"/"+PLUGIN_TAG_FILE;
    }
    
    public static String getMd5FilePath(String path)
    {
        return new File(path, PLUGIN_MD5_FILE).getPath();
    }
    
    /**
     * ClassFactory 统一需要对插件的支持功能 
     */
    public long getPluginTag() throws Exception 
    {
        return openRmtIntf().getPluginTag();
    }
    
    public long getCurrentPluginTag()
    {
        return _currTagID;
    }
    
    /**
     * ClassFactory 统一需要对插件的支持功能 
     */
    public Map<String, byte[]> downloadPlugin(boolean onlyPublic, Collection<String> excludeNames) throws Exception
    {
        BasicPluginIntf intf = openRmtIntf();
        CmnUtil.assertNotNull(intf, "Please init plugin center first");

        return  intf.downloadPlugin(onlyPublic, excludeNames);
    }
    
    public static long getLocalTagID()
    {
        try
        {
            return ToolUtilities.getLong(ToolUtilities.readFile(getLocalTagFilePath(), "UTF-8").trim(), INVALID_TAG_ID);
        } catch (Throwable exp)
        {
            return INVALID_TAG_ID;
        }
    }
    
    protected synchronized void resetCurrLoader() throws TimeoutException, InterruptedException
    {
        System.out.println("<=== Reset Current Emb Plugin Loader : "+lockGetCurrentTagID()+" ===>\n"+ToolUtilities.getCurrentStack());
        lockUpdate();
        try
        {
            _currentLoader = null;
            _currInfoLoader = null;
            _currTagID = INVALID_TAG_ID;
            
            ToolUtilities.deleteFileFolder(new File(getLocalTagFilePath()));
        } finally
        {
            unlockUpdate();
        }
    }
    
    public boolean isEnable()
    {
        return true;
    }
    
    public static String getDstPath(long tagID)
    {
        return LIB_PLUGIN_ROOT+"/"+tagID;
    }
    
    public List<String> getPluginJars(long tagID) throws IOException
    {
        List<String> lstJars = ToolUtilities.getAllFiles(getDstPath(tagID), "jar", false);
        if (lstJars == null)
            lstJars = new ArrayList();
        
        List<String> lstExtJars = ToolUtilities.getAllFiles(LIB_PLUGIN_EXT_ROOT, "jar", false);
        if (lstExtJars != null)
            lstJars.addAll(lstExtJars);
        
        return lstJars;
    }
    
    // TRUE= 真的下载并更新了插件并触发了replaceLoader（其中会触发插件类、CELL等加载）
    // FALSE=并没有真的更新（可能未启用、远端不可达、版本无变化等）
    public boolean checkAndUpgradePlugin_Offline() throws Exception
    {
        if (!isEnable())
        {
            clearCurrLoaderIfExist();
            return false;
        }
        
        long currTagID = lockGetCurrentTagID();
        if (ToolUtilities.isDebug())
            System.out.println("Begin check local emb plugin. Current Tag ID=" + currTagID);

        BasicPluginIntf intf = openRmtIntf();
        if (intf == null)
        {
            ToolUtilities.warning(LOG, "Clear current emb loader");
            clearCurrLoaderIfExist();
            return false;
        }

        long srvNewTag = intf.getPluginTag();
        if (srvNewTag == currTagID)
            return false;

        ToolUtilities.infoAndOutput(LOG, "<=== Begin download emb plugin. Server Tag=" + srvNewTag + ", My Tag=" + currTagID + " ===>");
        ToolUtilities.info(LOG, ToolUtilities.getCurrentStack());

        try (TempFile tmpFile = new TempFile(TMP_DOWNLOAD+"/auto_upgrade_cplugin_"+srvNewTag+"__"+currTagID))
        {
            // 离线下载文件（此过程可能较慢，需在锁外离线执行)
            dowloadPluginOffline(intf, tmpFile.getAbsolutePath());
            long srvTagID_AfterDownlow = intf.getPluginTag();
            if (srvTagID_AfterDownlow != srvNewTag)
            {
                // 发现脏了，放弃本次升级，等待下一次再次触发下载更新的版本
                ToolUtilities.warning(LOG, "Emb Tag id changed after auto download : " + srvTagID_AfterDownlow);
                return false;
            }
            long srvNewTagID = srvNewTag;
            
            // 加锁 - 替换/加载新的插件包
            lockUpdate();
            try
            {
                String dstPath = getDstPath(srvNewTagID);
                ToolUtilities.cleanFolder(dstPath, true);
                ToolUtilities.copyFile(tmpFile.getAbsolutePath(), dstPath, false);

                LvClassLoader loader = new LvClassLoader().setName("Downloaded Plugin").replaceBasic(getBasicClassLoader());
                List<String> allFiles = ToolUtilities.getAllFiles(dstPath, null);
                for (String jarFile : allFiles)
                {
                    loader.addFilePath(jarFile);
                }

                List<String> lstExtJars = ToolUtilities.getAllFiles(LIB_PLUGIN_EXT_ROOT, "jar", false);
                if (lstExtJars != null)
                    for (String extJar : lstExtJars)
                        loader.addFilePath(extJar);

                // 分析class信息
                BasiceClassInfoLoader infoLoader = new BasiceClassInfoLoader();
                List<String> lstJars = getPluginJars(srvNewTagID);
                for (String jarPath : lstJars)
                {
                    try
                    {
                        CodeUtil.ananyseClass(jarPath, infoLoader);
                    }catch(Throwable err)
                    {
                        System.err.println("Failed to analyse class info from jar : " + jarPath+", ERROR="+err);
                    }
                }
                infoLoader.parseClassLoader(getBasicClassLoader()); // 别忘了分析基础ClassLoader里的信息

                // 替换新的
                replaceLoader(srvNewTagID, loader, infoLoader);
                ToolUtilities.infoAndOutput(LOG, "Finish download emb plugin. New Tag ID=" + srvNewTagID);
                
            } finally
            {
                if (ToolUtilities.isDebug())
                    System.out.println("Quit check and download emb plugin.");
                unlockUpdate();
            }
            
            // 只要有更新，都主动触发一次回收
            cleanDirtyLater();
            
            return true;
        }
    }
    
    protected void replaceLoader(long plugTagID, LvClassLoader loader, BasiceClassInfoLoader infoLoader) throws Exception
    {
        if (!isEnable())
        {
            clearCurrLoaderIfExist();
            return;
        }
        
        lockUpdate();
        try
        {
            long orgTagID = _currTagID;
            LvClassLoader orgLoader  =_currentLoader;
            
            _currTagID = plugTagID;
            _currentLoader = loader.setTag(plugTagID);
            _currInfoLoader = infoLoader;
            
            ToolUtilities.saveFile(getLocalTagFilePath(), ""+plugTagID, "UTF-8", false);
            ClassFactory.CallBack_ReloadClass(this);
            
            try
            {
                // 更新后，触发全局监听器
                ClassFactory.dispatchAfterLoaded(_currTagID);
            }catch (Throwable err)
            {
                ToolUtilities.fatal(LOG, "Failed to invoke plugin agent listener", err);
            }

            // clear org loader
            if (orgLoader != null)
                addDirtyLoader(orgTagID, orgLoader);
        } finally
        {
            unlockUpdate();
        }
    }
    
    // 离线下到一个临时目录
//    protected void dowloadPluginOffline(BasicPluginIntf intf, String tmpPath) throws Exception
//    {
////        if (false)
////            throw new Exception("No disk space.");
//        
//        Map<String, byte[]> libFiles = intf.downloadPlugin(false, null);
//        if (ToolUtilities.isObjectEmpty(libFiles))
//            return;
//        
//        String fileMd5 = "";
//        for (Entry<String, byte[]> ent : libFiles.entrySet())
//        {
//            String simpleName = ToolUtilities.getPureFileName(ent.getKey());
//            
//            ToolUtilities.info(LOG, "Download(Offline) emb plugin JAR file : " + simpleName);
//            String filePath =tmpPath + "/" + simpleName;
//            ToolUtilities.saveFile(filePath, ent.getValue(), false);
//            
//            fileMd5 += simpleName+"=="+MD5Util.encode(ent.getValue())+"\n";
//        }
//        
//        // 存MD5文件
//        ToolUtilities.saveFile(getMd5FilePath(tmpPath), fileMd5, "UTF-8", false);
//    }

    // 离线下到一个临时目录
    protected void dowloadPluginOffline(BasicPluginIntf intf, String tmpPath) throws Exception
    {
        final StringBuffer sbMd5 = new StringBuffer();
        intf.streamDownloadPlugin(CBiConsumer.NEW((t, u) -> {
            try
            {
                String simpleName = ToolUtilities.getPureFileName(t);

                ToolUtilities.info(LOG, "Download(Offline) emb plugin JAR file : " + simpleName);
                String filePath = tmpPath + "/" + simpleName;
                ToolUtilities.saveFile(filePath, u, false);

                sbMd5.append(simpleName + "==" + MD5Util.encode(u) + "\n");
            } catch (Throwable err)
            {
                ToolUtilities.throwRuntimeException(err);
            }
        }), false, null);

        // 存MD5文件
        ToolUtilities.saveFile(getMd5FilePath(tmpPath), sbMd5.toString(), "UTF-8", false);
    }
    
    // 根据MD5校验码，获取增量更新包
    protected void dowloadPluginOffline_Delta(BasicPluginIntf intf, String tmpPath) throws Exception
    {
      
    }

    // 响应更底层（如DAO）发生模型变化，需要替换自身的basic loader
    public void replaceBasicLoader(LvClassLoader loader) throws Exception
    {
        setBasicLoader(loader);        
    }

    public void replaceModelLoader(LvClassLoader daoLoader)
    {
        // 模型包含在basic包内部
        getBasicClassLoader().replaceBasic(daoLoader);
    }

    public CPluginProjectDto exportPublishPlugin(CPluginExportPackage pkg, boolean publishNow) throws Exception
    {
        BasicPluginIntf intf = openRmtIntf();
        CmnUtil.assertNotNull(intf, "Please init plugin service first");
        
        return intf.exportPublishPlugin(pkg, publishNow);
    }

    public String toString()
    {
        return getClass().getSimpleName()+" (Loader:"+_currentLoader+", Basic Loader:"+ _basicLoader+")";
    }
}
