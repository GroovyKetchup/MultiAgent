package bap.plugin.mgr;

import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoUtil;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.BasicLoaderChangeListener;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.dfc.mgr.starter.CDaoStarter;
import com.leavay.starter.CStarter;
import com.leavay.starter.StarterMain;

/**
 * 启动插件服务（能跟随DAO的主从模式自动适应）
 */
public class CPluginStarter implements CStarter
{
    public CPluginStarter()
    {
    }
    
    public static boolean isDaoSlave()
    {
        return CDaoUtil.isConfDaoSlave();
    }
    
    public void before(CStarter other) throws Exception
    {
        if (!isDaoSlave() && other instanceof CDaoStarter)
        {
            CPluginCenter.getMe().initBeforeDao();
        }
    }

    public void start() throws Exception
    {
        if (isDaoSlave())
            CPluginFollower.getMe().start();
        else
            CPluginCenter.getMe().start();
        
        // 是否要拦截并响应模型变更的通知处理
        registDaoModelListener();
    }
    
    public void registDaoModelListener()
    {
        // 如果是强制发布插件来更新模型类包, 则无需继续(后续操作为温和替换局部模型包)
        if (!CDaoUtil.isPublishAfterAlterModel())
            return; 
        
        CDaoClient.getMe().setModelChangedLsnr(new BasicLoaderChangeListener()
        {
            
            @Override
            public void replaceModelLoader(LvClassLoader loader)
            {
                try
                {
                    // 首先默认的静默替换全局ModelLoader还是要做的(这是如果没有开启此选项, ClassFactory默认也会做的事)
                    ClassFactory.getMe().replaceModelLoader(loader);
                    
                    // 如果正在启动则忽略
                    if (StarterMain.isStarting())
                        return;
                    
                    ToolUtilities.infoAndOutput(getClass().getSimpleName(), "Will publish plugin because of model change ...");
                    if (!isDaoSlave())
                    {
                        CPluginCenter.getMe().publishFully();
                    }
                } catch (Exception exp)
                {
                    ToolUtilities.error(getClass().getSimpleName(), "Error on replaceModelLoader listener: publish plugin after model changed", exp);
                }
            }
            
            @Override
            public void replaceBasicLoader(LvClassLoader loader) throws Exception
            {
                // TODO 自动生成的方法存根
                ToolUtilities.fatal(getClass().getSimpleName(), "Should not run to this place.\n"+ToolUtilities.getCurrentStack());
                throw new RuntimeException("FATAL : Should not run to this place.");
            }
        });
    }

}
