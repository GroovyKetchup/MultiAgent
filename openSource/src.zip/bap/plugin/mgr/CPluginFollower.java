package bap.plugin.mgr;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.locks.ReentrantLock;

import org.nutz.dao.Cnd;
import org.nutz.dao.util.cri.Exps;
import org.nutz.dao.util.cri.SqlExpressionGroup;

import com.cdao.CDaoConst;
import com.cdao.mgr.CDaoClient;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.CodeUtil;
import com.leavay.common.util.javac.CodeUtil.BasiceClassInfoLoader;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.PluginAgentIntf;
import com.leavay.ms.tool.CmnUtil;

import bap.java.BapMgr;
import bap.md.CPluginEmbRoot;
import bap.md.CPluginJarPublished;
import bap.md.CPluginRoot;
import cell.function.CBiConsumer;
import cell.function.IBiConsumer;
import cmn.util.Nulls;
import tiny.service.cmn.TsHelper;

/**
 * 运行在DAO的follower上（代理），从DB直接下载插件库，并合并入DaoClient中的ClassLoader，（注：本地文件路径的方式合入DaoClient中，所以这里就没有ClassLoader了）
 * 通过调用CDaoClient.followUpdatePlugin去替换DaoClient中的扩展jar，从而实现合入Dao ClassLoader
 * 
 * 注：这里会维护一个ClassInfoLoader记录插件类的索引信息，以便CellFactory等获取
 *         而且这个infoLoader中还会合入DaoClient中的信息（因为Dao中可能存在来自级联上级的插件，所以也就不区分是Dao模型还是上层插件类，一并合入）
 * 
 * 基于DAO的插件系统，由于没有次级代理集群，所以通过DAO的子集群来完成分发
 *  （无需通过RPC从集群主控拿插件，因为DAO仆从会从DAO主控拿插件，而DAO主控会找微服务主控拿插件）
 */
public class CPluginFollower extends BapMgr implements PluginAgentIntf
{

    public final static String LIB_PLUGIN_ROOT = "lib_follow_dao_plugin";
    public final static String PLUGIN_TAG_FILE = "PluginTagID.finish";
    
    private static CPluginFollower _me;
    public static synchronized CPluginFollower getMe()
    {
        if (_me == null)
        {
            _me = new CPluginFollower();
        }
        
        return _me;
    }

    ReentrantLock _lockDirty = new ReentrantLock();
    Map<Long, LvClassLoader> _dirtyLoader = new TreeMap<Long, LvClassLoader>();
    ReentrantLock _lockUpdate = new ReentrantLock();
    BasiceClassInfoLoader _infoLoader = null;
    Long _localTag = null;
    public long getLocalTag()
    {
        return _localTag == null?-1:_localTag;
    }

    Thread _mainThread =  new Thread("Follower check DAO plugin") {
        public void run()
        {
            setPriority(MAX_PRIORITY);
            
            for (;;)
            {
                try
                {
                    // 若被首领标记为忽略更新，则本轮跳过下载/替换，保留已加载插件继续运行
                    if (!TsHelper.isMyPluginUpdateIgnored())
                        checkAndUpgrade();
                    
                    ToolUtilities.sleep(5000);
                } catch (Exception exp)
                {
                    error("Failed to upgrade plugin from DAO master", exp);
                    
                    ToolUtilities.sleep(5000);
                }
                
                try
                {
                    cleanDirtyLater();
                } catch (Throwable exp)
                {
                    error("Failed to clean plugin from DAO master", exp);
                }
            }
        }
    };
    
    protected void saveTagFile(long tag) throws UnsupportedEncodingException, IOException
    {
        ToolUtilities.saveFileUtf8(getLocalTagFilePath(), ""+tag, false);
    }
    
    public static String getLocalTagFilePath()
    {
        return LIB_PLUGIN_ROOT+"/"+PLUGIN_TAG_FILE;
    }
    
    public static String getDstPath(long tagID)
    {
        return LIB_PLUGIN_ROOT+"/"+tagID;
    }
    
    // 查广播的插件Tag，不行就直接查库里的Tag，啥都查不到则返回-1
    public static long queryPluginTag() throws Exception
    {
        long l = ToolUtilities.getLong(CDaoClient.getMe().getCenterCache(CDaoConst.DAO_PLUGIN_TAG), -1);
        if (l > 0)
            return l;
        
        CPluginRoot rt = (CPluginRoot) CDaoClient.getIntf().queryDo(CPluginRoot.class.getName(), null, CPluginRoot.TimeTag);
        return ToolUtilities.getLong(rt==null?null:rt.getTimeTag(), -1);
    }
    
    private LvClassLoader _currLoader = new LvClassLoader();
//    public void checkAndUpgrade() throws Exception
//    {
//        long centerTag = queryPluginTag();
//        if (getLocalTag() == centerTag)
//            return;
//
//        _lockUpdate.lock();
//        try
//        {
//            info("Begin update DAO plugin from center ... ");
//            
//            saveTagFile(centerTag); // 存到本地文件标识一下
//            String dstFolder = getDstPath(centerTag);
//
//            Set<String> extJarPath = new HashSet<String>();
//            BasiceClassInfoLoader infoLoader = new BasiceClassInfoLoader();
//            Map<String, byte[]> mapJars = downloadPlugin();
//            long srvTagID_AfterDownlow = queryPluginTag();
//            if (srvTagID_AfterDownlow != centerTag)
//            {
//                // 发现脏了，放弃本次升级，等待下一次再次触发下载更新的版本
//                ToolUtilities.warning(LOG, "Plugin Tag id changed after offline download : " + srvTagID_AfterDownlow);
//                return;
//            }
//            if (mapJars != null)
//            {
//                Set<String> setFiles = new HashSet();
//                for (Entry<String, byte[]> ent : mapJars.entrySet())
//                {
//                    String jarFile = dstFolder+"/"+ent.getKey();
//                    setFiles.add(jarFile);
//                    
//                    ToolUtilities.saveFile(jarFile, ent.getValue(), false);
//                    extJarPath.add(jarFile);
//                    
//                    // 分析插件信息
//                    CodeUtil.ananyseClass(jarFile, infoLoader);
//                }
//            }
//            BasiceClassInfoLoader daoInfoLoader = CDaoClient.getMe().getClassInfoLoader();
//            infoLoader.putAll(daoInfoLoader);
//
//            _localTag = centerTag;
//            _infoLoader = infoLoader;
//
//
//            // 不和DAO模型混在一起，而是把DAO模型包作为可替换部分，封装出新的总loader
//            LvClassLoader newLoader  = new LvClassLoader().setTag(centerTag);
//            for (String extJar : Nulls.get(extJarPath))
//            {
//                try
//                {
//                    newLoader.addFilePath(extJar);
//                } catch (Throwable exp)
//                {
//                    ToolUtilities.fatal(LOG, "There is invalid extend JARS for DAO loader : " + extJar, exp);
//                }
//            }
//            // 包裹DAO模型包到插件Loader中，也就是Plugin包内含Dao包
//            newLoader.replaceBasic(CDaoClient.getMe().getDaoClassLoader());
//            
//            if (_currLoader != null)
//                addDirtyLoader(_currLoader.getTag(), _currLoader);
//            _currLoader = newLoader;
//
//            // 更新插件后，全局替换，并且需触发全局监听器
////            newLoader.loadClass("cmn.dto.sql.SqlVarDto")
////            _currLoader.loadClass("cmn.dto.sql.SqlVarDto")
//            ClassFactory.getMe().replaceBasicLoader(_currLoader);
//            try
//            {
//                ClassFactory.dispatchAfterLoaded(centerTag);
//            }catch (Throwable err)
//            {
//                ToolUtilities.fatal(LOG, "Failed to invoke plugin agent listener", err);
//            }
//            
//            info("Finish update DAO plugin : " + ToolUtilities.time2String(centerTag));
//        } finally
//        {
//            _lockUpdate.unlock();
//        }
//        
//        // 只要有更新，都主动触发一次回收
//        cleanDirtyLater();
//    }

    public void checkAndUpgrade() throws Exception
    {
        long centerTag = queryPluginTag();
        if (getLocalTag() == centerTag)
            return;

        _lockUpdate.lock();
        try
        {
            info("Begin update DAO plugin from center ... ");

            saveTagFile(centerTag); // 存到本地文件标识一下
            String dstFolder = getDstPath(centerTag);

            Set<String> extJarPath = new HashSet<String>();
            BasiceClassInfoLoader infoLoader = new BasiceClassInfoLoader();
            
            Set<String> setFiles = new HashSet();
            streamDownloadPlugin(CBiConsumer.NEW((t, u) -> {
                try
                {
                    String jarFile = dstFolder + "/" + t;
                    setFiles.add(jarFile);

                    ToolUtilities.saveFile(jarFile, u, false);
                    extJarPath.add(jarFile);

                    // 分析插件信息
                    CodeUtil.ananyseClass(jarFile, infoLoader);
                } catch (Throwable err)
                {
                    ToolUtilities.throwRuntimeException(err);
                }
            }));
            long srvTagID_AfterDownlow = queryPluginTag();
            if (srvTagID_AfterDownlow != centerTag)
            {
                // 发现脏了，放弃本次升级，等待下一次再次触发下载更新的版本
                ToolUtilities.warning(LOG, "Plugin Tag id changed after offline download : " + srvTagID_AfterDownlow);
                return;
            }
          
            BasiceClassInfoLoader daoInfoLoader = CDaoClient.getMe().getClassInfoLoader();
            infoLoader.putAll(daoInfoLoader);

            _localTag = centerTag;
            _infoLoader = infoLoader;

            // 不和DAO模型混在一起，而是把DAO模型包作为可替换部分，封装出新的总loader
            LvClassLoader newLoader = new LvClassLoader().setTag(centerTag);
            for (String extJar : Nulls.get(extJarPath))
            {
                try
                {
                    newLoader.addFilePath(extJar);
                } catch (Throwable exp)
                {
                    ToolUtilities.fatal(LOG, "There is invalid extend JARS for DAO loader : " + extJar, exp);
                }
            }
            // 包裹DAO模型包到插件Loader中，也就是Plugin包内含Dao包
            newLoader.replaceBasic(CDaoClient.getMe().getDaoClassLoader());

            if (_currLoader != null)
                addDirtyLoader(_currLoader.getTag(), _currLoader);
            _currLoader = newLoader;

            // 更新插件后，全局替换，并且需触发全局监听器
//            newLoader.loadClass("cmn.dto.sql.SqlVarDto")
//            _currLoader.loadClass("cmn.dto.sql.SqlVarDto")
            ClassFactory.getMe().replaceBasicLoader(_currLoader);
            try
            {
                ClassFactory.dispatchAfterLoaded(centerTag);
            } catch (Throwable err)
            {
                ToolUtilities.fatal(LOG, "Failed to invoke plugin agent listener", err);
            }

            info("Finish update DAO plugin : " + ToolUtilities.time2String(centerTag));
        } finally
        {
            _lockUpdate.unlock();
        }

        // 只要有更新，都主动触发一次回收
        cleanDirtyLater();
    }

    public final static String LOG = CPluginFollower.class.getSimpleName();
    
    // 只下载DAO Center本地插件（不要来自上层桥接的插件，因为本地如果接入微集群也会得到，如果没有介入则不应该获取那部分插件）
    public static Map<String, byte[]> downloadPlugin() throws Exception
    {
        Cnd cnd = Cnd.NEW().where(CPluginJarPublished.ProjectClass, "<>", CPluginEmbRoot.class.getName());

        Map<String, byte[]> mapRet = new HashMap<String, byte[]>();
        List<CPluginJarPublished> allJars = CDaoClient.getIntf().queryDoList(CPluginJarPublished.class.getName(), cnd);
        for (CPluginJarPublished jar : allJars)
        {
            mapRet.put(jar.getName(), jar.getFileBin());
        }
        return mapRet;
    }

    public static void streamDownloadPlugin(IBiConsumer<String, byte[]> consumer) throws Exception
    {
        streamDownloadPlugin(consumer, false, null);
    }
    
    // 只下载DAO Center本地插件（不要来自上层桥接的插件，因为本地如果接入微集群也会得到，如果没有介入则不应该获取那部分插件）
    public static void streamDownloadPlugin(IBiConsumer<String, byte[]> consumer, boolean onlyPublic, Collection<String> excludeNames) throws Exception
    {
        Cnd cnd = Cnd.NEW().where(CPluginJarPublished.ProjectClass, "<>", CPluginEmbRoot.class.getName());
        if (!CmnUtil.isObjectEmpty(excludeNames))
            cnd.and(Exps.inStr(CPluginJarPublished.Name, excludeNames).setNot(true));

        // 只返回非私有的
        if (onlyPublic)
            cnd.and(new SqlExpressionGroup().orIsNull(CPluginJarPublished.PrivateOwn).or(CPluginJarPublished.PrivateOwn, "=", false));
        
        Map<String, byte[]> mapRet = new HashMap<String, byte[]>();
        CDaoClient.streamQueryDoPage(CPluginJarPublished.class, cnd, 1, (jar)->{
            consumer.accept(jar.getName(), jar.getFileBin());
        });
    }
    
    public long readLocalTagFile()
    {
        try
        {
            if (new File(getLocalTagFilePath()).exists())
                return ToolUtilities.getLong(ToolUtilities.readFileUtf8(getLocalTagFilePath()), -1);
        } catch (Throwable err)
        {
            return -1;
        }
        
        return -1;
    }
    
    // 无条件删除本地缓存的插件jar文件目录，不负责ClassLoader的销毁
    public void cleanDirtyFolder() throws IOException
    {
        File[] lst = new File(LIB_PLUGIN_ROOT).listFiles();
        if (CmnUtil.getObjectSize(lst) <= 2)
            return;

        long fileTag = readLocalTagFile();
        String sTag = ""+ fileTag;
        for (File f  : lst)
        {
            // 只删除目录
            if (!f.isDirectory())
                continue;
            
            // 文件记录tag和当前的不一致，则删除
            if (!f.getName().equals(sTag))
            {
                try
                {
                    ToolUtilities.deleteFileFolder(f.getAbsolutePath());
                } catch (Throwable err)
                {
                    warn("Failed to delete dirty plugin : " + f.getAbsolutePath(), err);
                }
            }
        }
    }
    
    public void start()
    {

        // 启动时强行清理缓存的垃圾插件包
        try
        {
            cleanDirtyFolder();
        } catch (IOException exp)
        {
            ToolUtilities.error(exp);
        }
        
        try
        {
            ClassFactory.setMe(ClassFactory.getFactory(), this);
        } catch (Exception exp)
        {
            ToolUtilities.error(exp);
            CmnUtil.throwRuntimeException(exp);
        }
        
        if (!_mainThread.isAlive())
            _mainThread.start();
    }

    public String getLog()
    {
        return "CDao Plugin Follower";
    }
    
    LazyPool _lazyCleanDirty = new LazyPool(5000)
    {
        public void handle(List objects)
        {
           tryCleanDirtyLoader();
        }
    };
    
    public void cleanDirtyLater()
    {
        _lazyCleanDirty.add(ToolBasic.NULL_OBJECT);
    }
    
    protected Map<Long, LvClassLoader> getDirtyLoader()
    {
        _lockDirty.lock();
        try
        {
            return new TreeMap(_dirtyLoader);
        }finally
        {
            _lockDirty.unlock();
        }
    }
    
    protected void tryCleanDirtyLoader()
    {
        Map<Long, LvClassLoader> allLoaders = getDirtyLoader();
        for (Entry<Long, LvClassLoader> entry : allLoaders.entrySet())
        {
            try
            {
                LvClassLoader loader = entry.getValue();
                loader.destroy();

                forceCleanDirtyLoader(entry.getKey());
            } catch (Exception exp)
            {
                // 还是关不掉，就算了
            }
        }
    }
    
    protected boolean forceCleanDirtyLoader(long tagID)
    {
        ToolUtilities.info(getLog(), "Try to delete Dirty Loader : " + tagID);
        File fl = new File(getDstPath(tagID));
        ToolUtilities.deleteFileFolder(getDstPath(tagID));
        if (!fl.exists())
        {
            removeOneDirtyLoader(tagID);
            return true;
        }
        
        return false;
    }
    
    protected void addDirtyLoader(long tag, LvClassLoader orgLoader)
    {
        if (orgLoader != null)
        {
            _lockDirty.lock();
            try
            {
                _dirtyLoader.put(tag, orgLoader);
            }finally
            {
                _lockDirty.unlock();
            }
        }
    }
    
    
    protected void removeOneDirtyLoader(long tagID)
    {
        _lockDirty.lock();
        try
        {
            _dirtyLoader.remove(tagID);
            ToolUtilities.infoAndOutput(getLog(), "Succeed to remove dirty plugin loader : " +tagID);
        }finally
        {
            _lockDirty.unlock();
        }
    }

    public long getPluginTag() throws Exception
    {
        return queryPluginTag();
    }

    public long getCurrentPluginTag()
    {
        return getLocalTag();
    }

    public Map<String, byte[]> downloadPlugin(boolean onlyPublic, Collection<String> excludeNames) throws Exception
    {
        return downloadPlugin();
    }

    public BasiceClassInfoLoader getClassInfoLoader()
    {
        return _infoLoader;
    }

    public List<String> getPluginJars(long tagID) throws IOException
    {
        throw new RuntimeException("CPlugin Follower do not support plugin jar files storagy");
    }
}
