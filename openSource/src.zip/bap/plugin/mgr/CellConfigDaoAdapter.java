package bap.plugin.mgr;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cdao.mgr.CDaoClient;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.CellConfigAdapter;
import bap.md.CellConfigDo;

/**
 * 用于从插件库（DAO中）加载配置，追加到文件配置之上，增量式覆盖
 * 
 * 这个是附加在默认文件配置适配器上的
 * 
 * 该适配器运行在DAO主控、从机上，通过CPluginClient加载
 */
public class CellConfigDaoAdapter extends CellConfigAdapter
{
    public final static String LOG = "CPluginConfigAdapter";
    
    private static CellConfigDaoAdapter _me;
    public synchronized static CellConfigDaoAdapter getMe()
    {
        if (_me == null)
        {
            _me = new CellConfigDaoAdapter();
        }
        
        return _me;
    }
    
    protected CellConfigDaoAdapter()
    {
        
    }
    
    // 加载本地配置文件，合并成property返回
    public HashMap<String, String> loadConfigProps() throws Exception
    {
        HashMap<String, String> mapConf = new HashMap<String, String>();
        
        List<CellConfigDo> lstCfg = CDaoClient.getIntf().queryDoList(CellConfigDo.class.getName(), null);
        if (lstCfg != null)
        {
            for (CellConfigDo cfg : lstCfg)
            {
                try
                {
                    String sXml = cfg.getConfigContent();
                    if (CmnUtil.isStringEmpty(sXml))
                        continue;
                    
                    Map<String, String> mapOne = fromXml(ToolUtilities.xmlString2Element(sXml));
                    if (!mapOne.isEmpty())
                        mapConf.putAll(mapOne);
                }catch (Throwable err)
                {
                    ToolUtilities.error(LOG, "Failed to load plugin cell config  : " + cfg.getCellClass(), err);
                }
            }
        }
        
        // 最后以本地配置文件为优先，覆盖所有配置
        HashMap<String, String> fileConf = super.loadConfigProps();
        if (fileConf  != null)
            mapConf.putAll(fileConf);
        
        return mapConf;
    }
}
