package bap.plugin.mgr;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.locks.ReentrantLock;

import com.cdao.mgr.CDao;
import com.cdao.mgr.CDaoClient;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassFactoryIntf;
import com.leavay.common.util.javac.ClassInfoQuery;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.dfc.microService.MsCenterInfo;
import com.leavay.dfc.microService.MsHelper;
import com.leavay.nio.crpc.CRpcAdapter;

import bap.java.BapMgr;
import bap.md.CPluginEmbRoot;
import bap.md.CPluginJar;
import bap.ms.BasicPluginIntf;

// 从微服务主控获取插件，桥接到本地DAO插件中心里
// 运行在BAP的微服务代理上，自己拥有DAO并且是次集群的虚拟中心
// 需要把微服务全局的插件桥接到本地开发中心的插件库里去
// 本身ClassFactory依然由PluginCenter接管，这里只透传全局ClassFactory
public class CMsPluginBridge extends BapMgr implements ClassFactoryIntf
{
    public final static String LOG = "MsEmbPluginBridge";

    // NIO
    ReentrantLock _lockCenter = new ReentrantLock();
    MsCenterInfo _centerInfo = null;
    CRpcAdapter _proxyAdapter = new CRpcAdapter();
    
    ReentrantLock _lockMo = new ReentrantLock();
        
    public static CMsPluginBridge _instance=null;
    public synchronized static CMsPluginBridge getMe()
    {
        if (_instance == null)
            _instance = new CMsPluginBridge();
        return _instance;
    }
    
    public void startService()
    {
        // DAO的仆从，不自己从MS中心获取插件，而是从DAO Master获取整包插件即可（其中包含了MS中心的
        if (CDaoClient.getMe().isCenterServer())
            _mainThread.start();
    }
    
    Thread _mainThread = new Thread("Auto upgrade emb plugin"){
        public void run()
        {
            for (;;)
            {
                // 仆从模式的agent，不从ms中心获取插件，而直接从其DAO Master获取插件即可
                if (!CDaoClient.getMe().isCenterServer())
                    return;
                
                try
                {
                    checkAndUpgradePlugin_Offline();
                } catch (Throwable err)
                {
                    ToolUtilities.error(LOG, "Failed to contact center of upper cluster", err);
                }
                
                ToolUtilities.sleep(5000);
            }
        }
    };
    
    public MsCenterInfo getCenterInfo() throws Exception
    {
        _lockCenter.lock();
        try
        {
            if (_centerInfo == null)
            {
                _centerInfo = MsHelper.queryCenterInfo();
            }
            
            return _centerInfo;
        }finally
        {
            _lockCenter.unlock();
        }
    }
    
    public BasicPluginIntf openRmtIntf() throws Exception
    {
        MsCenterInfo centInfo = getCenterInfo();
        if (centInfo == null)
            throw new Exception("There isn't valid MS Center info on zk");
        
        return (BasicPluginIntf)_proxyAdapter.openService(centInfo.getHost(), centInfo.getPort(), BasicPluginIntf.class, 60000);
    }

    // 插件工程（特定单例对象）
    CPluginEmbRoot _embRoot;
    public CPluginEmbRoot getEmbRoot() throws Exception
    {
        _lockMo.lock();
        try
        {
            if (_embRoot == null)
            {
                try (CDao dao = newDao())
                {
                    _embRoot = dao.getOrCreateSingleton(CPluginEmbRoot.class);
                }
            }
            return _embRoot;
        }finally
        {
            _lockMo.unlock();
        }
    }
    
    protected long getLocalTagID()
    {
        try
        {
            return getEmbRoot().getParentTimeTag();
        } catch (Throwable exp)
        {
            return -1;
        }
    }
    
    public void checkAndUpgradePlugin_Offline() throws Exception
    {
        BasicPluginIntf intf = openRmtIntf();
        if (intf == null)
        {
            return;
        }

        long srvNewTag = intf.getPluginTag();
        if (srvNewTag > getLocalTagID())
        {
            // 父集群插件发生变化，需要更新
            rebuildLocalPlugin(intf, srvNewTag);
        }
    }
    
    // 下载并桥接插件到本地插件库
    public void rebuildLocalPlugin(BasicPluginIntf intf, long newTag) throws Exception
    {
        Map<String, byte[]> libFiles = intf.downloadPlugin(false, null);
        if (ToolUtilities.isObjectEmpty(libFiles))
            return;

        _lockMo.lock();
        try (CDao dao = newDao())
        {
            CPluginEmbRoot root = getEmbRoot();
            // 重建jar包
            dao.deleteSlave(root);
            for (Entry<String, byte[]> ent : libFiles.entrySet())
            {
                String simpleName = ToolUtilities.getPureFileName(ent.getKey());
                CPluginJar jar = new CPluginJar();
                jar.setOwner(CPluginCenter.getMe().getRoot().getUuid());
                jar.setMaster(root.getGid(), CPluginEmbRoot.JarFiles);
                jar.setFile(simpleName, ent.getValue());
                jar = (CPluginJar) dao.createDo(jar);
            }

            // 更新缓存的root
            root = ToolUtilities.clone(root);
            root.setParentTimeTag(newTag);
            dao.updateDo(root);

            dao.commit();
            _embRoot = root;
        } finally
        {
            _lockMo.unlock();
        }
    }

    public LvClassLoader getBasicClassLoader()
    {
        return ClassFactory.getFactory().getBasicClassLoader();
    }

    public LvClassLoader getValidClassLoader()
    {
        return ClassFactory.getFactory().getValidClassLoader();
    }

    public LvClassLoader newValidClassLoader()
    {
        return ClassFactory.getFactory().newValidClassLoader();
    }
    
    public long getClassLoaderTag()
    {
        return ClassFactory.getFactory().getClassLoaderTag();
    }

    public Object newInstance(String clsName) throws Exception
    {
        return ClassFactory.getFactory().newInstance(clsName);
    }
    
    public <T> T  newInstance(Class<T> clazz) throws Exception
    {
        return ClassFactory.getFactory().newInstance(clazz);
    }

    public <T> T newInstance(Class<T> clazz, Object... params) throws Exception
    {
        return ClassFactory.getFactory().newInstance(clazz, params);
    }

    public Object newInstance(String className, Object... params) throws Exception
    {
        return ClassFactory.getFactory().newInstance(className, params);
    }

    public void replaceBasicLoader(LvClassLoader loader) throws Exception
    {
        ClassFactory.getFactory().replaceBasicLoader(loader);
    }

    public void replaceModelLoader(LvClassLoader loader)
    {
        ClassFactory.getFactory().replaceModelLoader(loader);
    }

    public ClassInfoQuery getClassInfoLoader()
    {
        return ClassFactory.getFactory().getClassInfoLoader();
    }

    public String getLog()
    {
        return LOG;
    }
}
