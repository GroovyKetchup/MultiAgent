package bap.plugin;

import com.cdao.dto.DaoDto;
import com.leavay.ms.tool.CmnUtil;

public class CPluginRootDto extends DaoDto
{

    private static final long serialVersionUID = -3666544163743076519L;

    public Long timeTag;
    
    public Boolean dirtyFlag;

    public String dirtyMessage;

    public String getDirtyMessage()
    {
        return dirtyMessage;
    }

    public CPluginRootDto setDirtyMessage(String v)
    {
        this.dirtyMessage = v;
        return this;
    }

    public Long getTimeTag()
    {
        return timeTag;
    }

    public void setTimeTag(Long timeTag)
    {
        this.timeTag = timeTag;
    }

    public boolean isDirty()
    {
        return CmnUtil.getBoolean(dirtyFlag, false);
    }

    public void setDirtyFlag(Boolean dirtyFlag)
    {
        this.dirtyFlag = dirtyFlag;
    }

    protected String initDaoClass()
    {
        return "bap.md.CPluginRoot";
    }

    public String toString()
    {
        return "Plugin("+CmnUtil.time2String(getTimeTag())+")";
    }
}
