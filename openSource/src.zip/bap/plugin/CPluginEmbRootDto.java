package bap.plugin;

import com.leavay.ms.tool.CmnUtil;

public class CPluginEmbRootDto extends CPluginProjectDto
{

    private static final long serialVersionUID = 8404519800426489469L;

    public long parentTimeTag = -1;

    public long getParentTimeTag()
    {
        return parentTimeTag;
    }

    public void setParentTimeTag(long parentTimeTag)
    {
        this.parentTimeTag = parentTimeTag;
    }
    
    public String toString()
    {
        if (getParentTimeTag() > 0)
            return getName() + " (" + CmnUtil.getString("Publish Time") + " : " + CmnUtil.time2String(getParentTimeTag(), true) + ")";
        else
            return getName();
    }
}
