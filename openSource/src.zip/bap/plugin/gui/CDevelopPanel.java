package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import com.leavay.client.util.MBox;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.crpc.CProgressProxy;
import com.leavay.common.util.ProgressCtrl.crpc.IProgressDialog;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.nio.crpc.CRpcAdapter;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.BasicDockView;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import art.mvn.MvnArt;
import bap.cells.CellConfig;
import bap.client.BapClient;
import bap.md.yun.GlobalDependSetting;
import cmn.security.dto.UserPassword;

public class CDevelopPanel extends BasicDockView implements ActionAdapter
{
    JButton jBtnPublish = GuiUtil.createButton("Publish", "dev/publish.png", this);

    JButton jBtnDownloadMaven = GuiUtil.createToolButton("bap/mvn.png", "Download From Maven And Publish", this);
    
    JButton jBtnSetGlobalDepend = GuiUtil.createButton("Set Global Depend", "bap/relation.png", this);
    JButton jBtnConfig = GuiUtil.createToolButton("dfc/config.gif", "Cell Config", this);
    JButton jBtnDebugMgr = GuiUtil.createToolButton("dfc/debug_16.png", "Manage Debugger", this);
    
    CJavaTreeView jJavaTree = new CJavaTreeView();
    
    public CDevelopPanel()
    {
        getDockKey().setName("Develop & Plugin");
        
        Box mainBox = Box.createVerticalBox();
        mainBox.add(MBox.createHBar(22, jBtnPublish, MBox.HGlue(), jBtnDownloadMaven, jBtnSetGlobalDepend, MBox.HSeperator(), jBtnConfig, MBox.HSeperator(), jBtnDebugMgr));
        
        mainBox.add(MBox.hBar(jJavaTree));
        
        GuiUtil.setGridLayout(this, mainBox);
    }
    
    public void initGuiEventLsnr()
    {
        super.initGuiEventLsnr();
        
        jJavaTree.initGuiEventLsnr();
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if (jBtnPublish == e.getSource())
        {
            OnPublish();
        }else if (jBtnConfig == e.getSource())
        {
            OnConfig();
        }
        else if (jBtnDebugMgr == e.getSource())
            OnMgrDebuger();
        else if (jBtnSetGlobalDepend == e.getSource())
            OnSetGlobalDepend();
        else if (jBtnDownloadMaven == e.getSource())
            OnDownloadMaven();
    }
    
    public void OnPublish() throws Exception
    {
        BapClient.getPluginIntf().publish(false);
        
        jJavaTree.refreshLater();
    }
    
    public void OnMgrDebuger()
    {
        CDebuggerMgrPanel panel = new CDebuggerMgrPanel();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel);
        dlg.setIconImage(GuiResource.getImage("dfc/debug_16.png"));
        dlg.setTitle("Debugger Management");
        dlg.pack();
        GuiUtil.centerWindow(dlg);
        dlg.showModel(false);
    }
    
    public void OnConfig() throws Exception
    {
        Map<String, CellConfig> map = BapClient.getJavaIntf().queryCellDaoConfig();
        
        Map<Class, CellConfig> mapView = new HashMap<Class, CellConfig>();
        for (Entry<String, CellConfig> ent : map.entrySet())
        {
            try
            {
                Class clsCell = ClassFactory.loadClass(ent.getKey());
                mapView.put(clsCell, ent.getValue());
            }catch (Throwable exp)
            {
                DetailErrorMsg.showError(this, "Failed to load cell class : " + ent.getKey(), exp);
            }
        }
        
        BapConfigTablePanel panel = new BapConfigTablePanel();
        panel.showCells(mapView);
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, this);
        while (dlg.showModel(true))
        {
            Map<String, CellConfig> mapCfg = panel.getConfigFromGui();
            BapClient.getJavaIntf().saveCellDaoConfig(mapCfg);
            break;
        }
    
    }
    
    public void OnSetGlobalDepend() throws Exception
    {
        GlobalDependSetting gDepend = BapClient.getJavaIntf().queryGlobalDepends();
        ArtifactGuiUtil.showDialogModifyGlobalDepend("Global Dependency Setting", gDepend, this);
    }
    
    MavenDefinePanel mvnPanel = new MavenDefinePanel();
    public void OnDownloadMaven() throws Exception
    {
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(mvnPanel, this);
        if (!dlg.showModel(true))
            return;
        MvnArt art = mvnPanel.getDataFromGui();
        
        IProgressDialog progDlg = IProgressDialog.create(this, "Download Maven Artifacts And Publish To Yun Store");
        CProgressProxy prog = CProgressProxy.build(progDlg);
        progDlg.startWork(()->
        {
            try
            {
                CRpcAdapter.setTempTimeout(60*60*1000); // 单次调用超时设置长一点，以免下载过慢
                String log = BapClient.getJavaIntf().downloadMavenArtifact(prog, art, new UserPassword().setUser("ck").setPassword("ck"));
                GuiUtil.invokeLater(()->{
                    DetailErrorMsg.showMessage(CDevelopPanel.this, "Finish download and publish artifact from MAVEN", log, "", JOptionPane.INFORMATION_MESSAGE, true);
                });
            } catch (Exception exp)
            {
                ToolUtilities.throwRuntimeException(exp);
            }
            return null;
        });
    }
}
