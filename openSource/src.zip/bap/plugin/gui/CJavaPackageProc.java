package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.io.File;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import com.cdao.mgr.CDaoUtil;
import com.leavay.client.util.CNClientUtil;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.CompileStastic;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.ms.cmn.DtoIntf;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.JWaitDialog;

import bap.cells.Cells;
import bap.client.BapClient;
import bap.client.BapGuiUtil;
import bap.java.CJavaCode;
import bap.java.CJavaConst;
import bap.java.CJavaFolderDto;
import bap.java.CPackageDto;
import cell.CellIntf;
import cell.ResourceCellIntf;
import cell.ServiceCellIntf;
import common.cell.cache.CellCacheMgr;
import cplugin.ms.dto.CResFileDto;

public class CJavaPackageProc extends DtoNodeProc
{

    JMenuItem jMItem_NewCell = GuiUtil.createMenuItem("", "Normal Cell", this);
    JMenuItem jMItem_NewSrvCell = GuiUtil.createMenuItem("", "Service Cell", this);
    JMenuItem jMItem_NewResCell = GuiUtil.createMenuItem("", "Resource Cell", this);
    
    JMenuItem jMItem_NewClass = GuiUtil.createMenuItem("add.gif", "New Class", this);
    JMenuItem jMItem_NewCellCache = GuiUtil.createMenuItem("add.gif", "New Cell Cache", this);
    JMenuItem jMItem_NewMainClass = GuiUtil.createMenuItem("add.gif", "New Main Class", this);

    JMenuItem jMItem_ImportFile = GuiUtil.createMenuItem("dev/import.png", GuiUtil.getString("Import Resource Files"), this);

    public CJavaPackageProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);

        if (getPackageDto().getCompileStastic() == null)
        {
            try
            {
                CompileStastic cmpSts = BapClient.getJavaIntf().getStastic(getPackageDto().getProjectUuid(), getFolderDto().getKey(), getPackageDto().getPackagePath());
                if (cmpSts == null)
                    cmpSts = new CompileStastic(getKey());
                getPackageDto().setCompileStastic(cmpSts);
            }catch(Throwable err)
            {
                err.printStackTrace();
            }
        }
    }
    
    public ImageIcon getIcon()
    {
        if (getPackageDto().getCompileStastic() != null)
        {
            if (getPackageDto().getCompileStastic().getError() > 0)
                return GuiResource.getIcon("dev/package_error.png");
            else if (getPackageDto().getCompileStastic().getWarn() > 0)
                return GuiResource.getIcon("dev/package_warn.png");
        }

        return GuiResource.getIcon("dev/package.png");
    }

    public boolean isLeaf()
    {
        return false;
    }
    
    public CPackageDto getPackageDto()
    {
        return (CPackageDto) getDto();
    }
    
    public CJavaFolderDto getFolderDto()
    {
        return (CJavaFolderDto) ((DtoTreeNode)getNode().getParent()).getDto();
    }
    
    public List<DtoIntf> getChildList() throws Exception
    {
        List<DtoIntf> lstDto = (List)BapClient.getJavaIntf().getChildCodeBrief(getPackageDto().getProjectUuid(), getFolderDto().getKey(), getPackageDto().getPackagePath());
        
        
        List lstRes = BapClient.getJavaIntf().queryResFiles(getPackageDto().getProjectUuid(), getFolderDto().getUuid(), getPackageDto().getPackagePath(), true);
        
        return CmnUtil.addAllToList(lstDto, lstRes);
    }
    
    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)  
    {
        super.prepareRightMenu(pop, selNode);
        if (CJavaConst.isSysFolder(getParent().getKey()))
            return;
        
        pop.addSeparator();
        
        JMenu jM = new JMenu("New Cell");
        jM.setIcon(GuiResource.getIcon("bap/cell16.png"));
        jM.add(jMItem_NewCell);
        jM.add(jMItem_NewSrvCell);
        jM.add(jMItem_NewResCell);
        pop.add(jM);
        
        pop.add(jMItem_NewClass);
        pop.add(jMItem_NewCellCache);
        pop.add(jMItem_NewMainClass);
        
        pop.addSeparator();
        pop.add(jMItem_ImportFile);
    }
    

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jMItem_NewClass)
            OnNewClass(false);
        else if (e.getSource() == jMItem_NewCellCache)
            OnNewCache();
        else if (e.getSource() == jMItem_NewMainClass)
            OnNewClass(true);
        else if (e.getSource() == jMItem_NewCell)
            OnNewCell(CellIntf.class);
        else if (e.getSource() == jMItem_NewSrvCell)
            OnNewCell(ServiceCellIntf.class);
        else if (e.getSource() == jMItem_NewResCell)
            OnNewCell(ResourceCellIntf.class);
        else if (e.getSource() == jMItem_ImportFile)
            OnImportResFile();
    }
    
    public void OnNewClass(boolean mainFunc) throws Exception
    {
        String name = JOptionPane.showInputDialog(getTree(), "Input name of class");
        if (CmnUtil.isStringEmpty(name))
            return;
        ToolUtilities.assertValidClassName(name);
        
        CJavaCode code = new CJavaCode();
        code.setUuid(CDaoUtil.allocUuid());
        code.setJavaPackage(getPackageDto().getPackagePath());
        code.setMainClass(name);
        code.setProjectUuid(getPackageDto().getProjectUuid()); // Project是从表形式管理代码及目录的
        code.setOwner(getFolderDto().getUuid()); //Owner是挂在目录下
        code.setEmptyCode(mainFunc);

        BapGuiUtil.openCode(code);
    }
    
    public void OnNewCell(Class basicIntf) throws Exception
    {
        String name = JOptionPane.showInputDialog(getTree(), "Input name of class : ", "IMyCell");
        if (CmnUtil.isStringEmpty(name))
            return;
        ToolUtilities.assertValidClassName(name);
        
        if (!name.startsWith(Cells.CELL_PREFIX))
            throw new Exception("First character of Cell should be '"+Cells.CELL_PREFIX+"'");
        
        String pkg = getPackageDto().getPackagePath();
        if (pkg == null || !pkg.startsWith(Cells.CELL_PACKAGE+"."))
            JOptionPane.showMessageDialog(getTree(), "Cell package should be start with : " + Cells.CELL_PACKAGE, GuiUtil.getString("Warning"), JOptionPane.WARNING_MESSAGE);
        
        CJavaCode code = new CJavaCode();
        code.setUuid(CDaoUtil.allocUuid());
        code.setMainClass(name);
        code.setJavaPackage(pkg);
        code.setProjectUuid(getPackageDto().getProjectUuid()); // Project是从表形式管理代码及目录的
        code.setOwner(getFolderDto().getUuid()); //Owner是挂在目录下
        code.setCode(CJavaCode.newCellCode(code.getJavaPackage(), code.getMainClass(), basicIntf));

        BapGuiUtil.openCode(code, true);
    }
    

    public void OnNewCache() throws Exception
    {
        String name = JOptionPane.showInputDialog(getTree(), "Input name of cache : ", "MyCache");
        if (CmnUtil.isStringEmpty(name))
            return;
        ToolUtilities.assertValidClassName(name);
        
        String pkg = getPackageDto().getPackagePath();
        
        CJavaCode code = new CJavaCode();
        code.setUuid(CDaoUtil.allocUuid());
        code.setMainClass(name);
        code.setJavaPackage(pkg);
        code.setProjectUuid(getPackageDto().getProjectUuid()); // Project是从表形式管理代码及目录的
        code.setOwner(getFolderDto().getUuid()); //Owner是挂在目录下
        code.setCode(CellCacheMgr.newCellCacheCode(code.getJavaPackage(), code.getMainClass()));

        BapGuiUtil.openCode(code, true);
    }
    

    public void OnImportResFile() throws Exception
    {
        // 选择导出的目标目录
        JFileChooser flChsr = new JFileChooser();
        flChsr.setCurrentDirectory(GuiUtil.getLastFolder());
        flChsr.setFileSelectionMode(JFileChooser.FILES_ONLY);
        flChsr.setMultiSelectionEnabled(true);
        if (JFileChooser.APPROVE_OPTION != flChsr.showOpenDialog(getTree()))
            return;
        
        // 如果目标不存在，则创建
        File[] files = flChsr.getSelectedFiles();
        if (ToolUtilities.isArrayEmpty(files))
            return;
        
        GuiUtil.setLastFolder(files[0]);
        
        
        if (false) doImportFile(files);
        JWaitDialog.showWaitDialog(GuiUtil.getString("Import Resource Files"), CNClientUtil.getTopoWindow(), this, "doImportFile", files);
        
        getTree().reloadData(getNode(), true);
    }
    
    public void doImportFile(File[] files) throws Exception
    {
        for (File f : files)
        {
            CResFileDto resFile = new CResFileDto();
            resFile.setProjectUuid(getPackageDto().getProjectUuid());
            resFile.setOwner(getFolderDto().getUuid());
            resFile.setFilePackage(getPackageDto().getPackagePath());
            resFile.setFileName(f.getName());
            resFile.setFileBin(ToolUtilities.readFile(f.getAbsolutePath()));
            BapClient.getJavaIntf().importResFile(getFolderDto().getProjectGid(), resFile);
        }
        
        if (!CmnUtil.isObjectEmpty(files))
            BapClient.getJavaIntf().rebuildAll(getFolderDto().getProjectUuid());
    }
}
