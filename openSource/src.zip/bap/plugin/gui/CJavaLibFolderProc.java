package bap.plugin.gui;

import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;

import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.ms.cmn.DtoIntf;
import com.project.gui.common.GuiResource;

import bap.client.BapClient;

public class CJavaLibFolderProc extends DtoNodeProc
{
    public CJavaLibFolderProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
    }

    public boolean isLeaf()
    {
        return false;
    }

    public ImageIcon getIcon()
    {
        return GuiResource.getIcon("dev/java_folder.png");
    }
    
    public List<DtoIntf> getChildList() throws Exception
    {
        return (List)BapClient.getJavaIntf().getJarFiles(getParent().getKey());
    }
    
    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)  
    {
        super.prepareRightMenu(pop, selNode);
    }
    
}
