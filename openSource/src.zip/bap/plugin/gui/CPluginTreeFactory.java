package bap.plugin.gui;

import com.leavay.dfc.gui.dto.DtoNodeFactory;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;

import bap.java.CJavaCode;
import bap.java.CJavaFolderDto;
import bap.java.CJavaProjectDto;
import bap.java.CJavaVirtualProjectDto;
import bap.java.CPackageDto;
import bap.md.java.CJavaLibFolderDto;
import bap.plugin.CPluginJarDto;
import bap.plugin.CPluginProjectDto;
import bap.plugin.CPluginRootDto;
import cplugin.ms.dto.CJarFileDto;
import cplugin.ms.dto.CResFileDto;

public class CPluginTreeFactory extends DtoNodeFactory
{

    public CPluginTreeFactory(DtoTreeView tree)
    {
        super(tree);
    }

    final static Class[][] DEFAULT_MAP= new Class[][] 
            {{CPluginRootDto.class, CPluginRootProc.class},
            {CPluginProjectDto.class, CPluginProjectProc.class},
            {CPluginJarDto.class, CPluginJarProc.class},
            {CJavaVirtualProjectDto.class, CJavaVirtualProjectProc.class},
            {CJavaProjectDto.class, CJavaProjectProc.class},
            {CJavaFolderDto.class, CJavaFolderProc.class},
            {CPackageDto.class, CJavaPackageProc.class},
            {CJavaCode.class, CJavaCodeProc.class},
            {CJavaLibFolderDto.class, CJavaLibFolderProc.class},
            {CJarFileDto.class, CJavaJarProc.class},
            {CResFileDto.class, CResFileProc.class}
            };
    
    public Class[][] getDefaultMapping()
    {
        return DEFAULT_MAP;
    }

    public DtoNodeProc createProc(DtoTreeNode node) throws Exception
    {
        if (node == null)
            return null;

        if (node.getDto() == CJavaTreeView._projectRootDto)
            return newProc(CJavaRootProc.class, node);

        return super.createProc(node);
    }
}
