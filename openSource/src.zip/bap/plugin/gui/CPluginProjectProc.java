package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.io.File;
import java.util.LinkedList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import com.cdao.mgr.CDaoClient;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.ms.cmn.DtoIntf;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;

import bap.client.BapClient;
import bap.md.CPluginProject;
import bap.plugin.CPluginJarDto;

public class CPluginProjectProc extends DtoNodeProc
{
    JMenuItem jMItem_Delete = GuiUtil.createMenuItem("remove.png", "Delete", this);
    JMenuItem jMItem_Upload = GuiUtil.createMenuItem("add.gif", "Upload JAR", this);
    
    public CPluginProjectProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
    }
    
    public boolean isLeaf()
    {
        return false;
    }
    
    public ImageIcon getIcon()
    {
        return GuiResource.getIcon("dev/jar_folder.png");
    }
    
    public List<DtoIntf> getChildList() throws Exception
    {
        return (List)BapClient.getPluginIntf().getJars(getKey(), false);
    }
    

    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)  
    {
        super.prepareRightMenu(pop, selNode);
        pop.addSeparator();
        
        pop.add(jMItem_Upload);
        pop.add(jMItem_Delete);
    }
    

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jMItem_Delete)
            OnDelete();
        else if (e.getSource() == jMItem_Upload)
            OnUpload();
    }
    
    public void OnDelete() throws Exception
    {
        if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(getTree(), "Are you sure want to delete all selected items", "", JOptionPane.YES_NO_OPTION))
            return;
        
        CDaoClient.getIntf().deleteDo(new CPluginProject().setUuid(getKey()));
        getTree().reloadData((DtoTreeNode) getNode().getParent(), true);
    }
    
    public void OnUpload() throws Exception
    {
        // 选择导出的目标目录
        JFileChooser flChsr = new JFileChooser();
        flChsr.setCurrentDirectory(GuiUtil.getLastFolder());
        flChsr.setFileSelectionMode(JFileChooser.FILES_ONLY);
        flChsr.setMultiSelectionEnabled(true);
        if (JFileChooser.APPROVE_OPTION != flChsr.showOpenDialog(getTree()))
            return;

        // 如果目标不存在，则创建
        File[] selFiles = flChsr.getSelectedFiles();
        if (CmnUtil.isObjectEmpty(selFiles))
            return;
        GuiUtil.setLastFolder(selFiles[0]);

        try
        {
            List<CPluginJarDto> lstJars = new LinkedList<CPluginJarDto>();
            for (File fl : selFiles)
            {
                CPluginJarDto dto = new CPluginJarDto();
                dto.setName(fl.getName());
                dto.setFileBin(ToolBasic.readFile(fl.getAbsolutePath()));
                lstJars.add(dto);
            }

            BapClient.getPluginIntf().uploadJar(getKey(), lstJars, false);
        } finally
        {
            reloadThis(true);
        }
    }
}
