package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.ListSelectionModel;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.crpc.CProgressProxy;
import com.leavay.common.util.ProgressCtrl.crpc.IProgressDialog;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.ms.cmn.DtoIntf;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import bap.client.BapClient;
import bap.java.CJavaConst;
import bap.java.CJavaProjectDto;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import bap.plugin.gui.yun.YunArtifactTablePanel;
import bap.yun.ArtifactUtil;
import cmn.security.dto.UserPassword;

public class CJavaRootProc extends DtoNodeProc
{

    JMenuItem jMItem_NewProject = GuiUtil.createMenuItem("add.gif", "New Project", this);

    JMenuItem jMItem_ImportYunProject = GuiUtil.createMenuItem("undo.gif", "Import Project From Store", this);

    JMenuItem jMItem_ImportYunVirtualProject = GuiUtil.createMenuItem("bap/store.png", "Import Virtual Project From Store", this);
    
    public CJavaRootProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
    }

    public boolean isLeaf()
    {
        return false;
    }
    
    public ImageIcon getIcon()
    {
        return GuiResource.getIcon("dev/project.png");
    }
    
    public List<DtoIntf> getChildList() throws Exception
    {
        List lstPjs = (List) BapClient.getJavaIntf().getAllProjects();
        try
        {
            List lstVPjs = BapClient.getJavaIntf().getAllVirtualProjects();
            return CmnUtil.addAllToList(lstPjs, lstVPjs);
        } catch (Throwable err)
        {
            // 有可能版本不兼容,还没有此接口
            err.printStackTrace();
        }

        return lstPjs;
    }
    
    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)  
    {
        super.prepareRightMenu(pop, selNode);
        pop.addSeparator();
        
        pop.add(jMItem_NewProject);
        pop.add(jMItem_ImportYunProject);
        pop.addSeparator();
        pop.add(jMItem_ImportYunVirtualProject);
    }
    

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jMItem_NewProject)
            OnNew();
        else if (e.getSource() == jMItem_ImportYunProject)
            OnImportFromStore();
        else if (e.getSource() == jMItem_ImportYunVirtualProject)
            OnImportVirtualFromStore();
    }
    
    public void OnNew() throws Exception
    {
        String name = JOptionPane.showInputDialog(getTree(), "Input name of project");
        if (CmnUtil.isStringEmpty(name))
            return;
        
        CJavaProjectDto pjDto = BapClient.getJavaIntf().createProject(name, CJavaConst.DEPEND_PLATFORM);
        reloadThis(true);
    }
    
    public void OnImportFromStore() throws Exception
    {
        UserPassword user = BapClient.getMe().loginYunStore(getTree());
        if (user == null)
            return;
        
        // 尝试登录云仓库
        BapClient.getJavaIntf().loginYunStore(user);
        
        YunArtifactTablePanel panel = new YunArtifactTablePanel();
        panel.jList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panel.showDataLater();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, getTree());
        dlg.setTitle(BapClient.getJavaIntf().getYunStoreUri());
        if (!dlg.showModel(true))
            return;
        ArtifactWare impArt = panel.getSelect();
        if (impArt == null)
            return;

        GlobalDependSetting orgDepend = BapClient.getJavaIntf().queryGlobalDepends();
        
        /**
         * 导入为本地新JAVA工程，设定好依赖，并导入了代码等
         */
        IProgressDialog progDlg = IProgressDialog.create(getTree(), "Import Project ... ");
        CJavaProjectDto project = progDlg.startRpcWork(60*60, (CProgressProxy prog)->
        {
            try
            {
                return BapClient.getJavaIntf().importYunProject(prog, impArt, user);
            } catch (Exception exp)
            {
                return (CJavaProjectDto)ToolUtilities.throwRuntimeException(exp);
            }
        });
        if (project == null)
            return;
        
     
        /** 
       * 检查全局依赖是否发生了变化，是的话，出对话框让用户做一次全局依赖变更
       */
        try
        {
            GlobalDependSetting newDepnd = BapClient.getJavaIntf().queryGlobalDepends();
            List<ArtifactDefine> lstOrgArts = ArtifactUtil.mergeConflictList(orgDepend.getLstDependArtifact(), orgDepend.getPreferConfigMap());
            List<ArtifactDefine> lstNewArts = ArtifactUtil.mergeConflictList(newDepnd.getLstDependArtifact(), newDepnd.getPreferConfigMap());
            if (!ArtifactUtil.isArtifactListSame(lstOrgArts, lstNewArts))
            {
                // 发生了依赖变化，需要Rebuild全局依赖
                ArtifactGuiUtil.showDialogModifyGlobalDepend("Import Dependency Of Project : " + impArt, newDepnd, getTree());
            }
        }finally
        {
            BapClient.getJavaIntf().rebuildAll(project.getUuid());
            
            reloadThis(true);
            DtoTreeNode node = getTree().findNodeByKey(getNode(), project.getUuid());
            if (node != null)
                getTree().selectNodeLater(node, true);
        }
    }
    

    public void OnImportVirtualFromStore() throws Exception
    {
        UserPassword user = BapClient.getMe().loginYunStore(getTree());
        if (user == null)
            return;
        
        // 尝试登录云仓库
        BapClient.getJavaIntf().loginYunStore(user);
        
        YunArtifactTablePanel panel = new YunArtifactTablePanel();
        panel.jList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panel.showDataLater();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, getTree());
        dlg.setTitle(BapClient.getJavaIntf().getYunStoreUri());
        if (!dlg.showModel(true))
            return;
        ArtifactWare impArt = panel.getSelect();
        if (impArt == null)
            return;

        /**
         * 导入为本地新JAVA工程，设定好依赖，并导入了代码等
         */
        IProgressDialog progDlg = IProgressDialog.create(getTree(), "Import Project ... ");
        CJavaProjectDto project = progDlg.startRpcWork(60*60, (CProgressProxy prog)->
        {
            try
            {
                return BapClient.getJavaIntf().importYunVirtualProject(prog, impArt, user);
            } catch (Exception exp)
            {
                return (CJavaProjectDto)ToolUtilities.throwRuntimeException(exp);
            }
        });
        if (project == null)
            return;

        BapClient.getJavaIntf().rebuildAll(project.getUuid());
        reloadThis(true);
        DtoTreeNode node = getTree().findNodeByKey(getNode(), project.getUuid());
        if (node != null)
            getTree().selectNodeLater(node, true);
    }
}
