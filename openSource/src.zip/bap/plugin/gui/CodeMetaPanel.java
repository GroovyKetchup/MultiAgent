package bap.plugin.gui;

import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import com.leavay.client.util.MBox;
import com.leavay.common.util.ToolUtilities;
import com.project.gui.common.GuiUtil;

import bap.java.CJavaCode;
import bap.java.CodeMeta;

public class CodeMetaPanel extends JPanel
{
    private static final long serialVersionUID = 8276903911912027588L;

    JTextArea jTxtMeta = new JTextArea();
    
    public CodeMetaPanel()
    {
        Box mainBox = Box.createVerticalBox();
        mainBox.add(MBox.hBar(80, new JScrollPane(jTxtMeta)));
        GuiUtil.setGridLayout(this, mainBox);
        setPreferredSize(new Dimension(400, 200));
    }
    
    CodeMeta _meta = null;
    public void showData(CJavaCode code, CodeMeta meta)
    {
        _meta = meta;
        jTxtMeta.setText(meta.getMeta());
    }
    
    public CodeMeta getMetaFromGui() throws Exception
    {
        CodeMeta meta = ToolUtilities.clone(_meta);
        meta.setMeta(jTxtMeta.getText());
        return meta;
    }
}
