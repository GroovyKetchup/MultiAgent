package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import com.cdao.gui.CDaoPanel;
import com.cdao.mgr.CDaoUtil;
import com.cdao.model.CDoUser;
import com.leavay.client.util.CNClientUtil;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.CompileStastic;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.ms.cmn.DtoIntf;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.JWaitDialog;

import bap.cells.Cells;
import bap.client.BapClient;
import bap.client.BapGuiUtil;
import bap.java.CJavaCode;
import bap.java.CJavaFolderDto;
import bap.java.CPackageDto;
import cell.CellIntf;
import cell.ResourceCellIntf;
import cell.ServiceCellIntf;
import common.cell.cache.CellCacheMgr;
import cplugin.ms.dto.CResFileDto;

public class CJavaFolderProc extends DtoNodeProc
{
    JMenuItem jMItem_NewCell = GuiUtil.createMenuItem("", "Normal Cell", this);
    JMenuItem jMItem_NewSrvCell = GuiUtil.createMenuItem("", "Service Cell", this);
    JMenuItem jMItem_NewResCell = GuiUtil.createMenuItem("", "Resource Cell", this);

    JMenuItem jMItem_NewClass = GuiUtil.createMenuItem("add.gif", "New Class", this);
    JMenuItem jMItem_NewCellCache = GuiUtil.createMenuItem("add.gif", "New Cell Cache", this);
    JMenuItem jMItem_NewMainClass = GuiUtil.createMenuItem("add.gif", "New Main Class", this);
    JMenuItem jMItem_SwitchPrivatePublic = GuiUtil.createMenuItem("db/user_16.png", "Switch Private/Public", this);

    JMenuItem jMItem_ImportFile = GuiUtil.createMenuItem("dev/import.png", GuiUtil.getString("Import Resource Files"), this);
    
    JMenuItem jMItem_Delete = GuiUtil.createMenuItem("remove.png", GuiUtil.getString("Delete"), this);
    
    public CJavaFolderProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
        
        if (getFolder().getCompileStastic() == null)
        {
            try
            {
                CompileStastic cmpSts =  BapClient.getJavaIntf().getFolderStastic(getFolder().getProjectUuid(), getKey());
                if (cmpSts == null)
                    cmpSts = new CompileStastic(getKey());
                getFolder().setCompileStastic(cmpSts);
            }catch(Throwable err)
            {
                err.printStackTrace();
            }
        }
    }

    public boolean isLeaf()
    {
        return false;
    }

    public ImageIcon getIcon()
    {
        if (getFolder().isPrivateOwn())
        {
            return GuiResource.getIcon("dev/lock_yellow.png");
        }else
        {
            if (getFolder().getCompileStastic() != null)
            {
                if (getFolder().getCompileStastic().getError() > 0)
                    return GuiResource.getIcon("dev/java_folder_error.png");
                else if (getFolder().getCompileStastic().getWarn() > 0)
                    return GuiResource.getIcon("dev/java_folder_warn.png");
            }
            return GuiResource.getIcon("dev/java_folder.png");
        }
    }
    
    public List<DtoIntf> getChildList() throws Exception
    {
        List<DtoIntf> lstDto = new LinkedList<DtoIntf>();
        Set<String> setPkg = BapClient.getJavaIntf().getAllPackages(getFolder().getProjectUuid(), getFolder().getUuid());
        if (setPkg != null)
        {
            for (String s : setPkg)
            {
                CPackageDto dto = new CPackageDto();
                dto.setPackagePath(s);
                dto.setProjectUuid(getFolder().getProjectUuid());
                lstDto.add(dto);
            }
        }
        
        List lstRes = BapClient.getJavaIntf().queryResFiles(getFolder().getProjectUuid(), getFolder().getUuid(), "", true);
        lstDto.addAll(lstRes);
        return lstDto;
    }
    
    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)  
    {
        super.prepareRightMenu(pop, selNode);
        pop.addSeparator();
        
        JMenu jM = new JMenu("New Cell");
        jM.setIcon(GuiResource.getIcon("bap/cell16.png"));
        jM.add(jMItem_NewCell);
        jM.add(jMItem_NewSrvCell);
        jM.add(jMItem_NewResCell);
        pop.add(jM);
        
        pop.add(jMItem_NewClass);
        pop.add(jMItem_NewCellCache);
        pop.add(jMItem_NewMainClass);
        pop.addSeparator();
        pop.add(jMItem_SwitchPrivatePublic);
        if (getFolder().isPrivateOwn())
        {
            jMItem_SwitchPrivatePublic.setIcon(GuiUtil.getIcon("dev/lock_blue.png"));
            jMItem_SwitchPrivatePublic.setText(GuiUtil.getString("Unlock As Public"));
        }else
        {
            jMItem_SwitchPrivatePublic.setIcon(GuiUtil.getIcon("dfc/locked_16.png"));
            jMItem_SwitchPrivatePublic.setText(GuiUtil.getString("Lock As Private"));
        }
        pop.addSeparator();
        pop.add(jMItem_ImportFile);
        pop.add(jMItem_Delete);
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jMItem_NewClass)
            OnNewClass(false);
        else if (e.getSource() == jMItem_NewMainClass)
            OnNewClass(true);
        else if (e.getSource() == jMItem_SwitchPrivatePublic)
            OnSwitchPrivatePublic();
        else if (e.getSource() == jMItem_NewCellCache)
            OnNewCache();
        else if (e.getSource() == jMItem_NewCell)
            OnNewCell(CellIntf.class);
        else if (e.getSource() == jMItem_NewSrvCell)
            OnNewCell(ServiceCellIntf.class);
        else if (e.getSource() == jMItem_NewResCell)
            OnNewCell(ResourceCellIntf.class);
        else if (e.getSource() == jMItem_Delete)
            OnDelete();
        else if (e.getSource() == jMItem_ImportFile)
            OnImportResFile();
    }
    
    public CJavaFolderDto getFolder()
    {
        return (CJavaFolderDto) getDto();
    }
    
    public void OnNewClass(boolean mainFunc) throws Exception
    {
        String name = JOptionPane.showInputDialog(getTree(), "Input name of class : ", "NewClass");
        if (CmnUtil.isStringEmpty(name))
            return;
        ToolUtilities.assertValidClassName(name);
        
        String pkg = JOptionPane.showInputDialog(getTree(), "Package", "com.code");
        ToolUtilities.assertValidPackage(pkg);
        
        CJavaCode code = new CJavaCode();
        code.setUuid(CDaoUtil.allocUuid());
        code.setMainClass(name);
        code.setJavaPackage(pkg);
        code.setProjectUuid(getFolder().getProjectUuid()); // Project是从表形式管理代码及目录的
        code.setOwner(getFolder().getUuid()); //Owner是挂在目录下
        code.setEmptyCode(mainFunc);

        BapGuiUtil.openCode(code, true);
    }
    
    public void OnNewCell(Class basicIntf) throws Exception
    {
        String name = JOptionPane.showInputDialog(getTree(), "Input name of class : ", "IMyCell");
        if (CmnUtil.isStringEmpty(name))
            return;
        ToolUtilities.assertValidClassName(name);
        
        if (!name.startsWith(Cells.CELL_PREFIX))
            throw new Exception("First character of Cell should be '"+Cells.CELL_PREFIX+"'");
        
        String pkg = JOptionPane.showInputDialog(getTree(), "Package", "cell.");
        ToolUtilities.assertValidPackage(pkg);
        if (pkg == null || !pkg.startsWith(Cells.CELL_PACKAGE+"."))
            JOptionPane.showMessageDialog(getTree(), "Cell package should be start with : " + Cells.CELL_PACKAGE, GuiUtil.getString("Warning"), JOptionPane.WARNING_MESSAGE);
        
        CJavaCode code = new CJavaCode();
        code.setUuid(CDaoUtil.allocUuid());
        code.setMainClass(name);
        code.setJavaPackage(pkg);
        code.setProjectUuid(getFolder().getProjectUuid()); // Project是从表形式管理代码及目录的
        code.setOwner(getFolder().getUuid()); //Owner是挂在目录下
        code.setCode(CJavaCode.newCellCode(code.getJavaPackage(), code.getMainClass(), basicIntf));

        BapGuiUtil.openCode(code, true);
    }
    
    public void OnNewCache() throws Exception
    {
        String name = JOptionPane.showInputDialog(getTree(), "Input name of cache : ", "MyCache");
        if (CmnUtil.isStringEmpty(name))
            return;
        ToolUtilities.assertValidClassName(name);
        
        String pkg = JOptionPane.showInputDialog(getTree(), "Package", "com.cell.cache");
        ToolUtilities.assertValidPackage(pkg);
        
        CJavaCode code = new CJavaCode();
        code.setUuid(CDaoUtil.allocUuid());
        code.setMainClass(name);
        code.setJavaPackage(pkg);
        code.setProjectUuid(getFolder().getProjectUuid()); // Project是从表形式管理代码及目录的
        code.setOwner(getFolder().getUuid()); //Owner是挂在目录下
        code.setCode(CellCacheMgr.newCellCacheCode(code.getJavaPackage(), code.getMainClass()));

        BapGuiUtil.openCode(code, true);
    }
    
    public void OnSwitchPrivatePublic() throws Exception
    {
        boolean isPrivate = getFolder().isPrivateOwn();
        if (isPrivate)
        {
            // 解锁，公开
            BapClient.getJavaIntf().setFolderPrivate(getFolder().getGid(), null);
            getFolder().setPrivateOwner(null); // 更新界面数据
        }else
        {
            // 加锁，指派个某个人
            CDoUser user = CDaoPanel.showSelectDialog("Select User", CDoUser.class);
            CmnUtil.assertNotNull(user, "Please select user to be assigned as writer");

            BapClient.getJavaIntf().setFolderPrivate(getFolder().getGid(), user.getCode());
            getFolder().setPrivateOwner(user.getCode()); // 更新界面数据
        }
        
        reloadThis(true);
    }
    
    public void OnDelete() throws Exception
    {
        if (!GuiUtil.showConfirmWarn(getTree(), GuiUtil.getString("Are you sure to delete this folder?"), "Warning"))
            return;
        
        BapClient.getJavaIntf().deleteFolder(getFolder().getProjectUuid(), getFolder().getUuid());
        GuiUtil.removeTreeNode(getTree().getTree(), getNode());
    }
    
    public void OnImportResFile() throws Exception
    {
        // 选择导出的目标目录
        JFileChooser flChsr = new JFileChooser();
        flChsr.setCurrentDirectory(GuiUtil.getLastFolder());
        flChsr.setFileSelectionMode(JFileChooser.FILES_ONLY);
        flChsr.setMultiSelectionEnabled(true);
        if (JFileChooser.APPROVE_OPTION != flChsr.showOpenDialog(getTree()))
            return;
        
        // 如果目标不存在，则创建
        File[] files = flChsr.getSelectedFiles();
        if (ToolUtilities.isArrayEmpty(files))
            return;
        
        GuiUtil.setLastFolder(files[0]);
        
        
        if (false) doImportFile(files);
        JWaitDialog.showWaitDialog(GuiUtil.getString("Import Resource Files"), CNClientUtil.getTopoWindow(), this, "doImportFile", files);
        
        getTree().reloadData(getNode(), true);
    }
    
    public void doImportFile(File[] files) throws Exception
    {
        for (File f : files)
        {
            String filePath = f.getName();
            CResFileDto resFile = new CResFileDto();
            resFile.setProjectUuid(getFolder().getProjectUuid());
            resFile.setOwner(getFolder().getUuid());
            resFile.setFileName(f.getName());
            resFile.setFileBin(ToolUtilities.readFile(f.getAbsolutePath()));
            BapClient.getJavaIntf().importResFile(getFolder().getProjectGid(), resFile);
        }
        
        if (!CmnUtil.isObjectEmpty(files))
            BapClient.getJavaIntf().rebuildAll(getFolder().getProjectUuid());
    }
}
