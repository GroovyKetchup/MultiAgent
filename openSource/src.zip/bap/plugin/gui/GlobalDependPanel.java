package bap.plugin.gui;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.cdao.mgr.CDaoClient;
import com.leavay.client.util.MBox;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SJsonMap;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import bap.client.BapClient;
import bap.java.CJavaProjectDto;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import bap.plugin.gui.yun.ArtifactGraphPanel;
import bap.plugin.gui.yun.YunArtifactTablePanel;
import cell.bap.yun.ArtifactGraph;
import cmn.util.NullUtil;

// 对整个服务器设定全局依赖列表（对云仓库组建的依赖）
public class GlobalDependPanel extends JPanel implements ActionAdapter
{
    public final static String[] HEADER = new String[]{"Local JAVA Project", "ArtifactID", "Version"};
    public final static int COL_PROJECT= 0;
    public final static int COL_ART = 1;
    public final static int COL_VER = 2;
    
    public JButton jBtnSetPreferDepend = GuiUtil.createButton("Set Prefer Dependency", "dfc/medical_16.png", this);
    public JButton jBtnSetLocalConflict = GuiUtil.createButton("Set Exclude List", "ignore.png", this);
    
    SortableModel _model = new SortableModel();
    JTable jTbl = new JTable(_model);
        
    public GlobalDependPanel()
    {
        Box mainBox = Box.createVerticalBox();
        
        mainBox.add(MBox.VStrut(5));
        Box boxDep = Box.createVerticalBox();
        boxDep.add(MBox.hBar(22, jBtnSetPreferDepend, jBtnSetLocalConflict, MBox.HGlue()));
        for (String s : HEADER)
            _model.addColumn(s);
        boxDep.add(MBox.hBar(new JScrollPane(jTbl)));
        boxDep.setBorder(BorderFactory.createTitledBorder("Dependency Setting"));
        mainBox.add(boxDep);
        
        GuiUtil.setGridLayout(this, mainBox);
        this.setPreferredSize(new Dimension(600, 280));
    }
    
    GlobalDependSetting _org = null;
    public void showData(GlobalDependSetting gDepend)
    {
        _org = gDepend;
        
        GuiUtil.clearTableRows(_model);
        if (gDepend.getLstDependArtifact() != null)
            for (ArtifactDefine dep : gDepend.getLstDependArtifact())
            {
                _model.addRow(new Object[] {NullUtil.getMapValue(_org.getMapProject(), dep.getMasterKey()), dep.getArtifactId(), dep.getVersion()});
            }
    }
    
    public GlobalDependSetting getDataFromGui() throws Exception
    {
        GlobalDependSetting data = ToolUtilities.clone(_org);
        return data;
    }

    public void OnAdd()
    {
        _model.addRow(new Object[] {});
    }
    
    public void OnImport() throws Exception
    {
        YunArtifactTablePanel panel = new YunArtifactTablePanel();
        panel.showData();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, this);
        dlg.setTitle(BapClient.getJavaIntf().getYunStoreUri());
        if (!dlg.showModel(true))
            return;
        
        List<ArtifactWare> lstWares = panel.getSelects();
        if (lstWares != null)
            for (ArtifactWare art : lstWares)
                _model.addRow(new Object[] {art.getGroupId(), art.getArtifactId(), art.getVersion()});
    }
    
    public void OnRemove()
    {
        GuiUtil.removeTableRow(_model, jTbl.getSelectedRows());
    }
    
    public void OnCheckDepend() throws Exception
    {
        GlobalDependSetting gDepend = getDataFromGui();
        if (CmnUtil.isObjectEmpty(gDepend.getLstDependArtifact()))
        {
            JOptionPane.showMessageDialog(this, "No Dependency");
            return;
        }
        
        Set<String> setArtUuids = new HashSet();
        for (ArtifactDefine dep : gDepend.getLstDependArtifact())
        {
            ArtifactWare art = BapClient.getJavaIntf().queryYunArtifact(dep.getGroupId(), dep.getArtifactId(), dep.getVersion(), false, ArtifactWare.FIELDS_BRIEF);
            if (art == null)
            {
                try
                {
                    ArtifactDefine parentDef = (ArtifactDefine) CDaoClient.getIntf().getDo(dep.getMaster());
                    CJavaProjectDto pj = BapClient.getJavaIntf().getProject(parentDef.getForeignKey());
                    DetailErrorMsg.showError(this, String.format("Please check dependent artifact (%s) in project : %s", dep, pj), "");
                    return;
                }catch (Throwable err)
                {
                    CmnUtil.assertNotNull(art, "Can not find artifact in YUN store : " + dep);
                }
            }
            setArtUuids.add(art.getUuid());
        }
        
        ArtifactGraph depGraph = BapClient.getJavaIntf().queryYunDependGraph(setArtUuids, true);
        ArtifactGraphPanel panel = new ArtifactGraphPanel();
        panel.showData(depGraph, gDepend.getPreferConfigMap());
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, this);
        dlg.setTitle("Check Dependency");
        if (dlg.showModel(true))
        {
            SJsonMap prefMap = panel.getPreferSetting();
            _org.setPreferConfig(prefMap);
        }
    }
    
    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jBtnSetPreferDepend)
            OnCheckDepend();
        else if (e.getSource() == jBtnSetLocalConflict)
            OnSetLocalConflict();
    }
    
    public void OnSetLocalConflict() throws Exception
    {
        GlobalDependSetting g = getDataFromGui();
        LocalConflictJarPanel conflictPanel = new LocalConflictJarPanel();
        conflictPanel.showData(g);
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(conflictPanel, this);
        if (!dlg.showModel(true))
            return;
        
        _org.setExcludeArtifactList(conflictPanel.getData());
    }
}
