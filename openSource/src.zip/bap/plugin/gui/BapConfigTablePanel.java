package bap.plugin.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.leavay.common.util.SortButtonRenderer;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import bap.cells.CellConfig;
import bap.debug.gui.BapConfigPanel;

public class BapConfigTablePanel extends JPanel
{

    static final int COL_CLASS= 0;
    static final int COL_CONFIG = 1;
    
    SortableModel _model = new SortableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return column == COL_CONFIG;
        }
    };
           
    JTable jTbl = new JTable(_model);
    
    class CE_Config extends DefaultCellEditor
    {
        JButton jBtn = new JButton("...");
        public CE_Config()
        {
            super(new JComboBox());
            
            jBtn.addActionListener(new ActionAdapter()
            {
                public void OnAction(ActionEvent e) throws Exception
                {
                    BapConfigPanel panel = new BapConfigPanel();
                    panel.showData(_cellClass, _conf);
                    JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, getParent());
                    dlg.pack();
                    if (dlg.showTopModel(true))
                    {
                        _conf = panel.getDataFromGui();
                    }
                }
            });
        }

        Class _cellClass;
        CellConfig _conf;
        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected,
                                                     int row, int column) 
        {
            _conf = (CellConfig) value;
            _cellClass = (Class) table.getModel().getValueAt(row, COL_CLASS);
            
            return jBtn;
        }
        
        public Object getCellEditorValue()
        {
            return _conf;
        }
    }
    
    public BapConfigTablePanel()
    {
        _model.addColumn("Cell");
        _model.addColumn("Config");
        jTbl.setRowHeight(25);
        
        GuiUtil.setCellEditor(jTbl, COL_CONFIG, new CE_Config());
        SortButtonRenderer.setHeaderQuietly(jTbl);
        
        GuiUtil.setGridLayout(this, new JScrollPane(jTbl));
        setPreferredSize(new Dimension(640, 450));
    }
    
    public void showCells(Map<Class, CellConfig> mapConf) throws Exception
    {
        for (Entry<Class, CellConfig> ent : mapConf.entrySet())
        {
            _model.addRow(new Object[] {ent.getKey(), ent.getValue()});
        }
        
        GuiUtil.adjustTableColumnWidth(jTbl);
        _model.sortColumn(COL_CLASS, SortButtonRenderer.DOWN);
    }
    
    public Map<String, CellConfig> getConfigFromGui()
    {
        GuiUtil.stopTableEditor(jTbl);
        
        Map<String, CellConfig> mapConf = new HashMap<String, CellConfig>();
        for (int i=0;i<_model.getRowCount();i++)
        {
            Class cellClass = (Class) _model.getValueAt(i, COL_CLASS);
            CellConfig cfg = (CellConfig) _model.getValueAt(i, COL_CONFIG);
            if (cfg == null)
                continue;
            
            mapConf.put(cellClass.getName(), cfg);
        }
        
        return mapConf;
    }
}
