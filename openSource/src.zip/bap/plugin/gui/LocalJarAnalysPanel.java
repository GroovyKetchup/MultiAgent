package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.util.List;

import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.leavay.common.util.Pair;
import com.leavay.common.util.SJsonList;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;

import bap.client.BapClient;
import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import bap.yun.ArtifactUtil;
import cmn.util.NullUtil;

public class LocalJarAnalysPanel extends JPanel implements ActionAdapter
{
    public final static int COL_JAR=0;
    public final static int COL_ART_WARE=1;
    
    SortableModel _model = new SortableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }
    };
    JTable jTbl = new JTable(_model);
    
    public LocalJarAnalysPanel()
    {
        Box mainBox = Box.createVerticalBox();
        _model.addColumn("Local File");
        _model.addColumn("Possible Conflict Artifact");
        
        mainBox.add(new JScrollPane(jTbl));
        
        GuiUtil.setGridLayout(this, mainBox);
    }
    
    public SJsonList getData()
    {
        SJsonList setRet = new SJsonList();
        for (int i=0;i <_model.getRowCount();i++)
            setRet.add((String)_model.getValueAt(i, 0));
        return setRet;
    }

    public void OnAction(ActionEvent e) throws Exception
    {
    }
    
    public void showData(GlobalDependSetting gDepend) throws Exception
    {
        List<String> lstLibFiles = BapClient.getJavaIntf().scanLocalFiles("lib", "lib_ui");
        List<ArtifactWare> lstWares = ArtifactUtil.queryAllDependWare(gDepend.getLstDependArtifact());
        for (String sFile : NullUtil.get(lstLibFiles))
        {
            String lowF = sFile.toLowerCase();
            ArtifactWare possibleWare = null;
            for (ArtifactWare w : NullUtil.get(lstWares))
            {
                if (lowF.indexOf(w.getArtifactId().toLowerCase())>=0)
                {
                    possibleWare = w;
                    break;
                }
            }
            
            _model.addRow(new Object[] {sFile, possibleWare});
        }
    }
    
    public Pair<String, ArtifactWare> getSelectRow()
    {
        int row = jTbl.getSelectedRow();
        if (row < 0)
            return null;
        
        Pair<String, ArtifactWare> p = new Pair<String, ArtifactWare>();
        
        p.setLeft((String)jTbl.getValueAt(row, COL_JAR));
        p.setValue((ArtifactWare)jTbl.getValueAt(row, COL_ART_WARE));
        return p;
    }
}
