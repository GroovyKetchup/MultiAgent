package bap.plugin.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import com.leavay.client.util.MBox;
import com.leavay.client.util.CmnEvent.CmnRunnable;
import com.leavay.client.util.CmnEvent.EThreadPool;
import com.leavay.common.Exception.MultipleException;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SortButtonRenderer;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.JWaitDialog;

import bap.client.BapClient;
import bap.java.CJavaConst;
import bap.java.CJavaDebuggerDto;

public class CDebuggerMgrPanel extends JPanel implements ActionAdapter
{
    public final static String[] _header = new String[] { "Name", "Running On", "Client", "Status", "Start Time" };
    public final static int _Name=0;
    public final static int _RunningOn=1;
    public final static int _Client=2;
    public final static int _Status=3;
    public final static int _Time=4;
    

    SortButtonRenderer.SortableModel _model = new SortButtonRenderer.SortableModel();

    JTable jTbl = new JTable(_model);

    JButton jBtn_Refresh = GuiUtil.createButton("Refresh", "refresh.png", this);

    JButton jBtn_Stop = GuiUtil.createButton("Terminate", "stop_16.png", this);
    
    JCheckBox jChk_OnlyAlive = new JCheckBox("Only Alive", true);

    class StatusRenderer extends DefaultTableCellRenderer
    {
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (value instanceof Integer)
            {
                switch((int)value)
                {
                case CJavaConst.STATUS_PREPARE_RUNNING:
                case CJavaConst.STATUS_RUNNING:
                    setIcon(GuiResource.getIcon("start_16.png"));
                    break;
                case CJavaConst.STATUS_ERROR:
                    setIcon(GuiResource.getIcon("error.png"));
                    break;
                case CJavaConst.STATUS_FINISHED:
                    setIcon(GuiResource.getIcon("OK_16.png"));
                    break;
                }
                
                setText(CJavaConst.getStatusName((int)value));
            }
            
            return this;
        }
    }
    
    public CDebuggerMgrPanel()
    {
        jbInit();

        try
        {
            refresh();
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
        }
    }

    public void jbInit()
    {
        for (String s : _header)
            _model.addColumn(s);
        
        jTbl.getColumnModel().getColumn(_Status).setCellRenderer(new StatusRenderer());
        try
        {
            SortButtonRenderer.setHeader(jTbl);
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }
        
        jChk_OnlyAlive.addActionListener(new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                refresh();
            }
        });

        Box boxMain = Box.createVerticalBox();
        boxMain.add(MBox.createHBar(22, jBtn_Refresh, jBtn_Stop, MBox.HGlue(), jChk_OnlyAlive));
        boxMain.add(new JScrollPane(jTbl));
        jTbl.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e) 
            {
                if (GuiUtil.isDoubleClickLeft(e))
                    OnDbClick();
            }
        });

        setPreferredSize(new Dimension(960, 500));
        GuiUtil.setGridLayout(this, boxMain);
    }

    public void refresh() throws Exception
    {
        GuiUtil.clearTableRows(_model);

        List<CJavaDebuggerDto> lstDbg = BapClient.getJavaIntf().getAllDebugger(jChk_OnlyAlive.isSelected());
        for (CJavaDebuggerDto dbg : lstDbg)
            _model.addRow(new Object[] { dbg, dbg.getRunningOn(), dbg.getClientInfo(), dbg.getStatus(), ToolUtilities.time2String(dbg.getStartTime()) });
        
        _model.reSort();

        GuiUtil.adjustTableColumnWidth(jTbl);
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jBtn_Refresh)
            refresh();
        else if (e.getSource() == jBtn_Stop)
            OnStop();
    }

    public void OnStop() throws Exception
    {
        int[] rows = jTbl.getSelectedRows();
        if (CmnUtil.isObjectEmpty(rows))
            return;

        try
        {
            List<CJavaDebuggerDto> lstDbg = new LinkedList<CJavaDebuggerDto>();
            for (int i = 0; i<rows.length; i++)
                lstDbg.add((CJavaDebuggerDto)_model.getValueAt(i, _Name));
            
            JWaitDialog.showWaitDialog("Terminate debugger ... ", this, this, "doStop", lstDbg);
        } finally
        {
            refresh();
        }
    }
    
    public void doStop(List<CJavaDebuggerDto> lstDebugger)
    {
        try
        {
            EThreadPool pool = new EThreadPool("Stop Thread Pool", 0, 10, false);
            MultipleException mExp = new MultipleException("Failed to terminate some debugger");
            for (CJavaDebuggerDto dbg : lstDebugger)
            {
                pool.run(new CmnRunnable()
                {
                    public void run()
                    {
                        try
                        {
                            BapClient.getJavaIntf().terminateDebug(dbg.getUuid(), 10000);
                        } catch (Throwable exp)
                        {
                            mExp.addException(exp);
                        }
                    }
                });
            }

            while (pool.isAlive())
            {
                Thread.sleep(500);
            }
            mExp.tryThrowException();
        } catch (Throwable err)
        {
            ToolUtilities.throwRuntimeException(err);
        }
    }
    
    public void OnDbClick()
    {
        int row = jTbl.getSelectedRow();
        if (row < 0)
            return;
        
        CJavaDebuggerDto dbg = (CJavaDebuggerDto) _model.getValueAt(row, _Name);
        if (ToolUtilities.isStringEmpty(dbg.getErrorMsg()))
            JOptionPane.showMessageDialog(this, dbg);
        else
            DetailErrorMsg.showError(this, "Debugger Exception Message : " , dbg.getErrorMsg());
    }
}
