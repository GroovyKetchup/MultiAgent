package bap.plugin.gui;

import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;

import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.project.gui.common.GuiResource;

public class CJavaVirtualProjectProc extends CJavaProjectProc
{
    public CJavaVirtualProjectProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
    }

    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)  
    {
        pop.addSeparator();
        pop.add(jMItem_Rebuild);
        pop.addSeparator();
        pop.add(jMItem_Delete);
        pop.add(jMItem_SearchText);
    }
    
    public ImageIcon getIcon()
    {
        return GuiResource.getIcon("bap/store.png");
    }
}
