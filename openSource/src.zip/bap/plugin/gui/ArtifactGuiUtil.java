package bap.plugin.gui;

import java.awt.Component;

import com.leavay.common.Exception.UserCancelException;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.crpc.CProgressProxy;
import com.leavay.common.util.ProgressCtrl.crpc.IProgressDialog;
import com.leavay.nio.crpc.CRpcAdapter;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import bap.client.BapClient;
import bap.md.yun.GlobalDependSetting;

public class ArtifactGuiUtil
{
    // 是否完成
    public static void modifyGlobalDepend(GlobalDependSetting depData, Component parent) throws UserCancelException, Exception
    {
        if (!GuiUtil.showConfirmWarn(parent, "Are you sure to save global dependency and reload into plugin?", "Will cause republish plugin"))
            throw new UserCancelException();
        
        IProgressDialog progDlg = IProgressDialog.create(parent, "Download Artifacts And Set Global Dependency ... ");
        CProgressProxy prog = CProgressProxy.build(progDlg);
        progDlg.startWork(()->
        {
            try
            {
                CRpcAdapter.setTempTimeout(60*60*1000); // 单次调用超时设置长一点，以免下载过慢
                BapClient.getJavaIntf().saveGlobalDepend(prog, depData);
            } catch (Exception exp)
            {
                ToolUtilities.throwRuntimeException(exp);
            }
            return null;
        });
    }
    
    /**
     * @return 是否真的做了rebuild操作
     */
    public static boolean showDialogModifyGlobalDepend(String title, GlobalDependSetting depData, Component parent)
    {
        GlobalDependPanel depPanel = new GlobalDependPanel();
        depPanel.showData(depData);
        JSimpleDialog depDlg = GuiUtil.createSimpleDialog(depPanel, parent);
        depDlg.getOkButton().setText("Rebuild Dependency");
        depDlg.getOkButton().setIcon(GuiResource.getIcon("save_info_16.png"));
        GuiUtil.setFixSize(depDlg.getOkButton(), 150, 22);
        depDlg.setTitle(title);
        depDlg.setIconImage(GuiResource.getImage("warning.png"));
        while (depDlg.showModel(true))
        {
            try
            {
                final GlobalDependSetting newDep = depPanel.getDataFromGui();
                ArtifactGuiUtil.modifyGlobalDepend(newDep, GuiUtil.getWindowForComponent(parent));
                return true;
            } catch (UserCancelException cancel)
            {
                return false;
            } catch (Throwable err)
            {
                DetailErrorMsg.showError(parent, err);
                continue;
            }
        }
        return false;
    }
}
