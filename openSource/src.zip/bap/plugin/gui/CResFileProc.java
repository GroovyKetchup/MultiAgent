package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import com.cdao.dto.DaoDto;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;

import bap.client.BapClient;
import cplugin.ms.dto.CResFileDto;


public class CResFileProc extends DtoNodeProc
{

    JMenuItem jMItem_Delete = GuiUtil.createMenuItem("remove.png", "Delete", this);
    
    public CResFileProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
    }

    public boolean isLeaf()
    {
        return true;
    }

    public String getNodeLable()
    {
        return getFileDto().getFileName()+ " ("+CmnUtil.fileSize2String(getFileDto().getSize())+")";
    }
    
    public CResFileDto getFileDto()
    {
        return (CResFileDto) getDto();
    }
    
    public ImageIcon getIcon()
    {
        return GuiResource.getIcon("dev/file.png");
    }
    
    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)  
    {
        super.prepareRightMenu(pop, selNode);
        pop.addSeparator();
        
        pop.add(jMItem_Delete);
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jMItem_Delete)
            OnDelete();
    }
    
    public void OnDelete() throws Exception
    {
        if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(getTree(), "Are you sure want to delete all selected items", "", JOptionPane.YES_NO_OPTION))
            return;
        
        BapClient.getJavaIntf().deleteResFile(((DaoDto)getDto()).getGid());
        getTree().reloadData((DtoTreeNode) getNode().getParent(), true);
    }
}
