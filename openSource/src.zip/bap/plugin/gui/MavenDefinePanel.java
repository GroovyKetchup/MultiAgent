package bap.plugin.gui;

import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;

import org.dom4j.Element;

import com.leavay.client.util.MBox;
import com.leavay.common.util.ToolUtilities;
import com.project.gui.common.GuiUtil;

import art.mvn.MvnArt;

/**
 * <!-- https://mvnrepository.com/artifact/io.lettuce/lettuce-core -->
 * <dependency> <groupId>io.lettuce</groupId>
 * <artifactId>lettuce-core</artifactId> <version>6.1.3.RELEASE</version>
 * </dependency>
 * 
 */
public class MavenDefinePanel extends JPanel
{
    JTextArea jTxtXml = new JTextArea();

    JTextField jTxtGroupId = new JTextField();

    JTextField jTxtArtifactId = new JTextField();

    JTextField jTxtVersion = new JTextField();

    public MavenDefinePanel()
    {
        Box mainBox = Box.createVerticalBox();

        int w = 90;
        mainBox.add(MBox.VStrut(5));
        mainBox.add(MBox.createHBar(22, MBox.HStrut(15), GuiUtil.LeftLabel.build("Group : ", w), jTxtGroupId, MBox.HStrut(15)));
        mainBox.add(MBox.VStrut(5));
        mainBox.add(MBox.createHBar(22, MBox.HStrut(15), GuiUtil.LeftLabel.build("Artifact : ", w), jTxtArtifactId, MBox.HStrut(15)));
        mainBox.add(MBox.VStrut(5));
        mainBox.add(MBox.createHBar(22, MBox.HStrut(15), GuiUtil.LeftLabel.build("Version : ", w), jTxtVersion, MBox.HStrut(15)));
        mainBox.add(MBox.VStrut(5));
        
        JScrollPane jScrXml = new JScrollPane(jTxtXml);
        jScrXml.setMinimumSize(new Dimension(50, 120));
        jScrXml.setBorder(BorderFactory.createTitledBorder("Description"));
        
        GuiUtil.addDocumentListener(jTxtXml, (DocumentEvent e)->parseXml());
        GuiUtil.setFocuseSelectAll(jTxtXml);
        
        mainBox.add(MBox.createHBar(120, MBox.HStrut(15), jScrXml, MBox.HStrut(15)));
        mainBox.add(MBox.VStrut(5));

        GuiUtil.setGridLayout(this, mainBox);
        this.setPreferredSize(new Dimension(600, 350));
    }
    
    public void parseXml()
    {
        try
        {
            Element ele = ToolUtilities.xmlString2Dom4j(jTxtXml.getText());
            Element eleGroup = ele.element("groupId");
            if (eleGroup != null)
                jTxtGroupId.setText(eleGroup.getText());
            Element eleArtifactId = ele.element("artifactId");
            if (eleArtifactId != null)
                jTxtArtifactId.setText(eleArtifactId.getText());
            Element eleVersion = ele.element("version");
            if (eleVersion != null)
                jTxtVersion.setText(eleVersion.getText());
        }catch (Throwable err)
        {
            
        }
    }
    
    public MvnArt getDataFromGui() throws Exception
    {
        MvnArt def = new MvnArt();
        def.setGroupId(jTxtGroupId.getText().trim());
        def.setArtifactId(jTxtArtifactId.getText().trim());
        def.setVersion(jTxtVersion.getText().trim());
        return def;
    }
}
