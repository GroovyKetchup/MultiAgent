package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.io.File;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import com.cdao.mgr.CDaoClient;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.model.inf.usertype.AttachObject;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.JWaitDialog;

import bap.client.BapClient;
import bap.md.CJarFile;
import bap.md.CPluginJar;
import bap.plugin.CPluginJarDto;
import cplugin.ms.dto.CJarFileDto;
import modeldef.com.leavay.dfc.javaDev.JarFileMo;

public class CPluginJarProc extends DtoNodeProc
{

    JMenuItem jMItem_Delete = GuiUtil.createMenuItem("remove.png", "Delete", this);

    JMenuItem jMItem_ExportFile = GuiUtil.createMenuItem("dev/export.png", GuiUtil.getString("Export Files"), this);

    public CPluginJarProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
    }

    public boolean isLeaf()
    {
        return true;
    }

    public ImageIcon getIcon()
    {
        if (getDto() instanceof CPluginJarDto)
            if (((CPluginJarDto) getDto()).isPrivateOwn())
                return GuiResource.getIcon("dev/jar_lock.png");

        return GuiResource.getIcon("dev/jar_obj.gif");
    }

    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)
    {
        super.prepareRightMenu(pop, selNode);
        pop.addSeparator();

        pop.add(jMItem_Delete);
        pop.add(jMItem_ExportFile);
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jMItem_Delete)
            OnDelete();
        else if (jMItem_ExportFile.equals(e.getSource()))
            OnExportFiles();
    }

    public void OnDelete() throws Exception
    {
        if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(getTree(), "Are you sure want to delete all selected items", "", JOptionPane.YES_NO_OPTION))
            return;

        CDaoClient.getIntf().deleteDo(new CPluginJar().setUuid(getKey()));
        getTree().reloadData((DtoTreeNode) getNode().getParent(), true);
    }

    public void OnExportFiles() throws Exception
    {
        // 选择导出的目标目录
        JFileChooser flChsr = new JFileChooser();
        flChsr.setCurrentDirectory(GuiUtil.getLastFolder());
        flChsr.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (JFileChooser.APPROVE_OPTION != flChsr.showSaveDialog(getTree()))
            return;

        // 如果目标不存在，则创建
        File selFolder = flChsr.getSelectedFile();
        if (selFolder == null || !selFolder.exists())
            return;
        GuiUtil.setLastFolder(selFolder);

        if (false)
            doExportFiles(selFolder);
        JWaitDialog.showWaitDialog(GuiUtil.getString("Export Files"), getTree(), this, "doExportFiles", selFolder);
    }

    public void doExportFiles(File folder) throws Exception
    {
        List<DtoTreeNode> selNodes = getTree().getSelectedNodes();
        if (ToolUtilities.isObjectEmpty(selNodes))
            return;

        for (DtoTreeNode node : selNodes)
        {
            if (!(node.getDto() instanceof CPluginJarDto))
                continue;

            CPluginJarDto jar = (CPluginJarDto) node.getDto();
            CJarFile jarDo = (CJarFile) CDaoClient.getIntf().getDo(jar.getGid());
            ToolUtilities.saveFile(folder.getAbsolutePath() + "/" + jar.getName(), jarDo.getFileBin(), false);
        }
    }
}
