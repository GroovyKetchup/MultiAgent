package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.util.LinkedList;
import java.util.List;
import java.util.Timer;

import com.leavay.client.util.EventQ.GuiEvent;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.ms.cmn.DtoIntf;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;

import bap.client.BapClient;
import bap.client.BapGuiConst;
import bap.client.BapGuiUtil;
import bap.java.CJavaCode;
import bap.plugin.CPluginRootDto;
import kafka.utils.timer.TimerTaskEntry;

public class CJavaTreeView extends DtoTreeView
{
    public final static String VDO_ROOT = "VDO_ROOT";
    DtoTreeNode _root;
    
    public final static String VDO_PROJECT_ROOT = "VDO_PROJECT_ROOT";
    static DtoIntf _projectRootDto = new DtoIntf()
    {
        public String getKey()
        {
            return VDO_PROJECT_ROOT;
        }
        
        public String toString()
        {
            return "Java Project";
        }
    };

    public void initGuiEventLsnr()
    {
        super.initGuiEventLsnr();
        
        BapGuiUtil.addListener(BapGuiConst.JAVA_CODE_SAVED, this, "OnJavaSaved");

        BapGuiUtil.addListener(BapGuiConst.SHOW_CJAVA_CODE_IN_TREE, this, "OnSelectInTree");
    }
    
    public void jbInit()
    {
        super.jbInit();

        // 极其特殊的功能，间隔一定时间刷新插件根节点等
        new Thread("Java Tree Timer") {
            public void run()
            {
                for(;;)
                {
                    try
                    {
                        refreshPluginRootNode();
                        
                        ToolUtilities.sleep(5000);
                    }catch (Throwable err)
                    {
                        err.printStackTrace();
                    }
                    
                    if (!GuiUtil.isComponentVisible(CJavaTreeView.this))
                        return;
                }
            }
        }.start();

        try
        {
            OnRefresh();
            GuiUtil.expandTreeLater(getTree(), getRootNode(), 1);
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }
    }
    
    public void initVirtualNode()
    {
        _root = new DtoTreeNode(new DtoIntf()
        {
            public String getKey()
            {
                return VDO_ROOT;
            }
        });
    }
    
    public void initFactory()
    {
        factory = new CPluginTreeFactory(this);
    }
    
    public DtoTreeNode getRootNode()
    {
        return _root;
    }
    
    public List<DtoIntf> getChlidList(DtoTreeNode node) throws Exception
    {
        if (_root == node)
        {
            List lst = new LinkedList();
            try
            {
                lst.add(BapClient.getPluginIntf().getRootDto());
            }catch(Throwable err)
            {
                err.printStackTrace();
            }
            
            lst.add(_projectRootDto);
            
            return lst;
        }
        else
            return super.getChlidList(node);
    }
    
    public void OnJavaSaved(GuiEvent e) throws Exception
    {
        CJavaCode code = (CJavaCode) e.getParam(0);
        DtoTreeNode codeNode = findNodeByKey(null, code.getKey());
        DtoTreeNode project = findNodeByKey(null, code.getProjectUuid());
        
        if (codeNode != null)
        {
            if (project != null)
            {
                ((CJavaProjectProc)getProc(project)).reloadChildCompileStastic();
            }
            
            return;
        }
        
        // 没有代码节点或者没展开，则reload整个工程（主要用于新增代码）
        if (project == null)
            return;
        
        reloadData(project, true);
    }
    
    public void OnSelectInTree(GuiEvent e)
    {
        String[] path = (String[]) e.getParams();
        
        DtoTreeNode leafNode = locateNodeByPath(path);
        if (leafNode != null)
        {
            selectNodeLater(leafNode, true);
        }
    }
    
    public void refreshPluginRootNode() throws Exception
    {
        DtoTreeNode node = findNodeByClass(getRootNode(), CPluginRootDto.class);
        if (node == null)
            return;
        
        CPluginRootDto dto = (CPluginRootDto) node.getDto();
        CPluginRootDto newRoot = BapClient.getPluginIntf().getRootDto();
        if (dto.getGid().equals(newRoot.getGid())
                && ToolUtilities.isEqual(dto.getTimeTag(), newRoot.getTimeTag())
                && dto.isDirty() == newRoot.isDirty()
                && ToolUtilities.isStringEqual(dto.getDirtyMessage(), newRoot.getDirtyMessage(), true))
            return;
        
        updateNode(node, newRoot);
    }
            
}
