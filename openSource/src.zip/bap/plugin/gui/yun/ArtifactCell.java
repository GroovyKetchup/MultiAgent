package bap.plugin.gui.yun;

import com.leavay.dfc.gui.graph.base.DefaultCell;
import com.mxgraph.model.mxGeometry;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.swing.util.mxCellOverlay;
import com.mxgraph.util.mxConstants;
import com.mxgraph.util.mxUtils;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;

import bap.md.yun.ArtifactWare;

public class ArtifactCell extends DefaultCell
{
    ArtifactWare art;
    boolean conflict = false;
    
    boolean preferPrior = false;
    
    public ArtifactCell(ArtifactWare art, boolean isConflict, boolean preferPrior)
    {
        super(art.getArtifactKey());
        
        this.art = art;
        setConflict(isConflict);
        setPreferPrior(preferPrior);

        int w = GuiUtil.getTextWidth(getLabel(), false);
        setGeometry(new mxGeometry(0, 0, Math.max(30, w), 32));
        initCellStyle();
    }

    public ArtifactWare getArtifact()
    {
        return art;
    }
    
    public boolean isConflict()
    {
        return conflict;
    }

    public void setConflict(boolean conflict)
    {
        this.conflict = conflict;
    }

    public boolean isPreferPrior()
    {
        return preferPrior;
    }

    public void setPreferPrior(boolean preferPrior)
    {
        this.preferPrior = preferPrior;
    }

    public void initCellStyle(boolean blVertical)
    {
        setVertex(true);
        setStyle(mxUtils.setStyle(getStyle(), mxConstants.STYLE_SHAPE, mxConstants.SHAPE_RECTANGLE));
        
        if (isPreferPrior())
            setStyle(mxUtils.setStyle(getStyle(), mxConstants.STYLE_FILLCOLOR, "#A8FF2E"));
        
        if (isConflict())
        {
            if (isPreferPrior())
                setStyle(mxUtils.setStyle(getStyle(), mxConstants.STYLE_FILLCOLOR, "#A8FF2E"));
            else
                setStyle(mxUtils.setStyle(getStyle(), mxConstants.STYLE_FILLCOLOR, "#FFA82E"));
        }
    }

    public void initOverlay(mxGraphComponent graphCmp, boolean isLayoutVertical)
    {

        graphCmp.removeCellOverlays(this);
        
        if (isPreferPrior())
        {
            mxCellOverlay priorOverlay = new mxCellOverlay(GuiResource.getIcon("OK_16.png"), "High Priority");
            priorOverlay.setAlign(mxConstants.ALIGN_LEFT); // 控制角标横向方位
            priorOverlay.setVerticalAlign(mxConstants.ALIGN_BOTTOM);// 控制角标纵向方位
            graphCmp.addCellOverlay(this, priorOverlay);
        }
    }

    public String getImagePath(boolean blVertical)
    {
        return "images/dfc/s.png";
    }

    public String getLabel()
    {
        return art==null?"":art.toString();
    }
    
    public String getToolTip()
    {
        if (isConflict())
            return "Conflict with others";
        else
            return art+"";
    }

    public String getKey()
    {
        return (String)getValue();
    }
}
