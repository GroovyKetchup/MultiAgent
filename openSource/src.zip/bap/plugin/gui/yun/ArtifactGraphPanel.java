package bap.plugin.gui.yun;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SJsonMap;
import com.leavay.dfc.gui.Draw2dLayouterEx;
import com.leavay.dfc.gui.graph.base.DefaultCell;
import com.leavay.dfc.gui.graph.base.DefaultLink;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.swing.handler.mxRubberband;
import com.mxgraph.view.mxGraph;
import com.project.gui.common.GuiUtil;

import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.yun.ArtifactConst;
import bap.yun.ArtifactUtil;
import cell.bap.yun.ArtifactGraph;

/**
 * 云组件依赖图谱浏览器
 */
public class ArtifactGraphPanel extends JPanel
{

    public mxGraph graph = null;

    public mxGraphComponent graphCmp = null;
    
    DefaultListModel<ArtifactDefine> model = new DefaultListModel<ArtifactDefine>();
    public JList<ArtifactDefine> jListArts = new JList(model);
    public JSplitPane jSpl = new JSplitPane();
    
    public ArtifactGraphPanel()
    {
        initGraph();
        
        JScrollPane scrList = new JScrollPane(jListArts);
        scrList.setBorder(BorderFactory.createTitledBorder("Final Dependency Table"));
        jSpl.setLeftComponent(scrList);
        jSpl.setRightComponent(graphCmp);
        jSpl.setDividerLocation(180);
        
        GuiUtil.setGridLayout(this, jSpl);
        GuiUtil.setPreferredSize(this, 1024, 440);
    }
    
    ArtifactGraph _data;
    SJsonMap _pref;
    
    public void showData(ArtifactGraph data, SJsonMap preferSetting) throws Exception
    {
        _data = data;
        _pref = preferSetting;
        
        Set<String> setConflictArt = data.analyseConflict().keySet();
        
        graph.getModel().beginUpdate();
        try
        {
            graph.removeAll();
            
            Map<String, ArtifactCell> mapCells = new HashMap();
            for (ArtifactWare art : data.getArtifacts().values())
            {
                boolean conflict = setConflictArt.contains(art.getArtifactId());
                boolean prefPrior = ArtifactUtil.isPreferPrior(art.getArtifactKey(), preferSetting);
                    
                ArtifactCell cell = new ArtifactCell(art, conflict, prefPrior);
                cell = (ArtifactCell) graph.addCell(cell);
                mapCells.put(art.getUuid(), cell);
            }
            
            for (Entry<String, Set<String>> ent  : data.getRelations().getAllSource2Target().entrySet())
            {
                ArtifactCell src = mapCells.get(ent.getKey());
                for (String dst : ent.getValue())
                {
                    ArtifactCell dstCell = mapCells.get(dst);
                    DefaultLink lnk = new DefaultLink(src, dstCell);
                    graph.addCell(lnk);
                }
            }
        }finally
        {
            graph.getModel().endUpdate();
        }
        

        layoutGraph();
        
        // 刷列表
        refreshList();
    }
    
    public void refreshList()
    {
        model.clear();
        
        SJsonMap prefMap = getPreferSetting();
        List<ArtifactCell> lstCells = graph.getAllCells(ArtifactCell.class);
        List<ArtifactWare> lstArts = new LinkedList<ArtifactWare>();
        for (ArtifactCell cell : lstCells)
            lstArts.add(cell.getArtifact());
        
        Collection<ArtifactDefine> lstResult = ArtifactUtil.mergeConflictList((List)lstArts, prefMap);
        for (ArtifactDefine def : lstResult)
            model.addElement(def);
    }
    
    public void initGraph()
    {
        // Init graph, set tooltip redirector
        graph = new mxGraph()
        {
            public String getToolTipForCell(Object cell)
            {
                if (cell instanceof DefaultCell)
                    return ((DefaultCell) cell).getToolTip();

                return super.getToolTipForCell(cell);
            }

            public String getCellLabel(Object cell)
            {
                if (cell instanceof DefaultCell)
                    return ((DefaultCell) cell).getCellLabel();

                return super.getCellLabel(cell);
            }

            public void cellsAdded(Object[] cells, Object parent, Integer index, Object source, Object target, boolean absolute)
            {
                super.cellsAdded(cells, parent, index, source, target, absolute);

                if (cells != null)
                {
                    for (int i = 0; i < cells.length; ++i)
                    {
                        if (cells[i] != null && cells[i] instanceof DefaultCell)
                        {
                            ((DefaultCell) cells[i]).initOverlay(getGraphComponent());
                        }
                    }
                }
            }

        };

        graph.setKeepEdgesInForeground(true);

        // Init graph component, set mouse listener to monitor start editing
        // event
        // Capture stop editing event , so that program can do something you
        // want
        graphCmp = new mxGraphComponent(graph)
        {
            public boolean isEditEvent(MouseEvent e)
            {
                return false;
            }
      
        };

        // Init select rectangle track listener
        final mxRubberband rubberband = new mxRubberband(graphCmp);

        // Disable auto connect from one source Cell
        // When toggle "create link" on, this variable should be set as true
        graphCmp.setConnectable(false);

        graph.setCellsResizable(true);
        graph.setCellsDisconnectable(false);

        graphCmp.setBackground(Color.white);
        graphCmp.setOpaque(true);
        graphCmp.setBorder(BorderFactory.createEmptyBorder());
        graphCmp.getGraphControl().setBorder(BorderFactory.createEmptyBorder());
        graphCmp.getViewport().setOpaque(false);

        graphCmp.getVerticalScrollBar().setUnitIncrement(30);
        graphCmp.getHorizontalScrollBar().setUnitIncrement(30);

        graphCmp.setGridVisible(true);
        //
        graphCmp.setToolTips(true);

        graphCmp.getGraphControl().addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e)
            {
                try
                {
                    if (e.getClickCount() >= 2)
                    {
                        OnDbClickCell(e);
                    }
                    e.consume();
                } catch (Exception exp)
                {
                    DetailErrorMsg.showError(exp);
                }
            }
        });
    }
    
    public void OnDbClickCell(MouseEvent e)
    {
        ArtifactCell cell = (ArtifactCell) graph.getSelectionCell();
        cell.setPreferPrior(!cell.isPreferPrior());
        cell.updateGraph(graph);
        
        refreshList();
    }
    
    public void layoutGraph() throws Exception
    {
        // 计算所有顺序链路，自动忽略掉死循环回路
        Draw2dLayouterEx layouter = new Draw2dLayouterEx(graph)
        {
            public int calcWidth(DefaultCell cell, int hSpace)
            {
                if (cell.getGeometry() != null)
                    return (int) cell.getGeometry().getWidth() + hSpace;

                return super.calcWidth(cell, hSpace);
            }

            public int calcHeight(DefaultCell cell, int vSpace)
            {
                if (cell.getGeometry() != null)
                    return (int) cell.getGeometry().getHeight() + vSpace;

                return super.calcHeight(cell, vSpace);
            }
        };
      
        layouter.doLayout(true, true, 10, 50);
    }

    public SJsonMap getPreferSetting()
    {
        SJsonMap map = new SJsonMap();
        List<ArtifactCell> lstCells = graph.getAllCells(ArtifactCell.class);
        if (lstCells != null)
            for (ArtifactCell c : lstCells)
            {
                if (c.isPreferPrior())
                    map.put(c.getArtifact().getArtifactKey(), ArtifactConst.PREFER_TYPE_PRIOR);
            }
        
        return map;
    }
}
