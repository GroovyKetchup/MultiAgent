package bap.plugin.gui.yun;

import javax.swing.Box;

import com.cdao.gui.CDoEditor;
import com.cdao.mgr.CDaoMappingField;
import com.leavay.common.util.ToolBasic;

import bap.md.yun.ArtifactWare;

public class ArtifactWareDetailPanel extends CDoEditor
{
    private static final long serialVersionUID = 7045843856017272991L;
    public ArtifactWareDetailPanel()
    {
        super(false);
    }
    
    public int getLabelWidth()
    {
        return 60;
    }
    public int getRightGap()
    {
        return 10;
    }

    public boolean isAttEditable(CDaoMappingField f)
    {
        return false;
    }

    public Box buildForeignBox() throws Exception
    {
        return Box.createHorizontalBox();
    }

    public Box buildSlave2MasterBox() throws Exception
    {
        return Box.createHorizontalBox();
    }
    
    String[] fields = new String[] {ArtifactWare.GroupId, ArtifactWare.ArtifactId, ArtifactWare.Version, ArtifactWare.MainPage, ArtifactWare.Description, ArtifactWare.PublishTime, ArtifactWare.Commiter};
    public boolean isAttrVisible(CDaoMappingField f)
    {
        if (super.isAttrVisible(f))
        {
            if (ToolBasic.contains(fields, f.getName()))
                return true;
        }
        
        return false;
    }
}
