package bap.plugin.gui.yun;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.nutz.dao.Cnd;

import com.cdao.dto.CPager;
import com.leavay.client.util.MBox;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ProgressCtrl.crpc.CProgressProxy;
import com.leavay.common.util.ProgressCtrl.crpc.IProgressDialog;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.project.gui.common.JSimplePagePanel;
import com.project.gui.common.JWaitDialog;
import com.project.gui.common.MouseAdapter;
import com.project.gui.common.component.JTextField_Search;

import bap.client.BapClient;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.plugin.gui.ArtifactDefinePanel;
import bap.yun.ArtifactPackage;
import bap.yun.YunStoreAgent;
import bap.yun.util.ArtWareMigrationTool;
import cell.bap.yun.ArtifactGraph;
import cell.bap.yun.IYunStore;
import cmn.security.dto.UserPassword;
import cmn.util.Nulls;

/**
 * 云组件列表浏览器
 */
public class YunArtifactTablePanel extends JPanel implements ActionAdapter
{
    public JTextField_Search jTxtCond = new JTextField_Search();

    public JButton jBtnPublishYun = GuiUtil.createToolButton("add.gif", "Publish Artifact Manually", this);
    public JButton jBtnExportJars = GuiUtil.createToolButton("export.png", "Export Selected Artifact Files", this);
    public JButton jBtnDelete = GuiUtil.createToolButton("remove_all.png", "Delete Selected Artifacts And All Dependencies", this);
    public JButton jBtnQueryDependMe = GuiUtil.createToolButton("search_16.png", "Query All Dependencies", this);
    
    JSplitPane jSpl = new JSplitPane();
    public ArtifactWareDetailPanel jDetail = new ArtifactWareDetailPanel();
    public DefaultListModel<ArtifactWare> _model = new DefaultListModel<ArtifactWare>();
    public JList<ArtifactWare> jList = new JList<ArtifactWare>(_model);
    public JSimplePagePanel jPager = new JSimplePagePanel()
    {
        public void showData(List lstData)
        {
            _model.clear();
            for (Object o : lstData)
                _model.addElement((ArtifactWare) o);
        }
        
        protected MultiPageResult CallBack_LoadPage(int iStartPos, int iPageSize) throws Exception
        {
            return queryPage(iStartPos, iPageSize);
        }

        public void showError(Throwable err)
        {
            DetailErrorMsg.showError(this, err);
        }
    };
    
    public Cnd getCondition()
    {
        Cnd cnd = Cnd.NEW();
        
        String filter = jTxtCond.getText();
        if (!CmnUtil.isStringEmpty(filter))
        {
            filter = ToolUtilities.replaceAll(filter, "*", "%");
            filter = "%"+filter+"%";
            filter = ToolUtilities.replaceAll(filter, "%%", "%");
            cnd = cnd.where("LOWER("+ArtifactWare.ArtifactId+")", "like", filter.toLowerCase());
        }
        
        cnd.orderBy(ArtifactWare.ArtifactId, "asc").orderBy(ArtifactWare.GroupId, "asc").orderBy(ArtifactWare.PublishTime, "desc");
        
        return cnd;
    }
    
    public String getRowText(ArtifactWare art)
    {
        return art==null?"":art.toString();
    }

    // 当前界面获取云仓库接口
    public IYunStore getIntf()
    {
        return getIntfWrapper().getIntf();
    }

    // 当前界面获取云仓库接口
    public CRpcClientWrapper<IYunStore> getIntfWrapper()
    {
        return YunStoreAgent.get().getIntfWrapper();
    }
    
    // 统一登录云仓库的入口
    public UserPassword loginYunStore() throws Exception
    {
        return BapClient.getMe().loginYunStore(this);
    }
    
    public YunArtifactTablePanel()
    {
        jTxtCond.setHintText("Input * or name of artifact to search ... ");
        Box mainBox = MBox.createVerticalBox();
        
        Box leftBox = MBox.createVerticalBox();
        leftBox.add(MBox.hBar(22, jTxtCond, MBox.HGlue(), jBtnPublishYun, jBtnExportJars, jBtnQueryDependMe, jBtnDelete));
        jList.setCellRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(
                    JList<?> list,
                    Object value,
                    int index,
                    boolean isSelected,
                    boolean cellHasFocus)
            {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value != null && value instanceof ArtifactWare)
                {
                    ArtifactWare art = (ArtifactWare)value;
                    setText(getRowText(art));
                }
                return this;
            }
        });
        leftBox.add(new JScrollPane(jList));
        leftBox.add(jPager);
        
        jSpl.setLeftComponent(leftBox);
        jSpl.setRightComponent(jDetail);
        jSpl.setDividerLocation(500);
        mainBox.add(MBox.hBar(jSpl));
        
        GuiUtil.setFocuseSelectAll(jTxtCond);
        GuiUtil.setKeyAction(jTxtCond, KeyEvent.VK_ENTER, 0, new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                jPager.refreshCurrentPage();
            }
        });
        GuiUtil.addDoubleClickListener(jList, new MouseAdapter()
        {
            public void onAction(MouseEvent e) throws Exception
            {
                OnDbClickTable();
            }
        });
        jList.getSelectionModel().addListSelectionListener(new ListSelectionListener()
        {
            
            public void valueChanged(ListSelectionEvent e)
            {
                if (e.getValueIsAdjusting())
                    return;
                
                OnSelChange();
            }
        });
        
        
        GuiUtil.setGridLayout(this, mainBox);
        GuiUtil.setPreferredSize(this, 960, 400);
    }
    
    public void showData()
    {
        jPager.refreshCurrentPage();
    }
    
    public void showDataLater()
    {
        GuiUtil.invokeLater(()->showData());
    }
    
    public ArtifactWare getSelect()
    {
        return CmnUtil.getFirst(jList.getSelectedValuesList());
    }
    
    public List<ArtifactWare> getSelects()
    {
        return jList.getSelectedValuesList();
    }
    
    public void OnSelChange()
    {
        ArtifactWare art = jList.getSelectedValue();
        try
        {
            art = queryDetail(art);
            jDetail.showData(CmnUtil.assertNotNull(art, "Artifact is invalid or removed"));
            GuiUtil.updateUILater(jDetail);
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }
    }
    
    public void OnDbClickTable() throws Exception
    {
        ArtifactWare art = jList.getSelectedValue();
        if (art == null)
            return;
        
        ArtifactGraph graph = queryGraph(art);
        if (graph == null)
            return;
        
        ArtifactGraphPanel graphPanel = new ArtifactGraphPanel();
        graphPanel.showData(graph, null);
        JSimpleDialog dlg =  GuiUtil.createSimpleDialog(graphPanel, this);
        dlg.setTitle("Artifact : " + art);
        dlg.showModel(false);
    }
    
    public void OnQueryDependMe() throws Exception
    {
        List<ArtifactWare> lst = getSelects();
        if (Nulls.isEmpty(lst))
            return;

        HashSet<String> setUuids = new HashSet<String>();
        lst.forEach((a)->setUuids.add(a.getUuid()));
        ArtifactGraph graph =  getIntf().queryDependByGraph(setUuids, true);
        if (graph == null)
            return;
        
        ArtifactGraphPanel graphPanel = new ArtifactGraphPanel();
        graphPanel.showData(graph, null);
        JSimpleDialog dlg =  GuiUtil.createSimpleDialog(graphPanel, this);
        dlg.setTitle("Who depend on Artifact");
        dlg.showModel(false);
    }
    
    // 涉及到远程调用的统统单独提出来，有些客户端要直连云仓库
    public MultiPageResult<ArtifactWare> queryPage(int iStartPos, int iPageSize) throws Exception
    {
        return getIntf().queryArtifact(getCondition(), CPager.build(iStartPos, iPageSize), ArtifactWare.FIELDS_BRIEF);
    }
    
    public ArtifactWare queryDetail(ArtifactWare art) throws Exception
    {
        return getIntf().queryArtifact(art.getGroupId(), art.getArtifactId(), art.getVersion(), false);
    }
    
    public  ArtifactGraph queryGraph(ArtifactWare art) throws Exception
    {
        return getIntf().queryDependGraph(ToolBasic.newHashSet(art.getUuid()), true);
    }

    public void OnPublishStore() throws Exception
    {
        UserPassword user = loginYunStore();
        if (user == null)
            return;
        
        ArtifactPackage pkg = editArtifactPackage();
        if (pkg == null)
            return;
        
        if (false) getIntf().publishArtifact(pkg, user);
        JWaitDialog.showWaitDialog("Release to YUN store ... " , this, getIntf(), "publishArtifact", pkg, user);
    }
    
    public void OnDelete() throws Exception
    {
        UserPassword user = loginYunStore();
        if (user == null)
            return;
        
        List<ArtifactWare> lst = getSelects();
        if (Nulls.isEmpty(lst))
            return;
        
        HashSet<String> setUuids = new HashSet<String>();
        lst.forEach((a)->setUuids.add(a.getUuid()));
        ArtifactGraph graph =  getIntf().queryDependByGraph(setUuids, true);
        if (graph == null)
            return;
        
        ArtifactGraphPanel graphPanel = new ArtifactGraphPanel();
        graphPanel.jSpl.setLeftComponent(new JLabel(""));
        graphPanel.jSpl.setDividerLocation(1);
        graphPanel.showData(graph, null);
        JSimpleDialog dlg =  GuiUtil.createSimpleDialog(graphPanel, this);
        dlg.getOkButton().setText("Delete All Above !!!");
        dlg.getOkButton().setFont(new Font("Dialog", 0, 16));
        dlg.getOkButton().setForeground(new Color(225, 80, 110));
        GuiUtil.setFixSize(dlg.getOkButton(), 150, 22);
        dlg.getOkButton().setMinimumSize(new Dimension(250, 22));
        dlg.setTitle("You will delete all these artifacts. Are you sure???");
        if (dlg.showModel(true))
        {
            int rows = 0;
            for (ArtifactWare art : Nulls.get(lst)) {
                rows += getIntf().deleteArtifact(user, art.getGroupId(), art.getArtifactId(), art.getVersion());
            }
            showDataLater();
            
            JOptionPane.showMessageDialog(this, "Deleted artifacts : " + rows);
        }
    }
    
    public void OnExportJars() throws Exception
    {
        ArtWareMigrationTool tool = new ArtWareMigrationTool(getIntfWrapper(), null);
        tool.setSrcUser(loginYunStore());
        
        List<ArtifactWare> lst = getSelects();
        Set<String> set = new HashSet();
        for (ArtifactWare w : Nulls.get(lst))
            set.add(w.getUuid());
        
        File lastFd = GuiUtil.getLastFolder();
        JFileChooser flChsr = new JFileChooser();
            flChsr.setCurrentDirectory(lastFd);
        flChsr.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (JFileChooser.APPROVE_OPTION != flChsr.showSaveDialog(this))
            return;

        File sel = flChsr.getSelectedFile();
        GuiUtil.setLastFolder(sel);

        IProgressDialog progDlg = IProgressDialog.create(this, "Export Artifacts Release Files With Dependency ... ");
        CProgressProxy prog = CProgressProxy.build(progDlg);
        progDlg.startWork(()->
        {
            try
            {
                CRpcAdapter.setTempTimeout(60*60*1000); // 单次调用超时设置长一点，以免下载过慢
                tool.exportJarsWithDepends(prog, sel, (List)lst);
            } catch (Exception exp)
            {
                ToolUtilities.throwRuntimeException(exp);
            }
            return null;
        });
    }
    
    ArtifactPackage _pkg;
    public ArtifactPackage editArtifactPackage() throws Exception
    {
        if (_pkg == null)
        {
            _pkg = new ArtifactPackage();
            ArtifactDefine def = new ArtifactDefine();
            def.setGroupId("free.open");
            def.setArtifactId("artifactName");
            def.setVersion("1.0.0");
            
            _pkg.setArtifactDefine(def);
        }
        
        ArtifactDefinePanel defPanel = new ArtifactDefinePanel();
        AttachListPanel fileListPanel = new AttachListPanel();
        defPanel.setPreferredSize(new Dimension(1000, 370));
        fileListPanel.setPreferredSize(new Dimension(1000, 230));
        fileListPanel.setBorder(BorderFactory.createTitledBorder("Release Package : "));
        
        defPanel.showData(_pkg.getArtifactDefine());
        fileListPanel.showValue(_pkg.getReleasePkg());

        Box mainBox = MBox.createVBar(Integer.MAX_VALUE, defPanel, fileListPanel);
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(mainBox, this);
        dlg.setTitle("Edit Artifact Info");
        while (dlg.showModel(true))
        {
            try
            {
                ArtifactDefine def = defPanel.getDataFromGui();
                _pkg.setArtifactDefine(def);
                _pkg.setReleasePkg(fileListPanel.getValue());
                
                return _pkg;
            }catch(Throwable err)
            {
                DetailErrorMsg.showError(this, err);
                continue;
            }
        }
        return null;
    }

    @Override
    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jBtnPublishYun)
            OnPublishStore();
        else if (e.getSource() == jBtnExportJars)
            OnExportJars();
        else if (e.getSource() == jBtnQueryDependMe)
            OnQueryDependMe();
        else if (e.getSource() == jBtnDelete)
            OnDelete();
    }
 }
