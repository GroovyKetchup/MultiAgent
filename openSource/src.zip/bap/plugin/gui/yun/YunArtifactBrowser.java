package bap.plugin.gui.yun;

import com.cdao.dto.CPager;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.MultiPage.MultiPageResult;

import bap.md.yun.ArtifactWare;
import bap.yun.YunStoreAgent;
import cell.bap.yun.ArtifactGraph;

public class YunArtifactBrowser extends YunArtifactTablePanel
{
   
    public MultiPageResult<ArtifactWare> queryPage(int iStartPos, int iPageSize) throws Exception
    {
        return YunStoreAgent.getIntf().queryArtifact(getCondition(), CPager.build(iStartPos, iPageSize), ArtifactWare.FIELDS_BRIEF);
    }
    
    public ArtifactWare queryDetail(ArtifactWare art) throws Exception
    {
        return YunStoreAgent.getIntf().queryArtifact(art.getGroupId(), art.getArtifactId(), art.getVersion(), false);
    }
    
    public  ArtifactGraph queryGraph(ArtifactWare art) throws Exception
    {
        return YunStoreAgent.getIntf().queryDependGraph(ToolBasic.newHashSet(art.getUuid()), true);
    }
}
