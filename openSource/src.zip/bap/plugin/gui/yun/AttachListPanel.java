package bap.plugin.gui.yun;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.cdao.gui.attCtrl.JRichDocumentEditor;
import com.cdao.mgr.CDaoClient;
import com.cdao.model.CDoAttach;
import com.cdao.model.type.RichDocument;
import com.leavay.client.util.MBox;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SortButtonRenderer;
import com.leavay.common.util.ToolUtilities;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import cmn.util.Nulls;

public class AttachListPanel extends JPanel implements ActionAdapter
{
    public final static String[] HEADER = new String[] {"Attach File"};
    
    SortButtonRenderer.SortableModel _model;
    JTable jTable;
    
    JButton jBtnUploadFile;
    JButton jBtnDownload;
    JButton jBtnDelete;

    JButton jBtnNewDocument;
    JButton jBtnOpenAsDoc;
    
    public AttachListPanel()
    {
        jbInit();
    }

    public void jbInit()
    {
        _model = new SortButtonRenderer.SortableModel(){
            public boolean isCellEditable(int row, int column)
            {
                return false;
            }
        };
        jTable = new JTable(_model);
        for (String s : HEADER)
            _model.addColumn(s);
        
        jBtnUploadFile = GuiUtil.createButton("Upload", null, this);
        jBtnDownload = GuiUtil.createButton("Download", null, this);
        jBtnDelete = GuiUtil.createButton("Delete", null, this);
        jBtnNewDocument = GuiUtil.createButton("New Document", null, this);
        jBtnOpenAsDoc = GuiUtil.createButton("Open As Document", null, this);
        
        Box box = MBox.createVerticalBox();
        box.add(MBox.createHBar(22, jBtnUploadFile, jBtnDownload, jBtnDelete, MBox.HGlue(), jBtnNewDocument, jBtnOpenAsDoc));
        box.add(new JScrollPane(jTable));
        
        GuiUtil.setGridLayout(this, box);
        this.setPreferredSize(new Dimension(200, 400));
    }
    
    // 传入为null或者List<CDoAttach>
    public void showValue(List<CDoAttach> lstAtt) throws Exception
    {
        GuiUtil.clearTableRows(_model);
        
        
        for (CDoAttach att : Nulls.get(lstAtt))
            _model.addRow(new Object[] {att});
    }
    
    public List<CDoAttach> getValue() throws Exception
    {
        List<CDoAttach> lstAtc = new LinkedList<CDoAttach>();
        for (int row =0; row<_model.getRowCount(); row++)
        {
            lstAtc.add((CDoAttach) _model.getValueAt(row, 0));
        }
        return lstAtc;
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jBtnUploadFile)
            OnBtnUpload();
        else if (e.getSource() == jBtnDownload)
            OnBtnDownload();
        else if (e.getSource() == jBtnDelete)
            OnBtnDelete();
        else if (e.getSource() == jBtnNewDocument)
            OnAddDocument();
        else if (e.getSource() == jBtnOpenAsDoc)
            OnEditDocument();
    }

    public void OnBtnUpload() throws IOException
    {
        JFileChooser flDlg = new JFileChooser();
        flDlg.setSelectedFile(GuiUtil.getLastFolder());
        if (JFileChooser.CANCEL_OPTION == flDlg.showOpenDialog(GuiUtil.getWindowForComponent(this)))
            return;
        
        File fl = flDlg.getSelectedFile();
        if (fl == null)
            return;
        
        GuiUtil.setLastFolder(fl);
        FileInputStream flIn = new FileInputStream(fl);
        try
        {
            CDoAttach dto = new CDoAttach();
            dto.setName(fl.getName());
            dto.setDescript(fl.getAbsolutePath());
            dto.setBin(ToolUtilities.readFile(fl.getAbsolutePath()));
            
            dto.setDirty(true);
            _model.addRow(new Object[] {dto});
        } finally
        {
            flIn.close();
        }
    }
    
    
    public void OnBtnDownload() throws Exception
    {
        int[] rows = jTable.getSelectedRows();
        if (rows == null)
            return;
        
        JFileChooser flDlg = new JFileChooser();
        flDlg.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        flDlg.setSelectedFile(GuiUtil.getLastFolder());
        if (JFileChooser.CANCEL_OPTION == flDlg.showSaveDialog(GuiUtil.getWindowForComponent(this)))
            return;

        File fl = flDlg.getSelectedFile();
        if (fl == null)
            return;
        GuiUtil.setLastFolder(fl);
        
        for (int i=0;i<rows.length;i++)
        {
            CDoAttach atc = (CDoAttach) _model.getValueAt(rows[i], 0);
            
            byte[] bt = null;
            if (atc.isDirty())
            {
                bt = atc.isBinary()?atc.getContentBin():atc.getContentText().getBytes();
            }
            else
            {
                CDoAttach atcDo = CDaoClient.getIntf().queryAttach(atc.getPKey(), atc.getPField(), atc.getName());
                bt = atcDo.isBinary()?atcDo.getContentBin():atcDo.getContentText().getBytes();
            }
            
            ToolUtilities.saveFile(fl.getAbsolutePath()+"/"+atc.getName(), bt, false);
        }
    }

    public void OnBtnDelete()
    {
        GuiUtil.deleteTableRows(_model, jTable.getSelectedRows());
    }
    
    public void OnAddDocument() throws Exception
    {
        JRichDocumentEditor editor = new JRichDocumentEditor();

        JSimpleDialog dlg = GuiUtil.createSimpleDialog(editor, this);
        dlg.pack();
        GuiUtil.adjustWindowInsideScreen(dlg);
        if (!dlg.showModel(true))
            return;

        CDoAttach o = new CDoAttach();
        o.setName("RichDocument");
        o.setBin(ToolUtilities.serialize(editor.getDataFromGui()));
        o.setDirty(true);
        _model.addRow(new Object[] { o });
    }
    
    public void OnEditDocument() throws Exception
    {
        int row = jTable.getSelectedRow();
        if (row < 0)
            return;
        
        RichDocument doc = null;
        try
        {
            // 强制假设所选附件就是一个RichDocument
            CDoAttach atc = (CDoAttach) _model.getValueAt(row, 0);
            byte[] bt = null;
            if (atc.isDirty())
                bt = atc.getContentBin();
            else
            {
                CDoAttach atcDo = CDaoClient.getIntf().queryAttach(atc.getPKey(), atc.getPField(), atc.getName());
                bt = atcDo.getContentBin();
            }
            doc = (RichDocument) ToolUtilities.unserialize(bt);
        }catch(Throwable err)
        {
            DetailErrorMsg.showError(err);
            return;
        }
        
        JRichDocumentEditor editor = new JRichDocumentEditor();
        editor.showDoc(doc);
        
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(editor, this);
        dlg.pack();
        GuiUtil.adjustWindowInsideScreen(dlg);
        
        if (!dlg.showModel(true))
            return;
        
        CDoAttach o = new CDoAttach();
        o.setName("RichDocument");
        o.setBin(ToolUtilities.serialize(editor.getDataFromGui()));
        o.setDirty(true);
        _model.setValueAt(o, row, 0);
    }
}
