package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.ListSelectionModel;
import javax.tools.Tool;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.crpc.CProgressProxy;
import com.leavay.common.util.ProgressCtrl.crpc.IProgressDialog;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.ms.cmn.DtoIntf;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.project.gui.common.GuiUtil.JUserMenuItem;

import bap.client.BapClient;
import bap.client.BapGuiUtil;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.plugin.CPluginProjectDto;
import bap.plugin.CPluginRootDto;
import bap.plugin.gui.yun.YunArtifactTablePanel;
import cmn.security.dto.UserPassword;
import cmn.util.Nulls;

public class CPluginRootProc extends DtoNodeProc
{

    JMenuItem jMItem_NewProject = GuiUtil.createMenuItem("add.gif", "New Project", this);

    JMenuItem jMItem_InstallYunArtifact = GuiUtil.createMenuItem("undo.gif", "Install Artifact From Store", this);
    
    JMenuItem jMItem_ScanConflict = GuiUtil.createMenuItem("bap/compare.png", "Scan Conflict Classes", this);

    public CPluginRootProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
    }

    public boolean isLeaf()
    {
        return false;
    }

    public ImageIcon getIcon()
    {
        if (((CPluginRootDto) getDto()).isDirty())
            return GuiResource.getIcon("warning.png");
        else
            return GuiResource.getIcon("dev/jar_catalog.png");
    }

    public List<DtoIntf> getChildList() throws Exception
    {
        return (List) BapClient.getPluginIntf().getProjects();
    }

    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)
    {
        super.prepareRightMenu(pop, selNode);
        pop.addSeparator();

        pop.add(jMItem_NewProject);
        pop.add(jMItem_InstallYunArtifact);
        pop.add(jMItem_ScanConflict);

        try
        {
            // 获取已安装的列表，作为移除选项
            List<ArtifactDefine> lstArts = BapClient.getJavaIntf().queryInstalledArtifacts(false);
            if (Nulls.isNotEmpty(lstArts))
            {
                JMenu menu = new JMenu("Remove Installed Artifact");
                for (ArtifactDefine art : lstArts)
                {
                    JUserMenuItem item = new GuiUtil.JUserMenuItem(art.getGroupId()+"/"+art.getArtifactId()+"("+art.getVersion()+")");
                    item.setActionCommand("remove");
                    item.setUserObject(art);
                    item.addActionListener(this);
                    menu.add(item);
                }
                pop.add(menu);
            }
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
        }

    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if ("remove".equals(e.getActionCommand()))
            OnUninstallArt((ArtifactDefine) ((JUserMenuItem) e.getSource()).getUserObject());
        if (e.getSource() == jMItem_NewProject)
            OnNew();
        else if (e.getSource() == jMItem_InstallYunArtifact)
            OnInstallFromStore();
        else if (e.getSource() == jMItem_ScanConflict)
            OnScanConflictJars();
    }

    public String getNodeLable()
    {
        CPluginRootDto rtDto = (CPluginRootDto) getDto();

        if (rtDto.isDirty())
        {
            if (Nulls.isNotEmpty(rtDto.getDirtyMessage()))
                return rtDto.getDirtyMessage();
            else
                return BapGuiUtil.getString("There are some dirty files need to be published!");
        }

        return rtDto.toString();
    }

    public void reloadThis(boolean reloadChild) throws Exception
    {
        CPluginRootDto newRoot = BapClient.getPluginIntf().getRootDto();
        getTree().updateNode(getNode(), newRoot);

        super.reloadThis(reloadChild);
    }

    public void OnNew() throws Exception
    {
        String name = JOptionPane.showInputDialog(getTree(), "Input name of project");
        if (CmnUtil.isStringEmpty(name))
            return;

        CPluginProjectDto pjDto = BapClient.getPluginIntf().createProject(name);
        reloadThis(true);
    }

    public void OnInstallFromStore() throws Exception
    {
        UserPassword user = BapClient.getMe().loginYunStore(getTree());
        if (user == null)
            return;
        
        // 尝试登录云仓库
        BapClient.getJavaIntf().loginYunStore(user);
        
        YunArtifactTablePanel panel = new YunArtifactTablePanel();
        panel.jList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panel.showDataLater();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, getTree());
        dlg.setTitle(BapClient.getJavaIntf().getYunStoreUri());
        if (!dlg.showModel(true))
            return;
        ArtifactWare impArt = panel.getSelect();
        if (impArt == null)
            return;

        try
        {
            IProgressDialog progDlg = IProgressDialog.create(getTree(), "Import Artifact ... ");
            progDlg.startRpcWork(60 * 60, (CProgressProxy prog) -> {
                // 发生了依赖变化，需要Rebuild全局依赖
                try
                {
                    BapClient.getJavaIntf().installArtifact(prog, impArt.toDefine(), 5*60*1000);
                } catch (Exception exp)
                {
                    ToolUtilities.throwRuntimeException(exp);
                }
                return null;
            });

        } finally
        {
            reloadThis(true);
        }
    }
    
    public void OnScanConflictJars() throws Exception
    {
        IProgressDialog progDlg = IProgressDialog.create(getTree(), "Import Artifact ... ");
        Map<String, List<ClassNameInfo>> mapConflict = progDlg.startRpcWork(60 * 60, (CProgressProxy prog) -> {
            // 发生了依赖变化，需要Rebuild全局依赖
            try
            {
                return BapClient.getJavaIntf().scanConflictPluginClass(prog);
            } catch (Exception exp)
            {
                ToolUtilities.throwRuntimeException(exp);
            }
            return null;
        });

        if (Nulls.isEmpty(mapConflict))
        {
            JOptionPane.showMessageDialog(getTree(), "No Conflict");
        }else
        {
            // key ：jar-path1 - jar-path2
            // value ：这个包下冲突的所有类
            Map<String, List<String>> sys2plugin = new HashMap();
            for (List<ClassNameInfo> c : mapConflict.values())
            {
                String key = c.get(0).getSrcPath() +"  -->  "+c.get(1).getSrcPath();
                ToolUtilities.putMapList(sys2plugin, key, c.get(0).getClassFullName());
            }
            
            String jarList = ToolUtilities.logString(sys2plugin.keySet(), true);
            DetailErrorMsg.showMessage(getTree(), "Found conflict class in plugin : \n"+ jarList, "Conflict jar list:\n"+ToolUtilities.logString(sys2plugin.keySet(), true)+"\n====Detail:=====\n"+ToolUtilities.logString(sys2plugin, true), "Error", JOptionPane.ERROR_MESSAGE, true);
        }
      }

    public void OnUninstallArt(ArtifactDefine art) throws Exception
    {
        try
        {
            IProgressDialog progDlg = IProgressDialog.create(getTree(), "Uninstall Artifact ... ");
            progDlg.startRpcWork(60 * 60, (CProgressProxy prog) -> {
                // 发生了依赖变化，需要Rebuild全局依赖
                try
                {
                    BapClient.getJavaIntf().uninstallArtifact(prog, art, 60*1000);
                } catch (Exception exp)
                {
                    ToolUtilities.throwRuntimeException(exp);
                }
                return null;
            });

        } finally
        {
            reloadThis(true);
        }
    }

}
