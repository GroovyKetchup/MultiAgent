package bap.plugin.gui;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.cdao.gui.CDaoPackageTree;
import com.cdao.gui.CDaoPackageTree.CDmTreeNode;
import com.cdao.gui.attCtrl.JIconChoosePanel;
import com.cdao.gui.attCtrl.JRichDocumentEditor;
import com.cdao.impl.entity.field.SlaveTable;
import com.cdao.model.type.RichDocument;
import com.leavay.client.util.MBox;
import com.leavay.common.util.SJsonList;
import com.leavay.common.util.SJsonMap;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.project.gui.common.cmp.SJsonMapPanel;

import bap.client.BapClient;
import bap.client.BapGuiUtil;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.plugin.gui.yun.ArtifactGraphPanel;
import bap.plugin.gui.yun.YunArtifactTablePanel;
import cell.bap.yun.ArtifactGraph;
import cmn.security.dto.UserPassword;
import cmn.util.NullUtil;
import cmn.util.Nulls;
import gui.cmn.component.JUserInputPanel;

// 对某个工程设定其Artifact信息，以及依赖信息
public class ArtifactDefinePanel extends JPanel implements ActionAdapter
{
    JTextField jTxtGroupId = new JTextField();
    JTextField jTxtArtifactId = new JTextField();
    JTextField jTxtVersion = new JTextField();
    JTextArea jTxtDesc = new JTextArea();

    public final static String[] HEADER = new String[]{"GroupID", "ArtifactID", "Version"};
    public final static int COL_GROUP = 0;
    public final static int COL_ART = 1;
    public final static int COL_VER = 2;
    
    public JButton jBtnAdd = GuiUtil.createToolButton("add.gif", "Add Dependency", this);
    public JButton jBtnImport = GuiUtil.createButton("Import From Store", "redo_16.png", this);
    public JButton jBtnRemove = GuiUtil.createToolButton("remove.png", "Remove Dependency", this);
    public JButton jBtnCheckDepend = GuiUtil.createToolButton("dfc/medical_16.png", "Check Dependency", this);

    public JButton jBtnAddModel = GuiUtil.createToolButton("add.gif", "Add Model", this);
    public JButton jBtnRemoveModel = GuiUtil.createToolButton("remove.png", "Remove Model", this);
    public JIconChoosePanel jIcon = new JIconChoosePanel();
    
    public JRichDocumentEditor jMainPage = new JRichDocumentEditor();
    
    public SJsonMapPanel jExtPanel = new SJsonMapPanel();
    
    SortableModel _model = new SortableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return true;
        }
    };
    JTable jTbl = new JTable(_model);
    
    // 专属模型列表
    DefaultListModel<String> _modelModel = new DefaultListModel<String>();
    JList<String> jLstModel = new JList(_modelModel);
    
    public ArtifactDefinePanel()
    {
        Box mainBox = Box.createVerticalBox();
        
        int w = 90;
        Box basicBox = Box.createVerticalBox();
        basicBox.add(MBox.VStrut(5));
        basicBox.add(MBox.createHBar(22, MBox.HStrut(15), GuiUtil.LeftLabel.build("Group : " , w), jTxtGroupId, MBox.HStrut(15)));
        basicBox.add(MBox.VStrut(5));
        basicBox.add(MBox.createHBar(22, MBox.HStrut(15), GuiUtil.LeftLabel.build("Artifact : " , w), jTxtArtifactId, MBox.HStrut(15)));
        basicBox.add(MBox.VStrut(5));
        basicBox.add(MBox.createHBar(22, MBox.HStrut(15), GuiUtil.LeftLabel.build("Version : " , w), jTxtVersion, MBox.HStrut(15)));
        basicBox.add(MBox.VStrut(5));

        JScrollPane jScrDesc = new JScrollPane(jTxtDesc);
        jScrDesc.setMinimumSize(new Dimension(50, 120));
        jScrDesc.setBorder(BorderFactory.createTitledBorder("Description"));
        basicBox.add(MBox.createHBar(120, MBox.HStrut(15), jScrDesc, MBox.HStrut(15)));
        
        jIcon.setPreferredSize(new Dimension(320, 120));
        mainBox.add(MBox.hBar(150, basicBox, jIcon));
        mainBox.add(MBox.VStrut(5));
        
        
        Box boxDep = Box.createVerticalBox();
        boxDep.add(MBox.hBar(22, jBtnAdd, jBtnImport, MBox.HSeperator(), jBtnRemove, MBox.HGlue(), jBtnCheckDepend));
        for (String s : HEADER)
            _model.addColumn(s);
        boxDep.add(MBox.hBar(new JScrollPane(jTbl)));

        Box boxMd = Box.createVerticalBox();
        boxMd.add(MBox.hBar(22, jBtnAddModel, jBtnRemoveModel, MBox.HGlue()));
        boxMd.add(MBox.hBar(new JScrollPane(jLstModel)));
        
        JTabbedPane jTab = new JTabbedPane();
        jTab.addTab("Dependency Setting", boxDep);
        jTab.addTab("Exclusive Model List", boxMd);
        jTab.addTab("Main Page", jMainPage);
        jTab.addTab("Extend", jExtPanel);
        mainBox.add(jTab);
        
        GuiUtil.setGridLayout(this, mainBox);
        this.setPreferredSize(new Dimension(800, 480));
    }
    
    ArtifactDefine _def;
    public void showData(ArtifactDefine def) throws Exception
    {
        _def = def;
        
        jTxtGroupId.setText(def.getGroupId());
        jTxtArtifactId.setText(def.getArtifactId());
        jTxtVersion.setText(def.getVersion());
        jTxtDesc.setText(def.getDescription());
        
        if (Nulls.isNotEmpty(def.getIconImg()))
            jIcon.showData(GuiUtil.imageFromByte(def.getIconImg()));
        
        GuiUtil.clearTableRows(_model);
        if (def.getDependTo() != null)
            for (ArtifactDefine dep : def.getDependTo())
            {
                _model.addRow(new Object[] {dep.getGroupId(), dep.getArtifactId(), dep.getVersion()});
            }
        
        _modelModel.clear();
        SJsonList lstMd = def.getExclusiveModelList();
        if (lstMd != null)
            for (String s : lstMd)
            _modelModel.addElement(s);
        
        RichDocument doc = null;
        if (!CmnUtil.isObjectEmpty(def.getMainPage()))
            doc = (RichDocument) ToolUtilities.unserialize(def.getMainPage());
        jMainPage.showDoc(doc);
        
        jExtPanel.showData(def.getExtendDataMap());
    }
    
    public ArtifactDefine getDataFromGui() throws Exception
    {
        ArtifactDefine def = ToolUtilities.clone(_def);
        def.setGroupId(jTxtGroupId.getText().trim());
        def.setArtifactId(jTxtArtifactId.getText().trim());
        def.setVersion(jTxtVersion.getText().trim());
        def.setDescription(jTxtDesc.getText().trim());
        def.setIconImg(GuiUtil.imageIcon2Byte(jIcon.getIcon()));

        GuiUtil.stopTableEditor(jTbl);
        SlaveTable< ArtifactDefine> lstDep = new SlaveTable<ArtifactDefine>();
        for (int i =0; i<_model.getRowCount(); i++)
        {
            ArtifactDefine dep = new ArtifactDefine();
            dep.setGroupId(CmnUtil.getString(_model.getValueAt(i, COL_GROUP), null, true));
            dep.setArtifactId(CmnUtil.getString(_model.getValueAt(i, COL_ART), null, true));
            dep.setVersion(CmnUtil.getString(_model.getValueAt(i, COL_VER), null, true));
            lstDep.add(dep);
        }
        def.setDependTo(lstDep);
        
        SJsonList lst = new SJsonList();
        for (int i = 0; i<_modelModel.getSize(); i++)
            lst.add(_modelModel.get(i));
        def.setExclusiveModelList(lst.isEmpty()?null:lst);
        
        RichDocument doc = jMainPage.getDataFromGui();
        def.setMainPage(doc==null?null:ToolBasic.serializeEx(doc));
        
        SJsonMap map = jExtPanel.getValue();
        if (Nulls.isEmpty(map))
            def.setExtendData(null);
        else
            def.setExtendData(map.toJson());
        
        return def;
    }

    public void OnAdd()
    {
        _model.addRow(new Object[] {});
    }
    
    public void OnImport() throws Exception
    {
        UserPassword user = BapClient.getMe().loginYunStore(this);
        if (user == null)
            return;
        
        // 尝试登录云仓库
        BapClient.getJavaIntf().loginYunStore(user);
        
        YunArtifactTablePanel panel = new YunArtifactTablePanel();
        panel.showData();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, this);
        dlg.setTitle(BapClient.getJavaIntf().getYunStoreUri());
        if (!dlg.showModel(true))
            return;
        
        List<ArtifactWare> lstWares = panel.getSelects();
        if (lstWares != null)
            for (ArtifactWare art : lstWares)
                _model.addRow(new Object[] {art.getGroupId(), art.getArtifactId(), art.getVersion()});
    }
    
    public void OnRemove()
    {
        GuiUtil.removeTableRow(_model, jTbl.getSelectedRows());
    }
    
    public void OnCheckDepend() throws Exception
    {
        ArtifactDefine def = getDataFromGui();
        SlaveTable<ArtifactDefine> lstDep = def.getDependTo();
        if (CmnUtil.isObjectEmpty(lstDep))
        {
            JOptionPane.showMessageDialog(this, "No Dependency");
            return;
        }
        
        Set<String> setArtUuids = new HashSet();
        for (ArtifactDefine dep : lstDep)
        {
            ArtifactWare art = BapClient.getJavaIntf().queryYunArtifact(dep.getGroupId(), dep.getArtifactId(), dep.getVersion(), false, ArtifactWare.FIELDS_BRIEF);
            CmnUtil.assertNotNull(art, "Can not find artifact in YUN store : " + dep);
            setArtUuids.add(art.getUuid());
        }
        
        ArtifactGraph depGraph = BapClient.getJavaIntf().queryYunDependGraph(setArtUuids, true);
        ArtifactGraphPanel panel = new ArtifactGraphPanel();
        panel.showData(depGraph, null);
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, this);
        dlg.setTitle("Check Dependency");
        dlg.showModel(false);
    }
    
    public void OnAddModel()
    {
        CDaoPackageTree tree = new CDaoPackageTree();
        tree.reload();
        
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(tree);
        if (!dlg.showModel(true))
            return;

        for (CDmTreeNode node : NullUtil.get(tree.getSelectedNodes()))
            _modelModel.addElement(node.getClassName());
    }
    
    public void OnRemoveModel()
    {
        List<String> lstSel = jLstModel.getSelectedValuesList();
        if (lstSel != null)
            for (String s : lstSel)
                _modelModel.removeElement(s);
    }
    
    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jBtnAdd)
            OnAdd();
        else if (e.getSource() == jBtnImport)
            OnImport();
        else if (e.getSource() == jBtnRemove)
            OnRemove();
        else if (e.getSource() == jBtnCheckDepend)
            OnCheckDepend();
        else if (e.getSource() == jBtnAddModel)
            OnAddModel();
        else if (e.getSource() == jBtnRemoveModel)
            OnRemoveModel();
    }
}
