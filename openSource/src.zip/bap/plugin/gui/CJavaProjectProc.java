package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.io.File;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.leavay.ms.cmn.DtoIntf;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.project.gui.common.JWaitDialog;

import bap.client.BapClient;
import bap.client.BapGuiConst;
import bap.client.BapGuiUtil;
import bap.java.CJavaConst;
import bap.java.CJavaFolderDto;
import bap.java.CJavaGuiCompilable;
import bap.java.CJavaProjectDto;
import bap.md.java.CJavaLibFolderDto;
import bap.md.java.CJavaProject;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.GlobalDependSetting;
import bap.plugin.CPluginProjectDto;
import bap.plugin.CPluginRootDto;
import bap.plugin.gui.yun.YunArtifactTablePanel;
import bap.yun.ArtifactUtil;
import cmn.security.dto.UserPassword;
import cplugin.ms.dto.CJarFileDto;

public class CJavaProjectProc extends DtoNodeProc
{

    JMenuItem jMItem_NewSourceFolder = GuiUtil.createMenuItem("add.gif", "New Folder", this);
    JMenuItem jMItem_Delete = GuiUtil.createMenuItem("remove.png", "Delete", this);
    JMenuItem jMItem_Rebuild = GuiUtil.createMenuItem("dev/compile_16.png", "Rebuild", this);
    JMenuItem jMItem_Publish = GuiUtil.createMenuItem("dev/publish.png", "Global Publish Plugin", this);
    JMenuItem jMItem_GrayPublishQuick = GuiUtil.createMenuItem("bap/engineer_16.png", "Gray Publish (Quick)", this);
    JMenuItem jMItem_GrayPublish = GuiUtil.createMenuItem("bap/engineer_16.png", "Gray Publish (Fully)", this);
    JMenuItem jMItem_SearchText = GuiUtil.createMenuItem("search.png", GuiUtil.getString("Search Text In Code"), this);

    JMenuItem jMItem_ImportJar = GuiUtil.createMenuItem("importZip.png", GuiUtil.getString("Import Jar Files"), this);

    JMenu jMItem_DependType = new JMenu("Depend Type");
    
    JMenuItem jMItem_SetArtifactInfo = GuiUtil.createMenuItem("bap/artifact.png", "Set Artifact Info", this);
    JMenuItem jMItem_QueryYunStore = GuiUtil.createMenuItem("bap/searchStore.png", "Explore In Store", this);
    JMenuItem jMItem_PublishYunStore = GuiUtil.createMenuItem("bap/store.png", "Release To Store", this);
    
    public CJavaProjectProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
    }

    public boolean isLeaf()
    {
        return false;
    }
    
    public ImageIcon getIcon()
    {
        if (getProject().isDependPlugin())
            return GuiResource.getIcon("bap/project_plugin.png");
        else if (getProject().isDependPlatform())
            return GuiResource.getIcon("bap/project_platform.png");
        else if (getProject().isUdfLib())
            return GuiResource.getIcon("dev/function.png");
        else
            return GuiResource.getIcon("dev/project_java.png");
    }
    
    public List<DtoIntf> getChildList() throws Exception
    {
        List lstRet = new LinkedList();
        ToolUtilities.combineList(lstRet, BapClient.getJavaIntf().getFolders(getKey()));
        if (BapClient.getJavaIntf().hasJarFiles(getKey()))
            lstRet.add(new CJavaLibFolderDto());
        
        return lstRet;
    }
    
    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)  
    {
        super.prepareRightMenu(pop, selNode);
        if (CJavaConst.isSysProject(getKey()))
            return;
        
        // 生成变更依赖类型的菜单
        jMItem_DependType.setIcon(GuiResource.getIcon("service.png"));
        JCheckBoxMenuItem jMItem_Dep_Platform = new JCheckBoxMenuItem("Depend Platform (Default)", GuiResource.getIcon("flag_blue3_16.png"), getProject().isDependPlatform());
        JCheckBoxMenuItem jMItem_Dep_Isolate = new JCheckBoxMenuItem("Isolate", GuiResource.getIcon("flag_red_16.png"), getProject().isDependIsolate());
        JCheckBoxMenuItem jMItem_Dep_Plugin = new JCheckBoxMenuItem("Depend Plugin (Debug)", GuiResource.getIcon("warning.png"), getProject().isDependPlugin());
        JCheckBoxMenuItem jMItem_Udf = new JCheckBoxMenuItem("UDF Library", GuiResource.getIcon("dev/function.png"), getProject().isUdfLib());
        
        jMItem_Dep_Platform.addActionListener(new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                OnChangeDependType(CJavaConst.DEPEND_PLATFORM);
            }
        });
        
        jMItem_Dep_Isolate.addActionListener(new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                OnChangeDependType(CJavaConst.DEPEND_ISOLATE);
            }
        });
        
        jMItem_Dep_Plugin.addActionListener(new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                OnChangeDependType(CJavaConst.DEPEND_PLUGIN);
            }
        });
        jMItem_Udf.addActionListener(new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                OnChangeDependType(CJavaConst.UDF_LIB);
            }
        });
        jMItem_DependType.add(jMItem_Dep_Platform);
        jMItem_DependType.add(jMItem_Dep_Isolate);
        jMItem_DependType.add(jMItem_Dep_Plugin);
        jMItem_DependType.addSeparator();
        jMItem_DependType.add(jMItem_Udf);
        
        pop.addSeparator();
        pop.add(jMItem_NewSourceFolder);
        pop.add(jMItem_ImportJar);
        pop.add(jMItem_Delete);
        pop.add(jMItem_SearchText);
        pop.addSeparator();
        pop.add(jMItem_DependType);
        pop.addSeparator();
        pop.add(jMItem_SetArtifactInfo);
        pop.add(jMItem_QueryYunStore);
        pop.add(jMItem_PublishYunStore);
        pop.addSeparator();
//        pop.add(jMItem_GrayPublishQuick);
//        pop.add(jMItem_GrayPublish);
//        pop.addSeparator();
        pop.add(jMItem_Rebuild);
        pop.add(jMItem_Publish);
    }
    
    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jMItem_NewSourceFolder)
            OnNew();
        else if (e.getSource() == jMItem_ImportJar)
            OnImportJar();
        else if (e.getSource() == jMItem_Rebuild)
            OnRebuild();
        else if (e.getSource() == jMItem_GrayPublishQuick)
            OnGrayPublish(false);
        else if (e.getSource() == jMItem_GrayPublish)
            OnGrayPublish(true);
        else if (e.getSource() == jMItem_Publish)
            OnPublish();
        else if (e.getSource() == jMItem_SearchText)
            OnSearchText();
        else if (e.getSource() == jMItem_Delete)
            OnDelete();
        else if (e.getSource() == jMItem_SetArtifactInfo)
            OnEditArtifact();
        else if (e.getSource() == jMItem_QueryYunStore)
            OnQueryStore();
        else if (e.getSource() == jMItem_PublishYunStore)
            OnPublishStore();
    }
    
    public CJavaProjectDto getProject()
    {
        return (CJavaProjectDto) getDto();
    }
    
    public void OnDelete() throws Exception
    {
        if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(getTree(), GuiUtil.getString("Are you sure want to delete all selected items"), "", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE))
            return;
        
        BapClient.getJavaIntf().deleteProject(getProject().getGid());
        GuiUtil.removeTreeNode(getTree().getTree(), getNode());
    }
    
    public void OnNew() throws Exception
    {
        String name = JOptionPane.showInputDialog(getTree(), "Input name of project");
        if (CmnUtil.isStringEmpty(name))
            return;
        
        CJavaFolderDto fd = BapClient.getJavaIntf().createFolder(getProject().getGid(), name);
        reloadThis(true);
    }
    
    public void OnRebuild() throws Exception
    {
        BapClient.getJavaIntf().rebuildAll(getKey());
        
        reloadThisLater(true, 0);
    }
    
    public void OnGrayPublish(boolean rebuildAll) throws Exception
    {
        BapClient.getJavaIntf().grayPublish(getKey(), rebuildAll);

        JOptionPane.showMessageDialog(getTree(), "Succeed to gray publish this project!");
    }
    
    public void OnPublish() throws Exception
    {
        CPluginProjectDto plgProject = BapClient.getJavaIntf().exportProject2Plugin(getKey(), null, true, false);

        DtoTreeNode plgRoot = getTree().findNodeByClass(getTree().getRootNode(), CPluginRootDto.class);
        if (plgRoot == null)
            return;

        GuiUtil.expandTree(getTree().getTree(), plgRoot, 0);
        DtoTreeNode plgNode = getTree().findNodeByKey(null, plgProject.getKey());
        if (plgNode != null)
            getTree().selectNodeLater(plgNode, true);
    }
    
    public void OnPublishStore() throws Exception
    {
        UserPassword user = BapClient.getMe().loginYunStore(getTree());
        if (user == null)
            return;
        
        ArtifactDefine def = editArtifact();
        if (def == null)
            return;
        
        if (false) BapClient.getJavaIntf().publishYunStore(getKey(), user);
        JWaitDialog.showWaitDialog("Release to YUN store ... " , getTree(), BapClient.getJavaIntf(), "publishYunStore", getKey(), user);
    }
    
    public void OnEditArtifact() throws Exception
    {
        GlobalDependSetting orgDep = BapClient.getJavaIntf().queryGlobalDepends();
        
        ArtifactDefine newDef = editArtifact();
        
        // 前后对比是否发生了依赖变化，如果有则提示重建依赖
        GlobalDependSetting newDep = BapClient.getJavaIntf().queryGlobalDepends();
        if (!ArtifactUtil.isArtifactListSame(orgDep.getLstDependArtifact(), newDep.getLstDependArtifact()))
        {
            ArtifactGuiUtil.showDialogModifyGlobalDepend("Recommend to rebuild changed dependency", newDep, getTree());
        }
    }
    
    public ArtifactDefine editArtifact() throws Exception
    {
        ArtifactDefine def = BapClient.getJavaIntf().getArtifactInfo(getKey());
        if (def == null)
        {
            def = new ArtifactDefine();
            def.setGroupId("free.open");
            def.setArtifactId(getProject().getName());
            def.setVersion("1.0.0");
            def.setForeignGid(getProject().getGid());
        }
        
        ArtifactDefinePanel panel = new ArtifactDefinePanel();
        panel.showData(def);
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, getTree());
        dlg.setTitle("Edit Artifact Info");
        while (dlg.showModel(true))
        {
            try
            {
                def = panel.getDataFromGui();
                return BapClient.getJavaIntf().saveArtifactInfo(def);
            }catch(Throwable err)
            {
                DetailErrorMsg.showError(getTree(), err);
                continue;
            }
        }
        return null;
    }
    
    public void OnQueryStore() throws Exception
    {
        YunArtifactTablePanel panel = new YunArtifactTablePanel();
        panel.showDataLater();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, getTree());
        dlg.setTitle(BapClient.getJavaIntf().getYunStoreUri());
        dlg.showModel(false);
    }
    
    public void reloadChildCompileStastic()
    {
       reloadChildCompileStastic(getNode());
       
    }
    
    public void reloadChildCompileStastic(DtoTreeNode pNode)
    {
        for (int i=0; i<pNode.getChildCount();i++)
        {
            DtoTreeNode child = (DtoTreeNode)pNode.getChildAt(i);
            if (child.getDto() instanceof CJavaGuiCompilable)
            {
                ((CJavaGuiCompilable)child.getDto()).setCompileStastic(null);
                GuiUtil.refreshTreeNode(getTree().getTree(), child);
            }
            
            reloadChildCompileStastic(child);
        }
    }
    
    public void OnSearchText()
    {
        BapGuiUtil.fireAsyncGuiEvent(BapGuiConst.SEARCH_TEXT_IN_CJAVA_CODE, getProject().getUuid(), "");
    }
    
    public void OnChangeDependType(int type) throws Exception
    {
        Map<String, Object> mapV = new HashMap();
        mapV.put(CJavaProject.DependType, type);
        
        CJavaProjectDto newDto = BapClient.getJavaIntf().updateProject(getProject().getGid(), mapV);
        getTree().updateNode(getNode(), newDto);
        getTree().reloadData(getNode(), true);
    }
    
    public void OnImportJar() throws Exception
    {
        // 选择导出的目标目录
        JFileChooser flChsr = new JFileChooser();
        flChsr.setCurrentDirectory(GuiUtil.getLastFolder());
        flChsr.setFileSelectionMode(JFileChooser.FILES_ONLY);
        flChsr.setMultiSelectionEnabled(true);
        if (JFileChooser.APPROVE_OPTION != flChsr.showOpenDialog(getTree()))
            return;
        
        // 如果目标不存在，则创建
        File[] selFiles = flChsr.getSelectedFiles();
        if (selFiles== null || ToolUtilities.isArrayEmpty(selFiles))
            return;
        GuiUtil.setLastFolder(selFiles[0]);
        
        GuiUtil.setWaitCursor(getTree());
        try
        {
            for (File fl : selFiles)
            {
                if (fl.isFile() && fl.canRead())
                {
                    byte[] bts = ToolUtilities.readFile(fl.getAbsolutePath());
                    CJarFileDto jar = new CJarFileDto();
                    jar.setFile(fl.getName(), bts);
                    
                    BapClient.getJavaIntf().importJarFile(getProject().getGid(), jar);
                }
            }
            
            getTree().reloadData(getNode(), true);
        }finally
        {
            GuiUtil.setDefaultCursor(getTree());
        }
    }
}
