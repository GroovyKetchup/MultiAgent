package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.CompileStastic;
import com.leavay.dfc.gui.dto.DtoNodeProc;
import com.leavay.dfc.gui.dto.DtoTreeNode;
import com.leavay.dfc.gui.dto.DtoTreeView;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.vlsolutions.swing.docking.Dockable;

import bap.client.BapClient;
import bap.java.CJavaCode;
import bap.java.CJavaConst;
import bap.java.CJavaEditor;
import bap.java.CJavaProjectDto;
import bap.java.CodeMeta;
import bap.udf.CUdfUtil;
import bap.udf.UdfMeta;
import cell.UdfIntf;

public class CJavaCodeProc extends DtoNodeProc
{

    JMenuItem jMItem_Delete = GuiUtil.createMenuItem("remove.png", GuiUtil.getString("Delete"), this);
    JMenuItem jMItem_SetMeta = GuiUtil.createMenuItem("doc.png", GuiUtil.getString("Set Meta"), this);

    public CJavaCodeProc(DtoTreeView parentTree, DtoTreeNode node)
    {
        super(parentTree, node);
        
        if (getCodeDto().getCompileStastic() == null)
        {
            try
            {
                CompileStastic cmpSts = BapClient.getJavaIntf().getStastic(getCodeDto().getProjectUuid(), getCodeDto().getOwner(), getCodeDto().getFullClassName());
                if (cmpSts == null)
                    cmpSts = new CompileStastic(getKey());
                getCodeDto().setCompileStastic(cmpSts);
            } catch (Throwable err)
            {
                err.printStackTrace();
            }
        }
    }

    public boolean isLeaf()
    {
        return true;
    }

    public ImageIcon getIcon()
    {
        if (getCodeDto().getCompileStastic() != null)
        {
            if (getCodeDto().getCompileStastic().getError() > 0)
                return GuiResource.getIcon("dev/java_error.png");
            else if (getCodeDto().getCompileStastic().getWarn() > 0)
                return GuiResource.getIcon("dev/java_warn.png");
        }
        return GuiResource.getIcon("dev/java.png");
    }
    
    public void prepareRightMenu(JPopupMenu pop, List<DtoTreeNode> selNode)  
    {
        super.prepareRightMenu(pop, selNode);
        if (CJavaConst.isSysCode(getKey()))
            return;
        
        pop.addSeparator();
        
        pop.add(jMItem_Delete);
        pop.add(jMItem_SetMeta);
    }

    public Dockable getDetailPanel() throws Exception
    {
        CJavaCode code = (CJavaCode) getDto();
        CJavaEditor editorV = new CJavaEditor();
        editorV.showCode(code.getProjectUuid(), code.getFullClassName());
        return editorV;
    }
    
    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jMItem_Delete)
            OnDelete();
        else if (e.getSource() == jMItem_SetMeta)
            OnSetMeta();
    }
    
    public String getNodeLable()
    {
        CJavaCode rtDto = (CJavaCode) getDto();
        
        return rtDto.getMainClass();
    }
    
    public CJavaCode getCodeDto()
    {
        return (CJavaCode) getDto();
    }
    
    public void OnDelete() throws Exception
    {
        if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(getTree(), GuiUtil.getString("Are you sure want to delete all selected items"), "", JOptionPane.YES_NO_OPTION))
            return;
        
        List<DtoTreeNode> lstNodes = getTree().getSelectedNodes();
        Set<String> delClasses = new TreeSet();
        for (DtoTreeNode node : lstNodes)
        {
            CJavaCode code = (CJavaCode) node.getDto();
            if (code.isReadOnly())
                continue;
            
            delClasses.add(code.getFullClassName());
        }
        if (ToolUtilities.isObjectEmpty(delClasses))
            return;
        
        BapClient.getJavaIntf().deleteCode(getCodeDto().getProjectUuid(), delClasses);
        for (DtoTreeNode node : lstNodes)
            GuiUtil.removeTreeNode(getTree().getTree(), node);
    }

    public void OnSetMeta() throws Exception
    {
        String cls = getCodeDto().getFullClassName();
        CJavaProjectDto pj = BapClient.getJavaIntf().getProject(getCodeDto().getProjectUuid());
        if (pj.isUdfLib() && UdfIntf.isUdfPackage(getCodeDto().getPackage()))
        {
            UdfMeta udfMeta = BapClient.getJavaIntf().queryUdfMeta(getCodeDto().getProjectUuid(), cls);
            if (udfMeta == null)
                udfMeta = new UdfMeta();
            UdfMetaPanel panel = new UdfMetaPanel();
            panel.showData(getCodeDto(), udfMeta);
            JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel);
            if (!dlg.showModel(true))
                return;
            UdfMeta newMeta = panel.getMetaFromGui();
            BapClient.getJavaIntf().saveCodeMeta(cls, newMeta, true);
        }else
        {
            CodeMeta meta = BapClient.getJavaIntf().getCodeMeta(getCodeDto().getFullClassName());
            if (meta == null)
                meta = new CodeMeta();
            
            CodeMetaPanel panel = new CodeMetaPanel();
            panel.showData(getCodeDto(), meta);
            JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel);
            if (!dlg.showModel(true))
                return;
            CodeMeta newMeta = panel.getMetaFromGui();
            BapClient.getJavaIntf().saveCodeMeta(getCodeDto().getFullClassName(), newMeta, true);
        }
        
        getTree().reloadData(getParent(), true);
    }
}
