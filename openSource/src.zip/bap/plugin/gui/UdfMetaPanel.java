package bap.plugin.gui;

import java.awt.Dimension;
import java.util.List;

import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

import com.leavay.client.util.MBox;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiUtil;

import bap.java.CJavaCode;
import bap.udf.UdfMeta;
import bap.udf.UdfMetaArg;
import bap.udf.UdfMetaBody;
import cmn.util.NullUtil;

public class UdfMetaPanel extends JPanel
{
    private static final long serialVersionUID = 8276903911912027588L;

    public final static String[] HEADER = new String[] {"Argument", "Type", "Description"};
    public final static int COL_Name = 0;
    public final static int COL_Type = 1;
    public final static int COL_Desc = 2;
    
    JTextArea jTxtDesc = new JTextArea();
    
    // 仅用于UDF
    SortableModel _modelArgs = new SortableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return column == COL_Desc;
        }
    };
    
    JTable jTbl = new JTable(_modelArgs);
    public UdfMetaPanel()
    {
        for (String s : HEADER)
            _modelArgs.addColumn(s);
        
        Box mainBox = Box.createVerticalBox();
        JScrollPane jscDesc = new JScrollPane(jTxtDesc);
        jscDesc.setMinimumSize(new Dimension(80, 280));
//        GuiUtil.setFixSize(jscDesc, 40, 40);
        mainBox.add(MBox.hBar(280, jscDesc));
        mainBox.add(MBox.hBar(80, new JScrollPane(jTbl)));
        
        GuiUtil.setGridLayout(this, mainBox);
        setPreferredSize(new Dimension(500, 400));
    }
    
    UdfMeta _meta = null;
    public void showData(CJavaCode code, UdfMeta meta) throws Exception
    {
        if (meta == null)
            return;
        
        _meta = meta;
        UdfMetaBody body = meta.getMetaBody();
        
        jTxtDesc.setText(body.getDesc());
        
        for (UdfMetaArg arg : NullUtil.get(body.getLstArgs()))
        {
            _modelArgs.addRow(new Object[] {arg.getName(), arg.getFullClass(), arg.getDesc()});
        }
    }
    
    public UdfMeta getMetaFromGui() throws Exception
    {
        GuiUtil.stopTableEditor(jTbl);
        
        UdfMetaBody meta = _meta.getMetaBody();
        
        meta.setDesc(jTxtDesc.getText());
        List<UdfMetaArg> lstArgs = null;
        for (int i=0; i<_modelArgs.getRowCount(); i++)
        {
            UdfMetaArg arg = new UdfMetaArg().setName((String) _modelArgs.getValueAt(i, COL_Name));
            arg.setFullClass((String) _modelArgs.getValueAt(i, COL_Type));
            arg.setDesc((String) _modelArgs.getValueAt(i, COL_Desc));
            lstArgs = CmnUtil.addToList(lstArgs, arg);
        }
        meta.setLstArgs(lstArgs);
        return new UdfMeta(meta);
    }
}
