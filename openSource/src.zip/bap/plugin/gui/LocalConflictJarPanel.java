package bap.plugin.gui;

import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.util.HashSet;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;

import com.leavay.client.util.MBox;
import com.leavay.common.util.Pair;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.MouseAction;

import bap.md.yun.ArtifactWare;
import bap.md.yun.GlobalDependSetting;
import cmn.util.NullUtil;

public class LocalConflictJarPanel extends JPanel implements ActionAdapter
{
    JButton jBtnAdd = GuiUtil.createToolButton("add.gif", "New", this);
    JButton jBtnDelete = GuiUtil.createToolButton("remove.png", "New", this);
    
    SortableModel _model = new SortableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return true;
        }
    };
    JTable jTbl = new JTable(_model);
    
    LocalJarAnalysPanel jarPanel = new LocalJarAnalysPanel();
    
    public LocalConflictJarPanel()
    {
        Box mainBox = Box.createVerticalBox();
        _model.addColumn("Exclude Artifact List");
        jarPanel.setBorder(BorderFactory.createTitledBorder("Double Click To Add To Right Side"));
        
        Box rigthBox = Box.createVerticalBox();
        rigthBox.add(MBox.hBar(22,  jBtnAdd, jBtnDelete, MBox.HGlue()));
        rigthBox.add(new JScrollPane(jTbl));
        
        JSplitPane jSpl = new JSplitPane();
        jSpl.setLeftComponent(jarPanel);
        jSpl.setRightComponent(rigthBox);
        jSpl.setDividerLocation(750);
        mainBox.add(MBox.hBar(jSpl));
        
        GuiUtil.setPreferredSize(this, 1024, 600);
        GuiUtil.setGridLayout(this, mainBox);
        
        GuiUtil.addDoubleClickListener(jarPanel.jTbl, new MouseAction()
        {
            
            public void action(MouseEvent e)
            {
                OnDbJarTable();
            }
        });
    }
    
    GlobalDependSetting _gDepend;
    public void showData(GlobalDependSetting gDepend) throws Exception
    {
        _gDepend = gDepend;
        
        GuiUtil.clearTableRows(_model);
        for (String s : NullUtil.get(_gDepend.getExcludeArtifactList()))
        {
            _model.addRow(new Object[] {s});
        }
        
        jarPanel.showData(gDepend);
    }
    
    public Set<String> getData()
    {
        Set<String> setRet = new HashSet();
        for (int i=0;i <_model.getRowCount();i++)
            setRet.add((String)_model.getValueAt(i, 0));
        return setRet;
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        if (e.getSource() == jBtnAdd)
            OnAdd();
        else if (e.getSource() == jBtnDelete)
            OnDelete();
    }
    
    public void OnAdd()
    {
        _model.addRow(new Object[] {});
    }
    
    public void OnDelete()
    {
        int[] rows = jTbl.getSelectedRows();
        if (rows != null)
            GuiUtil.removeTableRow(_model, rows);
    }
    
    public void OnDbJarTable()
    {
        Pair<String, ArtifactWare> p = jarPanel.getSelectRow();
        if (p == null)
            return;
        
        String artifact = null;
        if (p.getValue() != null)
            artifact = p.getValue().getArtifactId();
        else
            artifact = p.getKey();
        
        if (CmnUtil.isStringEmpty(artifact))
            return;
        
        for (int i=0;i< _model.getRowCount();i++)
        {
            String s = (String)_model.getValueAt(i, 0);
            if (artifact.equals(s))
            {
                GuiUtil.selectTableRows(jTbl, new int[] {i});
                return;
            }
        }
        
        _model.addRow(new String[] {artifact});
    }
}
