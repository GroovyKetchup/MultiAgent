package bap.ms;

public class CMsConst
{
    public final static int DEFAULT_NIO_PORT = 8001;
    public final static int DEFAULT_MAX_MEM = 2000;
    public final static int DEFAULT_MIN_MEM = 500;
    
    public final static String CONF_MASTER_HOST = "master.host"; // 主控参与该微服务集群的地址
    public final static String CONF_MASTER_NIO_PORT = "master.nio.port"; // 代理回连主控的NIO端口信息（如果主控开了此端口）
    
    
    public final static String CONF_AGENT_MCHINE_ID = "agent.machine.id"; // 作为代理接入微服务集群的机器ID，如：[EXTERNAL]xxx.xx.xx.x=8001
}
