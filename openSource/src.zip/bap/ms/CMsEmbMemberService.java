package bap.ms;

import java.io.IOException;

import com.leavay.common.util.MppContext;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactoryIntf;
import com.leavay.dfc.mgr.javaDev.JPluginAgentMgr;
import com.leavay.dfc.microService.MsHelper;
import com.leavay.dfc.microService.MsIntf;
import com.leavay.dfc.microService.MsMemberConf;
import com.leavay.dfc.microService.MsMgr;
import com.leavay.dfc.microService.MsNorthMgr;
import com.leavay.dfc.microService.MsProviderIntf;
import com.leavay.dfc.microService.MsUtil;
import com.leavay.ms.embed.MsEmbConsumer;
import com.leavay.ms.embed.MsEmbPluginBridge;
import com.leavay.ms.embed.MsEmbPluginClient;
import com.leavay.ms.embed.MsEmbProvider;
import com.leavay.nio.crpc.CRpcServer;
import com.leavay.nio.crpc.NioService;

import bap.plugin.mgr.CMsPluginBridge;

// 使用此类启动，主要用于嵌入到别的系统进行级联（非代理中启动）
// 最大不同就是插件系统需要桥接，而且没有追踪中心以及HTTP服务功能
// CMsEmb主要是接管了CMsImpl，从而接管了CMsCenter
public class CMsEmbMemberService
{
    public final static String LOG="Ms Embed Server";
    
    // 用于和普通Agent区分开, DCS/DCM/第三方等服务，连入上层网络时，都会设置该标识
    protected static volatile boolean _isRunEmbServer = false;
    public synchronized static boolean isRunEmbServer()
    {
        return _isRunEmbServer;
    }
    
    protected synchronized static void setRunEmbServer()
    {
        _isRunEmbServer = true;
    }
    
    public static void print(String s)
    {
        System.out.println(s);
        ToolUtilities.info(LOG, s);
    }
    
    public boolean start(ClassFactoryIntf clsLoaderFactory)
    {
        setRunEmbServer();
        
        // 开启了NIO服务，才会尝试启动微服务
        if (startNioService())
            return startMicroService(clsLoaderFactory);
        
        return false;
    }
    
    public static boolean startNioService()
    {
        if (NioService.getInstance().isStarted())
            return true;
        
        if (NioService.getInstance().startNioService())
        {
            CRpcServer.registService(MsIntf.class.getName(), CMsImpl.getMe());
            CRpcServer.registService(MsProviderIntf.class.getName(), CMsImpl.getMe());
            
//            CRpcServer.registService(MsProviderIntf.class.getName(), MsEmbProvider.getInstance());
        }
        
        return NioService.getInstance().isStarted();
    }
    
    // 是否开启微服务
    public static boolean startMicroService(ClassFactoryIntf clsFactory)
    {
        if (!MsMemberConf.isEnableMicroService())
            return false;

        // 只要支持微服务，默认就必须支持微服务消费者
        try
        {
            System.out.println("Begin connect zookeeper ... ");
            MsEmbConsumer.getInstance().initService(MsMemberConf.getZkAddress(), getMachineID());
        } catch (Throwable exp)
        {
            ToolUtilities.fatal(LOG, "Failed to start http service for CONSUMER", exp);
            System.exit(0);
        }

        // 启动微服务供应者
        if (MsMemberConf.isProvideService())
        {
            try
            {
                System.out.println("Starting micro service provider ... ");
                MsEmbProvider.getInstance().startService(MsEmbConsumer.getInstance(), clsFactory);
            } catch (Throwable exp)
            {
                ToolUtilities.fatal(LOG, "Failed to start micro service for PROVIDER", exp);
                System.exit(0);
            }
        }

        return true;
    }
    
    // 在Leavay系统中嵌入式启动微服务参与者：DCS/DCT/DRP等
    public static boolean startInLeavay()
    {
        // 是否启动级联（连接上一层微服务）
        if (!MsMemberConf.isEnableMicroService())
            return false;

        CMsEmbMemberService srv = new CMsEmbMemberService();
        if (!srv.start(MsEmbPluginBridge.getInstance()))
            return false;

        // 参与上层集群
        MsNorthMgr.getInstance().init(MsEmbConsumer.getInstance(), MsEmbProvider.getInstance(), false, false);
        
        // Leavay系统的插件采用桥接器实现
        MsEmbPluginBridge.getInstance().startService(); // 
        
        // 注册为Member
        MsHelper.setAsMember(MsEmbConsumer.getInstance());
        
        return true;
    }
    

    // 在第三方程序中启动嵌入式微服务参与者
    public static boolean startInIsolateProcess() throws Exception
    {
        // 微应用不参与RMI插件体系
        // 如果参与微服务集群，会融入微服务插件体系s
        JPluginAgentMgr.setEnable(false);
        
        // 这里会接管全局类工厂，和JPluginAgentMgr冲突的，所以要先关掉JPluginAgent
        MsEmbPluginClient.getMe().init();
        
        CMsEmbMemberService server = new CMsEmbMemberService();
        if (!server.start(CMsPluginBridge.getMe()))
            return false;

        // 参与本地集群
        MsMgr.getInstance().init(MsEmbConsumer.getInstance(), MsEmbProvider.getInstance(), true, false);
        
        // 以前是通过下载中心插件，现在是跟随DAO下载插件，DAO仆从直接从DAO库里获取
        // MsEmbPluginClient.getMe().startService();
        
        // 第三方系统的插件启用下载到本地动态加载器
        // 只有次集群主控才会启动该桥接器（现已基本废弃）
        CMsPluginBridge.getMe().startService();
        
        
        // 注册为Member
        MsHelper.setAsMember(MsEmbConsumer.getInstance());
        
        return true;
    }
    
    public static void main(String[] args) throws Exception
    {
        MppContext.init(ToolUtilities.getAbsolutPath("conf/base.conf"));
        CMsEmbMemberService.startInIsolateProcess();

        System.out.println("=== PID = "+ToolUtilities.getProcessID());
    }

    public static String getMachineID()
    {
        return MsUtil.getMachineID_EmbMember();
    }
}
