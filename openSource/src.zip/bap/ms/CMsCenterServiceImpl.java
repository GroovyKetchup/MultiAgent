package bap.ms;

import java.rmi.RemoteException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.Cnd;
import org.nutz.dao.util.cri.SqlExpression;

import com.cdao.dto.CPager;
import com.cdao.impl.entity.field.GID;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dfc.microService.MsCenterConf;
import com.leavay.dfc.microService.MsRegEntryInfo;
import com.leavay.dfc.microService.bean.MsAlarmBean;
import com.leavay.dfc.microService.track.filter.MsFilterReq;
import com.leavay.dfc.microService.track.filter.MsFilterReqList;
import com.leavay.ms.warehouse.MsAgentDto;
import com.leavay.ms.warehouse.MsAgentInfoDto;
import com.leavay.ms.warehouse.WhPackage;
import com.leavay.starter.StarterConf;
import com.project.gui.common.DBDataSourceIntf;

import bap.ms.CMsCenter.ALARM_STASTIC_KEY;
import bap.ms.agent.MsAgentMgr;
import ms.cmn.HostPort;

public class CMsCenterServiceImpl implements CMsCenterService
{
    public void registService(MsRegEntryInfo regEntry, boolean deleteEntry, boolean rebuildRoute) throws Exception
    {
        CMsCenter.getMe().registService(regEntry, deleteEntry, rebuildRoute);
    }

    public void unregistAgent(String serviceKey, String agentKey) throws Exception
    {
        CMsCenter.getMe().unregistAgent(serviceKey, agentKey);        
    }

    public MultiPageResult<MsAgentDto> queryMsAgent(Cnd cnd, CPager pager) throws Exception
    {
        return MsAgentMgr.getMe().queryAgent(cnd, pager);
    }
    
    public Map<String, MsAgentInfoDto> queryMsAgentInfo(Set<String> agentName) throws Exception
    {
        return MsAgentMgr.getMe().queryAgentInfo(agentName);
    }

    public void createMsAgent(MsAgentDto agent) throws Exception
    {
        MsAgentMgr.getMe().createAgent(agent);
    }

    public void terminateMsAgent(GID agtGid) throws Exception
    {
        MsAgentMgr.getMe().terminateAgent(agtGid);        
    }

    public void killAndDeleteMsAgent(GID agtGid) throws Exception
    {
        MsAgentMgr.getMe().killAndDeleteAgent(agtGid);
    }

    public void startMsAgent(GID agtGid) throws Exception
    {
        MsAgentMgr.getMe().startAgent(agtGid);
    }

    public MultiPageResult<String> readMsAgentOutput(GID agtGid, int startLine, int lastLineCount) throws Exception
    {
        return MsAgentMgr.getMe().readOutput(agtGid, startLine, lastLineCount);
    }

    public void updateMsAgent(MsAgentDto newAgent, boolean rebuild) throws Exception
    {
        MsAgentMgr.getMe().updateAgent(newAgent, rebuild);
    }

    public void rebuildMsAgent(GID agentGid) throws Exception
    {
        MsAgentMgr.getMe().rebuildAgent(agentGid);
    }

    public StarterConf loadMsPackageConfig(String pkgPath) throws Exception
    {
        return MsAgentMgr.getMe().loadPackageConfig(pkgPath);
    }
    public List loadWarehouseCatalog(List<String> path)
    {
        return MsAgentMgr.getMe().loadWhCatalog(path);
    }
    
    public List<WhPackage> loadAllWarehousePackage()
    {
        return MsAgentMgr.getMe().loadAllWhPackage(null);
    }

    public void ping() throws RemoteException
    {
        
    }

    public Map<String, MsRegEntryInfo> getAllEntryInfo() throws Exception
    {
        return CMsCenter.getMe().getAllEntryInfo();
    }

    public void deleteService(String serviceKey) throws Exception
    {
        CMsCenter.getMe().deleteService(serviceKey);
    }

    public String getMsZkAddr() throws Exception
    {
        return MsCenterConf.getZkAddr();
    }

    public HostPort getTrackCenter() throws Exception
    {
        return CMsCenter.getMe().getTrackCenter();
    }
    
    public boolean isTrackMonitorStarted() throws Exception
    {
        return CMsCenter.getMe().isTrackMonitorStarted();
    }

    public void startTrackMonitor(long interval) throws Exception
    {
        CMsCenter.getMe().startTrackMonitor(interval);
    }

    public void stopTrackMonitor() throws Exception
    {
        CMsCenter.getMe().stopTrackMonitor();        
    }

    public Map<String, Object> queryTrackData(MsFilterReqList reqList) throws Exception
    {
        return CMsCenter.getMe().queryTrackData(reqList);
    }

    public Object queryTrackData(MsFilterReq req) throws Exception
    {
        return CMsCenter.getMe().queryTrackData(req);
    }

    public MultiPageResult<MsAlarmBean> queryAlarm(SqlExpression whereCnd, int startPos, int pageSize) throws Exception
    {
        return CMsCenter.getMe().queryAlarm(whereCnd, startPos, pageSize);
    }

    public LinkedHashMap<Comparable, Number> queryAlarmStastic(ALARM_STASTIC_KEY stasticKey, int limit) throws Exception
    {
        return CMsCenter.getMe().queryAlarmStastic(stasticKey, limit);
    }

    public int deleteAlarmWhere(SqlExpression where)
    {
        return CMsCenter.getMe().deleteAlarmWhere(where);
    }

    public DBDataSourceIntf getTrackDB() throws Exception
    {
        return CMsCenter.getMe().getTrackDB();
    }

    public void deleteAlarmBatch(Set<String> setAlarmID)
    {
        CMsCenter.getMe().deleteAlarmBatch(setAlarmID);
    }

    public void updateServiceAttribute(String serviceKey, String field, Object v) throws Exception
    {
        CMsCenter.getMe().updateServiceAttribute(serviceKey, field, v);        
    }
}
