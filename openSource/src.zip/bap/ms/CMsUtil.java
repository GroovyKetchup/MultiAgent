package bap.ms;

import com.leavay.common.util.MppContext;
import com.leavay.dfc.microService.MsUtil;

// BAP平台在BAP的微代理上会自动配置CONF_MASTER_HOST，CONF_MASTER_NIO_PORT，以便直接找到主控
// DNS平台不支持（DNS平台也不允许作为微集群的主控了）
public class CMsUtil extends MsUtil
{
    public static String getConfCenterAddress()
    {
        return MppContext.getString(CMsConst.CONF_MASTER_HOST);
    }
    
    public static int getConfCenterPort()
    {
        return MppContext.getInt(CMsConst.CONF_MASTER_NIO_PORT);
    }
}
