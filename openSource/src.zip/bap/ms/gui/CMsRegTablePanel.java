package bap.ms.gui;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import com.leavay.client.util.CNClientUtil;
import com.leavay.client.util.MBox;
import com.leavay.client.util.EventQ.GuiEvent;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SortButtonRenderer;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.dfc.gui.AllGuiEvents;
import com.leavay.dfc.gui.DFCBaseDockView;
import com.leavay.dfc.mgr.javaDev.ClassNameInfoExt;
import com.leavay.dfc.mgr.javaDev.JavaClassSearchPanel;
import com.leavay.dfc.microService.MsRegAgentPath;
import com.leavay.dfc.microService.MsRegEntryInfo;
import com.leavay.dfc.microService.MsType;
import com.leavay.ms.warehouse.MsAgentDto;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import bap.client.BapClient;
import bap.client.BapGuiUtil;
import bap.java.CJavaClassSearchPanel;
import bap.md.CMsRegEntry;
import modeldef.com.leavay.dfc.physical.SshAgentMO;

public class CMsRegTablePanel extends DFCBaseDockView implements ActionListener
{
    protected final String[] sHeader = new String[]{"Label", "Version", "Service Key", "Service Implement", "Local Simulator", "Route Table", "Exclude Agent", "Restful Permission"};
    protected final int _iMo = 0;
    protected final int _iVersion = 1;
    protected final int _iServiceKey = 2;
    protected final int _iImplement = 3;
    protected final int _iLocalSimulator = 4;
    protected final int _iRouteTable = 5;
    protected final int _iExclude = 6;
    
    
    protected SortButtonRenderer.SortableModel _model = new SortButtonRenderer.SortableModel();

    public JButton jBtn_Refresh = GuiUtil.createToolButton("refresh.png", getString("Refresh"), this);
    
    public JButton jBtn_Add = GuiUtil.createToolButton("dev/newclass.png", getString("Publish Service"), this);
    public JButton jBtn_SetLabel = GuiUtil.createToolButton("rename_16.png", getString("Set Label"), this);
    public JButton jBtn_SetVersion = GuiUtil.createToolButton("dev/version.png", getString("Set Version"), this);

    public JButton jBtn_SetLocalSimulator = GuiUtil.createToolButton("dfc/simulator.png", getString("Set Local Simulator"), this);
    public JButton jBtn_SetImplementText = GuiUtil.createToolButton("dev/java.png", getString("Set Implement Class"), this);
    
    public JButton jBtn_Exclude = GuiUtil.createToolButton("dfc/agentExclude.png", getString("Set Exclude Agent"), this);

    public JButton jBtn_SetRouteTable = GuiUtil.createToolButton("dfc/route.png", getString("Set Route Table"), this);

    //配置权限的按钮
    public JButton jBtn_SEtRestfulPerm = GuiUtil.createToolButton("db/user_16.png", getString("Set Restful Permission"), this);
    
    public JButton jBtn_Delete = GuiUtil.createToolButton("remove.png", getString("Delete"), this);
    public JButton jBtn_BindingDomain= new JButton("");
    
    protected JTable jTbl_Reg = new JTable(_model);
    
    protected class MyRenderer extends DefaultTableCellRenderer{
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (value != null && value instanceof MsRegEntryInfo)
            {
                MsRegEntryInfo reg = (MsRegEntryInfo)value;
                setText(reg.getServiceLabel());
                if (reg.isSystemFixed())
                    setIcon(GuiResource.getIcon("dfc/gearLock.png"));
                else
                    setIcon(GuiResource.getIcon("dfc/gearGreen.png"));
            }
            else if (column == _iRouteTable && value instanceof List)
            {
                String route = "";
                List<MsRegAgentPath> lstRouteTable = (List<MsRegAgentPath>) value;
                for (MsRegAgentPath p : lstRouteTable)
                {
                    if (!route.equals(""))
                        route+=",";
                    String agentName = SshAgentMO.getDCacheName(p.getAgent());
                    if (agentName == null)
                        agentName = p.getAgent();
                    route += agentName;
                    if (p.hasRouteID())
                        route += "{"+p.getRouteID()+"}";
                }
                setText(route);
            }
            return this;
        }
    };
    
    public CMsRegTablePanel()
    {
        getDockKey().setKey("Micro Service Register Table");
        getDockKey().setName(getString("Micro Service Register Table"));
        getDockKey().setIcon(GuiResource.getIcon("dfc/register.png"));
        jbInit();
        
        try
        {
            reloadData();
        } catch (Exception exp)
        {
            throw new RuntimeException(exp);
        }
    }
    
    public Box createToolBar()
    {
        return MBox.createHBar(22, jBtn_Refresh, MBox.HSeperator(), jBtn_Add, jBtn_SetLabel, jBtn_Delete, jBtn_SetRouteTable, MBox.HStrut(1), MBox.HSeperator(), MBox.HStrut(1), jBtn_SetVersion, jBtn_SetLocalSimulator, jBtn_SetImplementText, MBox.HStrut(1), MBox.HSeperator(), MBox.HStrut(1), jBtn_Exclude, jBtn_SEtRestfulPerm, MBox.HSeperator(), MBox.HStrut(1), MBox.HGlue());
    }
    
    public String[] getHeader(){
		return sHeader;
	}
    
    public Box jbInit()
    {
    	String[] header = getHeader();
        for (int i=0; i<header.length; ++i)
            _model.addColumn(getString(header[i]));
        
        Box mainBox = Box.createVerticalBox();
        
        Box toolBar = createToolBar();
        mainBox.add(toolBar);
        mainBox.add(new JScrollPane(jTbl_Reg));
        setLayout(new GridLayout(1, 1));
        add(mainBox);
        
        jTbl_Reg.getColumnModel().getColumn(_iMo).setCellRenderer(new MyRenderer());
        jTbl_Reg.getColumnModel().getColumn(_iRouteTable).setCellRenderer(new MyRenderer());
        
        jTbl_Reg.addMouseMotionListener(new MouseMotionAdapter()
        {
            public void mouseMoved(MouseEvent e) {
                int row = jTbl_Reg.rowAtPoint(e.getPoint());
                if (row >= 0)
                {
                    MsRegEntryInfo info = (MsRegEntryInfo) _model.getValueAt(row, _iMo);
                    if (info != null)
                    {
                        jTbl_Reg.setToolTipText(info.getDesc());
                    }
                }
            }
        });
        
        jTbl_Reg.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e)
            {
                if (GuiUtil.isDoubleClickLeft(e))
                {
                    try
                    {
                        OnBtnModify();
                    } catch (Throwable exp)
                    {
                        DetailErrorMsg.showError(CMsRegTablePanel.this, exp);
                    }
                }
            }
        });
        try
        {
            SortButtonRenderer.setHeader(jTbl_Reg);
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }
        
        return mainBox;
    }
    
    public void reloadData() throws Exception
    {
        while(_model.getRowCount() > 0) _model.removeRow(0);
        
        Map<String, MsRegEntryInfo> mapEnt = CMsClient.getIntf().getAllEntryInfo();
        for (MsRegEntryInfo mo : mapEnt.values())
        {
            _model.addRow(new Object[]{mo, mo.getServiceVersion(), mo.getServiceKey(), mo.getServiceImplement(), mo.getLocalSimulator(), mo.getRouteTable(), transName(mo.getExcludeAgents()), mo.getRestfulPerm()});
        }
        
        GuiUtil.adjustTableColumnWidth(jTbl_Reg);
        
        _model.reSort();
    }

    public void actionPerformed(ActionEvent e)
    {
        try
        {
            if (e.getSource() == jBtn_Refresh)
                reloadData();
            if (e.getSource() == jBtn_Add)
                OnBtnAdd();
            else if (e.getSource() == jBtn_SetLabel)
                OnBtnSetLabel();
            else if (e.getSource() == jBtn_SetVersion)
                OnBtnSetVersion();
            else if (e.getSource() == jBtn_SetLocalSimulator)
                OnBtnSetLocalSimulator();
            else if (e.getSource() == jBtn_SetImplementText)
                OnBtnSetImplementText();
            else if (e.getSource() == jBtn_SetRouteTable)
                OnSetRouteTable();
            else if (e.getSource() == jBtn_Exclude)
                OnSetExclude();
            else if (e.getSource() == jBtn_SEtRestfulPerm)
                OnSetRestfulPerm();
            else if (e.getSource() == jBtn_Delete)
                OnBtnDelete();
        } catch (Throwable exp)
        {
            DetailErrorMsg.showError(this, exp);
        }
    }
    
    public MsRegEntryInfo getSelectRow()
    {
        int iSelRow = jTbl_Reg.getSelectedRow();
        if (iSelRow < 0)
            return null;
        
        return (MsRegEntryInfo) _model.getValueAt(iSelRow, _iMo);
    }
    
    public List<MsRegEntryInfo> getSelectRows()
    {
        int[] iSelRow = jTbl_Reg.getSelectedRows();
        if (iSelRow == null)
            return null;
        
        List<MsRegEntryInfo> lstRet = new ArrayList();
        for (int sel : iSelRow)
            lstRet.add((MsRegEntryInfo) _model.getValueAt(sel, _iMo));
        return lstRet;
    }
    
    public void OnBtnModify() throws Exception
    {
        MsRegEntryInfo registry = getSelectRow();
        if (registry == null)
            return;
        
        OnSetRouteTable();
    }
    
    public void OnBtnDelete() throws Exception
    {
        List<MsRegEntryInfo> selRows = getSelectRows();
        if (ToolUtilities.isObjectEmpty(selRows))
            return;

        if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(CNClientUtil.getTopoWindow(), getString("Are you sure want to delete all selected items"), getString("Warning"),
                JOptionPane.YES_NO_OPTION))
            return;

        try
        {
            for (MsRegEntryInfo reg : selRows)
                CMsClient.getIntf().deleteService(reg.getServiceKey());
        } finally
        {
            reloadData();
        }
    }
    
    public void initGuiEventLsnr()
    {
        BapGuiUtil.addListener(AllGuiEvents.REFRESH_ALL_AFTER_IMPORT, this, "OnEvtRefresh");
    }
    
    public void OnEvtRefresh(GuiEvent evt)
    {
        try
        {
            reloadData();
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }
    }
    
    public void OnBtnAdd() throws Exception
    {
        CJavaClassSearchPanel jSearchClassPanel = new CJavaClassSearchPanel();
        jSearchClassPanel.jTxt_Key.grabFocus();
        JSimpleDialog jDlgSearchClass = GuiUtil.createSimpleDialog(jSearchClassPanel, this, null, true);
        jDlgSearchClass.pack();
        GuiUtil.centerWindow(jDlgSearchClass);
        if (!jDlgSearchClass.showModel(true))
            return;

        List<ClassNameInfoExt> lstCodes = jSearchClassPanel.getSelectCodes();

        String selClassName = jSearchClassPanel.getTypedText();
        if (!ToolUtilities.isObjectEmpty(lstCodes))
        {
            selClassName = lstCodes.get(0).getClassFullName();
        }

        try
        {
            MsRegEntryInfo entry = new MsRegEntryInfo();
            entry.setServiceKey(MsType.getStandardServiceName(selClassName));
            entry.setServiceLabel(LvJavac.getSimpleName(selClassName));

            CMsClient.getIntf().registService(entry, true, true);
        } finally
        {
            reloadData();
        }
    }
    
    public void OnBtnSetLocalSimulator() throws Exception
    {
        MsRegEntryInfo entryInfo = getSelectRow();
        if (entryInfo == null)
            return;
        
        CJavaClassSearchPanel jSearchClassPanel = new CJavaClassSearchPanel();
        jSearchClassPanel.jTxt_Key.grabFocus();
        JSimpleDialog jDlgSearchClass = GuiUtil.createSimpleDialog(jSearchClassPanel, this, null, true);
        jDlgSearchClass.pack();
        GuiUtil.centerWindow(jDlgSearchClass);
        if (!jDlgSearchClass.showModel(true))
            return;

        String smltClass = null;
        ClassNameInfoExt selClass = jSearchClassPanel.getSelectClassInfo();
        if (selClass == null)
            smltClass = jSearchClassPanel.getTypedText();
        else
            smltClass = selClass.getClassFullName();
        
        try
        {
            CMsClient.getIntf().updateServiceAttribute(entryInfo.getServiceKey(), CMsRegEntry.LocalSimulator, smltClass);
        }finally
        {
            reloadData();
        }
    }
    
    public void OnBtnSetVersion() throws Exception
    {
        MsRegEntryInfo entryInfo = getSelectRow();
        if (entryInfo == null)
            return;
        
        String version = JOptionPane.showInputDialog(this, "Set version : ");
        if (version == null)
            return;
        
        try
        {
            if (version.trim().equals(""))
                version = null;
            CMsClient.getIntf().updateServiceAttribute(entryInfo.getServiceKey(), CMsRegEntry.Version, version);
        }finally
        {
            reloadData();
        }
    }
    
    public void OnBtnSetLabel() throws Exception
    {
        MsRegEntryInfo entryInfo = getSelectRow();
        if (entryInfo == null)
            return;
        
        String label = JOptionPane.showInputDialog(this, "Set label : ", entryInfo.getServiceLabel());
        if (label == null)
            return;
        
        try
        {
            if (label.trim().equals(""))
                label = null;
            CMsClient.getIntf().updateServiceAttribute(entryInfo.getServiceKey(), CMsRegEntry.Label, label);
        }finally
        {
            reloadData();
        }
    }
    
    public void OnBtnSetImplementText() throws Exception
    {
        MsRegEntryInfo entryInfo = getSelectRow();
        if (entryInfo == null)
            return;
        
        CJavaClassSearchPanel jSearchClassPanel = new CJavaClassSearchPanel();
        jSearchClassPanel.jTxt_Key.grabFocus();
        JSimpleDialog jDlgSearchClass = GuiUtil.createSimpleDialog(jSearchClassPanel, this, null, true);
        jDlgSearchClass.pack();
        GuiUtil.centerWindow(jDlgSearchClass);
        if (!jDlgSearchClass.showModel(true))
            return;

        String implClass = null;
        ClassNameInfoExt cls = jSearchClassPanel.getSelectClass();
        if (cls == null)
            implClass =  jSearchClassPanel.getTypedText();
        else
            implClass = cls.getClassFullName();
        
        try
        {
            CMsClient.getIntf().updateServiceAttribute(entryInfo.getServiceKey(), CMsRegEntry.Implement, implClass);
        }finally
        {
            reloadData();
        }
    }
    
    public String transName(Collection lstAgt)
    {
        String sRet = "";
        if (lstAgt != null)
            for (Object a : lstAgt)
            {
                String s = ToolUtilities.getString(a, "");
                if (!sRet.equals(""))
                    sRet +=",";
                
                String agtName = SshAgentMO.getDCacheName(s);
                if (agtName == null)
                    agtName = s;
                sRet += agtName;
            }
        return sRet;
    }
    
    public void OnSetRouteTable() throws Exception
    {
        List<MsRegEntryInfo> selRows = getSelectRows();
        if (ToolUtilities.isObjectEmpty(selRows))
            return;
        
        CMsRegRouteTablePanel panel = new CMsRegRouteTablePanel();
        panel.showData(selRows.get(0).getRouteTable());
        
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, this);
        dlg.setTitle(getString("Set Route Table"));
        dlg.pack();
        dlg.getOkButton().setText(GuiUtil.getString("Save"));
        if (!dlg.showModel(true))
            return;

        List<MsRegAgentPath> lstRet = panel.getDataFromGui();
        if (lstRet == null)
            return;

        try
        {
            for (MsRegEntryInfo sel : selRows)
            {
                sel.setRouteTable(lstRet);
                CMsClient.getIntf().registService(sel, false, true);
            }
        } finally
        {
            reloadData();
        }
    }
    
    public String getString(String s)
    {
        return s;
    }
    
    public void OnSetExclude() throws Exception
    {
        List<MsRegEntryInfo> selRows = getSelectRows();
        if (ToolUtilities.isObjectEmpty(selRows))
            return;

        CMsAgentMgrPanel msAgtPanel = new CMsAgentMgrPanel();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(msAgtPanel, this);
        dlg.pack();
        if (!dlg.showModel(true))
            return;
        
        List<MsAgentDto> lstAgts = msAgtPanel.getSelectAgents();
        if (lstAgts == null)
            return;

        List<String> lstAgtIDs = new LinkedList();
        for (MsAgentDto dto : lstAgts)
            lstAgtIDs.add(dto.getCode());
        
        try
        {
            for (MsRegEntryInfo sel : selRows)
            {
                sel.setExcludeAgents(lstAgtIDs);
                CMsClient.getIntf().registService(sel, false, true);
            }
        } finally
        {
            reloadData();
        }
    }

    public void OnSetRestfulPerm() throws Exception {
        MsRegEntryInfo entryInfo = getSelectRow();
        if (entryInfo == null)
            return;

        String restfulPerm = JOptionPane.showInputDialog(this, "Input restful permission, split with  ,  : ");
        if (restfulPerm == null)
            return;

        try {
            CMsClient.getIntf().updateServiceAttribute(entryInfo.getServiceKey(), CMsRegEntry.RestfulPermission, restfulPerm);
        } finally {
            reloadData();
        }
    }
}
