package bap.ms.gui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Paint;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.entity.CategoryItemEntity;
import org.jfree.chart.entity.CategoryLabelEntity;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.IntervalBarRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.data.category.DefaultCategoryDataset;

import com.leavay.common.util.KeyValuePair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.microService.track.filter.MsCallStastic;
import com.project.gui.common.GuiUtil;

public class CMsAgentStasticPanel extends JPanel
{
    DefaultCategoryDataset _dataSet = new DefaultCategoryDataset();
    static Color COLOR_BACK = new Color(0x35, 0x5c, 0x7d);
    static Color COLOR_LABEL = new Color(0x70, 0xAF, 0xCE);
    final static String sTitle = dfcutil.getString("Agent Stastic");
    JFreeChart jCntChart = ChartFactory.createBarChart(sTitle, null, null, _dataSet, PlotOrientation.VERTICAL, true, false , false);
    
    public class CustomRenderer extends IntervalBarRenderer
    {
        public Paint getItemPaint(int i, int j)
        {
            return COLOR_LABEL;
        }
    }
    
    public CMsAgentStasticPanel()
    {
        ChartPanel chartPanel = new ChartPanel(jCntChart);
        jCntChart.getTitle().setPaint(COLOR_LABEL);
        jCntChart.getPlot().setBackgroundPaint(COLOR_BACK );
        jCntChart.getPlot().setOutlinePaint(COLOR_BACK);

        jCntChart.setBackgroundPaint(COLOR_BACK);
        jCntChart.getCategoryPlot().getDomainAxis().setTickLabelsVisible(false);
        jCntChart.getCategoryPlot().getDomainAxis().setLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getDomainAxis().setTickLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getRangeAxis().setTickLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getRangeAxis().setTickLabelsVisible(false);
        jCntChart.getCategoryPlot().getRangeAxis().setRangeWithMargins(0, 10);
        jCntChart.getCategoryPlot().setBackgroundPaint(COLOR_BACK);
        
        jCntChart.getCategoryPlot().setDomainGridlinesVisible(false);
        jCntChart.getCategoryPlot().setRangeGridlinesVisible(false);
        
        jCntChart.getLegend().setVisible(false);
        
        BarRenderer render = new CustomRenderer();//自定义图形对象
        render.setShadowVisible(false);//取消柱子的阴影效果
        render.setDrawBarOutline(false); 
        render.setMaximumBarWidth(0.03); //设置柱子宽度 
        render.setMinimumBarLength(0.0); //设置柱子高度 
        //在柱子上显示相应信息 
        render.setBaseItemLabelsVisible(true); 
        render.setBaseItemLabelPaint(COLOR_LABEL);//设置数值颜色，默认黑色 
        render.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator()); 
        render.setBarPainter( new StandardBarPainter() ); //去掉渐变色


        //设置不显示边框线
        render.setDrawBarOutline(false);
        //render.setSeriesPaint(0,new Color(131,175,155));
       //  render.setBarPainter( new StandardBarPainter() );//取消渐变色
        //render.setItemMargin(-0.01);
        jCntChart.getCategoryPlot().setRenderer(render);
        
        chartPanel.addChartMouseListener(new ChartMouseListener()
        {
            public void chartMouseMoved(ChartMouseEvent var1)
            {
                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                updateTitle(null);
                
                if (var1.getEntity() != null)
                {
                    if (var1.getEntity() instanceof CategoryLabelEntity)
                    {
                        setCursor(new Cursor(Cursor.HAND_CURSOR));
                        KeyValuePair key = (KeyValuePair) ((CategoryLabelEntity) var1.getEntity()).getKey();
                        Object value = _dataSet.getValue(ROW_KEY, key);
                        updateTitle("" + (key == null ? null : key.getValue())+"("+value+")");
                    }else if (var1.getEntity() instanceof CategoryItemEntity)
                    {
                        setCursor(new Cursor(Cursor.HAND_CURSOR));
                        CategoryItemEntity itemEntity = (CategoryItemEntity) var1.getEntity();
                        KeyValuePair key = (KeyValuePair)itemEntity.getColumnKey();
                        Object value =  _dataSet.getValue(ROW_KEY, key);
                        updateTitle("" + (key == null ? null : key.getValue())+"("+value+")");
                    }
                }
            }
            
            public void chartMouseClicked(ChartMouseEvent var1)
            {
                ChartEntity ent = var1.getEntity();
                if (ent instanceof CategoryLabelEntity)
                {
                    KeyValuePair key = (KeyValuePair) ((CategoryLabelEntity)var1.getEntity()).getKey();
                    OnClickItem(key);
                }else if (var1.getEntity() instanceof CategoryItemEntity)
                {
                    KeyValuePair key = (KeyValuePair) ((CategoryItemEntity)var1.getEntity()).getColumnKey();
                    if (key != null)
                        OnClickItem(key);
                }
            }
        });
        
        this.setBackground(COLOR_BACK);
        GuiUtil.setGridLayout(this, chartPanel);
        autoSetRange();
    }
    
    public void OnClickItem(KeyValuePair serviceKey)
    {
        String agtKey = (String)serviceKey.getKey();
        if (_data == null)
            return;
        
        JPopupMenu pop = new JPopupMenu();
        pop.add(new JTextArea(ToolUtilities.logString(_data.get(agtKey), true)));
        pop.show(this, this.getMousePosition().x, this.getMousePosition().y);
    }
    
    public void updateTitle(String moveOnService)
    {
        if (ToolUtilities.isStringEmpty(moveOnService))
            jCntChart.setTitle(sTitle);
        else
            jCntChart.setTitle(moveOnService);
    }
    
    public final static String ROW_KEY = "HIT";
    Map<String, Map<String, MsCallStastic>> _data = null;
    public void showData(Map<String, Map<String, MsCallStastic>> mapData)
    {
        _data = mapData;
        removeAllValue();
        
        for (Entry<String, Map<String, MsCallStastic>> a : mapData.entrySet())
        {
            long cnt = 0;
            Map<String, MsCallStastic> mapSrv = a.getValue();
            for (MsCallStastic sts : mapSrv.values())
            {
                cnt += sts.getCount();
            }
            
            _dataSet.addValue(cnt, ROW_KEY, new KeyValuePair(a.getKey(), a.getKey()));
        }
        autoSetRange();
    }
    
    public void removeAllValue()
    {
        while (_dataSet.getColumnCount() > 0)
            _dataSet.removeColumn(0);
    }
    
    public void autoSetRange()
    {
        long num = 0L;
        for (int i=0; i< _dataSet.getColumnCount();i++)
        {
            for (int j=0;j<_dataSet.getRowCount(); j++)
                num = Math.max(num, ToolUtilities.getLong(_dataSet.getValue(j, i), 0));
        }
        
        jCntChart.getCategoryPlot().getRangeAxis().setRange(0, Math.max(5, num * 110/100));
    }
}
