package bap.ms.gui.track;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.Box;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import org.nutz.dao.util.cri.SqlExpression;

import com.leavay.client.util.MBox;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.dfc.microService.bean.MsAlarmBean;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.JSimplePagePanel;
import com.project.gui.common.JWaitDialog;

import bap.ms.gui.CMsClient;

public class CMsAlarmTablePanel extends JPanel
{
    
    public final static String[] _header = new String[]{"Error", "Level", "Service", "Interface", "Source Agent", "Agent", "Error Type", "Root Cause", "AlarmTime"};
    public final static int _col_bean = 0;
    
    SortableModel _model = new SortableModel();
    JTable jTbl_Data = new JTable(_model);
    JSimplePagePanel jPage = new JSimplePagePanel(GuiUtil.getTranslator())
    {
        public Component createToolBar()
        {
            jToolBar = MBox.createHBar(22, jBtn_FirstPage
                    , MBox.HStrut(2), jBtn_PrevPage
                    , MBox.HStrut(2), jLab_Text
                    , MBox.HStrut(2), jBtn_NextPage
                    , MBox.HStrut(5), jCmb_PageSize);
            return jToolBar;
        }
        
        public void showError(Throwable err)
        {
            DetailErrorMsg.showError(err);
        }
        
        public void showData(List lstData)
        {
            showRows(lstData);
        }
        
        protected MultiPageResult CallBack_LoadPage(int iStartPos, int iPageSize) throws Exception
        {
            return CMsClient.getIntf().queryAlarm(_sqlCond, iStartPos, iPageSize);
        }
    };
    
    SqlExpression _sqlCond = null;
    public void showData(SqlExpression sqlCondition) throws Exception
    {
        _sqlCond = sqlCondition;
       jPage.reloadData();
    }
    
    public void reload() throws Exception
    {
        showData(_sqlCond);
    }
    
    public void showRows(List<MsAlarmBean> lstData)
    {
        int[] selRows = jTbl_Data.getSelectedRows();
        GuiUtil.clearTableRows(_model);
        
        if (lstData == null)
            return;
        
        jTbl_Data.getColumnModel().getColumn(_col_bean).setCellRenderer(new MainRenderer());
        for (MsAlarmBean b : lstData)
        {
            addRow(b);
        }
        GuiUtil.adjustTableColumnWidth(jTbl_Data, false);
        
        if (selRows != null)
            for (int sel : selRows)
                jTbl_Data.setRowSelectionInterval(sel, sel);
    }
    
    class MainRenderer extends DefaultTableCellRenderer
    {
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (value != null && value instanceof MsAlarmBean)
            {
                MsAlarmBean bean = (MsAlarmBean)value;
                setText(bean.getMessage());
            }
            return this;
        }
    }
    
    public void addRow(MsAlarmBean bean)
    {
        _model.addRow(new Object[]{bean, bean.getLevelText(), bean.getServiceName(), bean.getServiceInterface(), CMsTrackPanel.getAgentName(bean.getSrcAgent()), CMsTrackPanel.getAgentName(bean.getDstAgent()), LvJavac.getSimpleName(bean.getErrorType()), LvJavac.getSimpleName(bean.getRootCauseType()), ToolUtilities.time2String(bean.getTime(), false, false)});
    }
    
    public CMsAlarmTablePanel()
    {
        jbInit();
    }
    
    public void jbInit()
    {
        Box boxMain = Box.createVerticalBox();
        
        for (String h : _header)
            _model.addColumn(GuiUtil.getString(h));
        
        CMsTrackPanel.getStyleUtil().setTableStyle(jTbl_Data);
        
        JScrollPane jScrTable = new JScrollPane(jTbl_Data);
        CMsTrackPanel.getStyleUtil().setScrollPanel(jScrTable);

        jPage.setPageSize(100, false);
        CMsTrackPanel.getStyleUtil().setSimplePagePanel(jPage);
        boxMain.add(jScrTable);
        boxMain.add(jPage);
        
        jTbl_Data.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e) {
                if (GuiUtil.isDoubleClickLeft(e))
                    OnDbClickTable();
                else if (GuiUtil.isSingleClickRight(e))
                    OnRightClickTable(e.getPoint());
            }

        });
        
        CMsTrackPanel.getStyleUtil().setStyle(this);
        GuiUtil.setGridLayout(this, boxMain);
    }
    
    public void OnDbClickTable()
    {
        int selRow =  jTbl_Data.getSelectedRow();
        if (selRow < 0)
            return ;
        
        MsAlarmBean bean = (MsAlarmBean) _model.getValueAt(selRow, _col_bean);
        String sMsg = bean.getMessage();
        
        String sDetail = "Raise Time : " + ToolUtilities.time2String(bean.getInsertTime());
        if (!ToolUtilities.isStringEmpty(bean.getRequestId()))
            sDetail += "\nRequest ID : " + bean.getRequestId();
        if (!ToolUtilities.isStringEmpty(bean.getRmtAddr()))
            sDetail += "\nRemote Address : " + bean.getRmtAddr();
        sDetail +="\n"+ bean.getErrorStack();
        
        DetailErrorMsg.showMessage(this, sMsg, sDetail, "Alarm", JOptionPane.INFORMATION_MESSAGE, false);
    }
    
    public void OnDeleteAlarms() throws Exception
    {
        int[] rows = jTbl_Data.getSelectedRows();
        if (rows == null)
            return ;
        
        Set<String> setID = new HashSet<>();
        for (int i=0;i<rows.length;i++)
            setID.add(((MsAlarmBean)_model.getValueAt(rows[i], _col_bean)).getMyID());
        
        if (false) CMsClient.getIntf().deleteAlarmBatch(setID);
        JWaitDialog.showWaitDialog("Deleting alarms", this, CMsClient.getIntf(), "deleteAlarmBatch", setID);
        
        reload();
    }
    
    public void OnRightClickTable(Point pt)
    {
        JPopupMenu pop = new JPopupMenu();
        pop.add(GuiUtil.createMenuItem("remove.png", "Delete Selection", new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try
                {
                    OnDeleteAlarms();
                } catch (Exception exp)
                {
                    DetailErrorMsg.showError(exp);
                }
            }
        }));
        
        pop.show(jTbl_Data, (int)pt.getX(), (int)pt.getY());
    }
}
