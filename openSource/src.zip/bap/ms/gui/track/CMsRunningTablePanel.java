package bap.ms.gui.track;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.Box;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.project.gui.common.GuiUtil;

public class CMsRunningTablePanel extends JPanel
{

    SortableModel _model = new SortableModel();
    JTable jTbl_Data = new JTable(_model);
    public final static String[] _header = new String[]{"Pending Running","Start Time"};
    
    public void showData(List<MsTrackBean> lstData)
    {
        int[] selRows = jTbl_Data.getSelectedRows();
        GuiUtil.clearTableRows(_model);
        
        if (lstData == null)
            return;
        
        for (MsTrackBean b : lstData)
        {
            addRow(b);
        }
        GuiUtil.adjustTableColumnWidth(jTbl_Data);
        
        if (selRows != null)
            for (int sel : selRows)
                jTbl_Data.setRowSelectionInterval(sel, sel);
    }
    
    public void addRow(MsTrackBean bean)
    {
        _model.addRow(new Object[]{bean, ToolUtilities.time2StringNoYear(bean.getStartTime(), false)});
    }
    
    public CMsRunningTablePanel()
    {
        jbInit();
    }
    
    public void jbInit()
    {
        Box boxMain = Box.createVerticalBox();
        
        for (String h : _header)
            _model.addColumn(dfcutil.getString(h));
        
        CMsTrackPanel.getStyleUtil().setTableStyle(jTbl_Data);
        
        
        JScrollPane jScrTable = new JScrollPane(jTbl_Data);
        CMsTrackPanel.getStyleUtil().setScrollPanel(jScrTable);
        
        boxMain.add(jScrTable);
        
        GuiUtil.setGridLayout(this, boxMain);
        
        jTbl_Data.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e) {
                if (GuiUtil.isDoubleClickLeft(e))
                    OnDbClickTable();
                else if (e.getClickCount() >= 2 && e.getButton()==MouseEvent.BUTTON3)
                    OnDbRightClickTable();
            }

        });
    }

    public void OnDbRightClickTable()
    {
        int selRow =  jTbl_Data.getSelectedRow();
        if (selRow < 0)
            return ;
        
        MsTrackBean bean = (MsTrackBean) _model.getValueAt(selRow, 0);
        String sMsg = bean.getMyInterfaceKey();
        
        
        String sDetail = "Start Time : " + ToolUtilities.time2String(bean.getStartTime());
        sDetail += "\nSource Agent : "+bean.getSrcAgent();
        sDetail += "\nTarget Agent : "+bean.getDstAgent();
        sDetail += "\nRequest ID : " + bean.getMyID();
        
        DetailErrorMsg.showMessage(this, sMsg, sDetail, "Alarm", JOptionPane.INFORMATION_MESSAGE, false);
    }
    
    public void OnDbClickTable()
    {
        int selRow =  jTbl_Data.getSelectedRow();
        if (selRow < 0)
            return ;
        
        MsTrackBean bean = (MsTrackBean) _model.getValueAt(selRow, 0);
        String sMsg = bean.getMyInterfaceKey();
        
        
        String sDetail = "Start Time : " + ToolUtilities.time2String(bean.getStartTime());
        sDetail += "\nSource Agent : "+bean.getSrcAgent();
        sDetail += "\nTarget Agent : "+bean.getDstAgent();
        sDetail += "\nRequest ID : " + bean.getMyID();
        
        DetailErrorMsg.showMessage(this, sMsg, sDetail, "Alarm", JOptionPane.INFORMATION_MESSAGE, false);
    }
}
