package bap.ms.gui.track.graph;

import com.leavay.dfc.microService.MsType;

public class MsIntfCell extends MsSrvCell
{
    private static final long serialVersionUID = 6995914511524721063L;

    public MsIntfCell(String interfaceKey)
    {
        super(interfaceKey);
    }
    
    public String getImagePath(boolean blVertical)
    {
        if (MsType.isNullKey(getKey()))
            return "images/dfc/start.png";
        else
            return "images/dfc/i.png";
    }
}
