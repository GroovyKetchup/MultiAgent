package bap.ms.gui.track.graph;

import static com.leavay.dfc.gui.microService.JMsTrackPanel.COLOR_BACK;
import static com.leavay.dfc.gui.microService.JMsTrackPanel.COLOR_LABEL;

import java.awt.Color;

import com.leavay.dfc.gui.graph.base.DefaultCell;
import com.leavay.dfc.gui.graph.base.DefaultLink;
import com.mxgraph.util.mxConstants;
import com.mxgraph.util.mxUtils;
import com.project.gui.common.GuiUtil;;
 
public class MsLink extends DefaultLink
{
    boolean isCycleLink = false;
    public MsLink()
    {
        super();
    }
    
    public MsLink(DefaultCell source, DefaultCell target)
    {
        super(source, target);
    }
    
    public void initCellStyle(boolean blVertical)
    {
        super.initCellStyle(blVertical);

        setToolTip(null);
    }
    
    public boolean isCycleLink()
    {
        return isCycleLink;
    }

    public void setCycleLink(boolean isCycleLink)
    {
        this.isCycleLink = isCycleLink;
    }

    public String getStyle(boolean blVertical)
    {
        String style = mxConstants.STYLE_EDGE+"="+(blVertical?mxConstants.EDGESTYLE_ENTITY_RELATION_V:mxConstants.EDGESTYLE_ENTITY_RELATION);
        if (isCycleLink())
            style = mxConstants.STYLE_EDGE+"="+(blVertical?mxConstants.EDGESTYLE_SIDETOSIDE:mxConstants.EDGESTYLE_LOOP_H);
        
        style = mxUtils.setStyle(style, mxConstants.STYLE_STROKECOLOR, getLineColor());
        style = mxUtils.setStyle(style, mxConstants.STYLE_FONTCOLOR, getLabelColor());
        style = mxUtils.setStyle(style, mxConstants.STYLE_LABEL_OFFSET_Y, "-6");
        style = mxUtils.setStyle(style, mxConstants.STYLE_LABEL_BACKGROUNDCOLOR, mxConstants.NONE);
        
        return style;
    }
    static Color colorCycle = new Color(0xC5, 0x6C, 0x86);
    static Color color = new Color(Math.min(255, COLOR_BACK.getRed()+50), Math.min(255, COLOR_BACK.getGreen()+50), Math.min(255, COLOR_BACK.getBlue()+50));
    public String getLineColor()
    {
        return GuiUtil.color2Hex(isCycleLink()?colorCycle:color);
    }
    
    static Color colorLabel = new Color(Math.min(255, COLOR_LABEL.getRed()+50), Math.min(255, COLOR_LABEL.getGreen()+50), Math.min(255, COLOR_LABEL.getBlue()+50));
    public String getLabelColor()
    {
        return GuiUtil.color2Hex(isCycleLink()?colorCycle:colorLabel);
    }
    
    public Object clone()
    {
        MsLink o = (MsLink) super.clone();
        return o;
    }
}
