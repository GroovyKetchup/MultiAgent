package bap.ms.gui.track.graph;

import com.leavay.dfc.gui.microService.JMsTrackPanel;
import com.leavay.dfc.microService.MsType;
import com.mxgraph.model.mxGeometry;
import com.mxgraph.util.mxConstants;
import com.mxgraph.util.mxUtils;
import com.project.gui.common.GuiUtil;

import bap.gui.ImageCell;

public class MsSrvCell extends ImageCell
{
    
    public MsSrvCell(String service)
    {
        super(service);
        
        setGeometry(new mxGeometry(0, 0, 32, 32));
    }


    public void initCellStyle(boolean blVertical)
    {
        super.initCellStyle(blVertical);
        
        setStyle(mxUtils.setStyle(getStyle(), mxConstants.STYLE_FONTCOLOR, GuiUtil.color2Hex(JMsTrackPanel.COLOR_LABEL)));
    }

    public String getImagePath(boolean blVertical)
    {
        if (MsType.isNullKey(getKey()))
            return "images/dfc/start.png";
        else if (MsType.isFBomService(getKey()))
            return "images/dfc/f.png";
        else
            return "images/dfc/s.png";
    }

    public String getLabel()
    {
        if (MsType.isNullKey(getKey()))
            return "Outside Entry";
        else
            return MsType.getSimpleServiceName(getKey());
    }
    
    public String getToolTip()
    {
        return getKey();
    }

    public String getKey()
    {
        return (String)getValue();
    }
}
