package bap.ms.gui.track.graph;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import org.w3c.dom.Document;

import com.leavay.client.util.MBox;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.Pair;
import com.leavay.common.util.RelationMap;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.Draw2dLayouterEx;
import com.leavay.dfc.gui.DflowPattern.DFPCell;
import com.leavay.dfc.gui.graph.base.DefaultCell;
import com.leavay.dfc.gui.microService.JMsTrackPanel;
import com.leavay.dfc.microService.MsType;
import com.leavay.dfc.microService.track.CallPair;
import com.leavay.dfc.microService.track.filter.MsCallStastic;
import com.leavay.dfc.microService.track.filter.MsFilterReq;
import com.leavay.dfc.microService.track.filter.MsFilter_StasticService;
import com.mxgraph.io.mxCodec;
import com.mxgraph.model.mxCell;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.swing.examples.FreeGraphEditor;
import com.mxgraph.swing.extend.BaseGraphEditor;
import com.mxgraph.util.mxUtils;
import com.mxgraph.view.mxGraph;
import com.mxgraph.view.mxGraphSelectionModel.CellSelectChangeListner;
import com.mxgraph.view.mxGraphSelectionModel.mxSelectionChange;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import bap.client.BapClient;
import bap.client.BapGuiUtil;
import bap.java.CJavaClassSearchPanel;
import bap.java.CJavaCode;
import bap.ms.gui.CMsClient;

public class CMsGraphPanel extends JPanel
{
    mxGraph graph;
    protected mxGraphComponent graphCmp;
    Timer _tm = new Timer("Refresh Stastic");
    
    JCheckBox jChk_ShowServiceInterface;

    public CMsGraphPanel()
    {
        jbInit();
    }
    
    public void jbInit()
    {
        initGraph();
        
        Box boxMain = Box.createVerticalBox();
        
        jChk_ShowServiceInterface = new JCheckBox("Show all interface");
        GuiUtil.setHandCursor(jChk_ShowServiceInterface);
        jChk_ShowServiceInterface.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try
                {
                    showService(_currentService);
                } catch (Exception exp)
                {
                    exp.printStackTrace();
                }
            }
        });
        
        Box toolBar = MBox.createHBar(22, jChk_ShowServiceInterface, MBox.HGlue()); 
        boxMain.add(toolBar);
        boxMain.add(graphCmp);
        
        JMsTrackPanel.getStyleUtil().setBoxStyle(toolBar);
        JMsTrackPanel.getStyleUtil().setCheckboxStyle(jChk_ShowServiceInterface);
        JMsTrackPanel.getStyleUtil().setScrollPanel(graphCmp);
        
        GuiUtil.setGridLayout(this, boxMain);
        graphCmp.setBorder(null);
    }
    
    public void initGraph()
    {
        graph = new mxGraph()
        {
            public boolean isCellContainable(Object cell)
            {
                return false;
            }
            
            public boolean isValidDropTarget(Object cell, Object[] cells)
            {
                if (cell instanceof DFPCell)
                    return true;
                
                return super.isValidDropTarget(cell, cells);
            }
            
            public String getToolTipForCell(Object cell)
            {
                if (cell instanceof DefaultCell)
                    return ((DefaultCell) cell).getToolTip();

                return super.getToolTipForCell(cell);
            }
            
            
            public void cellsAdded(Object[] cells, Object parent, Integer index, Object source, Object target,
                    boolean absolute)
            {
                super.cellsAdded(cells, parent, index, source, target, absolute);

                if (cells != null)
                {
                    for (int i = 0; i < cells.length; ++i)
                    {
                        if (cells[i] != null && cells[i] instanceof DefaultCell)
                        {
                            initCellOverlay((DefaultCell) cells[i]);
                        }
                    }
                }
            }
        };
        // 加载样例样式表，这才是控制cell样式、连线样式的关键
        loadCellStyle();

        
        graph.setSplitEnabled(false);
        graph.setCellsResizable(false);
        graph.setCellsDisconnectable(false);
        graph.setAllowDanglingEdges(false);
        graph.getSelectionModel().addSelectChangeListner(new CellSelectChangeListner()
        {
            public void selectChanged(mxSelectionChange evt)
            {
                try
                {
//                    OnSelectChanged(evt);
                } catch (Exception exp)
                {
                    DetailErrorMsg.showError(exp);
                }
            }
        });

        graphCmp = new BaseGraphEditor(graph){
            public boolean canImportCell(Object cell)
            {
                return super.canImportCell(cell);
            }
            
            protected mxGraphControl createGraphControl()
            {
                return new mxGraphControl(){
                    public void paintBackground(Graphics g)
                    {
                        super.paintBackground(g);
                    }
                };
            }
        };
        graphCmp.setForeground(Color.red);
        graphCmp.setConnectable(false);
        graphCmp.setEditable(false);
        // graphCmp.setBorder(BorderFactory.createEmptyBorder());

        graphCmp.getGraphControl().setGraphBackground(JMsTrackPanel.COLOR_BACK);
        // graphCmp.getGraphControl().setBorder(BorderFactory.createEmptyBorder());
        graphCmp.getViewport().setOpaque(false);
        // graphCmp.setGridVisible(true);
        graphCmp.setToolTips(true);

        graphCmp.getVerticalScrollBar().setUnitIncrement(30);
        graphCmp.getHorizontalScrollBar().setUnitIncrement(30);

        graphCmp.getGraphControl().addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e)
            {
                try
                {
                    if (e.getClickCount() >= 2 && e.getButton() == MouseEvent.BUTTON1)
                        OnDBClickCell(e);
                    else if (e.getButton() == MouseEvent.BUTTON3)
                        OnRightClickCell(e);
                } catch (Exception exp)
                {
                    DetailErrorMsg.showError(exp);
                }
            }
        });

        graphCmp.addKeyListener(new KeyAdapter()
        {
            public void keyPressed(KeyEvent e)
            {
             
            }
        });
    }
    
    public void loadCellStyle()
    {
        mxCodec codec = new mxCodec();
        Document doc = mxUtils.loadDocument(FreeGraphEditor.class.getResource("/graph-defult-style.xml").toString());
        codec.decode(doc.getDocumentElement(), graph.getStylesheet());
    }
    
    public void initCellOverlay(DefaultCell cell)
    {
        if (cell != null && graphCmp != null)
            cell.initOverlay(graphCmp);
    }
    
    
    String _currentService;
    String _currentInterface;
    protected void setCurrentData(String service, String intf)
    {
        _currentService = service;
        _currentInterface = intf;
    }
    
    public boolean isCurrentInterface()
    {
        return !ToolUtilities.isStringEmpty(_currentInterface);
    }
    
    public void showService(String service) throws Exception
    {
        setCurrentData(service, null);
        jChk_ShowServiceInterface.setVisible(true);
        
        graph.removeAll();
        RelationMap relMap = null;
        List<Pair<String, String>> lstCyclePath = new LinkedList();
        if (jChk_ShowServiceInterface.isSelected())
        {
            RelationMap srvRelMap = (RelationMap) CMsClient.getIntf().queryTrackData(MsFilterReq.newReq(MsFilter_StasticService.SERVICE_STASTIC_RELATION_INTERFACE).setParam(service));
            HashSet<String> setAll = new HashSet(srvRelMap.getSourceKeys());
            setAll.addAll(srvRelMap.getTargetKeys());
            
            relMap = new RelationMap();
            for (Iterator<String> it = setAll.iterator(); it.hasNext();)
            {
                String intf = it.next();
                if (intf.startsWith(_currentService+ MsType.SERVICE_INTERFACE_SPLIT))
                {
                    RelationMap oneMap = srvRelMap.getAllPathOf_SortFromHead(intf, lstCyclePath);
                    if (oneMap != null)
                        relMap.addAll(oneMap);
                }
            }
        }else
        {
            RelationMap srvRelMap = (RelationMap) CMsClient.getIntf().queryTrackData(MsFilterReq.newReq(MsFilter_StasticService.SERVICE_STASTIC_RELATION_SERVICE).setParam(service));
            relMap = srvRelMap.getAllPathOf_SortFromHead(service, lstCyclePath);
        }
        graph.getModel().beginUpdate();
        try
        {
            Map<String, Set<String>> allRel = relMap.getAllSource2Target();
            for (Entry<String, Set<String>> ent : allRel.entrySet())
            {
                if (ent.getValue() != null)
                    for (String dst : ent.getValue())
                    {
                        MsSrvCell srcC = getOrCreateCell(ent.getKey());
                        MsSrvCell dstC = getOrCreateCell(dst);
                        graph.addCell(createLink(srcC, dstC, false));
                    }
            }
        }finally
        {
            graph.getModel().endUpdate();
        }
        
        autoLayout(true);
     
        graph.getModel().beginUpdate();
        try
        {
            for (Pair<String, String> cycelLink : lstCyclePath)
            {
                if (ToolUtilities.isObjectEmpty(graph.getEdgesBetween(cycelLink.getKey(), cycelLink.getValue())))
                {
                    MsSrvCell srcC = getOrCreateCell(cycelLink.getKey());
                    MsSrvCell dstC = getOrCreateCell(cycelLink.getValue());
                    graph.addCell(createLink(srcC, dstC, true));
                }
            }
        }finally
        {
            graph.getModel().endUpdate();
        }
        
        // 刷一遍统计数据
        startRefreshStastic();
    }
    
    public void showInterface(String interfaceKey) throws Exception
    {
        jChk_ShowServiceInterface.setVisible(false);
        
        String srvKey = MsType.getServiceOfInterface(interfaceKey);
        String intf = MsType.getInterfaceOfKey(interfaceKey);
        setCurrentData(srvKey, intf);
        
        graph.removeAll();
        RelationMap srvRelMap = (RelationMap) CMsClient.getIntf().queryTrackData(MsFilterReq.newReq(MsFilter_StasticService.SERVICE_STASTIC_RELATION_INTERFACE));
        List<Pair<String, String>> lstCyclePath = new LinkedList();
        RelationMap relMap = srvRelMap.getAllPathOf_SortFromHead(interfaceKey, lstCyclePath);
        
        graph.getModel().beginUpdate();
        try
        {
            Map<String, Set<String>> allRel = relMap.getAllSource2Target();
            for (Entry<String, Set<String>> ent : allRel.entrySet())
            {
                if (ent.getValue() != null)
                    for (String dst : ent.getValue())
                    {
                        MsSrvCell srcC = getOrCreateCell(ent.getKey());
                        MsSrvCell dstC = getOrCreateCell(dst);
                        graph.addCell(createLink(srcC, dstC, false));
                    }
            }
        }finally
        {
            graph.getModel().endUpdate();
        }
        
        autoLayout(true);
     
        graph.getModel().beginUpdate();
        try
        {
            for (Pair<String, String> cycelLink : lstCyclePath)
            {
                if (ToolUtilities.isObjectEmpty(graph.getEdgesBetween(cycelLink.getKey(), cycelLink.getValue())))
                {
                    MsSrvCell srcC = getOrCreateCell(cycelLink.getKey());
                    MsSrvCell dstC = getOrCreateCell(cycelLink.getValue());
                    graph.addCell(createLink(srcC, dstC, true));
                }
            }
        }finally
        {
            graph.getModel().endUpdate();
        }
        
        // 刷一遍统计数据
        startRefreshStastic();
    }

    public void startRefreshStastic()
    {
        _tm.cancel();
        _tm.purge();
        _tm = new Timer();
        _tm.schedule(new TimerTask()
        {
            public void run()
            {
                try
                {
                    refreshStastic();
                } catch (Exception exp)
                {
                    exp.printStackTrace();
                }
            }
        }, 0, 2000);
    }
    
    public void insertAllSrouce(RelationMap relMap, String dst)
    {
        MsSrvCell dstC = getOrCreateCell(dst);
        Set<String> setSrc = relMap.getSource(dst);
        if (setSrc != null)
            for (String src : setSrc)
            {
                MsSrvCell srcC = getOrCreateCell(src);
                if (ToolUtilities.isObjectEmpty(graph.getEdgesBetween(srcC, dstC)))
                {
                    graph.addCell(createLink(srcC, dstC, false));
                    insertAllSrouce(relMap, src);
                }
            }
    }
    
    public void insertAllTarget(RelationMap relMap, String src)
    {
        MsSrvCell srcC = getOrCreateCell(src);
        Set<String> setDst = relMap.getTarget(src);
        if (setDst != null)
            for (String dst : setDst)
            {
                MsSrvCell dstC = getOrCreateCell(dst);
                if (ToolUtilities.isObjectEmpty(graph.getEdgesBetween(srcC, dstC)))
                {
                    graph.addCell(createLink(srcC, dstC, false));
                    insertAllTarget(relMap, dst);
                }
            }
    }
    
    public MsSrvCell getOrCreateCell(String key)
    {
        MsSrvCell dstC = (MsSrvCell) graph.getCellByKey(key);
        if (dstC == null)
        {
            dstC = createCell(key);
            graph.addCell(dstC);
        }
        
        return dstC;
    }
    
    public MsSrvCell createCell(String skey)
    {
        if (isCurrentInterface())
            return new MsIntfCell(skey);
        else
            return new MsSrvCell(skey);
    }
    
    public MsLink createLink(MsSrvCell src, MsSrvCell dst, boolean isCycleLink)
    {
        MsLink lnk = new MsLink(src, dst);
        lnk.setCycleLink(isCycleLink);
        lnk.initCellStyle();
        return lnk;
    }
    
    public void autoLayout(boolean isVertical)
    {
        Draw2dLayouterEx layouter = new Draw2dLayouterEx(graph);
        layouter.setOffsetX(50);
        layouter.setOffsetY(50);
        layouter.doLayout(false, true, 50, 0);
        if (true)
            return;
    }
    
    public void refreshStastic() throws Exception
    {
        Set<CallPair> setCp = new TreeSet();
        List<mxCell> allLinks = graph.getAllEdges();
        for (mxCell lnk : allLinks)
        {
            MsSrvCell src = (MsSrvCell) lnk.getSource();
            MsSrvCell dst = (MsSrvCell) lnk.getTarget();
            if (src != null && dst != null)
                setCp.add(new CallPair(src.getKey(), dst.getKey()));
        }
        
        TreeMap<CallPair, MsCallStastic> sts = null;
        if (isCurrentInterface() || jChk_ShowServiceInterface.isSelected())
            sts = (TreeMap<CallPair, MsCallStastic>) CMsClient.getIntf().queryTrackData(MsFilterReq.newReq(MsFilter_StasticService.SERVICE_STASTIC_INTERFACE_CALL_STASTIC).setParam(setCp));
        else
            sts = (TreeMap<CallPair, MsCallStastic>) CMsClient.getIntf().queryTrackData(MsFilterReq.newReq(MsFilter_StasticService.SERVICE_STASTIC_SERVICE_CALL_STASTIC).setParam(setCp));
        
        if (false) showStastic(sts);
        GuiUtil.invokeLater(this, "showStastic", sts);
    }
    
    public void showStastic(TreeMap<CallPair, MsCallStastic> sts)
    {
        graph.getModel().beginUpdate();
        try
        {
            for (Entry<CallPair, MsCallStastic> ent : sts.entrySet())
            {
                Object src = graph.getCellByKey(ent.getKey().getSrc());
                Object dst = graph.getCellByKey(ent.getKey().getDst());
                if (src == null || dst == null)
                    continue;

                Object[] lnks = graph.getEdgesBetween(src, dst);
                MsLink lnk = (MsLink) ToolUtilities.getParamObject(lnks, 0, null);
                if (lnk != null)
                {
                    MsCallStastic callSts = ent.getValue();
                    if (callSts != null)
                    {
                        String msg = "" + callSts.getCount();
                        String avgDur = new BigDecimal(callSts.getAvgDuration()).setScale(1, BigDecimal.ROUND_HALF_UP).toString();
                        lnk.setToolTip("Average Duration = " + avgDur + "ms");
                        lnk.setLabel(msg);
                        graph.updateCell(lnk, msg);
                    }else
                    {
                        lnk.setLabel("Unknown");
                        graph.updateCell(lnk, "Unknown");
                    }
                }
            }
        }finally
        {
            graph.getModel().endUpdate();
        }
    }
    
    public void OnDBClickCell(MouseEvent e) throws Exception
    {
        Object cell = graph.getSelectionCell();
        if (cell == null || !MsSrvCell.class.isInstance(cell))
            return;
        
        MsSrvCell msCell = (MsSrvCell)cell;
        String selKey = msCell.getKey();
        if (MsType.isInterfaceKey(selKey))
        {
            showInterface(selKey);
        }else
            showService(selKey);
    }
    
    public void OnRightClickCell(MouseEvent e)
    {
        JPopupMenu pop = new JPopupMenu();
        JMenuItem jMItem = GuiUtil.createMenuItem("redo_16.png", "Open Source Code", new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try
                {
                    openSource();
                } catch (Exception exp)
                {
                    DetailErrorMsg.showError(exp);
                }
            }
        });
        pop.add(jMItem);
        pop.show(graphCmp, (int)graphCmp.getMousePosition().getX(), (int)graphCmp.getMousePosition().getY());
    }
    
    public void openSource() throws Exception
    {
        Object cell = graph.getSelectionCell();
        if (cell == null || !MsSrvCell.class.isInstance(cell))
            return;

        MsSrvCell msCell = (MsSrvCell) cell;
        String selService = null;
        String selIntf = null;
        if (MsType.isInterfaceKey(msCell.getKey()))
        {
            selService = MsType.getServiceOfInterface(msCell.getKey());
            selIntf = MsType.getInterfaceOfKey(msCell.getKey());
        } else
            selService = msCell.getKey();

        CJavaCode jcode = null;

        List<CJavaCode> lstCode = BapClient.getJavaIntf().searchCode(selService);
        if (ToolUtilities.getObjectSize(lstCode) == 1)
            jcode = lstCode.get(0);

        // 直接搜不到或者有多个可选，则给一个选择框让用户选
        if (jcode == null)
        {
            CJavaClassSearchPanel jSearchClassPanel = new CJavaClassSearchPanel();
            jSearchClassPanel.jTxt_Key.setText(msCell.getKey());
            jSearchClassPanel.jTxt_Key.grabFocus();
            JSimpleDialog jDlgSearchClass = GuiUtil.createSimpleDialog(jSearchClassPanel, this, GuiUtil.getTranslator(), true);
            jDlgSearchClass.pack();
            GuiUtil.centerWindow(jDlgSearchClass);
            if (!jDlgSearchClass.showModel(true))
                return;

            jcode = jSearchClassPanel.getSelectCode();
        }

        if (jcode == null)
            throw new Exception(GuiUtil.getString("Can not find service class") + " : " + msCell.getKey());

        BapGuiUtil.openCode(jcode.getProjectUuid(), jcode.getFullClassName());
    }
}
