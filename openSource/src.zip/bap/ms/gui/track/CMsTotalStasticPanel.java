package bap.ms.gui.track;

public class CMsTotalStasticPanel
{

}
