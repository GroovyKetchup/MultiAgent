package bap.ms.gui.track;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.dbutil;
import com.leavay.starter.StarterParam;
import com.project.gui.common.component.JTextField_Integer;

public class CMsGuiPlugin
{
    // 创建参数的编辑控件
    // 简单根据key和类型，决定组件
    // 和下面的getMsAgentParamValue配套显示和取值
    public JComponent createMsAgentParamCtrl(StarterParam param, String value)
    {
        if ("base.DBPool.driverName".equals(param.getKey()))
        {
            JComboBox<String> jCmb = new JComboBox<String>();
            jCmb.setEditable(true);
            jCmb.addItem(dbutil.s_Driver_PG);
            jCmb.setSelectedItem(value);
            return jCmb;
        }
        
        if (param.isBoolean())
        {
            JCheckBox jChk = new JCheckBox();
            jChk.setSelected(ToolUtilities.getBoolean(value, false));
            return jChk;
        }
        else
        {
            JTextField jTxt = new JTextField();
            if (param.isInt())
                jTxt = new JTextField_Integer();
            
            jTxt.setText(ToolUtilities.getString(value, getParamDefaultValue(param)));
            return jTxt;
        }
    }

    public String getMsAgentParamValue(StarterParam param, JComponent cmp)
    {
        if (cmp instanceof JComboBox)
            return ToolUtilities.getString(((JComboBox)cmp).getSelectedItem(), null);
        else if (cmp instanceof JCheckBox)
            return ""+((JCheckBox)cmp).isSelected();
        else if (cmp instanceof JTextComponent)
            return ToolUtilities.getString(((JTextComponent)cmp).getText(), null);
        
        return null;
    }
    
    // 就简单根据固定参数提供默认值，不搞太复杂，只是给技术人员使用的
    public String getParamDefaultValue(StarterParam param)
    {
        if ("base.DBPool.dbName".equals(param.getKey()))
            return dbutil.getDefaultUrl(dbutil.s_TYPE_PG);
        
        return "";
    }
    
}
