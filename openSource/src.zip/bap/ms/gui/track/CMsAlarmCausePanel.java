package bap.ms.gui.track;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Paint;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.entity.PieSectionEntity;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.DefaultDrawingSupplier;
import org.jfree.chart.plot.RingPlot;
import org.jfree.data.general.DefaultPieDataset;

import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dfcutil;
import com.project.gui.common.GuiUtil;

public class CMsAlarmCausePanel<T> extends JPanel
{
    private static final long serialVersionUID = 3638481820273388401L;
    static Color COLOR_BACK = new Color(0x35, 0x5c, 0x7d);
    static Color COLOR_LABEL = new Color(0x70, 0xAF, 0xCE);
    
    DefaultPieDataset _dataSet = new DefaultPieDataset();
    String _title = dfcutil.getString("Cause Stastic");
    JFreeChart jCntChart = ChartFactory.createRingChart(_title, _dataSet, false, true, false);
    
    public void setTitle(String title)
    {
        _title = title;
        updateTitle(null);
    }
    
    public CMsAlarmCausePanel()
    {
        ChartPanel chartPanel = new ChartPanel(jCntChart);
        jCntChart.getTitle().setPaint(COLOR_LABEL);
        jCntChart.getPlot().setBackgroundPaint(COLOR_BACK );
        jCntChart.getPlot().setOutlinePaint(COLOR_BACK);

        jCntChart.setBackgroundPaint(COLOR_BACK);
        
        RingPlot ringplot = (RingPlot) jCntChart.getPlot();
        ringplot.setOutlineVisible(false);
        //{2}表示显示百分比
        ringplot.setLabelGenerator(new StandardPieSectionLabelGenerator("{2}"));
        ringplot.setBackgroundPaint(COLOR_BACK);
        ringplot.setOutlineVisible(false);
        //设置标签样式
        ringplot.setLabelFont(new Font("宋体", Font.BOLD, 15));
        ringplot.setSimpleLabels(true);
        ringplot.setLabelLinkPaint(COLOR_BACK);
        ringplot.setLabelOutlinePaint(COLOR_BACK);
        ringplot.setLabelLinksVisible(false);
        ringplot.setLabelShadowPaint(null);
        ringplot.setLabelOutlinePaint(new Color(0,true));
        ringplot.setLabelBackgroundPaint(null);
        ringplot.setLabelPaint(COLOR_LABEL);
        
        ringplot.setSectionOutlinePaint(COLOR_BACK);
        ringplot.setSeparatorsVisible(true);
        ringplot.setSeparatorPaint(COLOR_BACK);
        ringplot.setShadowGenerator(null);
        ringplot.setShadowPaint(COLOR_BACK);
        ringplot.setSectionDepth(0.2);
        ringplot.setStartAngle(90);
        ringplot.setDrawingSupplier(new DefaultDrawingSupplier(
                new Paint[] { 
                        new Color(134, 212, 222), 
                        new Color(174, 145, 195), 
                        new Color(255, 162, 195),
                        new Color(249, 163, 86),
                        new Color(119, 173, 195),
                        new Color(0x00, 0xE0, 0xC7),
                        new Color(0xFF, 0xAB, 0x40),
                        new Color(0xFF, 0x6D, 0x00),
                        new Color(0xA5, 0xDE, 0xF1),
                        },
                DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE, 
                DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE,
                DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE, 
                DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE));

        
        
        chartPanel.addChartMouseListener(new ChartMouseListener()
        {
            public void chartMouseMoved(ChartMouseEvent var1)
            {
                if (var1.getEntity() != null && var1.getEntity() instanceof PieSectionEntity)
                {
                    setCursor(new Cursor(Cursor.HAND_CURSOR));
                }
                else
                {
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
            
            public void chartMouseClicked(ChartMouseEvent var1)
            {
                ChartEntity ent = var1.getEntity();
                if (ent instanceof PieSectionEntity)
                {
                    T key = (T)((PieSectionEntity)ent).getSectionKey();
                    OnClickItem(key);
                }
            }
        });
        
        GuiUtil.setGridLayout(this, chartPanel);
        
        showData(null);
    }
    
    public void OnClickItem(T sectionKey)
    {
        
    }
    
    public void updateTitle(String moveOnItem)
    {
        String s = ToolUtilities.getString(moveOnItem, null);
        if (ToolUtilities.isStringEmpty(s))
            jCntChart.setTitle(_title);
        else
            jCntChart.setTitle(s);
    }
    
    public void showData(LinkedHashMap<Comparable, Number> mapData)
    {
        removeAllValue();
        if (mapData != null)
            for (Entry<Comparable, Number> ent : mapData.entrySet())
            {
                if (ent.getKey() == null)
                    continue;
                _dataSet.setValue(ent.getKey(), ent.getValue());
            }

//        _dataSet.setValue("Exception", 235);
//        _dataSet.setValue("Throwable", 33);
//        _dataSet.setValue("Test2", 532);
//        _dataSet.setValue("Test55", 1232);
//        _dataSet.setValue("Test65", 798);
//        _dataSet.setValue("Test66", 345);
//        _dataSet.setValue("Test67", 22);
//        _dataSet.setValue("Test68", 100);
//        _dataSet.setValue("Test69", 500);
//        _dataSet.setValue("Test60", 0);
    }
    
    public void removeAllValue()
    {
        _dataSet.clear();
    }
}
