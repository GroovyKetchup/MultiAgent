package bap.ms.gui.track;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.List;

import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.leavay.client.util.MBox;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.JSimplePagePanel;

public class CMsDetailTablePanel extends JPanel
{

    static Color COLOR_BACK = new Color(0x35, 0x5c, 0x7d);
    static Color COLOR_LABEL = new Color(0x70, 0xAF, 0xCE);
    
    SortableModel _model = new SortableModel();
    JTable jTbl_Data = new JTable(_model);
    public final static String[] _header = new String[]{"Data", "MsType", "Name","Interface","Start Time", "End Time", "Duration(ms)", "Depth", "Client"};
            
    JSimplePagePanel<MsTrackBean> jPage = new JSimplePagePanel<MsTrackBean>(dfcutil.getInstance())
    {
        public Component createToolBar()
        {
            jToolBar = MBox.createHBar(22, jBtn_FirstPage
                    , MBox.HStrut(2), jBtn_PrevPage
                    , MBox.HStrut(2), jLab_Text
                    , MBox.HStrut(2), jBtn_NextPage
                    , MBox.HStrut(5), jCmb_PageSize);
            return jToolBar;
        }
        
        public void showError(Throwable err)
        {
            DetailErrorMsg.showError(err);
        }
        
        public void showData(List<MsTrackBean> lstData)
        {
            GuiUtil.clearTableRows(_model);
            for (MsTrackBean bean : lstData)
                addRow(bean);
            
            GuiUtil.adjustTableColumnWidth(jTbl_Data, false);
        }
        
        protected MultiPageResult<MsTrackBean> CallBack_LoadPage(int startPos, int pageSize) throws Exception
        {
            return dfcutil.getDfcIntf().queryMsTrack(false, startPos, pageSize);
//            return new MultiPageResult();
        }
    };
    
    public void addRow(MsTrackBean bean)
    {
        String sEndTime = "";//bean.getEndTime() <=0?"":ToolUtilities.time2String(bean.getEndTime());
        String sDuration = "";//bean.getEndTime() <=0?"":bean.getDuration()+"";
        bean.getMyID();
        bean.getpID();
        bean.getRootID();
        _model.addRow(new Object[]{bean, bean.getServiceType(), bean.getServiceName(), bean.getServiceInterface(), ToolUtilities.time2String(bean.getStartTime()), sEndTime, sDuration, bean.getDepth(), bean.getRmtAddr()});
    }
    
    public CMsDetailTablePanel()
    {
        jbInit();
        
        refresh();
    }
    
    public void refresh()
    {
        jPage.loadPageData(0);
    }
    
    public void jbInit()
    {
        Box boxMain = Box.createVerticalBox();
        
        for (String h : _header)
            _model.addColumn(dfcutil.getString(h));
        
        CMsTrackPanel.getStyleUtil().setTableStyle(jTbl_Data);
        
        CMsTrackPanel.getStyleUtil().setSimplePagePanel(jPage);
//        jPage.setPreferredSize(new Dimension(100, 22));
        
        JScrollPane jScrTable = new JScrollPane(jTbl_Data);
        CMsTrackPanel.getStyleUtil().setScrollPanel(jScrTable);
        
        boxMain.add(jScrTable);
        boxMain.add(jPage);
        
        GuiUtil.setGridLayout(this, boxMain);
    }
}
