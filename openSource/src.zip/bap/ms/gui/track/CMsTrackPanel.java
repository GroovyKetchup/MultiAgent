package bap.ms.gui.track;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSplitPane;

import org.nutz.dao.Cnd;
import org.nutz.dao.util.cri.SqlExpression;

import com.leavay.client.util.MBox;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.KeyValuePair;
import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.ResourceMgr.LoadingWidget;
import com.leavay.dfc.microService.MsZkConst;
import com.leavay.dfc.microService.bean.MsAlarmBean;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.leavay.dfc.microService.track.filter.MsCallStastic;
import com.leavay.dfc.microService.track.filter.MsFilterReq;
import com.leavay.dfc.microService.track.filter.MsFilterReqList;
import com.leavay.dfc.microService.track.filter.MsFilterTag;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.JFreeChartUtil;
import com.project.gui.common.JWaitDialog;
import com.project.gui.common.style.FlatStyleUtil;
import com.project.gui.component.MyCardLayout;

import bap.ms.CMsCenter.ALARM_STASTIC_KEY;
import bap.ms.gui.CMsClient;
import bap.ms.gui.track.graph.CMsGraphPanel;
import bap.ms.track.CMsFilter_Error;
import bap.ms.track.CMsFilter_Finish;
import bap.ms.track.CMsFilter_Main;
import bap.ms.track.CMsFilter_StasticService;
import bap.ms.track.CMsTrackCenter;

public class CMsTrackPanel extends JPanel implements ActionListener
{
    public final static Color COLOR_BACK = new Color(0x35, 0x5c, 0x7d);
    public final static Color COLOR_LABEL = new Color(0x70, 0xAF, 0xCE);
    
    static{
        JFreeChartUtil.initJFreeChart();
    }
    
    JButton jBtnStartStop = GuiUtil.createToolButton("start_16.png", "Start Monitor", this);

    CMsDurationPanel jDurationPanel = new CMsDurationPanel(){
        public void OnClickService(KeyValuePair serviceKey)
        {
            try
            {
                showServiceGraph((String) serviceKey.getKey());
            } catch (Exception exp)
            {
                DetailErrorMsg.showError(exp);
            }
        }
    };

    CMsTpsPanel jTpsPanel = new CMsTpsPanel();

    CMsTopServicePanel jTopPanel = new CMsTopServicePanel()
    {
        public void OnClickService(KeyValuePair serviceKey)
        {
            try
            {
                showServiceGraph((String) serviceKey.getKey());
            } catch (Exception exp)
            {
                DetailErrorMsg.showError(exp);
            }
        }
    };

    CMsAlarmRtPanel jErrorPanel = new CMsAlarmRtPanel(){
        public void OnClickItem(String periodicTag)
        {
            OnClickErrorItem(periodicTag);
        }
    };
    
    CMsAlarmTablePanel jAlarmTablePanel = new CMsAlarmTablePanel();
    
    CMsAlarmCausePanel jAlarmCausePanel = new CMsAlarmCausePanel<String>(){
        public void OnClickItem(String sectionKey)
        {
            OnClickStasticCause(sectionKey);
        }
    };
    CMsAlarmRootCausePanel jAlarmRootCausePanel = new CMsAlarmRootCausePanel(){
        public void OnClickItem(String sectionKey)
        {
            OnClickStasticRootCause(sectionKey);
        }
    };
    CMsAlarmLevelPanel jAlarmLevelPanel = new CMsAlarmLevelPanel(){
        public void OnClick(int level)
        {
            OnClickStasticLevel(level);
        }
        

        public void OnRightClick(int level, MouseEvent e)
        {
            OnRightClickStasticLevel(level, e);
        }
    };
    CMsAlarmMsgPanel jAlarmMsgPanel = new CMsAlarmMsgPanel(){
        public void OnClickItem(String sectionKey)
        {
            OnClickStasticMsg(sectionKey);
        }
    };
    
    CMsAgentStasticPanel jAgentPanel = new CMsAgentStasticPanel();
    
    CMsAlarmAgentPanel jAlarmAgentPanel = new CMsAlarmAgentPanel(){
        public void OnClickItem(KeyValuePair itemKey)
        {
            OnClickStasticAgent((String) itemKey.getKey());
        }
    };
    
    CMsGraphPanel jMsGraphPanel = new CMsGraphPanel();
    
    JPanel jMainPanel = new JPanel();
    MyCardLayout jLayoutCard = new MyCardLayout();
    
    CMsRunningTablePanel jRuningPanel = new CMsRunningTablePanel()
    {
        public void OnDbClickTable()
        {
            try
            {
                int selRow = jTbl_Data.getSelectedRow();
                if (selRow < 0)
                    return;

                MsTrackBean bean = (MsTrackBean) _model.getValueAt(selRow, 0);
                showInterfaceGraph(bean.getMyInterfaceKey());
            } catch (Exception exp)
            {
                DetailErrorMsg.showError(exp);
            }
        }
    };
    
    JLabel jLabZkError = new JLabel(GuiResource.getIcon("dfc/Error_flash_16.png"));
    LoadingWidget jMainBuffer = new LoadingWidget(CmnUtil.getString("Main Buffer"));
    LoadingWidget jAlarmDbBuffer = new LoadingWidget(CmnUtil.getString("Alarm DB Buffer"));
    LoadingWidget jRunningBuffer = new LoadingWidget(CmnUtil.getString("Running Filter Buffer"));
    LoadingWidget jErrorBuffer = new LoadingWidget(CmnUtil.getString("Error Filter Buffer"));
    LoadingWidget jFinishBuffer = new LoadingWidget(CmnUtil.getString("Finished Filter Buffer"));
    
    public CMsTrackPanel() throws Exception
    {
        jbInit();

        updateButtonStatus(CMsClient.getIntf().isTrackMonitorStarted());

        startTimer();
    }

    static final String PANEL_ALARM_TABLE = "PANEL_ALARM_TABLE";
    static final String PANEL_SERVICE_GRAPH = "PANEL_SERVICE_GRAPH";
    public void jbInit()
    {
        jMainPanel.setLayout(jLayoutCard);
        jLayoutCard.addAndShow(jMainPanel, PANEL_SERVICE_GRAPH, jMsGraphPanel);
        jLayoutCard.addAndShow(jMainPanel, PANEL_ALARM_TABLE, jAlarmTablePanel);
        
        Box mainBox = Box.createVerticalBox();

        hideZkError();
        jLabZkError.setForeground(Color.RED);
        
        setButtonStyle(jBtnStartStop);
        Box toolBar = MBox.createHBar(22, jBtnStartStop, MBox.HGlue(), jLabZkError, MBox.HStrut(2), jMainBuffer, MBox.HStrut(2), jAlarmDbBuffer, MBox.HStrut(4), jRunningBuffer, MBox.HStrut(2), jErrorBuffer, MBox.HStrut(2), jFinishBuffer, MBox.HStrut(2));
        mainBox.add(toolBar);
        
        setBufferMonitor(jMainBuffer, 20000);
        setBufferMonitor(jAlarmDbBuffer, 20000);
        setBufferMonitor(jRunningBuffer, 20000);
        setBufferMonitor(jErrorBuffer, 20000);
        setBufferMonitor(jFinishBuffer, 20000);
        
        int topBarHeight = 200;
        jDurationPanel.setPreferredSize(new Dimension(450, topBarHeight));
        jTpsPanel.setPreferredSize(new Dimension(350, topBarHeight));
        jTopPanel.setPreferredSize(new Dimension(450, topBarHeight));
        jRuningPanel.setPreferredSize(new Dimension(350, topBarHeight));
        mainBox.add(MBox.createHBar(topBarHeight, jDurationPanel, jTpsPanel, jTopPanel, MBox.HStrut(5), jRuningPanel));

        int VBoxWidth = 350;
        int alarmStsHeight = 150;
        Box hBoxAlarmStastic1 = MBox.createHBar(alarmStsHeight, jAlarmCausePanel, jAlarmRootCausePanel);
        Box hBoxAlarmStastic2 = MBox.createHBar(alarmStsHeight, jAlarmMsgPanel, jAlarmLevelPanel);
        Box hBoxAlarmStasticAgent = MBox.createHBar(alarmStsHeight,  jAlarmAgentPanel);
        Box hBoxAgent = MBox.createHBar(alarmStsHeight, jAgentPanel);
        
        hBoxAlarmStastic1.setPreferredSize(new Dimension(400, alarmStsHeight));
        hBoxAlarmStastic2.setPreferredSize(new Dimension(400, alarmStsHeight));
        hBoxAlarmStasticAgent.setPreferredSize(new Dimension(400, 250));
        jAgentPanel.setPreferredSize(new Dimension(400, 250));
        jErrorPanel.setPreferredSize(new Dimension(VBoxWidth, 350));
        
        Box vBoxErrorRunn = MBox.createVBar(VBoxWidth, jAgentPanel, MBox.VStrut(10), hBoxAlarmStastic1, hBoxAlarmStastic2, jErrorPanel);
        vBoxErrorRunn.setBackground(COLOR_BACK);
        
        JSplitPane jSplMain = new JSplitPane();
        jSplMain.setLeftComponent(vBoxErrorRunn);
        jSplMain.setRightComponent(jMainPanel);
        jSplMain.setDividerLocation(330);
        getStyleUtil().setSplitPanel(jSplMain);
        getStyleUtil().setStyle(jMainPanel);
        
        int bottomHeight = 650;
        jSplMain.setPreferredSize(new Dimension(1024, bottomHeight));
        Box b = MBox.createHBar(jSplMain);
        mainBox.add(b);

        GuiUtil.setGridLayout(this, mainBox);
        this.setBackground(COLOR_BACK);
    }
    
    public void setBufferMonitor(LoadingWidget wgt, int max)
    {
        wgt.setBorder(BorderFactory.createLineBorder(COLOR_LABEL));
        wgt.setBackground(COLOR_BACK);
        wgt.setForeground(COLOR_LABEL);
        wgt.setMax(max);
    }
    
    
    static FlatStyleUtil styleUtil = new FlatStyleUtil(COLOR_BACK, COLOR_LABEL);
    public static void setButtonStyle(JButton btn)
    {
        styleUtil.setButtonStyle(btn);
    }
    
    public static FlatStyleUtil getStyleUtil()
    {
        return styleUtil;
    }

    public void actionPerformed(ActionEvent e)
    {
        try
        {
            if (e.getSource() == jBtnStartStop)
                OnStartStop();
        } catch (Throwable err)
        {
            DetailErrorMsg.showError(err);
        }
    }

    public void updateButtonStatus(boolean isMonitorStarted)
    {
        jBtnStartStop.setIcon(isMonitorStarted ? GuiResource.getIcon("stop_16.png") : GuiResource.getIcon("start_16.png"));
        jBtnStartStop.setText(isMonitorStarted ? CmnUtil.getString("Stop Monitor") : CmnUtil.getString("Start Monitor"));
    }

    final Timer tm = new Timer();

    public void startTimer()
    {
        tm.schedule(new TimerTask()
        {
            public void run()
            {
                try
                {
                    reloadData();
                } catch (Exception exp)
                {
                    if (MsZkConst.isCauseByInvalidZK(exp))
                        showZkError(exp);

                    exp.printStackTrace();
                }
            }
        }, 1000, 2000);
    }
    
    public void showZkError(Throwable err)
    {
        jLabZkError.setVisible(true);
        jLabZkError.setText("Critical Zookeeper Error : " + err.getMessage());
    }
    
    public void hideZkError()
    {
        jLabZkError.setVisible(false);
    }
    
    public void reloadData() throws Exception
    {
        if (!GuiUtil.isComponentShowing(CMsTrackPanel.this))
        {
            GuiUtil.isComponentShowing(CMsTrackPanel.this);
            tm.cancel();
            return;
        }

        boolean isMonitorStarted = CMsClient.getIntf().isTrackMonitorStarted();
        hideZkError(); // 能拿到这个标志，说明zk能连通并找到TrackCenter
        updateButtonStatus(isMonitorStarted);
        if (!isMonitorStarted)
            return;
        
        // 延迟后台刷告警统计
        lazyRefreshAlarmStastic();

        MsFilterReqList req = MsFilterReqList.newList(MsFilterReq.newReq(CMsFilter_StasticService.SERVICE_STASTIC_TPS));
        req.add(MsFilterReq.newReq(CMsFilter_StasticService.SERVICE_STASTIC_TOP_HIT).setParam(10));
        req.add(MsFilterReq.newReq(CMsFilter_StasticService.SERVICE_STASTIC_SLOWEST).setParam(10));
        req.add(MsFilterReq.newReq(CMsFilter_Error.SERVICE_ERROR_QUERY_STASTIC));
        req.add(MsFilterReq.newReq(CMsFilter_Main.SERVICE_MAIN_TOP_RUNNING).setParam(10));
        req.add(MsFilterReq.newReq(CMsTrackCenter.SERVICE_MAIN_BUFFER));
        req.add(MsFilterReq.newReq(CMsTrackCenter.SERVICE_MAIN_ALARM_BUFFER));
        req.add(MsFilterReq.newReq(CMsFilter_Main.SERVICE_RUNNING_BUFFER));
        req.add(MsFilterReq.newReq(CMsFilter_Error.SERVICE_ERROR_BUFFER));
        req.add(MsFilterReq.newReq(CMsFilter_Finish.SERVICE_FINISH_BUFFER));

        Map<String, Object> mapData = CMsClient.getIntf().queryTrackData(req);

        long lTps = ToolUtilities.getLong(mapData.get(CMsFilter_StasticService.SERVICE_STASTIC_TPS), 0);
        jTpsPanel.showData(lTps);

        List<Pair<String, Long>> lstTopHit = (List<Pair<String, Long>>) mapData.get(CMsFilter_StasticService.SERVICE_STASTIC_TOP_HIT);
        jTopPanel.showData(lstTopHit);

        List<Pair<String, Double>> lstSlowest = (List<Pair<String, Double>>) mapData.get(CMsFilter_StasticService.SERVICE_STASTIC_SLOWEST);
        jDurationPanel.showData(lstSlowest);

        LinkedHashMap<MsFilterTag, Integer> lstError = (LinkedHashMap<MsFilterTag, Integer>) mapData.get(CMsFilter_Error.SERVICE_ERROR_QUERY_STASTIC);
        jErrorPanel.showData(lstError);
        
        List<MsTrackBean> lstRunning = (List<MsTrackBean>) mapData.get(CMsFilter_Main.SERVICE_MAIN_TOP_RUNNING);
        jRuningPanel.showData(lstRunning);
        
        int mainBuffer = ToolUtilities.getInteger(mapData.get(CMsTrackCenter.SERVICE_MAIN_BUFFER), 0);
        jMainBuffer.setLoading(mainBuffer);
        
        int alarmDbBuffer = ToolUtilities.getInteger(mapData.get(CMsTrackCenter.SERVICE_MAIN_ALARM_BUFFER), 0);
        jAlarmDbBuffer.setLoading(alarmDbBuffer);
        
        int runningBuffer = ToolUtilities.getInteger(mapData.get(CMsFilter_Main.SERVICE_RUNNING_BUFFER), 0);
        jRunningBuffer.setLoading(runningBuffer);

        int errorBuffer = ToolUtilities.getInteger(mapData.get(CMsFilter_Error.SERVICE_ERROR_BUFFER), 0);
        jErrorBuffer.setLoading(errorBuffer);
        
        int finishBuffer = ToolUtilities.getInteger(mapData.get(CMsFilter_Finish.SERVICE_FINISH_BUFFER), 0);
        jFinishBuffer.setLoading(finishBuffer);
        
    }

    public void OnStartStop() throws Exception
    {
        boolean isStart = CMsClient.getIntf().isTrackMonitorStarted();
        if (isStart)
        {
            CMsClient.getIntf().stopTrackMonitor();
            updateButtonStatus(false);
        } else
        {
            CMsClient.getIntf().startTrackMonitor(5*60000);
            updateButtonStatus(true);
        }
    }
    
    public void OnClickErrorItem(String periodicTag)
    {
        try
        {
            SqlExpression cnd = Cnd.exp(MsAlarmBean._periodicTag, "=", periodicTag);
            jAlarmTablePanel.showData(cnd);
            
            showAlarmTable();
        } catch (Exception err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    LazyPool<Long> _lazyAlarmStastic = new LazyPool<Long>(2000)
    {
        public void handle(List<Long> objects)
        {
            try
            {
                LinkedHashMap<Comparable, Number> stsCause = (LinkedHashMap)CMsClient.getIntf().queryAlarmStastic(ALARM_STASTIC_KEY.cause, 10);
                jAlarmCausePanel.showData(stsCause);
                
                LinkedHashMap<Comparable, Number> stsRCause = (LinkedHashMap)CMsClient.getIntf().queryAlarmStastic(ALARM_STASTIC_KEY.rootCause, 10);
                jAlarmRootCausePanel.showData(stsRCause);
                
                LinkedHashMap stsLevel = (LinkedHashMap)CMsClient.getIntf().queryAlarmStastic(ALARM_STASTIC_KEY.level, 4); // 不统计INFO的
                jAlarmLevelPanel.showData(stsLevel);

                LinkedHashMap<Comparable, Number> stsMsg = (LinkedHashMap)CMsClient.getIntf().queryAlarmStastic(ALARM_STASTIC_KEY.message, 5);
                jAlarmMsgPanel.showData(stsMsg);
                
//                LinkedHashMap<Comparable, Number> stsAgt = (LinkedHashMap)dfcutil.getDfcIntf().queryMsAlarmStastic(ALARM_STASTIC_KEY.agent, 10);
//                jAlarmAgentPanel.showData((LinkedHashMap)stsAgt);
                
                Map<String, Map<String, MsCallStastic>> mapData =  (Map)CMsClient.getIntf().queryTrackData(MsFilterReq.newReq(CMsFilter_StasticService.SERVICE_STASTIC_AGENT_SERVICE));
                jAgentPanel.showData(mapData);
                
            } catch (Exception exp)
            {
                exp.printStackTrace();
            }
        }
    };
    
    public void OnClickStasticCause(String cause)
    {
        try
        {
            SqlExpression cnd = Cnd.exp(MsAlarmBean._errorType, "=", cause);
            jAlarmTablePanel.showData(cnd);
            
            showAlarmTable();
        } catch (Exception err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    public void OnClickStasticRootCause(String rootCause)
    {
        try
        {
            SqlExpression cnd = Cnd.exp(MsAlarmBean._rootCauseType, "=", rootCause);
            jAlarmTablePanel.showData(cnd);
            
            showAlarmTable();
        } catch (Exception err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    public void OnClickStasticLevel(int level)
    {
        try
        {
            SqlExpression cnd = Cnd.exp(MsAlarmBean._level, "=", level);
            jAlarmTablePanel.showData(cnd);
            
            showAlarmTable();
        } catch (Exception err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    public void OnRightClickStasticLevel(final int level, MouseEvent e)
    {
        JPopupMenu pop = new JPopupMenu();
        pop.add(GuiUtil.createMenuItem("remove_all.png", CmnUtil.getString("Delete"), new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(CMsTrackPanel.this, CmnUtil.getString("Are you sure to delete these datas")+"?", "", JOptionPane.YES_NO_OPTION))
                    return;
                
                try
                {
                    OnDeleteAlarmByLevel(level);
                    lazyRefreshAlarmStastic();
                } catch (Exception exp)
                {
                    DetailErrorMsg.showError(exp);
                }
            }
        }));
        pop.show((Component) e.getSource(), (int)e.getX(), (int)e.getY());
    }
    
    public void OnDeleteAlarmByLevel(int level) throws Exception
    {
        SqlExpression cnd = Cnd.exp(MsAlarmBean._level, "=", level);
        
        if (false) CMsClient.getIntf().deleteAlarmWhere(cnd);
        JWaitDialog.showWaitDialog("Deleting Alarm ... ...", this, CMsClient.getIntf(), "deleteAlarmWhere", cnd);
    }
    
    public void OnClickStasticMsg(String msg)
    {
        try
        {
            SqlExpression cnd = Cnd.exp(MsAlarmBean._message, "=", msg);
            jAlarmTablePanel.showData(cnd);
            
            showAlarmTable();
        } catch (Exception err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    public void OnClickStasticAgent(String agent)
    {
        try
        {
            SqlExpression cnd = Cnd.exp(MsAlarmBean._dstAgent, "=", agent);
            jAlarmTablePanel.showData(cnd);
            
            showAlarmTable();
        } catch (Exception err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    public void lazyRefreshAlarmStastic()
    {
        _lazyAlarmStastic.add(System.currentTimeMillis());
    }
    
    static Map<String, String> _cacheAgentNames = null;
    static long _lastUpdate = -1;
    public static synchronized String getAgentName(String agentID)
    {
        if (_cacheAgentNames == null || System.currentTimeMillis()-_lastUpdate > 5000)
        {
            try
            {
//                _cacheAgentNames = CMsClient.getIntf().getAllAgentNames();
            } catch (Exception exp)
            {
                exp.printStackTrace();
            }
        }
        
        String agtName =  _cacheAgentNames==null?null:_cacheAgentNames.get(agentID);
        if (ToolUtilities.isStringEmpty(agtName))
            return agentID;
        
        return agtName;
    }
    
    public void showAlarmTable()
    {
        jLayoutCard.addAndShow(jMainPanel, PANEL_ALARM_TABLE, jAlarmTablePanel);
    }
    
    public void showServiceGraph(String serviceName) throws Exception
    {
        jMsGraphPanel.showService(serviceName);
        jLayoutCard.addAndShow(jMainPanel, PANEL_SERVICE_GRAPH, jMsGraphPanel);
    }
    
    public void showInterfaceGraph(String interfaceKey) throws Exception
    {
        jMsGraphPanel.showInterface(interfaceKey);
        jLayoutCard.addAndShow(jMainPanel, PANEL_SERVICE_GRAPH, jMsGraphPanel);
    }
}
