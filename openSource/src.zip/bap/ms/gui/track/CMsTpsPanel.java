package bap.ms.gui.track;

import java.awt.Color;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import com.leavay.common.util.ToolUtilities;
import com.project.gui.common.GuiUtil;

public class CMsTpsPanel extends JPanel 
{
    DefaultCategoryDataset callCnt = new DefaultCategoryDataset();
    static Color COLOR_BACK = new Color(0x35, 0x5c, 0x7d);
    static Color COLOR_LABEL = new Color(0x70, 0xAF, 0xCE);
    static Color COLOR_LINE = new Color(0xc5, 0x6c, 0x86);
    JFreeChart jCntChart = ChartFactory.createLineChart("TPS", null, null, callCnt);
    
    public CMsTpsPanel()
    {
        ChartPanel chartPanel = new ChartPanel(jCntChart);
        jCntChart.getTitle().setPaint(COLOR_LABEL);
        jCntChart.getPlot().setBackgroundPaint(COLOR_BACK );
        jCntChart.getPlot().setOutlinePaint(COLOR_BACK);

        jCntChart.setBackgroundPaint(COLOR_BACK);
        jCntChart.getCategoryPlot().getRenderer().setSeriesPaint(0, COLOR_LINE);
        jCntChart.getCategoryPlot().getRenderer().setSeriesPaint(1, COLOR_LINE);
        jCntChart.getCategoryPlot().getDomainAxis().setLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getDomainAxis().setTickLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getDomainAxis().setTickLabelsVisible(false);
        jCntChart.getCategoryPlot().getRangeAxis().setTickLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getRangeAxis().setLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getRangeAxis().setRangeWithMargins(0, 100);
        jCntChart.getCategoryPlot().setBackgroundPaint(COLOR_BACK);
        jCntChart.getLegend().setVisible(false);
        
        GuiUtil.setGridLayout(this, chartPanel);
        autoSetRange();
    }
    
    public void showData(long lTps)
    {
        final String rowKeyTps = "TPS";
        String timeS = ToolUtilities.time2String(System.currentTimeMillis(),false, true);
        jCntChart.setTitle("TPS : "+lTps+"/s");
//        callCnt.addValue(lCnt, rowKeyCnt, timeS);
        callCnt.addValue(lTps, rowKeyTps, timeS);
        while (callCnt.getColumnCount() > 60)
        {
            callCnt.removeValue(rowKeyTps, callCnt.getColumnKey(0));
        }
        autoSetRange();
    }
    
    public void autoSetRange()
    {
        long num = 0L;
        for (int i=0; i< callCnt.getColumnCount();i++)
        {
            for (int j=0;j<callCnt.getRowCount(); j++)
                num = Math.max(num, ToolUtilities.getLong(callCnt.getValue(j, i), 0));
        }
        
        jCntChart.getCategoryPlot().getRangeAxis().setRange(0, Math.max(1000, num+1000));
    }
}
