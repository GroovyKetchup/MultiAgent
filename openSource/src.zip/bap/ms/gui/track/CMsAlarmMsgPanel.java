package bap.ms.gui.track;

public class CMsAlarmMsgPanel extends CMsAlarmCausePanel<String>
{
    public CMsAlarmMsgPanel()
    {
        super();
        setTitle("Alarm Message");
    }
}
