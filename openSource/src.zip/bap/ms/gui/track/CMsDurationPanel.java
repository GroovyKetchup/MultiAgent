package bap.ms.gui.track;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Paint;
import java.util.List;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.entity.CategoryLabelEntity;
import org.jfree.chart.entity.ChartEntity;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.IntervalBarRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.data.category.DefaultCategoryDataset;

import com.leavay.common.util.KeyValuePair;
import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.microService.MsType;
import com.project.gui.common.GuiUtil;

public class CMsDurationPanel extends JPanel 
{
    DefaultCategoryDataset _dataSet = new DefaultCategoryDataset();
    static Color COLOR_BACK = new Color(0x35, 0x5c, 0x7d);
    static Color COLOR_LABEL = new Color(0x70, 0xAF, 0xCE);
    final static String sTitle = dfcutil.getString("Duration(ms)");
    JFreeChart jCntChart = ChartFactory.createBarChart(sTitle, null, null, _dataSet, PlotOrientation.HORIZONTAL, true, false , false);
    
    public class CustomRenderer extends IntervalBarRenderer
    {
        public Paint getItemPaint(int i, int j)
        {
            return COLOR_LABEL;
        }
    }
    
    public CMsDurationPanel()
    {
        ChartPanel chartPanel = new ChartPanel(jCntChart);
        jCntChart.getTitle().setMaximumLinesToDisplay(1);
        jCntChart.getTitle().setPaint(COLOR_LABEL);
        jCntChart.getPlot().setBackgroundPaint(COLOR_BACK );
        jCntChart.getPlot().setOutlinePaint(COLOR_BACK);

        jCntChart.setBackgroundPaint(COLOR_BACK);
        jCntChart.getCategoryPlot().getDomainAxis().setLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getDomainAxis().setTickLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getRangeAxis().setTickLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getRangeAxis().setLabelPaint(COLOR_LABEL);
        jCntChart.getCategoryPlot().getRangeAxis().setRange(0, 100);
        jCntChart.getCategoryPlot().setBackgroundPaint(COLOR_BACK);
        jCntChart.getLegend().setVisible(false);
        
        BarRenderer render = new CustomRenderer();//自定义图形对象
        render.setShadowVisible(false);//取消柱子的阴影效果
        render.setDrawBarOutline(false); 
        render.setMaximumBarWidth(0.02); //设置柱子宽度 
        render.setMinimumBarLength(0.0); //设置柱子高度 
        //在柱子上显示相应信息 
        render.setBaseItemLabelsVisible(true); 
        render.setBaseItemLabelPaint(COLOR_LABEL);//设置数值颜色，默认黑色 
        render.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator()); 
        render.setBarPainter( new StandardBarPainter() ); //去掉渐变色


        //设置不显示边框线
        render.setDrawBarOutline(false);
        //render.setSeriesPaint(0,new Color(131,175,155));
       //  render.setBarPainter( new StandardBarPainter() );//取消渐变色
        //render.setItemMargin(-0.01);
        jCntChart.getCategoryPlot().setRenderer(render);
        
        chartPanel.addChartMouseListener(new ChartMouseListener()
        {
            public void chartMouseMoved(ChartMouseEvent var1)
            {
                if (var1.getEntity() != null && var1.getEntity() instanceof CategoryLabelEntity)
                {
                    setCursor(new Cursor(Cursor.HAND_CURSOR));
                    KeyValuePair key = (KeyValuePair) ((CategoryLabelEntity)var1.getEntity()).getKey();
                    updateTitle(""+(key==null?null:key.getKey()));
                }
                else
                {
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    updateTitle(null);
                }
            }
            
            public void chartMouseClicked(ChartMouseEvent var1)
            {
                ChartEntity ent = var1.getEntity();
                if (ent instanceof CategoryLabelEntity)
                {
                    KeyValuePair key = (KeyValuePair) ((CategoryLabelEntity)var1.getEntity()).getKey();
                    OnClickService(key);
                }
            }
        });
        
        GuiUtil.setGridLayout(this, chartPanel);
        autoSetRange();
    }
    
    public void OnClickService(KeyValuePair serviceKey)
    {
        
    }
    
    public void updateTitle(String moveOnService)
    {
        if (ToolUtilities.isStringEmpty(moveOnService))
            jCntChart.setTitle(sTitle);
        else
            jCntChart.setTitle(moveOnService);
    }
    
    public void showData(List<Pair<String, Double>> lstData)
    {
        final String rowKeyTps = "HIT";
        
        removeAllValue();
        for (Pair<String, Double> a : lstData)
        {
            _dataSet.addValue(a.getValue(), rowKeyTps, new KeyValuePair(a.getKey(), MsType.getSimpleServiceName(a.getKey())));
        }
        autoSetRange();
    }
    
    public void removeAllValue()
    {
        while (_dataSet.getColumnCount() > 0)
            _dataSet.removeColumn(0);
    }
    
    public void autoSetRange()
    {
        double num = 0L;
        for (int i=0; i< _dataSet.getColumnCount();i++)
        {
            for (int j=0;j<_dataSet.getRowCount(); j++)
                num = Math.max(num, ToolUtilities.getDouble(_dataSet.getValue(j, i), 0));
        }
        
        jCntChart.getCategoryPlot().getRangeAxis().setRange(0, Math.max(10, num * 110/100));
    }
}
