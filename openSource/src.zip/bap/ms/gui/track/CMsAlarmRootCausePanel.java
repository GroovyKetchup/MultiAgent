package bap.ms.gui.track;

public class CMsAlarmRootCausePanel extends CMsAlarmCausePanel<String>
{
    public CMsAlarmRootCausePanel()
    {
        super();
        setTitle("Root Cause");
    }
}
