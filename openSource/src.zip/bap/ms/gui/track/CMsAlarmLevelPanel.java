package bap.ms.gui.track;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;

import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.microService.bean.MsAlarmBean;
import com.project.gui.common.GuiUtil;

public class CMsAlarmLevelPanel extends JPanel
{

    SortableModel _model = new SortableModel();
    JTable jTbl_Data = new JTable(_model);
    public final static String[] _header = new String[]{"Level","Count"};
    
    
    class LevelRenderer extends DefaultTableCellRenderer
    {
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
        {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setText(MsAlarmBean.getLevelText((int)value));
            return this;
        }
    }
    
    public void showData(Map<String, Number> stastic)
    {
        int[] selRows = jTbl_Data.getSelectedRows();
        GuiUtil.clearTableRows(_model);
        
        for (int i : MsAlarmBean.LEVELS)
        {
            long cnt = ToolUtilities.getLong(""+stastic.get(i), 0);
            addRow(i, cnt);
        }
        GuiUtil.adjustTableColumnWidth(jTbl_Data);
        
        if (selRows != null)
            for (int sel : selRows)
                jTbl_Data.setRowSelectionInterval(sel, sel);
    }
    
    public void addRow(int level, long count)
    {
        _model.addRow(new Object[]{level, count});
    }
    
    public CMsAlarmLevelPanel()
    {
        jbInit();
    }
    
    public void jbInit()
    {
        Box boxMain = Box.createVerticalBox();
        
        for (String h : _header)
            _model.addColumn(dfcutil.getString(h));
        
        jTbl_Data.getColumnModel().getColumn(0).setCellRenderer(new LevelRenderer());

        jTbl_Data.getTableHeader().setVisible(false);
        jTbl_Data.getTableHeader().setPreferredSize(new Dimension(0, 0));
        CMsTrackPanel.getStyleUtil().setTableStyle(jTbl_Data);
        jTbl_Data.setGridColor(CMsTrackPanel.COLOR_BACK);
        jTbl_Data.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jTbl_Data.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e) {
                if (GuiUtil.isSingleClickLeft(e))
                {
                    int row = jTbl_Data.getSelectedRow();
                    if (row < 0)
                        return;
                    
                    OnClick((int)_model.getValueAt(row, 0));
                }else if (GuiUtil.isSingleClickRight(e))
                {
                    int row = jTbl_Data.getSelectedRow();
                    if (row < 0)
                        return;
                    
                    OnRightClick((int)_model.getValueAt(row, 0), e);
                    e.consume();
                }
            }

        });
        
        JScrollPane jScrTable = new JScrollPane(jTbl_Data);
        CMsTrackPanel.getStyleUtil().setScrollPanel(jScrTable);
        
        boxMain.add(jScrTable);
        
        GuiUtil.setGridLayout(this, boxMain);
    }
    
    public void OnClick(int level)
    {
        
    }
    
    public void OnRightClick(int level, MouseEvent e)
    {
        
    }
}