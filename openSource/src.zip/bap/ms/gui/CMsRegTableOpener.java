package bap.ms.gui;

import com.leavay.common.util.javac.ClassFactory;
import com.leavay.dfc.SubjectView.gui.MainEditor.AbstractMoOpener;
import com.leavay.dfc.gui.dfcutil;
import com.vlsolutions.swing.docking.Dockable;

public class CMsRegTableOpener extends AbstractMoOpener
{
    public final static String KEY = "Micro Service Registry Table";
    public CMsRegTableOpener()
    {
        super(KEY);
    }
    
    // 默认每次要刷新
    public boolean isForceReopen()
    {
        return false;
    }

    CMsRegTablePanel _panel = null;
    public Dockable openNewEditor() throws Exception
    {
        if (_panel == null)
        {
            if (false) new CMsRegTablePanel();
            _panel = (CMsRegTablePanel) ClassFactory.newInstance(CMsRegTablePanel.class);
            _panel.getDockKey().setKey(KEY);
        }
        
        return _panel;
    }
    
    public void openExistEditor(Dockable dockable) throws Exception
    {
        CMsRegTablePanel view = (CMsRegTablePanel) dockable;
        view.reloadData();
    }

    public String getName()
    {
        return dfcutil.getString("Open "+KEY);
    }

}
