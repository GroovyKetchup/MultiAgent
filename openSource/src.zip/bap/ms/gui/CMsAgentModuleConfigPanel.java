package bap.ms.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import com.leavay.client.util.MBox;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.dfc.mgr.javaDev.GuiPluginMgr;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.ms.warehouse.MsAgentDto;
import com.leavay.nio.crpc.CRpcServer;
import com.leavay.starter.StarterConf;
import com.leavay.starter.StarterItem;
import com.leavay.starter.StarterParam;
import com.project.gui.common.GuiUtil;

import bap.client.BapClient;
import bap.ms.gui.track.CMsGuiPlugin;
import md.ms.MsAgentDo;

public class CMsAgentModuleConfigPanel extends JPanel
{
    List<ParamPair> lstParamPair = new LinkedList<CMsAgentModuleConfigPanel.ParamPair>();
    Map<String, JCheckBox> mapEnable = new HashMap();
    
    class ParamPair
    {
        StarterParam p;
        JComponent cmp;
        public ParamPair(StarterParam p, JComponent cmp)
        {
            super();
            this.p = p;
            this.cmp = cmp;
        }
        public StarterParam getP()
        {
            return p;
        }
        public void setP(StarterParam p)
        {
            this.p = p;
        }
        public JComponent getCmp()
        {
            return cmp;
        }
        public void setCmp(JComponent cmp)
        {
            this.cmp = cmp;
        }
    }
    
    StarterConf _conf;
    public void showData(MsAgentDto agent, String selectPackage) throws Exception
    {
        this.removeAll();
        lstParamPair.clear();
        _conf = CMsClient.getIntf().loadMsPackageConfig(selectPackage);
        if (_conf == null)
            return;

        HashSet<String> enableOption = MsAgentDo.convertStarterConfig(agent.getStarterConf());
        enableOption = enableOption == null ? new HashSet<String>() : enableOption;

        Box box = Box.createVerticalBox();
        box.add(MBox.VStrut(10));

        Map<String, String> mapParam = MsAgentDo.convertConfigTableMap(agent.getConfigTable());

        List<StarterItem> lstStarter = _conf.getStartSequence();
        for (StarterItem starter : lstStarter)
        {
            if (!starter.isOptional() && !starter.hasParams())
                continue;

            Box boxModule = Box.createVerticalBox();
            boxModule.setBorder(BorderFactory.createTitledBorder(starter.getLabelOrKey()));
            Box boxParam = Box.createVerticalBox();
            

            boolean hasVisibleCtrl = false; // 如果没有可配参数，模块也不可选，则不显示该模块了

            // 参数区
            boxModule.add(MBox.VStrut(10));
            boxModule.add(boxParam);
            if (starter.hasParams())
            {
                
                for (StarterParam p : starter.getAllParams())
                {
                    // NIO Port特殊处理，在主页配置了，这里就不写入starter配置了
                    if (CmnUtil.isStringEqual(p.getKey(), CRpcServer.CONF_NIO_PORT))
                        continue;
                    
                    CMsGuiPlugin plugin = ClassFactory.newInstance(CMsGuiPlugin.class);
                    
                    // 优先获取配置里的参数值，如果没有，则获取starter模板里的默认值
                    String paramValue = mapParam == null ? null : mapParam.get(p.getKey());
                    if (CmnUtil.isStringEmpty(paramValue, true))
                        paramValue = p.getValue();
                    
                    JComponent cmp = plugin.createMsAgentParamCtrl(p, paramValue);

                    JLabel label = new GuiUtil.LeftLabel(p.getLabelOrKey(), 150);
                    label.setToolTipText(p.getKey());
                    
                    boxParam.add(MBox.createHBar(22, label, MBox.HStrut(5), new JLabel(":"), MBox.HStrut(5), cmp));
                    boxParam.add(MBox.HStrut(2));

                    lstParamPair.add(new ParamPair(p, cmp));
                    hasVisibleCtrl = true;
                }

                boxParam.setBorder(BorderFactory.createEmptyBorder(5, 40, 5, 5));
                boxParam.add(MBox.VGlue());
            }

            if (starter.isOptional())
            {
                JCheckBox jChkEnable = new JCheckBox(GuiUtil.getString("Enable Module"));
                jChkEnable.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent e)
                    {
                        GuiUtil.setAllChildEditable(boxParam, jChkEnable.isSelected());
                    }
                });
                mapEnable.put(starter.getKey(), jChkEnable);
                boxModule.add(MBox.createHBar(22, MBox.HStrut(20), jChkEnable, MBox.HGlue()), 0);

                boolean enable = enableOption.contains(starter.getKey());
                jChkEnable.setSelected(enable);
                GuiUtil.setAllChildEditable(boxParam, enable);
                hasVisibleCtrl = true;
            }

            if (hasVisibleCtrl)
                box.add(boxModule);
        }

        JScrollPane jScr = new JScrollPane(box);
        jScr.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        GuiUtil.setGridLayout(this, jScr);
    }
    
    public HashSet<String> getStarterConfFromGui() throws Exception
    {
        HashSet<String> set = new HashSet();
        for (Entry<String, JCheckBox> ent : mapEnable.entrySet())
            if (ent.getValue().isSelected())
                set.add(ent.getKey());
        
        return set.isEmpty()?null:set;
    }
    
    public HashMap<String, String> getParamFromGui()
    {
        CMsGuiPlugin plugin = GuiPluginMgr.newInstance(CMsGuiPlugin.class);
        
        HashMap<String, String> mapRet = new HashMap<String, String>();
        
        for (ParamPair p : lstParamPair)
        {
            String o = plugin.getMsAgentParamValue(p.getP(), p.getCmp());
            if (o != null)
                mapRet.put(p.getP().getKey(), o);
        }
        
        if (mapRet.isEmpty())
            return null;
        else
            return mapRet;
    }
}
