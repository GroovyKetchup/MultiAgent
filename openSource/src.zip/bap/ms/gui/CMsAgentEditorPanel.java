package bap.ms.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.plaf.basic.BasicComboBoxRenderer;

import com.leavay.client.util.MBox;
import com.leavay.common.util.KeyValuePair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.warehouse.MsAgentDto;
import com.leavay.ms.warehouse.WhPackage;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.RightLabel;
import com.project.gui.common.component.JTextField_Integer;

import bap.client.BapClient;
import bap.ms.CMsConst;
import md.ms.MsAgentDo;

public class CMsAgentEditorPanel extends JPanel implements ActionListener
{
    JComboBox jCmbPackage = new JComboBox();
    JTextField jTxt_Name = new JTextField();
    JTextField jTxt_Host = new JTextField();
    JTextField jTxt_NioPort = new JTextField("8088");

    JTextField_Integer jTxt_MaxMem = new JTextField_Integer(""+CMsConst.DEFAULT_MAX_MEM);
    JTextField_Integer jTxt_MinMem = new JTextField_Integer(""+CMsConst.DEFAULT_MIN_MEM);

    JComboBox jCmb_DeployType = new JComboBox();
    
    JTextField jTxt_User= new JTextField("User");
    JPasswordField jTxt_Pwd = new JPasswordField();
    JTextField jTxt_SshPort = new JTextField(""+CMsConst.DEFAULT_NIO_PORT);
    JTextField jTxt_DstPath= new JTextField(MsAgentDo.DEFAULT_TARGET_PATH);
    JTextField jTxt_JdkPath= new JTextField("/usr/java");
    JCheckBox jChk_UseAuthorizedFile = new JCheckBox(getString("Use Authorized File"));
    JTextArea jTxt_AuthKey = new JTextArea();
    JButton jBtn_ImportKeyFile = GuiUtil.createToolButton("folder.png", getString("Import Authorized File"), this);
    
    JCheckBox jChk_EnableLocalDB = new JCheckBox(getString("Enable Local Status DB"));
    
    Box mainBox = null;
    Box sshBox = null; 

    JTabbedPane jTab_Main = new JTabbedPane();
    
    CMsAgentModuleConfigPanel jModuleConfPanel = new CMsAgentModuleConfigPanel();
    
    public String getString(String s)
    {
        return s;
    }
    
    public CMsAgentEditorPanel() throws Exception
    {
        jbInit();
    }
    
    public void jbInit() throws Exception
    {
        mainBox = Box.createVerticalBox();
        
        int iw = 150;
        mainBox.add(MBox.VStrut(15));
        mainBox.add(MBox.createHBar(22, new RightLabel(getString("Name")+" : ", iw), jTxt_Name, MBox.HStrut(15)));
        mainBox.add(MBox.VStrut(5));
        mainBox.add(MBox.createHBar(22, new RightLabel(getString("Host Address")+" : ", iw), jTxt_Host, MBox.HStrut(15)));
        mainBox.add(MBox.VStrut(5));
        mainBox.add(MBox.createHBar(22, new RightLabel(getString("NIO Port")+" : ", iw), jTxt_NioPort, MBox.HStrut(5), MBox.HStrut(15)));
        mainBox.add(MBox.VStrut(8));

        mainBox.add(MBox.VSeperator());        
        mainBox.add(MBox.VStrut(8));
        
        mainBox.add(MBox.createHBar(22, MBox.HStrut(5), jCmb_DeployType, MBox.HStrut(5)));
        jCmb_DeployType.addItem(new KeyValuePair(MsAgentDto.DEPLOY_DISABLE, "Disable Auto Deploy"));
        jCmb_DeployType.addItem(new KeyValuePair(MsAgentDto.DEPLOY_LOCAL, "Local Deploy"));
        jCmb_DeployType.addItem(new KeyValuePair(MsAgentDto.DEPLOY_SSH, "Ssh Deploy"));
        
        jCmb_DeployType.setRenderer(new BasicComboBoxRenderer()
        {
            public Component getListCellRendererComponent(JList<? extends KeyValuePair> list, KeyValuePair value, int index, boolean isSelected, boolean cellHasFocus)
            {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                
                setIcon(null);
                if (value != null && value instanceof KeyValuePair)
                {
                    int i = (int)((KeyValuePair)value).getKey();
                    if (i  == MsAgentDto.DEPLOY_SSH)
                        setIcon(GuiResource.getIcon("dfc/ssh.png"));
                    else if (i == MsAgentDto.DEPLOY_LOCAL)
                        setIcon(GuiResource.getIcon("dfc/service.png"));
                    else if (i == MsAgentDto.DEPLOY_DISABLE)
                        setIcon(GuiResource.getIcon("dfc/server.png"));
                }
                return this;
            }
        });
        
        mainBox.add(MBox.VStrut(8));
        
        Box deployBox = Box.createVerticalBox();

        deployBox.add(MBox.VStrut(5));
        deployBox.add(MBox.createHBar(22, new RightLabel(getString("Package")+" : ", iw), jCmbPackage, MBox.HStrut(15)));
        deployBox.add(MBox.VStrut(5));
        jTxt_MaxMem.setValidate(false, 5L, Long.MAX_VALUE);
        deployBox.add(MBox.createHBar(22, new RightLabel(getString("Max Mem")+" : ", iw), jTxt_MaxMem, new JLabel(" MB"), MBox.HStrut(15), new RightLabel(getString("Min Mem")+" : ", iw), jTxt_MinMem,  new JLabel(" MB"), MBox.HStrut(15)));
        deployBox.add(MBox.VStrut(8));
        deployBox.add(MBox.VSeperator());        
        deployBox.add(MBox.VStrut(8));
        
        sshBox = Box.createVerticalBox();
        sshBox.add(MBox.createHBar(22, new RightLabel(getString("User")+" : ", iw), jTxt_User, MBox.HStrut(15)));
        sshBox.add(MBox.VStrut(5));
        sshBox.add(MBox.createHBar(22, new RightLabel(getString("Password")+" : ", iw), jTxt_Pwd, MBox.HStrut(15)));
        sshBox.add(MBox.VStrut(5));
        sshBox.add(MBox.createHBar(22, new RightLabel(getString("SSH Port")+" : ", iw), jTxt_SshPort, MBox.HStrut(15)));
        sshBox.add(MBox.VStrut(5));
        sshBox.add(MBox.createHBar(22, new RightLabel(getString("Destination Path")+" : ", iw), jTxt_DstPath, MBox.HStrut(15)));
        sshBox.add(MBox.VStrut(5));
        sshBox.add(MBox.createHBar(22, new RightLabel(getString("JDK Path")+" : ", iw), jTxt_JdkPath, MBox.HStrut(15)));
        sshBox.add(MBox.VStrut(5));
        sshBox.add(MBox.VSeperator());
        sshBox.add(MBox.VStrut(2));
        sshBox.add(MBox.createHBar(22, MBox.HStrut(5), jChk_UseAuthorizedFile, MBox.HGlue(), jBtn_ImportKeyFile, MBox.HStrut(5)));
        sshBox.add(MBox.createHBar(150, MBox.HStrut(5), new JScrollPane(jTxt_AuthKey), MBox.HStrut(5)));
        sshBox.add(MBox.VStrut(5));
        jTxt_AuthKey.setLineWrap(true);
        
        deployBox.add(sshBox);
        deployBox.setBorder(BorderFactory.createLineBorder(Color.gray));
        mainBox.add(deployBox);
        
        jTab_Main.addTab("Basic Config", mainBox);
        jTab_Main.addTab("Module Config", jModuleConfPanel);
        GuiUtil.setGridLayout(this, jTab_Main);
        setPreferredSize(new Dimension(600, 640));
        
        List<WhPackage> lstPkg = CMsClient.getIntf().loadAllWarehousePackage();
        for (WhPackage pkg : lstPkg)
            jCmbPackage.addItem(pkg);
        jCmbPackage.setEditable(true);
        
        jCmb_DeployType.addActionListener(new ActionAdapter()
        {
            public void OnAction(ActionEvent e) throws Exception
            {
                OnCheckboxChanged();
            }
        });
        
        jCmbPackage.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                OnPackageChanged();
            }
        });
    }
    
    public void OnCheckboxChanged()
    {
        int type = (int) GuiUtil.getComboValue(jCmb_DeployType);
        if (type == MsAgentDto.DEPLOY_DISABLE)
        {
            enableMemPkgConfig(false);
            enableSshConfig(false);
        }else 
        {
            enableMemPkgConfig(true);
            if (type == MsAgentDto.DEPLOY_LOCAL)
            {
                enableSshConfig(false);
            } else
            {
                enableSshConfig(true);
            }
        }
    }

    public void enableMemPkgConfig(boolean enable)
    {
        jCmbPackage.setEnabled(enable);
        jTxt_MinMem.setEditable(enable);
        jTxt_MaxMem.setEditable(enable);
    }
    
    public void enableSshConfig(boolean enable)
    {
        jTxt_User.setEditable(enable);
        jTxt_Pwd.setEditable(enable);
        jTxt_SshPort.setEditable(enable);
        jTxt_DstPath.setEditable(enable);
        jTxt_JdkPath.setEditable(enable);
        jChk_UseAuthorizedFile.setEnabled(enable);
        jBtn_ImportKeyFile.setEnabled(enable);
        jTxt_AuthKey.setEditable(enable);
    }

    public void actionPerformed(ActionEvent e)
    {
        
    }
    
    MsAgentDto _org;
    public boolean isShowingData()
    {
        return _isShowing;
    }
    
    boolean _isShowing=false;
    public void showData(MsAgentDto agent) throws Exception
    {
        _isShowing = true;
        try
        {
            _org = agent;
            jCmbPackage.setSelectedItem(agent.getPkgPath());
            jModuleConfPanel.showData(agent, agent.getPkgPath());

            jTxt_Name.setText(agent.getName());
            jTxt_Host.setText(agent.getMyHost());
            jTxt_NioPort.setText("" + agent.getNioPort());
            
            GuiUtil.setComboSelValue(jCmb_DeployType, agent.getDeployType());
            jTxt_MaxMem.setText("" + agent.getMaxMem());
            jTxt_MinMem.setText("" + agent.getMinMem());

            jTxt_SshPort.setText("" + agent.getSshPort());
            jTxt_User.setText(agent.getSshUser());
            jTxt_Pwd.setText(agent.getSshPwd());
            jTxt_DstPath.setText(agent.getSshPath());
            jTxt_JdkPath.setText(agent.getSshJdkPath());

            jChk_UseAuthorizedFile.setSelected(agent.getUseSshKeyFile());
            jTxt_AuthKey.setText(agent.getSshKeyFile());
            
            OnCheckboxChanged();
        } finally
        {
            _isShowing = false;
        }
    }
    
    public String getSelectPackage()
    {
        Object pkg = jCmbPackage.getSelectedItem();
        if (pkg instanceof WhPackage)
            return ((WhPackage) pkg).getKey();
        else
            return ToolUtilities.getString(pkg, null);
    }
    
    public MsAgentDto getDataFrmGui() throws Exception
    {
        MsAgentDto agent = _org==null?new MsAgentDto():(MsAgentDto) ToolUtilities.clone(_org);
        
        ToolUtilities.verifyPortRange(ToolUtilities.getInteger(jTxt_NioPort.getText()));
        
        agent.setPkgPath(getSelectPackage());
        agent.setConfigTable(MsAgentDo.convertConfigTableMap(jModuleConfPanel.getParamFromGui()));
        agent.setStarterConf(MsAgentDo.convertStarterConfig(jModuleConfPanel.getStarterConfFromGui()));
        
        agent.setName(jTxt_Name.getText().trim());
        agent.setMyHost(jTxt_Host.getText());
        agent.setNioPort(ToolUtilities.getInteger(jTxt_NioPort.getText()));
        
        agent.setDeployType((int)GuiUtil.getComboValue(jCmb_DeployType));
        agent.setMaxMem(jTxt_MaxMem.getValueInteger());
        agent.setMinMem(jTxt_MinMem.getValueInteger());
        
        agent.setSshPort(ToolUtilities.getInteger(jTxt_SshPort.getText(), -1));
        agent.setSshUser(jTxt_User.getText());
        agent.setSshPwd(new String(jTxt_Pwd.getPassword()));
        agent.setSshPath(jTxt_DstPath.getText());
        agent.setSshJdkPath(jTxt_JdkPath.getText());
        
        agent.setUseSshKeyFile(jChk_UseAuthorizedFile.isSelected());
        agent.setSshKeyFile(jTxt_AuthKey.getText());
        
        return agent;
    }
    
    public void OnPackageChanged()
    {
        if (_isShowing)
            return;
        
        try
        {
            jModuleConfPanel.showData(_org, getSelectPackage());
        }catch(Throwable err)
        {
            err.printStackTrace();
        }
    }
}
