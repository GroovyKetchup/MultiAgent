package bap.ms.gui;

import java.net.URI;

import com.cdao.mgr.CDaoClient;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;

import bap.ms.CMsCenterService;

public class CMsClient
{
    private static CMsClient _me;
    public synchronized static CMsClient getMe()
    {
        if (_me ==null)
            _me = new CMsClient();
        
        return _me;
    }
    
    protected CMsClient()
    {
    }
    
    protected CRpcClientWrapper<CMsCenterService> _intfMsCenter = new CRpcClientWrapper<CMsCenterService>(CMsCenterService.class)
    {
        public CRpcAdapter getAdapter()
        {
            // 基于CDao的通讯通道，来获取远程接口
            return CDaoClient.getMe().getRpcAdapter();
        }
    };
    
    public static CMsCenterService getIntf()
    {
        return getMe()._intfMsCenter.getIntf();
    }
    
    // 基于CDaoClient以及BapClient启动之后
    public synchronized void init(URI uri) throws Exception
    {
        _intfMsCenter.init(uri);
    }
}
