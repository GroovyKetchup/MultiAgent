package bap.ms.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableCellRenderer;

import com.leavay.client.util.MBox;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.SortButtonRenderer;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.microService.MsRegAgentPath;
import com.leavay.ms.warehouse.MsAgentDto;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;

import modeldef.com.leavay.dfc.physical.SshAgentMO;

public class CMsRegRouteTablePanel extends JPanel implements ActionListener
{
    protected final String[] sHeader = new String[]{"Provider", "RouteID"};
    public final static int _colAgent = 0;
    public final static int _colRouteID = 1;
    
    protected SortButtonRenderer.SortableModel _model = new SortButtonRenderer.SortableModel(){
        public boolean isCellEditable(int row, int column)
        {
            if (column == _colRouteID)
                return true;
            
            return false;
        }
    };

    protected class MyRenderer extends DefaultTableCellRenderer{
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (column == _colAgent && value instanceof String)
            {
                String agentID = (String)value;
                String agentName = SshAgentMO.getDCacheName(agentID);
                if (agentName == null)
                    agentName = agentID;
                setText(agentName);
            }
            return this;
        }
    }
        
    public String getString(String s)
    {
        return s;
    }
    
    public JButton jBtn_Refresh = GuiUtil.createToolButton("refresh.png", getString("Refresh"), this);
    
    public JButton jBtn_AddMsAgent = GuiUtil.createToolButton("dfc/extServer.png", getString("Add Ms Agent"), this);

    public JButton jBtn_Delete = GuiUtil.createToolButton("remove.png", getString("Delete"), this);

    protected JTable jTbl_Route = new JTable(_model);
    
    public CMsRegRouteTablePanel()
    {
        Box mainBox = Box.createVerticalBox();
        mainBox.add(createToolBar());
        
        for (String s : sHeader)
            _model.addColumn(getString(s));
        mainBox.add(new JScrollPane(jTbl_Route));
        jTbl_Route.getColumnModel().getColumn(_colAgent).setCellRenderer(new MyRenderer());
        try
        {
            SortButtonRenderer.setHeader(jTbl_Route);
        } catch (Exception exp)
        {
            exp.printStackTrace();
        }
        
        GuiUtil.setGridLayout(this, mainBox);
    }
    
    public Box createToolBar()
    {
        return MBox.createHBar(22, jBtn_Refresh, MBox.HSeperator(), jBtn_AddMsAgent, MBox.HSeperator(), jBtn_Delete, MBox.HGlue());
    }
    
    public void actionPerformed(ActionEvent e)
    {
        try
        {
            if (e.getSource() == jBtn_AddMsAgent)
                OnAddMsAgent();
            else if (e.getSource() == jBtn_Delete)
                OnDelete();
        } catch (Exception err)
        {
            DetailErrorMsg.showError(err);
        }
    }
    
    public void OnDelete()
    {
        GuiUtil.removeTableRow(_model, jTbl_Route.getSelectedRows());
    }
    
    public void OnAddMsAgent() throws Exception
    {
        CMsAgentMgrPanel msAgtPanel = new CMsAgentMgrPanel();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(msAgtPanel, this, dfcutil.getInstance(), true);
        dlg.pack();
        if (!dlg.showModel(true))
            return;
        
        List<MsAgentDto> lstAgts = msAgtPanel.getSelectAgents();
        if (lstAgts != null)
            for (MsAgentDto agt  : lstAgts)
                addRow(new MsRegAgentPath(agt.getCode(), null));
    }
    
    public void addRow(MsRegAgentPath p)
    {
        _model.addRow(new Object[] { p.getAgent(), p.getRouteID()});
    }
    
    public List<MsRegAgentPath> getDataFromGui()
    {
        GuiUtil.stopTableEditor(jTbl_Route);
        
        List<MsRegAgentPath> lstRet = new ArrayList<MsRegAgentPath>();
        for (int i = 0;i <_model.getRowCount(); i++)
        {
            String sAgt = ToolUtilities.getString(_model.getValueAt(i, _colAgent), null);
            String sRouteID = ToolUtilities.getString(_model.getValueAt(i, _colRouteID), null);
            lstRet.add(new MsRegAgentPath(sAgt, sRouteID));
        }
        
        return lstRet;
    }
    
    public void showData(List<MsRegAgentPath> lstRegPair)
    {
        GuiUtil.clearTableRows(_model);
        if (lstRegPair == null)
            return;
        
        for (MsRegAgentPath p : lstRegPair)
            addRow(p);
    }
}
