package bap.ms.gui;

import com.leavay.common.util.javac.ClassFactory;
import com.leavay.dfc.SubjectView.gui.MainEditor.AbstractMoOpener;
import com.leavay.dfc.gui.dfcutil;
import com.vlsolutions.swing.docking.Dockable;

public class CMsAgentMgrOpener extends AbstractMoOpener
{
    public final static String KEY = "Micro Service Agent Mgr";
    public CMsAgentMgrOpener()
    {
        super(KEY);
    }
    
    // 默认每次要刷新
    public boolean isForceReopen()
    {
        return false;
    }

    CMsAgentMgrPanel _panel = null;
    public Dockable openNewEditor() throws Exception
    {
        if (_panel == null)
        {
            if (false) new CMsAgentMgrPanel();
            _panel = (CMsAgentMgrPanel) ClassFactory.newInstance(CMsAgentMgrPanel.class);
            _panel.getDockKey().setKey(KEY);
        }
        
        return _panel;
    }
    
    public void openExistEditor(Dockable dockable) throws Exception
    {
        CMsAgentMgrPanel view = (CMsAgentMgrPanel) dockable;
        view.reload();
    }

    public String getName()
    {
        return dfcutil.getString("Open "+KEY);
    }

}
