package bap.ms.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

import org.nutz.dao.Cnd;
import org.nutz.dao.sql.OrderBy;
import org.nutz.dao.util.cri.OrderBySet;
import org.nutz.dao.util.cri.SimpleCriteria;
import org.nutz.dao.util.cri.SqlExpression;

import com.cdao.CDaoConst;
import com.cdao.dto.CPager;
import com.cdao.gui.CDaoFrame;
import com.cdao.gui.filter.CDoFilterPanel;
import com.cdao.mgr.CDaoClient;
import com.leavay.client.util.MBox;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.Exception.UserCancelException;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.OSProcessCmd.MonitorErrorThread;
import com.leavay.common.util.Pair;
import com.leavay.common.util.SortButtonRenderer;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ToolUtilities.AnsyncCallThread;
import com.leavay.common.util.ToolUtilities.AsynCallbackHandler;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ProgressCtrl.ProgressControllerFEImpl;
import com.leavay.common.util.ProgressCtrl.ProgressCtrlUtil;
import com.leavay.common.util.systemOut.StreamPrinter;
import com.leavay.dfc.mgr.starter.CDaoStarter;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.ms.warehouse.MsAgentDto;
import com.leavay.ms.warehouse.MsAgentInfoDto;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.BasicDockView;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.project.gui.common.JMultiPagePanel;
import com.project.gui.common.JSimplePagePanel;
import com.project.gui.common.JWaitDialog;

import bap.ms.CMsCenterService;
import bap.ms.track.CMsTrackCenterStarter;
import jetty.emb.JettyStarter;
import md.ms.MsAgentDo;
import ms.cmn.HostPort;
import ms.cmn.util.ProcessMonitor;

/**
 * To AI：此模块已废弃，现由Ts（Tiny Service）系列功能代替
 */
@Deprecated
public class CMsAgentMgrPanel extends BasicDockView implements ActionListener
{
    public JButton jBtnRefresh = GuiUtil.createToolButton("refresh.png", getString("Refresh"), this);
    public JButton jBtnCreate = GuiUtil.createButton(getString("Create"), "add.gif", this);
    public  JButton jBtnBatchCreate = GuiUtil.createButton(getString("Batch Create"), "batchAdd.png", this);
    JButton jBtnModify = GuiUtil.createButton(getString("Modify"), "modify.png", this);
    JButton jBtnRebuild = GuiUtil.createButton(getString("Rebuild Agent"), "service.png", this);
    JButton jBtnDelete = GuiUtil.createToolButton("remove.png", getString("Delete"), this);
    JButton jBtnStart = GuiUtil.createToolButton("start_16.png", getString("Startup"), this);
    JButton jBtnShutdown = GuiUtil.createToolButton("stop_16.png", getString("Shutdown"), this);
    
    public JButton jBtn_Filter = GuiUtil.createToolButton("dfc/filter.png", "Advance Filter", this);
    JButton jBtn_ReadWorkerOutput = GuiUtil.createToolButton("dfc/command_16.png", getString("Read Last Output"), this);
    
    final static String[] Header = new String[] {"Agent", "Status",  "PID", "Start Time", "Thread", "JVM Memory", "OS Memory","Message", "Deploy Info"};
    public final static int COL_Agent=0;
    public final static int COL_Status=1;
    public final static int COL_Pid=2;
    public final static int COL_ProcStart=3;
    public final static int COL_ThreadCnt=4;
    public final static int COL_JvmMem=5;
    public final static int COL_OsMem=6;
    public final static int COL_Message=7;
    public final static int COL_DeployInfo=8;
    
    SortButtonRenderer.SortableModel _model = new SortableModel() {
        public boolean isCellEditable(int row, int column)
        {
            return false;
        }
        
        public void sortColumnData(int iColumn, int iState) throws Exception
        {
            reload();
        }
    };
    JTable jTbl = new JTable(_model);
    
    public static String getString(String s)
    {
        return s;
    }
    
    public CMsCenterService getIntf()
    {
        return CMsClient.getIntf();
    }
    
    public class AgentWrapper
    {
        MsAgentDto dto;
        HashSet<String> enableOption;
        Map<String, String> mapParam;
        
        public AgentWrapper(MsAgentDto agt)
        {
            dto = agt;
        }
        
        public MsAgentDto getAgent()
        {
            return dto;
        }
        
        public String toString()
        {
            return dto.toString();
        }
        
        public HashSet<String> getOptionSet() throws Exception
        {
            if (enableOption == null && !CmnUtil.isStringEmpty(dto.getStarterConf()))
            {
                enableOption = MsAgentDo.convertStarterConfig(dto.getStarterConf());
            }
            
            return enableOption;
        }
        
        public Map<String, String> getConfigTable() throws Exception
        {
            if (mapParam == null)
            {
                mapParam = MsAgentDo.convertConfigTableMap(dto.getConfigTable());
            }
            
            return mapParam;
        }
    }

    class StatusRender extends DefaultTableCellRenderer
    {
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (value != null)
            {
                switch ((int)value)
                {
                case MsAgentInfoDto.STATUS_OK:
                    setBackground(Color.green);
                    setText("OK");
                    break;
                case MsAgentInfoDto.STATUS_WARN:
                    setBackground(Color.yellow);
                    setText("WARN");
                    break;
                case MsAgentInfoDto.STATUS_DANGER:
                    setBackground(Color.orange);
                    setText("DANGER");
                    break;
                case MsAgentInfoDto.STATUS_LOST:
                    setBackground(Color.red);
                    setText("LOST");
                    break;
                }
            }
            return this;
        }
    }
    
    class MainRender extends DefaultTableCellRenderer
    {
        Box myBox = Box.createHorizontalBox();
        JLabel jLabDebug = new JLabel(GuiResource.getIcon("dfc/debug_16.png"));
        JLabel jLabWeb = new JLabel(GuiResource.getIcon("dfc/internet.png"));
        JLabel jLabDaoCenter = new JLabel(GuiResource.getIcon("db/db_18.png"));
        JLabel jLabDaoFollower = new JLabel(GuiResource.getIcon("dfc/db.png"));
        JLabel jLabMsTrackLeader = new JLabel(GuiResource.getIcon("dfc/track.png"));
        JLabel jLabMsTrackFollower = new JLabel(GuiResource.getIcon("dfc/trackDisable.png"));
        
        public MainRender()
        {
            jLabWeb.setToolTipText(getString("HTTP Service"));
            jLabDaoCenter.setToolTipText(getString("DAO Center"));
            jLabDaoFollower.setToolTipText(getString("DAO Follower"));
            
            myBox.add(this);
            myBox.add(MBox.HGlue());
            myBox.add(jLabMsTrackLeader);
            myBox.add(MBox.HStrut(1));
            myBox.add(jLabMsTrackFollower);
            myBox.add(MBox.HStrut(1));
            myBox.add(jLabDaoCenter);
            myBox.add(MBox.HStrut(1));
            myBox.add(jLabDaoFollower);
            myBox.add(MBox.HStrut(1));
            myBox.add(jLabWeb);
            myBox.add(MBox.HStrut(2));
            myBox.add(jLabDebug);
            myBox.add(MBox.HStrut(1));
            myBox.add(MBox.HStrut(1));
            jLabDaoCenter.setVisible(false);
            jLabDaoFollower.setVisible(false);
            jLabWeb.setVisible(false);
            jLabDebug.setVisible(false);
            myBox.setOpaque(true);
        }
        
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column)
        {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            jLabDaoCenter.setVisible(false);
            jLabDaoFollower.setVisible(false);
            jLabDebug.setVisible(false);
            jLabWeb.setVisible(false);
            jLabMsTrackLeader.setVisible(false);
            jLabMsTrackFollower.setVisible(false);
            
            if (value != null && value instanceof AgentWrapper)
            {
                AgentWrapper agt = (AgentWrapper)value;
                setForeground(Color.black);
                if (agt.getAgent().isAutoDeploy())
                {
                    if (agt.getAgent().getDeployType() == MsAgentDto.DEPLOY_SSH)
                        setIcon(GuiResource.getIcon("dfc/ssh.png"));
                    else
                        setIcon(GuiResource.getIcon("dfc/service.png"));
                }else
                {
                    setIcon(GuiResource.getIcon("dfc/server.png"));
                    setForeground(Color.gray);
                }
                
                setText(agt.toString());

                try
                {
                    if (agt.getOptionSet() != null)
                    {
                        if (agt.getOptionSet().contains(CDaoStarter.MODULE_NAME))
                        {
                            boolean isSlave = ToolUtilities.getBoolean(agt.getConfigTable().get(CDaoConst.CONF_CLUSTER_IS_SLAVE), CDaoConst.DEFAULT_IS_SLAVE);
                            jLabDaoCenter.setVisible(!isSlave);
                            jLabDaoFollower.setVisible(isSlave);
                        }
                        
                        if (agt.getOptionSet().contains(CMsTrackCenterStarter.MODULE_NAME))
                        {
                            if (_trackCenter != null && CmnUtil.isStringEqual(_trackCenter.getKey(), agt.getAgent().getCode()))
                                jLabMsTrackLeader.setVisible(true);
                            else
                                jLabMsTrackFollower.setVisible(true);
                        }
                        
                        if (agt.getOptionSet().contains(JettyStarter.MODULE_NAME))
                        {
                            jLabWeb.setVisible(true);
                        }
                    }
                } catch (Exception exp)
                {
                    exp.printStackTrace();
                }
            }
            
            myBox.setBackground(getBackground());
            return myBox;
        }
    }
    
    public static class MemBar extends DefaultTableCellRenderer
    {
        final Color c1 = new Color(130, 150 ,255);
        final Color c2 = new Color(250, 220 ,90);
        final Color c3 = new Color(255, 130 , 80);
        final Color c4 = new Color(255, 40 , 40);
        long _used = 0;
        long _max = -1;

        public MemBar()
        {
            setHorizontalTextPosition(SwingConstants.CENTER);
        }
        
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
        {
            super.getTableCellRendererComponent(table, value, false, hasFocus, row, column);
            
            _used = 0;
            _max  = 0;
            if (column == COL_OsMem || column == COL_JvmMem)
            {
                if (value != null && value instanceof Pair)
                {
                    try
                    {
                        _used = (Long) ((Pair) value).left;
                        _max = (Long) ((Pair) value).right;
                    }catch(Throwable err)
                    {
                        
                    }
                }
            }

            return this;
        }

        protected void paintComponent(Graphics g)
        {
            try
            {
                int iHeight = getHeight() - 3;
                int iWidth = getWidth() - 3;
                if ((double)_used * 100 / (double)_max < 80f)
                    g.setColor(c1);
                else if ((double)_used * 100 / (double)_max < 85f)
                    g.setColor(c2);
                else if ((double)_used * 100 / (double)_max < 89f)
                    g.setColor(c3);
                else
                    g.setColor(c4);
                
                g.fillRect(1, 1, (int) (_used * iWidth/ _max), iHeight);
                g.drawRect(1, 1, iWidth, iHeight);
                
                setText(ToolUtilities.memSize2String(_used) + " / " + ToolUtilities.memSize2String(_max));
            } catch (Throwable err)
            {
                setText(getString("Unknown"));
            }

            super.paintComponent(g);
        }
    }
    
    public  JMultiPagePanel jPage = new JMultiPagePanel(null, JSimplePagePanel.TYPE_FULL)
    {
        public void showData(List lstData)
        {
            try
            {
                showRows(lstData);
            } catch (Exception exp)
            {
                DetailErrorMsg.showError(this, exp);
                ToolUtilities.throwRuntimeException(exp);
            }
        }
        
        protected MultiPageResult CallBack_LoadPage(int iStartPos, int iPageSize) throws Exception
        {
            return CMsClient.getIntf().queryMsAgent(getCondition(), new CPager(iStartPos, iPageSize, true));
        }
    };
    
    public CMsAgentMgrPanel() throws Exception
    {
        super();
        getDockKey().setIcon(GuiResource.getIcon("dfc/server2.png"));
        getDockKey().setName(getString("Micro Agent Management"));
        
        for (String s : Header)
            _model.addColumn(getString(s));
        
        jTbl.getColumnModel().getColumn(COL_Agent).setCellRenderer(new MainRender());
        jTbl.getColumnModel().getColumn(COL_Status).setCellRenderer(new StatusRender());
        jTbl.getColumnModel().getColumn(COL_JvmMem).setCellRenderer(new MemBar());
        jTbl.getColumnModel().getColumn(COL_OsMem).setCellRenderer(new MemBar());
        GuiUtil.setTableColumnWidth(jTbl, COL_Agent,250);
        GuiUtil.setTableColumnMaxWidth(jTbl, COL_Status, 60);
        
        GuiUtil.setTableColumnMaxWidth(jTbl, COL_Pid, 60);
        GuiUtil.setTableColumnMaxWidth(jTbl, COL_ProcStart, 80);
        GuiUtil.setTableColumnMaxWidth(jTbl, COL_ThreadCnt, 50);

        GuiUtil.setTableColumnWidth(jTbl, COL_JvmMem, 140);
        GuiUtil.setTableColumnMaxWidth(jTbl, COL_JvmMem, 140);
        GuiUtil.setTableColumnWidth(jTbl, COL_OsMem, 140);
        GuiUtil.setTableColumnMaxWidth(jTbl, COL_OsMem, 140);
        
        GuiUtil.setTableColumnWidth(jTbl, COL_Message, 250);
        GuiUtil.setTableColumnWidth(jTbl, COL_DeployInfo, 120);
        SortButtonRenderer.setHeader(jTbl);
        jTbl.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent e) {
                if (GuiUtil.isSingleClickRight(e))
                {
                    try
                    {
                        OnRighClick(e);
                    } catch (Exception exp)
                    {
                        DetailErrorMsg.showError(exp);
                    }
                }
            }
        });
        
        Box boxMain = Box.createVerticalBox();
        boxMain.add(MBox.createHBar(22, jBtnRefresh, MBox.HSeperator(), jBtnCreate, jBtnBatchCreate, jBtnModify, jBtnRebuild, jBtnDelete, jBtnShutdown, jBtnStart, MBox.HSeperator(), jBtn_ReadWorkerOutput, MBox.HGlue(), jBtn_Filter));
        boxMain.add(new JScrollPane(jTbl));
        boxMain.add(jPage);
        
        GuiUtil.setGridLayout(this, boxMain);
        reload();
        GuiUtil.adjustTableColumnWidth(jTbl);
        
        this.setPreferredSize(new Dimension(1200, 500));
        _thrUpdate.start();
    }
    
    HostPort _trackCenter = null;
    public void reload() throws Exception
    {
        jPage.refreshCurrentPage();
        _trackCenter = CMsClient.getIntf().getTrackCenter();
    }
    
    protected void showRows(List lstData) throws Exception
    {
        GuiUtil.clearTableRows(_model);

        for(MsAgentDto agt : (List<MsAgentDto>)lstData)
            _model.addRow(new Object[] {new AgentWrapper(agt), null, null, null, null, null, null, agt.getMessage(), null});
        
        updateInfo();
    }

    public void actionPerformed(ActionEvent e)
    {
        try
        {
            if (e.getSource() == jBtnRefresh)
                reload();
            else if (e.getSource() == jBtnCreate)
                OnBtnCreate();
            else if (e.getSource() == jBtnBatchCreate)
                OnBtnBatchCreate();
            else if (e.getSource() == jBtnModify)
                OnBtnModify();
            else if (e.getSource() == jBtnRebuild)
                OnBtnRebuild();
            else if (e.getSource() == jBtn_Filter)
                OnBtnFilter();
            else if (e.getSource() == jBtnDelete)
                OnBtnDelete();
            else if (e.getSource() == jBtnShutdown)
                OnBtnShutdown();
            else if (e.getSource() == jBtnStart)
                OnBtnStart();
            else if (e.getSource() == jBtn_ReadWorkerOutput)
                OnBtnReadConsole();
        } catch (Throwable err)
        {
            DetailErrorMsg.showError(this, err);
        }
    }

    SqlExpression _sqlExp;
    public void OnBtnFilter() throws Exception
    {
        try
        {
            setFilter(CDoFilterPanel.showFilterDialog(jBtn_Filter, CDaoClient.getIntf().getEntity(MsAgentDo.class.getName()), _sqlExp));
        }catch(UserCancelException cancel)
        {
            
        }
        reload();
    }
    
    public void setFilter(SqlExpression exp)
    {
        _sqlExp = exp;
    }
    
    public SqlExpression getFilter()
    {
        return _sqlExp;
    }
    
    public Cnd getCondition()
    {
        SimpleCriteria cri = Cnd.cri();
        
        getOrderBy(cri);

        SqlExpression filter = getFilter();
        if (filter != null)
            cri.where().and(filter);
        
        return Cnd.byCri(cri);
    }
    
    public String getColumnName(int col)
    {
        switch(col)
        {
        case COL_Agent:
            return MsAgentDo.Code;
        case COL_Message:
            return MsAgentDo.Message;
        }
        
        return null;
    }
    
    public OrderBy getOrderBy(SimpleCriteria cri)
    {
        if (_model == null)
            return null;
        
        int sortCol = _model.getSortColumn();
        String col = getColumnName(sortCol);
        
        if (!ToolUtilities.isStringEmpty(col))
        {        
            if (_model.getSortState() == SortButtonRenderer.UP)
                return cri.asc(col);
            else if (_model.getSortState() == SortButtonRenderer.DOWN)
                return cri.desc(col);
        }
        
        if (_dftOrder != null)
            cri.setOrderBy(_dftOrder);
        return cri.getOrderBy();
    }
    
    OrderBySet _dftOrder = new OrderBySet().asc(MsAgentDo.Code);
    public void setDefaultOrderBy(OrderBySet order)
    {
        _dftOrder = order;
    }
    
    public void OnBtnCreate() throws Exception
    {
        MsAgentDto selAgt = getSelectAgent();
        if (selAgt == null)
            selAgt = new MsAgentDto();
        selAgt.setUuid(null);
        selAgt.setName(null);
        
        CMsAgentEditorPanel panel = new CMsAgentEditorPanel();
        panel.showData(selAgt);
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, this);
        dlg.pack();
        while (dlg.showTopModel(true))
        {
            try
            {
                MsAgentDto agent = panel.getDataFrmGui();
                getIntf().createMsAgent(agent);
                reload();
                return;
            } catch (Throwable err)
            {
                DetailErrorMsg.showError(err);
                continue;
            }
        }
        return;
    }
    
    public void OnBtnBatchCreate() throws Exception
    {
        String ss = JOptionPane.showInputDialog(this, "How many agents do you need : ");
        if (ss == null)
            return;
        int cnt = ToolUtilities.getInteger(ss);
        
        CMsAgentEditorPanel panel = new CMsAgentEditorPanel();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, this);
        dlg.pack();
        if (!dlg.showModel(true))
            return;
        
        try
        {
            MsAgentDto orgAgent = panel.getDataFrmGui();
            for (int i=0;i <cnt;i++)
            {
                int port = orgAgent.getNioPort() + i;
                
                MsAgentDto agent = (MsAgentDto) ToolUtilities.clone(orgAgent);
                agent.setNioPort(port);
                agent.setSshPath(orgAgent.getSshPath()+"/"+port);
                getIntf().createMsAgent(agent);
            }
      
        }finally
        {
            reload();
        }
    }

    public void OnBtnModify() throws Exception
    {
        MsAgentDto agt = getSelectAgent();
        if (agt == null)
            return;
        
        CMsAgentEditorPanel editor = new CMsAgentEditorPanel();
        editor.showData(agt);

        JSimpleDialog dlg = GuiUtil.createSimpleDialog(editor, this);
        dlg.pack();
        while (dlg.showModel())
        {
            try
            {
                MsAgentDto agent = editor.getDataFrmGui();
                
                if (false) doModify(agent);
                JWaitDialog.showWaitDialogModeless(new AsynCallbackHandler()
                {
                    public void afterFinished(AnsyncCallThread thread)
                    {
                        try
                        {
                            reload();
                        } catch (Exception exp)
                        {
                            exp.printStackTrace();
                        }
                    }
                }, "Modify Agent : " + agent.getName(), this, this, "doModify", agent);
                return;
            } catch(Throwable err)
            {
                DetailErrorMsg.showError(this, err);
                continue;
            }
        }
    }
    
    public void doModify(MsAgentDto agent) throws Exception
    {
        getIntf().updateMsAgent(agent, true);
    }
    
    public void OnBtnRebuild() throws Exception
    {
        int[] rows = jTbl.getSelectedRows();
        if (rows == null || rows.length <= 0)
            return;

        try
        {
            List<MsAgentDto> lstAgts = new LinkedList<MsAgentDto>();
            for (int i = 0; i < rows.length; i++)
            {
                MsAgentDto agt = getRowAgent(rows[i]);
                lstAgts.add(agt);
            }

            if (false) doRebuild(null, lstAgts);
            ProgressCtrlUtil.startProgressDialog(this, "Rebuild Agents", this, "doRebuild", lstAgts);
        } finally
        {
            reload();
        }
    }
    
    public MsAgentDto getRowAgent(int row)
    {
        return ((AgentWrapper)_model.getValueAt(row, COL_Agent)).getAgent();
    }
    
    public void doRebuild(ProgressControllerFEImpl prog, List<MsAgentDto> lstAgts) throws Exception
    {
        try
        {
            for (int i=0;i<lstAgts.size(); i++)
            {
                MsAgentDto agt = lstAgts.get(i);
                
                ProgressCtrlUtil.assertCancel(prog);
                ProgressCtrlUtil.sendProcess(prog, i*100/lstAgts.size(), "Deploy agent : " + agt.getName(), true);
                
                getIntf().rebuildMsAgent(agt.getGid());
            }
        }finally
        {
            ProgressCtrlUtil.sendFinishProcess(prog);
        }
    }
    
    public void OnBtnDelete() throws Exception
    {
        int[] rows = jTbl.getSelectedRows();
        if (rows == null || rows.length <= 0)
            return;

        if (JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(this, "Are you sure to delete selected rows?"))
            return;
        
        try
        {
            List<MsAgentDto> lstAgts = new LinkedList<MsAgentDto>();
            for (int i = 0; i < rows.length; i++)
            {
                MsAgentDto agt = getRowAgent(rows[i]);
                lstAgts.add(agt);
            }

            if (false) doDelete(null, lstAgts);
            ProgressCtrlUtil.startProgressDialog(this, "Delete Agents", this, "doDelete", lstAgts);
        } finally
        {
            reload();
        }
    }
    
    public void doDelete(ProgressControllerFEImpl prog, List<MsAgentDto> lstAgts) throws Exception
    {
        try
        {
            for (int i=0;i<lstAgts.size(); i++)
            {
                MsAgentDto agt = lstAgts.get(i);
                
                ProgressCtrlUtil.assertCancel(prog);
                ProgressCtrlUtil.sendProcess(prog, i*100/lstAgts.size(), "Delete agent : " + agt.getName(), true);
                
                getIntf().killAndDeleteMsAgent(agt.getGid());
            }
        }finally
        {
            ProgressCtrlUtil.sendFinishProcess(prog);
        }
    }
    
    public void OnBtnShutdown() throws Exception
    {
        int[] rows = jTbl.getSelectedRows();
        if (rows == null || rows.length <= 0)
            return;

        
        try
        {
            List<MsAgentDto> lstAgts = new LinkedList<MsAgentDto>();
            for (int i = 0; i < rows.length; i++)
            {
                MsAgentDto agt = getRowAgent(rows[i]);
                lstAgts.add(agt);
            }

            if (false) doShutdown(null, lstAgts);
            ProgressCtrlUtil.startProgressDialog(this, "Shutdown Agents", this, "doShutdown", lstAgts);
        } finally
        {
            reload();
        }
    }
    
    public void doShutdown(ProgressControllerFEImpl prog, List<MsAgentDto> lstAgts) throws Exception
    {
        try
        {
            for (int i=0;i<lstAgts.size(); i++)
            {
                MsAgentDto agt = lstAgts.get(i);
                
                ProgressCtrlUtil.assertCancel(prog);
                ProgressCtrlUtil.sendProcess(prog, i*100/lstAgts.size(), "Shutdown agent : " + agt.getName(), true);
                
                getIntf().terminateMsAgent(agt.getGid());
            }
        }finally
        {
            ProgressCtrlUtil.sendFinishProcess(prog);
        }
    }
    
    public void OnBtnStart() throws Exception
    {
        int[] rows = jTbl.getSelectedRows();
        if (rows == null || rows.length <= 0)
            return;

        try
        {
            List<MsAgentDto> lstAgts = new LinkedList<MsAgentDto>();
            for (int i = 0; i < rows.length; i++)
            {
                MsAgentDto agt = getRowAgent(rows[i]);
                lstAgts.add(agt);
            }

            if (false) doStart(null, lstAgts);
            ProgressCtrlUtil.startProgressDialog(this, "Start Agents", this, "doStart", lstAgts);
        } finally
        {
            reload();
        }
    }
    
    public void doStart(ProgressControllerFEImpl prog, List<MsAgentDto> lstAgts) throws Exception
    {
        try
        {
            for (int i=0;i<lstAgts.size(); i++)
            {
                MsAgentDto agt = lstAgts.get(i);
                
                ProgressCtrlUtil.assertCancel(prog);
                ProgressCtrlUtil.sendProcess(prog, i*100/lstAgts.size(), "Start agent : " + agt.getName(), true);
                
                getIntf().startMsAgent(agt.getGid());
            }
        }finally
        {
            ProgressCtrlUtil.sendFinishProcess(prog);
        }
    }
    
    public void updateInfo() throws Exception
    {
        Set<String> ids = new HashSet<String>();
        for (int i =0;i<_model.getRowCount();i++)
        {
            ids.add(getRowAgent(i).getCode());
        }
        
        asyncUpdateInfo(ids);
    }
    
    LazyPool<String> _lazyUpdateAgentInfo = new LazyPool<String>("Lazy Update MsAgent Info", 500)
    {
        public void handle(List<String> objects)
        {
            try
            {
                _doUpdateInfo(new HashSet(objects));
            } catch (Exception exp)
            {
                exp.printStackTrace();
            }
        }
    };
    
    public void asyncUpdateInfo(Set<String> ids) throws Exception
    {
        _lazyUpdateAgentInfo.add(ids);
    }
    
    public void _doUpdateInfo(Set<String> ids) throws Exception
    {
        Map<String, MsAgentInfoDto> mapInfo = getIntf().queryMsAgentInfo(ids);
        if (false) updateInfoRows(mapInfo);
        GuiUtil.invokeLater(this, "updateInfoRows", mapInfo);
    }
    
    public void updateInfoRows(Map<String, MsAgentInfoDto> mapInfo)
    {
        for (int i =0;i<_model.getRowCount();i++)
        {
            MsAgentInfoDto info = mapInfo.get(getRowAgent(i).getCode());
            updateRowInfo(i, info);
        }
    }
    
    public void updateRowInfo(int row, MsAgentInfoDto info)
    {
        if (info == null)
        {
            _model.setValueAt(null, row, COL_Status);
            _model.setValueAt(null, row, COL_Pid);
            _model.setValueAt(null, row, COL_ProcStart);
            _model.setValueAt(null, row, COL_ThreadCnt);
            _model.setValueAt(null, row, COL_JvmMem);
            _model.setValueAt(null, row, COL_OsMem);
            _model.setValueAt(null, row, COL_DeployInfo);
        }else
        {
            String startTime = info.getProcStartTime() <= 0 ? "" : ToolUtilities.timeTick2String(info.getProcStartTime(), false);
            _model.setValueAt(startTime, row, COL_ProcStart);
            
            _model.setValueAt(info.getStatus(), row, COL_Status);
            _model.setValueAt(new Pair(info.getJvmMemUsed(), info.getJvmMemMax()), row, COL_JvmMem);
            _model.setValueAt(new Pair(info.getTotalSysMem()-info.getFreeSysMem(), info.getTotalSysMem()), row, COL_OsMem);
            _model.setValueAt(info.getProcessID(), row, COL_Pid);
            
            _model.setValueAt(info.getThreadCount(), row, COL_ThreadCnt);
            _model.setValueAt(info.getMessage(), row, COL_Message);
            
            String deployInfo = "";
            if (info.getDeployTime() > 0)
                deployInfo = ToolUtilities.time2String(info.getDeployTime(), false);
            if (!CmnUtil.isObjectEmpty(info.getAddrList()))
                deployInfo+= " "+ToolBasic.logString(info.getAddrList(), false);
            _model.setValueAt(deployInfo, row, COL_DeployInfo);
        }
    }
    
    public MsAgentDto getSelectAgent()
    {
        int row = jTbl.getSelectedRow();
        if (row >=0)
            return getRowAgent(row);
        
        return null;
    }
    
    public List<MsAgentDto> getSelectAgents()
    {
        List<MsAgentDto> lstRet= new LinkedList<MsAgentDto>();
        
        int[] rows = jTbl.getSelectedRows();
        if (rows != null)
            for (int i=0;i<rows.length;i++)
            {
                lstRet.add(getRowAgent(rows[i]));
            }
        
        return lstRet;
    }
    
    Thread _thrUpdate = new Thread()
    {
        public void run()
        {
            for (;;)
            {
                try
                {
                    if (false)
                        updateInfo();
                    GuiUtil.invokeLater(CMsAgentMgrPanel.this, "updateInfo");
                    
                    ToolUtilities.sleep(2000);
                }catch(Throwable err)
                {
                    err.printStackTrace();
                }
            }
        }
    };
    
    public void OnBtnReadConsole() throws Exception
    {
        final MsAgentDto agent = getSelectAgent();
        if (agent == null)
            return;

        final JTextArea jTxt = new JTextArea();
        jTxt.setLineWrap(true);
        jTxt.setFont(new Font("Dialog", 0, 13));
        jTxt.setBackground(Color.black);
        jTxt.setForeground(Color.white);
        JScrollPane jScr = new JScrollPane(jTxt);

        JSimpleDialog dlg = GuiUtil.createSimpleDialog(jScr, this, null, true);
        dlg.setTitle(agent.getName());
        dlg.getButtonBar().setVisible(false);
        dlg.setPreferredSize(new Dimension(840, 480));
        dlg.pack();
        GuiUtil.centerWindow(dlg);
        dlg.setAlwaysOnTop(true);
        dlg.showModel(false);
        new Thread("Auto refresh worker output")
        {
            public void run()
            {
                jTxt.setText("Reading ... ");
                
                boolean firstTime = true;
                do
                {
                    ToolUtilities.sleep(1000);
                    try
                    {
                        // 如果有选中，则暂挂不刷新
                        if (!ToolUtilities.isStringEmpty(jTxt.getSelectedText()))
                            continue;
                        
                        MultiPageResult<String> lstLines = getIntf().readMsAgentOutput(agent.getGid(), -1, 300);
                        if (lstLines == null)
                            return;
                        
                        boolean orgAtBottom = GuiUtil.isScrollbarBottom(jScr);
                        
                        jTxt.setText(ToolUtilities.listToString(lstLines.getListData()));

                        // 原本处于滚动最底，则自动滚
                        if (firstTime || orgAtBottom)
                        {
                            firstTime = false;
                            GuiUtil.scrollToBottomLater(jTxt, true);
                        }
                    } catch (Exception exp)
                    {
                        exp.printStackTrace();
                    }

                } while (GuiUtil.isComponentVisible(jTxt));
            }
        }.start();
    }
    
    public void OnRighClick(MouseEvent e) throws Exception
    {
        int row = jTbl.getSelectedRow();
        if (row < 0)
            return;

        JPopupMenu pop = new JPopupMenu();
        AgentWrapper agt = (AgentWrapper) _model.getValueAt(row, COL_Agent);

        if (agt.getOptionSet() != null && agt.getOptionSet().contains(CDaoStarter.MODULE_NAME))
        {
            JMenuItem menuShowDaoFrame = new JMenuItem("DAO Frame");
            menuShowDaoFrame.addActionListener(new ActionAdapter()
            {
                public void OnAction(ActionEvent e) throws Exception
                {
                    OnShowDaoFrame(agt.getAgent());
                }
            });
            
            pop.add(menuShowDaoFrame);
        }
        
        pop.show(e.getComponent(), e.getX(), e.getY());
    }
    
    public void OnShowDaoFrame(MsAgentDto agt) throws IOException
    {
        Process proc = Runtime.getRuntime().exec(ToolUtilities.getJdkHome()+"/bin/java -cp "+ CmnUtil.getClassPath() + " "+CDaoFrame.class.getName()+" "+agt.getMyHost()+" "+agt.getNioPort());
        ProcessMonitor moni = new ProcessMonitor("DAO Frame : " + agt.getMyHost()+":"+agt.getNioPort(), proc) {

            public void printError(Object o)
            {
                CmnUtil.err(o);
            }

            public void printOut(Object o)
            {
                CmnUtil.out(o);
            }
            
        };
        moni.start();
    }
    
    public static class MonitorErrorThread extends Thread
    {
        boolean blTerminate = false;
        BufferedReader _errorReader;
        public MonitorErrorThread(BufferedReader _errorReader)
        {
            super("OSProcessCtrl_Error : ");
            this._errorReader = _errorReader;
        }
        
        public synchronized void stopThread()
        {
            blTerminate = true;
        }
        
        public void run()
        {
            while (true)
            {
                // 默认sleep 100，但是如遇未完待续则缩短为1
                long sleepTime = 100;
                
                synchronized (this)
                {
                    if (blTerminate)
                        return;
                }

                try
                {
                    if (_errorReader.ready())
                    {
                        char[] buf = new char[1024];
                        int iSize = _errorReader.read(buf);
                        if (iSize > 0)
                            CmnUtil.err(new String(buf, 0, iSize).trim());
                        
                        if (iSize >= 1024)
                            sleepTime = 1;
                    }
                } catch (IOException exp1)
                {
                    exp1.printStackTrace();
                }
                
                ToolUtilities.sleep(sleepTime);
            }
        }
    }
}
