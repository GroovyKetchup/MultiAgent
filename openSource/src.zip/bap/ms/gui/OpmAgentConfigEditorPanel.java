package bap.ms.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import com.leavay.client.util.MBox;
import com.leavay.common.util.ToolUtilities;
import com.project.gui.common.GuiUtil;

public class OpmAgentConfigEditorPanel extends JPanel
{
    protected static class ParamItem
    {
        String key;
        String label;
        String type;
        String dft;
        String group;
        String groupLabel;
        String subGroup;
    }

    protected final JTabbedPane _tabs = new JTabbedPane();
    protected final LinkedHashMap<String, JComponent> _ctrlMap = new LinkedHashMap<String, JComponent>();
    protected final LinkedHashMap<String, String> _typeMap = new LinkedHashMap<String, String>();

    public OpmAgentConfigEditorPanel(Map<String, Object> schema, Map<String, String> values)
    {
        build(schema, values);
    }

    @SuppressWarnings("unchecked")
    protected void build(Map<String, Object> schema, Map<String, String> values)
    {
        List<Map<String, String>> groups = schema == null ? null : (List<Map<String, String>>) schema.get("groups");
        List<Map<String, String>> params = schema == null ? null : (List<Map<String, String>>) schema.get("params");

        ArrayList<ParamItem> items = new ArrayList<ParamItem>();
        if (params != null)
            for (Map<String, String> p : params)
            {
                ParamItem pi = new ParamItem();
                pi.key = ToolUtilities.getString(p.get("key"), null);
                if (ToolUtilities.isStringEmpty(pi.key, true))
                    continue;
                pi.label = ToolUtilities.getString(p.get("label"), pi.key);
                pi.type = ToolUtilities.getString(p.get("type"), "string");
                pi.dft = p.get("default");
                pi.group = ToolUtilities.getString(p.get("group"), "default");
                pi.groupLabel = ToolUtilities.getString(p.get("groupLabel"), pi.group);
                pi.subGroup = ToolUtilities.getString(p.get("subGroup"), "default");
                items.add(pi);
            }

        if (groups != null)
            for (Map<String, String> g : groups)
            {
                String gkey = ToolUtilities.getString(g.get("key"), null);
                if (ToolUtilities.isStringEmpty(gkey, true))
                    continue;

                String glabel = ToolUtilities.getString(g.get("label"), gkey);
                JPanel gp = createGroupPanel(gkey, items, values);
                _tabs.addTab(glabel, gp);
            }

        if (_tabs.getTabCount() <= 0)
            _tabs.addTab("配置", createGroupPanel(null, items, values));

        setPreferredSize(new Dimension(860, 620));
        GuiUtil.setGridLayout(this, _tabs);
    }

    protected JPanel createGroupPanel(String groupKey, List<ParamItem> all, Map<String, String> values)
    {
        Box root = Box.createVerticalBox();
        String currSub = null;

        for (ParamItem p : all)
        {
            if (p == null)
                continue;
            if (!ToolUtilities.isStringEmpty(groupKey, true) && !ToolUtilities.isStringEqual(groupKey, p.group))
                continue;

            if (!ToolUtilities.isStringEqual(currSub, p.subGroup))
            {
                currSub = p.subGroup;
                JLabel sub = new JLabel("[" + ToolUtilities.getString(currSub, "default") + "]");
                sub.setBorder(BorderFactory.createEmptyBorder(8, 4, 4, 4));
                root.add(sub);
            }

            String val = values == null ? null : values.get(p.key);
            if (ToolUtilities.isStringEmpty(val, true))
                val = p.dft;

            JComponent ctrl = createEditor(p.type, val);
            _ctrlMap.put(p.key, ctrl);
            _typeMap.put(p.key, p.type);

            JLabel lab = new GuiUtil.LeftLabel(p.label, 240);
            lab.setToolTipText(p.key);
            root.add(MBox.createHBar(24, lab, MBox.HStrut(6), new JLabel(":"), MBox.HStrut(6), ctrl));
            root.add(MBox.VStrut(2));
        }

        root.add(MBox.VGlue());
        root.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

        JScrollPane scr = new JScrollPane(root);
        scr.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        JPanel panel = new JPanel();
        GuiUtil.setGridLayout(panel, scr);
        return panel;
    }

    protected JComponent createEditor(String type, String value)
    {
        String t = ToolUtilities.getString(type, "string").toLowerCase();
        if ("boolean".equals(t))
        {
            JCheckBox chk = new JCheckBox();
            chk.setSelected(ToolUtilities.getBoolean(value, false));
            return chk;
        }

        JTextField txt = new JTextField();
        txt.setText(ToolUtilities.getString(value, ""));
        return txt;
    }

    public LinkedHashMap<String, String> getConfigMap()
    {
        LinkedHashMap<String, String> out = new LinkedHashMap<String, String>();
        for (Map.Entry<String, JComponent> ent : _ctrlMap.entrySet())
        {
            String key = ent.getKey();
            if (ToolUtilities.isStringEmpty(key, true))
                continue;

            JComponent c = ent.getValue();
            String type = ToolUtilities.getString(_typeMap.get(key), "string");
            out.put(key, readVal(c, type));
        }
        return out;
    }

    protected String readVal(Component c, String type)
    {
        String t = ToolUtilities.getString(type, "string").toLowerCase();
        if (c instanceof JCheckBox)
            return String.valueOf(((JCheckBox) c).isSelected());

        if (c instanceof JTextField)
        {
            String txt = ((JTextField) c).getText();
            if ("boolean".equals(t))
                return String.valueOf(ToolUtilities.getBoolean(txt, false));
            return ToolUtilities.getString(txt, "").trim();
        }

        return "";
    }
}
