package bap.ms.embed;

import com.leavay.client.util.CNClientUtil;
import com.leavay.common.util.MppContext;
import com.leavay.dfc.mgr.disCache.DCacheUtil;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.starter.CStarter;

import bap.java.CJavaAgentMgr;
import bap.ms.CMsConst;
import bap.ms.CMsEmbMemberService;
import bap.ms.CMsUtil;

/**
 * 微代理接入微服务的启动模块
 * 
 */
public class CMsEmbStarter implements CStarter
{
    public void before(CStarter other) throws Exception
    {
        
    }

    public void start() throws Exception
    {
        // 初始化DCache，配置CNClient连主控的信息
        startAsMember();
        
        // 启动微服务（内部会自动启动NIO）
        CMsEmbMemberService.startInIsolateProcess();

        // 微代理上也要提供JAVA远程调试的服务
        CJavaAgentMgr.getMe().start();
    }
    
    public static void startAsMember()
    {
        DCacheUtil.setAsClient();
        
        CNClientUtil.setBEHost(CmnUtil.assertNotEmpty(MppContext.getString(CMsConst.CONF_MASTER_HOST), "Please check basic config : " + CMsConst.CONF_MASTER_HOST));
        CNClientUtil.setNioPort(MppContext.getInt(CMsConst.CONF_MASTER_NIO_PORT));
    }

}
