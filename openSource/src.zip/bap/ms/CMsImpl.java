package bap.ms;

import java.rmi.RemoteException;
import java.rmi.server.RemoteObject;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dfc.microService.MicroServiceRequest;
import com.leavay.dfc.microService.MsConsumer;
import com.leavay.dfc.microService.MsFragment;
import com.leavay.dfc.microService.MsIntf;
import com.leavay.dfc.microService.MsMgr;
import com.leavay.dfc.microService.MsProvider;
import com.leavay.dfc.microService.MsProviderCmn;
import com.leavay.dfc.microService.bean.AbsMsTrackBean;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.leavay.dfc.microService.msCache.MsCacheActionPackage;
import com.leavay.dfc.microService.msCache.MsCacheFinder;
import com.leavay.dfc.microService.msCache.MsCacheMap;
import com.leavay.dfc.microService.track.filter.MsFilterReq;
import com.leavay.dfc.microService.track.filter.MsFilterReqList;
import com.leavay.ms.embed.MsEmbConsumer;
import com.leavay.ms.embed.MsEmbProvider;

import bap.ms.track.CMsTrackCenter;

public class CMsImpl extends RemoteObject implements MsIntf
{
    private static final long serialVersionUID = -7844735647040262694L;
    
    private static CMsImpl _me = null;

    public static synchronized CMsImpl getMe()
    {
        if (_me == null)
        {
            _me = new CMsImpl();
        }

        return _me;
    }

    private CMsImpl()
    {
        super();
    }

    public void saveTrackData(List<AbsMsTrackBean> lstTracks) throws Exception
    {
        CMsTrackCenter.getHealthyCenter().saveTrack(lstTracks);
    }

    public MultiPageResult<MsTrackBean> queryTrack(boolean getCount, int startPos, int pageSize) throws Exception
    {
        return CMsTrackCenter.getHealthyCenter().queryTrack(getCount, startPos, pageSize);
    }

    public void startTrackMonitor(long interval)
    {
        CMsTrackCenter.getMe().startMonitor(interval);
    }

    public void stopTrackMonitor()
    {
        CMsTrackCenter.getMe().stopMonitor();
    }

    public Map<String, Object> queryTrackData(MsFilterReqList reqList) throws Exception
    {
        return CMsTrackCenter.getMe().queryTrackData(reqList);
    }

    public Object queryTrackData(MsFilterReq req) throws Exception
    {
        return CMsTrackCenter.getMe().queryTrackData(req);
    }

    public boolean isMonitorStarted() throws RemoteException
    {
        return CMsTrackCenter.getMe().isMonitorStarted();
    }

    public MsProviderCmn getProvider(String clusterCenter) throws Exception
    {
        if (CMsEmbMemberService.isRunEmbServer())
        {
            // 传入的cluster是否匹配北方center的ID，来判断是否来自北方
            if (ToolUtilities.isStringEqual(MsEmbConsumer.getInstance().queryCenterInfo().getMachineKey(), clusterCenter))
                return MsEmbProvider.getInstance();
        }
        
        return MsProvider.getInstance();
    }
    
    // 根据传入的clusterCenter，决定是返回上一级、还是本级的消费者
    // 首先当前必须是级联状态，且传入的clusterCenter要等于北方集群主控的机器ID，就会返回上一级集群的consumer，所有的调用都执行到上一级集群里
    // 否则，返回本地集群的消费者，所执行的调用，都在本地集群
    public MsConsumer getConsumer(String clusterCenter) throws Exception
    {
        if (CMsEmbMemberService.isRunEmbServer())
        {
            // 传入的cluster是否匹配北方center的ID，来判断是否来自北方
            if (ToolUtilities.isStringEqual(MsEmbConsumer.getInstance().queryCenterInfo().getMachineKey(), clusterCenter))
                return MsEmbConsumer.getInstance();
        }
        
        return MsMgr.getMe().getConsumer();
    }

    public Object executeService(MicroServiceRequest msReq) throws Exception
    {
        return getProvider(msReq.getCenterMachine()).executeService(msReq);
    }
    
    public MsCacheActionPackage loadActionList(String clusterCenter, long startTime) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().loadActionList(startTime);
    }

    public Pair<Long, Map<String, MsCacheMap>> loadFullCache(String clusterCenter) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().loadFullCache();
    }
    

    public long putCacheValue(String clusterCenter, String cacheKey, String key, Object v) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().putValue(cacheKey, key, v);
    }

    public long putCacheBatch(String clusterCenter, String cacheKey, Map<String, Object> mapValue) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().putBatch(cacheKey, mapValue);
    }

    public long replaceCache(String clusterCenter, String srcCacheKey, String dstCacheKey) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().replaceCache(srcCacheKey, dstCacheKey);
    }

    public long clearCacheValue(String clusterCenter, String cacheKey) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().clearValue(cacheKey);
    }

    public Object deleteCacheValue(String clusterCenter, String cacheKey, String key) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().deleteValue(cacheKey, key);
    }

    public Object getCacheValue(String clusterCenter, String cacheKey, String key) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().getValue(cacheKey, key);
    }

    public Pair<String, Object> findCacheValue(String clusterCenter, String cacheKey, MsCacheFinder finder) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().findValue(cacheKey, finder);
    }

    public Map<String, Object> getCacheAllValue(String clusterCenter, String cacheKey) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().getAllValue(cacheKey);
    }

    public Set<String> getCacheAllKey(String clusterCenter, String cacheKey) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().getAllKey(cacheKey);
    }

    public long deleteCacheBatch(String clusterCenter, String cacheKey, Set<String> key) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().deleteBatch(cacheKey, key);
    }

    public List<Pair<String, Object>> popCacheValue(String clusterCenter, String cacheKey, int count) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().popValue(cacheKey, count);
    }

    public MsFragment createSnapshot(String clusterCenter, int readLength) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().createSnapshot(readLength);
    }

    public MsFragment readSnapshot(String clusterCenter, String tmpFile, int offset, int length) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().readSnapshot(tmpFile, offset, length);
    }

    public MsCacheActionPackage lockAndReleaseLeader(String clusterCenter, long startTime) throws Exception
    {
        return getConsumer(clusterCenter).getCacheServer().lockAndReleaseLeader(startTime);
    }

    public void doFissionSync(String clusterCenter, String sponsorLeader, String srcMachine, List<String> lstFollower) throws Exception
    {
        getConsumer(clusterCenter).getCacheServer().doFissionSync(sponsorLeader, srcMachine, lstFollower);
    }

   
}
