package bap.ms.track;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException.ConnectionLossException;
import org.apache.zookeeper.KeeperException.NoNodeException;
import org.apache.zookeeper.KeeperException.SessionExpiredException;
import org.nutz.dao.Cnd;
import org.nutz.dao.Sqls;
import org.nutz.dao.impl.NutDao;
import org.nutz.dao.impl.NutTxDao;
import org.nutz.dao.impl.SimpleDataSource;
import org.nutz.dao.pager.Pager;
import org.nutz.dao.sql.Sql;
import org.nutz.dao.sql.SqlCallback;
import org.nutz.dao.util.Daos;

import com.leavay.client.util.CmnEvent.CmnRunnable;
import com.leavay.client.util.CmnEvent.EThreadPool;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dfc.microService.MsCenterInfo;
import com.leavay.dfc.microService.MsConst;
import com.leavay.dfc.microService.MsHelper;
import com.leavay.dfc.microService.MsMemberConf;
import com.leavay.dfc.microService.MsMgr;
import com.leavay.dfc.microService.MsZkConst;
import com.leavay.dfc.microService.ZkAgentInfo;
import com.leavay.dfc.microService.ZkTool;
import com.leavay.dfc.microService.bean.AbsMsTrackBean;
import com.leavay.dfc.microService.bean.MsAlarmBean;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.leavay.dfc.microService.bean.MsTrackEndBean;
import com.leavay.dfc.microService.exception.MsTrackCenterOverloadException;
import com.leavay.dfc.microService.exception.MsZookeeperException;
import com.leavay.dfc.microService.track.MsTrackConst;
import com.leavay.dfc.microService.track.MsTrackUtil;
import com.leavay.dfc.microService.track.filter.MsFilterReq;
import com.leavay.dfc.microService.track.filter.MsFilterReqList;
import com.leavay.dfc.microService.track.filter.MsTrackFilter;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;
import com.leavay.nio.crpc.CRpcUtil;
import com.project.gui.common.DBDataSourceIntf;

import bap.ms.CMsCenterService;
import bap.ms.CMsUtil;

// Track Center只能运行在代理上，主要是因为如果在主控上可以当track center，那么如果主控是桥阶机，则无法区分当前到底参与哪个集群的监控
// 所以干脆就只允许Track Center运行在代理上
public class CMsTrackCenter
{
    public final static String LOG = "Ms Track Center";
    
    public final static String SERVICE_MAIN_BUFFER = "SERVICE_MAIN_BUFFER";
    public final static String SERVICE_MAIN_ALARM_BUFFER = "SERVICE_MAIN_ALARM_BUFFER";
    
    static CMsTrackCenter _me;

    public static synchronized CMsTrackCenter getMe()
    {
        if (_me == null)
        {
            _me = new CMsTrackCenter();
        }
        return _me;
    }

    boolean _inited = false;

    String _zkAddr;
    CuratorFramework _zk;

    ZkAgentInfo _agentStaticInfo;
    
    EThreadPool _poolWriteDB = new EThreadPool("Write Mem DB", 1, 20, false);

    public synchronized void initService() throws Exception
    {
        if (_inited)
            return;

        _agentStaticInfo = getMyAgentInfo();

        _zkAddr = getConfZkAddress();
        
        // 这里是有点悖论的，如果都没有zk地址，如何得知主控在哪里，又如何获取主控上的ZK地址？
        // 原来的代理是可以自动通过RMI得知，但是这个不符合现在全微服务的架构，所以改成必须配置ZK地址
        CmnUtil.assertNotEmpty(_zkAddr, "Please config ZK address");

        // 连接ZK
        reconnectZK(_zkAddr);

        // 放弃用内存数据库，太慢了
        // 初始化内存库
//        print("Init Track Mem DB ... ");
//        MsTrackMemDB.openDao().close();
        
        // 初始化持久库
        print("Init Track DB ... ");
        initTrackCenterDB();
        
        // 启动轮询注册线程，不断尝试去抢领导席位
        _mainThread.start();

        print("Regist Track Service On ZK : " + _zkAddr);
        _inited = true;
    }
    
    ReentrantLock _lockConn = new ReentrantLock();
    public void reconnectZK(String zkAddr) throws InterruptedException
    {
        _lockConn.lock();
        try
        {
            if (_zk != null)
            {
                try
                {
                    _zk.close();
                }catch(Throwable err)
                {
                    ToolUtilities.warning(LOG, "Failed to release old ZK", err);
                }
            }
            
            _zk = ZkTool.blockUntilConnect(zkAddr, MsZkConst.DEFAULT_ZK_SESSION_TIMEOUT_MS);
        }finally
        {
            _lockConn.unlock();
        }
    }
    

    public void reconnectZK_NoError(String zkAddr)
    {
        try
        {
            reconnectZK(zkAddr);
        }catch(Throwable err)
        {
            ToolUtilities.error(LOG, "Failed to reconnect ZK : " + zkAddr, err);
        }
    }

    public static boolean isEnableTrackService()
    {
        return MppContext.getBoolean(MsTrackConst.EXT_CONF_ENABLE_TRACK_SERVICE, false);
    }

    public static String getConfZkAddress()
    {
        return MsMemberConf.getZkAddress();
    }

    long _lastClearAlarm = System.currentTimeMillis();
    final static long ALARM_CLEAR_INTERVAL = 60*60000; // 每小时清理一次垃圾告警
    final static int ALARM_KEEP_COUNT = 1000000; // 保留100W笔告警数据
    Thread _mainThread = new Thread("Ms Track Center Main Thread")
    {
        public void run()
        {
            while (true)
            {
                // 尝试获取zk一点信息，如果断连，会自动尝试重连
                // 并且会报告警
                maintainZkHealth();
                
                try
                {
                    tryTakeLeadership();
                } catch(ConnectionLossException connErr)
                {
                    reconnectZK_NoError(_zkAddr);
                    reportCenterAlarm(MsAlarmBean.LEVEL_ERROR_CRITICAL, connErr);
                } catch (SessionExpiredException sessErr)
                {
                    reconnectZK_NoError(_zkAddr);
                    reportCenterAlarm(MsAlarmBean.LEVEL_WARN, sessErr);
                }
                catch (Throwable err)
                {
                    ToolUtilities.error(LOG, err);
                    reportCenterAlarm(MsAlarmBean.LEVEL_ERROR_CRITICAL, err);
                }

                if (System.currentTimeMillis() - _lastClearAlarm > ALARM_CLEAR_INTERVAL)
                {
                    try
                    {
                        clearExpiredAlarm(ALARM_KEEP_COUNT);
                    } catch (Throwable exp)
                    {
                        ToolUtilities.error(LOG, "Failed to clear expired alarm data", exp);
                    }
                    _lastClearAlarm = System.currentTimeMillis();
                }
                
//                try
//                {
//                    clearExpiredTrackData(MsTrackUtil.getDCacheTrackLimit());
//                }catch (Throwable err)
//                {
//                    ToolUtilities.error(LOG, err);
//                }
                
                ToolUtilities.sleep_IgnoreInterrupt(5000);
            }
        }
    };

    volatile static boolean _isLeader = false;
    protected void setIsLeader(boolean isLeader)
    {
        boolean firstLead = isLeader && !_isLeader;
        _isLeader = isLeader;
        
        // 默认启动监控，并以之前的启动周期为准（如果没有则以默认值）
        if (isLeader && !isMonitorStarted())
        {
            startMonitor(MsTrackUtil.getTrackCenterPeriodic());
        }
    }

    public static boolean isLeader()
    {
        return _isLeader;
    }

    volatile boolean _debug = false;
    public void setDebug(boolean debug)
    {
        _debug = debug;
    }
    
    public boolean isDebug()
    {
        return _debug;
    }
    
    volatile boolean _monitorStarted = false;
    public boolean isMonitorStarted()
    {
        return _monitorStarted;
    }
    
    Thread _moniThread;
    public synchronized void startMonitor(final long interval)
    {
        stopMonitor();

        _moniThread = new Thread()
        {
            public void run()
            {
                MsTrackUtil.setCenterStarted(true, interval);
                _monitorStarted = true;

                boolean firstTimeStart = true;
                try
                {
                    while (true)
                    {
                        try
                        {
                            renewAllFilter(firstTimeStart);
                            firstTimeStart=false;
                        } catch (Throwable err)
                        {
                            ToolUtilities.error(LOG, err);
                        }
                        
                        sleep(interval);
                    }
                } catch(InterruptedException intExp)
                {
                    return;
                }
                finally
                {
                    _monitorStarted = false;

                    MsTrackUtil.setCenterStarted(false, interval);
                }
            }
        };
        _moniThread.start();
    }
    
    
    public Map<String, Object> queryTrackData(MsFilterReqList reqList)
    {
        Map<String, Object> ret = new HashMap();
        List<MsTrackFilter> lstFilter = getFilters();
        for (MsFilterReq req : reqList)
        {
            if (SERVICE_MAIN_BUFFER.equals(req.getServiceId()))
                ret.put(SERVICE_MAIN_BUFFER, getTotalBufferSize());
            else if (SERVICE_MAIN_ALARM_BUFFER.equals(req.getServiceId()))
                ret.put(SERVICE_MAIN_ALARM_BUFFER, getAlarmSavingBufferSize());
            else
            {
                for (MsTrackFilter f : lstFilter)
                {
                    Object o = f.queryData(req.getServiceId(), req.getParam());
                    if (o != null)
                    {
                        ret.put(req.getServiceId(), o);
                        break;
                    }
                }
            }
        }
        
        return ret;
    }

    public Object queryTrackData(MsFilterReq req)
    {
        List<MsTrackFilter> lstFilter = getFilters();
        for (MsTrackFilter f : lstFilter)
        {
            Object o = f.queryData(req.getServiceId(), req.getParam());
            if (o != null)
            {
                return o;
            }
        }
        
        return null;
    }
    

    public synchronized void stopMonitor()
    {
        if (_moniThread != null)
        {
            _moniThread.interrupt();
            _moniThread = null;
        }
    }
    
    public ZkAgentInfo getMyAgentInfo() throws Exception
    {
        ZkAgentInfo info = new ZkAgentInfo();
        info.setAgentID(MsHelper.getMyMachineID());
        info.setName(MsHelper.getMyMachineID());

        info.setServerProcess(MsHelper.isCenter());
        info.setRegistAddr(MsHelper.getRegistAddress());
        info.setServerProcess(MsHelper.isCenter());
        info.setAddrList(ToolUtilities.array2List(ToolUtilities.getCurrentIPList()));
        info.setNioPort(CMsUtil.getNioPort());

        info.setProcessID(ToolBasic.getProcessID());
        info.setProcStartTime(ToolBasic.getProcessStartTime());
        
        return info;
    }
    
    public void tryTakeLeadership() throws Exception
    {
        InterProcessMutex lock = new InterProcessMutex(_zk, MsZkConst.PATH_TRACK_LEADER_LOCK);
        lock.acquire();
        try
        {
            if (!isLeader())
                print("Try to take MS Track leader position ... ");
            
            // 判断当前leader是否自己
            boolean hasLeader = false;
            try
            {
                String existJson = new String(_zk.getData().forPath(MsZkConst.PATH_TRACK_CENTER_LEADER));
                ZkAgentInfo existLeader = ZkAgentInfo.fromJson(existJson);
                if (ToolUtilities.isStringEmpty(existJson) || existLeader == null)
                {
                    hasLeader = false;
                } else
                {
                    hasLeader = true;

                    // 判断leader是否自己
                    boolean isMe = ToolUtilities.isStringEqual(existLeader.getAgentID(), MsHelper.getMyMachineID());
                    setIsLeader(isMe);
                    
                    if (!isMe && isDebug())
                        ToolUtilities.info(LOG, "There is other leader : " + existLeader.toString());
                }
            } catch (NoNodeException noNode)
            {
                hasLeader = false;
            } catch (Exception otherExp)
            {
                ToolUtilities.error(LOG, otherExp);
            }
            
            // 没有leader则自己抢占
            if (!hasLeader)
            {
                // 没有合法Leader，则自己抢占
                ToolUtilities.info(LOG, "Take MS Track leader position ........ ");
                _zk.create().creatingParentsIfNeeded().withMode(CreateMode.EPHEMERAL).forPath(MsZkConst.PATH_TRACK_CENTER_LEADER, _agentStaticInfo.toJson().getBytes());
                setIsLeader(true);
                print("Take MS Track leader position successfully!! ");
            }
        } finally
        {
            lock.release();
        }
    }
    
    public void maintainZkHealth()
    {
        try
        {
            _zk.checkExists().forPath(MsZkConst.PATH_LEAVAY_ROOT);
        } catch(ConnectionLossException connErr)
        {
            ToolUtilities.error(LOG, "Lost ZK connection", connErr);
            reportCenterAlarm(MsAlarmBean.LEVEL_ERROR_CRITICAL, new MsZookeeperException("Failed to check zookeeper health", connErr));
            reconnectZK_NoError(_zkAddr);
        } catch (SessionExpiredException sessErr)
        {
            ToolUtilities.error(LOG, "ZK session is expired", sessErr);
            reportCenterAlarm(MsAlarmBean.LEVEL_WARN, sessErr);
            reconnectZK_NoError(_zkAddr);
        }
        catch (Throwable err)
        {
            ToolUtilities.error(LOG, "ZK connection has some problem", err);
            reportCenterAlarm(MsAlarmBean.LEVEL_ERROR_CRITICAL, new MsZookeeperException("Failed to check zookeeper health", err));
            ToolUtilities.error(LOG, err);
        }
    }
    
    public void print(String s)
    {
        System.out.println(s);
        ToolUtilities.info(LOG, s);
    }
    
    NutTxDao _persisConn;
    protected void initTrackCenterDB() throws Exception
    {
//        IConnectDB conn = new IConnectDB();
//        conn.connectDB(_dbDriver, _dbUrl, _dbUser, "");
        
        // 初始化连接（就会初始化库）
        NutDao dao = prepareCenterDao();
        _persisConn = new NutTxDao(dao);
        _persisConn.beginRC();

        //  创建一个NutDao实例,在真实项目中, NutDao通常由ioc托管, 使用注入的方式获得.
//        dao.create(MsTrackBean.class, false); // false的含义是,如果表已经存在,就不要删除重建了.
//        Daos.migration(dao, MsTrackBean.class, true, true); // 自动迁移表结构
//        
//        dao.create(MsTrackEndBean.class, false); // false的含义是,如果表已经存在,就不要删除重建了.
//        Daos.migration(dao, MsTrackEndBean.class, true, true); // 自动迁移表结构
        
        // 初始化告警表
        dao.create(MsAlarmBean.class, false);
        Daos.migration(dao, MsAlarmBean.class, true, true); // 自动迁移表结构
        
        _persisConn.commit();
        print("Finish init track center DB : " + _persisConn);
    }

    CRpcClientWrapper<CMsCenterService> _centWrap = new CRpcClientWrapper<CMsCenterService>(CMsCenterService.class)
    {
        public CRpcAdapter getAdapter()
        {
            return CRpcAdapter.getInstance();
        }
    };
    
    public CMsCenterService openCenterIntf() throws Exception
    {
        try
        {
            MsCenterInfo centInfo = MsMgr.getMe().getConsumer().queryCenterInfo();
            if (centInfo == null)
                throw new Exception("There isn't valid MS Center info on zk");
            
            return _centWrap.init(centInfo.getHost(), centInfo.getPort()).getIntf();
        }catch (Throwable err)
        {
            //如果通过ZK拿出问题，则尝试通过配置文件找主控
            return CRpcAdapter.getInstance().openService(CMsUtil.getConfCenterAddress(), CMsUtil.getConfCenterPort(), CMsCenterService.class, CRpcUtil.getConnectTimeoutMs());
        }
    }
    
    static SimpleDataSource _ds = null;
    static NutDao _dao = null;
    protected synchronized NutDao prepareCenterDao()
    {
        if (_ds == null || _dao == null)
        {
            if (_ds != null)
                _ds.close();

            try
            {
                print("Init track center DB");
                _ds = new SimpleDataSource();
                DBDataSourceIntf cDs = openCenterIntf().getTrackDB();
                if (cDs == null)
                    throw new Exception("Failed to get track DB info from center. Please config on MS center first.");

                _ds.setDriverClassName(cDs.getDriverClass());
                _ds.setUrl(cDs.getUrl());
                _ds.setUsername(cDs.getUserName());
                _ds.setPassword(cDs.getPassword());
            } catch (Exception exp)
            {
                ToolUtilities.throwRuntimeException(exp);
            }

            _dao = new NutDao(_ds);
        }

        return _dao;
    }

    // 内存库比较特殊，长连接不能释放
    public NutTxDao getDao()
    {
        NutTxDao dao = new NutTxDao(prepareCenterDao());
        dao.beginRC();
        return dao;
//        return _persisConn;
    }
    
    public void releaseDao(NutTxDao dao)
    {
        if (dao != null)
            dao.close();
    }

    AtomicLong _DeadTime = new AtomicLong(-1);
    public void clearExpiredTrackData(int keepRows) throws Exception
    {
//        NutTxDao dao = getDao();
//        try
//        {
//            List<MsTrackBean> limitBean = dao.query(MsTrackBean.class, Cnd.orderBy().desc(MsTrackBean._StartTime), new Pager(keepRows + 1, 1));
//            if (ToolUtilities.isObjectEmpty(limitBean))
//                return;
//
//            // 删掉超过数量的记录
//            long deadTime = limitBean.get(0).getStartTime();
//            _DeadTime.set(deadTime);
//
//            // 首先删除队列中的超期任务，从前往后找，因为后来的都是插到队列头的
//            ArrayList<CmnRunnable> lstRunn = _poolWriteDB.getWaitingRunnable();
//            CmnRunnable expiredRunn = null;
//            for (CmnRunnable o : lstRunn)
//            {
//                WriteMemRunn runn = (WriteMemRunn) o;
//                AbsMsTrackBean lastBean = runn.getLastestBean();
//                if (lastBean.getTime() <= deadTime)
//                {
//                    expiredRunn = runn;
//                    break;
//                }
//            }
//
//            if (expiredRunn != null)
//            {
//                List<CmnRunnable> lstExpireRunn = _poolWriteDB.removeFromRunnable(expiredRunn.getKey());
//                if (!ToolUtilities.isObjectEmpty(lstExpireRunn))
//                {
//                    WriteMemRunn run1 = (WriteMemRunn) lstExpireRunn.get(0);
//                    WriteMemRunn run2 = (WriteMemRunn) lstExpireRunn.get(lstExpireRunn.size() - 1);
//
//                    String warn = "Clear expired waiting task : " + ToolUtilities.getObjectSize(lstExpireRunn) + ", " + ToolUtilities.time2String(run1.getLastestBean().getTime()) + " --->> "
//                            + ToolUtilities.time2String(run2.getLastestBean().getTime());
//                    System.out.println(warn);
//                    ToolUtilities.warning(LOG, warn);
//                }
//            }
//
//            // 删掉内存库中的超期任务
//            int cnt = dao.clear(MsTrackBean.class, Cnd.where(MsTrackBean._StartTime, "<=", deadTime));
//            ToolUtilities.info(LOG, "Clear micro service track begin data : " + cnt + "rows, from = " + ToolUtilities.time2String(limitBean.get(0).getStartTime(), true));
//            dao.commit();
//
//            cnt = dao.clear(MsTrackEndBean.class, Cnd.where(MsTrackEndBean._EndTime, "<=", deadTime));
//            ToolUtilities.info(LOG, "Clear micro service track end data : " + cnt + "rows, from = " + ToolUtilities.time2String(limitBean.get(0).getStartTime(), true));
//            dao.commit();
//        }finally
//        {
//            releaseDao(dao);
//        }
    }

    public static CMsTrackCenter getHealthyCenter()
    {
        if (!isEnableTrackService())
            throw new RuntimeException("This agent is not track center");
        
        if (!isLeader())
            throw new RuntimeException("This agent is not leader of track center");
        
        return getMe();
    }
    
    public int queryTrackCount()
    {
        NutTxDao dao = getDao();
        try
        {
            return dao.count(MsTrackBean.class);
        }finally
        {
            releaseDao(dao);
        }
    }
    
    public MultiPageResult<MsTrackBean> queryTrack(boolean getCount, int startPos, int pageSize) throws Exception
    {
        NutTxDao dao = getDao();
        try
        {
            final List list = new ArrayList();
            // Sql sql = Sqls.create("select * from ms_track_start_bean");
            Sql sql = Sqls.create("select a.*,b.* from ms_track_start_bean a left join ms_track_end_bean b on a.myID = b.myID order by a.startTime desc limit 10");
            sql.setCallback(new SqlCallback()
            {
                public Object invoke(Connection conn, ResultSet rs, Sql sql) throws SQLException
                {
                    List lstRet = new ArrayList();
                    while (rs.next())
                    {
                        MsTrackBean m = dao.getEntity(MsTrackBean.class).getObject(rs, null);
                        long endTime = rs.getLong("endTime");
                        lstRet.add(m);
                    }
                    return lstRet;
                }
            });
            sql = dao.execute(sql);
            List<MsTrackBean> listRs = sql.getList(MsTrackBean.class);
            MultiPageResult<MsTrackBean> res = new MultiPageResult();
            res.setTotalCount(listRs.size());
            res.setListData(listRs);
            return res;
        } finally
        {
            releaseDao(dao);
        }
    }
    
    public void reportOverloadAlarm(int ignoreCount)
    {
        reportCenterAlarm(MsAlarmBean.LEVEL_ERROR_CRITICAL, new MsTrackCenterOverloadException("Track center buffer was overload. More than "+ignoreCount+" events will be ignored."));
    }

    public void saveTrack(List<AbsMsTrackBean> lstData)
    {
        if (!isMonitorStarted())
            return;
        
        // 检查是否积压过多，如若则需报告警并抛弃
        long safeCount = MsConst.getMainBufferSafeSize();
        if (_lazySavePool.getSize() > safeCount)
        {
            reportOverloadAlarm(lstData.size());
        }else
            _lazySavePool.add(lstData);
    }
    
    public int getTotalBufferSize()
    {
        return _lazySavePool.getSize();
    }
    
    public int getAlarmSavingBufferSize()
    {
        return _lazySaveAlarm.getSize();
    }
    
    protected volatile boolean _recordeAllEvents = false;
    LazyPool<List<AbsMsTrackBean>> _lazySavePool = new LazyPool<List<AbsMsTrackBean>>(1)
    {
        public void handle(List<List<AbsMsTrackBean>> objects)
        {
            for (List<AbsMsTrackBean> lstData : objects)
            {
                try
                {
                    //用于排查问题
                    if (_recordeAllEvents)
                    {
                        Set<String> msg = new HashSet();
                        for (AbsMsTrackBean bean : lstData)
                        {
                            if (bean instanceof MsTrackEndBean)
                                msg.add(bean.getMyID() + "=END");
                            else if (bean instanceof MsAlarmBean)
                                if (!ToolUtilities.isStringEmpty(bean.getMyID()))
                                    msg.add(bean.getMyID() + "=ALARM");
                        }
                        ToolUtilities.info("Recieved Data : " + ToolUtilities.logString(msg, false));
                    }
                    
                    doSaveTrack(lstData);
                } catch (Throwable exp)
                {
                    ToolUtilities.error(LOG, exp);
                }
            }
        }
    };
    
    public void doSaveTrack(List<AbsMsTrackBean> lstData) throws Exception
    {
        if (!isMonitorStarted())
            return;
        
        List<MsTrackFilter> lstFilter = getFilters();
        if (ToolUtilities.isObjectEmpty(lstFilter))
            return;
        
        for (AbsMsTrackBean bean : lstData)
        {
            for (MsTrackFilter f : lstFilter)
            {
                Object o = f.filter(bean);
                if (o == null)
                    break;
            }
        }
    }
    
    List<MsTrackFilter> _lstFilter = null;
    public synchronized List<MsTrackFilter> getTrackFilter()
    {
        if (_lstFilter == null)
        {
            _lstFilter = new ArrayList();
            _lstFilter.add(new CMsFilter_Main());
            _lstFilter.add(new CMsFilter_Error());
            _lstFilter.add(new CMsFilter_StasticService());
            _lstFilter.add(new CMsFilter_Finish());
        }
        return _lstFilter;
    }
    
    public List<MsTrackFilter> getFilters()
    {
        return getTrackFilter();
    }
    
    public CMsFilter_Main getMainFilter()
    {
        return (CMsFilter_Main) getFileterByName(CMsFilter_Main.class);
    }
    
    public MsTrackFilter getFileterByName(Class clazz)
    {
        for (MsTrackFilter f : getFilters())
            if (f.getClass().equals(clazz))
                return f;
        
        return null;
    }
    
    public void renewAllFilter(boolean firstStartMonitor)
    {
        List<MsTrackFilter> lstFilter = getFilters();
        if (lstFilter != null)
            for (MsTrackFilter f : lstFilter)
                f.renew(firstStartMonitor);
    }
    
    public void saveTrackToDB(List<AbsMsTrackBean> lstData)
    {
        WriteMemRunn writer = new WriteMemRunn(lstData);
        _poolWriteDB.runToHead(writer);
    }
    
    public void setThreadPoolSize(int size)
    {
        _poolWriteDB.setMax(size);
    }
    
    class WriteMemRunn extends CmnRunnable
    {
        List<AbsMsTrackBean> _lstData;
        public WriteMemRunn(List<AbsMsTrackBean> lstData)
        {
            super();
            _lstData = lstData;
        }

        public void run()
        {
            try
            {
                doSaveTrack(_lstData);
            } catch (Exception exp)
            {
                ToolUtilities.error(LOG, exp);
            }
        }
        
        public AbsMsTrackBean getLastestBean()
        {
            return ToolUtilities.isObjectEmpty(_lstData)?null:_lstData.get(_lstData.size()-1);
        }
    }

    public void reportCenterAlarm(int level, Throwable err)
    {
        MsAlarmBean alarm = new MsAlarmBean();
        alarm.setSrcAgent(MsHelper.getMyMachineID());
        alarm.setDstAgent(alarm.getSrcAgent());
        alarm.setAlarmTime(System.currentTimeMillis());
        alarm.setLevel(level);
        alarm.setException(err);
        
        saveAlarm(alarm);
    }
    
    public void saveAlarm(MsAlarmBean alarm)
    {
        // 超过堆积门限，就抛弃
        if (_lazySaveAlarm.getSize() > MsConst.getAlarmBufferSafeSize())
            return;

        // 如果没有指定目标代理的，统统以源代理为准（例如分配失败的异常，目标代理不存在而恰好源代理正是发生故障的地方）
        if (alarm.getDstAgent() == null)
            alarm.setDstAgent(alarm.getSrcAgent());
        
        _lazySaveAlarm.add(alarm);
    }
    
    LazyPool<MsAlarmBean> _lazySaveAlarm = new LazyPool<MsAlarmBean>(100)
    {
        public void handle(List<MsAlarmBean> lstData)
        {
            try
            {
                doSaveAlarm(lstData);
            } catch (Throwable exp)
            {
                ToolUtilities.error(LOG, exp);
            }
        }
    };
    
    public void doSaveAlarm(List<MsAlarmBean> lstData) throws Exception
    {
        NutTxDao dao = getDao();
        try
        {
            List lstBatch = new ArrayList();
            for (MsAlarmBean bean : lstData)
            {
                lstBatch.add(bean);
                if (lstBatch.size() >= 1000)
                {
                    dao.insert(lstBatch);
                    dao.commit();
                    lstBatch.clear();
                }
            }

            if (!lstBatch.isEmpty())
                dao.insert(lstBatch);
            dao.commit();
        } finally
        {
            dao.close();
        }
    }
    
    public void clearExpiredAlarm(int keepRows) throws Exception
    {
        NutTxDao dao = getDao();
        try
        {
            List<MsAlarmBean> limitBean = dao.query(MsAlarmBean.class, Cnd.orderBy().desc(MsAlarmBean._alarmTime), new Pager(keepRows + 1, 1));
            if (ToolUtilities.isObjectEmpty(limitBean))
                return;

            // 删掉超过数量的记录
            long deadTime = limitBean.get(0).getAlarmTime();

            // 删掉库中的超期Alarm
            int cnt = dao.clear(MsAlarmBean.class, Cnd.where(MsAlarmBean._alarmTime, "<=", deadTime));
            ToolUtilities.info(LOG, "Clear alarm begin data : " + cnt + "rows, from = " + ToolUtilities.time2String(deadTime, true));
            dao.commit();
        }finally
        {
            releaseDao(dao);
        }
    }
}
