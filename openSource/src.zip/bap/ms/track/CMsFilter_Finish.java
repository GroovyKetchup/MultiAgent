package bap.ms.track;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.microService.MsConst;
import com.leavay.dfc.microService.bean.AbsMsTrackBean;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.leavay.dfc.microService.bean.MsTrackEndBean;
import com.leavay.dfc.microService.track.MsTrackPlugin;
import com.leavay.dfc.microService.track.filter.MsFilterBasic;
import com.leavay.dfc.microService.track.filter.MsTrackFilter;

public class CMsFilter_Finish extends MsFilterBasic<AbsMsTrackBean>
{
    private static final long serialVersionUID = 2146235955510835913L;
    
    public final static String SERVICE_FINISH_BUFFER = "SERVICE_FINISH_LOADING"; // param0 : String(session myID)
    
    // 这个当前running比较特殊，是要一直保留的，切换周期也不清除的
    // 只有在启动监控的时候，才会被清理掉
    ReentrantLock _lockData;
    List<MsTrackBean> _cacheFinished;
    int _keepFinishCount = 100000;
    HashMap<String, Long> _mapRubbishEnd;
    
    public CMsFilter_Finish()
    {
        super();
        _lockData = new ReentrantLock();
    }
    
    public void initOnStart()
    {
        _lockData.lock();
        try
        {
            _cacheFinished = new LinkedList();
            _mapRubbishEnd = new HashMap();
        } finally
        {
            _lockData.unlock();
        }
    }
    
    public void initPeriodicData()
    {
    }
    
    public void clearPeriodicData()
    {
    }
    
    public MsTrackFilter<AbsMsTrackBean> clone()
    {
        CMsFilter_Finish f = new CMsFilter_Finish();

        return f;
    }
    
    public int getKeepFinishCount()
    {
        return _keepFinishCount;
    }

    public void setKeepFinishCount(int keepFinishCount)
    {
        this._keepFinishCount = keepFinishCount;
    }

    protected void pushFinishBean(MsTrackBean bean)
    {
        _cacheFinished.add(bean);
        while (_cacheFinished.size() > getKeepFinishCount())
        {
            _cacheFinished.remove(0);
        }
        
        MsTrackPlugin.getPlugin().OnTrackFinished(bean);
    }

    public String toString()
    {
        if (isHistory())
            return  "Finished : " + _cacheFinished.size() ;
        else
            return "Cached Finished : " + _cacheFinished.size() + ", History : "+ToolUtilities.logString(getHistory(), false);
    }

    public int getHistoryLimit()
    {
        return 0;
    }

    public Object queryData(String serviceId, Object... param)
    {
        switch(serviceId)
        {
        case SERVICE_FINISH_BUFFER:
            return getLazySize();
        }
        return null;
    }

    CMsFilter_Main _mainFilter;
    public synchronized CMsFilter_Main getMainFilter()
    {
        if (_mainFilter == null)
        {
            _mainFilter = CMsTrackCenter.getMe().getMainFilter();
        }
        return _mainFilter;
    }
    
    public void doLazyFilter(AbsMsTrackBean bean)
    {
        if (!(bean instanceof MsTrackEndBean))
            return;

        _lockData.lock();
        try
        {
            MsTrackBean finishBean = getMainFilter().removeRunning(bean.getMyID());
            if (finishBean == null)
            {
                long nowTime = System.currentTimeMillis();
                Long firstTime = _mapRubbishEnd.get(bean.getMyID());
                if (firstTime == null)
                {
                    firstTime = nowTime;
                    _mapRubbishEnd.put(bean.getMyID(), firstTime);
                    fireLazyFilter(bean); // 没找到开始消息，重新扔回队列尾
                } else
                {
                    // 如果没超期，则丢到队尾等待下次处理，反之则抛弃
                    if (nowTime - firstTime < (MsConst.getRubbishEndTimeout()*1000))
                        fireLazyFilter(bean); // 还没超时，继续扔回队列尾
                    else
                    {
                        // 超期抛弃，记得要删除垃圾
                        _mapRubbishEnd.remove(bean.getMyID());
                    }
                }
            } else
            {
                // 成功匹配上了，记得要删除垃圾
                _mapRubbishEnd.remove(bean.getMyID());
                
                finishBean.writeEndData((MsTrackEndBean) bean);
                pushFinishBean(finishBean);
            }
        } finally
        {
            _lockData.unlock();
        }

    }

    public AbsMsTrackBean doFilter(AbsMsTrackBean bean)
    {
        return bean;
    }
}
