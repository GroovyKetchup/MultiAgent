package bap.ms.track;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.microService.MsConst;
import com.leavay.dfc.microService.bean.AbsMsTrackBean;
import com.leavay.dfc.microService.bean.MsAlarmBean;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.leavay.dfc.microService.bean.MsTrackErrorBean;
import com.leavay.dfc.microService.exception.MsWaitEndTimeoutException;
import com.leavay.dfc.microService.track.MsTrackPlugin;
import com.leavay.dfc.microService.track.filter.MsFilterBasic;
import com.leavay.dfc.microService.track.filter.MsFilterTag;
import com.leavay.dfc.microService.track.filter.MsTrackFilter;

public class CMsFilter_Error extends MsFilterBasic<AbsMsTrackBean>
{
    private static final long serialVersionUID = 2146235955510835913L;

    public final static String SERVICE_ERROR_BUFFER = "SERVICE_ERROR_BUFFER"; // param0 : String(session myID)
    public final static String SERVICE_ERROR_QUERY_ALL = "SERVICE_ERROR_QUERY_ALL"; // param0 : int(count)
    public final static String SERVICE_ERROR_QUERY_STASTIC = "SERVICE_ERROR_QUERY_STASTIC"; // param0 : int(count)
    
    // 这个当前running比较特殊，是要一直保留的，切换周期也不清除的
    // 只有在启动监控的时候，才会被清理掉
    ReentrantLock _lockData;
    int _errorCount = 0;
    HashMap<String, Long> _mapRubbishEnd;
    
    public CMsFilter_Error()
    {
        super();
        _lockData = new ReentrantLock();
    }
    
    public void initOnStart()
    {
        _lockData.lock();
        try
        {
            _mapRubbishEnd = new HashMap();
        } finally
        {
            _lockData.unlock();
        }
    }
    
    public void initPeriodicData()
    {
        _lockData.lock();
        try
        {
            _errorCount = 0;
        } finally
        {
            _lockData.unlock();
        }
    }
    
    public void clearPeriodicData()
    {
        _lockData.lock();
        try
        {
            _errorCount = 0;
        } finally
        {
            _lockData.unlock();
        }
    }
    
    public MsTrackFilter<AbsMsTrackBean> clone()
    {
        CMsFilter_Error f = new CMsFilter_Error();
        f._errorCount = _errorCount;

        return f;
    }
    
    protected void pushFinishBean(MsTrackBean bean, MsTrackErrorBean error)
    {
        _lockData.lock();
        try
        {
            _errorCount++;
        }finally
        {
            _lockData.unlock();
        }
        
        // 存入告警库
        MsAlarmBean alarm = convertAlarm(bean, error);
        CMsTrackCenter.getMe().saveAlarm(alarm);
        
        // 通知外部插件
        MsTrackPlugin.getPlugin().OnRaiseAlarm(alarm);
    }
    
    public MsAlarmBean convertAlarm(MsTrackBean reqTrack,  MsTrackErrorBean error)
    {
        MsAlarmBean alarm = reqTrack.convertAlarm(error);
        alarm.setPeriodicTag(getPeriodicTag().getTag());
        return alarm;
    }
    
    LazyPool _lazyCleanRunning = new LazyPool(1000)
    {
        public void handle(List objects)
        {
            doCleanRubbishRunning();
        }
    };
    
    public void doCleanRubbishRunning()
    {
        boolean hasRubbish = false;
        CMsFilter_Main mainFilter = CMsTrackCenter.getMe().getMainFilter();
        do
        {
            hasRubbish = false;
            List<MsTrackBean> lstEarlyRunning = mainFilter.queryRunning(5);
            
            long timeout = MsConst.getCleanRubbishPendingTimeout()*1000;
            long time = System.currentTimeMillis();
            for (MsTrackBean bean : lstEarlyRunning)
            {
                if (time - bean.getStartTime() > timeout)
                {
                    // 发现超时垃圾
                    hasRubbish = true;
                    
                    // 移除Running
                    mainFilter.removeRunning(bean.getMyID());
                    
                    // 生成模拟异常，产生告警
                    MsTrackErrorBean simError = MsTrackErrorBean.newErrorBean(bean, new MsWaitEndTimeoutException("Time out to wait for end signal more than "+ (timeout/1000) + "s"));
                    simError.setLevel(MsAlarmBean.LEVEL_WARN);
                    
                    pushFinishBean(bean, simError);
                }
            }
            
            if (hasRubbish)
                ToolUtilities.sleep(1);
        }while (hasRubbish);
    }

    public String toString()
    {
        return "Error : " + getCount();
    }

    public int getHistoryLimit()
    {
        return 10;
    }

    public Object queryData(String serviceId, Object... param)
    {
        switch(serviceId)
        {
        case SERVICE_ERROR_BUFFER:
            return getLazySize();
        case SERVICE_ERROR_QUERY_STASTIC:
            return queryErrorStastic();
        }
        return null;
    }

    public int getCount()
    {
        _lockData.lock();
        try
        {
            return _errorCount;
        } finally
        {
            _lockData.unlock();
        }
    }
    
    public LinkedHashMap<MsFilterTag, Integer> queryErrorStastic()
    {
        LinkedHashMap<MsFilterTag, Integer> mapSts = new LinkedHashMap();
        
        // 压入历史的
        List<CMsFilter_Error> lstHis = (List)getHistory();
        if (lstHis != null)
            for (CMsFilter_Error f : lstHis)
                mapSts.put(f.getPeriodicTag(), f.getCount());
        
        // 压入当前的
        mapSts.put(getPeriodicTag(), getCount());
        return mapSts;
    }
    
    CMsFilter_Main _mainFilter;
    public synchronized CMsFilter_Main getMainFilter()
    {
        if (_mainFilter == null)
        {
            _mainFilter = CMsTrackCenter.getMe().getMainFilter();
        }
        return _mainFilter;
    }
    
    public void doLazyFilter(AbsMsTrackBean bean)
    {
        // 触发清理超时垃圾
        _lazyCleanRunning.add(ToolUtilities.NULL_OBJECT);

        if (!(bean instanceof MsTrackErrorBean))
            return;

        _lockData.lock();
        try
        {
            MsTrackBean runningBean = getMainFilter().removeRunning(bean.getMyID());
            if (runningBean == null)
            {
                long nowTime = System.currentTimeMillis();
                Long firstTime = _mapRubbishEnd.get(bean.getMyID());
                if (firstTime == null)
                {
                    firstTime = nowTime;
                    _mapRubbishEnd.put(bean.getMyID(), firstTime);
                    fireLazyFilter(bean); // 没找到开始消息，重新扔回队列尾
                } else
                {
                    // 如果没超期，则丢到队尾等待下次处理，反之则抛弃
                    if (nowTime - firstTime < (MsConst.getRubbishEndTimeout()*1000))
                        fireLazyFilter(bean); // 还没超时，继续扔回队列尾
                    else
                    {
                        // 超期抛弃，记得要删除垃圾
                        _mapRubbishEnd.remove(bean.getMyID());
                    }
                }
            } else
            {
                // 成功匹配上了，记得要删除垃圾
                _mapRubbishEnd.remove(bean.getMyID());
                pushFinishBean(runningBean, (MsTrackErrorBean) bean);
            }
        } finally
        {
            _lockData.unlock();
        }
    }

    /**
     * 返回NULL：不给后续的Filter处理了，在这一步就拦截了（但不会影响自身的doLazyFilter处理）
     */
    public AbsMsTrackBean doFilter(AbsMsTrackBean bean)
    {
        // 告警直接截留
        if (bean instanceof MsAlarmBean)
        {
            MsAlarmBean alarm = (MsAlarmBean)bean;
            alarm.setPeriodicTag(getPeriodicTag().getTag());
            CMsTrackCenter.getMe().saveAlarm(alarm);
            return null;
        }
        
        // error的需要拦截下来，以免影响后续处理Finish
        if (bean instanceof MsTrackErrorBean)
            return null;
        
        return bean;
    }
}
