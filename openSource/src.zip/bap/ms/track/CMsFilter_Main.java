package bap.ms.track;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.locks.ReentrantLock;

import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.microService.bean.AbsMsTrackBean;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.leavay.dfc.microService.track.MsTrackPlugin;
import com.leavay.dfc.microService.track.filter.MsFilterBasic;
import com.leavay.dfc.microService.track.filter.MsTrackFilter;

public class CMsFilter_Main extends MsFilterBasic<AbsMsTrackBean>
{
    private static final long serialVersionUID = 2146235955510835913L;
    
    public final static long TIMEOUT_RUBBISH_END = 60000; // 垃圾结束信号（找不到开始信号的），超过多少ms后就抛弃

    public final static String SERVICE_RUNNING_BUFFER = "SERVICE_RUNNING_BUFFER"; // param0 : String(session myID)
    public final static String SERVICE_MAIN_HISTORY = "SERVICE_MAIN_HISTORY";
    public final static String SERVICE_MAIN_ALL_RUNNING = "SERVICE_MAIN_ALL_RUNNING";
    public final static String SERVICE_MAIN_TOP_RUNNING = "SERVICE_MAIN_TOP_RUNNING"; // param0 : int(limit)
    
    public final static String SERVICE_MAIN_GET_BEAN = "SERVICE_MAIN_GET_BEAN"; // param0 : String(session myID)
    
    // 这个当前running比较特殊，是要一直保留的，切换周期也不清除的
    // 只有在启动监控的时候，才会被清理掉
    ReentrantLock _lockData;
    LinkedHashMap<String, MsTrackBean> _cacheRunning;
    
    public CMsFilter_Main()
    {
        super();
        _lockData = new ReentrantLock();
    }
    
    public void initOnStart()
    {
        _lockData.lock();
        try
        {
            _cacheRunning = new LinkedHashMap();
        } finally
        {
            _lockData.unlock();
        }
    }
    
    public void initPeriodicData()
    {
    }
    
    public void clearPeriodicData()
    {
    }
    
    public MsTrackBean getRunning(String id)
    {
        _lockData.lock();
        try
        {
            return _cacheRunning.get(id);
        } finally
        {
            _lockData.unlock();
        }
    }
    
    public MsTrackBean removeRunning(String id)
    {
        _lockData.lock();
        try
        {
            return _cacheRunning.remove(id);
        } finally
        {
            _lockData.unlock();
        }
    }
    
    public MsTrackFilter<AbsMsTrackBean> clone()
    {
        CMsFilter_Main f = new CMsFilter_Main();
//        f._lstFinishBean = _lstFinishBean;

        return f;
    }
    
    public List<MsTrackBean> queryRunning(int limit)
    {
        LinkedList<MsTrackBean> lstSort = new LinkedList();
        _lockData.lock();
        try
        {
            int cnt = 0;
            for (Entry<String, MsTrackBean> ent : _cacheRunning.entrySet())
            {
                lstSort.add(ent.getValue());
                if (++cnt >= limit)
                    break;
            }
            return lstSort;
        } finally
        {
            _lockData.unlock();
        }
    }
    
    public String toString()
    {
        return "Running : " + _cacheRunning.size();
    }

    public int getHistoryLimit()
    {
        return 0;
    }

    public Object queryData(String serviceId, Object... param)
    {
        switch(serviceId)
        {
        case SERVICE_RUNNING_BUFFER:
            return getLazySize();
        case SERVICE_MAIN_HISTORY:
            return getHistory();
        case SERVICE_MAIN_GET_BEAN:
            return getBean(param);
        case SERVICE_MAIN_TOP_RUNNING:
            return  queryRunning(param==null?10:(int)param[0]);
        }
        return null;
    }

    public MsTrackBean getBean(Object ... param)
    {
        if (ToolUtilities.isObjectEmpty(param))
            return null;
        
        return getBean(ToolUtilities.getString(param[0], null));
    }
    
    public MsTrackBean getBean(String id)
    {
        if (id == null)
            return null;
        
        MsTrackBean runn = _cacheRunning.get(id);
        if (runn != null)
            return runn;
        
        return null;
    }

    public void doLazyFilter(AbsMsTrackBean bean)
    {
        if (!(bean instanceof MsTrackBean))
            return;

        MsTrackBean sBean = (MsTrackBean) bean;
        _lockData.lock();
        try
        {
            _cacheRunning.put(bean.getMyID(), sBean);
        } finally
        {
            _lockData.unlock();
        }
        
        MsTrackPlugin.getPlugin().OnTrackBegin(sBean);
    }

    public AbsMsTrackBean doFilter(AbsMsTrackBean bean)
    {
        return bean;
    }
    
    
}
