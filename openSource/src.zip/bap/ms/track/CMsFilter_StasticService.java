package bap.ms.track;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.locks.ReentrantLock;

import com.leavay.common.util.Pair;
import com.leavay.common.util.RelationMap;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.microService.MsType;
import com.leavay.dfc.microService.bean.AbsMsTrackBean;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.leavay.dfc.microService.bean.MsTrackEndBean;
import com.leavay.dfc.microService.track.CallPair;
import com.leavay.dfc.microService.track.filter.MsCallStastic;
import com.leavay.dfc.microService.track.filter.MsFilterBasic;
import com.leavay.dfc.microService.track.filter.MsTrackFilter;

public class CMsFilter_StasticService extends MsFilterBasic<AbsMsTrackBean>
{
    private static final long serialVersionUID = -7238604209039860483L;

    public final static String SERVICE_STASTIC_HISTORY = "SERVICE_STASTIC_HISTORY";
    public final static String SERVICE_STASTIC_TPS = "SERVICE_STASTIC_TPS";
    
    public final static String SERVICE_STASTIC_TOP_HIT = "SERVICE_STASTIC_CALL_COUNT"; // Param0 : num(Integer)
    public final static String SERVICE_STASTIC_SLOWEST = "SERVICE_STASTIC_SLOWEST"; // Param0 : num(Integer)

    public final static String SERVICE_STASTIC_AGENT_SERVICE = "SERVICE_STASTIC_AGENT_SERVICE";

    public final static String SERVICE_STASTIC_RELATION_SERVICE = "SERVICE_STASTIC_RELATION_SERVICE";
    public final static String SERVICE_STASTIC_RELATION_INTERFACE = "SERVICE_STASTIC_RELATION_INTERFACE";
    
    public final static String SERVICE_STASTIC_SERVICE_CALL_STASTIC = "SERVICE_STASTIC_SERVICE_CALL_STASTIC"; // param0 : Set<CallPair>
    public final static String SERVICE_STASTIC_INTERFACE_CALL_STASTIC = "SERVICE_STASTIC_INTERFACE_CALL_STASTIC"; // param0 : Set<CallPair>
    
    // 周期内总调用次数
    ReentrantLock _lockStastic;
    long _totalCount;
    long _lastTpsTime;
    long _lastTpsCount;
    
    // 一个周期里第一次被触发和最后一次被触发的时间
    long _firstTime;
    long _finalTime;
    
    //专用于统计服务间调用计数
    ReentrantLock _lockLazy;

    // 统计服务调用计数（永不清除）
    Map<String, MsCallStastic> _serviceCount;
    
    // 统计每个代理（服务提供者）执行每个服务的计数以及耗时
    Map<String, Map<String, MsCallStastic>> _agentStastic;
    
    // 服务级调用关系统计
    RelationMap _serviceRel;
    Map<CallPair, MsCallStastic> _serviceRelStastic;
    
    // 接口级调用关系统计
    RelationMap _intfRel;
    Map<CallPair, MsCallStastic> _intfRelStastic;
    
    public CMsFilter_StasticService()
    {
        super();
        _lockStastic = new ReentrantLock();
        _lockLazy = new ReentrantLock();
    }
    
    public void initOnStart()
    {
        _lockStastic.lock();
        try
        {
            _firstTime = System.currentTimeMillis();
            _finalTime = _firstTime;
            _lastTpsTime = _firstTime;

            _totalCount = 0;
            _lastTpsCount = 0;
        } finally
        {
            _lockStastic.unlock();
        }
        
        _lockLazy.lock();
        try
        {
            _serviceCount = new HashMap();
            _agentStastic = new HashMap();
            
            _serviceRelStastic = new TreeMap(); // 必须是Treemap，里面的key的判断用comparator
            _serviceRel = new RelationMap();
            
            _intfRelStastic = new TreeMap(); // 必须是Treemap，里面的key的判断用comparator
            _intfRel = new RelationMap();
        }finally
        {
            _lockLazy.unlock();
        }
    }
    
    public void initPeriodicData()
    {
    }
    
    public void clearPeriodicData()
    {
    }
    
    public MsTrackFilter<AbsMsTrackBean> clone()
    {
        CMsFilter_StasticService newO = new CMsFilter_StasticService();

        _lockStastic.lock();
        try
        {
            newO._firstTime = _firstTime;
            newO._finalTime = _finalTime;

            newO._totalCount = _totalCount;
        } finally
        {
            _lockStastic.unlock();
        }
        
        _lockLazy.lock();
        try
        {
            newO._serviceCount = _serviceCount;
            newO._agentStastic = _agentStastic;
            
            newO._serviceRel = _serviceRel;
            newO._serviceRelStastic = _serviceRelStastic;
            
            newO._intfRelStastic = _intfRelStastic;
            newO._intfRel = _intfRel;
        }finally
        {
            _lockLazy.unlock();
        }

        return newO;
    }
    
    public void doLazyFilter(AbsMsTrackBean bean)
    {
        _lockLazy.lock();
        try
        {
            if (bean instanceof MsTrackBean)
            {
                MsTrackBean sBean = (MsTrackBean) bean;
                
                // 记录调用关系
                putRelation(sBean);
                
                // 服务调用计数统计
                String srvName = sBean.getServiceName();
                MsCallStastic srvCnt = _serviceCount.get(srvName);
                if (srvCnt == null)
                {
                    srvCnt = new MsCallStastic();
                    _serviceCount.put(srvName, srvCnt);
                }
                srvCnt.incremCall();
                
                // 每个代理分别执行服务的统计
                recordAgentService(sBean);
                
                // 服务级调用关系统计，以调用父子关系为key
                CallPair srvCallPair = newCallPair(sBean.getPService(), sBean.getServiceName());
                MsCallStastic srvSts = _serviceRelStastic.get(srvCallPair);
                if (srvSts == null)
                {
                    srvSts = new MsCallStastic();
                    _serviceRelStastic.put(srvCallPair, srvSts);
                }
                srvSts.incremCall();
                
                // 接口级调用关系统计，以调用父子关系为key，精确到interface
                CallPair callPair = newCallPair(sBean.getPInterfaceKey(), sBean.getMyInterfaceKey());
                MsCallStastic sts = _intfRelStastic.get(callPair);
                if (sts == null)
                {
                    sts = new MsCallStastic();
                    _intfRelStastic.put(callPair, sts);
                }
                sts.incremCall();
            } else if (bean instanceof MsTrackEndBean)
            {
                // 结束消息单独处理
                MsTrackEndBean endBean = (MsTrackEndBean) bean;
                MsCallStastic srvCnt = _serviceCount.get(endBean.getServiceName());
                if (srvCnt != null)
                    srvCnt.putDuration(endBean.getDuration());
                
                // 每个代理对服务调用的统计
                recordAgentService(endBean);

                // 服务级调用关系计时
                CallPair srvCallPair = newCallPair(endBean.getPService(), endBean.getServiceName());
                MsCallStastic srvSts = _serviceRelStastic.get(srvCallPair);
                if (srvSts != null)
                    srvSts.putDuration(endBean.getDuration());

                // 接口级调用关系计时
                CallPair callPair = newCallPair(endBean.getPInterfaceKey(), endBean.getMyInterfaceKey());
                MsCallStastic sts = _intfRelStastic.get(callPair);
                if (sts != null)
                    sts.putDuration(endBean.getDuration());
            }
        } finally
        {
            _lockLazy.unlock();
        }
    }
    
    protected void recordAgentService(MsTrackEndBean endBean)
    {
        Map<String, MsCallStastic> srvOfAgt = _agentStastic.get(endBean.getDstAgent());
        if (srvOfAgt == null)
        {
            srvOfAgt = new HashMap();
            _agentStastic.put(endBean.getDstAgent(), srvOfAgt);
        }
        
        MsCallStastic agtSrvCnt = srvOfAgt.get(endBean.getServiceName());
        if (agtSrvCnt == null)
        {
            agtSrvCnt = new MsCallStastic();
            srvOfAgt.put(endBean.getServiceName(), agtSrvCnt);
        }
        agtSrvCnt.incremCall();
        agtSrvCnt.putDuration(endBean.getDuration());
    }
    
    protected void recordAgentService(MsTrackBean startBean)
    {
        // 开始事件中，还没有DstAgent的信息，所以无法按Agent统计
        // 全部实现挪到endBean的处理中去 ：recordAgentService(MsTrackEndBean endBean)
    }
    
    public static CallPair newCallPair(String src, String dst)
    {
        return new CallPair(getKeyString(src), getKeyString(dst));
    }
    
    public static String getKeyString(String key)
    {
        if (ToolUtilities.isStringEmpty(key, true))
            return MsType.NULL_KEY;
        return key;
    }
    
    protected void putRelation(MsTrackBean bean)
    {
        _serviceRel.addRelation(getKeyString(bean.getPService()), getKeyString(bean.getServiceName()));
        _intfRel.addRelation(getKeyString(bean.getPInterfaceKey()), getKeyString(bean.getMyInterfaceKey()));
    }
    
    long _lastTps = 0;
    long _lastTpsQueryTime = -1;
    public float getTps()
    {
        _lockStastic.lock();
        try
        {
            long time = System.currentTimeMillis();
            if (time - _lastTpsQueryTime < 1000)
                return _lastTps;

            long duration = time - _lastTpsTime;
            try
            {
                _lastTps = ((_totalCount - _lastTpsCount) * 1000) / duration;
                return _lastTps;
            } finally
            {
                _lastTpsCount = _totalCount;
                _lastTpsTime = time;
                _lastTpsQueryTime = time;
            }
        } finally
        {
            _lockStastic.unlock();
        }
    }
    
    public String toString()
    {
        if (isHistory())
            return "Total : " + _totalCount + ", TPS = "+getTps()+"/s";
        else
            return "Total : " + _totalCount + ", TPS = "+getTps()+"/s"
            +"\nServiceCall : " + ToolUtilities.logString(_serviceCount, false)
            +"\nService Call (Sub) : " + ToolUtilities.logString(_intfRelStastic, false)
            +"\nHistory : " + ToolUtilities.logString(getHistory(), false);
    }
    
    public int getHistoryLimit()
    {
        return 20;
    }

    public Object queryData(String serviceId, Object... param)
    {
        switch(serviceId)
        {
        case SERVICE_STASTIC_TPS:
            return getTps();
        case SERVICE_STASTIC_TOP_HIT:
            return getTopService(param==null?5:ToolUtilities.getInteger(param[0], 5));
        case SERVICE_STASTIC_SLOWEST:
            return getSlowestService(param==null?5:ToolUtilities.getInteger(param[0], 5));
        case SERVICE_STASTIC_HISTORY:
            return getHistory();
        case SERVICE_STASTIC_RELATION_INTERFACE:
            return queryInterfaceRelation();
        case SERVICE_STASTIC_RELATION_SERVICE:
            return queryServiceRelation();
        case SERVICE_STASTIC_SERVICE_CALL_STASTIC:
            return queryServiceStastic((Set<CallPair>) param[0]);
        case SERVICE_STASTIC_INTERFACE_CALL_STASTIC:
            return queryInterfaceStastic((Set<CallPair>) param[0]);
        case SERVICE_STASTIC_AGENT_SERVICE:
            return queryAgentStastic();
        }
        return null;
    }
    
    public RelationMap queryInterfaceRelation()
    {
        _lockLazy.lock();
        try
        {
            return _intfRel.clone();
        } finally
        {
            _lockLazy.unlock();
        }
    }
    
    public Map<String, Map<String, MsCallStastic>> queryAgentStastic()
    {
        _lockLazy.lock();
        try
        {
            return _agentStastic;
        } finally
        {
            _lockLazy.unlock();
        }
    }
    
    public RelationMap queryServiceRelation()
    {
        _lockLazy.lock();
        try
        {
            return _serviceRel.clone();
        } finally
        {
            _lockLazy.unlock();
        }
    }
    
    public TreeMap<CallPair, MsCallStastic> queryServiceStastic(Set<CallPair> setCp)
    {
        TreeMap<CallPair, MsCallStastic> mapRet = new TreeMap();
        _lockLazy.lock();
        try
        {
            for (CallPair cp : setCp)
            {
                mapRet.put(cp, _serviceRelStastic.get(cp));
            }
        } finally
        {
            _lockLazy.unlock();
        }
        return mapRet;
    }
    
    public TreeMap<CallPair, MsCallStastic> queryInterfaceStastic(Set<CallPair> setCp)
    {
        TreeMap<CallPair, MsCallStastic> mapRet = new TreeMap();
        _lockLazy.lock();
        try
        {
            for (CallPair cp : setCp)
            {
                mapRet.put(cp, _intfRelStastic.get(cp));
            }
        } finally
        {
            _lockLazy.unlock();
        }
        return mapRet;
    }
    
    public String printInterfaceRelation()
    {
        _lockLazy.lock();
        try
        {
            return ToolUtilities.logString(_intfRel.getAllSource2Target(), true);
        } finally
        {
            _lockLazy.unlock();
        }
    }
    
    public String printServiceRelation()
    {
        _lockLazy.lock();
        try
        {
            return ToolUtilities.logString(_serviceRel.getAllSource2Target(), true);
        } finally
        {
            _lockLazy.unlock();
        }
    }
    
    public List<Pair<String, Double>> getSlowestService(int num)
    {
        LinkedList<Pair<String, Double>> lstP = new LinkedList<>();
        _lockLazy.lock();
        try
        {
            for (Entry<String, MsCallStastic> ent : _serviceCount.entrySet())
            {
                lstP.add(new Pair<String, Double>(ent.getKey(), ent.getValue().getAvgDuration()));
            }
        } finally
        {
            _lockLazy.unlock();
        }

        Collections.sort(lstP, new Comparator<Pair<String, Double>>()
        {
            public int compare(Pair<String, Double> o1, Pair<String, Double> o2)
            {
                return -1 * ToolUtilities.compareDouble(o1.getValue(), o2.getValue());
            }
        });

        while (lstP.size() > num)
            lstP.removeLast();
        return lstP;
    }
    
    public List<Pair<String, Long>> getTopService(int num)
    {
        LinkedList<Pair<String, Long>> lstP = new LinkedList<>();
        _lockLazy.lock();
        try
        {
            for (Entry<String, MsCallStastic> ent : _serviceCount.entrySet())
            {
                lstP.add(new Pair<String, Long>(ent.getKey(), ent.getValue().getCount()));
            }
        } finally
        {
            _lockLazy.unlock();
        }

        Collections.sort(lstP, new Comparator<Pair<String, Long>>()
        {
            public int compare(Pair<String, Long> o1, Pair<String, Long> o2)
            {
                return -1 * ToolUtilities.compareLong(o1.getValue(), o2.getValue());
            }
        });

        while (lstP.size() > num)
            lstP.removeLast();
        return lstP;
    }

    public AbsMsTrackBean doFilter(AbsMsTrackBean bean)
    {
        _lockStastic.lock();
        try
        {
            if (bean instanceof MsTrackBean)
                _totalCount++;
            _finalTime = System.currentTimeMillis();
        } finally
        {
            _lockStastic.unlock();
        }

        return bean;
    }
    
    public static void main(String[] args)
    {
        RelationMap m = new RelationMap();
        m.addRelation(null, "test");
        m.addRelation("ss", null);
        System.out.println(m);
    }
}
