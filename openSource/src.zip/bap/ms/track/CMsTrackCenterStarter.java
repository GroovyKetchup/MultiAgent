package bap.ms.track;

import com.leavay.common.util.ToolUtilities;
import com.leavay.starter.CStarter;

/**
 * 微代理接入微服务的启动模块
 * 
 */
public class CMsTrackCenterStarter implements CStarter
{
    public final static String MODULE_NAME="msTrackCenter";
    
    public void before(CStarter other) throws Exception
    {
        
    }

    public void start() throws Exception
    {
        
        // 主控挂掉的时候，要反复尝试启动track center，但不能影响正常启动
        new Thread("Start Track Center ... ")
        {
            public void run()
            {
                for (;;)
                {
                    try
                    {
                        CMsTrackCenter.getMe().initService();
                        return;
                    }catch(Throwable err)
                    {
                        ToolUtilities.error(MODULE_NAME, "Failed to init track center service", err);
                        ToolUtilities.sleep(5000);
                    }
                }
            }
        }.start();
    }
}
