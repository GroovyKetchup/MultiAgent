package bap.ms.agent;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import com.leavay.common.util.LogS;
import com.leavay.common.util.OSProcessCmd;
import com.leavay.common.util.SrvRes;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ZipUtils;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ssh.SshUtil;
import com.leavay.dfc.microService.MsCenterConf;
import com.leavay.dfc.microService.MsCenterMgr;
import com.leavay.dfc.microService.MsConf;
import com.leavay.dfc.microService.MsMemberConf;
import com.leavay.jmxfw.util.rmi.RmiAutoClientSocketFactory;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.ms.warehouse.MsAgentInfoDto;
import com.leavay.nio.crpc.CRpcServer;
import com.leavay.starter.StarterConf;
import com.leavay.starter.StarterItem;
import com.leavay.starter.StarterMain;
import com.leavay.starter.StarterParam;

import bap.ms.CMsConst;
import md.ms.MsAgentDo;

public class MsAgentDeployTool
{
    final static String LOG="Agent Deploy Tool";

    public static long START_AGENT_TIMEOUT = 30*1000; // 1 minutes
    public final static String AGENT_PID_FILE = "ProcessID.txt";
    
    public final static String Local_Agent_Path = "LocalMsAgent";
//    public final static String Download_Template_Path = "Download/MsAgent";

    static ReentrantLock _lockMap = new ReentrantLock();
    static Map<String, OSProcessCmd> _mapLocalProcess = new TreeMap<String, OSProcessCmd>();
    
    public static String getLocalAgentPath(MsAgentDo agent)
    {
        return ToolUtilities.getCurrentDirectory()+File.separator+Local_Agent_Path+File.separator+agent.getNioPort();
    }
    
    public static void chmodShell(MsAgentDo agent) throws Exception
    {
        if (agent.isLocal())
        {
            String rootPath = getLocalAgentPath(agent);
            String binPath = rootPath + File.separator + "bin";
            String sCmd = "bin/chmodShell.sh " + binPath + File.separator + "*";

            // 启动进程
            ToolUtilities.info(LOG, "Try to chmod all *.sh files to '+x' \nCMD : " + sCmd);
            Process proc = Runtime.getRuntime().exec(sCmd);
            int iExitCode = proc.waitFor();
            ToolUtilities.info(LOG, "Succed to chmod all *.sh files to '+x' right.(Exit Code:" + iExitCode + ")\nCMD : " + sCmd);
        }else if (agent.isSsh())
        {
            String sCmd = "chmod 777 "+ agent.getSshPath()+"/bin/*";
            runSSH(agent, sCmd, null, null);
        }
    }
    
    public static void deployLocalAgent(MsAgentDo agent) throws Exception
    {
        try
        {
            String dstPath = getLocalAgentPath(agent);
            ToolUtilities.deleteFileFolder(new File(dstPath));
            ToolUtilities.createFolder(dstPath);
            
            prepareLocalAgentFile(agent, dstPath);
        } catch (Throwable err)
        {
            // 如果失败，则尝试回滚
            ToolUtilities.err(LOG, "Failed to deployAgent : " + agent, err);
            deleteAgentFile(agent);
            ToolUtilities.throwException(err);
        }
    }
    
    // 仅用于windows部署本机代理，由于文件名过长容易启动失败
    // 全部文件重命名即可
    public static void renameJarForWindows(String path) throws IOException
    {
        String fileMap = "";
        List<String> lstFile = ToolUtilities.getAllChildFile(new File(path));
        
        int id = 0;
        for (String sfl : lstFile)
        {
            File fl = new File(sfl);
            if (fl.isDirectory() || !fl.exists())
                continue;
            
            String ext = ToolUtilities.getExtOfFile(fl.getName());
            File dstFl = new File(fl.getParentFile(), id+++"."+ext);
            
            ToolUtilities.renameFile(fl.getAbsolutePath(), dstFl.getAbsolutePath());
            fileMap+="[" + dstFl.getName()+"] = "+fl.getAbsolutePath()+"\n";
        }
        ToolUtilities.saveFile(path+"/FileMapping.txt", fileMap.getBytes(), false);
    }
    
    public static void deploySshBasicPackage(MsAgentDo agent) throws Exception
    {
            File cmnPkg = MsAgentMgr.getPackageFile(agent.getPkgPath());
            String commonJar = "agent_common.jar";
            scpPut(agent, cmnPkg, agent.getSshPath() + "/" + commonJar );
            String sCmd1 = "export JAVA_HOME=" + agent.getSshJdkPath() + ";";
            sCmd1 += "\nexport PATH=$PATH:$JAVA_HOME/bin;";
            sCmd1 += "\nenv;";
            sCmd1 += "\ncd " + agent.getSshPath() + ";";
            sCmd1 += "\njar -xvf " + commonJar;
            sCmd1 += "\nrm -rf " + commonJar;
            runSSH(agent, sCmd1, null, null);
    }
    
    public static void updateMessage(MsAgentDo agent, String msg)
    {
        MsAgentMgr.getMe().updateMessage(agent, msg);
    }
    
    public static void deploySshCustomFile(MsAgentDo agent) throws Exception
    {
        String allocKey = ToolUtilities.allockUUIDWithUnderline();
        String tmpPath = "tmp" + File.separator + "AgentTmp_" + allocKey + File.separator;
        String tmpZip = "tmp" + File.separator + "AgentTmp_zip_" + allocKey + ".zip";

        try
        {
            File tmpFolder = prepareCustomerFile(agent, tmpPath);
            updateMessage(agent, SrvRes.getString("Compress agent files") + " ... ");
            ZipUtils.zip(tmpPath, tmpZip, "UTF-8");
            ToolUtilities.deleteFileFolder(tmpFolder);

            String dstJarFile = allocKey + ".jar";
            try
            {
                updateMessage(agent, SrvRes.getString("SSH transmission agent files") + " ....... ");
                scpPut(agent, new File(tmpZip), agent.getSshPath() + "/" + dstJarFile);

                // 远程解压缩
                String sCmd = "export JAVA_HOME=" + agent.getSshJdkPath() + ";";
                sCmd += "\nexport PATH=$PATH:$JAVA_HOME/bin;";
                sCmd += "\nenv;";
                sCmd += "\ncd " + agent.getSshPath() + ";";
                sCmd += "\njar -xvf " + dstJarFile;
                sCmd += "\nrm -rf " + dstJarFile;
                runSSH(agent, sCmd, null, null);
            } catch (Throwable exp)
            {
                runSSH(agent, "rm -rf " + agent.getSshPath(), null, null);
                ToolUtilities.throwException(exp);
            }
        } finally
        {
            try
            {
                ToolUtilities.deleteFileFolder(tmpZip);
            } catch (Throwable err)
            {
                ToolUtilities.error(LOG, err);
            }
            try
            {
                ToolUtilities.deleteFileFolder(tmpPath);
            } catch (Throwable err)
            {
                ToolUtilities.error(LOG, err);
            }
        }
    }
    
    public static void deploySshAgent(MsAgentDo agent) throws Exception
    {
        // 先部署公共文件
        deploySshBasicPackage(agent);

        // 再部署用户定义相关文件
        deploySshCustomFile(agent);

        // bin权限
        chmodShell(agent);
    }
    
    public static void deleteAgentFile(MsAgentDo agent) throws Exception
    {
        if (agent.isLocal())
        {
            deleteLocalAgentFile(agent);
        }else if (agent.isSsh())
        {
            deleteSshAgentFile(agent);
        }
    }
    
    public static void deleteLocalAgentFile(MsAgentDo agent) throws Exception
    {
        String dstPath = getLocalAgentPath(agent);
        long time = System.currentTimeMillis();
        for (;;)
        {
            File f = new File(dstPath);
            ToolUtilities.deleteFileFolder(f);
            if (!f.exists())
                return;
            
            if (System.currentTimeMillis() - time >= 10000)
                throw new Exception("Failed to delete agent folder : " + f);
        }
    }
    
    public static void deleteSshAgentFile(MsAgentDo agent)
    {
        String sCmd = "rm -rf " + agent.getSshPath();
        try
        {
            runSSH(agent, sCmd, null, null);
        } catch (Exception exp)
        {
            System.err.println("Failed to delete ssh agent files : "+ agent.getName());
            exp.printStackTrace();
        }
    }

    public static void startAgent(MsAgentDo agent) throws Exception
    {
        startAgent(agent, true);
    }
    
    public static void startAgent(MsAgentDo agent, boolean wait) throws Exception
    {
        if (agent.isLocal())
            startLocalAgent(agent, wait);
        else if (agent.isSsh())
            startSshAgent(agent, wait);
    }

    public static void startLocalAgent(MsAgentDo agent) throws Exception
    {
        startLocalAgent(agent, true);
    }
    
    public static void startLocalAgent(MsAgentDo agent, boolean wait) throws Exception
    {
        String agentPath = getLocalAgentPath(agent);
        String binPath = agentPath + File.separator + "bin";
        boolean blWindows = ToolUtilities.isRunningOnWindows();
        String shellCmd = "";
        if (blWindows)
        {
            if (agent.isDebug())
                shellCmd = binPath + File.separator +MsAgentDo.StartupBatName_Debug + " \"" + agent.getDebugPort()+"\"";
            else
                shellCmd = binPath + File.separator +MsAgentDo.StartupBatName;
        }
        else
        {
            if (agent.isDebug())
                shellCmd = binPath + File.separator +MsAgentDo.StartupShellName_Debug+" " + agent.getDebugPort();
            else
                shellCmd = binPath + File.separator + MsAgentDo.StartupShellName;
        }

        try
        {
            OSProcessCmd _process = new OSProcessCmd("Agent_" + agent.getName() + "_" + agent.getNioPort(), binPath, shellCmd)
            {
                public void printInfo(String s)
                {
                    super.printInfo(s);
                }

                public void printError(String s)
                {
                    String outS = "[" + getProcessName() + "]" + s + "[/" + getProcessName() + "]";
                    System.err.println(outS);
                }

                public void OnProcessExit()
                {
                    removeCachedProcess(this);
                }
            };

            // 等待进程真正启动
            long lStarttime = System.currentTimeMillis();
            while (!_process.isAlive())
            {
                // 刚启动就已经退出了
                if (_process.isExitAfterStart())
                    throw new Exception("Process is already exit");
                
                // 响应强制重构命令
                if (isAquireQuitWait(agent.getUuid()))
                    throw new Exception("Quit wait startup for other reason : " + getAquireQuitReason(agent.getUuid()));

                // 既没有退出，又老是没有启动进程
                if (System.currentTimeMillis() - lStarttime > START_AGENT_TIMEOUT)
                {
                    ToolUtilities.fatal(LOG, "Timeout to start agent");
                    throw new Exception("Timeout to start agent");
                }

                ToolUtilities.sleep(1);
            }

            if (_process.isAlive())
                addCachedProcess(agent.getUuid(), _process);

        } catch (Throwable exp)
        {
            Exception erro = new Exception(SrvRes.getString("Failed to start worker"), exp);
            throw erro;
        }
        
        if (!wait)
            return;
        
//        // 死等一下rmi启动
//        long lTimeOut = 15*1000;
//        long lstart = System.currentTimeMillis();
//        while (true)
//        {
//            ToolUtilities.sleep(100);
//            try
//            {
//                SshAgentIntf agtIntf = agent.tryConnect();
//                
//                // 出现这种情况是因为代理rmi主服务已经启动了，但是remote对象还没来得及设置进去
//                if (agtIntf == null)
//                    throw new Exception("Agent remote object is not registed");
//                
//                return agtIntf;
//            }catch(Throwable err)
//            {
//                if (System.currentTimeMillis() - lstart <= lTimeOut)
//                    continue;
//                
//                throw new Exception(SrvRes.getString("Timed out to wait for connecting agent")+" : " + agent.getNameText());
//            }
//        }
    }

    public static void startSshAgent(MsAgentDo agent) throws Exception
    {
        startSshAgent(agent, true);
    }
    
    static ConcurrentHashMap<String, String> _forceQuitWait = new ConcurrentHashMap();
    public static void aquireQuitWait(String agtRdn, String reason)
    {
        _forceQuitWait.put(agtRdn, reason);
    }
    
    public static boolean isAquireQuitWait(String agtRdn)
    {
        return _forceQuitWait.containsKey(agtRdn);
    }
    
    public static String getAquireQuitReason(String agtRdn)
    {
        return _forceQuitWait.get(agtRdn);
    }
    
    public static void cancelQuitWait(String agtRdn)
    {
        _forceQuitWait.remove(agtRdn);
    }
    
    public static void startSshAgent(MsAgentDo agent, boolean wait) throws Exception
    {
//        String sCmd = "export JAVA_HOME=" + agent.getSshJdkPath() + ";";
//        sCmd += "\nexport PATH=$PATH:$JAVA_HOME/bin;";
//        sCmd += "\nenv;";
//        sCmd += "\ncd " + agent.getSshDspPath() + "/bin;";
        String sCmd = "\ncd " + agent.getSshPath() + "/bin;";
        
        sCmd += "\nnohup ./";
//        sCmd += "\n ./";
        if (agent.isDebug())
            sCmd += MsAgentDo.StartupShellName_Debug + " \"" +agent.getDebugPort()+ "\" &";
        else
            sCmd += MsAgentDo.StartupShellName + " &";
        
        StringBuffer outErr = new StringBuffer();

        updateMessage(agent, SrvRes.getString("Starting agent by SSH") + " ....... ");
        int res = runSSHAndWait(agent, sCmd, outErr, outErr, 1000);

        if (!wait)
            return;

//        // 死等一下rmi启动
//        // 如果外部有重构命令，需要终止等待，则退出等待
//        long lTimeOut = 60 * 1000;
//        long lstart = System.currentTimeMillis();
//        while (true)
//        {
//            if (isAquireQuitWait(agent.getRDN()))
//                throw new Exception("Quit wait startup for other reason : " + getAquireQuitReason(agent.getRDN()));
//            
//            ToolUtilities.sleep(100);
//            try
//            {
//                SshAgentIntf agtIntf = agent.tryConnect();
//
//                // 出现这种情况是因为代理rmi主服务已经启动了，但是remote对象还没来得及设置进去
//                if (agtIntf == null)
//                    throw new Exception("Agent remote object is not registed");
//
//                return agtIntf;
//            } catch (Throwable err)
//            {
//                if (System.currentTimeMillis() - lstart <= lTimeOut)
//                    continue;
//
//                throw new Exception(SrvRes.getString("Timed out to startup") + " : " + agent.getNameText() + "(return:" + res + ")", new Exception("" + outErr));
//            }
//        }

    }
    
    protected static void addCachedProcess(String agentRDN, OSProcessCmd process)
    {
        _lockMap.lock();
        try
        {
            _mapLocalProcess.put(agentRDN, process);
        }finally
        {
            _lockMap.unlock();
        }
    }
    
    protected static OSProcessCmd getCachedProcess(String agentRDN)
    {
        _lockMap.lock();
        try
        {
            return _mapLocalProcess.get(agentRDN);
        }finally
        {
            _lockMap.unlock();
        }
    }
    
    protected static OSProcessCmd removeCachedProcess(String agentRDN)
    {
        _lockMap.lock();
        try
        {
            return _mapLocalProcess.remove(agentRDN);
        }finally
        {
            _lockMap.unlock();
        }
    }
    
    protected static void removeCachedProcess(OSProcessCmd proc)
    {
        _lockMap.lock();
        try
        {
            for (Entry<String, OSProcessCmd> entry : _mapLocalProcess.entrySet())
            {
                if (entry.getValue().equals(proc))
                {
                    _mapLocalProcess.remove(entry.getKey());
                    return;
                }
            }
        }finally
        {
            _lockMap.unlock();
        }
    }
    
    public static void killLocalAgent(MsAgentDo agent, long lTimeOut) throws Exception
    {
        int iPid = getPID(agent);
        OSProcessCmd proc = getCachedProcess(agent.getUuid());
        if (proc != null)
        {
            proc.stopAndClear(lTimeOut);
    
            // 再根据进程信息来判断是否正常退出
            long lStartWait = System.currentTimeMillis();
            while (proc.isAlive())
            {
                ToolUtilities.sleep(100);
                long lWaitTime = System.currentTimeMillis() - lStartWait;
                if (lWaitTime > lTimeOut)
                {
                    // 如果等了lTimeOut都没有退出，那么可能进程出问题了，停不掉了，只能重新启动新的了
                    ToolUtilities.fatal(LOG, "Time out to kill agent process. This error will be ignored : " + agent);
                    proc.stopAndClear();
                    throw new TimeoutException("Time out to kill agent process : " + agent.getName());
                }
            }
        }
        
        if (iPid >= 0)
        {
            ToolBasic.killPorcess(iPid);
            
            ToolUtilities.forceKillPorcess_IgnoreError(iPid);
        }
    }
    
    public static void killSshAgent(MsAgentDo agent, long lTimeOut) throws Exception
    {
        int pid = getPID(agent);
        if (pid < 0)
            return;
        
        try
        {
            StringBuffer sb = new StringBuffer();
            runSSH(agent, "kill " + pid, sb, sb);
            
            runSSH(agent, "kill -9 " + pid, sb, sb);
        }catch(Throwable err)
        {
            ToolUtilities.error(LOG, err);
        }
    }
    
    public static void stopAgent(MsAgentDo agent, long timeOut) throws Exception
    {
//        long lStartTime = System.currentTimeMillis();
//        
//        // 首先尝试文明的退出
//        SshAgentIntf agtIntf = SshAgentCache.getInstance().getAgentIntf(agent.getRDN());
//        if (agtIntf != null)
//        {
//            try
//            {
//                try
//                {
//                    updateMessage(agent.getRDN(), SrvRes.getString("Stopping agent"));
//                    agtIntf.terminate();
//                } catch (RemoteException exp)
//                {
//                    ToolUtilities.error(LOG, exp);
//                }
//
//                while (System.currentTimeMillis() - lStartTime < timeOut)
//                {
//                    try
//                    {
//                        agtIntf.ping();
//
//                        // 能ping通说明agent还活着，继续等
//                        ToolUtilities.sleep(100);
//                        continue;
//                    } catch (RemoteException rmtExp)
//                    {
//                        // ping不通说明可能已经挂了
//                        break;
//                    }
//                }
//            } catch (Throwable err)
//            {
//                ToolUtilities.error(LOG, err);
//            }
//        }
        
        // 尝试强制杀进程
        if (agent.isLocal())
            killLocalAgent(agent, timeOut);
        else if (agent.isSsh())
            killSshAgent(agent, timeOut);
    }
    
    public static void deployAndStart(MsAgentDo agent) throws Exception
    {
        if (agent.isLocal())
        {
            deployLocalAgent(agent);
            startLocalAgent(agent);
        }else if (agent.isSsh())
        {
            deploySshAgent(agent);
            startSshAgent(agent);
        }
    }
    
    public static void deployAgent(MsAgentDo agent) throws Exception
    {
        if (agent.isLocal())
        {
            deployLocalAgent(agent);
        }else if (agent.isSsh())
        {
            deploySshAgent(agent);
        }
    }
    
    public static void stopAndRemove(MsAgentDo agent) throws Exception
    {
        stopAgent(agent, 20*1000);
        
        deleteAgentFile(agent);
    }
    
    public static int getPID(MsAgentDo agent)
    {
        try
        {
            MsAgentInfoDto info = MsAgentMgr.getMe().queryAgentInfo(agent.getCode());
            if (info != null)
                return ToolUtilities.getInteger(info.getProcessID());
        } catch (Exception exp)
        {
            // ZK上查不到就尝试ssh拿本地
        }
        
        try
        {
            if (agent.isLocal())
            {
                String sPath = getLocalAgentPath(agent) + File.separator + AGENT_PID_FILE;

                return ToolUtilities.getInteger(new String(ToolUtilities.readFile(sPath)), -1);
            } else
            {
                String sPath = agent.getSshPath() + "/" + AGENT_PID_FILE;
                ToolUtilities.createFolder("tmp/");
                File tmpFile = new File("tmp/TmpPID_"+ToolUtilities.allockUUIDWithUnderline());
                try
                {
                    scpGet(agent, sPath, tmpFile);
                    return ToolUtilities.getInteger(new String(ToolUtilities.readFile(tmpFile.getAbsolutePath())), -1);
                }catch(Throwable err)
                {
                    ToolUtilities.warning(LOG,  "Failed to ssh get PID file", err);
                    return -1;
                }finally
                {
                    ToolUtilities.deleteFileFolder(tmpFile);
                }
            }
        } catch (Throwable err)
        {
            ToolUtilities.warning(LOG, "Failed to get process ID : " + agent);
            return -1;
        }
    }
    
    static List<InetAddress> lstIP = null;
    public synchronized static String getIPListText() throws SocketException
    {
        String sIP = "";
        if (lstIP == null)
            lstIP = ToolUtilities.getAllAddress(false);

        String sysHost = System.getProperty("java.rmi.server.hostname");
        if (!ToolUtilities.isStringEmpty(sysHost))
            sIP = sysHost + ",";

        List<String> lstConf = RmiAutoClientSocketFactory.loadRmiListConfig();
        for (String s : lstConf)
            sIP += s + ",";
        
        for (InetAddress ip : lstIP)
            sIP += ip.getHostAddress() + ",";

        return sIP;
    }
    
    public static File prepareLocalAgentFile(MsAgentDo agent, String dstPath) throws Exception
    {
        updateMessage(agent, SrvRes.getString("Preparing local files")+" ....... ");
        
        ToolUtilities.deleteFileFolder(dstPath);
        ToolUtilities.createFolder(dstPath);
        File dstFolder = new File(dstPath);
        
        ZipUtils.unzip(MsAgentMgr.getPackageFile(agent.getPkgPath()).getAbsolutePath(), dstPath);
        updateMessage(agent, SrvRes.getString("Finish copy agent files"));

        // 修改bin目录权限
        if (!ToolUtilities.isRunningOnWindows())
            chmodShell(agent);
        
        // 修改配置文件-base.conf，比如设置端口号
        modifyCustomerFile(agent, dstPath);
        
        return dstFolder;
    }
    
    public static File prepareCustomerFile(MsAgentDo agent, String dstPath) throws Exception
    {
        updateMessage(agent, SrvRes.getString("Preparing customized files") + " ....... ");

        ToolUtilities.createFolder(dstPath);
        File dstFolder = new File(dstPath);

        // 解压缩包到临时目录
        updateMessage(agent, SrvRes.getString("Unzip package files"));
        String tmpPkgFolder = dstPath + "/package_temp";
        ZipUtils.unzip(MsAgentMgr.getPackageFile(agent.getPkgPath()).getAbsolutePath(), tmpPkgFolder);
        try
        {
            // 修改配置文件-base.conf，比如设置端口号
            ToolUtilities.createFolder(dstPath + "/conf");
            ToolUtilities.copyFile(tmpPkgFolder + "/conf/", dstPath, true);

            ToolUtilities.createFolder(dstPath + "/bin");
            ToolUtilities.copyFile(tmpPkgFolder + "/bin", dstPath, true);

            modifyCustomerFile(agent, dstPath);
        } finally
        {
            ToolBasic.deleteFileFolder(tmpPkgFolder);
        }

        return dstFolder;
    }
    
 // 用于部署代理配置文件
    public static void writeBasicConfigFile(MsAgentDo agent, Properties baseProp) throws Exception
    {
        // NIO 端口，小于零则表示不支持 
        baseProp.setProperty(CRpcServer.CONF_NIO_PORT, ""+agent.getNioPort());
        
        baseProp.setProperty(CMsConst.CONF_AGENT_MCHINE_ID, ToolUtilities.getString(agent.getCode(), ""));

        // 模块的参数交给starter那边了，这边不需要统一写入base.conf了
//        Map<String, String> mapConf = agent.getConfigTableMap();
//        if (mapConf != null)
//            baseProp.putAll(mapConf);
    }
    
    public static void writeMsConfigFile(MsAgentDo agent, String dstPath) throws IOException
    {
        if (true)
            return;
        
        Properties msProp = new Properties();
        
        MsCenterMgr.getInstance().getCenterInfo().getHost();
        msProp.put(MsMemberConf.CONF_ENABLE_MS, "true");
        msProp.put(MsMemberConf.CONF_ENABLE_PROVIDE_SERVICE, "true");
        msProp.put(MsMemberConf.CONF_ZK_ADDR, MsCenterConf.getZkAddr());
        msProp.put(MsConf.CONF_EMB_PROVIDER_HOST, agent.getMyHost());
        
        ToolBasic.saveProperty(dstPath+"/" +MsMemberConf.CONF_FILE_MS_MEMBER, msProp);
    }
    
    // 根据代理上的配置，决定哪些模块启动，从而修改配置文件
    public static void writeStarterConfig(MsAgentDo agent, String dstPath) throws Exception
    {
        String confPath = MsAgentMgr.getPackageConfFile(agent.getPkgPath()).getAbsolutePath();
        String dstConfPath = dstPath+"/"+StarterMain.CONF;
        
        StarterConf conf = StarterMain.loadConfig(confPath);
        HashSet<String> setStarter = agent.getStarterConfig();
        if (setStarter == null)
            setStarter = new HashSet<String>();
        
        HashMap<String, String> paramValue = agent.getConfigTableMap();
        
        for (StarterItem st : conf.getMapItems().values())
        {
            // 从配置里读取参数确实有非空值，则覆盖写入starter文件
            // 否则保持starter文件本身默认值不动
            if (st.hasParams())
                for (StarterParam p : st.getAllParams())
                {
                    String pValue = paramValue.get(p.getKey());
                    if (!CmnUtil.isStringEmpty(pValue, true))
                        p.setValue(pValue);
                }
            
            // 设置是否启用的开关
            if (st.isOptional())
            {
                st.setEnable(setStarter.contains(st.getKey()));
            }
        }
        
        // 用这个动作校验一遍，有没有被依赖的模块被禁用了
        conf.initConfig();
        
        ToolUtilities.saveFile(dstConfPath, StarterMain.saveConfig(conf), "UTF-8", false);
    }
    
    public static void modifyCustomerFile(MsAgentDo agent, String dstPath) throws Exception
    {
        File baseConf = new File(dstPath + "/conf/base.conf");
        Properties baseProp = new Properties();
        FileInputStream in = new FileInputStream(baseConf);
        try
        {
            baseProp.load(in);
        } finally
        {
            in.close();
        }
        
        // 写入基本配置
        writeBasicConfigFile(agent, baseProp);

        // 主控的NIO服务地址以及端口
        if (CRpcServer.getNioPort() > 0)
        {
            baseProp.setProperty(CMsConst.CONF_MASTER_NIO_PORT, ""+CRpcServer.getNioPort());
        }
        baseProp.setProperty(CMsConst.CONF_MASTER_HOST, MsCenterConf.getCenterHost());
        
        // 存base.conf
        ToolUtilities.saveProperty(baseConf.getAbsolutePath(), baseProp);
        
        // 修改覆盖Starter配置
        writeStarterConfig(agent, dstPath);
        
        // 覆盖MS的Member配置文件，自动指向本机所处的微服务集群（ZK地址等）
        writeMsConfigFile(agent, dstPath);
        
        // 设置启动参数（最大最小内存等）
        overwriteShellFile(agent, dstPath + "/bin/"+MsAgentDo.StartupShellName);
        overwriteShellFile(agent, dstPath + "/bin/"+MsAgentDo.StartupShellName_Debug);
        overwriteShellFile(agent, dstPath + "/bin/"+MsAgentDo.StartupBatName);
        overwriteShellFile(agent, dstPath + "/bin/"+MsAgentDo.StartupBatName_Debug);
        
        ToolUtilities.saveFile(dstPath + "/"+MsAgentDo.AGENT_DEPLOY_TIME_TXT, ""+System.currentTimeMillis(), "UTF-8", false);
    }
    
    public static void overwriteShellFile(MsAgentDo agtMo, String fileName) throws Exception
    {
        String sMax = "-Xmx\""+agtMo.getMaxMem()+"\"M";
        String sMin = "-Xms\""+agtMo.getMinMem()+"\"M";
        
        String shellText = ToolUtilities.readFile(fileName, "UTF-8");
        shellText = ToolUtilities.replaceAll(shellText, "$MXPARAM", sMax);
        shellText = ToolUtilities.replaceAll(shellText, "%MXPARAM%", sMax);

        String jdkPath = null;
        if (agtMo.isLocal())
            jdkPath = ToolBasic.getJdkHome();
        else if (agtMo.isSsh() && !ToolUtilities.isStringEmpty(agtMo.getSshJdkPath()))
            jdkPath = agtMo.getSshJdkPath();
        
        if (!ToolUtilities.isStringEmpty(jdkPath, true))
        {
            if (jdkPath.endsWith("/") || jdkPath.endsWith("\\"))
                jdkPath = jdkPath.substring(0, jdkPath.length()-2);
            
            shellText = ToolUtilities.replaceAll(shellText, "$JAVA_HOME", jdkPath);
        }

        shellText = ToolUtilities.replaceAll(shellText, "$MSPARAM", sMin);
        shellText = ToolUtilities.replaceAll(shellText, "%MSPARAM%", sMin);
        shellText = ToolBasic.textWin2Unix(shellText);
        shellText = ToolBasic.textMac2Unix(shellText);
        
        ToolUtilities.saveFile(fileName, shellText, "UTF-8", false);
    }
    
    public static void restartAgent(MsAgentDo agent, long timeout) throws Exception
    {
        System.out.println("Start agent : " + agent.getName());
        System.out.println(ToolUtilities.getCurrentStack());
        System.out.println("======================");
        
        try
        {
            stopAgent(agent, timeout);
        }catch(Throwable err)
        {
            
        }
        
        startAgent(agent);
    }
    
    public static int runSSHAndWait(MsAgentDo agent, String sCmd, StringBuffer std, StringBuffer err, long waitTimeOut) throws Exception
    {
        if (agent.isUseSshKeyFile())
        {
            ToolUtilities.createFolder("tmp/");
            File tmpFile = new File("tmp/ssh_key_"+ToolUtilities.allockUUIDWithUnderline());
            try
            {
                ToolUtilities.saveFile(tmpFile.getAbsolutePath(), agent.getSshKeyFile().getBytes(), false);
                return SshUtil.runSSHAndWait(agent.getMyHost(), agent.getSshPort(), agent.getSshUser(), agent.getSshPassword(), tmpFile, sCmd, std, err, waitTimeOut);
            }finally
            {
                ToolUtilities.deleteFileFolder(tmpFile);
            }
        }else
        {
            return SshUtil.runSSH_NoBlock(agent.getMyHost(), agent.getSshPort(), agent.getSshUser(), agent.getSshPassword(), sCmd, std, err, waitTimeOut);
        }
    }

    public static int runSSH(MsAgentDo agent, String cmd, StringBuffer str, StringBuffer error) throws Exception
    {
        if (agent.isUseSshKeyFile())
        {
            ToolUtilities.createFolder("tmp/");
            File tmpFile = new File("tmp/ssh_key_"+ToolUtilities.allockUUIDWithUnderline());
            try
            {
                ToolUtilities.saveFile(tmpFile.getAbsolutePath(), agent.getSshKeyFile().getBytes(), false);
                return SshUtil.runSSH(agent.getMyHost(), agent.getSshPort(), agent.getSshUser(), tmpFile, agent.getSshPassword(), cmd, str, error);
            }finally
            {
                ToolUtilities.deleteFileFolder(tmpFile);
            }
        }else
        {
            return SshUtil.runSSH(agent.getMyHost(), agent.getSshPort(), agent.getSshUser(), agent.getSshPassword(), cmd, str, error);
        }
    }

    public static long scpPut(MsAgentDo agent, File localFile, String remoteFile) throws Exception
    {
        if (agent.isUseSshKeyFile())
        {
            ToolUtilities.createFolder("tmp/");
            File tmpFile = new File("tmp/ssh_key_"+ToolUtilities.allockUUIDWithUnderline());
            try
            {
                ToolUtilities.saveFile(tmpFile.getAbsolutePath(), agent.getSshKeyFile().getBytes(), false);
                return SshUtil.scpPut(agent.getMyHost(), agent.getSshPort(), agent.getSshUser(), tmpFile, agent.getSshPassword(), localFile, remoteFile);
            }finally
            {
                ToolUtilities.deleteFileFolder(tmpFile);
            }
        }else
        {
            return SshUtil.scpPut(agent.getMyHost(), agent.getSshPort(), agent.getSshUser(), agent.getSshPassword(), localFile, remoteFile);
        }
    }

    public static long scpGet(MsAgentDo agent, String remoteFile, File localFile) throws Exception
    {
        if (agent.isUseSshKeyFile())
        {
            ToolUtilities.createFolder("tmp/");
            File tmpFile = new File("tmp/ssh_key_" + ToolUtilities.allockUUIDWithUnderline());
            try
            {
                ToolUtilities.saveFile(tmpFile.getAbsolutePath(), agent.getSshKeyFile().getBytes(), false);
                return SshUtil.scpGet(agent.getMyHost(), agent.getSshPort(), agent.getSshUser(), tmpFile, agent.getSshPassword(), remoteFile, localFile);
            } finally
            {
                ToolUtilities.deleteFileFolder(tmpFile);
            }
        } else
        {
            return SshUtil.scpGet(agent.getMyHost(), agent.getSshPort(), agent.getSshUser(), agent.getSshPassword(), remoteFile, localFile);
        }
    }
    
    public static MultiPageResult<String> readLastOutput(MsAgentDo agent, int startLine, int lastLineCount) throws Exception
    {
        if (agent.isLocal())
        {
            String sFile = getLocalAgentPath(agent)+File.separator+MsAgentDo.OutputFile;
            return LogS.readLastLog(sFile, startLine, lastLineCount);
        }else if (agent.isSsh())
        {
            String sPath = agent.getSshPath() + "/" + MsAgentDo.OutputFile;
            ToolUtilities.createFolder("tmp/");
            File tmpFile = new File("tmp/TmpOutput_"+ToolUtilities.allockUUIDWithUnderline());
            try
            {
                scpGet(agent, sPath, tmpFile);
                return LogS.readLastLog(tmpFile.getAbsolutePath(), startLine, lastLineCount);
            }finally
            {
                ToolUtilities.deleteFileFolder(tmpFile);
            }
        }else
            return null;
    }
}
