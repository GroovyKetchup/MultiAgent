package bap.ms.agent;

import java.io.IOException;

import com.leavay.common.util.AsyncSystemOutLog;
import com.leavay.common.util.LogS;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.SystemOutLog;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.CodeUtil;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.NioService;
import com.leavay.starter.CStarter;

import bap.java.CJavaAgentMgr;
import md.ms.MsAgentDo;

// 专用于维代理启动模式下，启动一些基础功能，如转存OUT、生成PID文件、CNClient初始化等
public class AgentBasicStarter implements CStarter
{
    public final static String CONF_REDIRECT_OUTPUT = "agent.redirect.output";
    public final static String CONF_REDIRECT_OUTPUT_ROLLING_MODE = "agent.redirect.output.rollingMode";
    public final static String CONF_REDIRECT_OUTPUT_MAX_RETENTION_DAYS = "agent.redirect.output.maxRetentionDays";
    public final static String CONF_REDIRECT_OUTPUT_MAX_FILE_COUNT = "agent.redirect.output.maxFileCount";
    public final static String CONF_REDIRECT_OUTPUT_MAX_FILE_SIZE = "agent.redirect.output.maxFileSize";
    
    static AsyncSystemOutLog _agentOut = new AsyncSystemOutLog(MsAgentDo.OutputFile);
    
    
    public static void redirectSystemOut() throws IOException
    {
    	System.out.println("=== Redirect System Output => "+MsAgentDo.OutputFile);
    	_agentOut.setMaxFileCount(MppContext.getInt(CONF_REDIRECT_OUTPUT_MAX_FILE_COUNT,10));
    	_agentOut.setMaxFileSize(MppContext.getInt(CONF_REDIRECT_OUTPUT_MAX_FILE_SIZE,5) * 1024*1024);
    	_agentOut.setLogFileRollingMode(MppContext.getString(CONF_REDIRECT_OUTPUT_ROLLING_MODE, LogS.RollingMode_FileSize));
    	_agentOut.setMaxRetentionDays(MppContext.getInt(CONF_REDIRECT_OUTPUT_MAX_RETENTION_DAYS, 7));
        _agentOut.redirectSystemOut(true);
    }
    
    public void before(CStarter other) throws Exception
    {
    }


    // 第一轮初始化（按照依赖顺序每一个都会调用到）
    public void init() throws Exception{
        // 打印转存
        if (MppContext.getBoolean(CONF_REDIRECT_OUTPUT, true))
        {
            try
            {
                redirectSystemOut();
            } catch (IOException exp)
            {
                exp.printStackTrace();
            }
        }
    }
    
    public void start() throws Exception
    {
        // 代理上不需要分析类，浪费性能
        CodeUtil.setEnable(false);

        // 启动NIO RPC服务
        NioService.getInstance().startNioService();
        
        // 代理上也要提供JAVA远程调试的服务
        CJavaAgentMgr.getMe().start();
        
        System.out.println("=== PID = "+ToolUtilities.getProcessID());
        initPIDSaver();

    }

    
    public static void initPIDSaver()
    {
        // 保存当前PID
        try
        {
            ToolUtilities.saveFile(MsAgentDeployTool.AGENT_PID_FILE, ToolUtilities.getProcessID(), "UTF-8", false);
        } catch (Exception exp1)
        {
            exp1.printStackTrace();
            System.exit(0);
        }

        // 退出时删掉当前PID文件
        Runtime.getRuntime().addShutdownHook(new Thread()
        {
            // hook中不能打印东西，以免和output打印互锁
            public void run()
            {
                try
                {
                    System.out.println("|===== Quit Process Now =====|");
                    
                    int pid = ToolUtilities.getInteger(new String(ToolUtilities.readFile(MsAgentDeployTool.AGENT_PID_FILE)), -1);
                    if (pid != ToolUtilities.getInteger(ToolUtilities.getProcessID(), -1))
                        return;
                    
                    ToolUtilities.deleteFileFolder(MsAgentDeployTool.AGENT_PID_FILE);
                    ToolUtilities.info("AgentBasicStarter", "Succeed to deleted pid file : " + MsAgentDeployTool.AGENT_PID_FILE);
                } catch (IOException exp)
                {
                    ToolUtilities.warning("AgentBasicStarter", "Failed to read pid file : " + MsAgentDeployTool.AGENT_PID_FILE + "\n"+ToolUtilities.getExceptionStatck(exp));
                }
            }
        });
    }
}
