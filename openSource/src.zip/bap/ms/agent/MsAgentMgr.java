package bap.ms.agent;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.curator.framework.recipes.cache.ChildData;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.nutz.dao.Cnd;
import org.nutz.repo.cache.simple.LRUCache;

import com.cdao.dto.CPager;
import com.cdao.impl.entity.field.GID;
import com.cdao.mgr.CDaoCenter;
import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoUtil;
import com.cdao.mgr.action.UpdateAction;
import com.cdao.model.CDoBasic;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dfc.microService.MsMgr;
import com.leavay.dfc.microService.ZkAgentInfo;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.ms.warehouse.MsAgentDto;
import com.leavay.ms.warehouse.MsAgentInfoDto;
import com.leavay.ms.warehouse.WhFolder;
import com.leavay.ms.warehouse.WhPackage;
import com.leavay.ms.warehouse.WhPackageConf;
import com.leavay.starter.StarterConf;
import com.leavay.starter.StarterMain;

import bap.ms.CMsCenter;
import md.ms.MsAgentDo;

public class MsAgentMgr
{
  protected static MsAgentMgr instance = null;
    
    public final static String LOG = "Micro Service Center";
    
    public synchronized static MsAgentMgr getMe()
    {
        if (instance == null)
        {
            instance = new MsAgentMgr();
        }
        return instance;
    }
    
    protected MsAgentMgr()
    {
       
    }
    
    public void initBeforeDao()
    {
        CDaoCenter.addInitModel(MsAgentDo.class);
    }
    
    public final static String WH_PATH = "warehouse";
    public final static File WH_ROOT = new File(WH_PATH);
    
    // 以相对路径获取包绝对路径
    public static File getPackageFile(String relpath)
    {
      return new File(WH_ROOT, relpath);  
    }
    
    public List loadWhCatalog(List<String> path)
    {
        List lst = new LinkedList();
        
        String sPath = WH_PATH;
        if (!ToolUtilities.isObjectEmpty(path))
            sPath += "/"+ToolUtilities.listToString(path, "/");
        
        File f = new File(sPath);
        File[] child = f.listFiles();
        if (child != null)
            for (File cf : child)
            {
                if (cf.isDirectory())
                    lst.add(new WhFolder().setName(cf.getName()));
                else if (cf.isFile())
                {
                    if ("zip".equalsIgnoreCase(ToolUtilities.getExtOfFile(cf.getName())))
                        lst.add(loadWhPackage(cf));
                }
            }
        
        return lst;
    }
    
    public List<WhPackage> loadAllWhPackage(List<String> path)
    {
        List<WhPackage> lstRet = new LinkedList<WhPackage>();
        
        List lst = loadWhCatalog(path);
        for (Object o : lst)
        {
            if (o instanceof WhFolder)
            {
                WhFolder fd = (WhFolder)o;
                List<String> childPath = new LinkedList();
                if (path != null)
                    childPath.addAll(path);
                childPath.add(fd.getName());
                
                List cOfc = loadAllWhPackage(childPath);
                if (!cOfc.isEmpty())
                    lstRet.addAll(cOfc);
            }else if (o instanceof WhPackage)
                lstRet.add((WhPackage) o);
        }
        
        return lstRet;
    }
    
    // pkgPath必须是基于WH_ROOT的相对路径
    public StarterConf loadPackageConfig(String pkgPath) throws Exception
    {
        if (CmnUtil.isStringEmpty(pkgPath))
            return null;
        
        File confFile = getPackageConfFile(pkgPath);
        if (confFile == null || !confFile.exists())
            return null;
        
        return StarterMain.loadConfig(confFile.getAbsolutePath());
    }

    // pkgPath必须是基于WH_ROOT的相对路径
    public static File getPackageConfFile(String pkgPath)
    {
        File pkgFile = getPackageFile(pkgPath);
        File confFile = new File(pkgFile.getParentFile(), ToolUtilities.getFileNameWithoutExt(pkgFile.getAbsolutePath())+".xml");
        return confFile;
    }
    
    // 传入绝对路径，返回相对WH_ROOT的相对路径，且统一转换为/
    public String getPackageRelatedPath(String absPath)
    {
        return  ToolUtilities.getRelatedPath(absPath, WH_ROOT.getAbsolutePath());
    }
    
    public WhPackage loadWhPackage(File zipFile)
    {
        WhPackage pkg = new WhPackage();
        
        String pkgName = ToolUtilities.getPureFileName(zipFile.getName());
        String relPath = getPackageRelatedPath(zipFile.getAbsolutePath());
        CmnUtil.assertNotEmpty(relPath, "Please select valid package");
        
        pkg.setKey(pkgName);
        pkg.setPath(zipFile.getAbsolutePath());
        try
        {
            pkg.setLstConf(loadWhConfig(zipFile));
        } catch (Throwable exp)
        {
            ToolUtilities.throwRuntimeException(exp);
        }
        return pkg;
    }
    
    public List<WhPackageConf> loadWhConfig(File zipFile) throws DocumentException, IOException
    {
        String purePath = ToolUtilities.getPureFileName(zipFile.getAbsolutePath());
        String confPath = purePath + ".xml";
        if (!ToolUtilities.isFileExist(confPath))
            return null;
        
        List<WhPackageConf> lstConf = new LinkedList<WhPackageConf>();
        Element ele = ToolUtilities.xmlString2Dom4j(ToolUtilities.readFile(confPath, "UTF-8"));
        for (Object c : ele.elements("Config"))
        {
            if (c instanceof Element)
            {
                Element eleC = (Element)c;
                WhPackageConf conf = new WhPackageConf();
                conf.setKey(eleC.attributeValue("key"));
                conf.setLabel(eleC.attributeValue("label"));
                conf.setDesc(eleC.attributeValue("desc"));
            }
        }
                
        return lstConf;
    }
    
    public void updateAgent(MsAgentDto newAgent, boolean rebuild) throws Exception
    {
        MsAgentDo orgAgent = (MsAgentDo) CDaoClient.getIntf().getDo(newAgent.getGid());
        ToolBasic.assertNotNull(orgAgent, "Agent is invalid or deleted");

        try
        {
            // 校验是否合法包路径，且是相对路径
            verifyPackagePath(newAgent);
            
            MsAgentDo newDo = CDaoUtil.convertDo(newAgent);

            if (newDo.isNameAuto())
                newDo.setName(null);

            newDo.autoUpdateValue();
            newDo.verify();

            updateMessage(orgAgent, "Update agent");
            CDaoClient.getIntf().updateDo(newDo);

            if (rebuild)
                rebuildAgent(newDo.getGid());
        } catch (Throwable err)
        {
            updateMessage(orgAgent, "Failed to update agent : " + ToolUtilities.getExceptionStatck(err, true));
            ToolUtilities.throwException(err);
        }
    }
    
    public void rebuildAgent(GID agentGid) throws Exception
    {
        MsAgentDo agent = (MsAgentDo) CDaoClient.getIntf().getDo(agentGid);
        ToolBasic.assertNotNull(agent, "Agent is invalid or deleted");
        
        // 无需部署的就不部署了
        if (!agent.isAutoDeploy())
        {
            updateMessage(agent, "This agent is wild, please deploy manully");
            return;
        }
        
        try
        {
            updateMessage(agent, "Terminate and remove agent file");
            MsAgentDeployTool.stopAndRemove(agent);

            updateMessage(agent, "Begin deploy and startup");
            MsAgentDeployTool.deployAndStart(agent);
            
            updateMessage(agent, "Finish rebuild agent");
        } catch (Throwable err)
        {
            updateMessage(agent, "Failed to rebuild : " + ToolUtilities.getExceptionStatck(err, true));
            ToolUtilities.throwException(err);
        }
    }
    
    public MultiPageResult<MsAgentDto> queryAgent(Cnd cnd, CPager pager) throws Exception
    {
        MultiPageResult rs = CDaoClient.getIntf().queryDoPage(MsAgentDo.class.getName(), cnd, pager);
        if (rs.hasData())
            rs.setListData(CDaoUtil.convertDtos(rs.getListData(), MsAgentDto.class));
        
        return rs;
    }
    
    public MsAgentDo queryAgentByCode(String agentCode) throws Exception
    {
        return (MsAgentDo) CDaoClient.getIntf().queryDo(MsAgentDo.class.getName(), Cnd.where(MsAgentDo.Code, "=", agentCode));
    }
    
    public MsAgentInfoDto queryAgentInfo(String agentCode) throws Exception
    {
        Map<String, MsAgentInfoDto> map = queryAgentInfo(ToolUtilities.newHashSet(agentCode));
        return map==null?null:map.get(agentCode);
    }
    
    // 不可能有1万个代理，缓存一下时间也不奇怪
    // 左：进程启动时间，右：变更时间
    LRUCache<String, Pair<Long, Long>> _cacheTime = new LRUCache(10000);
    ReentrantLock _lockChangeTime = new ReentrantLock();
    
    // 获取最近一次有发生变化的时间
    public long getLastChangedTime(String key)
    {
        _lockChangeTime.lock();
        try
        {
            Pair<Long, Long> p = _cacheTime.get(key);
            return p == null ? -1 : p.getValue();
        } finally
        {
            _lockChangeTime.unlock();
        }
    }
    
    // TRUE：有发生变化
    public boolean touchChangedTime(String key, long procStartTime)
    {
        _lockChangeTime.lock();
        try
        {
            Pair<Long, Long> p = _cacheTime.get(key);
            
            // 只有当原本不存在或者启动时间有变化，才记录到缓存
            if (p == null || p.getKey() != procStartTime)
            {
                _cacheTime.put(key, new Pair(procStartTime, System.currentTimeMillis()));
                return true;
            }
            
            return false;
        } finally
        {
            _lockChangeTime.unlock();
        }
    }
    
    public Map<String, MsAgentInfoDto> queryAgentInfo(Set<String> agentCode) throws Exception
    {
        Map<String, MsAgentInfoDto> mapRet = new HashMap<String, MsAgentInfoDto>();
        if (ToolUtilities.isObjectEmpty(agentCode))
            return mapRet;
        
        // 先查消息，同时也就确定了库里存在
        List lstMsg = CDaoClient.getIntf().cqueryDoList(MsAgentDo.class.getName(), Cnd.where(MsAgentDo.Code, "in", CDaoUtil.stringList2Sql(agentCode)), MsAgentDo.Code, MsAgentDo.Message);
        for (MsAgentDo o : (List<MsAgentDo>)lstMsg)
        {
            MsAgentInfoDto infoDto = new MsAgentInfoDto();
            infoDto.setMessage(o.getMessage());
            infoDto.setAgentID(o.getCode());
            
            mapRet.put(o.getCode(), infoDto);
        }
        
        // 再查远端负载信息
        List<ChildData> lstCache = MsMgr.getInstance().getConsumer().queryCachedAgents();
        for (ChildData cd : lstCache)
        {
            String rdn = ToolUtilities.getPureFileName(cd.getPath());
            if (agentCode.contains(rdn))
            {
                MsAgentInfoDto infoDto = mapRet.get(rdn);
                if (infoDto == null)
                {
                    infoDto = new MsAgentInfoDto().setAgentID(rdn); 
                    mapRet.put(rdn, infoDto);
                }
                
                ZkAgentInfo info = ZkAgentInfo.fromJson(new String(cd.getData()));
                
                // 缓存进程时间信息，以便计算最近一次变更到现在的时长
                touchChangedTime(rdn, info.getProcStartTime());
                infoDto.setLastUpdateDuration(System.currentTimeMillis() - getLastChangedTime(rdn));
                
                infoDto = ToolBasic.copyFields(info, infoDto, false, false);
                
                mapRet.put(rdn, infoDto);
            }
        }
        
        return mapRet;
    }

    public static void verifyPackagePath(MsAgentDto agent) throws Exception
    {
        // 本地代理或者SSH代理才校验包路径，否则视为无需自动部署的
        if (agent.isAutoDeploy())
            verifyPackagePath(agent.getPkgPath());
    }
    
    public static void verifyPackagePath(String path) throws Exception
    {
        // 校验是否合法包路径，且是相对路径
        if (!new File(WH_ROOT, path).exists())
            throw new Exception("Please select valid package");
    }
    
    public void createAgent(MsAgentDto agent) throws Exception
    {
        MsAgentDo o = CDaoUtil.convertDo(agent);

        // 校验是否合法包路径，且是相对路径
        verifyPackagePath(agent);
        
        o.autoUpdateValue();
        o.verify();
        o = (MsAgentDo) CDaoClient.getIntf().createDo(o);
        
        rebuildAgent(o.getGid());
    }
    
    public void terminateAgent(GID agtGid) throws Exception
    {
        MsAgentDo agt = (MsAgentDo) CDaoClient.getIntf().getDo(agtGid);
        if (!agt.isAutoDeploy())
            return;
        
        ToolBasic.assertNotNull(agt, "Agent is invalid or deleted");

        try
        {
            updateMessage(agt, "Begin terminate");

            MsAgentDeployTool.stopAgent(agt, 10000);

            updateMessage(agt, "Finish terminate");
            CMsCenter.getMe().deleteAgentZkInfo(agt.getCode());
        } catch (Throwable err)
        {
            updateMessage(agt, "Failed to terminate : " + ToolUtilities.getExceptionStatck(err, true));
            ToolUtilities.throwException(err);
        }
    }
    
    public void killAndDeleteAgent(GID agtGid) throws Exception
    {
        MsAgentDo agt = (MsAgentDo) CDaoClient.getIntf().getDo(agtGid);
        ToolBasic.assertNotNull(agt, "Agent is invalid or deleted");

        try
        {
            if (agt.isAutoDeploy())
            {
                updateMessage(agt, "Terminate and remove agent file");
                MsAgentDeployTool.stopAndRemove(agt);
            }

            updateMessage(agt, "Delete agent");
            CDaoClient.getIntf().deleteDo(agt);
            CMsCenter.getMe().deleteAgentZkInfo(agt.getCode());

            MsAgentDeployTool.deleteAgentFile(agt);
        } catch (Throwable err)
        {
            updateMessage(agt, "Failed to kill and delete : " + ToolUtilities.getExceptionStatck(err, true));
            ToolUtilities.throwException(err);
        }
    }
    
    public void startAgent(GID agtGid) throws Exception
    {
        MsAgentDo agt = (MsAgentDo) CDaoClient.getIntf().getDo(agtGid);
        ToolBasic.assertNotNull(agt, "Agent is invalid or deleted");

        try
        {
            updateMessage(agt, "Start agent");
            MsAgentDeployTool.startAgent(agt);
            updateMessage(agt, "Finish send startup command");
        } catch (Throwable err)
        {
            updateMessage(agt, "Failed to startup : " + ToolUtilities.getExceptionStatck(err, true));
            ToolUtilities.throwException(err);
        }
    }
    
    public MultiPageResult<String> readOutput(GID agtGid, int startLine, int lastLineCount) throws Exception
    {
        MsAgentDo agt = (MsAgentDo) CDaoClient.getIntf().getDo(agtGid);
        if (agt == null)
            return null;

        if (!agt.isLocal() && !agt.isSsh())
            throw new Exception("Only can read output of local or ssh agent : " + agt.getName());

        return MsAgentDeployTool.readLastOutput(agt, startLine, lastLineCount);
    }
    
    public void updateMessage(MsAgentDo agent, String msg)
    {
        _lazyUpdateMsg.add(new Pair(agent.getGid(), ToolUtilities.getCurrentTime(true)+" : " + msg));
    }
    
    LazyPool<Pair<GID, String>> _lazyUpdateMsg = new LazyPool<Pair<GID, String>>(1000)
    {
        public void handle(List<Pair<GID, String>> objects)
        {
            if (ToolUtilities.isObjectEmpty(objects))
                return;
            
            Map<GID, String> map = new HashMap<GID, String>();
            for (Pair<GID, String> p : objects)
            {
                map.put(p.getKey(), p.getValue());
            }
            
            List<UpdateAction> lstUpdate = new LinkedList<UpdateAction>();
            for (Entry<GID, String> ent : map.entrySet())
            {
                GID gid = ent.getKey();
                UpdateAction act = new UpdateAction().setClassName(gid.getClassName()).setCnd(Cnd.where(CDoBasic.UUID, "=", gid.getUuid()));
                act.setUpdateValue(MsAgentDo.Message, ent.getValue());
                lstUpdate.add(act);
            }
            
            try
            {
                CDaoClient.getIntf().batchUpdate(lstUpdate);
            } catch (Exception exp)
            {
                exp.printStackTrace();
            }
        }
        
    };
}
