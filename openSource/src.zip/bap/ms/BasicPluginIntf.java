package bap.ms;

import java.util.Collection;
import java.util.Map;

import bap.plugin.CPluginExportPackage;
import bap.plugin.CPluginProjectDto;
import cell.function.IBiConsumer;

// 微服务体系中提供插件更新服务
public interface BasicPluginIntf
{
    public long getPluginTag() throws Exception;
    
    // 如果没有则返回null
    // 如果有更新，则返回类二进制流
    public Map<String, byte[]> downloadPlugin(boolean onlyPublic, Collection<String> excludeNames) throws Exception;
    
    public void streamDownloadPlugin(IBiConsumer<String, byte[]> consumer, boolean onlyPublic, Collection<String> excludeNames)  throws Exception;

    // 导出工程到插件
    public CPluginProjectDto exportPublishPlugin(CPluginExportPackage pkg, boolean publishNow) throws Exception;
    
    public default boolean isSupportDelta() {
        return false;
    }
}
