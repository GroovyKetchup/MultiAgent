package bap.ms;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException.NoNodeException;
import org.apache.zookeeper.KeeperException.NodeExistsException;
import org.nutz.dao.Cnd;
import org.nutz.dao.Sqls;
import org.nutz.dao.impl.NutDao;
import org.nutz.dao.impl.NutTxDao;
import org.nutz.dao.impl.SimpleDataSource;
import org.nutz.dao.pager.Pager;
import org.nutz.dao.sql.Sql;
import org.nutz.dao.sql.SqlCallback;
import org.nutz.dao.util.cri.SqlExpression;

import com.cdao.mgr.CDao;
import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoCenter;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.StringLock;
import com.leavay.common.util.StringLock.LockObject;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.cjson.CJson;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.dfc.mgr.disCache.DCacheService;
import com.leavay.dfc.mgr.disCache.DCacheUtil;
import com.leavay.dfc.microService.MsCenterConf;
import com.leavay.dfc.microService.MsCenterInfo;
import com.leavay.dfc.microService.MsCenterService;
import com.leavay.dfc.microService.MsConsumer;
import com.leavay.dfc.microService.MsHelper;
import com.leavay.dfc.microService.MsIntf;
import com.leavay.dfc.microService.MsMgr;
import com.leavay.dfc.microService.MsProvider;
import com.leavay.dfc.microService.MsProviderIntf;
import com.leavay.dfc.microService.MsRegAgentPath;
import com.leavay.dfc.microService.MsRegEntryInfo;
import com.leavay.dfc.microService.MsUtil;
import com.leavay.dfc.microService.MsZkConst;
import com.leavay.dfc.microService.ZkAgentInfo;
import com.leavay.dfc.microService.bean.MsAlarmBean;
import com.leavay.dfc.microService.bean.MsTrackBean;
import com.leavay.dfc.microService.track.MsTrackClient;
import com.leavay.dfc.microService.track.MsTrackUtil;
import com.leavay.dfc.microService.track.filter.MsFilterReq;
import com.leavay.dfc.microService.track.filter.MsFilterReqList;
import com.leavay.model.exception.McException;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcServer;
import com.project.gui.common.DBDataSourceIntf;
import com.project.gui.common.GuiUtil;

import bap.md.CMsAgent;
import bap.md.CMsEntryExclude;
import bap.md.CMsEntryInclude;
import bap.md.CMsRegEntry;
import bap.ms.agent.MsAgentMgr;
import md.ms.MsAgentDo;
import modeldef.com.leavay.ms.MsEntryAgentExclude;
import ms.cmn.HostPort;

public class CMsCenter
{
    protected static CMsCenter _me = null;
    
    public final static String LOG = "Micro Service Center";
    
    public synchronized static CMsCenter getMe()
    {
        if (_me == null)
        {
            _me = new CMsCenter();
        }
        return _me;
    }
    
    protected CMsCenter()
    {
    }
    
    public void initBeforeDao() throws Exception
    {
        CRpcServer.registService(CMsCenterService.class, new CMsCenterServiceImpl());

        CDaoCenter.addInitModel(CMsEntryInclude.class);
        CDaoCenter.addInitModel(CMsEntryExclude.class);
        CDaoCenter.addInitModel(CMsRegEntry.class);
        
        // 初始化微服务代理管理后台
        MsAgentMgr.getMe().initBeforeDao();
    }
    
    public MsCenterInfo getCenterInfo()
    {
        MsCenterInfo info = new MsCenterInfo();
        info.setHost(MsCenterConf.getCenterHost());
        info.setPort(MppContext.getInt(CRpcServer.CONF_NIO_PORT, -1));
        return info;
    }

    CuratorFramework _client;
    MsTrackUtil _trackUtil;
    public boolean initService() throws Exception
    {
        return initService(null);
    }
    
    protected void initClientUtil()
    {
        DCacheUtil.setAsCenter();
        
        DCacheService.getInstance().start();
        DCacheUtil.setLocalCache(DCacheService.getInstance().checkStarted());
        
        // 因为MsTrackUtil中捆绑了dfcutil的一些信息例如：isRunInServer，所以必须这样初始化一下
//        dfcutil.setRunInServer();
//        CNClientUtil.setBEHost(ToolUtilities.getCurrentIP());
//        CNClientUtil.setRMIPort(MppContext.getRmiPort());
//        CNClientUtil.setNioPort(CRpcServer.getNioPort());
    }
    
    public boolean initService(List<MsRegEntryInfo> extSystemService) throws Exception
    {
        if (!MsCenterConf.isEnableMsCenter())
            return false;
        
        // 初始化兼容老的实现
        initClientUtil();
        
        _extSystemEntryList = extSystemService;
        
        // 连接ZK
        System.out.println("Starting connect ZK server : " + MsCenterConf.getZkAddr());
        _client = CuratorFrameworkFactory.builder().connectString(MsCenterConf.getZkAddr()).retryPolicy(new ExponentialBackoffRetry(1000, 3)).sessionTimeoutMs(MsZkConst.DEFAULT_ZK_SESSION_TIMEOUT_MS).build();
        _client.start();
        if (!_client.blockUntilConnected(30, TimeUnit.SECONDS))
            throw new Exception("Failed to connect zookeeper server : " + MsCenterConf.getZkAddr());
        
        // 注册中心就连本地集群的追踪服务
        _trackUtil = new MsTrackUtil(MsCenterConf.getZkAddr(), MsHelper.getMyMachineID());
        
        // 注册自身信息
        updateCenterInfo();
        
        // 初始化服务注册表
        System.out.print("Begin init ZK registry cache : " + MsCenterConf.getZkAddr()+" ........ ");
        uploadFullRegCache(true);
        _srvThread.start();
        System.out.println(" OK ");
        
        // 启动本地微服务提供/参与
        startLocalMicroService();
        
        return true;
    }
    
    public void startLocalMicroService()
    {
        if (!MsCenterConf.isEnableMsCenter())
            return;
        
        // 只要支持微服务，默认就必须支持微服务消费者
        MsMgr.getInstance().init(MsConsumer.getInstance(), MsProvider.getInstance(), false, false);
        try
        {
            System.out.println("Begin connect zookeeper ... ");
            MsConsumer.getInstance().initService(MsCenterConf.getZkAddr(), MsUtil.getMachineID_CenterMaster(), true);
        } catch (Throwable exp)
        {
            ToolUtilities.fatal(LOG, "Failed to start http service for CONSUMER", exp);
            System.exit(0);
        }

        // 启动微服务供应者
        if (MsCenterConf.isProvideService())
        {
            try
            {
                System.out.println("Starting micro service provider ... ");
                MsProvider.getInstance().startCenterService(MsConsumer.getInstance(), ClassFactory.getFactory());
            } catch (Throwable exp)
            {
                ToolUtilities.fatal(LOG, "Failed to start micro service for PROVIDER", exp);
                System.exit(0);
            }
        }
        
        // 暂不考虑级联
        // 启动与上级微服务集群级联的服务 （同时会启动插件桥接器）
//        CMsEmbMemberService.startInLeavay();
        
        MsHelper.setAsCenter(MsConsumer.getInstance());
    }
    
    public void updateCenterInfo() throws Exception
    {
        MsCenterInfo info = getCenterInfo();
        byte[] bt = CJson.toJson(info).getBytes();

        // 无条件删了再建一次，因为有可能重启残留前一次启动留下的临时节点
        try
        {
            _client.delete().deletingChildrenIfNeeded().forPath(MsZkConst.PATH_MS_CENTER);
        }catch(NoNodeException noNode)
        {
            // ignore no node
        }
        _client.create().creatingParentContainersIfNeeded().withMode(CreateMode.PERSISTENT).forPath(MsZkConst.PATH_MS_CENTER, bt);
    }
    
    public void deleteAgentZkInfo(String agentCode) throws Exception
    {
        try
        {
            _client.delete().deletingChildrenIfNeeded().forPath(MsZkConst.getPath_AgentMo(agentCode));
        }catch(NoNodeException noNode)
        {
            // ignore no node
        }
    }

    public boolean startService() throws Exception
    {
        if (!MsCenterConf.isEnableMsCenter())
            return false;
        
        // 作为中央服务器，提供基础服务
        CRpcServer.registService(MsIntf.class.getName(), CMsImpl.getMe());
        CRpcServer.registService(MsProviderIntf.class.getName(), CMsImpl.getMe());
        
        int limitRows = MsCenterConf.getTrackKeepRows();
        
        MsTrackUtil.uploadTrackRowsLimit(limitRows);
        return true;
    }


    public DBDataSourceIntf getTrackDB()
    {
        return MsCenterConf.getTrackDB();
    }
    
    public NutTxDao getTrackDao()
    {
        NutTxDao dao = new NutTxDao(prepareCenterDao());
        dao.beginRC();
        return dao;
    }
    
    static SimpleDataSource _ds = null;
    static NutDao _dao = null;
    protected synchronized NutDao prepareCenterDao()
    {
        if (_ds == null || _dao == null)
        {
            if (_ds != null)
                _ds.close();

            DBDataSourceIntf ds = getTrackDB();
            if (ds == null)
                throw new RuntimeException("Please setup track center DB in config file : " + MsCenterConf._file);
            
            try
            {
                _ds = new SimpleDataSource();
                
                _ds.setDriverClassName(ds.getDriverClass());
                _ds.setUrl(ds.getUrl());
                _ds.setUsername(ds.getUserName());
                _ds.setPassword(ds.getPassword());
            } catch (Exception exp)
            {
                ToolUtilities.throwRuntimeException(exp);
            }

            _dao = new NutDao(_ds);
        }

        return _dao;
    }

    public MultiPageResult<MsAlarmBean> queryAlarm(SqlExpression whereCnd, int startPos, int pageSize)
    {
        NutTxDao dao = getTrackDao();
        try
        {
            Cnd cnd = Cnd.NEW();
            if (whereCnd != null)
                cnd = Cnd.where(whereCnd);
            
            cnd.orderBy(MsAlarmBean._alarmTime, "DESC");
            
            int startPage = startPos/pageSize + 1;
            
            List<MsAlarmBean> lstData = dao.query(MsAlarmBean.class, cnd, new Pager(startPage, pageSize));
            MultiPageResult rs = new MultiPageResult();
            rs.setStartPos(startPos);
            rs.setListData(lstData);
            return rs;
        }finally
        {
            dao.close();
        }
    }

    public static enum ALARM_STASTIC_KEY{cause, rootCause, level, agent, message};
    public LinkedHashMap<Comparable, Number> queryAlarmStastic(ALARM_STASTIC_KEY stasticKey, int limit)
    {
        final LinkedHashMap<Comparable, Number> sts = new LinkedHashMap();
        NutTxDao dao = getTrackDao();
        try
        {
            SqlCallback stsCallBack = new SqlCallback()
            {
                public Object invoke(Connection conn, ResultSet rs, Sql sql) throws SQLException
                {
                    while (rs.next())
                    {
                        Comparable key = null;
                        if (stasticKey == ALARM_STASTIC_KEY.level)
                            key = rs.getInt(1);
                        else
                            key = rs.getString(1);
                        
                        Long cnt = rs.getLong(2);
                        sts.put(key, cnt);
                    }
                    return null;
                }
            };
            
            String grpField = MsAlarmBean._errorType;
            switch(stasticKey)
            {
            case cause:
                grpField = MsAlarmBean._errorType;
                break;
            case rootCause:
                grpField = MsAlarmBean._rootCauseType;
                break;
            case level:
                grpField = MsAlarmBean._level;
                break;
            case message:
                grpField = MsAlarmBean._message;
                break;
            case agent:
            default:
                grpField = MsAlarmBean._dstAgent;
                break;
            }
            Sql sql = Sqls.create("select "+grpField+", count(1) as cnt from "+MsAlarmBean.TableName+" group by("+grpField+") order by cnt desc limit "+limit);
            
            sql.setCallback(stsCallBack);
            sql = dao.execute(sql);
            return sts;
        }finally
        {
            dao.close();
        }
    }
    
    public void deleteAlarmBatch(Set<String> setAlarmID)
    {
        NutTxDao dao = getTrackDao();
        try
        {
            List<MsAlarmBean> lstO = new ArrayList();
            for (String s : setAlarmID)
            {
                MsAlarmBean b = new MsAlarmBean();
                b.setMyID(s);
                lstO.add(b);
                if (lstO.size() >= 1000)
                {
                    dao.delete(lstO);
                    dao.commit();
                    lstO.clear();
                }
            }
            
            if (!lstO.isEmpty())
            {
                dao.delete(lstO);
                dao.commit();
                lstO.clear();
            }
        }finally
        {
            dao.close();
        }
    }
    
    public int deleteAlarmWhere(SqlExpression where)
    {
        NutTxDao dao = getTrackDao();
        try
        {
            int cnt = dao.clear(MsAlarmBean.class, Cnd.where(where));
            dao.commit();
            return cnt;
        }finally
        {
            dao.close();
        }
    }
    
    public CDao newDao() throws Exception
    {
        return CDaoClient.newDao();
    }

    public MsTrackUtil getMsTrackUtil()
    {
        return _trackUtil;
    }
    
    public MsTrackClient getMsTrackCenterClient()
    {
        if (getMsTrackUtil() == null)
            throw new RuntimeException("Please enable micro service first");
        
        return getMsTrackUtil().getTrackClient();
    }
    
    public HostPort getTrackCenter() throws Exception
    {
        ZkAgentInfo cent = getMsTrackUtil().getTrackClient().queryTrackCenter();
        if (cent == null)
            return null;
        
        return new HostPort().setHost(cent.getRegistAddr()).setPort(cent.getNioPort()).setKey(cent.getAgentID()).setName(cent.getName());
    }
    
    public MultiPageResult<MsTrackBean> queryTrack(boolean getCount, int startPos, int pageSize) throws Exception
    {
        return getMsTrackCenterClient().getRemoteIntf().queryTrack(getCount, startPos, pageSize);
    }
    
    public void startTrackMonitor(long interval) throws Exception
    {
        getMsTrackCenterClient().getRemoteIntf().startTrackMonitor(interval);
    }
    
    public void stopTrackMonitor() throws Exception
    {
        getMsTrackCenterClient().getRemoteIntf().stopTrackMonitor();
    }

    public Map<String, Object> queryTrackData(MsFilterReqList reqList) throws Exception
    {
        return getMsTrackCenterClient().getRemoteIntf().queryTrackData(reqList);
    }
    
    public Object queryTrackData(MsFilterReq req) throws Exception
    {
        return getMsTrackCenterClient().getRemoteIntf().queryTrackData(req);
    }

    public boolean isTrackMonitorStarted() throws Exception
    {
        return getMsTrackCenterClient().getRemoteIntf().isMonitorStarted();
    }
    
    Thread _srvThread = new Thread("Micro Service Thread"){
        public void run()
        {
            while (true)
            {
                try
                {
                    uploadFullRegCache(false);
                }catch(Throwable err)
                {
                    ToolUtilities.error(LOG, err);
                }
                
                ToolUtilities.sleep(5*60000);
            }
        }
    };
    
    public List<CMsRegEntry> getAllEntry() throws Exception
    {
        try (CDao dao = newDao())
        {
            return dao.queryDoList(CMsRegEntry.class, null);
        }
    }
    
    List<MsRegEntryInfo> _extSystemEntryList = null;
    public synchronized List<MsRegEntryInfo> getSystemRegEntry()
    {
        List<MsRegEntryInfo> lstSys = new ArrayList();
        
        // 中心对本地集群提供调用上层服务的接口
        MsRegEntryInfo entryCenterSrv = new MsRegEntryInfo();
        entryCenterSrv.setSystemFixed(true);
        entryCenterSrv.setRegRdn(MsCenterService.REG_RDN_KEY);
        entryCenterSrv.setServiceImplement(CMsCenterServiceImpl.class.getName());
        entryCenterSrv.setServiceKey(MsCenterService.class.getName());
        entryCenterSrv.setServiceLabel(GuiUtil.getString(MsCenterService.class.getSimpleName()));
        entryCenterSrv.setRouteTable(ToolUtilities.newArrayList(new MsRegAgentPath(MsUtil.getMachineID_CenterMaster(), null)));
        lstSys.add(entryCenterSrv);
        
        // 暂不支持RAP平台作为下级级联到上级
//         中心对本地集群提供调用上层服务的接口
//        MsRegEntryInfo entryCenterBridgeSrv = new MsRegEntryInfo();
//        entryCenterBridgeSrv.setSystemFixed(true);
//        entryCenterBridgeSrv.setRegRdn(MsCenterBridgeService.REG_RDN_KEY);
//        entryCenterBridgeSrv.setServiceKey(MsCenterBridgeService.class.getName());
//        entryCenterBridgeSrv.setServiceLabel(dfcutil.getString(MsCenterBridgeService.class.getSimpleName()));
//        entryCenterBridgeSrv.setRouteTable(ToolUtilities.newArrayList(new MsRegAgentPath(MsUtil.getMachineID_CenterMaster(), null)));
//        lstSys.add(entryCenterBridgeSrv);
        
        if (_extSystemEntryList != null)
            lstSys.addAll(_extSystemEntryList);
        
        return lstSys;
    }
    
    public Map<String, MsRegEntryInfo> getAllEntryInfo() throws Exception
    {
        Map<String, MsRegEntryInfo> mapReg = new HashMap<String, MsRegEntryInfo>();
        List<CMsRegEntry> allEntry = getAllEntry();
        for (CMsRegEntry ent : allEntry)
        {
            MsRegEntryInfo info = ent.toInfo(null, null);
            
            mapReg.put(info.getServiceKey(), info);
        }
        
        List<MsRegEntryInfo> lstSysEntry = getSystemRegEntry();
        for (MsRegEntryInfo ent : lstSysEntry)
            mapReg.put(ent.getServiceKey(), ent);
        
        // 限定代理
        List<CMsEntryInclude> lstAllInc = CDaoClient.getIntf().queryDoList(CMsEntryInclude.class.getName(), null);
        for (CMsEntryInclude lnk : lstAllInc)
        {
            for (MsRegEntryInfo entryInfo : mapReg.values())
            {
                if (ToolUtilities.isStringEqual(entryInfo.getRegRdn(), lnk.getMasterKey()))
                {
                    entryInfo.addRoutePath(new MsRegAgentPath(lnk.getLinkAgent(), lnk.getRouteID()));
                }
            }
        }
        
        // 排除代理
        List<CMsEntryExclude> lstAllExl = CDaoClient.getIntf().queryDoList(CMsEntryExclude.class.getName(), null);
        for (CMsEntryExclude lnk : lstAllExl)
        {
            for (MsRegEntryInfo entryInfo : mapReg.values())
            {
                if (ToolUtilities.isStringEqual(entryInfo.getRegRdn(), lnk.getMasterKey()))
                {
                    entryInfo.addExcludeAgent(lnk.getLinkAgent());
                }
            }
        }
        
        return mapReg;
    }
    
    public List<MsRegAgentPath> getIncludeAgentID(String entryUuid) throws Exception
    {
        List<CMsEntryInclude> lstDo = CDaoClient.getIntf().queryDoList(CMsEntryInclude.class.getName(), Cnd.where(CMsEntryInclude.MasterKey, "=", entryUuid), CMsEntryInclude.LinkAgent, CMsEntryInclude.RouteID);
        if (ToolUtilities.isObjectEmpty(lstDo))
            return null;
        else
        {
            List<MsRegAgentPath> lstRet = new ArrayList();
            for (CMsEntryInclude agt : lstDo)
            {
                lstRet.add(new MsRegAgentPath(agt.getLinkAgent(), agt.getRouteID()));
            }
            return lstRet;
        }
    }
    
    public List<MsEntryAgentExclude> getExcludeAgent(String entryRdn) throws McException
    {
        return null;
    }
    
    public List<String> getExcludeAgentID(String entryRdn) throws McException
    {
        return null;
    }
  
    StringLock _lockRegistry = new StringLock();
    /**
     * 注册微服务
     * 
     * @param regEntry ：微服务信息
     * @param deleteEntry ：是否删掉旧的完全重建
     * @param rebuildRoute : 是否删掉旧的路由表（含白名单黑名单），重建路由。如果为FALSE则为增量式覆盖
     */
    public void registService(MsRegEntryInfo regEntry, boolean deleteEntry, boolean rebuildRoute) throws Exception
    {
        LockObject lock = _lockRegistry.lockDN(regEntry.getServiceKey());
        try (CDao dao = newDao())
        {
            CMsRegEntry entryDo = dao.queryDo(CMsRegEntry.class, CMsRegEntry.Name, regEntry.getServiceKey());
            if (entryDo != null && deleteEntry)
            {
                dao.deleteDo(entryDo);
                entryDo = null;
            }

            boolean create = false;
            if (entryDo == null)
            {
                create = true;
                entryDo = new CMsRegEntry();
                entryDo.setByInfo(regEntry);
                entryDo = (CMsRegEntry) dao.createDo(entryDo);
            } else
            {
                create = false;
                entryDo.setByInfo(regEntry);
                dao.updateDo(entryDo);
            }

            if (rebuildRoute || create)
            {
                setIncludeAgents(dao, entryDo, regEntry.getRouteTable());
                setExcludeAgents(dao, entryDo, regEntry.getExcludeAgents());
            } else
            {
                // 追加新增的路由信息
                MsRegEntryInfo orgEntry = entryDo.toInfo(getIncludeAgentID(entryDo.getUuid()), getExcludeAgentID(entryDo.getUuid()));
                if (regEntry.getRouteTable() != null)
                {
                    // 相同代理的路由信息会被完整替换掉，其它代理的不变
                    orgEntry.overwriteRouteTable(regEntry.getRouteTable());
                    setIncludeAgents(dao, entryDo, orgEntry.getRouteTable());
                }

                if (regEntry.getExcludeAgents() != null)
                {
                    for (String exAgt : regEntry.getExcludeAgents())
                        if (!orgEntry.getExcludeAgents().contains(exAgt))
                            orgEntry.addExcludeAgent(exAgt);

                    setExcludeAgents(dao, entryDo, orgEntry.getExcludeAgents());
                }
            }

            dao.commit();

            // 全量更新entry下的include和exclude
            OnEvtEntryModified(entryDo, entryDo);
        } finally
        {
            lock.unlock();
        }
    }
    
    // 修改服务注册项的一些其它属性：标签、版本、实现类、仿真器等
    public void updateServiceAttribute(String serviceKey, String field, Object v) throws Exception
    {
        CmnUtil.assertTrue(ToolUtilities.contains(CMsRegEntry.FIELDS_UPDATABLE, field), "Denied to modify service attribute : " + field);
        
        LockObject lock = _lockRegistry.lockDN(serviceKey);
        try (CDao dao = newDao())
        {
            CMsRegEntry entryDo = dao.queryDo(CMsRegEntry.class, CMsRegEntry.Name, serviceKey);
            CmnUtil.assertNotNull(entryDo, "Service is invalid or removed");

            dao.updateDoField(entryDo, field, v);
            dao.commit();

            OnEvtEntryModified((CMsRegEntry) dao.queryDo(entryDo.getGid()), entryDo);
        } finally
        {
            lock.unlock();
        }
    }
    
    public void setIncludeAgents(CDao dao, CMsRegEntry entry, List<MsRegAgentPath> lstInclude) throws Exception
    {
        List<CMsEntryInclude> orgInc = dao.queryDoList(CMsEntryInclude.class, Cnd.where(CMsEntryInclude.MasterKey, "=", entry.getUuid()));
     
        // 删掉不需要的
        for (CMsEntryInclude org : orgInc)
        {
            if (lstInclude != null && lstInclude.contains(new MsRegAgentPath(org.getLinkAgent(), org.getRouteID())))
                continue;

            dao.deleteDo(org);
        }
        
        // 创建新增的
        if (lstInclude != null)
        {
            for (MsRegAgentPath create : lstInclude)
            {
                MsAgentDo extAgt = MsAgentMgr.getMe().queryAgentByCode(create.getAgent());
                if (extAgt == null)
                    throw new McException("Failed to query external agent : " + create.getAgent());

                boolean isNew = true;
                if (orgInc != null)
                {
                    for (CMsEntryInclude org : orgInc)
                    {
                        if (ToolUtilities.isStringEqual(org.getLinkAgent(), create.getAgent()) && ToolUtilities.isStringEqual(org.getRouteID(), create.getRouteID()))
                        {
                            isNew = false;
                            break;
                        }
                    }
                }

                if (isNew)
                {
                    CMsEntryInclude newInc = new CMsEntryInclude();
                    newInc.setMaster(entry.getGid(), CMsRegEntry.IncludeList);
                    newInc.setOwner(extAgt.getUuid()); // 与实际代理对象建立强依赖，以便删代理时自动删除
                    
                    newInc.setLinkAgent(extAgt.getCode());
                    newInc.setRouteID(create.getRouteID());
                    dao.createDo(newInc);
                }
            }
        }
    }
    
    public void setExcludeAgents(CDao dao, CMsRegEntry entry, List<String> lstExclude) throws Exception
    {
        List<CMsEntryExclude> orgExl = dao.queryDoList(CMsEntryExclude.class, Cnd.where(CMsEntryExclude.MasterKey, "=", entry.getUuid()));
     
        // 删掉不需要的
        for (CMsEntryExclude org : orgExl)
        {
            if (lstExclude != null && lstExclude.contains(org.getLinkAgent()))
                continue;

            dao.deleteDo(org);
        }
        
        // 创建新增的
        if (lstExclude != null)
        {
            for (String create : lstExclude)
            {
                MsAgentDo extAgt = MsAgentMgr.getMe().queryAgentByCode(create);
                if (extAgt == null)
                    throw new McException("Failed to query external agent : " + create);

                boolean isNew = true;
                if (orgExl != null)
                {
                    for (CMsEntryExclude org : orgExl)
                    {
                        if (ToolUtilities.isStringEqual(org.getLinkAgent(), create))
                        {
                            isNew = false;
                            break;
                        }
                    }
                }

                if (isNew)
                {
                    CMsEntryExclude newExl = new CMsEntryExclude();
                    newExl.setMaster(entry.getGid(), CMsRegEntry.ExcludeList);
                    newExl.setOwner(extAgt.getUuid()); // 与实际代理对象建立强依赖，以便删代理时自动删除
                    
                    newExl.setLinkAgent(extAgt.getCode());
                    dao.createDo(newExl);
                }
            }
        }
    }
    

    public void deleteService(String serviceKey) throws Exception
    {
        LockObject lock = _lockRegistry.lockDN(serviceKey);
        try (CDao dao = newDao())
        {
            // 再删数据
            CMsRegEntry entryDo = dao.queryDo(CMsRegEntry.class, CMsRegEntry.Name, serviceKey);
            if (entryDo != null)
                dao.deleteDo(entryDo);
            
            // 先删掉ZK里的，再提交
            deleteRegistry(serviceKey);
            dao.commit();
        } finally
        {
            lock.unlock();
        }
    }
    
    public void unregistAgent(String serviceKey, String agentKey) throws Exception
    {
        LockObject lock = _lockRegistry.lockDN(serviceKey);
        try (CDao dao = newDao())
        {
            CMsRegEntry entryDo = dao.queryDo(CMsRegEntry.class, CMsRegEntry.Name, serviceKey);
            if (entryDo == null)
                return;

//            MsRegEntryInfo entInfo = entryDo.toInfo(getIncludeAgentID(entryDo.getUuid()), getExcludeAgentID(entryDo.getUuid()));
//            entInfo.removeRoutePath(agentKey);
//            entInfo.removeExcludeAgent(agentKey);
//
//            setRegAgentLimit(entryDo.getUuid(), entInfo.getRouteTable(), entInfo.getExcludeAgents());
        } finally
        {
            lock.unlock();
        }
    }
    
    
    public CMsAgent queryAgent(String extAgentID) throws McException 
    {
        String host = ZkAgentInfo.getExtHost(extAgentID);
        int port = ZkAgentInfo.getExtPort(extAgentID);
        
        return queryAgent(host, port);
    }
    
    public CMsAgent queryAgent(String host, int port) throws McException 
    {
        return null;
    }
    
    // 只要是修改分布式缓存的，统一加锁，这个缓存全网只有主控这里会根据mo的联动去维护（以及定时全量维护）
    ReentrantLock _lockCache = new ReentrantLock();
    public void uploadFullRegCache(boolean clearFirst) throws Exception
    {
        Map<String, MsRegEntryInfo> mapReg = getAllEntryInfo();
    
        _lockCache.lock();
        try
        {
            // 初始化父目录
            try
            {
                _client.create().creatingParentsIfNeeded().forPath(MsZkConst.PATH_MS_REGISTER_TABLE);
            }catch(NodeExistsException exist)
            {
                // 已经存在，且要求清除的，先全删
                if (clearFirst)
                {
                    _client.delete().deletingChildrenIfNeeded().forPath(MsZkConst.PATH_MS_REGISTER_TABLE);
                }
            }
            
            // 写入
            for (MsRegEntryInfo info : mapReg.values())
            {
                writeRegistry(info);
            }
        }finally
        {
            _lockCache.unlock();
        }
    }
    
    public void writeSystemRegistry()
    {
//        MsRegEntryInfo sysReg = new MsRegEntryInfo();
//        sysReg.setRegRdn("SYSTEM="+(-1*ToolUtilities.allocRandomID()));
//        sysReg.setServiceKey(MsSysBasicServiceIntf.class.getName());
//        sysReg.setServiceKey(MsSysBasicService.class.getName());
//        sysReg.setServiceLabel("System Plugin Service (On Agent)");
    }
    
    public void writeRegistry(MsRegEntryInfo entry) throws Exception
    {
        String sAgtJson = entry.toJson();
        try
        {
            byte[] bMo = _client.getData().forPath(MsZkConst.getPath_Registry(entry.getServiceKey()));
            String existJson = new String(bMo);
            if (!ToolUtilities.isStringEqual(existJson, sAgtJson))
                _client.setData().forPath(MsZkConst.getPath_Registry(entry.getServiceKey()), sAgtJson.getBytes());
        }catch(NoNodeException no)
        {
            _client.create().creatingParentContainersIfNeeded().withMode(CreateMode.PERSISTENT).forPath(MsZkConst.getPath_Registry(entry.getServiceKey()), sAgtJson.getBytes());
        }
    }
    
    public void deleteRegistry(String serviceKey) throws Exception
    {
        try
        {
            _client.delete().forPath(MsZkConst.getPath_Registry(serviceKey));
        }catch(NoNodeException noNode)
        {
            //Ignore
        }
    }
    
    public void OnEvtEntryCreated(CMsRegEntry entry)
    {
        _lockCache.lock();
        try
        {
//            writeRegistry(entry.toInfo(null, null));
        } catch(Exception exp)
        {
            ToolUtilities.error(LOG, exp);
        }finally
        {
            _lockCache.unlock();
        }
    }
    
    public void OnEvtEntryModified(CMsRegEntry entry, CMsRegEntry org)
    {
        _lockCache.lock();
        try
        {
            MsRegEntryInfo info = entry.toInfo(getIncludeAgentID(entry.getUuid()), getExcludeAgentID(entry.getUuid()));
            writeRegistry(info);
            
            if (!ToolUtilities.isStringEqual(org.getName(), entry.getName()))
                deleteRegistry(org.getName());
        } catch(Exception exp)
        {
            ToolUtilities.error(LOG, exp);
        }
        finally
        {
            _lockCache.unlock();
        }
    }
    
    public void OnEvtEntryDeleted(CMsRegEntry entry)
    {
        _lockCache.lock();
        try
        {
//            deleteRegistry(entry.getServiceKey());
        } catch (Exception exp)
        {
            ToolUtilities.error(LOG, exp);
        }finally
        {
            _lockCache.unlock();
        }
    }
}
