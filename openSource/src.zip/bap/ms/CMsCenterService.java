package bap.ms;

import java.rmi.RemoteException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.Cnd;
import org.nutz.dao.util.cri.SqlExpression;

import com.cdao.dto.CPager;
import com.cdao.impl.entity.field.GID;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dfc.microService.MsCenterService;
import com.leavay.dfc.microService.MsRegEntryInfo;
import com.leavay.dfc.microService.bean.MsAlarmBean;
import com.leavay.dfc.microService.track.filter.MsFilterReq;
import com.leavay.dfc.microService.track.filter.MsFilterReqList;
import com.leavay.ms.warehouse.MsAgentDto;
import com.leavay.ms.warehouse.MsAgentInfoDto;
import com.leavay.ms.warehouse.WhPackage;
import com.leavay.nio.crpc.Pingable;
import com.leavay.starter.StarterConf;
import com.project.gui.common.DBDataSourceIntf;

import bap.ms.CMsCenter.ALARM_STASTIC_KEY;
import ms.cmn.HostPort;

public interface CMsCenterService extends MsCenterService, Pingable
{
    
    /**
     * 删除某服务，连同所有
     */
    public void deleteService(String serviceKey) throws Exception;

    // 修改服务注册项的一些其它属性：标签、版本、实现类、仿真器等
    /**
     * 修改服务注册项的一些其它属性：标签、版本、实现类、仿真器等
     * @param serviceKey ：服务Key
     * @param field : CMsRegEntry下的FieldName，但仅限于FIELDS_UPDATABLE中约定的字段名
     * @param v : 值
     */
    public void updateServiceAttribute(String serviceKey, String field, Object v) throws Exception;

    /**
     * 微服务注册 
     */
    public Map<String, MsRegEntryInfo> getAllEntryInfo() throws Exception;
    
    /**
     * 获取微代理仓库目录
     */
    public List loadWarehouseCatalog(List<String> path) throws RemoteException;
    public List<WhPackage> loadAllWarehousePackage() throws RemoteException;
    public void updateMsAgent(MsAgentDto newAgent, boolean rebuild) throws Exception;
    public void rebuildMsAgent(GID agentGid) throws Exception;
    public MultiPageResult<MsAgentDto> queryMsAgent(Cnd cnd, CPager pager) throws Exception;
    public Map<String, MsAgentInfoDto> queryMsAgentInfo(Set<String> agentName) throws Exception;
    public void createMsAgent(MsAgentDto agent) throws Exception;
    public void terminateMsAgent(GID agtGid) throws Exception;
    public void killAndDeleteMsAgent(GID agtGid) throws Exception;
    public void startMsAgent(GID agtGid) throws Exception;
    public MultiPageResult<String> readMsAgentOutput(GID agtGid, int startLine, int lastLineCount) throws Exception;
    
    // 加载微代理包的配置信息
    public StarterConf loadMsPackageConfig(String pkgPath) throws Exception;
    
    // 追踪中心界面访问入口
    public HostPort getTrackCenter() throws Exception;
    public DBDataSourceIntf getTrackDB() throws Exception;
    public boolean isTrackMonitorStarted() throws Exception;
    public void startTrackMonitor(long interval) throws Exception;
    public void stopTrackMonitor() throws Exception;
    public Map<String, Object> queryTrackData(MsFilterReqList reqList) throws Exception;
    public Object queryTrackData(MsFilterReq req) throws Exception;
    public MultiPageResult<MsAlarmBean> queryAlarm(SqlExpression whereCnd, int startPos, int pageSize) throws Exception;
    public LinkedHashMap<Comparable, Number> queryAlarmStastic(ALARM_STASTIC_KEY stasticKey, int limit) throws Exception;

    public void deleteAlarmBatch(Set<String> setAlarmID);
    public int deleteAlarmWhere(SqlExpression where);
    
}
