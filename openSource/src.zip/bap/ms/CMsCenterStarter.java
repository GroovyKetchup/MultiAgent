package bap.ms;

import com.leavay.dfc.mgr.disCache.DCacheUtil;
import com.leavay.dfc.mgr.starter.CDaoStarter;
import com.leavay.starter.CStarter;

public class CMsCenterStarter implements CStarter
{
    public void before(CStarter other) throws Exception
    {
        if (other instanceof CDaoStarter)
            CMsCenter.getMe().initBeforeDao();
    }

    public void start() throws Exception
    {
        // 作为集群主控，作为分布式缓存的中心
        DCacheUtil.setAsCenter();
        
        CMsCenter.getMe().initService();
        
        CMsCenter.getMe().startService();
    }
}
