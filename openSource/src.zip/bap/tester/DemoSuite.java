package bap.tester;

import org.junit.runners.Suite.SuiteClasses;

@SuiteClasses(DemoCase1.class)
public class DemoSuite
{

}
