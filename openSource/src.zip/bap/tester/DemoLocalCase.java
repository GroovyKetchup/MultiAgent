package bap.tester;

import static org.junit.Assert.assertNull;

import org.junit.Test;

import com.leavay.common.util.ToolUtilities;

import bap.cells.Cells;
import bap.cells.hook.BapTesterHook;


public class DemoLocalCase extends BapLocalTester
{
    @Test
    public void test() throws Exception
    {
        assertNull(Cells.getConfig(DemoLocalCase.class));
        
        trace(ToolUtilities.logString(BapTesterHook.getRatio(), true));
    }
}
