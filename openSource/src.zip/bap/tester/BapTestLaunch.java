package bap.tester;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import com.leavay.dfc.gui.LvUtil;

public class BapTestLaunch
{
    public static void main(String[] args)
    {
        Result rs = JUnitCore.runClasses(DemoCase1.class);
        LvUtil.trace(rs.getRunCount());
    }
}
