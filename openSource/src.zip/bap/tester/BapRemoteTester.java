package bap.tester;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.LvUtil;
import com.project.gui.common.GuiUtil;

import bap.cells.Cells;
import bap.cells.hook.BapTesterHook;
import bap.debug.BapDebugUtil;
import bap.debug.BapDebugger;
import bap.debug.gui.DevConf;
import bap.debug.gui.ProjectAgent;

/**
 * 纯云端测试用例
 * 测试用例开始时还会注册测试覆盖率HOOK
 * 
 * 派生于此用例的所有测试用例，运行模式只有两种：
 *  1、在主控上由API触发执行（当前目录下没有.develop文件）
 *  2、在Eclipse端，云开发工程下，由Eclipse启动测试（在这种工程根目录下有.develop文件，可自动远程测试）
 */
public class BapRemoteTester
{
    private static BapRemoteTester _me;

    // 全局初始化连接
    static
    {
        try
        {
            get();
        } catch (Throwable err)
        {
            DetailErrorMsg.showError(err);
            throw err;
        }
    }

    public static synchronized BapRemoteTester get()
    {
        if (_me == null)
        {
            BapRemoteTester me = new BapRemoteTester();
            me.initSingleton();
            _me = me;
        }
        return _me;
    }

    // 默认本地cell都生效，可以不生效
    public boolean enableLocalCells()
    {
        return false;
    }
    

    protected void initSingleton()
    {
        try
        {
            DevConf conf = BapDebugUtil.loadConfigIfexist(ToolUtilities.getCurrentDirectory());
            
            // 为null说明在主控内执行（并不在开发端，不是Eclipse工程里），不启动任何远程联调
            if (conf == null) 
                return;
            
            // 如果本身已经启动了远程调试，则不再尝试启动
            if (BapDebugger.get().isStarted())
                return;
            
            // 以Eclipse工程端，发起登录
            ProjectAgent pjAgent = connect(conf);
            
            // 说明当前处于开发端（Eclipse或其它独立进程），需要启动远程调试
            GuiUtil.setLookAndFeel_JDK6();
            BapDebugger.get().start(enableLocalCells(), false, conf.getURIForDebug(), false);
            
            // 单次用例启动，启动测试覆盖追踪功能
            BapTesterHook.reset();
            Cells.getFactory().addGlobalBefore(BapTesterHook.class.getName());
            
            trace("|===== Connect  : " + conf.getUri() + " OK ======|");
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
        }
    }
    
    public ProjectAgent connect(DevConf conf) throws Exception
    {
        ProjectAgent pjAgent = new ProjectAgent(ToolUtilities.getCurrentDirectory(), conf);
        pjAgent.connectAndLogin();
        pjAgent.setToGlobalSession();
        
        return pjAgent;
    }

    public static void trace(Object o)
    {
        LvUtil.trace(o);
    }
}
