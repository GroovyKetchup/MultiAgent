package bap.tester;

import static org.junit.Assert.assertNull;

import org.junit.Test;

import com.leavay.common.util.ToolUtilities;

import bap.cells.Cells;
import bap.cells.hook.BapTesterHook;


public class DemoCase1 extends BapTester
{
    @Test
    public void test() throws Exception
    {
        assertNull(Cells.getConfig(DemoCase1.class));
        
        trace(ToolUtilities.logString(BapTesterHook.getRatio(), true));
    }
}
