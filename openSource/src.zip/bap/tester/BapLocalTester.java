package bap.tester;

import java.net.URI;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.LvUtil;
import com.leavay.nio.crpc.CRpcServer;
import com.project.gui.common.GuiUtil;

import bap.cells.CellClientFactory;
import bap.cells.Cells;
import bap.cells.ServerCellService;
import bap.cells.hook.BapTesterHook;
import bap.debug.BapDebugUtil;
import bap.debug.BapDebugger;
import bap.debug.gui.DevConf;

public class BapLocalTester
{

    private static BapLocalTester _me;

    // 全局初始化连接
    static
    {
        try
        {
            get();
        } catch (Throwable err)
        {
            DetailErrorMsg.showError(err);
            throw err;
        }
    }

    public static synchronized BapLocalTester get()
    {
        if (_me == null)
        {
            BapLocalTester me = new BapLocalTester();
            me.initSingleton();
            _me = me;
        }
        return _me;
    }

    
    // 子类可以派生重载
    public boolean enableLocalCells()
    {
        return false;
    }

    protected void initSingleton()
    {
        try
        {
            DevConf conf = BapDebugUtil.loadConfigIfexist(ToolUtilities.getCurrentDirectory());
            // 为null说明在主控内执行（并不在开发端，不是Eclipse工程里），不启动任何远程联调
            if (conf == null) 
                return;
            
            URI localUri = conf.getLocalUri();
            ToolUtilities.assertNotNull(localUri, "Please start local service first!");
            
            // 如果本身已经启动了远程调试，则不再尝试启动
            if (BapDebugger.get().isStarted())
                return;
            
            // 说明当前处于开发端（Eclipse或其它独立进程），需要启动远程调试
            GuiUtil.setLookAndFeel_JDK6();
            BapDebugger.get().start(enableLocalCells(), true, localUri, false);
            
            // 单次用例启动，启动测试覆盖追踪功能
            BapTesterHook.reset();
            Cells.getFactory().addGlobalBefore(BapTesterHook.class.getName());
            
            trace("|===== Connect  : " + localUri + " OK ======|");
        } catch (Exception exp)
        {
            ToolUtilities.throwRuntimeException(exp);
        }
    }

    public static void trace(Object o)
    {
        LvUtil.trace(o);
    }
}
