# OPM采集器开发文档

## 一、PG数据库监控采集器

### 1.1 功能概述

PG数据库监控采集器用于监控PostgreSQL数据库的运行状态，支持同机部署和远程连接两种模式。

### 1.2 部署模式与功能矩阵

| 功能分类 | 监控项 | 同机部署 | 远程连接 |
|---------|-------|---------|---------|
| **基础监控** | 长时SQL监控 | ✅ | ✅ |
| **基础监控** | 数据库空间监控 | ✅ | ✅ |
| **基础监控** | 死锁/长时锁监控 | ✅ | ✅ |
| **基础监控** | 连接数/事务监控 | ✅ | ✅ |
| **基础监控** | 复制延迟监控 | ✅ | ✅ |
| **高级监控** | PG进程监控（CPU/内存） | ✅ | ❌ |
| **高级监控** | 磁盘使用率监控（OS层面） | ✅ | ❌ |

### 1.3 告警级别

| 级别 | 说明 |
|------|------|
| **WARN** | 警告 |
| **MINOR** | 次要 |
| **MAJOR** | 主要 |
| **CRITICAL** | 严重 |

---

## 二、文件结构

```
Product/Core/bap/src/
├── cell/bap/opm/collector/pg/
│   ├── IOpmPgCollector.java          # Cell接口
│   └── COpmPgCollector.java          # Cell实现
│
├── bap/opm/collector/pg/
│   ├── OpmPgConst.java               # 常量定义
│   ├── PgSqlQueries.java             # PG SQL查询封装
│   └── PgProcessMonitor.java         # 跨平台进程监控
│
└── bap/md/opm/pg/
    ├── OpmPgMetricDo.java            # 主表数据模型
    ├── OpmPgSqlDetailDo.java         # SQL详情（外键扩展）
    ├── OpmPgLockDetailDo.java        # 锁详情（外键扩展）
    └── OpmPgAlarmExtDo.java          # 告警扩展模型
```

---

## 三、数据模型

### 3.1 主表：OpmPgMetricDo

| 字段 | 类型 | 说明 |
|------|------|------|
| dbName | String | 数据库名 |
| longSqlCount | Integer | 长时SQL数量 |
| maxSqlDurationSec | Double | 最长SQL时长(秒) |
| blockedSqlCount | Integer | 阻塞SQL数量 |
| dbSizeBytes | Long | 数据库大小(字节) |
| tablespaceUsageRate | Double | 表空间使用率 |
| diskUsageRate | Double | 磁盘使用率 |
| pgProcCount | Integer | PG进程数量 |
| pgCpuUsageRate | Double | PG进程CPU占用率 |
| pgMemUsageBytes | Long | PG进程内存占用 |
| lockWaitCount | Integer | 锁等待数量 |
| maxLockWaitSec | Double | 最大锁等待时长 |
| deadlockCount | Integer | 死锁数量 |
| totalConnCount | Integer | 总连接数 |
| activeConnCount | Integer | 活动连接数 |
| idleConnCount | Integer | 空闲连接数 |
| idleInTxnConnCount | Integer | 空闲事务连接数 |
| maxConnLimit | Integer | 最大连接数限制 |
| connUsageRate | Double | 连接使用率 |
| txnCommitCount | Long | 事务提交数 |
| txnRollbackCount | Long | 事务回滚数 |
| replicationRole | String | 复制角色 |
| replicationLagSec | Double | 复制延迟 |
| replicationState | String | 复制状态 |
| detailJson | String | 详细JSON |

### 3.2 外键扩展表

- **OpmPgSqlDetailDo**：长时SQL详情，通过 `@Foreign` 关联主表
- **OpmPgLockDetailDo**：锁等待详情，通过 `@Foreign` 关联主表

---

## 四、配置项

### 4.1 基础配置

| 配置Key | 默认值 | 说明 |
|---------|--------|------|
| opm.pg.enable | true | 启用采集器 |
| opm.pg.collectIntervalSec | 30 | 采集周期(秒) |
| opm.pg.dbName | postgres | 监控数据库名 |
| opm.pg.localMode | true | 同机部署模式 |

### 4.2 详情存储

| 配置Key | 默认值 | 说明 |
|---------|--------|------|
| opm.pg.storeSqlDetail | true | 存储SQL详情 |
| opm.pg.storeLockDetail | true | 存储锁详情 |
| opm.pg.sqlDetailMaxRows | 20 | SQL详情最大行数 |
| opm.pg.lockDetailMaxRows | 20 | 锁详情最大行数 |

### 4.3 告警阈值

详见 `OpmPgConst.java` 常量定义。

---

## 五、跨平台支持

### 5.1 进程监控

| 平台 | 实现方式 |
|------|---------|
| **Windows** | PowerShell: `Get-Process postgres*` |
| **Linux** | `ps aux \| grep postgres` |

### 5.2 磁盘监控

复用 `SystemMetricsUtil` 获取磁盘使用率。

---

## 六、配置样板

### 6.1 自动发现机制

配置界面采用**自动发现**机制，无需手动开发前端配置界面：

1. 系统启动时自动扫描 `cell.bap.opm.collector.` 包下所有实现 `IOpmCollector` 接口的类
2. 自动调用每个采集器的 `getParamDefs()` 方法获取配置参数定义
3. 前端配置界面动态渲染这些配置项

### 6.2 starter.xml 配置样板

```xml
<module name="pg" label="PG数据库监控" enable="true" 
        class_name="cell.bap.opm.collector.pg.IOpmPgCollector">
    <param key="opm.pg.enable" label="启用PG采集器" type="boolean" value="true"/>
    <param key="opm.pg.collectIntervalSec" label="采集周期秒" type="int" value="30"/>
    <param key="opm.pg.dbName" label="监控数据库名" type="string" value="postgres"/>
    <param key="opm.pg.localMode" label="同机部署模式" type="boolean" value="true"/>
    <param key="opm.pg.storeSqlDetail" label="存储SQL详情" type="boolean" value="true"/>
    <param key="opm.pg.storeLockDetail" label="存储锁详情" type="boolean" value="true"/>
    <param key="opm.pg.sqlDetailMaxRows" label="SQL详情最大行数" type="int" value="20"/>
    <param key="opm.pg.lockDetailMaxRows" label="锁详情最大行数" type="int" value="20"/>
    <param key="opm.pg.sql.warnSec" label="SQL警告时长秒" type="int" value="30"/>
    <param key="opm.pg.space.warnRate" label="空间警告阈值" type="string" value="0.70"/>
    <param key="opm.pg.lock.warnSec" label="锁等待警告秒" type="int" value="10"/>
    <param key="opm.pg.conn.warnRate" label="连接警告阈值" type="string" value="0.70"/>
    <param key="opm.pg.replication.warnSec" label="复制延迟警告秒" type="int" value="10"/>
    <param key="opm.pg.rule.cooldownSec" label="规则冷却秒" type="int" value="300"/>
</module>
```

---

## 七、更新日志

| 日期 | 版本 | 更新内容 |
|------|------|---------|
| 2026-04-01 | v1.0 | 初始版本，支持PG数据库基础监控和高级监控 |