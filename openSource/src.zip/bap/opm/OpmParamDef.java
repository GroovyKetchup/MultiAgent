package bap.opm;

public class OpmParamDef
{
    public String key;
    public String label;
    public String type;
    public String defaultValue;
    public String desc;
    public String group;
    public String groupLabel;
    public boolean groupEnableSwitch;

    public OpmParamDef()
    {
    }

    public OpmParamDef(String key, String label, String type, String defaultValue)
    {
        this.key = key;
        this.label = label;
        this.type = type;
        this.defaultValue = defaultValue;
        fillAutoDesc();
    }

    public OpmParamDef(String key, String label, String type, String defaultValue, String group, String groupLabel)
    {
        this.key = key;
        this.label = label;
        this.type = type;
        this.defaultValue = defaultValue;
        this.group = group;
        this.groupLabel = groupLabel;
        fillAutoDesc();
    }

    public OpmParamDef setGroup(String group, String groupLabel)
    {
        this.group = group;
        this.groupLabel = groupLabel;
        return this;
    }

    public OpmParamDef setGroupEnableSwitch(boolean enableSwitch)
    {
        this.groupEnableSwitch = enableSwitch;
        return this;
    }

    public OpmParamDef setDesc(String desc)
    {
        if (desc == null || desc.trim().length() <= 0)
            this.desc = OpmParamDescResolver.resolve(key, label, type, defaultValue);
        else
            this.desc = desc.trim();
        return this;
    }

    public OpmParamDef fillAutoDesc()
    {
        if (this.desc == null || this.desc.trim().length() <= 0)
            this.desc = OpmParamDescResolver.resolve(key, label, type, defaultValue);
        return this;
    }
}
