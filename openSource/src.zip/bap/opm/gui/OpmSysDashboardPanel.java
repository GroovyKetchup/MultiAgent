package bap.opm.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Dialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicSplitPaneDivider;
import javax.swing.plaf.basic.BasicSplitPaneUI;
import javax.swing.table.DefaultTableCellRenderer;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import com.leavay.client.util.MBox;
import com.leavay.common.util.SortButtonRenderer.SortableModel;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.JFreeChartUtil;

import bap.md.opm.OpmAlarmRefDo;
import bap.md.opm.cpu.OpmCpuMetricDo;
import bap.md.opm.disk.OpmDiskMetricDo;
import bap.md.opm.io.OpmIoMetricDo;
import bap.md.opm.net.OpmNetMetricDo;
import bap.md.opm.sys.OpmSysMetricDo;
import bap.opm.OpmCenterService;
import bap.opm.OpmCollectResult;
import tiny.service.client.OpmClient;
import tiny.service.track.gui.TsTrackPanel;
import tiny.service.md.TsAlarm;

public class OpmSysDashboardPanel extends JPanel implements ActionListener
{
    static
    {
        JFreeChartUtil.initJFreeChart();
    }

    static final Color COLOR_BG = new Color(0x03, 0x1B, 0x2D);
    static final Color COLOR_CARD = new Color(0x0B, 0x23, 0x39);
    static final Color COLOR_TEXT = new Color(0xA7, 0xDA, 0xF4);
    static final Color COLOR_ACCENT = new Color(0x47, 0xD0, 0xFF);
    static final Color COLOR_CPU = new Color(0x45, 0xD9, 0xFF);
    static final Color COLOR_MEM = new Color(0x4B, 0xF0, 0xA0);
    static final Color COLOR_DISK = new Color(0xFF, 0xC4, 0x53);
    static final Color COLOR_SPLIT = new Color(0x0F, 0x2D, 0x46);
    static final Color COLOR_LINE = new Color(0x1A, 0x4A, 0x68);
    static final int TOOLBAR_HEIGHT = 28;
    static final int MAX_USAGE_CHART_POINTS = 8;
    static final int MAX_NET_CHART_POINTS = 8;

    static final Font FONT_TITLE = new Font("Dialog", Font.PLAIN, 12);
    static final Font FONT_HEADER = new Font("Dialog", Font.PLAIN, 12);
    static final Font FONT_TABLE = new Font("Dialog", Font.PLAIN, 12);
    static final Font FONT_STATUS = new Font("Dialog", Font.PLAIN, 11);

    JButton jBtnRefresh = GuiUtil.createToolButton("redo_16.png", "", this);
    JButton jBtnCollectNow = GuiUtil.createToolButton("start_16.png", "", this);

    JLabel jLabAgent = new JLabel("代理:");
    JComboBox<AgentItem> jCmbAgent = new JComboBox<AgentItem>();
    JLabel jLabStatus = new JLabel("OPM dashboard ready", JLabel.RIGHT);

    DefaultCategoryDataset _usageData = new DefaultCategoryDataset();
    JFreeChart jUsageChart = ChartFactory.createLineChart("系统资源趋势", null, "%", _usageData);

    DefaultPieDataset _diskPieData = new DefaultPieDataset();
    JFreeChart jDiskPieChart = ChartFactory.createPieChart("磁盘分区占用", _diskPieData, true, false, false);

    DefaultCategoryDataset _ioBarData = new DefaultCategoryDataset();
    JFreeChart jIoBarChart = ChartFactory.createBarChart("IO进程速率", null, "B/s", _ioBarData);

    DefaultCategoryDataset _netLineData = new DefaultCategoryDataset();
    JFreeChart jNetLineChart = ChartFactory.createLineChart("网络吞吐趋势", null, "B/s", _netLineData);

    SortableModel _cpuProcModel = new SortableModel();
    JTable jTblCpuProc = new JTable(_cpuProcModel);

    SortableModel _alarmModel = new SortableModel();
    JTable jTblAlarm = new JTable(_alarmModel);

    JTextArea jTxtDiskBrief = new JTextArea();
    JTextArea jTxtDetail = new JTextArea();

    volatile boolean _closed = false;
    Timer _timer = new Timer("OPM GUI Refresh", true);
    AtomicBoolean _loading = new AtomicBoolean(false);
    volatile boolean _updatingAlarmTable = false;

    List<OpmSysMetricDo> _allMetrics = new ArrayList<OpmSysMetricDo>();
    List<OpmCpuMetricDo> _allCpuMetrics = new ArrayList<OpmCpuMetricDo>();
    List<OpmDiskMetricDo> _allDiskMetrics = new ArrayList<OpmDiskMetricDo>();
    List<OpmIoMetricDo> _allIoMetrics = new ArrayList<OpmIoMetricDo>();
    List<OpmNetMetricDo> _allNetMetrics = new ArrayList<OpmNetMetricDo>();
    List<OpmAlarmRefDo> _allAlarms = new ArrayList<OpmAlarmRefDo>();
    String _selectedAlarmKey;

    String _myAgentCode;
    String _myAgentName;
    String _myUri;
    boolean _runtimeHasConfigRecord;
    boolean _runtimeCollectorEnabled;

    public OpmSysDashboardPanel()
    {
        jbInit();
        startTimer();
        reloadNow();
    }

    protected void jbInit()
    {
        setBackground(COLOR_BG);

        styleButton(jBtnRefresh);
        styleButton(jBtnCollectNow);
        fixSquareToolButton(jBtnRefresh);
        fixSquareToolButton(jBtnCollectNow);
        jBtnRefresh.setToolTipText("刷新");
        jBtnCollectNow.setToolTipText("立即采集");

        jLabAgent.setForeground(COLOR_TEXT);
        jLabAgent.setFont(FONT_HEADER);
        jLabStatus.setForeground(COLOR_ACCENT);
        jLabStatus.setFont(FONT_STATUS);
        jLabStatus.setPreferredSize(new Dimension(640, 24));
        jLabStatus.setMinimumSize(new Dimension(640, 24));
        jLabStatus.setMaximumSize(new Dimension(640, 24));

        jCmbAgent.setPreferredSize(new Dimension(240, 26));
        jCmbAgent.setBackground(COLOR_CARD);
        jCmbAgent.setForeground(COLOR_TEXT);
        jCmbAgent.setFont(FONT_HEADER);
        jCmbAgent.setBorder(BorderFactory.createLineBorder(COLOR_LINE));
        styleComboBox(jCmbAgent);
        jCmbAgent.addActionListener(this);

        _alarmModel.addColumn("Bean");
        _alarmModel.addColumn("级别");
        _alarmModel.addColumn("规则");
        _alarmModel.addColumn("代理");
        _alarmModel.addColumn("时间");
        _alarmModel.addColumn("摘要");

        _cpuProcModel.addColumn("PID");
        _cpuProcModel.addColumn("进程");
        _cpuProcModel.addColumn("CPU占比");

        setupUsageChart();
        setupDiskPieChart();
        setupIoBarChart();
        setupNetLineChart();
        setupCpuProcTable();
        setupAlarmTable();
        setupDiskBriefArea();
        setupDetailArea();

        JPanel toolBar = new JPanel(new BorderLayout(8, 0));
        toolBar.setBackground(COLOR_BG);

        Box leftBox = MBox.createHBar(TOOLBAR_HEIGHT,
                jLabAgent, MBox.HStrut(4), jCmbAgent,
                MBox.HStrut(8), jBtnRefresh,
                MBox.HStrut(4), jBtnCollectNow);
        leftBox.setPreferredSize(new Dimension(400, TOOLBAR_HEIGHT));
        leftBox.setMinimumSize(new Dimension(400, TOOLBAR_HEIGHT));
        leftBox.setMaximumSize(new Dimension(400, TOOLBAR_HEIGHT));

        toolBar.add(leftBox, BorderLayout.WEST);
        toolBar.add(jLabStatus, BorderLayout.EAST);

        JLabel jLabAlarm = createTitleLabel("最近告警");
        JLabel jLabDetail = createTitleLabel("告警详情");
        JLabel jLabTrend = createTitleLabel("性能面板");

        JSplitPane spCol3 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                wrapDiskPanel(360, 260),
                wrapChart(jIoBarChart, 360, 260));
        spCol3.setDividerLocation(0.36D);
        spCol3.setResizeWeight(0.36D);
        styleSplit(spCol3);
        GuiUtil.invokeLater(() -> spCol3.setDividerLocation(0.36D));

        JPanel pTop = new JPanel(new GridLayout(1, 4, 6, 0));
        pTop.setBackground(COLOR_CARD);
        pTop.add(wrapChart(jUsageChart, 360, 420));
        pTop.add(wrapChart(jNetLineChart, 360, 420));
        pTop.add(spCol3);
        pTop.add(wrapCpuProcCard());
        pTop.setMinimumSize(new Dimension(120, 140));

        JPanel pTrend = new JPanel();
        pTrend.setBackground(COLOR_CARD);
        pTrend.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(COLOR_ACCENT.darker()), BorderFactory.createEmptyBorder(6, 8, 8, 8)));
        pTrend.setMinimumSize(new Dimension(120, 160));
        Box trendBox = Box.createVerticalBox();
        trendBox.add(jLabTrend);
        trendBox.add(MBox.VStrut(4));
        trendBox.add(pTop);
        GuiUtil.setGridLayout(pTrend, trendBox);

        JScrollPane jScrAlarm = new JScrollPane(jTblAlarm);
        TsTrackPanel.getStyleUtil().setScrollPanel(jScrAlarm);
        jScrAlarm.getViewport().setBackground(COLOR_CARD);

        JPanel pAlarm = new JPanel();
        pAlarm.setBackground(COLOR_CARD);
        pAlarm.setBorder(BorderFactory.createEmptyBorder(4, 6, 6, 6));
        Box alarmBox = Box.createVerticalBox();
        alarmBox.add(jLabAlarm);
        alarmBox.add(MBox.VStrut(4));
        alarmBox.add(jScrAlarm);
        GuiUtil.setGridLayout(pAlarm, alarmBox);

        JScrollPane jScrDetail = new JScrollPane(jTxtDetail);
        jScrDetail.getViewport().setBackground(COLOR_CARD);
        jScrDetail.setBorder(BorderFactory.createLineBorder(COLOR_ACCENT.darker()));

        JPanel pDetail = new JPanel();
        pDetail.setBackground(COLOR_CARD);
        pDetail.setBorder(BorderFactory.createEmptyBorder(4, 6, 6, 6));
        Box detailBox = Box.createVerticalBox();
        detailBox.add(jLabDetail);
        detailBox.add(MBox.VStrut(4));
        detailBox.add(jScrDetail);
        GuiUtil.setGridLayout(pDetail, detailBox);

        JSplitPane spBottom = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, pAlarm, pDetail);
        spBottom.setDividerLocation(830);
        styleSplit(spBottom);

        JSplitPane spMain = new JSplitPane(JSplitPane.VERTICAL_SPLIT, pTrend, spBottom);
        spMain.setDividerLocation(0.5D);
        spMain.setResizeWeight(0.5D);
        styleSplit(spMain);
        GuiUtil.invokeLater(() -> spMain.setDividerLocation(0.5D));

        Box main = Box.createVerticalBox();
        main.add(MBox.hBar(toolBar));
        main.add(MBox.VStrut(6));
        main.add(MBox.hBar(spMain));

        GuiUtil.setGridLayout(this, main);
    }

    protected JLabel createTitleLabel(String text)
    {
        JLabel lab = new JLabel(text);
        lab.setForeground(COLOR_ACCENT);
        lab.setFont(FONT_TITLE);
        return lab;
    }

    protected void styleSplit(JSplitPane sp)
    {
        sp.setBackground(COLOR_BG);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.setContinuousLayout(true);
        sp.setOneTouchExpandable(false);

        BasicSplitPaneUI ui = new BasicSplitPaneUI()
        {
            @Override
            public BasicSplitPaneDivider createDefaultDivider()
            {
                BasicSplitPaneDivider divider = new BasicSplitPaneDivider(this)
                {
                    @Override
                    public void setBorder(Border border)
                    {
                    }
                };
                divider.setBackground(COLOR_SPLIT);
                divider.setBorder(BorderFactory.createEmptyBorder());
                return divider;
            }
        };
        sp.setUI(ui);
        sp.setDividerSize(6);
    }

    protected void styleButton(JButton btn)
    {
        btn.setBackground(COLOR_CARD);
        btn.setForeground(COLOR_TEXT);
        btn.setFont(FONT_HEADER);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(COLOR_LINE));
    }

    protected void fixSquareToolButton(JButton btn)
    {
        Dimension d = new Dimension(TOOLBAR_HEIGHT, TOOLBAR_HEIGHT);
        btn.setPreferredSize(d);
        btn.setMinimumSize(d);
        btn.setMaximumSize(d);
    }

    protected void styleComboBox(JComboBox box)
    {
        if (box == null)
            return;

        box.setOpaque(true);
        box.setFocusable(false);
        box.setRenderer(new DefaultListCellRenderer()
        {
            @Override
            public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
            {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                setFont(FONT_HEADER);
                setBorder(BorderFactory.createEmptyBorder(2, 6, 2, 6));
                if (isSelected)
                {
                    setBackground(new Color(0x1D, 0x4F, 0x68));
                    setForeground(Color.WHITE);
                }
                else
                {
                    setBackground(COLOR_CARD);
                    setForeground(COLOR_TEXT);
                }
                return this;
            }
        });

        box.setUI(new BasicComboBoxUI()
        {
            @Override
            protected JButton createArrowButton()
            {
                BasicArrowButton btn = new BasicArrowButton(BasicArrowButton.SOUTH,
                        COLOR_CARD,
                        COLOR_LINE,
                        COLOR_SPLIT,
                        COLOR_ACCENT)
                {
                    @Override
                    public void paint(Graphics g)
                    {
                        setBackground(COLOR_CARD);
                        super.paint(g);
                    }
                };
                btn.setBackground(COLOR_CARD);
                btn.setOpaque(true);
                btn.setBorder(BorderFactory.createLineBorder(COLOR_LINE));
                return btn;
            }
        });
    }

    protected void setupUsageChart()
    {
        jUsageChart.setBackgroundPaint(COLOR_CARD);
        jUsageChart.getTitle().setPaint(COLOR_ACCENT);
        jUsageChart.getTitle().setFont(new Font("Dialog", Font.PLAIN, 14));
        jUsageChart.setPadding(new org.jfree.ui.RectangleInsets(4, 8, 4, 8));

        CategoryPlot plot = jUsageChart.getCategoryPlot();
        plot.setBackgroundPaint(COLOR_BG);
        plot.setOutlinePaint(COLOR_BG);
        plot.setDomainGridlinePaint(new Color(0x15, 0x3A, 0x53));
        plot.setRangeGridlinePaint(new Color(0x15, 0x3A, 0x53));
        plot.getDomainAxis().setMaximumCategoryLabelLines(1);
        plot.getDomainAxis().setCategoryMargin(0.10D);
        plot.getDomainAxis().setLowerMargin(0.02D);
        plot.getDomainAxis().setUpperMargin(0.02D);
        plot.getDomainAxis().setTickLabelPaint(COLOR_TEXT);
        plot.getDomainAxis().setLabelPaint(COLOR_TEXT);
        plot.getDomainAxis().setTickLabelFont(new Font("Dialog", Font.PLAIN, 11));
        plot.getDomainAxis().setLabelFont(new Font("Dialog", Font.PLAIN, 11));
        plot.getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.STANDARD);
        plot.getRangeAxis().setTickLabelPaint(COLOR_TEXT);
        plot.getRangeAxis().setLabelPaint(COLOR_TEXT);
        plot.getRangeAxis().setTickLabelFont(new Font("Dialog", Font.PLAIN, 11));
        plot.getRangeAxis().setLabelFont(new Font("Dialog", Font.PLAIN, 11));
        plot.getRangeAxis().setRange(0D, 100D);

        LineAndShapeRenderer renderer = new LineAndShapeRenderer(true, false);
        renderer.setSeriesPaint(0, COLOR_CPU);
        renderer.setSeriesPaint(1, COLOR_MEM);
        renderer.setSeriesPaint(2, COLOR_DISK);
        renderer.setSeriesStroke(0, new java.awt.BasicStroke(1.6f));
        renderer.setSeriesStroke(1, new java.awt.BasicStroke(1.4f));
        renderer.setSeriesStroke(2, new java.awt.BasicStroke(1.4f));
        plot.setRenderer(renderer);

        jUsageChart.getLegend().setItemPaint(COLOR_TEXT);
        jUsageChart.getLegend().setItemFont(new Font("Dialog", Font.PLAIN, 11));
        jUsageChart.getLegend().setBackgroundPaint(COLOR_CARD);
        jUsageChart.getLegend().setFrame(BlockBorder.NONE);
    }

    protected void setupDiskPieChart()
    {
        jDiskPieChart.setBackgroundPaint(COLOR_CARD);
        jDiskPieChart.getTitle().setPaint(COLOR_ACCENT);
        jDiskPieChart.getTitle().setFont(new Font("Dialog", Font.PLAIN, 14));
        jDiskPieChart.getLegend().setItemPaint(COLOR_TEXT);
        jDiskPieChart.getLegend().setItemFont(new Font("Dialog", Font.PLAIN, 11));
        jDiskPieChart.getLegend().setBackgroundPaint(COLOR_CARD);
        jDiskPieChart.getLegend().setFrame(BlockBorder.NONE);

        PiePlot plot = (PiePlot) jDiskPieChart.getPlot();
        plot.setBackgroundPaint(COLOR_BG);
        plot.setOutlinePaint(COLOR_BG);
        plot.setCircular(true);
        plot.setLabelPaint(COLOR_TEXT);
        plot.setLabelBackgroundPaint(COLOR_CARD);
        plot.setLabelOutlinePaint(COLOR_LINE);
        plot.setLabelShadowPaint(COLOR_BG);
        plot.setSectionPaint(0, new Color(0x37, 0xB4, 0xFF));
        plot.setSectionPaint(1, new Color(0x56, 0xDA, 0xA8));
        plot.setSectionPaint(2, new Color(0xF5, 0xC0, 0x4E));
        plot.setSectionPaint(3, new Color(0xFF, 0x8B, 0x6A));
        plot.setSectionPaint(4, new Color(0xA2, 0x8C, 0xFF));
    }

    protected void setupIoBarChart()
    {
        jIoBarChart.setBackgroundPaint(COLOR_CARD);
        jIoBarChart.getTitle().setPaint(COLOR_ACCENT);
        jIoBarChart.getTitle().setFont(new Font("Dialog", Font.PLAIN, 14));
        jIoBarChart.getLegend().setItemPaint(COLOR_TEXT);
        jIoBarChart.getLegend().setItemFont(new Font("Dialog", Font.PLAIN, 11));
        jIoBarChart.getLegend().setBackgroundPaint(COLOR_CARD);
        jIoBarChart.getLegend().setFrame(BlockBorder.NONE);

        CategoryPlot plot = jIoBarChart.getCategoryPlot();
        plot.setBackgroundPaint(COLOR_BG);
        plot.setOutlinePaint(COLOR_BG);
        plot.setDomainGridlinePaint(new Color(0x15, 0x3A, 0x53));
        plot.setRangeGridlinePaint(new Color(0x15, 0x3A, 0x53));
        plot.getDomainAxis().setTickLabelPaint(COLOR_TEXT);
        plot.getRangeAxis().setTickLabelPaint(COLOR_TEXT);
        plot.getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.UP_45);

        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, new Color(0x45, 0xD9, 0xFF));
        renderer.setSeriesPaint(1, new Color(0xFF, 0xC4, 0x53));
        renderer.setShadowVisible(false);
    }

    protected void setupNetLineChart()
    {
        jNetLineChart.setBackgroundPaint(COLOR_CARD);
        jNetLineChart.getTitle().setPaint(COLOR_ACCENT);
        jNetLineChart.getTitle().setFont(new Font("Dialog", Font.PLAIN, 14));
        jNetLineChart.getLegend().setItemPaint(COLOR_TEXT);
        jNetLineChart.getLegend().setItemFont(new Font("Dialog", Font.PLAIN, 11));
        jNetLineChart.getLegend().setBackgroundPaint(COLOR_CARD);
        jNetLineChart.getLegend().setFrame(BlockBorder.NONE);

        CategoryPlot plot = jNetLineChart.getCategoryPlot();
        plot.setBackgroundPaint(COLOR_BG);
        plot.setOutlinePaint(COLOR_BG);
        plot.setDomainGridlinePaint(new Color(0x15, 0x3A, 0x53));
        plot.setRangeGridlinePaint(new Color(0x15, 0x3A, 0x53));
        plot.getDomainAxis().setMaximumCategoryLabelLines(1);
        plot.getDomainAxis().setCategoryMargin(0.10D);
        plot.getDomainAxis().setLowerMargin(0.02D);
        plot.getDomainAxis().setUpperMargin(0.02D);
        plot.getDomainAxis().setTickLabelPaint(COLOR_TEXT);
        plot.getRangeAxis().setTickLabelPaint(COLOR_TEXT);
        plot.getDomainAxis().setTickLabelFont(new Font("Dialog", Font.PLAIN, 11));
        plot.getRangeAxis().setTickLabelFont(new Font("Dialog", Font.PLAIN, 11));
        plot.getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.STANDARD);

        LineAndShapeRenderer renderer = new LineAndShapeRenderer(true, false);
        renderer.setSeriesPaint(0, new Color(0x45, 0xD9, 0xFF));
        renderer.setSeriesPaint(1, new Color(0xFF, 0xC4, 0x53));
        renderer.setSeriesPaint(2, new Color(0x70, 0xE8, 0xB8));
        renderer.setSeriesStroke(0, new java.awt.BasicStroke(1.6f));
        renderer.setSeriesStroke(1, new java.awt.BasicStroke(1.4f));
        renderer.setSeriesStroke(2, new java.awt.BasicStroke(1.4f));
        plot.setRenderer(renderer);
    }

    protected void setupCpuProcTable()
    {
        TsTrackPanel.getStyleUtil().setTableStyle(jTblCpuProc);
        jTblCpuProc.setBackground(COLOR_CARD);
        jTblCpuProc.setForeground(COLOR_TEXT);
        jTblCpuProc.setFont(FONT_TABLE);
        jTblCpuProc.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jTblCpuProc.setRowHeight(22);
        jTblCpuProc.setGridColor(new Color(0x14, 0x39, 0x50));
        jTblCpuProc.setShowVerticalLines(false);
        jTblCpuProc.setShowHorizontalLines(true);
        jTblCpuProc.setDefaultRenderer(Object.class, new PlainCellRenderer());
    }

    protected JPanel wrapChart(JFreeChart chart, int w, int h)
    {
        ChartPanel p = createChartPanel(chart, w, h);
        JPanel box = new JPanel(new BorderLayout());
        box.setBackground(COLOR_CARD);
        box.setMinimumSize(new Dimension(100, 100));
        box.add(p, BorderLayout.CENTER);
        return box;
    }

    protected JPanel wrapDiskPanel(int w, int h)
    {
        JPanel left = wrapChart(jDiskPieChart, (int) (w * 0.60D), h);
        JPanel right = wrapDiskBriefCard((int) (w * 0.40D), h);
        JSplitPane sp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, right);
        sp.setDividerLocation(0.60D);
        sp.setResizeWeight(0.60D);
        styleSplit(sp);
        GuiUtil.invokeLater(() -> sp.setDividerLocation(0.60D));

        JPanel box = new JPanel(new BorderLayout());
        box.setBackground(COLOR_CARD);
        box.setMinimumSize(new Dimension(100, 100));
        box.add(sp, BorderLayout.CENTER);
        return box;
    }

    protected JPanel wrapDiskBriefCard(int w, int h)
    {
        JScrollPane scr = new JScrollPane(jTxtDiskBrief);
        scr.getViewport().setBackground(COLOR_CARD);
        scr.setBorder(BorderFactory.createLineBorder(COLOR_LINE));

        JPanel box = new JPanel(new BorderLayout());
        box.setBackground(COLOR_CARD);
        box.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        JLabel title = createTitleLabel("分区简讯");
        title.setFont(new Font("Dialog", Font.PLAIN, 11));
        box.add(title, BorderLayout.NORTH);
        box.add(scr, BorderLayout.CENTER);
        box.setPreferredSize(new Dimension(Math.max(110, w), h));
        box.setMinimumSize(new Dimension(90, 90));
        return box;
    }

    protected ChartPanel createChartPanel(JFreeChart chart, int w, int h)
    {
        ChartPanel p = new ChartPanel(chart);
        p.setPreferredSize(new Dimension(w, h));
        p.setMaximumDrawWidth(2200);
        p.setMaximumDrawHeight(1200);
        p.setMinimumDrawWidth(120);
        p.setMinimumDrawHeight(90);
        p.setMinimumSize(new Dimension(80, 80));
        p.setMouseWheelEnabled(true);
        p.setDomainZoomable(true);
        p.setRangeZoomable(true);
        p.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseClicked(MouseEvent e)
            {
                if (e.getClickCount() >= 2 && SwingUtilities.isLeftMouseButton(e))
                    showChartInDialog(chart);
            }
        });
        return p;
    }

    protected void showChartInDialog(JFreeChart chart)
    {
        if (chart == null)
            return;

        String title = chart.getTitle() == null ? null : chart.getTitle().getText();
        title = ToolUtilities.getString(title, "图表详情");

        Window owner = SwingUtilities.getWindowAncestor(this);
        JDialog dlg = createModelessDialog(owner, title);
        dlg.getContentPane().setLayout(new BorderLayout());
        dlg.getContentPane().setBackground(COLOR_BG);

        ChartPanel detail = new ChartPanel(chart);
        detail.setMouseWheelEnabled(true);
        detail.setDomainZoomable(true);
        detail.setRangeZoomable(true);
        detail.setMaximumDrawWidth(5000);
        detail.setMaximumDrawHeight(3000);
        detail.setMinimumDrawWidth(800);
        detail.setMinimumDrawHeight(500);

        dlg.getContentPane().add(detail, BorderLayout.CENTER);

        Rectangle bounds = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        int w = Math.max(980, (int) (bounds.width * 0.82D));
        int h = Math.max(680, (int) (bounds.height * 0.82D));
        if (w > bounds.width)
            w = bounds.width;
        if (h > bounds.height)
            h = bounds.height;

        dlg.setMinimumSize(new Dimension(Math.min(980, w), Math.min(680, h)));
        dlg.setSize(w, h);
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    protected JDialog createModelessDialog(Window owner, String title)
    {
        if (owner instanceof Frame)
            return new JDialog((Frame) owner, title, Dialog.ModalityType.MODELESS);
        if (owner instanceof Dialog)
            return new JDialog((Dialog) owner, title, Dialog.ModalityType.MODELESS);
        return new JDialog((Frame) null, title, Dialog.ModalityType.MODELESS);
    }

    protected JPanel wrapCpuProcTable()
    {
        JScrollPane scr = new JScrollPane(jTblCpuProc);
        TsTrackPanel.getStyleUtil().setScrollPanel(scr);
        scr.getViewport().setBackground(COLOR_CARD);
        JPanel box = new JPanel(new BorderLayout());
        box.setBackground(COLOR_CARD);
        box.add(scr, BorderLayout.CENTER);
        return box;
    }

    protected JPanel wrapCpuProcCard()
    {
        JPanel box = wrapCpuProcTable();
        box.setPreferredSize(new Dimension(360, 420));
        box.setMinimumSize(new Dimension(110, 120));
        return box;
    }

    protected void setupAlarmTable()
    {
        TsTrackPanel.getStyleUtil().setTableStyle(jTblAlarm);
        jTblAlarm.setBackground(COLOR_CARD);
        jTblAlarm.setForeground(COLOR_TEXT);
        jTblAlarm.setFont(FONT_TABLE);
        jTblAlarm.setSelectionBackground(new Color(0x1D, 0x4F, 0x68));
        jTblAlarm.setSelectionForeground(Color.WHITE);
        jTblAlarm.setGridColor(new Color(0x14, 0x39, 0x50));
        jTblAlarm.setShowVerticalLines(false);
        jTblAlarm.setShowHorizontalLines(true);
        jTblAlarm.setIntercellSpacing(new Dimension(0, 1));
        jTblAlarm.setRowHeight(22);
        jTblAlarm.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        hideBeanColumn();

        jTblAlarm.setDefaultRenderer(Object.class, new PlainCellRenderer());
        jTblAlarm.getColumnModel().getColumn(1).setCellRenderer(new LevelCellRenderer());
        jTblAlarm.getSelectionModel().addListSelectionListener((e) -> {
            if (!e.getValueIsAdjusting() && !_updatingAlarmTable)
                showSelectedAlarmDetail();
        });
    }

    protected void setupDiskBriefArea()
    {
        jTxtDiskBrief.setBackground(COLOR_CARD);
        jTxtDiskBrief.setForeground(COLOR_TEXT);
        jTxtDiskBrief.setCaretColor(COLOR_ACCENT);
        jTxtDiskBrief.setFont(new Font("Monospaced", Font.PLAIN, 12));
        jTxtDiskBrief.setLineWrap(false);
        jTxtDiskBrief.setEditable(false);
        jTxtDiskBrief.setText("暂无分区数据");
    }

    protected void hideBeanColumn()
    {
        jTblAlarm.getColumnModel().getColumn(0).setMinWidth(0);
        jTblAlarm.getColumnModel().getColumn(0).setMaxWidth(0);
        jTblAlarm.getColumnModel().getColumn(0).setWidth(0);
    }

    protected void setupDetailArea()
    {
        jTxtDetail.setBackground(COLOR_CARD);
        jTxtDetail.setForeground(COLOR_TEXT);
        jTxtDetail.setCaretColor(COLOR_ACCENT);
        jTxtDetail.setFont(new Font("Monospaced", Font.PLAIN, 12));
        jTxtDetail.setLineWrap(true);
        jTxtDetail.setWrapStyleWord(true);
        jTxtDetail.setEditable(false);
        jTxtDetail.setText("选择左侧告警可查看详情");
    }

    public void startTimer()
    {
        _timer.schedule(new TimerTask()
        {
            public void run()
            {
                if (_closed)
                {
                    _timer.cancel();
                    return;
                }

                if (!GuiUtil.isComponentShowing(OpmSysDashboardPanel.this))
                    return;

                reloadNow();
            }
        }, 1200L, 1000L);
    }

    public void shutdown()
    {
        _closed = true;
        _timer.cancel();
    }

    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == jBtnRefresh)
            reloadNow();
        else if (e.getSource() == jBtnCollectNow)
            collectNowAsync();
        else if (e.getSource() == jCmbAgent)
            refreshViewFromCache();
    }

    public void reloadNow()
    {
        if (!_loading.compareAndSet(false, true))
            return;

        Thread t = new Thread("OPM GUI Reload")
        {
            public void run()
            {
                try
                {
                    loadData();
                }
                finally
                {
                    _loading.set(false);
                }
            }
        };
        t.setDaemon(true);
        t.start();
    }

    protected void loadData()
    {
        DashboardData data = new DashboardData();
        try
        {
            OpmCenterService intf = OpmClient.getIntf();
            if (intf == null)
                throw new Exception("OPM服务接口不可用，请确认服务端已启用opm starter");

            data.runtimeMeta = intf.queryRuntimeMeta();
            data.metrics = intf.queryLatestSysMetric(120);
            data.cpuMetrics = intf.queryLatestCpuMetric(120);
            data.diskMetrics = intf.queryLatestDiskMetric(120);
            data.ioMetrics = intf.queryLatestIoMetric(120);
            data.netMetrics = intf.queryLatestNetMetric(120);
            data.alarms = intf.queryLatestAlarmRef(120);
            data.error = null;
        }
        catch (Throwable err)
        {
            data.error = err;
        }

        GuiUtil.invokeLater(() -> applyData(data));
    }

    protected void applyData(DashboardData data)
    {
        if (data == null)
            return;

        if (data.error != null)
        {
            _allMetrics = new ArrayList<OpmSysMetricDo>();
            _allCpuMetrics = new ArrayList<OpmCpuMetricDo>();
            _allDiskMetrics = new ArrayList<OpmDiskMetricDo>();
            _allIoMetrics = new ArrayList<OpmIoMetricDo>();
            _allNetMetrics = new ArrayList<OpmNetMetricDo>();
            _allAlarms = new ArrayList<OpmAlarmRefDo>();
            setStatus("OPM连接失败: " + data.error.getMessage());
            jTxtDetail.setText("OPM服务连接失败:\n" + ToolUtilities.getExceptionStatck(data.error));
            clearUsageData();
            clearDiskPie();
            clearDiskBrief();
            clearIoBar();
            clearNetLine();
            clearCpuProcRows();
            clearAlarmRows();
            return;
        }

        _allMetrics = data.metrics == null ? new ArrayList<OpmSysMetricDo>() : data.metrics;
        _allCpuMetrics = data.cpuMetrics == null ? new ArrayList<OpmCpuMetricDo>() : data.cpuMetrics;
        _allDiskMetrics = data.diskMetrics == null ? new ArrayList<OpmDiskMetricDo>() : data.diskMetrics;
        _allIoMetrics = data.ioMetrics == null ? new ArrayList<OpmIoMetricDo>() : data.ioMetrics;
        _allNetMetrics = data.netMetrics == null ? new ArrayList<OpmNetMetricDo>() : data.netMetrics;
        _allAlarms = data.alarms == null ? new ArrayList<OpmAlarmRefDo>() : data.alarms;

        Map<String, Object> meta = data.runtimeMeta;
        _myAgentCode = meta == null ? null : ToolUtilities.getString(meta.get("agentCode"), null);
        _myAgentName = meta == null ? null : ToolUtilities.getString(meta.get("agentName"), null);
        _myUri = meta == null ? null : ToolUtilities.getString(meta.get("myUri"), null);
        _runtimeHasConfigRecord = meta != null && ToolUtilities.getBoolean(meta.get("runtimeHasConfigRecord"), false);
        _runtimeCollectorEnabled = meta != null && ToolUtilities.getBoolean(meta.get("runtimeCollectorEnabled"), false);

        rebuildAgentCombo();
        refreshViewFromCache();
    }

    protected void rebuildAgentCombo()
    {
        String oldKey = getSelectedAgentCode();
        LinkedHashMap<String, String> mapAgent = new LinkedHashMap<String, String>();

        for (OpmSysMetricDo m : _allMetrics)
        {
            if (m == null || ToolUtilities.isStringEmpty(m.agentCode))
                continue;
            mapAgent.put(m.agentCode, ToolUtilities.getString(m.agentName, m.agentCode));
        }

        mergeAgentMap(mapAgent, _allCpuMetrics);
        mergeAgentMap(mapAgent, _allDiskMetrics);
        mergeAgentMap(mapAgent, _allIoMetrics);
        mergeAgentMap(mapAgent, _allNetMetrics);

        for (OpmAlarmRefDo a : _allAlarms)
        {
            if (a == null || ToolUtilities.isStringEmpty(a.agentCode))
                continue;
            if (!mapAgent.containsKey(a.agentCode))
                mapAgent.put(a.agentCode, ToolUtilities.getString(a.agentName, a.agentCode));
        }

        jCmbAgent.removeActionListener(this);
        jCmbAgent.removeAllItems();
        jCmbAgent.addItem(new AgentItem("*", "全部代理"));

        for (Map.Entry<String, String> ent : mapAgent.entrySet())
        {
            String code = ent.getKey();
            String name = ToolUtilities.getString(ent.getValue(), code);
            String show = ToolUtilities.isStringEqual(name, code) ? code : name + " (" + code + ")";
            jCmbAgent.addItem(new AgentItem(code, show));
        }

        if (ToolUtilities.isStringEmpty(oldKey))
            jCmbAgent.setSelectedIndex(0);
        else
            selectAgentItem(oldKey);

        jCmbAgent.addActionListener(this);
    }

    protected <T> void mergeAgentMap(LinkedHashMap<String, String> mapAgent, List<T> list)
    {
        if (list == null)
            return;

        for (Object obj : list)
        {
            if (obj == null)
                continue;

            String code = null;
            String name = null;
            if (obj instanceof OpmCpuMetricDo)
            {
                code = ((OpmCpuMetricDo) obj).agentCode;
                name = ((OpmCpuMetricDo) obj).agentName;
            }
            else if (obj instanceof OpmDiskMetricDo)
            {
                code = ((OpmDiskMetricDo) obj).agentCode;
                name = ((OpmDiskMetricDo) obj).agentName;
            }
            else if (obj instanceof OpmIoMetricDo)
            {
                code = ((OpmIoMetricDo) obj).agentCode;
                name = ((OpmIoMetricDo) obj).agentName;
            }
            else if (obj instanceof OpmNetMetricDo)
            {
                code = ((OpmNetMetricDo) obj).agentCode;
                name = ((OpmNetMetricDo) obj).agentName;
            }

            if (ToolUtilities.isStringEmpty(code))
                continue;
            if (!mapAgent.containsKey(code))
                mapAgent.put(code, ToolUtilities.getString(name, code));
        }
    }

    protected void selectAgentItem(String code)
    {
        if (ToolUtilities.isStringEmpty(code))
        {
            jCmbAgent.setSelectedIndex(0);
            return;
        }

        for (int i = 0; i < jCmbAgent.getItemCount(); i++)
        {
            AgentItem one = (AgentItem) jCmbAgent.getItemAt(i);
            if (one != null && ToolUtilities.isStringEqual(one.code, code))
            {
                jCmbAgent.setSelectedIndex(i);
                return;
            }
        }

        jCmbAgent.setSelectedIndex(0);
    }

    protected String getSelectedAgentCode()
    {
        AgentItem item = (AgentItem) jCmbAgent.getSelectedItem();
        return item == null ? "*" : ToolUtilities.getString(item.code, "*");
    }

    protected void refreshViewFromCache()
    {
        String selected = getSelectedAgentCode();

        List<OpmSysMetricDo> metrics = filterSysMetricByAgent(selected);
        List<OpmCpuMetricDo> cpuMetrics = filterCpuMetricByAgent(selected);
        List<OpmDiskMetricDo> diskMetrics = filterDiskMetricByAgent(selected);
        List<OpmIoMetricDo> ioMetrics = filterIoMetricByAgent(selected);
        List<OpmNetMetricDo> netMetrics = filterNetMetricByAgent(selected);
        List<OpmAlarmRefDo> alarms = filterAlarmByAgent(selected);

        renderUsage(metrics);
        renderDiskPie(diskMetrics);
        renderIoBar(ioMetrics);
        renderNetLine(netMetrics);
        renderCpuProc(cpuMetrics);
        renderAlarms(alarms);

        String agt = "*".equals(selected) ? "全部代理" : selected;
        String me = ToolUtilities.isStringEmpty(_myAgentCode) ? "-" : _myAgentCode;
        String runStatus;
        if (!_runtimeHasConfigRecord)
            runStatus = "未配置(空转)";
        else if (!_runtimeCollectorEnabled)
            runStatus = "采集器全关(空转)";
        else
            runStatus = "采集中";

        setStatus("数据已刷新  Sys=" + metrics.size() + " CPU=" + cpuMetrics.size() + " Disk=" + diskMetrics.size()
                + " IO=" + ioMetrics.size() + " Net=" + netMetrics.size() + " 告警=" + alarms.size()
                + " 过滤=" + agt + " 当前代理=" + me + " 运行态=" + runStatus);
    }

    protected List<OpmSysMetricDo> filterSysMetricByAgent(String selected)
    {
        ArrayList<OpmSysMetricDo> list = new ArrayList<OpmSysMetricDo>();
        for (OpmSysMetricDo m : _allMetrics)
        {
            if (m == null)
                continue;
            if (!"*".equals(selected) && !ToolUtilities.isStringEqual(selected, m.agentCode))
                continue;
            list.add(m);
        }

        Collections.sort(list, new Comparator<OpmSysMetricDo>()
        {
            public int compare(OpmSysMetricDo a, OpmSysMetricDo b)
            {
                long ta = a == null || a.collectTime == null ? 0L : a.collectTime.longValue();
                long tb = b == null || b.collectTime == null ? 0L : b.collectTime.longValue();
                return ta == tb ? 0 : (ta < tb ? -1 : 1);
            }
        });

        while (list.size() > 90)
            list.remove(0);

        return list;
    }

    protected List<OpmCpuMetricDo> filterCpuMetricByAgent(String selected)
    {
        ArrayList<OpmCpuMetricDo> list = new ArrayList<OpmCpuMetricDo>();
        for (OpmCpuMetricDo m : _allCpuMetrics)
        {
            if (m == null)
                continue;
            if (!"*".equals(selected) && !ToolUtilities.isStringEqual(selected, m.agentCode))
                continue;
            list.add(m);
        }
        Collections.sort(list, new Comparator<OpmCpuMetricDo>()
        {
            public int compare(OpmCpuMetricDo a, OpmCpuMetricDo b)
            {
                long ta = a == null || a.collectTime == null ? 0L : a.collectTime.longValue();
                long tb = b == null || b.collectTime == null ? 0L : b.collectTime.longValue();
                return ta == tb ? 0 : (ta < tb ? -1 : 1);
            }
        });
        while (list.size() > 120)
            list.remove(0);
        return list;
    }

    protected List<OpmDiskMetricDo> filterDiskMetricByAgent(String selected)
    {
        ArrayList<OpmDiskMetricDo> list = new ArrayList<OpmDiskMetricDo>();
        for (OpmDiskMetricDo m : _allDiskMetrics)
        {
            if (m == null)
                continue;
            if (!"*".equals(selected) && !ToolUtilities.isStringEqual(selected, m.agentCode))
                continue;
            list.add(m);
        }
        Collections.sort(list, new Comparator<OpmDiskMetricDo>()
        {
            public int compare(OpmDiskMetricDo a, OpmDiskMetricDo b)
            {
                long ta = a == null || a.collectTime == null ? 0L : a.collectTime.longValue();
                long tb = b == null || b.collectTime == null ? 0L : b.collectTime.longValue();
                return ta == tb ? 0 : (ta < tb ? -1 : 1);
            }
        });
        while (list.size() > 120)
            list.remove(0);
        return list;
    }

    protected List<OpmIoMetricDo> filterIoMetricByAgent(String selected)
    {
        ArrayList<OpmIoMetricDo> list = new ArrayList<OpmIoMetricDo>();
        for (OpmIoMetricDo m : _allIoMetrics)
        {
            if (m == null)
                continue;
            if (!"*".equals(selected) && !ToolUtilities.isStringEqual(selected, m.agentCode))
                continue;
            list.add(m);
        }
        Collections.sort(list, new Comparator<OpmIoMetricDo>()
        {
            public int compare(OpmIoMetricDo a, OpmIoMetricDo b)
            {
                long ta = a == null || a.collectTime == null ? 0L : a.collectTime.longValue();
                long tb = b == null || b.collectTime == null ? 0L : b.collectTime.longValue();
                return ta == tb ? 0 : (ta < tb ? -1 : 1);
            }
        });
        while (list.size() > 120)
            list.remove(0);
        return list;
    }

    protected List<OpmNetMetricDo> filterNetMetricByAgent(String selected)
    {
        ArrayList<OpmNetMetricDo> list = new ArrayList<OpmNetMetricDo>();
        for (OpmNetMetricDo m : _allNetMetrics)
        {
            if (m == null)
                continue;
            if (!"*".equals(selected) && !ToolUtilities.isStringEqual(selected, m.agentCode))
                continue;
            list.add(m);
        }
        Collections.sort(list, new Comparator<OpmNetMetricDo>()
        {
            public int compare(OpmNetMetricDo a, OpmNetMetricDo b)
            {
                long ta = a == null || a.collectTime == null ? 0L : a.collectTime.longValue();
                long tb = b == null || b.collectTime == null ? 0L : b.collectTime.longValue();
                return ta == tb ? 0 : (ta < tb ? -1 : 1);
            }
        });
        while (list.size() > 120)
            list.remove(0);
        return list;
    }

    protected List<OpmAlarmRefDo> filterAlarmByAgent(String selected)
    {
        ArrayList<OpmAlarmRefDo> list = new ArrayList<OpmAlarmRefDo>();
        for (OpmAlarmRefDo a : _allAlarms)
        {
            if (a == null)
                continue;
            if (!"*".equals(selected) && !ToolUtilities.isStringEqual(selected, a.agentCode))
                continue;
            list.add(a);
        }

        Collections.sort(list, new Comparator<OpmAlarmRefDo>()
        {
            public int compare(OpmAlarmRefDo a, OpmAlarmRefDo b)
            {
                long ta = a == null || a.alarmTime == null ? 0L : a.alarmTime.longValue();
                long tb = b == null || b.alarmTime == null ? 0L : b.alarmTime.longValue();
                return ta == tb ? 0 : (ta < tb ? 1 : -1);
            }
        });

        while (list.size() > 120)
            list.remove(list.size() - 1);

        return list;
    }

    protected void renderUsage(List<OpmSysMetricDo> list)
    {
        clearUsageData();
        if (list == null || list.isEmpty())
        {
            jUsageChart.setTitle("系统资源趋势（暂无数据）");
            return;
        }

        List<OpmSysMetricDo> points = pickTimePoints(list, MAX_USAGE_CHART_POINTS);
        for (OpmSysMetricDo m : points)
        {
            String t = formatChartTime(m.collectTime == null ? 0L : m.collectTime.longValue());
            _usageData.addValue(rateToPercent(m.cpuUsageRate), "CPU", t);
            _usageData.addValue(rateToPercent(m.memUsageRate), "Memory", t);
            _usageData.addValue(rateToPercent(m.diskMaxUsageRate), "Disk", t);
        }
        jUsageChart.setTitle("系统资源趋势");
    }

    protected void clearUsageData()
    {
        while (_usageData.getColumnCount() > 0)
            _usageData.removeColumn(0);
    }

    protected void renderDiskPie(List<OpmDiskMetricDo> list)
    {
        clearDiskPie();
        clearDiskBrief();
        if (list == null || list.isEmpty())
            return;

        OpmDiskMetricDo last = list.get(list.size() - 1);
        List<Map<String, Object>> disks = parseListFromDetail(last == null ? null : last.detailJson, "disks");
        if (disks == null || disks.isEmpty())
        {
            if (last != null && !ToolUtilities.isStringEmpty(last.maxUsageMount))
            {
                String mount = normalizeMountLabel(last.maxUsageMount);
                _diskPieData.setValue(mount, rateToPercent(last.maxUsageRate));
                ArrayList<DiskRateRow> rows = new ArrayList<DiskRateRow>();
                rows.add(new DiskRateRow(mount, ToolUtilities.getDouble(last.maxUsageRate, -1D)));
                renderDiskBrief(rows);
            }
            return;
        }

        ArrayList<DiskRateRow> rows = new ArrayList<DiskRateRow>();
        int idx = 0;
        for (Map<String, Object> one : disks)
        {
            if (one == null)
                continue;
            boolean available = ToolUtilities.getBoolean(one.get("available"), true);
            if (!available)
                continue;

            String mount = ToolUtilities.getString(one.get("mountPath"), "disk" + idx);
            double rate = ToolUtilities.getDouble(one.get("usageRate"), -1D);
            if (rate < 0D)
                continue;

            rows.add(new DiskRateRow(mount, rate));
            idx++;
        }

        Collections.sort(rows, new Comparator<DiskRateRow>()
        {
            public int compare(DiskRateRow a, DiskRateRow b)
            {
                if (a == null && b == null)
                    return 0;
                if (a == null)
                    return 1;
                if (b == null)
                    return -1;

                if (a.usageRate == b.usageRate)
                    return ToolUtilities.getString(a.mount, "").compareTo(ToolUtilities.getString(b.mount, ""));
                return a.usageRate > b.usageRate ? -1 : 1;
            }
        });

        int cnt = 0;
        for (DiskRateRow row : rows)
        {
            if (row == null)
                continue;

            _diskPieData.setValue(normalizeMountLabel(row.mount), rateToPercent(Double.valueOf(row.usageRate)));
            cnt++;
            if (cnt >= 12)
                break;
        }

        renderDiskBrief(rows);
    }

    protected void clearDiskPie()
    {
        _diskPieData.clear();
    }

    protected void clearDiskBrief()
    {
        jTxtDiskBrief.setText("暂无分区数据");
        jTxtDiskBrief.setCaretPosition(0);
    }

    protected void renderDiskBrief(List<DiskRateRow> rows)
    {
        if (rows == null || rows.isEmpty())
        {
            clearDiskBrief();
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (DiskRateRow row : rows)
        {
            if (row == null)
                continue;

            if (sb.length() > 0)
                sb.append('\n');
            sb.append(normalizeMountLabel(row.mount));
            sb.append(": ");
            sb.append(formatDiskBriefPercent(row.usageRate));
        }

        if (sb.length() <= 0)
            sb.append("暂无分区数据");

        jTxtDiskBrief.setText(sb.toString());
        jTxtDiskBrief.setCaretPosition(0);
    }

    protected String normalizeMountLabel(String mount)
    {
        String m = ToolUtilities.getString(mount, "").trim();
        if (ToolUtilities.isStringEmpty(m))
            return "?";
        if (m.endsWith("\\") && m.length() > 1)
            return m.substring(0, m.length() - 1);
        if (m.endsWith("/") && m.length() > 1)
            return m.substring(0, m.length() - 1);
        return m;
    }

    protected String formatDiskBriefPercent(double rate)
    {
        if (rate < 0D)
            return "N/A";
        double v = rate * 100D;
        if (v < 0D)
            v = 0D;
        if (v > 100D)
            v = 100D;
        return String.format(java.util.Locale.US, "%.0f%%", Double.valueOf(v));
    }

    protected void renderIoBar(List<OpmIoMetricDo> list)
    {
        clearIoBar();
        if (list == null || list.isEmpty())
            return;

        OpmIoMetricDo last = list.get(list.size() - 1);
        List<Map<String, Object>> top = parseListFromDetail(last == null ? null : last.detailJson, "topProcesses");
        if (top == null)
            return;

        int cnt = 0;
        for (Map<String, Object> one : top)
        {
            if (one == null)
                continue;
            String name = ToolUtilities.getString(one.get("processName"), "p" + cnt);
            double read = ToolUtilities.getDouble(one.get("readRateBytesPerSec"), 0D);
            double write = ToolUtilities.getDouble(one.get("writeRateBytesPerSec"), 0D);
            _ioBarData.addValue(read, "Read", name);
            _ioBarData.addValue(write, "Write", name);
            cnt++;
            if (cnt >= 10)
                break;
        }
    }

    protected void clearIoBar()
    {
        while (_ioBarData.getColumnCount() > 0)
            _ioBarData.removeColumn(0);
    }

    protected void renderNetLine(List<OpmNetMetricDo> list)
    {
        clearNetLine();
        if (list == null || list.isEmpty())
            return;

        List<OpmNetMetricDo> points = pickTimePoints(list, MAX_NET_CHART_POINTS);
        for (OpmNetMetricDo m : points)
        {
            String t = formatChartTime(m.collectTime == null ? 0L : m.collectTime.longValue());
            _netLineData.addValue(ToolUtilities.getDouble(m.rxRate, 0D), "Rx", t);
            _netLineData.addValue(ToolUtilities.getDouble(m.txRate, 0D), "Tx", t);
            _netLineData.addValue(ToolUtilities.getDouble(m.totalRate, 0D), "Total", t);
        }
    }

    protected <T> List<T> pickTimePoints(List<T> list, int maxCount)
    {
        if (list == null || list.isEmpty())
            return new ArrayList<T>();
        if (maxCount <= 0 || list.size() <= maxCount)
            return list;

        ArrayList<T> out = new ArrayList<T>();
        double step = (list.size() - 1D) / (maxCount - 1D);
        int lastIndex = -1;
        for (int i = 0; i < maxCount; i++)
        {
            int idx = (int) Math.round(i * step);
            if (idx <= lastIndex)
                idx = lastIndex + 1;
            if (idx >= list.size())
                idx = list.size() - 1;

            out.add(list.get(idx));
            lastIndex = idx;
            if (lastIndex >= list.size() - 1)
                break;
        }

        if (out.isEmpty() || out.get(out.size() - 1) != list.get(list.size() - 1))
            out.add(list.get(list.size() - 1));
        return out;
    }

    protected String formatChartTime(long ts)
    {
        if (ts <= 0L)
            return "--";
        return new SimpleDateFormat("HH:mm:ss").format(new Date(ts));
    }

    protected void clearNetLine()
    {
        while (_netLineData.getColumnCount() > 0)
            _netLineData.removeColumn(0);
    }

    protected void renderCpuProc(List<OpmCpuMetricDo> list)
    {
        clearCpuProcRows();
        if (list == null || list.isEmpty())
            return;

        List<Map<String, Object>> top = null;
        for (int i = list.size() - 1; i >= 0; i--)
        {
            OpmCpuMetricDo one = list.get(i);
            top = parseListFromDetail(one == null ? null : one.detailJson, "topProcesses");
            if (top != null && !top.isEmpty())
                break;
        }

        if (top == null)
            return;

        int cnt = 0;
        for (Map<String, Object> one : top)
        {
            if (one == null)
                continue;
            int pid = ToolUtilities.getInteger(one.get("pid"), -1);
            String name = ToolUtilities.getString(one.get("processName"), "");
            double cpuRate = ToolUtilities.getDouble(one.get("cpuRate"), -1D);
            _cpuProcModel.addRow(new Object[] { pid < 0 ? "-" : String.valueOf(pid), name, formatPercent(cpuRate) });
            cnt++;
            if (cnt >= 20)
                break;
        }

        GuiUtil.adjustTableColumnWidth(jTblCpuProc, false);
    }

    protected void clearCpuProcRows()
    {
        while (_cpuProcModel.getRowCount() > 0)
            _cpuProcModel.removeRow(0);
    }

    @SuppressWarnings("unchecked")
    protected List<Map<String, Object>> parseListFromDetail(String detailJson, String key)
    {
        if (ToolUtilities.isStringEmpty(detailJson))
            return null;
        try
        {
            Object obj = CJson.fromJson(detailJson);
            Object normalized = normalizeCJsonObject(obj);
            if (!(normalized instanceof Map))
                return null;

            Object value = ((Map<String, Object>) normalized).get(key);
            if (!(value instanceof List))
                return null;

            return (List<Map<String, Object>>) value;
        }
        catch (Throwable err)
        {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    protected Object normalizeCJsonObject(Object obj)
    {
        if (obj == null)
            return null;

        if (obj instanceof Map)
        {
            Map<Object, Object> map = (Map<Object, Object>) obj;

            if (map.containsKey("#O"))
                return normalizeCJsonObject(map.get("#O"));

            if (map.containsKey("#M"))
            {
                Object items = map.get("#M");
                if (items instanceof List)
                {
                    LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
                    for (Object one : (List<Object>) items)
                    {
                        if (!(one instanceof Map))
                            continue;

                        Map<Object, Object> ent = (Map<Object, Object>) one;
                        String k = ToolUtilities.getString(ent.get("$"), null);
                        if (ToolUtilities.isStringEmpty(k))
                            continue;
                        ret.put(k, normalizeCJsonObject(ent.get("^")));
                    }
                    return ret;
                }
            }

            if (map.containsKey("#L"))
            {
                Object arr = map.get("#L");
                if (arr instanceof List)
                {
                    ArrayList<Object> ret = new ArrayList<Object>();
                    for (Object one : (List<Object>) arr)
                        ret.add(normalizeCJsonObject(one));
                    return ret;
                }
            }

            if (map.containsKey("@") || map.containsKey("@A"))
                return null;

            LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
            for (Map.Entry<Object, Object> ent : map.entrySet())
            {
                String k = String.valueOf(ent.getKey());
                if (k.startsWith("#"))
                    continue;
                ret.put(k, normalizeCJsonObject(ent.getValue()));
            }
            return ret;
        }

        if (obj instanceof List)
        {
            ArrayList<Object> ret = new ArrayList<Object>();
            for (Object one : (List<Object>) obj)
                ret.add(normalizeCJsonObject(one));
            return ret;
        }

        return obj;
    }

    protected String formatPercent(double rate)
    {
        if (rate < 0D)
            return "N/A";
        return String.format(java.util.Locale.US, "%.2f%%", Double.valueOf(rate * 100D));
    }

    protected void renderAlarms(List<OpmAlarmRefDo> list)
    {
        String oldKey = _selectedAlarmKey;
        if (ToolUtilities.isStringEmpty(oldKey))
            oldKey = getSelectedAlarmKeyFromTable();

        _updatingAlarmTable = true;
        clearAlarmRows();
        if (list == null)
        {
            _updatingAlarmTable = false;
            return;
        }

        for (OpmAlarmRefDo a : list)
        {
            _alarmModel.addRow(new Object[] {
                    a,
                    levelText(a.alarmLevel),
                    ToolUtilities.getString(a.ruleLabel, a.ruleKey),
                    ToolUtilities.getString(a.agentName, a.agentCode),
                    ToolUtilities.time2String(a.alarmTime == null ? 0L : a.alarmTime.longValue(), false, false),
                    ToolUtilities.getString(a.message, "")
            });
        }

        GuiUtil.adjustTableColumnWidth(jTblAlarm, false);
        hideBeanColumn();
        _updatingAlarmTable = false;

        if (_alarmModel.getRowCount() <= 0)
        {
            _selectedAlarmKey = null;
            jTxtDetail.setText("当前筛选条件下暂无告警");
            return;
        }

        int restoreRow = findAlarmRowByKey(oldKey);
        if (restoreRow >= 0)
        {
            jTblAlarm.setRowSelectionInterval(restoreRow, restoreRow);
            showSelectedAlarmDetail();
            return;
        }

        if (ToolUtilities.isStringEmpty(oldKey))
        {
            jTblAlarm.setRowSelectionInterval(0, 0);
            showSelectedAlarmDetail();
        }
    }

    protected void clearAlarmRows()
    {
        while (_alarmModel.getRowCount() > 0)
            _alarmModel.removeRow(0);
    }

    protected void showSelectedAlarmDetail()
    {
        int row = jTblAlarm.getSelectedRow();
        if (row < 0)
            return;

        int modelRow = jTblAlarm.convertRowIndexToModel(row);
        if (modelRow < 0 || modelRow >= _alarmModel.getRowCount())
            return;

        Object obj = _alarmModel.getValueAt(modelRow, 0);
        if (!(obj instanceof OpmAlarmRefDo))
            return;

        OpmAlarmRefDo a = (OpmAlarmRefDo) obj;
        _selectedAlarmKey = buildAlarmSelectionKey(a);
        StringBuilder sb = new StringBuilder();
        sb.append("告警级别: ").append(levelText(a.alarmLevel)).append('\n');
        sb.append("采集器: ").append(ToolUtilities.getString(a.collectorLabel, a.collectorKey)).append('\n');
        sb.append("规则: ").append(ToolUtilities.getString(a.ruleLabel, a.ruleKey)).append('\n');
        sb.append("代理: ").append(ToolUtilities.getString(a.agentName, a.agentCode)).append('\n');
        sb.append("时间: ").append(ToolUtilities.time2String(a.alarmTime == null ? 0L : a.alarmTime.longValue(), false, false)).append('\n');
        sb.append("请求ID: ").append(ToolUtilities.getString(a.alarmRequestId, "")).append('\n');
        sb.append("关联指标UUID: ").append(ToolUtilities.getString(a.metricMainUuid, "")).append("\n\n");
        sb.append("消息:\n").append(ToolUtilities.getString(a.message, "")).append("\n\n");
        sb.append("细节JSON:\n").append(ToolUtilities.getString(a.detailJson, ""));

        jTxtDetail.setText(sb.toString());
        jTxtDetail.setCaretPosition(0);
    }

    protected String getSelectedAlarmKeyFromTable()
    {
        int row = jTblAlarm.getSelectedRow();
        if (row < 0)
            return null;

        int modelRow = jTblAlarm.convertRowIndexToModel(row);
        if (modelRow < 0 || modelRow >= _alarmModel.getRowCount())
            return null;

        Object obj = _alarmModel.getValueAt(modelRow, 0);
        if (!(obj instanceof OpmAlarmRefDo))
            return null;

        return buildAlarmSelectionKey((OpmAlarmRefDo) obj);
    }

    protected int findAlarmRowByKey(String key)
    {
        if (ToolUtilities.isStringEmpty(key))
            return -1;

        for (int i = 0; i < _alarmModel.getRowCount(); i++)
        {
            Object obj = _alarmModel.getValueAt(i, 0);
            if (!(obj instanceof OpmAlarmRefDo))
                continue;

            String rowKey = buildAlarmSelectionKey((OpmAlarmRefDo) obj);
            if (ToolUtilities.isStringEqual(key, rowKey))
                return i;
        }
        return -1;
    }

    protected String buildAlarmSelectionKey(OpmAlarmRefDo a)
    {
        if (a == null)
            return null;

        StringBuilder sb = new StringBuilder();
        sb.append(ToolUtilities.getString(a.alarmRequestId, ""));
        sb.append('|').append(ToolUtilities.getString(a.alarmUuid, ""));
        sb.append('|').append(a.alarmTime == null ? 0L : a.alarmTime.longValue());
        sb.append('|').append(ToolUtilities.getString(a.ruleKey, ""));
        sb.append('|').append(ToolUtilities.getString(a.agentCode, ""));
        return sb.toString();
    }

    protected void collectNowAsync()
    {
        Thread t = new Thread("OPM Collect Now")
        {
            public void run()
            {
                try
                {
                    setStatusLater("正在执行即时采集...");
                    OpmCenterService intf = OpmClient.getIntf();
                    if (intf == null)
                        throw new Exception("OPM服务接口不可用");

                    String[] keys = new String[] {"sys", "topCpu", "disk", "topIo", "topNet"};
                    StringBuilder sb = new StringBuilder();
                    for (String key : keys)
                    {
                        try
                        {
                            OpmCollectResult rs = intf.collectNow(key);
                            if (rs == null)
                                continue;
                            if (sb.length() > 0)
                                sb.append(" | ");
                            sb.append(key).append(':').append(ToolUtilities.getString(rs.summary, "ok"));
                        }
                        catch (Throwable sub)
                        {
                        }
                    }
                    setStatusLater("即时采集完成: " + sb.toString());
                    reloadNow();
                }
                catch (Throwable err)
                {
                    setStatusLater("即时采集失败: " + err.getMessage());
                    GuiUtil.invokeLater(() -> DetailErrorMsg.showError(OpmSysDashboardPanel.this, err));
                }
            }
        };
        t.setDaemon(true);
        t.start();
    }

    protected void setStatus(String text)
    {
        jLabStatus.setText(text);
    }

    protected void setStatusLater(String text)
    {
        GuiUtil.invokeLater(() -> setStatus(text));
    }

    protected double rateToPercent(Double rate)
    {
        if (rate == null || rate.doubleValue() < 0D)
            return 0D;
        double v = rate.doubleValue() * 100D;
        if (v > 100D)
            v = 100D;
        return v;
    }

    protected String levelText(Integer level)
    {
        if (level == null)
            return "未知";
        if (level.intValue() == TsAlarm.LEVEL_ERROR_CRITICAL)
            return "严重";
        if (level.intValue() == TsAlarm.LEVEL_WARN)
            return "预警";
        if (level.intValue() > TsAlarm.LEVEL_WARN)
            return "错误";
        if (level.intValue() <= 0)
            return "信息";
        return "L" + level.intValue();
    }

    class PlainCellRenderer extends DefaultTableCellRenderer
    {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
        {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setFont(FONT_TABLE);
            setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 0));
            if (!isSelected)
                setForeground(COLOR_TEXT);
            return this;
        }
    }

    class LevelCellRenderer extends PlainCellRenderer
    {
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
        {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            if (isSelected)
                return this;

            String txt = ToolUtilities.getString(value, "");
            if ("严重".equals(txt))
                setForeground(new Color(0xFF, 0x6A, 0x6A));
            else if ("预警".equals(txt))
                setForeground(new Color(0xFF, 0xCF, 0x66));
            else if ("错误".equals(txt))
                setForeground(new Color(0xFF, 0x98, 0x5A));
            else
                setForeground(COLOR_TEXT);
            return this;
        }
    }

    static class AgentItem
    {
        String code;
        String label;

        AgentItem(String code, String label)
        {
            this.code = code;
            this.label = label;
        }

        public String toString()
        {
            return label;
        }
    }

    static class DiskRateRow
    {
        String mount;
        double usageRate;

        DiskRateRow(String mount, double usageRate)
        {
            this.mount = mount;
            this.usageRate = usageRate;
        }
    }

    static class DashboardData
    {
        Map<String, Object> runtimeMeta;
        List<OpmSysMetricDo> metrics;
        List<OpmCpuMetricDo> cpuMetrics;
        List<OpmDiskMetricDo> diskMetrics;
        List<OpmIoMetricDo> ioMetrics;
        List<OpmNetMetricDo> netMetrics;
        List<OpmAlarmRefDo> alarms;
        Throwable error;
    }
}
