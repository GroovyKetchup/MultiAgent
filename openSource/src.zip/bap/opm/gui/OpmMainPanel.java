package bap.opm.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import com.leavay.client.util.MBox;
import com.project.gui.common.GuiUtil;

public class OpmMainPanel extends JPanel implements ActionListener
{
    public static final Color COLOR_BG = new Color(0x03, 0x1B, 0x2D);
    public static final Color COLOR_BG_CARD = new Color(0x0B, 0x23, 0x39);
    public static final Color COLOR_TEXT = new Color(0xA7, 0xDA, 0xF4);
    public static final Color COLOR_ACCENT = new Color(0x47, 0xD0, 0xFF);

    JButton jBtnRefresh = GuiUtil.createToolButton("redo_16.png", "刷新", this);
    JLabel jLabTitle = new JLabel("OPM 运维监控中心");
    JLabel jLabSubTitle = new JLabel("系统趋势 / 告警中心 / 多代理筛选");

    JTabbedPane jTabs = new JTabbedPane();
    OpmSysDashboardPanel jSysDashboard;

    public OpmMainPanel() throws Exception
    {
        jbInit();
    }

    protected void jbInit() throws Exception
    {
        jSysDashboard = new OpmSysDashboardPanel();

        setBackground(COLOR_BG);
        setPreferredSize(new Dimension(1400, 860));

        jLabTitle.setForeground(COLOR_ACCENT);
        jLabTitle.setFont(new Font("Dialog", Font.BOLD, 20));

        jLabSubTitle.setForeground(COLOR_TEXT);
        jLabSubTitle.setFont(new Font("Dialog", Font.PLAIN, 13));

        styleButton(jBtnRefresh);

        jTabs.setBackground(COLOR_BG_CARD);
        jTabs.setForeground(COLOR_TEXT);
        jTabs.addTab("系统监控", jSysDashboard);

        Box head = MBox.createHBar(30, jLabTitle, MBox.HStrut(10), jLabSubTitle, MBox.HGlue(), jBtnRefresh);
        Box main = Box.createVerticalBox();
        main.add(head);
        main.add(MBox.VStrut(6));
        main.add(jTabs);

        GuiUtil.setGridLayout(this, main);
    }

    protected void styleButton(JButton btn)
    {
        btn.setBackground(COLOR_BG_CARD);
        btn.setForeground(COLOR_TEXT);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
    }

    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == jBtnRefresh)
            jSysDashboard.reloadNow();
    }

    public void shutdown()
    {
        if (jSysDashboard != null)
            jSysDashboard.shutdown();
    }
}
