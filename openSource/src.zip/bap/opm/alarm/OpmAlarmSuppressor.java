package bap.opm.alarm;

import org.nutz.dao.Cnd;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.md.opm.OpmAlarmRefDo;
import bap.opm.OpmConst;
import bap.opm.OpmRuleResult;
import cell.cdao.IDao;

/**
 * OPM告警抑制器。
 */
public class OpmAlarmSuppressor
{
    public static class SuppressDecision
    {
        public boolean suppressed;
        public String fingerprint;
        public int suppressSec;
        public OpmAlarmRefDo latestAlarm;
    }

    private OpmAlarmSuppressor()
    {
    }

    public static SuppressDecision evaluate(IDao dao, String agentCode, String collectorKey, OpmRuleResult rule, long now) throws Exception
    {
        SuppressDecision decision = new SuppressDecision();
        decision.fingerprint = OpmAlarmPolicy.buildSuppressFingerprint(agentCode, collectorKey, rule);
        decision.suppressSec = OpmAlarmPolicy.getSuppressSec();

        if (dao == null || rule == null || decision.suppressSec <= 0)
            return decision;

        long beginTime = now - decision.suppressSec * 1000L;
        Cnd cnd = Cnd.where(OpmAlarmRefDo.AgentCode, "=", agentCode)
                .and(OpmAlarmRefDo.CollectorKey, "=", collectorKey)
                .and(OpmAlarmRefDo.RuleKey, "=", rule.ruleKey)
                .and(OpmAlarmRefDo.AlarmTime, ">=", Long.valueOf(beginTime))
                .desc(OpmAlarmRefDo.AlarmTime);

        java.util.List<OpmAlarmRefDo> list = dao.queryDoList(OpmAlarmRefDo.class, cnd,
                OpmAlarmRefDo.UUID,
                OpmAlarmRefDo.AlarmTime,
                OpmAlarmRefDo.Message,
                OpmAlarmRefDo.DetailJson,
                OpmAlarmRefDo.AgentCode,
                OpmAlarmRefDo.CollectorKey,
                OpmAlarmRefDo.RuleKey);
        if (list == null || list.isEmpty())
            return decision;

        for (OpmAlarmRefDo one : list)
        {
            String fp = OpmAlarmPolicy.buildSuppressFingerprint(one.agentCode, one.collectorKey, toRule(one));
            if (ToolUtilities.isStringEqual(fp, decision.fingerprint, true))
            {
                decision.suppressed = true;
                decision.latestAlarm = one;
                return decision;
            }
        }

        return decision;
    }

    protected static OpmRuleResult toRule(OpmAlarmRefDo alarm)
    {
        OpmRuleResult rule = new OpmRuleResult();
        if (alarm == null)
            return rule;
        rule.ruleKey = alarm.ruleKey;
        rule.ruleLabel = alarm.ruleLabel;
        rule.message = alarm.message;
        rule.detailJson = alarm.detailJson;
        rule.alarmLevel = ToolUtilities.getInteger(alarm.alarmLevel, 0);
        return rule;
    }

    public static void logSuppressed(String agentCode, String collectorKey, OpmRuleResult rule, SuppressDecision decision)
    {
        java.util.LinkedHashMap<String, Object> detail = new java.util.LinkedHashMap<String, Object>();
        detail.put("agentCode", agentCode);
        detail.put("collectorKey", collectorKey);
        detail.put("ruleKey", rule == null ? null : rule.ruleKey);
        detail.put("ruleLabel", rule == null ? null : rule.ruleLabel);
        detail.put("message", rule == null ? null : rule.message);
        detail.put("fingerprint", decision == null ? null : decision.fingerprint);
        detail.put("suppressSec", decision == null ? null : Integer.valueOf(decision.suppressSec));
        detail.put("latestAlarmTime", decision == null || decision.latestAlarm == null ? null : decision.latestAlarm.alarmTime);
        detail.put("latestAlarmUuid", decision == null || decision.latestAlarm == null ? null : decision.latestAlarm.getUuid());
        ToolUtilities.warning(OpmConst.LOG, "[opm.alarm.suppressed] " + CJson.toJson(detail));
    }
}
