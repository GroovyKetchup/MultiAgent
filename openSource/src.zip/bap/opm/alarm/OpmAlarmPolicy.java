package bap.opm.alarm;

import java.util.Map;
import java.util.regex.Pattern;

import bap.opm.OpmParamDef;
import com.leavay.common.util.GsonUtil;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.opm.OpmCollectResult;
import bap.opm.OpmBackendConfig;
import bap.opm.OpmConst;
import bap.opm.OpmRuleResult;
import bap.opm.registry.OpmAlarmConfigKeys;
import tiny.service.md.TsAlarm;

/**
 * OPM告警策略工具。
 *
 * 测试用例：bap.opm.test.OpmPgLongSqlSuppressKeyTest
 */
public class OpmAlarmPolicy
{
    public static final String RULE_KEY_EXPECTATION = "collectExpectation";
    public static final String RULE_LABEL_EXPECTATION = "采集频度预期";

    protected static final Pattern P_NUM = Pattern.compile("\\d+(?:\\.\\d+)?");
    protected static final Pattern P_TIME = Pattern.compile("\\b\\d{10,13}\\b");

    private OpmAlarmPolicy()
    {
    }

    public static OpmParamDef newGlobalSuppressParam()
    {
        return new OpmParamDef(OpmConst.CONF_ALARM_SUPPRESS_SEC, OpmConst.LABEL_ALARM_SUPPRESS_SEC, "int", String.valueOf(OpmConst.DEFAULT_ALARM_SUPPRESS_SEC))
                .setDesc("同一代理上最近N秒内若再次出现主要内容一致的告警，则抑制重复告警，仅记录抑制日志。该配置对所有采集器统一生效，默认5分钟。");
    }

    public static int getSuppressSec()
    {
        return Math.max(0, OpmBackendConfig.getAlarmSuppressSec());
    }

    public static String buildSuppressFingerprint(String agentCode, String collectorKey, OpmRuleResult rule)
    {
        String suppressKey = resolveSuppressKey(rule);
        StringBuilder sb = new StringBuilder();
        sb.append(normalizeToken(agentCode)).append('|');
        sb.append(normalizeToken(collectorKey)).append('|');
        sb.append(normalizeToken(rule == null ? null : rule.ruleKey)).append('|');
        if (!ToolUtilities.isStringEmpty(suppressKey, true))
            sb.append(normalizeSuppressKey(suppressKey));
        else
            sb.append(normalizeMessage(rule == null ? null : rule.message));
        return sb.toString();
    }

    protected static String resolveSuppressKey(OpmRuleResult rule)
    {
        Map<String, Object> detail = parseDetailMap(rule == null ? null : rule.detailJson);
        if (detail == null || detail.isEmpty())
            return null;
        String suppressKey = ToolUtilities.getString(detail.get("suppressKey"), null);
        if (!ToolUtilities.isStringEmpty(suppressKey, true))
            return suppressKey;
        suppressKey = ToolUtilities.getString(detail.get("_suppressKey"), null);
        return ToolUtilities.isStringEmpty(suppressKey, true) ? null : suppressKey;
    }

    @SuppressWarnings("unchecked")
    protected static Map<String, Object> parseDetailMap(String detailJson)
    {
        if (ToolUtilities.isStringEmpty(detailJson, true))
            return null;
        try
        {
            Object obj = CJson.fromJson(detailJson);
            if (obj instanceof Map)
                return (Map<String, Object>) obj;
        }
        catch (Throwable ignore)
        {
        }
        try
        {
            Object obj = GsonUtil.fromJson(detailJson, Object.class);
            if (obj instanceof Map)
                return (Map<String, Object>) obj;
        }
        catch (Throwable ignore)
        {
        }
        return null;
    }

    public static String normalizeToken(String text)
    {
        String val = ToolUtilities.getString(text, "").trim().toLowerCase();
        return val;
    }

    public static String normalizeMessage(String message)
    {
        String text = ToolUtilities.getString(message, "").toLowerCase();
        text = P_TIME.matcher(text).replaceAll("#time");
        text = P_NUM.matcher(text).replaceAll("#num");
        text = text.replace('\r', ' ').replace('\n', ' ');
        text = text.replaceAll("\\s+", " ").trim();
        return text;
    }

    public static String normalizeSuppressKey(String suppressKey)
    {
        String text = ToolUtilities.getString(suppressKey, "").toLowerCase();
        text = text.replace('\r', ' ').replace('\n', ' ');
        text = text.replaceAll("\\s+", " ").trim();
        return text;
    }

    public static OpmRuleResult buildExpectationRule(String collectorKey, String collectorLabel,
            long expectedTime, long now, long lagMs, long intervalMs, int overdueCount)
    {
        return buildExpectationRule(collectorKey, collectorLabel, expectedTime, now, lagMs, intervalMs, overdueCount, null, null, null);
    }

    public static OpmRuleResult buildExpectationRule(String collectorKey, String collectorLabel,
            long expectedTime, long now, long lagMs, long intervalMs, int overdueCount,
            String reason, String suggestion, Long runningMs)
    {
        OpmRuleResult rs = new OpmRuleResult();
        rs.triggered = true;
        rs.alarmLevel = TsAlarm.LEVEL_WARN;
        rs.ruleKey = RULE_KEY_EXPECTATION;
        rs.ruleLabel = RULE_LABEL_EXPECTATION;

        String finalReason = ToolUtilities.getString(reason, "采集器执行耗时超过配置周期，导致下一轮调度到点时上一轮仍未完成");
        String finalSuggestion = ToolUtilities.getString(suggestion,
                "建议优先检查该采集器执行耗时、目标主机负载、采样范围与采样周期；必要时增大采集周期或优化采集逻辑，避免连续重叠。");
        String label = ToolUtilities.getString(collectorLabel, ToolUtilities.getString(collectorKey, "unknown"));
        rs.message = "采集周期未达预期: 采集器=" + label
                + "，原因=" + finalReason
                + "，建议=" + finalSuggestion
                + " [collector=" + ToolUtilities.getString(collectorKey, "unknown")
                + ", intervalMs=" + intervalMs
                + ", lagMs=" + lagMs
                + ", overdueCount=" + overdueCount
                + "]";

        java.util.LinkedHashMap<String, Object> detail = new java.util.LinkedHashMap<String, Object>();
        detail.put("collectorKey", collectorKey);
        detail.put("collectorLabel", collectorLabel);
        detail.put("expectedCollectTime", Long.valueOf(expectedTime));
        detail.put("alarmTime", Long.valueOf(now));
        detail.put("lagMs", Long.valueOf(lagMs));
        detail.put("intervalMs", Long.valueOf(intervalMs));
        detail.put("overdueCount", Integer.valueOf(overdueCount));
        detail.put("reason", finalReason);
        detail.put("suggestion", finalSuggestion);
        detail.put("runningMs", runningMs);
        rs.detailJson = com.leavay.common.util.GsonUtil.toJson(detail);
        return rs;
    }

    public static String buildExpectationRuleKey(String collectorKey)
    {
        return OpmAlarmConfigKeys.buildExpectationRuleKey(ToolUtilities.getString(collectorKey, OpmConst.MODULE_NAME));
    }

    public static void fillExpectationRule(OpmRuleResult rule, OpmCollectResult collect, String collectorKey, String collectorLabel)
    {
        if (rule == null)
            return;
        if (ToolUtilities.isStringEmpty(rule.ruleKey, true))
            rule.ruleKey = buildExpectationRuleKey(collectorKey);
        if (ToolUtilities.isStringEmpty(rule.ruleLabel, true))
            rule.ruleLabel = RULE_LABEL_EXPECTATION;
        if (ToolUtilities.isStringEmpty(rule.message, true))
            rule.message = "采集周期未达预期: collector=" + ToolUtilities.getString(collectorKey, "unknown");
        if (collect != null)
        {
            if (ToolUtilities.isStringEmpty(collect.collectorKey, true))
                collect.collectorKey = collectorKey;
            if (ToolUtilities.isStringEmpty(collect.collectorLabel, true))
                collect.collectorLabel = collectorLabel;
        }
    }
}
