package bap.opm;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import org.nutz.dao.Cnd;

import com.cdao.dto.CPager;
import com.cdao.mgr.CDaoUtil;
import com.leavay.common.util.GsonUtil;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.nio.crpc.CRpcServer;
import com.leavay.starter.ModuleItem;
import com.leavay.starter.StarterConf;
import com.leavay.starter.StarterItem;
import com.leavay.starter.StarterMain;

import bap.cells.Cells;
import bap.md.opm.OpmAlarmExtDo;
import bap.md.opm.OpmAlarmRefDo;
import bap.md.opm.OpmMetricExtDo;
import bap.md.opm.OpmMetricMainDo;
import bap.md.opm.cpu.OpmCpuMetricDo;
import bap.md.opm.disk.OpmDiskMetricDo;
import bap.md.opm.io.OpmIoMetricDo;
import bap.md.opm.memory.OpmMemoryMetricDo;
import bap.md.opm.net.OpmNetMetricDo;
import bap.md.opm.pg.OpmPgLockDetailDo;
import bap.md.opm.pg.OpmPgSqlDetailDo;
import bap.md.opm.sys.OpmSysMetricDo;
import bap.md.opm.cfg.OpmAgentConfigDo;
import bap.opm.alarm.OpmAlarmPolicy;
import bap.opm.alarm.OpmAlarmSuppressor;
import bap.opm.collector.topcpu.OpmTopCpuConst;
import bap.opm.collector.focus.OpmFocusConst;
import bap.opm.collector.topmemory.OpmTopMemoryConst;
import bap.opm.collector.pg.OpmPgConst;
import bap.opm.collector.system.OpmSysConst;
import bap.opm.cfg.OpmAgentConfigMgr;
import cell.bap.opm.collector.IOpmCollector;
import cell.bap.opm.collector.system.COpmSysCollector;
import cell.bap.opm.collector.system.IOpmSysCollector;
import cell.bap.opm.simulator.IOpmCollectorSimulator;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.cmn.TsHelper;
import tiny.service.md.TsAlarm;

public class OpmCenter
{
    protected static OpmCenter _me;

    public synchronized static OpmCenter get()
    {
        if (_me == null)
            _me = new OpmCenter();
        return _me;
    }

    protected volatile boolean _initedBeforeDao = false;
    protected volatile boolean _started = false;

    protected volatile OpmAgentContext _agentCtx;

    protected final ConcurrentHashMap<String, IOpmCollector> _collectors = new ConcurrentHashMap<String, IOpmCollector>();
    protected final ConcurrentHashMap<String, Long> _nextCollect = new ConcurrentHashMap<String, Long>();
    protected final ConcurrentHashMap<String, Long> _collectorRunningSince = new ConcurrentHashMap<String, Long>();

    protected volatile ExecutorService _collectorExecutor;
    protected volatile int _collectorWorkerSize = 0;
    protected final AtomicInteger _collectorThreadSeq = new AtomicInteger(1);

    protected volatile long _lastCollectorScan = 0L;
    protected volatile long _lastPluginTag = -1L;
    protected volatile long _lastRetentionClean = 0L;
    protected volatile long _lastRuntimeCfgCheck = 0L;
    protected volatile boolean _runtimeHasConfigRecord = false;
    protected volatile boolean _runtimeCollectorEnabled = false;

    protected static final long RUNTIME_CONFIG_REFRESH_INTERVAL_MS = 3000L;

    protected Thread _mainThread;

    protected volatile OpmSimulator _simulator = null;

    protected OpmCenter()
    {
    }

    public synchronized void initBeforeDao() throws Exception
    {
        // 在 DAO 启动前注册静态模型（主表+索引+扩展+采集器自定义模型）
        if (_initedBeforeDao)
            return;

        // 初始化配置注册表
        initConfigRegistry();

        CRpcServer.registService(OpmCenterService.class, OpmCenterServiceImpl.get());

        refreshCollectors(true);

        LinkedHashSet<Class> setModel = new LinkedHashSet<Class>();
        setModel.add(OpmMetricMainDo.class);
        setModel.add(OpmMetricExtDo.class);
        setModel.add(OpmAlarmRefDo.class);
        setModel.add(OpmAlarmExtDo.class);
        setModel.add(OpmAgentConfigDo.class);
        // TsAlarm是由Chief初始化
//        setModel.add(TsAlarm.class); 

        for (IOpmCollector c : _collectors.values())
        {
            try
            {
                List<Class> one = c.getModelClasses();
                if (one != null)
                    setModel.addAll(one);
            }
            catch (Throwable err)
            {
                ToolUtilities.error(OpmConst.LOG, "Failed to collect model classes from collector: " + c, err);
            }
        }

        IDaoService.get().addInitModel(setModel.toArray(new Class[setModel.size()]));
        _initedBeforeDao = true;
    }

    public synchronized void start() throws Exception
    {
        // OPM 只允许单次启动，生命周期和进程一致
        if (_started)
            return;

        if (!_initedBeforeDao)
            initBeforeDao();

        _agentCtx = OpmAgentContext.detect();
        // 启动时刷新运行态配置
        refreshRuntimeConfig(true);

        _mainThread = new Thread("OPM Main Thread")
        {
            @Override
            public void run()
            {
                mainLoop();
            }
        };
        _mainThread.start();
        _started = true;
    }

    protected void mainLoop()
    {
        // 主循环职责：采集调度、采集器刷新、保留策略清理
        for (;;)
        {
            try
            {
                refreshRuntimeConfig(false);

                if (!_runtimeHasConfigRecord || !_runtimeCollectorEnabled)
                {
                    ToolUtilities.sleep(5000);
                    continue;
                }

                loopCollectors();
                cleanRetentionIfNeed();
            }
            catch (Throwable err)
            {
                ToolUtilities.error(OpmConst.LOG, "Error in OPM main loop", err);
            }

            ToolUtilities.sleep(1000);
        }
    }

    protected void loopCollectors() throws Exception
    {
        // 按采集器独立周期调度执行（允许并发，超周期时跳过重叠）
        long now = System.currentTimeMillis();
        List<IOpmCollector> lst = new ArrayList<IOpmCollector>(_collectors.values());
        for (IOpmCollector c : lst)
        {
            if (c == null)
                continue;

            String key = safeCollectorKey(c);
            long next = ToolUtilities.getLong(_nextCollect.get(key), 0L);
            if (now < next)
                continue;

            long interval = c.getCollectIntervalMs();
            if (interval <= 0L)
                interval = OpmBackendConfig.getCoreCollectIntervalMs();
            if (interval < 1000L)
                interval = 1000L;

            long runningSince = getCollectorRunningSince(key);
            if (runningSince > 0L || !markCollectorRunning(key, now))
            {
                long latestRunningSince = getCollectorRunningSince(key);
                _nextCollect.put(key, now + interval);
                triggerCollectExpectationAlarm(key, c, now, now, interval, latestRunningSince, "overlap");
                if (OpmBackendConfig.isDebugEnable())
                {
                    ToolUtilities.info(OpmConst.LOG, "[opm.schedule.skip.overlap] collector=" + key
                            + ", runningMs=" + (latestRunningSince <= 0L ? 0L : now - latestRunningSince)
                            + ", nextInMs=" + interval);
                }
                continue;
            }

            _nextCollect.put(key, now + interval);

            ExecutorService executor = ensureCollectorExecutor();
            final IOpmCollector collector = c;
            final String collectorKey = key;
            final long taskStart = now;
            try
            {
                executor.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        executeCollectorSafely(collectorKey, collector, taskStart, "schedule");
                    }
                });
            }
            catch (Throwable err)
            {
                releaseCollectorRunning(collectorKey);
                ToolUtilities.warning(OpmConst.LOG, "[opm.schedule.submit.error] collector=" + collectorKey, err);
            }
        }
    }

    protected long getCollectorRunningSince(String collectorKey)
    {
        return ToolUtilities.getLong(_collectorRunningSince.get(collectorKey), 0L);
    }

    protected boolean markCollectorRunning(String collectorKey, long startMillis)
    {
        _collectorRunningSince.putIfAbsent(collectorKey, 0L);
        return _collectorRunningSince.replace(collectorKey, 0L, startMillis);
    }

    protected void releaseCollectorRunning(String collectorKey)
    {
        if (collectorKey != null)
            _collectorRunningSince.put(collectorKey, 0L);
    }

    protected synchronized ExecutorService ensureCollectorExecutor()
    {
        if (_collectorExecutor != null)
            return _collectorExecutor;

        int collectors = Math.max(1, _collectors.size());
        int cpuCount = Runtime.getRuntime().availableProcessors();
        if (cpuCount <= 0)
            cpuCount = 2;
        int workers = Math.max(1, Math.min(collectors, Math.max(2, cpuCount)));
        _collectorWorkerSize = workers;

        _collectorExecutor = Executors.newFixedThreadPool(_collectorWorkerSize, new ThreadFactory()
        {
            @Override
            public Thread newThread(Runnable run)
            {
                Thread t = new Thread(run, "OPM Collector Worker-" + _collectorThreadSeq.getAndIncrement());
                t.setDaemon(true);
                return t;
            }
        });

        if (OpmBackendConfig.isDebugEnable())
        {
            ToolUtilities.info(OpmConst.LOG, "[opm.schedule.executor.created] workers=" + _collectorWorkerSize
                    + ", collectors=" + collectors
                    + ", cpu=" + cpuCount);
        }

        return _collectorExecutor;
    }

    protected void executeCollectorSafely(String collectorKey, IOpmCollector collector, long startMillis, String source)
    {
        long begin = System.currentTimeMillis();
        if (OpmBackendConfig.isDebugEnable())
        {
            ToolUtilities.info(OpmConst.LOG, "[opm.collector.start] collector=" + collectorKey
                    + ", source=" + source
                    + ", delayMs=" + (begin - startMillis)
                    + ", thread=" + Thread.currentThread().getName());
        }

        try
        {
            executeCollector(collector);
            if (OpmBackendConfig.isDebugEnable())
            {
                ToolUtilities.info(OpmConst.LOG, "[opm.collector.end] collector=" + collectorKey
                        + ", source=" + source
                        + ", costMs=" + (System.currentTimeMillis() - begin));
            }
        }
        catch (Throwable err)
        {
            persistCollectorError(collectorKey, collector, begin, err, source);
            ToolUtilities.warning(OpmConst.LOG, "[opm.collector.error] collector=" + collectorKey
                    + ", source=" + source
                    + ", costMs=" + (System.currentTimeMillis() - begin), err);
        }
        finally
        {
            releaseCollectorRunning(collectorKey);
        }
    }

    protected void persistCollectorError(String collectorKey, IOpmCollector collector, long begin, Throwable err, String source)
    {
        if (!OpmBackendConfig.isPersistEnable())
            return;
        try
        {
            long now = System.currentTimeMillis();
            OpmCollectResult collect = new OpmCollectResult();
            collect.collectorKey = collectorKey;
            collect.collectorLabel = collector == null ? collectorKey : collector.getCollectorLabel();
            collect.collectTime = now;
            collect.collectCostMs = Math.max(0L, now - begin);
            collect.status = OpmConst.STATUS_ERROR;
            collect.summary = "采集异常: " + (err == null ? "unknown" : ToolUtilities.getString(err.getMessage(), err.getClass().getSimpleName()));

            LinkedHashMap<String, Object> detail = new LinkedHashMap<String, Object>();
            detail.put("type", "error");
            detail.put("collectorKey", collectorKey);
            detail.put("collectorLabel", collect.collectorLabel);
            detail.put("phase", "collect_execute");
            detail.put("source", source);
            detail.put("errorTime", Long.valueOf(now));
            detail.put("errorClass", err == null ? null : err.getClass().getName());
            detail.put("errorMessage", err == null ? null : err.getMessage());
            detail.put("stack", err == null ? null : ToolBasic.getExceptionStatck(err, true));
            detail.put("collectErrorDetail", err == null ? null : ToolBasic.getExceptionStatck(err, true));
            collect.statusDetailJson = GsonUtil.toJson(detail);

            saveCollect(collect);
        }
        catch (Throwable saveErr)
        {
            ToolUtilities.warning(OpmConst.LOG, "[opm.collector.error.persist.fail] collector=" + collectorKey, saveErr);
        }
    }

    protected void executeCollector(IOpmCollector collector) throws Exception
    {
        String collectorKey = safeCollectorKey(collector);

        OpmCollectResult collect;
        OpmSimulator sim = _simulator;

        if (sim != null && sim.getCollectorKey() != null && sim.getCollectorKey().equals(collectorKey))
        {
            collector.loadConfig();
            try
            {
                String cellClassName = sim.getCellClassName();
                IOpmCollectorSimulator simulator = (IOpmCollectorSimulator) Cells.get(cellClassName);
                if (simulator == null)
                {
                    ToolUtilities.warning(OpmConst.LOG, "[opm.simulator.notfound] collectorKey=" + collectorKey
                            + ", cellClassName=" + cellClassName);
                    return;
                }
                
                long now = System.currentTimeMillis();
                collect = simulator.simulateCollect(_agentCtx, now);
                
                if (OpmBackendConfig.isDebugEnable())
                {
                    ToolUtilities.info(OpmConst.LOG, "[opm.simulator.collect] collectorKey=" + collectorKey
                            + ", summary=" + (collect == null ? "null" : collect.summary));
                }
            }
            catch (Exception e)
            {
                persistCollectorError(collectorKey, collector, System.currentTimeMillis(), e, "simulator");
                ToolUtilities.error(OpmConst.LOG, "[opm.simulator.error] collectorKey=" + collectorKey
                        + ", message=" + e.getMessage(), e);
                return;
            }
        }
        else
        {
            collector.loadConfig();
            collect = collector.collect(_agentCtx);
        }

        if (collect == null)
            return;

        OpmMetricMainDo savedMain = null;
        if (OpmBackendConfig.isPersistEnable())
            savedMain = saveCollect(collect);

        List<OpmRuleResult> rules = null;
        try
        {
            rules = collector.evaluateRules(collect, _agentCtx);
        }
        catch (Throwable err)
        {
            markCollectError(collect, savedMain, "evaluateRules", err, System.currentTimeMillis());
            throw err;
        }
        handleCollectRules(collect, savedMain, rules);
    }

    protected OpmMetricMainDo saveCollect(OpmCollectResult collect) throws Exception
    {
        if (collect == null)
            return null;

        // 共性主表用于检索，个性字段落采集器附表
        OpmMetricMainDo main = new OpmMetricMainDo();
        main.collectorKey = collect.collectorKey;
        main.collectorLabel = collect.collectorLabel;
        main.collectTime = collect.collectTime;
        main.collectCostMs = Long.valueOf(collect.collectCostMs);
        main.status = collect.status;
        main.alarmUuid = collect.alarmUuid;
        main.statusDetail = collect.statusDetailJson;
        main.summary = collect.summary;
        main.agentCode = _agentCtx == null ? null : _agentCtx.getAgentCode();
        main.agentName = _agentCtx == null ? null : _agentCtx.getAgentName();
        main.myUri = _agentCtx == null ? null : _agentCtx.getMyUri();

        try (IDao dao = IDaoService.newIDao())
        {
            main = (OpmMetricMainDo) dao.createDo(main);

            if (collect.metricExt != null)
            {
                // 外键关联主表：结构异构场景下优先采用 Foreign 模式
                collect.metricExt.bindMain(main);
                collect.metricExt.collectorKey = main.collectorKey;
                collect.metricExt.collectorLabel = main.collectorLabel;
                collect.metricExt.agentCode = main.agentCode;
                collect.metricExt.agentName = main.agentName;
                collect.metricExt.myUri = main.myUri;
                collect.metricExt.collectTime = main.collectTime;
                collect.metricExt.summary = collect.summary;

                collect.metricExt = (bap.md.opm.OpmMetricExtDo) dao.createDo(collect.metricExt);
                persistCollectorSubDetails(dao, collect.metricExt);

                main.metricClass = collect.metricExt.getClass().getName();
                main.metricUuid = collect.metricExt.getUuid();
                dao.updateDo(main,
                        OpmMetricMainDo.MetricClass,
                        OpmMetricMainDo.MetricUuid,
                        OpmMetricMainDo.AlarmUuid,
                        OpmMetricMainDo.StatusDetail,
                        OpmMetricMainDo.Status);
            }

            dao.commit();
            return main;
        }
    }

    @SuppressWarnings("unchecked")
    protected void persistCollectorSubDetails(IDao dao, OpmMetricExtDo metricExt) throws Exception
    {
        if (dao == null || metricExt == null)
            return;
        if (!(metricExt instanceof bap.md.opm.pg.OpmPgMetricDo))
            return;

        bap.md.opm.pg.OpmPgMetricDo pgExt = (bap.md.opm.pg.OpmPgMetricDo) metricExt;
        if (ToolUtilities.isStringEmpty(pgExt.detailJson, true))
            return;

        Object obj = CJson.fromJson(pgExt.detailJson);
        if (!(obj instanceof Map))
            return;
        Map<String, Object> detail = (Map<String, Object>) obj;

        Object sqlObj = detail.remove("_pendingSqlDetails");
        if (sqlObj instanceof List)
        {
            for (Object one : (List<?>) sqlObj)
            {
                if (!(one instanceof Map))
                    continue;
                Map<String, Object> item = (Map<String, Object>) one;
                OpmPgSqlDetailDo sqlDetail = new OpmPgSqlDetailDo();
                sqlDetail.setForeignGid(pgExt.getGid());
                sqlDetail.pid = Integer.valueOf(ToolUtilities.getInteger(item.get("pid"), 0));
                sqlDetail.queryText = truncateString(ToolUtilities.getString(item.get("query"), null), 4000);
                sqlDetail.queryState = ToolUtilities.getString(item.get("state"), null);
                sqlDetail.durationSec = ToolUtilities.getDouble(item.get("durationSec"), 0D);
                sqlDetail.waitEventType = ToolUtilities.getString(item.get("waitEventType"), null);
                sqlDetail.waitEvent = ToolUtilities.getString(item.get("waitEvent"), null);
                sqlDetail.applicationName = ToolUtilities.getString(item.get("applicationName"), null);
                sqlDetail.clientAddr = ToolUtilities.getString(item.get("clientAddr"), null);
                dao.createDo(sqlDetail);
            }
        }

        Object lockObj = detail.remove("_pendingLockDetails");
        if (lockObj instanceof List)
        {
            for (Object one : (List<?>) lockObj)
            {
                if (!(one instanceof Map))
                    continue;
                Map<String, Object> item = (Map<String, Object>) one;
                OpmPgLockDetailDo lockDetail = new OpmPgLockDetailDo();
                lockDetail.setForeignGid(pgExt.getGid());
                lockDetail.blockedPid = Integer.valueOf(ToolUtilities.getInteger(item.get("blockedPid"), 0));
                lockDetail.blockedQuery = ToolUtilities.getString(item.get("blockedQuery"), null);
                lockDetail.blockingPid = Integer.valueOf(ToolUtilities.getInteger(item.get("blockingPid"), 0));
                lockDetail.blockingQuery = ToolUtilities.getString(item.get("blockingQuery"), null);
                lockDetail.waitSec = ToolUtilities.getDouble(item.get("waitSec"), 0D);
                lockDetail.lockType = ToolUtilities.getString(item.get("lockType"), null);
                lockDetail.lockMode = ToolUtilities.getString(item.get("lockMode"), null);
                dao.createDo(lockDetail);
            }
        }

        pgExt.detailJson = CJson.toJson(detail);
        dao.updateDo(pgExt, "detailJson");
    }

    protected void saveAlarm(OpmCollectResult collect, OpmMetricMainDo main, OpmRuleResult rule) throws Exception
    {
        if (!OpmBackendConfig.isAlarmEnable())
            return;

        // 告警请求ID用于跨 TsAlarm 与 OPM 告警索引关联
        String alarmReqId = "opm_" + CDaoUtil.allocUuid();
        long now = System.currentTimeMillis();
        String configParamKey = resolveAlarmConfigParamKey(collect, rule);

        String agentCode = _agentCtx == null ? null : _agentCtx.getAgentCode();
        String collectorKey = collect == null ? null : collect.collectorKey;

        try (IDao dao = IDaoService.newIDao())
        {
            OpmAlarmSuppressor.SuppressDecision decision = OpmAlarmSuppressor.evaluate(dao, agentCode, collectorKey, rule, now);
            if (decision != null && decision.suppressed)
            {
                OpmAlarmSuppressor.logSuppressed(agentCode, collectorKey, rule, decision);
                markCollectSuppressed(collect, main, rule, decision, now);
                return;
            }
        }

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        detail.put("collectorKey", collect == null ? null : collect.collectorKey);
        detail.put("collectorLabel", collect == null ? null : collect.collectorLabel);
        detail.put("metricMainUuid", main == null ? null : main.getUuid());
        detail.put("agentCode", _agentCtx == null ? null : _agentCtx.getAgentCode());
        detail.put("agentName", _agentCtx == null ? null : _agentCtx.getAgentName());
        detail.put("myUri", _agentCtx == null ? null : _agentCtx.getMyUri());
        detail.put("ruleKey", rule.ruleKey);
        detail.put("ruleLabel", rule.ruleLabel);
        detail.put("ruleDetail", rule.detailJson);

        TsAlarm alarm = new TsAlarm();
        alarm.setRequestId(alarmReqId);
        alarm.setAlarmLevel(rule.alarmLevel);
        alarm.setServiceType(OpmConst.SERVICE_TYPE);
        alarm.setServiceName(OpmConst.MODULE_NAME + "." + (collect == null ? "unknown" : collect.collectorKey));
        alarm.setCallFunction(rule.ruleKey);
        alarm.setMessage(rule.message);
        alarm.setDetail(CJson.toJson(detail));
        alarm.setAlarmTime(now);
        alarm.setSrcAgent(_agentCtx == null ? null : _agentCtx.getMyUri());
        alarm.setDstAgent(_agentCtx == null ? null : _agentCtx.getMyUri());

        String alarmUuid = null;
        boolean reported = false;
        final TsAlarm alarmToSend = alarm;
        if (ToolUtilities.isStringEmpty(alarm.getUuid(), true))
            alarm.setUuid(CDaoUtil.allocUuid());
        alarmUuid = alarm.getUuid();
        try
        {
            if (TsHelper.isStarted())
            {
                // tiny service 已启动：优先走统一告警上报链路
                TsHelper.callServant((rmt) -> {
                    try
                    {
                        rmt.reportAlarm(alarmToSend);
                    }
                    catch (Exception exp)
                    {
                        ToolUtilities.throwRuntimeException(exp);
                    }
                    return null;
                });
                reported = true;
            }
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "Failed to report TsAlarm by tiny service, fallback local save", err);
        }

        if (!reported)
        {
            // tiny service 不可用时回退本地保存，确保告警不丢
            try (IDao dao = IDaoService.newIDao())
            {
                alarm = (TsAlarm) dao.createDo(alarm);
                dao.commit();
                alarmUuid = alarm.getUuid();
            }
        }

        try (IDao dao = IDaoService.newIDao())
        {
            // 告警结构化索引：可反查采集数据，但不对采集数据做强依赖
            OpmAlarmRefDo ref = new OpmAlarmRefDo();
            ref.alarmRequestId = alarmReqId;
            ref.alarmUuid = alarmUuid;
            ref.metricMainUuid = main == null ? null : main.getUuid();
            ref.collectorKey = collect == null ? null : collect.collectorKey;
            ref.collectorLabel = collect == null ? null : collect.collectorLabel;
            ref.ruleKey = rule.ruleKey;
            ref.ruleLabel = rule.ruleLabel;
            ref.configParamKey = configParamKey;
            ref.alarmLevel = rule.alarmLevel;
            ref.alarmTime = now;
            ref.agentCode = _agentCtx == null ? null : _agentCtx.getAgentCode();
            ref.agentName = _agentCtx == null ? null : _agentCtx.getAgentName();
            ref.myUri = _agentCtx == null ? null : _agentCtx.getMyUri();
            ref.message = rule.message;
            ref.detailJson = rule.detailJson;

            ref = (OpmAlarmRefDo) dao.createDo(ref);

            if (rule.alarmExt != null)
            {
                // 告警扩展以外键模式挂接告警索引，保留独立生命周期
                OpmAlarmExtDo ext = rule.alarmExt;
                ext.setForeignGid(ref.getGid());
                ext.alarmRequestId = alarmReqId;
                ext.alarmRefUuid = ref.getUuid();
                ext.metricMainUuid = ref.metricMainUuid;
                ext.collectorKey = ref.collectorKey;
                ext.collectorLabel = ref.collectorLabel;
                ext.ruleKey = ref.ruleKey;
                ext.ruleLabel = ref.ruleLabel;
                ext.alarmLevel = ref.alarmLevel;
                ext.alarmTime = ref.alarmTime;
                ext.agentCode = ref.agentCode;
                ext.agentName = ref.agentName;
                ext.myUri = ref.myUri;
                if (ext.message == null)
                    ext.message = ref.message;
                if (ext.detailJson == null)
                    ext.detailJson = ref.detailJson;

                dao.createDo(ext);
            }

            dao.commit();
        }

        markCollectAlarmed(collect, main, alarmUuid, rule, now);
    }

    protected void handleCollectRules(OpmCollectResult collect, OpmMetricMainDo savedMain, List<OpmRuleResult> rules) throws Exception
    {
        if (collect == null)
            return;

        if (rules == null)
            rules = Collections.emptyList();

        boolean triggered = false;
        for (OpmRuleResult rs : rules)
        {
            if (rs == null || !rs.triggered)
                continue;
            triggered = true;
            saveAlarm(collect, savedMain, rs);
        }

        if (!triggered && collect.status != OpmConst.STATUS_ERROR)
        {
            collect.status = OpmConst.STATUS_NORMAL;
            updateCollectMainStatus(savedMain, collect);
        }
    }

    protected void markCollectSuppressed(OpmCollectResult collect, OpmMetricMainDo main,
            OpmRuleResult rule, OpmAlarmSuppressor.SuppressDecision decision, long now)
    {
        if (collect == null)
            return;
        if (collect.status == OpmConst.STATUS_ALARM || collect.status == OpmConst.STATUS_ERROR)
            return;

        collect.status = OpmConst.STATUS_SUPPRESSED;
        LinkedHashMap<String, Object> detail = new LinkedHashMap<String, Object>();
        detail.put("type", "suppressed");
        detail.put("collectorKey", collect.collectorKey);
        detail.put("ruleKey", rule == null ? null : rule.ruleKey);
        detail.put("ruleLabel", rule == null ? null : rule.ruleLabel);
        detail.put("message", rule == null ? null : rule.message);
        detail.put("suppressedAt", Long.valueOf(now));
        detail.put("fingerprint", decision == null ? null : decision.fingerprint);
        detail.put("suppressSec", decision == null ? null : Integer.valueOf(decision.suppressSec));
        detail.put("latestAlarmUuid", decision == null || decision.latestAlarm == null ? null : decision.latestAlarm.alarmUuid);
        detail.put("latestAlarmRefUuid", decision == null || decision.latestAlarm == null ? null : decision.latestAlarm.getUuid());
        collect.statusDetailJson = GsonUtil.toJson(detail);
        updateCollectMainStatus(main, collect);
    }

    protected void markCollectAlarmed(OpmCollectResult collect, OpmMetricMainDo main,
            String alarmUuid, OpmRuleResult rule, long now)
    {
        if (collect == null)
            return;
        if (collect.status == OpmConst.STATUS_ERROR)
            return;

        collect.status = OpmConst.STATUS_ALARM;
        collect.alarmUuid = alarmUuid;
        LinkedHashMap<String, Object> detail = new LinkedHashMap<String, Object>();
        detail.put("type", "alarm");
        detail.put("collectorKey", collect.collectorKey);
        detail.put("alarmUuid", alarmUuid);
        detail.put("ruleKey", rule == null ? null : rule.ruleKey);
        detail.put("ruleLabel", rule == null ? null : rule.ruleLabel);
        detail.put("message", rule == null ? null : rule.message);
        detail.put("alarmTime", Long.valueOf(now));
        collect.statusDetailJson = GsonUtil.toJson(detail);
        updateCollectMainStatus(main, collect);
    }

    protected void markCollectError(OpmCollectResult collect, OpmMetricMainDo main,
            String phase, Throwable err, long now)
    {
        if (collect == null)
            return;

        collect.status = OpmConst.STATUS_ERROR;
        LinkedHashMap<String, Object> detail = new LinkedHashMap<String, Object>();
        detail.put("type", "error");
        detail.put("collectorKey", collect.collectorKey);
        detail.put("phase", phase);
        detail.put("errorTime", Long.valueOf(now));
        detail.put("errorClass", err == null ? null : err.getClass().getName());
        detail.put("errorMessage", err == null ? null : err.getMessage());
        detail.put("stack", err == null ? null : ToolBasic.getExceptionStatck(err, true));
        detail.put("collectErrorDetail", err == null ? null : ToolBasic.getExceptionStatck(err, true));
        collect.statusDetailJson = GsonUtil.toJson(detail);
        if (ToolUtilities.isStringEmpty(collect.summary, true))
            collect.summary = "采集异常: " + (err == null ? "unknown" : ToolUtilities.getString(err.getMessage(), err.getClass().getSimpleName()));
        updateCollectMainStatus(main, collect);
    }

    protected void updateCollectMainStatus(OpmMetricMainDo main, OpmCollectResult collect)
    {
        if (main == null || collect == null)
            return;
        main.status = Integer.valueOf(collect.status);
        main.alarmUuid = collect.alarmUuid;
        main.statusDetail = collect.statusDetailJson;
        main.summary = collect.summary;
        try (IDao dao = IDaoService.newIDao())
        {
            dao.updateDo(main,
                    OpmMetricMainDo.Status,
                    OpmMetricMainDo.AlarmUuid,
                    OpmMetricMainDo.StatusDetail,
                    OpmMetricMainDo.Summary);
            dao.commit();
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "[opm.collect.status.update.error] collector=" + main.collectorKey, err);
        }
    }

    protected String truncateString(String text, int maxLen)
    {
        if (text == null)
            return null;
        if (maxLen <= 0 || text.length() <= maxLen)
            return text;
        return text.substring(0, maxLen);
    }

    protected String resolveAlarmConfigParamKey(OpmCollectResult collect, OpmRuleResult rule)
    {
        if (rule == null)
            return null;
        if (!ToolUtilities.isStringEmpty(rule.configParamKey, true))
            return rule.configParamKey;

        String collectorKey = ToolUtilities.getString(collect == null ? null : collect.collectorKey, null);
        String ruleKey = ToolUtilities.getString(rule.ruleKey, null);
        if (ToolUtilities.isStringEmpty(collectorKey, true) || ToolUtilities.isStringEmpty(ruleKey, true))
            return null;

        // 使用统一注册表解析并归一化配置项映射
        return bap.opm.registry.OpmConfigRegistry.getInstance().normalizeConfigParamKey(
                collectorKey, ruleKey, rule.alarmLevel, rule.configParamKey);
    }

    protected void triggerCollectExpectationAlarm(String collectorKey, IOpmCollector collector,
            long expectedTime, long now, long intervalMs, long runningSince, String reason)
    {
        try
        {
            String label = collector == null ? collectorKey : collector.getCollectorLabel();
            long runningMs = runningSince <= 0L ? 0L : Math.max(0L, now - runningSince);
            long lagMs = Math.max(0L, runningMs > 0L ? runningMs - intervalMs : now - expectedTime);
            int overdueCount = 1;

            String reasonText = "采集器未在预期周期内完成，本轮调度到点时上一轮仍在执行，发生采集重叠";
            String suggestionText = "建议优先检查该采集器执行耗时、目标环境负载、采样范围与采样周期；若当前周期偏短，可适当调大采集周期，或优化采集逻辑避免重叠。";

            if (ToolUtilities.isStringEqual(reason, "overlap", true) && runningMs > 0L)
                reasonText = "采集器执行耗时约" + runningMs + "毫秒，已超过或逼近配置周期，导致下一轮调度到点时上一轮仍未结束";

            OpmRuleResult rule = OpmAlarmPolicy.buildExpectationRule(collectorKey, label,
                    expectedTime, now, lagMs, intervalMs, overdueCount,
                    reasonText, suggestionText, Long.valueOf(runningMs));
            rule.ruleKey = OpmAlarmPolicy.buildExpectationRuleKey(collectorKey);

            OpmCollectResult collect = new OpmCollectResult();
            collect.collectorKey = collectorKey;
            collect.collectorLabel = label;
            collect.collectTime = now;
            collect.collectCostMs = 0L;
            collect.status = OpmConst.STATUS_ALARM;
            collect.summary = rule.message;

            saveAlarm(collect, null, rule);
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "[opm.collect.expectation.alarm.error] collector=" + collectorKey, err);
        }
    }

    protected synchronized void refreshCollectors(boolean force)
    {
        // 配置驱动挂载采集器：从 opm.core.collectorClasses 读取并装配
        if (!force)
            return;

        long now = System.currentTimeMillis();

        LinkedHashMap<String, IOpmCollector> map = loadCollectorsFromConfig();

        Set<String> setOldKey = new LinkedHashSet<String>(_collectors.keySet());
        _collectors.clear();
        _collectors.putAll(map);

        ensureCollectorExecutor();

        for (String old : setOldKey)
        {
            if (!map.containsKey(old))
            {
                _nextCollect.remove(old);
                _collectorRunningSince.remove(old);
            }
        }

        for (String nowKey : map.keySet())
        {
            if (!_nextCollect.containsKey(nowKey))
                _nextCollect.put(nowKey, 0L);
            if (!_collectorRunningSince.containsKey(nowKey))
                _collectorRunningSince.put(nowKey, 0L);
        }

        OpmAgentConfigMgr.refreshTemplate(new ArrayList<IOpmCollector>(_collectors.values()));

        _lastCollectorScan = now;
        _lastPluginTag = ClassFactory.getCurrentPluginTag();
    }

    protected synchronized void refreshRuntimeConfig(boolean force)
    {
        if (_agentCtx == null)
            return;

        long now = System.currentTimeMillis();
        if (!force)
        {
            long checkInterval = RUNTIME_CONFIG_REFRESH_INTERVAL_MS;
            if (now - _lastRuntimeCfgCheck < checkInterval)
                return;
        }

        try
        {
            OpmAgentConfigMgr.RuntimeSnapshot snap = OpmAgentConfigMgr.loadAndApplyRuntimeConfig(_agentCtx);
            _runtimeHasConfigRecord = snap != null && snap.hasConfigRecord;
            _runtimeCollectorEnabled = snap != null && snap.hasEnabledCollector;
            _lastRuntimeCfgCheck = now;
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "Failed to refresh runtime config", err);
        }
    }

    protected LinkedHashMap<String, IOpmCollector> loadCollectorsFromConfig()
    {
        LinkedHashMap<String, IOpmCollector> map = new LinkedHashMap<String, IOpmCollector>();

        List<String> classes = getConfiguredCollectorClasses();
        for (String className : classes)
        {
            try
            {
                IOpmCollector collector = createCollectorByClass(className);
                if (collector == null)
                    continue;

                map.put(safeCollectorKey(collector), collector);
            }
            catch (Throwable err)
            {
                ToolUtilities.warning(OpmConst.LOG, "Failed to create collector by config class: " + className, err);
            }
        }

        if (map.isEmpty())
        {
            IOpmCollector sysCollector = buildDefaultSysCollector();
            map.put(safeCollectorKey(sysCollector), sysCollector);
            ToolUtilities.warning(OpmConst.LOG,
                    "No valid collector class configured, fallback to default sys collector: " + OpmConst.DEFAULT_CORE_COLLECTOR_CLASSES);
        }

        return map;
    }

    protected List<String> getConfiguredCollectorClasses()
    {
        LinkedHashSet<String> set = new LinkedHashSet<String>();
        set.addAll(parseCollectorClasses(loadCollectorClassesByStarterModule()));
        set.addAll(parseCollectorClasses(OpmBackendConfig.getCollectorClassesTextNullable()));

        if (set.isEmpty())
            set.addAll(parseCollectorClasses(OpmConst.DEFAULT_CORE_COLLECTOR_CLASSES));

        return new ArrayList<String>(set);
    }

    protected String loadCollectorClassesByStarterModule()
    {
        try
        {
            StarterConf conf = StarterMain.getMe().getConf();
            if (conf == null)
                return null;

            StarterItem st = conf.getStarter(OpmConst.MODULE_NAME);
            if (st == null || !st.hasModules())
                return null;

            StringBuilder sb = new StringBuilder();
            for (ModuleItem md : st.getLstModules())
            {
                if (md == null)
                    continue;

                boolean enable = ToolUtilities.getBoolean(md.getAttr(OpmConst.MODULE_ATTR_ENABLE), true);
                if (!enable)
                    continue;

                String cls = md.getAttr(OpmConst.MODULE_ATTR_CLASS_NAME);
                if (cls == null || cls.trim().isEmpty())
                    continue;

                if (sb.length() > 0)
                    sb.append(',');
                sb.append(cls.trim());
            }

            return sb.toString();
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "Failed to load collector class list from starter modules", err);
            return null;
        }
    }

    protected IOpmCollector buildDefaultSysCollector()
    {
        IOpmCollector sysCollector = null;
        try
        {
            sysCollector = IOpmSysCollector.get();
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "Failed to get IOpmSysCollector from cell, use local fallback", err);
        }
        if (sysCollector == null)
            // 没有可用Cell实现时，兜底本地实例，保证系统采集器可运行
            sysCollector = new COpmSysCollector();
        return sysCollector;
    }

    protected IOpmCollector createCollectorByClass(String className) throws Exception
    {
        if (className == null || className.trim().isEmpty())
            return null;

        Class cls = ClassFactory.loadClass(className);
        if (cls == null)
            throw new IOException("Class not found: " + className);
        if (!IOpmCollector.class.isAssignableFrom(cls))
            throw new Exception("Class is not IOpmCollector: " + className);

        if (cls.isInterface())
            return (IOpmCollector) Cells.get((Class<? extends IOpmCollector>) cls);

        return (IOpmCollector) ClassFactory.newInstance(cls);
    }

    protected List<String> parseCollectorClasses(String txt)
    {
        ArrayList<String> list = new ArrayList<String>();
        if (txt == null)
            return list;

        String[] lines = txt.split("[\\r\\n;]");
        for (String line : lines)
        {
            if (line == null)
                continue;

            int iComment = line.indexOf('#');
            if (iComment >= 0)
                line = line.substring(0, iComment);

            String[] parts = line.split(",");
            for (String one : parts)
            {
                if (one == null)
                    continue;
                String cls = one.trim();
                if (cls.isEmpty())
                    continue;
                if (!list.contains(cls))
                    list.add(cls);
            }
        }
        return list;
    }

    protected String safeCollectorKey(IOpmCollector collector)
    {
        if (collector == null || collector.getCollectorKey() == null || collector.getCollectorKey().trim().isEmpty())
            return "unknownCollector";
        return collector.getCollectorKey().trim();
    }

    protected void cleanRetentionIfNeed()
    {
        // 定时按保留天数清理历史数据，避免表无限增长
        if (!OpmBackendConfig.isPersistEnable())
            return;

        long now = System.currentTimeMillis();
        if (now - _lastRetentionClean < 3600000L)
            return;

        String agentCode = _agentCtx == null ? null : _agentCtx.getAgentCode();
        if (!ToolUtilities.isStringEmpty(agentCode, true))
            agentCode = agentCode.trim();
        if (ToolUtilities.isStringEmpty(agentCode, true))
        {
            ToolUtilities.warning(OpmConst.LOG, "Skip retention clean because current agentCode is empty");
            _lastRetentionClean = now;
            return;
        }

        long keep = OpmBackendConfig.getRetentionDay() * 24L * 3600L * 1000L;
        long deadTime = now - keep;

        try (IDao dao = IDaoService.newIDao())
        {
            int metricDeleted = dao.deleteDos(OpmMetricMainDo.class.getName(),
                    Cnd.where(OpmMetricMainDo.AgentCode, "=", agentCode)
                            .and(OpmMetricMainDo.CollectTime, "<", deadTime));
            int alarmDeleted = dao.deleteDos(OpmAlarmRefDo.class.getName(),
                    Cnd.where(OpmAlarmRefDo.AgentCode, "=", agentCode)
                            .and(OpmAlarmRefDo.AlarmTime, "<", deadTime));
            dao.commit();

            if (metricDeleted > 0 || alarmDeleted > 0)
            {
                ToolUtilities.info(OpmConst.LOG,
                        "[opm.retention.clean] agentCode=" + agentCode
                                + ", metricDeleted=" + metricDeleted
                                + ", alarmDeleted=" + alarmDeleted
                                + ", deadTime=" + deadTime);
            }
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "Failed to clean retention data", err);
        }

        _lastRetentionClean = now;
    }

    public OpmAgentContext getAgentContext()
    {
        return _agentCtx;
    }

    public OpmCollectResult collectNow(String collectorKey) throws Exception
    {
        // 测试/手动触发入口：立即执行一次指定采集器
        IOpmCollector collector = _collectors.get(collectorKey);
        if (collector == null)
            throw new Exception("Collector not found: " + collectorKey);

        long now = System.currentTimeMillis();
        if (!markCollectorRunning(collectorKey, now))
        {
            long runningSince = getCollectorRunningSince(collectorKey);
            throw new Exception("Collector is running, skip overlapped collectNow: " + collectorKey
                    + ", runningMs=" + (runningSince <= 0L ? 0L : now - runningSince));
        }

        try
        {
            if (OpmBackendConfig.isDebugEnable())
            {
                ToolUtilities.info(OpmConst.LOG, "[opm.collector.start] collector=" + collectorKey
                        + ", source=collectNow"
                        + ", delayMs=0"
                        + ", thread=" + Thread.currentThread().getName());
            }

            collector.loadConfig();
            OpmCollectResult collect = collector.collect(_agentCtx);
            if (collect != null && OpmBackendConfig.isPersistEnable())
                saveCollect(collect);

            if (OpmBackendConfig.isDebugEnable())
            {
                ToolUtilities.info(OpmConst.LOG, "[opm.collector.end] collector=" + collectorKey
                        + ", source=collectNow"
                        + ", costMs=" + (System.currentTimeMillis() - now));
            }

            return collect;
        }
        catch (RuntimeException err)
        {
            ToolUtilities.warning(OpmConst.LOG, "[opm.collector.error] collector=" + collectorKey
                    + ", source=collectNow"
                    + ", costMs=" + (System.currentTimeMillis() - now), err);
            throw err;
        }
        catch (Exception err)
        {
            ToolUtilities.warning(OpmConst.LOG, "[opm.collector.error] collector=" + collectorKey
                    + ", source=collectNow"
                    + ", costMs=" + (System.currentTimeMillis() - now), err);
            throw err;
        }
        finally
        {
            releaseCollectorRunning(collectorKey);
        }
    }

    public List<OpmMetricMainDo> queryLatestMain(int count) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryDoPage(OpmMetricMainDo.class, Cnd.orderBy().desc(OpmMetricMainDo.CollectTime),
                    new CPager(0, Math.max(1, count))).getListData();
        }
    }

    public List<OpmAlarmRefDo> queryLatestAlarmRef(int count) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryDoPage(OpmAlarmRefDo.class, Cnd.orderBy().desc(OpmAlarmRefDo.AlarmTime),
                    new CPager(0, Math.max(1, count))).getListData();
        }
    }

    public List<OpmSysMetricDo> queryLatestSysMetric(int count) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryDoPage(OpmSysMetricDo.class, Cnd.orderBy().desc(OpmSysMetricDo.CollectTime),
                    new CPager(0, Math.max(1, count))).getListData();
        }
    }

    public List<OpmCpuMetricDo> queryLatestCpuMetric(int count) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryDoPage(OpmCpuMetricDo.class, Cnd.orderBy().desc(OpmCpuMetricDo.CollectTime),
                    new CPager(0, Math.max(1, count))).getListData();
        }
    }

    public List<OpmMemoryMetricDo> queryLatestMemoryMetric(int count) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryDoPage(OpmMemoryMetricDo.class, Cnd.orderBy().desc(OpmMemoryMetricDo.CollectTime),
                    new CPager(0, Math.max(1, count))).getListData();
        }
    }

    public List<OpmDiskMetricDo> queryLatestDiskMetric(int count) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryDoPage(OpmDiskMetricDo.class, Cnd.orderBy().desc(OpmDiskMetricDo.CollectTime),
                    new CPager(0, Math.max(1, count))).getListData();
        }
    }

    public List<OpmIoMetricDo> queryLatestIoMetric(int count) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryDoPage(OpmIoMetricDo.class, Cnd.orderBy().desc(OpmIoMetricDo.CollectTime),
                    new CPager(0, Math.max(1, count))).getListData();
        }
    }

    public List<OpmNetMetricDo> queryLatestNetMetric(int count) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryDoPage(OpmNetMetricDo.class, Cnd.orderBy().desc(OpmNetMetricDo.CollectTime),
                    new CPager(0, Math.max(1, count))).getListData();
        }
    }

    public List<String> listCollectorKeys()
    {
        return new ArrayList<String>(_collectors.keySet());
    }

    public boolean isStarted()
    {
        return _started;
    }

    public boolean isRuntimeConfigured()
    {
        return _runtimeHasConfigRecord;
    }

    public boolean hasRuntimeConfigRecord()
    {
        return _runtimeHasConfigRecord;
    }

    public boolean hasRuntimeEnabledCollector()
    {
        return _runtimeCollectorEnabled;
    }

    public void reloadRuntimeConfigNow()
    {
        refreshRuntimeConfig(true);
    }

    public void reloadCollectorsNow()
    {
        refreshCollectors(true);
    }

    public OpmSimulator getSimulatorInternal()
    {
        return _simulator;
    }

    public static OpmSimulator getSimulator()
    {
        return get()._simulator;
    }

    public static boolean isSimulating(String collectorKey)
    {
        OpmSimulator sim = get()._simulator;
        return sim != null && sim.getCollectorKey() != null && sim.getCollectorKey().equals(collectorKey);
    }

    /**
     * 设置仿真器（设置即替换，设置null则解挂）。
     * 
     * 使用方式：
     * 1. 创建Java工程，实现IOpmCollectorSimulator接口
     * 2. 发布为插件
     * 3. 调用此方法挂载仿真器
     * 
     * 示例实现：
     * <pre>
     * package com.example;
     * 
     * import bap.opm.OpmCollectResult;
     * import bap.md.opm.sys.OpmSysMetricDo;
     * import cell.bap.opm.simulator.IOpmCollectorSimulator;
     * import java.util.Random;
     * 
     * public class MySysSimulator implements IOpmCollectorSimulator {
     *     public String getSimulatorName() { return "CPU高负载仿真器"; }
     *     public String getTargetCollectorKey() { return "sys"; }
     *     
     *     public OpmCollectResult simulateCollect(OpmAgentContext agentCtx, long now) {
     *         Random rand = new Random(now);
     *         double cpuBase = 0.70 + rand.nextDouble() * 0.25;
     *         
     *         OpmCollectResult result = new OpmCollectResult();
     *         result.collectorKey = "sys";
     *         result.collectTime = now;
     *         result.status = cpuBase >= 0.90 ? 2 : 1;
     *         result.summary = String.format("cpu=%.2f%%", cpuBase*100);
     *         
     *         OpmSysMetricDo ext = new OpmSysMetricDo();
     *         ext.cpuUsageRate = cpuBase;
     *         result.metricExt = ext;
     *         
     *         return result;
     *     }
     * }
     * </pre>
     * 
     * 挂载命令：
     * <pre>
     * OpmCenter.setSimulator("sys", "com.example.MySysSimulator");
     * </pre>
     * 
     * 解挂命令：
     * <pre>
     * OpmCenter.setSimulator(null, null);
     * </pre>
     * 
     * @param collectorKey 采集器Key，如 "sys", "topCpu", "mem"
     * @param cellClassName 仿真器Cell实现类全名；null则解挂
     */
    public static void setSimulator(String collectorKey, String cellClassName)
    {
        OpmCenter center = get();
        if (cellClassName == null || cellClassName.trim().isEmpty())
        {
            center._simulator = null;
            ToolUtilities.info(OpmConst.LOG, "[opm.simulator.detach]");
            return;
        }

        OpmSimulator sim = new OpmSimulator();
        sim.setCollectorKey(collectorKey);
        sim.setCellClassName(cellClassName.trim());

        center._simulator = sim;
        ToolUtilities.info(OpmConst.LOG, "[opm.simulator.attach] collectorKey=" + collectorKey + ", cellClassName=" + cellClassName);
    }

    /**
     * 初始化配置注册表
     */
    protected void initConfigRegistry()
    {
        bap.opm.registry.OpmConfigRegistry registry = bap.opm.registry.OpmConfigRegistry.getInstance();
        
        if (registry.isInitialized())
            return;

        ToolUtilities.info(OpmConst.LOG, "[opm.registry.init] 开始初始化配置注册表");

        // 注册所有采集器的配置项和规则
        new bap.opm.collector.topcpu.OpmTopCpuCollectorRegistry().registerConfigParams(registry);
        new bap.opm.collector.topmemory.OpmTopMemoryCollectorRegistry().registerConfigParams(registry);
        new bap.opm.collector.focus.OpmFocusCollectorRegistry().registerConfigParams(registry);
        new bap.opm.collector.topio.OpmTopIoCollectorRegistry().registerConfigParams(registry);
        new bap.opm.collector.system.OpmSysCollectorRegistry().registerConfigParams(registry);
        new bap.opm.collector.pg.OpmPgCollectorRegistry().registerConfigParams(registry);
        new bap.opm.collector.disk.OpmDiskCollectorRegistry().registerConfigParams(registry);
        new bap.opm.collector.diskpartition.OpmDiskPartitionCollectorRegistry().registerConfigParams(registry);
        new bap.opm.collector.topnet.OpmTopNetCollectorRegistry().registerConfigParams(registry);

        // 验证配置完整性（每次启动都执行，快速检查）
        java.util.List<String> errors = registry.validate();
        if (!errors.isEmpty())
        {
            ToolUtilities.warning(OpmConst.LOG, "[opm.registry.validate] 配置注册表验证失败:");
            for (String error : errors)
            {
                ToolUtilities.warning(OpmConst.LOG, "  " + error);
            }
        }
        else
        {
            ToolUtilities.info(OpmConst.LOG, "[opm.registry.validate] 配置注册表验证通过");
        }

        // 运行自动化测试（仅开发环境或配置开启时执行）
        boolean runTest = bap.opm.cfg.OpmRuntimeConfig.getBoolean("opm.registry.test.enable", false);
        if (runTest)
        {
            bap.opm.registry.OpmConfigTestRunner.OpmConfigTestResult testResult = 
                    bap.opm.registry.OpmConfigTestRunner.runTests();
            
            if (!testResult.isAllPassed())
            {
                ToolUtilities.warning(OpmConst.LOG, "[opm.registry.test] 配置注册表测试失败: " + testResult.getFailCount() + " 个失败");
            }
            else
            {
                ToolUtilities.info(OpmConst.LOG, "[opm.registry.test] 配置注册表测试通过: " + testResult.getTotalCount() + " 个测试");
            }
        }

        registry.setInitialized(true);
        ToolUtilities.info(OpmConst.LOG, "[opm.registry.init] 配置注册表初始化完成");
    }
}
