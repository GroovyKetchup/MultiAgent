package bap.opm;

import org.nutz.dao.Cnd;

import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.cmn.TsConst;
import tiny.service.cmn.TsHelper;
import tiny.service.md.TsAgentDo;

import com.cdao.model.CDo;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

public class OpmAgentContext
{
    private String agentCode;
    private String agentName;
    private String myUri;
    private long detectTime;

    public String getAgentCode()
    {
        return agentCode;
    }

    public void setAgentCode(String agentCode)
    {
        this.agentCode = agentCode;
    }

    public String getAgentName()
    {
        return agentName;
    }

    public void setAgentName(String agentName)
    {
        this.agentName = agentName;
    }

    public String getMyUri()
    {
        return myUri;
    }

    public void setMyUri(String myUri)
    {
        this.myUri = myUri;
    }

    public long getDetectTime()
    {
        return detectTime;
    }

    public void setDetectTime(long detectTime)
    {
        this.detectTime = detectTime;
    }

    public static OpmAgentContext detect() throws Exception
    {
        // 启动阶段识别并缓存代理上下文，供全生命周期复用
        OpmAgentContext ctx = new OpmAgentContext();
        ctx.setDetectTime(System.currentTimeMillis());

        String myUri = null;
        try
        {
            // 优先从 tiny service 运行态获取 myUri
            myUri = TsHelper.getMyUriText();
        }
        catch (Throwable ignore)
        {
        }

        if (CmnUtil.isStringEmpty(myUri))
            // 回退配置项，兼容 tiny service 未完整启动场景
            myUri = MppContext.getString(TsConst.CONF_MY_URI, "");

        if (CmnUtil.isStringEmpty(myUri))
            myUri = "unknown://unknown";

        ctx.setMyUri(myUri);
        ctx.setAgentCode(myUri);
        ctx.setAgentName(myUri);

        try (IDao dao = IDaoService.newIDao())
        {
            // 用 myUri 反查 TsAgentDo，补齐 agentCode/agentName
            CDo agt = dao.queryDo(TsAgentDo.class.getName(), Cnd.where(TsAgentDo.Code, "=", myUri), TsAgentDo.Code, TsAgentDo.Name);
            if (agt != null)
            {
                String code = agt.getString(TsAgentDo.Code);
                String name = agt.getString(TsAgentDo.Name);
                if (!CmnUtil.isStringEmpty(code))
                    ctx.setAgentCode(code);
                if (!CmnUtil.isStringEmpty(name))
                    ctx.setAgentName(name);
            }
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "Failed to resolve agent info by TsAgentDo, fallback to myUri", err);
        }

        return ctx;
    }
}
