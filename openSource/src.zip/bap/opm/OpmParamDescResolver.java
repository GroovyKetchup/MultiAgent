package bap.opm;

public class OpmParamDescResolver
{
    private OpmParamDescResolver()
    {
    }

    public static String resolve(String key, String label, String type, String defaultValue)
    {
        String safeKey = key == null ? "" : key.trim();
        String safeLabel = label == null || label.trim().length() <= 0 ? safeKey : label.trim();
        String safeType = type == null ? "string" : type.trim().toLowerCase();
        String safeDefault = defaultValue == null ? "" : defaultValue.trim();
        String lowerKey = safeKey.toLowerCase();

        if (lowerKey.endsWith(".enable") || lowerKey.endsWith("enable"))
            return appendDefault("控制该功能或采集器是否启用。关闭后对应采集、规则或附加逻辑将停止执行。生产环境建议默认开启，仅在排障或临时停用时关闭。", safeDefault);

        if (lowerKey.contains("persistenable"))
            return appendDefault("控制采集结果是否入库保存。关闭后实时采集可能仍执行，但历史查询、汇总统计和部分追溯能力会受到影响。", safeDefault);

        if (lowerKey.contains("retentionday"))
            return appendDefault("单位：天。控制历史采集与告警数据的保留时长。值越大，数据库占用越高；建议结合磁盘容量与排障需求设置。", safeDefault);

        if (lowerKey.contains("debugenable"))
            return appendDefault("开启后会输出更多调试日志，便于定位采集与规则问题。生产环境建议默认关闭，仅在排障时临时开启。", safeDefault);

        if (lowerKey.contains("defaultcooldownsec") || lowerKey.endsWith("rule.cooldownsec") || lowerKey.contains("cooldownsec"))
            return appendDefault("单位：秒。控制同一规则重复触发后的静默冷却时间，避免短时间内连续刷出大量重复告警。建议根据业务噪声设置为 60~300 秒。", safeDefault);

        if (lowerKey.endsWith("collectintervalsec") || lowerKey.contains("collectintervalsec"))
            return appendDefault("单位：秒。控制该采集器的执行周期。值越小越实时，但会增加主机采集、数据库写入和页面刷新压力；常规建议设置在 5~30 秒之间。", safeDefault);

        if (lowerKey.contains("samplemillis"))
            return appendDefault("单位：毫秒。控制单次采样窗口长度。窗口越大结果越平滑，越小越敏感；多数采样场景建议使用 1000ms 左右。", safeDefault);

        if (lowerKey.contains("topprocsize"))
            return appendDefault("单位：条。控制每次采集返回的热点进程数量，同时影响详情体量与页面渲染负载。建议按排障需要设置为 5~20。", safeDefault);

        if (lowerKey.endsWith("dbname") || lowerKey.contains(".dbname"))
            return appendDefault("要监控的 PostgreSQL 数据库名。请确保当前连接用户对该数据库具备查询系统视图与统计信息的权限。", safeDefault);

        if (lowerKey.endsWith("localmode") || lowerKey.contains(".localmode"))
            return appendDefault("开启后会额外采集本机 PostgreSQL 进程与磁盘占用信息，仅适用于数据库与 OPM 所在主机同机部署；远程数据库建议关闭。", safeDefault);

        if (lowerKey.endsWith("storesqldetail") || lowerKey.contains("storesqldetail"))
            return appendDefault("是否将长 SQL 详情落库保存。开启后可在历史详情中回溯具体 SQL 文本与等待事件，但会增加存储与写入压力。", safeDefault);

        if (lowerKey.endsWith("storelockdetail") || lowerKey.contains("storelockdetail"))
            return appendDefault("是否将锁等待详情落库保存。开启后可回溯阻塞链路与等待语句，但会增加明细存储体量。", safeDefault);

        if (lowerKey.endsWith("sqldetailmaxrows") || lowerKey.contains("sqldetailmaxrows"))
            return appendDefault("单位：条。限制单次采集最多保存或展示的长 SQL 明细数量，用于控制详情体量和数据库写入压力。", safeDefault);

        if (lowerKey.endsWith("lockdetailmaxrows") || lowerKey.contains("lockdetailmaxrows"))
            return appendDefault("单位：条。限制单次采集最多保存或展示的锁等待明细数量，用于控制详情体量和数据库写入压力。", safeDefault);

        if (isRateThreshold(lowerKey))
            return appendDefault("用于设置“" + safeLabel + "”阈值。单位为比例值 0~1，例如 0.70 表示 70%。阈值越低越敏感；建议按照警告 < 次要 < 主要 < 严重的顺序逐级递增配置。", safeDefault);

        if (isDurationThreshold(lowerKey))
            return appendDefault("单位：秒。与同级阈值配套使用，只有指标连续超过阈值达到该时长后才触发，避免瞬时抖动造成误报。", safeDefault);

        if (isSqlThreshold(lowerKey))
            return appendDefault("单位：秒。用于判定长 SQL 告警阈值，SQL 持续执行时间超过该值后进入对应告警级别。", safeDefault);

        if (isLockThreshold(lowerKey))
            return appendDefault("单位：秒。用于判定锁等待告警阈值，等待时间越长说明阻塞越严重。", safeDefault);

        if (isReplicationThreshold(lowerKey))
            return appendDefault("单位：秒。用于判定主从复制延迟告警阈值，值越小越敏感。适合对实时性要求较高的同步链路。", safeDefault);

        if (lowerKey.contains("conn") && lowerKey.endsWith("rate"))
            return appendDefault("用于设置连接数占用阈值。单位为比例值 0~1，通常表示当前连接数 / 最大连接数。建议保留足够余量，避免连接池打满。", safeDefault);

        if (lowerKey.contains("space") && lowerKey.endsWith("rate"))
            return appendDefault("用于设置库空间或表空间占用阈值。单位为比例值 0~1，建议结合磁盘扩容策略提前预警。", safeDefault);

        if (lowerKey.contains("proc") && lowerKey.contains("topCpu") && lowerKey.endsWith("rate"))
            return appendDefault("用于设置 PostgreSQL 进程 CPU 占用阈值。单位为比例值 0~1，可用于识别数据库进程过热或异常负载。", safeDefault);

        if ("boolean".equals(safeType))
            return appendDefault("开关参数。true 表示开启，false 表示关闭。请结合当前场景确认是否需要启用。", safeDefault);

        if ("int".equals(safeType))
            return appendDefault("整数参数，用于控制“" + safeLabel + "”的取值。请按页面说明和业务容量评估后设置，避免过大或过小导致监控结果失真。", safeDefault);

        return appendDefault("参数“" + safeLabel + "”的配置项。请结合采集目的、单位含义和业务负载情况进行设置。", safeDefault);
    }

    protected static boolean isRateThreshold(String lowerKey)
    {
        return lowerKey.endsWith("rate")
                && (lowerKey.contains("warn") || lowerKey.contains("minor") || lowerKey.contains("major") || lowerKey.contains("critical"));
    }

    protected static boolean isDurationThreshold(String lowerKey)
    {
        return lowerKey.endsWith("durationsec")
                && (lowerKey.contains("warn") || lowerKey.contains("minor") || lowerKey.contains("major") || lowerKey.contains("critical"));
    }

    protected static boolean isSqlThreshold(String lowerKey)
    {
        return lowerKey.contains(".sql.") && lowerKey.endsWith("sec") && !lowerKey.endsWith("durationsec");
    }

    protected static boolean isLockThreshold(String lowerKey)
    {
        return lowerKey.contains(".lock.") && lowerKey.endsWith("sec") && !lowerKey.endsWith("durationsec");
    }

    protected static boolean isReplicationThreshold(String lowerKey)
    {
        return lowerKey.contains("replication") && lowerKey.endsWith("sec") && !lowerKey.endsWith("durationsec");
    }

    protected static String appendDefault(String prefix, String defaultValue)
    {
        if (defaultValue == null || defaultValue.trim().length() <= 0)
            return prefix;
        return prefix + " 默认值：" + defaultValue.trim() + "。";
    }
}
