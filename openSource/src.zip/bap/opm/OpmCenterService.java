package bap.opm;

import java.util.List;
import java.util.Map;

import com.leavay.nio.crpc.Pingable;

import bap.md.opm.OpmAlarmRefDo;
import bap.md.opm.OpmMetricMainDo;
import bap.md.opm.cpu.OpmCpuMetricDo;
import bap.md.opm.disk.OpmDiskMetricDo;
import bap.md.opm.io.OpmIoMetricDo;
import bap.md.opm.memory.OpmMemoryMetricDo;
import bap.md.opm.net.OpmNetMetricDo;
import bap.md.opm.sys.OpmSysMetricDo;

public interface OpmCenterService extends Pingable
{
    public Map<String, Object> queryRuntimeMeta() throws Exception;

    public boolean isAgentOpmEditable(String agentCode) throws Exception;

    public Map<String, String> queryAgentConfigMap(String agentCode) throws Exception;

    public void saveAgentConfigMap(String agentCode, Map<String, String> mapCfg) throws Exception;

    public Map<String, Object> queryConfigSchema() throws Exception;

    public List<String> listCollectorKeys() throws Exception;

    public OpmCollectResult collectNow(String collectorKey) throws Exception;

    public List<OpmMetricMainDo> queryLatestMain(int count) throws Exception;

    public List<OpmAlarmRefDo> queryLatestAlarmRef(int count) throws Exception;

    public List<OpmSysMetricDo> queryLatestSysMetric(int count) throws Exception;

    public List<OpmCpuMetricDo> queryLatestCpuMetric(int count) throws Exception;

    public List<OpmMemoryMetricDo> queryLatestMemoryMetric(int count) throws Exception;

    public List<OpmDiskMetricDo> queryLatestDiskMetric(int count) throws Exception;

    public List<OpmIoMetricDo> queryLatestIoMetric(int count) throws Exception;

    public List<OpmNetMetricDo> queryLatestNetMetric(int count) throws Exception;
}
