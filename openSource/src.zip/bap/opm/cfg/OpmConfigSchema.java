package bap.opm.cfg;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.ToolUtilities;

import bap.opm.OpmConst;
import bap.opm.OpmParamDef;
import bap.opm.alarm.OpmAlarmPolicy;
import bap.opm.collector.focus.OpmFocusConfigSupport;
import cell.bap.opm.collector.IOpmCollector;

public class OpmConfigSchema
{
    private OpmConfigSchema()
    {
    }

    public static Map<String, Object> buildSchema()
    {
        ensureTemplateLoaded();

        LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
        ArrayList<OpmConfigGroup> groups = new ArrayList<OpmConfigGroup>();

        groups.add(buildCoreGroup());

        Map<String, OpmCollectorTemplate> templates = OpmConfigTemplateManager.getAllTemplate();

        ArrayList<IOpmCollector> collectors = OpmAgentConfigMgr.getCollectors();
        Map<String, IOpmCollector> collectorMap = new LinkedHashMap<String, IOpmCollector>();
        if (collectors != null)
        {
            for (IOpmCollector c : collectors)
            {
                if (c != null && c.getCollectorKey() != null)
                    collectorMap.put(c.getCollectorKey(), c);
            }
        }

        List<String> ordered = mergeCollectorKeys(getOrderedCollectorKeys(templates), collectorMap);

        LinkedHashMap<String, OpmConfigGroup> collectorGroups = new LinkedHashMap<String, OpmConfigGroup>();
        for (String key : ordered)
        {
            IOpmCollector collector = collectorMap.get(key);
            OpmCollectorTemplate tpl = templates.get(key);
            OpmConfigGroup group = resolveCollectorGroup(key, collector, tpl);
            if (group != null)
                collectorGroups.put(key, group);
        }

        IOpmCollector sysCollector = collectorMap.get("sys");
        OpmConfigGroup sysGroup = takeGroup(collectorGroups, "sys");
        OpmConfigGroup systemGroup = buildSystemMonitorGroup(sysCollector, sysGroup);
        if (systemGroup != null)
            groups.add(systemGroup);

        OpmConfigGroup focusGroup = OpmFocusConfigSupport.buildFocusGroup();
        if (focusGroup != null)
        {
            focusGroup.label = "重点进程";
            groups.add(focusGroup);
        }
        takeGroup(collectorGroups, "focus");

        OpmConfigGroup topGroup = buildTopMonitorGroup(collectorGroups);
        if (topGroup != null)
            groups.add(topGroup);

        OpmConfigGroup diskGroup = takeGroup(collectorGroups, "disk");
        OpmConfigGroup diskPartitionGroup = takeGroup(collectorGroups, "diskPartition");
        OpmConfigGroup diskMonitorGroup = buildDiskMonitorGroup(diskGroup, diskPartitionGroup);
        if (diskMonitorGroup != null)
            groups.add(diskMonitorGroup);

        OpmConfigGroup pgGroup = takeGroup(collectorGroups, "pg");
        if (pgGroup != null)
        {
            pgGroup.label = "PG监控";
            groups.add(pgGroup);
        }

        for (String key : ordered)
        {
            OpmConfigGroup group = takeGroup(collectorGroups, key);
            if (group != null)
                groups.add(group);
        }

        for (OpmConfigGroup group : collectorGroups.values())
            if (group != null)
                groups.add(group);

        ret.put("groups", groups);
        return ret;
    }

    protected static OpmConfigGroup resolveCollectorGroup(String key, IOpmCollector collector, OpmCollectorTemplate tpl)
    {
        if (collector != null)
        {
            try
            {
                OpmConfigGroup group = collector.getConfigGroup();
                if (group != null)
                    return group;
            }
            catch (Throwable err)
            {
            }
        }

        if (tpl != null)
            return buildCollectorGroup(key, tpl);
        return null;
    }

    protected static OpmConfigGroup buildSystemMonitorGroup(IOpmCollector sysCollector, OpmConfigGroup sysGroup)
    {
        if (sysCollector == null && sysGroup == null)
            return null;

        Map<String, OpmParamDef> index = buildParamIndex(sysCollector, sysGroup);

        OpmConfigGroup root = new OpmConfigGroup("sys", "系统监控")
                .setDesc("统一展示主机总体 CPU、内存、IO 与网络监控配置，不承载重点进程或 TOP 监控语义。 ");

        OpmConfigGroup collect = new OpmConfigGroup("sysCollect", "采集开关与周期")
                .setDesc("配置系统总体监控的启用开关、采集周期与采样窗口。 ");
        appendParamsByKeys(collect, index, new String[] { "opm.sys.enable", "opm.sys.collectIntervalSec",
                "opm.sys.cpu.sampleMillis", "opm.sys.io.collectIntervalSec", "opm.sys.io.sampleMillis",
                "opm.sys.net.collectIntervalSec", "opm.sys.net.sampleMillis", "opm.sys.rule.cooldownSec" });
        addGroupIfNotEmpty(root, collect);

        OpmConfigGroup cpu = new OpmConfigGroup("sysCpu", "总体CPU")
                .setDesc("配置主机总体 CPU 使用率的分级告警阈值。 ");
        appendParamsByKeys(cpu, index,
                new String[] { "opm.sys.cpu.warnRate", "opm.sys.cpu.warnDurationSec", "opm.sys.cpu.minorRate",
                        "opm.sys.cpu.minorDurationSec", "opm.sys.cpu.majorRate", "opm.sys.cpu.majorDurationSec",
                        "opm.sys.cpu.criticalRate", "opm.sys.cpu.criticalDurationSec" });
        addGroupIfNotEmpty(root, cpu);

        OpmConfigGroup memory = new OpmConfigGroup("sysMemory", "总体内存")
                .setDesc("配置主机总体内存使用率的分级告警阈值。 ");
        appendParamsByKeys(memory, index,
                new String[] { "opm.sys.mem.warnRate", "opm.sys.mem.warnDurationSec", "opm.sys.mem.minorRate",
                        "opm.sys.mem.minorDurationSec", "opm.sys.mem.majorRate", "opm.sys.mem.majorDurationSec",
                        "opm.sys.mem.criticalRate", "opm.sys.mem.criticalDurationSec" });
        addGroupIfNotEmpty(root, memory);

        OpmConfigGroup io = new OpmConfigGroup("sysIo", "总体IO")
                .setDesc("配置主机总体 IO 吞吐的分级告警阈值。 ");
        appendParamsByKeys(io, index,
                new String[] { "opm.sys.io.warnRateBytesPerSec", "opm.sys.io.warnDurationSec",
                        "opm.sys.io.minorRateBytesPerSec", "opm.sys.io.minorDurationSec",
                        "opm.sys.io.majorRateBytesPerSec", "opm.sys.io.majorDurationSec",
                        "opm.sys.io.criticalRateBytesPerSec", "opm.sys.io.criticalDurationSec" });
        addGroupIfNotEmpty(root, io);

        OpmConfigGroup net = new OpmConfigGroup("sysNet", "总体网络")
                .setDesc("配置主机总体网络吞吐的分级告警阈值。 ");
        appendParamsByKeys(net, index,
                new String[] { "opm.sys.net.warnRateBytesPerSec", "opm.sys.net.warnDurationSec",
                        "opm.sys.net.minorRateBytesPerSec", "opm.sys.net.minorDurationSec",
                        "opm.sys.net.majorRateBytesPerSec", "opm.sys.net.majorDurationSec",
                        "opm.sys.net.criticalRateBytesPerSec", "opm.sys.net.criticalDurationSec" });
        addGroupIfNotEmpty(root, net);

        return isGroupEmpty(root) ? null : root;
    }

    protected static OpmConfigGroup buildTopMonitorGroup(Map<String, OpmConfigGroup> collectorGroups)
    {
        OpmConfigGroup cpuGroup = takeGroup(collectorGroups, "topCpu");
        OpmConfigGroup memoryGroup = takeGroup(collectorGroups, "topMemory");
        OpmConfigGroup ioGroup = takeGroup(collectorGroups, "topIo");
        OpmConfigGroup netGroup = takeGroup(collectorGroups, "topNet");
        if (cpuGroup == null && memoryGroup == null && ioGroup == null && netGroup == null)
            return null;

        OpmConfigGroup root = new OpmConfigGroup("top", "TOP监控")
                .setDesc("统一展示普通进程的 TOP 排行监控，不承载重点进程语义。 ");

        OpmConfigGroup collect = new OpmConfigGroup("topCollect", "采集开关与周期")
                .setDesc("配置 TOP 监控各类采集器的启用开关、采样窗口、采集周期与保留的 TOP 数量。 ");
        appendParam(collect, findParam(cpuGroup == null ? null : cpuGroup.params, "opm.topCpu.enable"));
        appendParam(collect, findParam(cpuGroup == null ? null : cpuGroup.params, "opm.topCpu.collectIntervalSec"));
        appendParam(collect, findParam(cpuGroup == null ? null : cpuGroup.params, "opm.topCpu.sampleMillis"));
        appendParam(collect, findParam(cpuGroup == null ? null : cpuGroup.params, "opm.topCpu.topProcSize"));
        appendParam(collect, findParam(memoryGroup == null ? null : memoryGroup.params, "opm.topMemory.enable"));
        appendParam(collect, findParam(memoryGroup == null ? null : memoryGroup.params, "opm.topMemory.collectIntervalSec"));
        appendParam(collect, findParam(ioGroup == null ? null : ioGroup.params, "opm.topIo.enable"));
        appendParam(collect, findParam(ioGroup == null ? null : ioGroup.params, "opm.topIo.collectIntervalSec"));
        appendParam(collect, findParam(ioGroup == null ? null : ioGroup.params, "opm.topIo.sampleMillis"));
        appendParam(collect, findParam(ioGroup == null ? null : ioGroup.params, "opm.topIo.topProcSize"));
        appendParam(collect, findParam(netGroup == null ? null : netGroup.params, "opm.topNet.enable"));
        appendParam(collect, findParam(netGroup == null ? null : netGroup.params, "opm.topNet.collectIntervalSec"));
        appendParam(collect, findParam(netGroup == null ? null : netGroup.params, "opm.topNet.sampleMillis"));
        appendParam(collect, findParam(netGroup == null ? null : netGroup.params, "opm.topNet.topProcSize"));
        addGroupIfNotEmpty(root, collect);

        addGroupIfNotEmpty(root,
                copyGroupExcludingParams(cpuGroup, "topCpu", "TOP进程CPU",
                        new String[] { "opm.topCpu.enable", "opm.topCpu.collectIntervalSec", "opm.topCpu.sampleMillis",
                                "opm.topCpu.topProcSize" }, "配置普通进程 CPU Top 排行的阈值与告警参数。 "));
        addGroupIfNotEmpty(root,
                copyGroupExcludingParams(memoryGroup, "topMemory", "TOP进程内存",
                        new String[] { "opm.topMemory.enable", "opm.topMemory.collectIntervalSec" },
                        "配置普通进程内存 Top 排行的阈值与告警参数。 "));
        addGroupIfNotEmpty(root,
                copyGroupExcludingParams(ioGroup, "topIo", "TOP进程IO",
                        new String[] { "opm.topIo.enable", "opm.topIo.collectIntervalSec", "opm.topIo.sampleMillis",
                                "opm.topIo.topProcSize" }, "配置普通进程 IO Top 排行的阈值与告警参数。 "));
        addGroupIfNotEmpty(root,
                copyGroupExcludingParams(netGroup, "topNet", "TOP进程网络",
                        new String[] { "opm.topNet.enable", "opm.topNet.collectIntervalSec", "opm.topNet.sampleMillis",
                                "opm.topNet.topProcSize" }, "配置普通进程网络 Top 排行的阈值与告警参数。 "));

        return isGroupEmpty(root) ? null : root;
    }

    protected static OpmConfigGroup buildDiskMonitorGroup(OpmConfigGroup diskGroup, OpmConfigGroup diskPartitionGroup)
    {
        if (diskGroup == null && diskPartitionGroup == null)
            return null;

        OpmConfigGroup root = new OpmConfigGroup("diskMonitor", "磁盘监控")
                .setDesc("统一展示磁盘总体监控与磁盘分区监控配置。 ");

        OpmConfigGroup overall = copyGroup(diskGroup);
        if (overall != null)
        {
            overall.key = "disk";
            overall.label = "磁盘总体监控";
            root.addGroup(overall);
        }

        OpmConfigGroup partition = copyGroup(diskPartitionGroup);
        if (partition != null)
        {
            partition.key = "diskPartition";
            partition.label = "磁盘分区监控";
            root.addGroup(partition);
        }

        return isGroupEmpty(root) ? null : root;
    }

    protected static List<String> mergeCollectorKeys(List<String> ordered, Map<String, IOpmCollector> collectorMap)
    {
        LinkedHashMap<String, String> merged = new LinkedHashMap<String, String>();
        if (ordered != null)
        {
            for (String key : ordered)
            {
                if (!ToolUtilities.isStringEmpty(key, true))
                    merged.put(key, key);
            }
        }
        if (collectorMap != null)
        {
            String[] prefer = new String[] { "sys", "focus", "topCpu", "topMemory", "topIo", "topNet", "disk",
                    "diskPartition", "pg" };
            for (String key : prefer)
            {
                if (collectorMap.containsKey(key))
                    merged.put(key, key);
            }
            for (String key : collectorMap.keySet())
            {
                if (!ToolUtilities.isStringEmpty(key, true))
                    merged.put(key, key);
            }
        }
        return new ArrayList<String>(merged.keySet());
    }

    protected static OpmConfigGroup takeGroup(Map<String, OpmConfigGroup> collectorGroups, String key)
    {
        if (collectorGroups == null || ToolUtilities.isStringEmpty(key, true))
            return null;
        return collectorGroups.remove(key);
    }

    protected static OpmConfigGroup findGroup(List<OpmConfigGroup> groups, String key)
    {
        if (groups == null || ToolUtilities.isStringEmpty(key, true))
            return null;
        for (OpmConfigGroup one : groups)
        {
            if (one == null)
                continue;
            if (ToolUtilities.isStringEqual(one.key, key, true))
                return one;
        }
        return null;
    }

    protected static void appendParams(OpmConfigGroup target, OpmConfigGroup source)
    {
        if (target == null || source == null || source.params == null || source.params.isEmpty())
            return;
        for (OpmParamDef one : source.params)
        {
            OpmParamDef copied = copyParam(one);
            if (copied != null)
                target.addParam(copied);
        }
    }

    protected static void appendParam(OpmConfigGroup target, OpmParamDef param)
    {
        if (target == null)
            return;
        OpmParamDef copied = copyParam(param);
        if (copied != null)
            target.addParam(copied);
    }

    protected static OpmParamDef findParam(List<OpmParamDef> params, String key)
    {
        if (params == null || ToolUtilities.isStringEmpty(key, true))
            return null;
        for (OpmParamDef one : params)
        {
            if (one == null)
                continue;
            if (ToolUtilities.isStringEqual(one.key, key, true))
                return one;
        }
        return null;
    }

    protected static OpmParamDef copyParam(OpmParamDef param)
    {
        if (param == null || ToolUtilities.isStringEmpty(param.key, true))
            return null;

        OpmParamDef copied = new OpmParamDef(param.key, param.label, param.type, param.defaultValue);
        copied.group = param.group;
        copied.groupLabel = param.groupLabel;
        copied.groupEnableSwitch = param.groupEnableSwitch;
        copied.setDesc(param.desc);
        return copied;
    }

    protected static Map<String, OpmParamDef> buildParamIndex(IOpmCollector collector, OpmConfigGroup group)
    {
        LinkedHashMap<String, OpmParamDef> map = new LinkedHashMap<String, OpmParamDef>();
        indexParams(map, group);
        if (collector != null)
        {
            try
            {
                List<OpmParamDef> defs = collector.getParamDefs();
                if (defs != null)
                {
                    for (OpmParamDef one : defs)
                    {
                        if (one == null || ToolUtilities.isStringEmpty(one.key, true))
                            continue;
                        if (!map.containsKey(one.key))
                            map.put(one.key, one);
                    }
                }
            }
            catch (Throwable err)
            {
            }
        }
        return map;
    }

    protected static void indexParams(Map<String, OpmParamDef> map, OpmConfigGroup group)
    {
        if (map == null || group == null)
            return;
        if (group.params != null)
        {
            for (OpmParamDef one : group.params)
            {
                if (one == null || ToolUtilities.isStringEmpty(one.key, true))
                    continue;
                if (!map.containsKey(one.key))
                    map.put(one.key, one);
            }
        }
        if (group.groups != null)
        {
            for (OpmConfigGroup child : group.groups)
                indexParams(map, child);
        }
    }

    protected static void appendParamsByKeys(OpmConfigGroup target, Map<String, OpmParamDef> index, String[] keys)
    {
        if (target == null || index == null || keys == null)
            return;
        for (String key : keys)
        {
            if (ToolUtilities.isStringEmpty(key, true))
                continue;
            appendParam(target, index.get(key));
        }
    }

    protected static OpmConfigGroup copyGroupExcludingParams(OpmConfigGroup source, String newKey, String newLabel,
            String[] excludeKeys, String desc)
    {
        if (source == null)
            return null;

        OpmConfigGroup copied = new OpmConfigGroup(newKey, newLabel);
        copied.setDesc(ToolUtilities.isStringEmpty(desc, true) ? source.desc : desc);
        copied.extraText = source.extraText;

        if (source.params != null)
        {
            for (OpmParamDef one : source.params)
            {
                if (one == null || containsKey(excludeKeys, one.key))
                    continue;
                OpmParamDef copiedParam = copyParam(one);
                if (copiedParam != null)
                    copied.addParam(copiedParam);
            }
        }

        if (source.groups != null)
        {
            for (OpmConfigGroup child : source.groups)
            {
                OpmConfigGroup copiedChild = copyGroup(child);
                if (copiedChild != null)
                    copied.addGroup(copiedChild);
            }
        }

        return isGroupEmpty(copied) ? null : copied;
    }

    protected static boolean containsKey(String[] keys, String key)
    {
        if (keys == null || ToolUtilities.isStringEmpty(key, true))
            return false;
        for (String one : keys)
            if (ToolUtilities.isStringEqual(one, key, true))
                return true;
        return false;
    }

    protected static void addGroupIfNotEmpty(OpmConfigGroup root, OpmConfigGroup child)
    {
        if (root == null || isGroupEmpty(child))
            return;
        root.addGroup(child);
    }

    protected static boolean isGroupEmpty(OpmConfigGroup group)
    {
        if (group == null)
            return true;
        boolean noParams = group.params == null || group.params.isEmpty();
        boolean noGroups = group.groups == null || group.groups.isEmpty();
        return noParams && noGroups;
    }

    protected static OpmConfigGroup copyGroup(OpmConfigGroup group)
    {
        if (group == null)
            return null;

        OpmConfigGroup copied = new OpmConfigGroup(group.key, group.label);
        copied.setDesc(group.desc);
        copied.extraText = group.extraText;
        copied.enableSwitch = group.enableSwitch;
        copied.enableSwitchKey = group.enableSwitchKey;

        if (group.params != null)
        {
            for (OpmParamDef param : group.params)
            {
                OpmParamDef copiedParam = copyParam(param);
                if (copiedParam != null)
                    copied.addParam(copiedParam);
            }
        }

        if (group.groups != null)
        {
            for (OpmConfigGroup child : group.groups)
            {
                OpmConfigGroup copiedChild = copyGroup(child);
                if (copiedChild != null)
                    copied.addGroup(copiedChild);
            }
        }
        return copied;
    }

    protected static OpmConfigGroup buildCoreGroup()
    {
        OpmConfigGroup group = new OpmConfigGroup("core", "全局")
                .setDesc("配置 OPM 全局保留策略与统一告警抑制参数。 ");
        group.addParam(new OpmParamDef(OpmConst.CONF_CORE_RETENTION_DAY, OpmConst.LABEL_CORE_RETENTION_DAY, "int", String.valueOf(OpmConst.DEFAULT_CORE_RETENTION_DAY)));
        group.addParam(OpmAlarmPolicy.newGlobalSuppressParam());
        return group;
    }

    protected static OpmConfigGroup buildCollectorGroup(String key, OpmCollectorTemplate tpl)
    {
        String label = ToolUtilities.getString(tpl.label, key);
        OpmConfigGroup group = new OpmConfigGroup(key, label);

        if (tpl.params != null)
        {
            for (OpmParamDef p : tpl.params)
            {
                if (p != null && !ToolUtilities.isStringEmpty(p.key, true))
                    group.addParam(p);
            }
        }

        return group;
    }

    protected static void ensureTemplateLoaded()
    {
        OpmAgentConfigMgr.ensureBuiltinTemplateLoaded();
    }

    protected static List<String> getOrderedCollectorKeys(Map<String, OpmCollectorTemplate> templates)
    {
        ArrayList<String> keys = new ArrayList<String>();
        String[] prefer = new String[] { "sys", "focus", "topCpu", "topMemory", "topIo", "topNet", "disk",
                "diskPartition", "pg" };

        for (String one : prefer)
            if (templates.containsKey(one))
                keys.add(one);

        for (String one : templates.keySet())
            if (!keys.contains(one))
                keys.add(one);
        return keys;
    }
}
