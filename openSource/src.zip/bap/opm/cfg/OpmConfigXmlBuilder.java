package bap.opm.cfg;

import java.util.List;

import bap.opm.OpmParamDef;

public class OpmConfigXmlBuilder
{
    private OpmConfigXmlBuilder()
    {
    }

    public static String buildModuleSample(String moduleName, String label, String className, OpmConfigGroup group)
    {
        StringBuilder sb = new StringBuilder();
        sb.append("<module name=\"").append(escape(moduleName)).append("\"");
        sb.append(" label=\"").append(escape(label)).append("\"");
        sb.append(" enable=\"true\"");
        sb.append(" class_name=\"").append(escape(className)).append("\">\n");
        appendGroupParams(sb, group, "    ");
        sb.append("</module>\n");
        return sb.toString();
    }

    protected static void appendGroupParams(StringBuilder sb, OpmConfigGroup group, String indent)
    {
        if (group == null)
            return;

        appendParams(sb, group.params, indent);

        if (group.groups == null)
            return;

        for (OpmConfigGroup sub : group.groups)
            appendGroupParams(sb, sub, indent);
    }

    protected static void appendParams(StringBuilder sb, List<OpmParamDef> params, String indent)
    {
        if (params == null)
            return;

        for (OpmParamDef param : params)
        {
            if (param == null || param.key == null)
                continue;

            sb.append(indent)
              .append("<param key=\"").append(escape(param.key)).append("\"")
              .append(" label=\"").append(escape(param.label)).append("\"")
              .append(" type=\"").append(escape(param.type)).append("\"")
              .append(" value=\"").append(escape(param.defaultValue)).append("\"")
              .append(" desc=\"").append(escape(param.desc)).append("\"/>")
              .append("\n");
        }
    }

    protected static String escape(String text)
    {
        if (text == null)
            return "";
        return text.replace("&", "&amp;")
                .replace("\"", "&quot;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }
}
