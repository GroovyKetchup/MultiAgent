package bap.opm.cfg;

import java.util.ArrayList;
import java.util.List;

import bap.opm.OpmParamDef;

public class OpmConfigGroup
{
    public String key;
    public String label;
    public String desc;
    public String extraText;
    public Boolean enableSwitch;
    public String enableSwitchKey;
    public List<OpmConfigGroup> groups;
    public List<OpmParamDef> params;

    public OpmConfigGroup()
    {
    }

    public OpmConfigGroup(String key, String label)
    {
        this.key = key;
        this.label = label;
    }

    public OpmConfigGroup setDesc(String desc)
    {
        this.desc = desc;
        return this;
    }

    public OpmConfigGroup setExtraText(String extraText)
    {
        this.extraText = extraText;
        return this;
    }

    public OpmConfigGroup setEnableSwitch(boolean enableSwitch, String enableSwitchKey)
    {
        this.enableSwitch = enableSwitch;
        this.enableSwitchKey = enableSwitchKey;
        return this;
    }

    public OpmConfigGroup addGroup(OpmConfigGroup group)
    {
        if (this.groups == null)
            this.groups = new ArrayList<OpmConfigGroup>();
        this.groups.add(group);
        return this;
    }

    public OpmConfigGroup addParam(OpmParamDef param)
    {
        if (this.params == null)
            this.params = new ArrayList<OpmParamDef>();
        this.params.add(param);

        if (param != null && isEnableParam(param) && (this.enableSwitchKey == null || this.enableSwitchKey.trim().length() <= 0))
            setEnableSwitch(true, param.key);

        return this;
    }

    protected boolean isEnableParam(OpmParamDef param)
    {
        if (param == null || param.key == null)
            return false;
        if (param.type == null || !"boolean".equalsIgnoreCase(param.type.trim()))
            return false;
        String k = param.key.trim().toLowerCase();
        return k.endsWith(".enable") || k.endsWith("enable");
    }
}
