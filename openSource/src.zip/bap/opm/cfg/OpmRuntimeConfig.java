package bap.opm.cfg;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import com.leavay.common.util.ToolUtilities;

public class OpmRuntimeConfig
{
    protected static volatile Map<String, String> _cfg = Collections.emptyMap();

    private OpmRuntimeConfig()
    {
    }

    public static synchronized void apply(Map<String, String> map)
    {
        LinkedHashMap<String, String> copy = new LinkedHashMap<String, String>();
        if (map != null)
            for (Map.Entry<String, String> ent : map.entrySet())
            {
                String key = ToolUtilities.getString(ent.getKey(), null);
                if (ToolUtilities.isStringEmpty(key, true))
                    continue;

                String value = ent.getValue();
                if (value != null)
                    value = value.trim();
                copy.put(key.trim(), value);
            }

        _cfg = Collections.unmodifiableMap(copy);
    }

    public static Map<String, String> snapshot()
    {
        return _cfg;
    }

    public static String getString(String key, String dft)
    {
        if (ToolUtilities.isStringEmpty(key, true))
            return dft;

        String v = _cfg.get(key.trim());
        if (ToolUtilities.isStringEmpty(v, true))
            return dft;
        return v;
    }

    public static boolean getBoolean(String key, boolean dft)
    {
        return ToolUtilities.getBoolean(getString(key, null), dft);
    }

    public static int getInt(String key, int dft)
    {
        return ToolUtilities.getInteger(getString(key, null), dft);
    }

    public static long getLong(String key, long dft)
    {
        return ToolUtilities.getLong(getString(key, null), dft);
    }

    public static double getDouble(String key, double dft)
    {
        return ToolUtilities.getDouble(getString(key, null), dft);
    }
}
