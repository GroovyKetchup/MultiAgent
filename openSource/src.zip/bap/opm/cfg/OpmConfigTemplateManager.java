package bap.opm.cfg;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Element;

import com.leavay.common.util.ToolUtilities;

import bap.opm.OpmParamDef;
import cell.bap.opm.collector.IOpmCollector;

public class OpmConfigTemplateManager
{
    public static final String TEMPLATE_PATH_PREFIX = "bap/opm/collector/";
    public static final String TEMPLATE_FILE_NAME = "config.xml";

    protected static final LinkedHashMap<String, OpmCollectorTemplate> _mapTpl = new LinkedHashMap<String, OpmCollectorTemplate>();

    private OpmConfigTemplateManager()
    {
    }

    public static synchronized void refresh(List<IOpmCollector> collectors)
    {
        _mapTpl.clear();
        if (collectors == null)
            return;

        for (IOpmCollector one : collectors)
        {
            if (one == null)
                continue;

            String key = ToolUtilities.getString(one.getCollectorKey(), null);
            if (ToolUtilities.isStringEmpty(key, true))
                continue;
            key = key.trim();

            OpmCollectorTemplate tpl = null;
            
            try
            {
                OpmConfigGroup group = one.getConfigGroup();
                if (group != null)
                    tpl = convertGroupToTemplate(group);
            }
            catch (Throwable ignore)
            {
            }
            
            if (tpl == null)
                tpl = loadTemplateByCollector(one);

            if (tpl == null)
                tpl = buildFallbackTemplate(one);

            if (tpl != null)
            {
                tpl.key = key;
                if (ToolUtilities.isStringEmpty(tpl.label, true))
                    tpl.label = one.getCollectorLabel();
                _mapTpl.put(key, tpl);
            }
        }
    }

    protected static OpmCollectorTemplate convertGroupToTemplate(OpmConfigGroup group)
    {
        if (group == null)
            return null;

        OpmCollectorTemplate tpl = new OpmCollectorTemplate();
        tpl.key = group.key;
        tpl.label = group.label;

        convertGroupParams(group, tpl);

        if (tpl.params.isEmpty())
            return null;

        return tpl;
    }

    protected static void convertGroupParams(OpmConfigGroup group, OpmCollectorTemplate tpl)
    {
        if (group.params != null)
        {
            for (OpmParamDef p : group.params)
            {
                if (p != null && p.key != null)
                    tpl.params.add(new OpmParamDef(p.key, p.label, p.type, p.defaultValue).setDesc(p.desc));
            }
        }

        if (group.groups != null)
        {
            for (OpmConfigGroup sub : group.groups)
            {
                convertGroupParams(sub, tpl);
            }
        }
    }

    public static synchronized OpmCollectorTemplate getTemplate(String collectorKey)
    {
        OpmCollectorTemplate tpl = _mapTpl.get(collectorKey);
        return tpl == null ? null : tpl.copyShallow();
    }

    public static synchronized Map<String, OpmCollectorTemplate> getAllTemplate()
    {
        LinkedHashMap<String, OpmCollectorTemplate> out = new LinkedHashMap<String, OpmCollectorTemplate>();
        for (Map.Entry<String, OpmCollectorTemplate> ent : _mapTpl.entrySet())
            out.put(ent.getKey(), ent.getValue().copyShallow());
        return Collections.unmodifiableMap(out);
    }

    public static synchronized LinkedHashMap<String, String> getDefaultConfigMap()
    {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (OpmCollectorTemplate tpl : _mapTpl.values())
        {
            if (tpl == null || tpl.params == null)
                continue;

            for (OpmParamDef p : tpl.params)
            {
                if (p == null || ToolUtilities.isStringEmpty(p.key, true))
                    continue;

                if (!map.containsKey(p.key))
                    map.put(p.key, p.defaultValue);
            }
        }
        return map;
    }

    protected static OpmCollectorTemplate loadTemplateByCollector(IOpmCollector collector)
    {
        String key = collector == null ? null : collector.getCollectorKey();
        if (ToolUtilities.isStringEmpty(key, true))
            return null;

        String path = TEMPLATE_PATH_PREFIX + key.trim() + "/" + TEMPLATE_FILE_NAME;
        try
        {
            byte[] data = ToolUtilities.readResourceFile(path);
            if (data == null || data.length <= 0)
                return null;

            String xml = new String(data, "UTF-8");
            return parseTemplate(path, xml);
        }
        catch (Throwable err)
        {
            InputStream ins = null;
            try
            {
                ins = OpmConfigTemplateManager.class.getClassLoader().getResourceAsStream(path);
                if (ins == null)
                    return null;

                byte[] data = readAll(ins);
                if (data == null || data.length <= 0)
                    return null;

                String xml = new String(data, "UTF-8");
                return parseTemplate(path, xml);
            }
            catch (Throwable ignore)
            {
                return null;
            }
            finally
            {
                try
                {
                    if (ins != null)
                        ins.close();
                }
                catch (Throwable ignore2)
                {
                }
            }
        }
    }

    protected static OpmCollectorTemplate parseTemplate(String resourcePath, String xml)
    {
        if (ToolUtilities.isStringEmpty(xml, true))
            return null;

        try
        {
            Element root = ToolUtilities.xmlString2Dom4j(xml);
            if (root == null)
                return null;

            OpmCollectorTemplate tpl = new OpmCollectorTemplate();
            tpl.resourcePath = resourcePath;
            tpl.key = root.attributeValue("key");
            tpl.label = root.attributeValue("label");

            List<Element> groups = root.elements("group");
            if (groups != null)
                for (Element g : groups)
                {
                    if (g == null)
                        continue;

                    String gname = ToolUtilities.getString(g.attributeValue("name"), null);
                    String glabel = ToolUtilities.getString(g.attributeValue("label"), gname);
                    if (!ToolUtilities.isStringEmpty(gname, true))
                        tpl.groups.put(gname.trim(), glabel);

                    List<Element> params = g.elements("param");
                    if (params == null)
                        continue;

                    for (Element p : params)
                    {
                        if (p == null)
                            continue;

                        OpmParamDef def = parseParam(p);
                        if (def != null)
                        {
                            tpl.params.add(def);
                            tpl.paramGroups.put(def.key, gname);
                        }
                    }
                }

            if (tpl.params.isEmpty())
            {
                List<Element> params = root.elements("param");
                if (params != null)
                    for (Element p : params)
                    {
                        OpmParamDef def = parseParam(p);
                        if (def != null)
                            tpl.params.add(def);
                    }
            }

            if (tpl.params.isEmpty())
                return null;
            return tpl;
        }
        catch (Throwable err)
        {
            return null;
        }
    }

    protected static OpmParamDef parseParam(Element ele)
    {
        if (ele == null)
            return null;

        String key = ToolUtilities.getString(ele.attributeValue("key"), null);
        if (ToolUtilities.isStringEmpty(key, true))
            return null;

        OpmParamDef def = new OpmParamDef();
        def.key = key.trim();
        def.label = ToolUtilities.getString(ele.attributeValue("label"), def.key);
        def.type = ToolUtilities.getString(ele.attributeValue("type"), "string");
        def.defaultValue = ele.attributeValue("default");
        if (def.defaultValue == null)
            def.defaultValue = ele.attributeValue("value");
        def.desc = ele.attributeValue("desc");
        def.fillAutoDesc();
        return def;
    }

    protected static OpmCollectorTemplate buildFallbackTemplate(IOpmCollector collector)
    {
        OpmCollectorTemplate tpl = new OpmCollectorTemplate();
        tpl.key = collector.getCollectorKey();
        tpl.label = collector.getCollectorLabel();
        tpl.resourcePath = TEMPLATE_PATH_PREFIX + tpl.key + "/" + TEMPLATE_FILE_NAME;

        List<OpmParamDef> defs = collector.getParamDefs();
        if (defs != null)
            for (OpmParamDef one : defs)
            {
                if (one == null || ToolUtilities.isStringEmpty(one.key, true))
                    continue;
                OpmParamDef p = new OpmParamDef(one.key, one.label, one.type, one.defaultValue).setDesc(one.desc);
                tpl.params.add(p);
            }

        if (tpl.params.isEmpty())
            return null;
        return tpl;
    }

    public static synchronized List<String> getCollectorKeys()
    {
        return new ArrayList<String>(_mapTpl.keySet());
    }

    protected static byte[] readAll(InputStream ins) throws Exception
    {
        if (ins == null)
            return null;

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[2048];
        int n;
        while ((n = ins.read(buf)) > 0)
            bos.write(buf, 0, n);
        return bos.toByteArray();
    }
}
