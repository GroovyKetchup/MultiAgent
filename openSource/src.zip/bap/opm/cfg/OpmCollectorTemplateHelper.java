package bap.opm.cfg;

import java.util.List;

import bap.opm.OpmParamDef;
import cell.bap.opm.collector.IOpmCollector;

public class OpmCollectorTemplateHelper
{
    private OpmCollectorTemplateHelper()
    {
    }

    public static OpmCollectorTemplate buildTemplateFromParamDefs(IOpmCollector collector)
    {
        if (collector == null)
            return null;

        OpmCollectorTemplate tpl = new OpmCollectorTemplate();
        tpl.key = collector.getCollectorKey();
        tpl.label = collector.getCollectorLabel();

        List<OpmParamDef> defs = collector.getParamDefs();
        if (defs != null)
        {
            for (OpmParamDef def : defs)
            {
                if (def == null || def.key == null)
                    continue;
                OpmParamDef p = new OpmParamDef(def.key, def.label, def.type, def.defaultValue).setDesc(def.desc);
                tpl.params.add(p);
            }
        }

        if (tpl.params.isEmpty())
            return null;

        return tpl;
    }
}
