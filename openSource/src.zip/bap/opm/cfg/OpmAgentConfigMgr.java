package bap.opm.cfg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.nutz.dao.Cnd;

import com.cdao.impl.entity.field.GID;
import com.cdao.model.CDo;
import com.cdao.model.CDoBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;
import com.leavay.common.util.javac.ClassFactory;

import bap.cells.Cells;
import bap.md.opm.cfg.OpmAgentConfigDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmConst;
import bap.opm.alarm.OpmAlarmPolicy;
import bap.opm.collector.topcpu.OpmTopCpuConst;
import bap.opm.collector.disk.OpmDiskConst;
import bap.opm.collector.topio.OpmTopIoConst;
import bap.opm.collector.topmemory.OpmTopMemoryConst;
import bap.opm.collector.topnet.OpmTopNetConst;
import bap.opm.collector.pg.OpmPgConst;
import bap.opm.collector.system.OpmSysConst;
import cell.bap.opm.collector.IOpmCollector;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.md.TsAgentDo;

public class OpmAgentConfigMgr
{
    public static final String JSON_KEY_VERSION = "version";
    public static final String JSON_KEY_UPDATE_TIME = "updateTime";
    public static final String JSON_KEY_PARAM = "params";
    public static final int JSON_VERSION = 1;

    public static class RuntimeSnapshot
    {
        public long updateTime;
        public boolean hasConfigRecord;
        public boolean hasEnabledCollector;
        public Map<String, String> paramMap;
    }

    private OpmAgentConfigMgr()
    {
    }

    public static ArrayList<IOpmCollector> getCollectors()
    {
        return buildBuiltinCollectors();
    }

    public static void refreshTemplate(List<IOpmCollector> collectors)
    {
        OpmConfigTemplateManager.refresh(collectors);
    }

    public static void autoDiscoverAndRefreshTemplate()
    {
        ArrayList<IOpmCollector> collectors = buildBuiltinCollectors();
        if (collectors.isEmpty())
            return;
        refreshTemplate(collectors);
    }

    protected static ArrayList<IOpmCollector> buildBuiltinCollectors()
    {
        LinkedHashMap<String, IOpmCollector> map = new LinkedHashMap<String, IOpmCollector>();

        appendCollectorsFromClassText(map, OpmConst.DEFAULT_CORE_COLLECTOR_CLASSES, true);

        ArrayList<IOpmCollector> out = new ArrayList<IOpmCollector>(map.values());
        Collections.sort(out, new Comparator<IOpmCollector>()
        {
            public int compare(IOpmCollector a, IOpmCollector b)
            {
                String ka = a == null ? "" : ToolUtilities.getString(a.getCollectorKey(), "");
                String kb = b == null ? "" : ToolUtilities.getString(b.getCollectorKey(), "");
                return ka.compareTo(kb);
            }
        });
        return out;
    }

    protected static void appendCollectorsFromClassText(LinkedHashMap<String, IOpmCollector> map, String classText,
            boolean verifyDefaultList)
    {
        if (map == null)
            return;

        List<String> classList = parseCollectorClasses(classText);
        if (classList.isEmpty())
            return;

        LinkedHashSet<String> loaded = new LinkedHashSet<String>();
        for (String className : classList)
        {
            IOpmCollector collector = createCollector(className);
            if (collector == null)
                continue;

            String key = safeCollectorKey(collector);
            if (ToolUtilities.isStringEmpty(key, true))
                continue;

            map.put(key, collector);
            loaded.add(className);
        }

        if (verifyDefaultList)
            logMissingCollectors(classList, loaded);
    }

    protected static IOpmCollector createCollector(String className)
    {
        String clsName = ToolUtilities.getString(className, null);
        if (ToolUtilities.isStringEmpty(clsName, true))
            return null;
        clsName = clsName.trim();

        try
        {
            Class<?> cls = ClassFactory.loadClass(clsName);
            if (cls == null)
                throw new IllegalStateException("Class not found: " + clsName);
            if (!IOpmCollector.class.isAssignableFrom(cls))
                throw new IllegalStateException("Class is not IOpmCollector: " + clsName);

            if (cls.isInterface())
            {
                @SuppressWarnings("unchecked")
                Class<? extends IOpmCollector> intfCls = (Class<? extends IOpmCollector>) cls;
                return Cells.get(intfCls);
            }

            return (IOpmCollector) ClassFactory.newInstance((Class<?>) cls);
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "Failed to create builtin collector: " + clsName, err);
            return null;
        }
    }

    protected static List<String> parseCollectorClasses(String txt)
    {
        ArrayList<String> list = new ArrayList<String>();
        if (txt == null)
            return list;

        String[] lines = txt.split("[\\r\\n;]");
        for (String line : lines)
        {
            if (line == null)
                continue;

            int iComment = line.indexOf('#');
            if (iComment >= 0)
                line = line.substring(0, iComment);

            String[] parts = line.split(",");
            for (String one : parts)
            {
                if (one == null)
                    continue;
                String cls = one.trim();
                if (cls.isEmpty())
                    continue;
                if (!list.contains(cls))
                    list.add(cls);
            }
        }
        return list;
    }

    protected static String safeCollectorKey(IOpmCollector collector)
    {
        if (collector == null || collector.getCollectorKey() == null || collector.getCollectorKey().trim().isEmpty())
            return null;
        return collector.getCollectorKey().trim();
    }

    protected static void logMissingCollectors(List<String> expected, LinkedHashSet<String> loaded)
    {
        if (expected == null || expected.isEmpty())
            return;

        ArrayList<String> missing = new ArrayList<String>();
        for (String one : expected)
        {
            if (ToolUtilities.isStringEmpty(one, true))
                continue;
            if (!loaded.contains(one))
                missing.add(one);
        }

        if (!missing.isEmpty())
        {
            ToolUtilities.warning(OpmConst.LOG,
                    "Builtin collector list has unresolved entries: " + missing + ", source="
                            + OpmConst.CONF_CORE_COLLECTOR_CLASSES);
        }
    }

    public static RuntimeSnapshot loadAndApplyRuntimeConfig(OpmAgentContext ctx) throws Exception
    {
        RuntimeSnapshot snap = new RuntimeSnapshot();

        if (ctx == null || ToolUtilities.isStringEmpty(ctx.getAgentCode(), true))
        {
            LinkedHashMap<String, String> dft = buildDefaultParams();
            OpmRuntimeConfig.apply(dft);
            snap.updateTime = 0L;
            snap.hasConfigRecord = false;
            snap.hasEnabledCollector = false;
            snap.paramMap = dft;
            return snap;
        }

        try (IDao dao = IDaoService.newIDao())
        {
            OpmAgentConfigDo cfg = queryByAgentCode(dao, ctx.getAgentCode());
            Map<String, String> map = buildMergedParamMap(cfg == null ? null : cfg.configJson);
            OpmRuntimeConfig.apply(map);

            snap.updateTime = ToolUtilities.getLong(cfg == null ? null : cfg.updateTime, 0L);
            snap.hasConfigRecord = cfg != null;
            snap.hasEnabledCollector = hasAnyCollectorEnabled(map);
            snap.paramMap = map;
            return snap;
        }
    }

    public static OpmAgentConfigDo queryByAgentGid(IDao dao, GID agentGid) throws Exception
    {
        if (dao == null || agentGid == null || ToolUtilities.isStringEmpty(agentGid.getUuid(), true))
            return null;
        return queryByAgentUuid(dao, agentGid.getUuid());
    }

    public static OpmAgentConfigDo queryByAgentUuid(IDao dao, String agentUuid) throws Exception
    {
        if (dao == null || ToolUtilities.isStringEmpty(agentUuid, true))
            return null;

        return dao.queryDo(OpmAgentConfigDo.class,
                Cnd.where(OpmAgentConfigDo.ForeignClass, "=", TsAgentDo.class.getName())
                        .and(OpmAgentConfigDo.ForeignKey, "=", agentUuid));
    }

    public static OpmAgentConfigDo queryByAgentCode(IDao dao, String agentCode) throws Exception
    {
        if (dao == null || ToolUtilities.isStringEmpty(agentCode, true))
            return null;

        CDo agt = dao.queryDo(TsAgentDo.class.getName(),
                Cnd.where(TsAgentDo.Code, "=", agentCode),
                CDoBasic.UUID);
        if (agt == null)
            return null;

        String agtUuid = agt.getString(CDoBasic.UUID);
        if (ToolUtilities.isStringEmpty(agtUuid, true))
            return null;
        return queryByAgentUuid(dao, agtUuid);
    }

    public static Map<String, String> queryConfigMapByAgentGid(GID agentGid) throws Exception
    {
        ensureBuiltinTemplateLoaded();
        if (agentGid == null)
            return buildDefaultParams();

        try (IDao dao = IDaoService.newIDao())
        {
            OpmAgentConfigDo cfg = queryByAgentGid(dao, agentGid);
            return buildMergedParamMap(cfg == null ? null : cfg.configJson);
        }
    }

    public static Map<String, String> queryConfigMapByAgentCode(String agentCode, String agentName, String myUri) throws Exception
    {
        ensureBuiltinTemplateLoaded();
        if (ToolUtilities.isStringEmpty(agentCode, true))
            return buildDefaultParams();

        try (IDao dao = IDaoService.newIDao())
        {
            OpmAgentConfigDo cfg = queryByAgentCode(dao, agentCode);
            return buildMergedParamMap(cfg == null ? null : cfg.configJson);
        }
    }

    public static void saveConfigMapByAgentGid(GID agentGid, Map<String, String> map) throws Exception
    {
        if (agentGid == null || ToolUtilities.isStringEmpty(agentGid.getUuid(), true))
            return;

        try (IDao dao = IDaoService.newIDao())
        {
            CDo agt = dao.queryDo(TsAgentDo.class.getName(), Cnd.where(CDoBasic.UUID, "=", agentGid.getUuid()),
                    CDoBasic.UUID, TsAgentDo.Code, TsAgentDo.Name);
            if (agt == null)
                throw new Exception("Agent not found: " + agentGid);

            String agtUuid = agt.getString(CDoBasic.UUID);
            String code = agt.getString(TsAgentDo.Code);
            String name = agt.getString(TsAgentDo.Name);

            OpmAgentConfigDo cfg = queryByAgentUuid(dao, agtUuid);
            if (cfg == null)
            {
                cfg = new OpmAgentConfigDo();
                cfg.setForeignGid(new GID(TsAgentDo.class.getName(), agtUuid));
                cfg.agentCode = code;
                cfg.agentName = name;
            }

            long now = System.currentTimeMillis();
            LinkedHashMap<String, String> merged = buildDefaultParams();
            if (map != null)
                for (Map.Entry<String, String> ent : map.entrySet())
                {
                    String key = ToolUtilities.getString(ent.getKey(), null);
                    if (ToolUtilities.isStringEmpty(key, true))
                        continue;
                    merged.put(key.trim(), normalizeVal(ent.getValue()));
                }

            cfg.agentCode = ToolUtilities.getString(code, cfg.agentCode);
            cfg.agentName = ToolUtilities.getString(name, cfg.agentName);
            cfg.updateTime = Long.valueOf(now);
            cfg.configJson = toConfigJson(merged, now);

            if (ToolUtilities.isStringEmpty(cfg.getUuid(), true))
                dao.createDo(cfg);
            else
                dao.updateDo(cfg, OpmAgentConfigDo.AgentCode, OpmAgentConfigDo.AgentName,
                        OpmAgentConfigDo.UpdateTime, OpmAgentConfigDo.ConfigJson);
            dao.commit();
        }
    }

    public static void saveConfigMapByAgentCode(String agentCode, String agentName, String myUri, Map<String, String> map) throws Exception
    {
        if (ToolUtilities.isStringEmpty(agentCode, true))
            return;

        try (IDao dao = IDaoService.newIDao())
        {
            OpmAgentConfigDo cfg = queryByAgentCode(dao, agentCode);
            if (cfg == null)
            {
                CDo agt = dao.queryDo(TsAgentDo.class.getName(), Cnd.where(TsAgentDo.Code, "=", agentCode),
                        CDoBasic.UUID, TsAgentDo.Code, TsAgentDo.Name);
                if (agt == null)
                    return;

                String agtUuid = agt.getString(CDoBasic.UUID);
                if (ToolUtilities.isStringEmpty(agtUuid, true))
                    return;

                cfg = new OpmAgentConfigDo();
                cfg.setForeignGid(new GID(TsAgentDo.class.getName(), agtUuid));
                cfg.agentCode = ToolUtilities.getString(agt.getString(TsAgentDo.Code), agentCode);
                cfg.agentName = ToolUtilities.getString(agt.getString(TsAgentDo.Name), agentName);
            }

            long now = System.currentTimeMillis();
            LinkedHashMap<String, String> merged = buildDefaultParams();
            if (map != null)
                for (Map.Entry<String, String> ent : map.entrySet())
                {
                    String key = ToolUtilities.getString(ent.getKey(), null);
                    if (ToolUtilities.isStringEmpty(key, true))
                        continue;
                    merged.put(key.trim(), normalizeVal(ent.getValue()));
                }

            String validationError = validateFocusConfig(merged);
            if (validationError != null)
                throw new Exception(validationError);

            cfg.agentCode = ToolUtilities.getString(agentCode, cfg.agentCode);
            cfg.agentName = ToolUtilities.getString(agentName, cfg.agentName);
            cfg.myUri = ToolUtilities.getString(myUri, cfg.myUri);
            cfg.updateTime = Long.valueOf(now);
            cfg.configJson = toConfigJson(merged, now);

            if (ToolUtilities.isStringEmpty(cfg.getUuid(), true))
                dao.createDo(cfg);
            else
                dao.updateDo(cfg, OpmAgentConfigDo.AgentCode, OpmAgentConfigDo.AgentName, OpmAgentConfigDo.MyUri,
                        OpmAgentConfigDo.UpdateTime, OpmAgentConfigDo.ConfigJson);
            dao.commit();
        }
    }

    public static LinkedHashMap<String, String> buildDefaultParams()
    {
        ensureBuiltinTemplateLoaded();

        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

        map.put(OpmConst.CONF_CORE_PERSIST_ENABLE, String.valueOf(OpmConst.DEFAULT_CORE_PERSIST_ENABLE));
        map.put(OpmConst.CONF_CORE_RETENTION_DAY, String.valueOf(OpmConst.DEFAULT_CORE_RETENTION_DAY));
        map.put(OpmConst.CONF_ALARM_SUPPRESS_SEC, String.valueOf(OpmConst.DEFAULT_ALARM_SUPPRESS_SEC));

        LinkedHashMap<String, String> template = OpmConfigTemplateManager.getDefaultConfigMap();
        if (template != null && !template.isEmpty())
            map.putAll(template);
        else
            map.putAll(buildFallbackCollectorDefaults());

        normalizeCollectorEnableDefaults(map);

        return map;
    }

    protected static void ensureBuiltinTemplateLoaded()
    {
        Map<String, OpmCollectorTemplate> all = OpmConfigTemplateManager.getAllTemplate();
        if (all != null && !all.isEmpty())
            return;
        refreshTemplate(buildBuiltinCollectors());
    }

    protected static LinkedHashMap<String, String> buildFallbackCollectorDefaults()
    {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

        map.put(OpmSysConst.CONF_ENABLE, String.valueOf(OpmSysConst.DEFAULT_ENABLE));
        map.put(OpmSysConst.CONF_COLLECT_INTERVAL_SEC, String.valueOf(OpmSysConst.DEFAULT_COLLECT_INTERVAL_SEC));
        map.put(OpmSysConst.CONF_CPU_SAMPLE_MILLIS, String.valueOf(OpmSysConst.DEFAULT_CPU_SAMPLE_MILLIS));
        map.put(OpmSysConst.CONF_CPU_WARN_RATE, String.valueOf(OpmSysConst.DEFAULT_CPU_WARN_RATE));
        map.put(OpmSysConst.CONF_CPU_CRITICAL_RATE, String.valueOf(OpmSysConst.DEFAULT_CPU_CRITICAL_RATE));
        map.put(OpmSysConst.CONF_MEM_WARN_RATE, String.valueOf(OpmSysConst.DEFAULT_MEM_WARN_RATE));
        map.put(OpmSysConst.CONF_MEM_CRITICAL_RATE, String.valueOf(OpmSysConst.DEFAULT_MEM_CRITICAL_RATE));
        map.put(OpmSysConst.CONF_IO_COLLECT_INTERVAL_SEC, String.valueOf(OpmSysConst.DEFAULT_IO_COLLECT_INTERVAL_SEC));
        map.put(OpmSysConst.CONF_IO_SAMPLE_MILLIS, String.valueOf(OpmSysConst.DEFAULT_IO_SAMPLE_MILLIS));
        map.put(OpmSysConst.CONF_IO_WARN_RATE, String.valueOf(OpmSysConst.DEFAULT_IO_WARN_RATE));
        map.put(OpmSysConst.CONF_IO_WARN_DURATION_SEC, String.valueOf(OpmSysConst.DEFAULT_IO_WARN_DURATION_SEC));
        map.put(OpmSysConst.CONF_IO_MINOR_RATE, String.valueOf(OpmSysConst.DEFAULT_IO_MINOR_RATE));
        map.put(OpmSysConst.CONF_IO_MINOR_DURATION_SEC, String.valueOf(OpmSysConst.DEFAULT_IO_MINOR_DURATION_SEC));
        map.put(OpmSysConst.CONF_IO_MAJOR_RATE, String.valueOf(OpmSysConst.DEFAULT_IO_MAJOR_RATE));
        map.put(OpmSysConst.CONF_IO_MAJOR_DURATION_SEC, String.valueOf(OpmSysConst.DEFAULT_IO_MAJOR_DURATION_SEC));
        map.put(OpmSysConst.CONF_IO_CRITICAL_RATE, String.valueOf(OpmSysConst.DEFAULT_IO_CRITICAL_RATE));
        map.put(OpmSysConst.CONF_IO_CRITICAL_DURATION_SEC, String.valueOf(OpmSysConst.DEFAULT_IO_CRITICAL_DURATION_SEC));
        map.put(OpmSysConst.CONF_NET_COLLECT_INTERVAL_SEC, String.valueOf(OpmSysConst.DEFAULT_NET_COLLECT_INTERVAL_SEC));
        map.put(OpmSysConst.CONF_NET_SAMPLE_MILLIS, String.valueOf(OpmSysConst.DEFAULT_NET_SAMPLE_MILLIS));
        map.put(OpmSysConst.CONF_NET_WARN_RATE, String.valueOf(OpmSysConst.DEFAULT_NET_WARN_RATE));
        map.put(OpmSysConst.CONF_NET_WARN_DURATION_SEC, String.valueOf(OpmSysConst.DEFAULT_NET_WARN_DURATION_SEC));
        map.put(OpmSysConst.CONF_NET_MINOR_RATE, String.valueOf(OpmSysConst.DEFAULT_NET_MINOR_RATE));
        map.put(OpmSysConst.CONF_NET_MINOR_DURATION_SEC, String.valueOf(OpmSysConst.DEFAULT_NET_MINOR_DURATION_SEC));
        map.put(OpmSysConst.CONF_NET_MAJOR_RATE, String.valueOf(OpmSysConst.DEFAULT_NET_MAJOR_RATE));
        map.put(OpmSysConst.CONF_NET_MAJOR_DURATION_SEC, String.valueOf(OpmSysConst.DEFAULT_NET_MAJOR_DURATION_SEC));
        map.put(OpmSysConst.CONF_NET_CRITICAL_RATE, String.valueOf(OpmSysConst.DEFAULT_NET_CRITICAL_RATE));
        map.put(OpmSysConst.CONF_NET_CRITICAL_DURATION_SEC, String.valueOf(OpmSysConst.DEFAULT_NET_CRITICAL_DURATION_SEC));

        map.put(OpmTopCpuConst.CONF_ENABLE, String.valueOf(OpmTopCpuConst.DEFAULT_ENABLE));
        map.put(OpmTopCpuConst.CONF_COLLECT_INTERVAL_SEC, String.valueOf(OpmTopCpuConst.DEFAULT_COLLECT_INTERVAL_SEC));
        map.put(OpmTopCpuConst.CONF_CPU_SAMPLE_MILLIS, String.valueOf(OpmTopCpuConst.DEFAULT_CPU_SAMPLE_MILLIS));
        map.put(OpmTopCpuConst.CONF_TOP_PROC_SIZE, String.valueOf(OpmTopCpuConst.DEFAULT_TOP_PROC_SIZE));
        map.put(OpmTopCpuConst.CONF_WARN_RATE, String.valueOf(OpmTopCpuConst.DEFAULT_WARN_RATE));
        map.put(OpmTopCpuConst.CONF_WARN_DURATION_SEC, String.valueOf(OpmTopCpuConst.DEFAULT_WARN_DURATION_SEC));
        map.put(OpmTopCpuConst.CONF_MINOR_RATE, String.valueOf(OpmTopCpuConst.DEFAULT_MINOR_RATE));
        map.put(OpmTopCpuConst.CONF_MINOR_DURATION_SEC, String.valueOf(OpmTopCpuConst.DEFAULT_MINOR_DURATION_SEC));
        map.put(OpmTopCpuConst.CONF_MAJOR_RATE, String.valueOf(OpmTopCpuConst.DEFAULT_MAJOR_RATE));
        map.put(OpmTopCpuConst.CONF_MAJOR_DURATION_SEC, String.valueOf(OpmTopCpuConst.DEFAULT_MAJOR_DURATION_SEC));
        map.put(OpmTopCpuConst.CONF_CRITICAL_RATE, String.valueOf(OpmTopCpuConst.DEFAULT_CRITICAL_RATE));
        map.put(OpmTopCpuConst.CONF_CRITICAL_DURATION_SEC, String.valueOf(OpmTopCpuConst.DEFAULT_CRITICAL_DURATION_SEC));

        map.put(OpmTopMemoryConst.CONF_ENABLE, String.valueOf(OpmTopMemoryConst.DEFAULT_ENABLE));
        map.put(OpmTopMemoryConst.CONF_COLLECT_INTERVAL_SEC, String.valueOf(OpmTopMemoryConst.DEFAULT_COLLECT_INTERVAL_SEC));
        map.put(OpmTopMemoryConst.CONF_WARN_RATE, String.valueOf(OpmTopMemoryConst.DEFAULT_WARN_RATE));
        map.put(OpmTopMemoryConst.CONF_WARN_DURATION_SEC, String.valueOf(OpmTopMemoryConst.DEFAULT_WARN_DURATION_SEC));
        map.put(OpmTopMemoryConst.CONF_MINOR_RATE, String.valueOf(OpmTopMemoryConst.DEFAULT_MINOR_RATE));
        map.put(OpmTopMemoryConst.CONF_MINOR_DURATION_SEC, String.valueOf(OpmTopMemoryConst.DEFAULT_MINOR_DURATION_SEC));
        map.put(OpmTopMemoryConst.CONF_MAJOR_RATE, String.valueOf(OpmTopMemoryConst.DEFAULT_MAJOR_RATE));
        map.put(OpmTopMemoryConst.CONF_MAJOR_DURATION_SEC, String.valueOf(OpmTopMemoryConst.DEFAULT_MAJOR_DURATION_SEC));
        map.put(OpmTopMemoryConst.CONF_CRITICAL_RATE, String.valueOf(OpmTopMemoryConst.DEFAULT_CRITICAL_RATE));
        map.put(OpmTopMemoryConst.CONF_CRITICAL_DURATION_SEC, String.valueOf(OpmTopMemoryConst.DEFAULT_CRITICAL_DURATION_SEC));

        map.put(OpmDiskConst.CONF_ENABLE, String.valueOf(OpmDiskConst.DEFAULT_ENABLE));
        map.put(OpmDiskConst.CONF_COLLECT_INTERVAL_SEC, String.valueOf(OpmDiskConst.DEFAULT_COLLECT_INTERVAL_SEC));

        map.put(OpmTopIoConst.CONF_ENABLE, String.valueOf(OpmTopIoConst.DEFAULT_ENABLE));
        map.put(OpmTopIoConst.CONF_COLLECT_INTERVAL_SEC, String.valueOf(OpmTopIoConst.DEFAULT_COLLECT_INTERVAL_SEC));
        map.put(OpmTopIoConst.CONF_SAMPLE_MILLIS, String.valueOf(OpmTopIoConst.DEFAULT_SAMPLE_MILLIS));
        map.put(OpmTopIoConst.CONF_TOP_PROC_SIZE, String.valueOf(OpmTopIoConst.DEFAULT_TOP_PROC_SIZE));

        map.put(OpmTopNetConst.CONF_ENABLE, String.valueOf(OpmTopNetConst.DEFAULT_ENABLE));
        map.put(OpmTopNetConst.CONF_COLLECT_INTERVAL_SEC, String.valueOf(OpmTopNetConst.DEFAULT_COLLECT_INTERVAL_SEC));
        map.put(OpmTopNetConst.CONF_SAMPLE_MILLIS, String.valueOf(OpmTopNetConst.DEFAULT_SAMPLE_MILLIS));
        map.put(OpmTopNetConst.CONF_TOP_PROC_SIZE, String.valueOf(OpmTopNetConst.DEFAULT_TOP_PROC_SIZE));

        map.put(OpmPgConst.CONF_ENABLE, String.valueOf(OpmPgConst.DEFAULT_ENABLE));
        map.put(OpmPgConst.CONF_COLLECT_INTERVAL_SEC, String.valueOf(OpmPgConst.DEFAULT_COLLECT_INTERVAL_SEC));
        map.put(OpmPgConst.CONF_LOW_FREQ_COLLECT_INTERVAL_SEC, String.valueOf(OpmPgConst.DEFAULT_LOW_FREQ_COLLECT_INTERVAL_SEC));

        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_ENABLE, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_ENABLE));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_COLLECT_INTERVAL_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_COLLECT_INTERVAL_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MATCH_PIDS, bap.opm.collector.focus.OpmFocusConst.DEFAULT_MATCH_PIDS);
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MATCH_PROCESS_NAMES, bap.opm.collector.focus.OpmFocusConst.DEFAULT_MATCH_PROCESS_NAMES);
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MATCH_PROCESS_PATHS, bap.opm.collector.focus.OpmFocusConst.DEFAULT_MATCH_PROCESS_PATHS);
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_CPU_WARN_RATE, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_CPU_WARN_RATE));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_CPU_WARN_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_CPU_WARN_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_CPU_MINOR_RATE, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_CPU_MINOR_RATE));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_CPU_MINOR_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_CPU_MINOR_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_CPU_MAJOR_RATE, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_CPU_MAJOR_RATE));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_CPU_MAJOR_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_CPU_MAJOR_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_CPU_CRITICAL_RATE, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_CPU_CRITICAL_RATE));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_CPU_CRITICAL_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_CPU_CRITICAL_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_WARN_BYTES, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_MEMORY_WARN_BYTES));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_WARN_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_MEMORY_WARN_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_MINOR_BYTES, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_MEMORY_MINOR_BYTES));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_MINOR_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_MEMORY_MINOR_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_MAJOR_BYTES, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_MEMORY_MAJOR_BYTES));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_MAJOR_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_MEMORY_MAJOR_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_CRITICAL_BYTES, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_MEMORY_CRITICAL_BYTES));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_CRITICAL_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_MEMORY_CRITICAL_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_IO_WARN_RATE, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_IO_WARN_RATE));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_IO_WARN_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_IO_WARN_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_IO_MINOR_RATE, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_IO_MINOR_RATE));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_IO_MINOR_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_IO_MINOR_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_IO_MAJOR_RATE, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_IO_MAJOR_RATE));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_IO_MAJOR_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_IO_MAJOR_DURATION_SEC));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_IO_CRITICAL_RATE, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_IO_CRITICAL_RATE));
        map.put(bap.opm.collector.focus.OpmFocusConst.CONF_IO_CRITICAL_DURATION_SEC, String.valueOf(bap.opm.collector.focus.OpmFocusConst.DEFAULT_IO_CRITICAL_DURATION_SEC));

        map.put(bap.opm.collector.diskpartition.OpmDiskPartitionConst.CONF_ENABLE, String.valueOf(bap.opm.collector.diskpartition.OpmDiskPartitionConst.DEFAULT_ENABLE));
        map.put(bap.opm.collector.diskpartition.OpmDiskPartitionConst.CONF_WARN_RATE, String.valueOf(bap.opm.collector.diskpartition.OpmDiskPartitionConst.DEFAULT_WARN_RATE));
        map.put(bap.opm.collector.diskpartition.OpmDiskPartitionConst.CONF_CRITICAL_RATE, String.valueOf(bap.opm.collector.diskpartition.OpmDiskPartitionConst.DEFAULT_CRITICAL_RATE));


        return map;
    }

    public static LinkedHashMap<String, String> buildMergedParamMap(String configJson)
    {
        LinkedHashMap<String, String> out = buildDefaultParams();
        LinkedHashMap<String, String> custom = parseParamMap(configJson);
        if (custom != null && !custom.isEmpty())
            out.putAll(custom);
        return out;
    }

    @SuppressWarnings("unchecked")
    public static LinkedHashMap<String, String> parseParamMap(String configJson)
    {
        if (ToolUtilities.isStringEmpty(configJson, true))
            return new LinkedHashMap<String, String>();

        try
        {
            Object obj = CJson.fromJson(configJson);
            Object normalized = normalizeCJsonObject(obj);
            if (!(normalized instanceof Map))
                return new LinkedHashMap<String, String>();

            Map<String, Object> root = (Map<String, Object>) normalized;
            Object params = root.get(JSON_KEY_PARAM);
            if (params == null)
                params = root;

            if (!(params instanceof Map))
                return new LinkedHashMap<String, String>();

            LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
            for (Map.Entry<String, Object> ent : ((Map<String, Object>) params).entrySet())
            {
                String key = ToolUtilities.getString(ent.getKey(), null);
                if (ToolUtilities.isStringEmpty(key, true))
                    continue;
                map.put(key.trim(), normalizeVal(ent.getValue()));
            }
            return map;
        }
        catch (Throwable err)
        {
            return new LinkedHashMap<String, String>();
        }
    }

    public static String toConfigJson(Map<String, String> map, long updateTime)
    {
        LinkedHashMap<String, Object> root = new LinkedHashMap<String, Object>();
        root.put(JSON_KEY_VERSION, Integer.valueOf(JSON_VERSION));
        root.put(JSON_KEY_UPDATE_TIME, Long.valueOf(updateTime));
        root.put(JSON_KEY_PARAM, map == null ? new LinkedHashMap<String, String>() : map);
        return CJson.toJson(root);
    }

    protected static String normalizeVal(Object obj)
    {
        if (obj == null)
            return null;
        String v = String.valueOf(obj);
        return v == null ? null : v.trim();
    }

    @SuppressWarnings("unchecked")
    protected static Object normalizeCJsonObject(Object obj)
    {
        if (obj == null)
            return null;

        if (obj instanceof Map)
        {
            Map<Object, Object> map = (Map<Object, Object>) obj;

            if (map.containsKey("#O"))
                return normalizeCJsonObject(map.get("#O"));

            if (map.containsKey("#M"))
            {
                Object items = map.get("#M");
                if (items instanceof List)
                {
                    LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
                    for (Object one : (List<Object>) items)
                    {
                        if (!(one instanceof Map))
                            continue;
                        Map<Object, Object> ent = (Map<Object, Object>) one;
                        String k = ToolUtilities.getString(ent.get("$"), null);
                        if (ToolUtilities.isStringEmpty(k, true))
                            continue;
                        ret.put(k, normalizeCJsonObject(ent.get("^")));
                    }
                    return ret;
                }
            }

            if (map.containsKey("#L"))
            {
                Object arr = map.get("#L");
                if (arr instanceof List)
                {
                    ArrayList<Object> ret = new ArrayList<Object>();
                    for (Object one : (List<Object>) arr)
                        ret.add(normalizeCJsonObject(one));
                    return ret;
                }
            }

            if (map.containsKey("@") || map.containsKey("@A"))
                return null;

            LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
            for (Map.Entry<Object, Object> ent : map.entrySet())
            {
                String k = String.valueOf(ent.getKey());
                if (k.startsWith("#"))
                    continue;
                ret.put(k, normalizeCJsonObject(ent.getValue()));
            }
            return ret;
        }

        if (obj instanceof List)
        {
            ArrayList<Object> ret = new ArrayList<Object>();
            for (Object one : (List<Object>) obj)
                ret.add(normalizeCJsonObject(one));
            return ret;
        }

        return obj;
    }

    protected static boolean hasAnyCollectorEnabled(Map<String, String> map)
    {
        if (map == null || map.isEmpty())
            return false;

        for (Map.Entry<String, String> ent : map.entrySet())
        {
            String key = ToolUtilities.getString(ent.getKey(), null);
            if (!isCollectorEnableKey(key))
                continue;

            if (ToolUtilities.getBoolean(ent.getValue(), false))
                return true;
        }
        return false;
    }

    protected static void normalizeCollectorEnableDefaults(Map<String, String> map)
    {
        if (map == null || map.isEmpty())
            return;

        for (Map.Entry<String, String> ent : map.entrySet())
        {
            String key = ToolUtilities.getString(ent.getKey(), null);
            if (!isCollectorEnableKey(key))
                continue;
            ent.setValue("false");
        }
    }

    protected static boolean isCollectorEnableKey(String key)
    {
        if (ToolUtilities.isStringEmpty(key, true))
            return false;

        String k = key.trim();
        if (!k.startsWith("opm."))
            return false;
        if (!k.endsWith(".enable"))
            return false;
        if (k.startsWith("opm.core.") || k.startsWith("opm.alarm."))
            return false;
        return true;
    }

    protected static String validateFocusConfig(Map<String, String> map)
    {
        if (map == null)
            return null;

        String pids = map.get(bap.opm.collector.focus.OpmFocusConst.CONF_MATCH_PIDS);
        String names = map.get(bap.opm.collector.focus.OpmFocusConst.CONF_MATCH_PROCESS_NAMES);
        String paths = map.get(bap.opm.collector.focus.OpmFocusConst.CONF_MATCH_PROCESS_PATHS);

        return bap.opm.collector.focus.OpmFocusMatcher.validateConfig(pids, names, paths);
    }
}
