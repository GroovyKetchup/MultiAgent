package bap.opm.cfg;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import bap.opm.OpmParamDef;

public class OpmCollectorTemplate
{
    public String key;
    public String label;
    public String resourcePath;

    public final List<OpmParamDef> params = new ArrayList<OpmParamDef>();
    public final Map<String, String> groups = new LinkedHashMap<String, String>();
    public final Map<String, String> paramGroups = new LinkedHashMap<String, String>();

    public OpmCollectorTemplate copyShallow()
    {
        OpmCollectorTemplate t = new OpmCollectorTemplate();
        t.key = key;
        t.label = label;
        t.resourcePath = resourcePath;
        t.params.addAll(params);
        t.groups.putAll(groups);
        t.paramGroups.putAll(paramGroups);
        return t;
    }
}
