package bap.opm;

import com.leavay.common.util.MppContext;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.mgr.starter.CDaoStarter;
import com.leavay.starter.CStarter;

import bap.AuthInitRegister;
import bap.ServletInitRegister;
import bap.auth.AuthModuleConfig;
import bap.opm.web.OpmAuthProvider;
import bap.opm.web.OpmAuthServlet;
import bap.opm.web.OpmWebServlet;

public class OpmStarter implements CStarter
{
    @Override
    public void init() throws Exception
    {
        initOpmWebSettings();

        if (!MppContext.getBoolean(OpmConst.CONF_WEB_ENABLE, OpmConst.DEFAULT_WEB_ENABLE))
            return;

        ServletInitRegister.get().initRegistServlet(OpmAuthServlet.SERVLET_CONTEXT_PATH, OpmAuthServlet.class);
        ToolUtilities.infoAndOutput(getClass().getSimpleName(), "Regist OPM Auth Servlet: " + OpmAuthServlet.SERVLET_CONTEXT_PATH);

        ServletInitRegister.get().initRegistServlet(OpmWebServlet.SERVLET_CONTEXT_PATH, OpmWebServlet.class);
        ToolUtilities.infoAndOutput(getClass().getSimpleName(), "Regist OPM Web Servlet: " + OpmWebServlet.SERVLET_CONTEXT_PATH);

        registerOpmAuthModule();
    }

    protected void registerOpmAuthModule()
    {
        AuthModuleConfig moduleConfig = new AuthModuleConfig()
                .setModuleKey(getClass().getName())
                .setOrder(100)
                .setLoginRedirectPath(OpmConst.WEB_LOGIN_REDIRECT_PATH)
                .setAuthProvider(new OpmAuthProvider())
                .addManagedPath(OpmConst.WEB_ROOT_PATH)
                .addManagedPath(OpmWebServlet.SERVLET_CONTEXT_PATH)
                .addManagedPath(OpmConst.DEFAULT_WEB_BASE_PATH + "*")
                .addManagedPath(OpmConst.WEB_INDEX_PATH)
                .addPublicPath(OpmConst.WEB_ROOT_PATH)
                .addPublicPath(OpmAuthServlet.SERVLET_CONTEXT_PATH)
                .addPublicPath(OpmConst.AUTH_LOGIN_PATH)
                .addPublicPath(OpmConst.AUTH_CHECK_PATH)
                .addPublicPath(OpmConst.AUTH_REFRESH_PATH)
                .addPublicPath(OpmConst.AUTH_USER_INFO_PATH)
                .addPublicPath(OpmConst.WEB_PING_PATH)
                .addPublicPath(OpmConst.FAVICON_PATH)
                .addPublicPath(OpmConst.DEFAULT_WEB_BASE_PATH)
                .addPublicPath(OpmConst.WEB_INDEX_PATH)
                .addApiPath(OpmWebServlet.SERVLET_CONTEXT_PATH)
                .addStaticExtension(".css")
                .addStaticExtension(".js")
                .addStaticExtension(".png")
                .addStaticExtension(".jpg")
                .addStaticExtension(".jpeg")
                .addStaticExtension(".gif")
                .addStaticExtension(".svg")
                .addStaticExtension(".ico")
                .addStaticExtension(".woff")
                .addStaticExtension(".woff2")
                .addStaticExtension(".ttf")
                .addStaticExtension(".eot")
                .addStaticExtension(".html");

        AuthInitRegister.get().registerModule(moduleConfig);
        ToolUtilities.infoAndOutput(getClass().getSimpleName(), "Regist OPM Auth Module: " + moduleConfig.getModuleKey());
    }

    protected void initOpmWebSettings()
    {
        setDefaultConfig("jetty.resource.path", "/webapps");
        setDefaultConfig(OpmConst.CONF_WEB_BASE_PATH, OpmConst.DEFAULT_WEB_BASE_PATH);
        setDefaultConfig(OpmConst.CONF_WEB_API_PATH, OpmConst.DEFAULT_WEB_API_PATH);
        setDefaultConfig(OpmConst.CONF_WEB_DEPLOY_DIR, OpmConst.DEFAULT_WEB_DEPLOY_DIR);
        setDefaultConfig(OpmConst.CONF_WEB_DASHBOARD_LIMIT, OpmConst.DEFAULT_WEB_DASHBOARD_LIMIT);
    }

    protected void setDefaultConfig(String key, Object value)
    {
        if (!ToolUtilities.isStringEmpty(MppContext.getString(key), true))
            return;
        MppContext.setProperty(key, value);
    }

    @Override
    public void before(CStarter other) throws Exception
    {
        // 参考 WFE 模式：在 DAO 启动前注册静态模型
        if (other instanceof CDaoStarter)
            OpmCenter.get().initBeforeDao();
    }

    @Override
    public void start() throws Exception
    {
        // 启动 OPM 主循环（采集/规则/告警）
        OpmCenter.get().start();
    }
}
