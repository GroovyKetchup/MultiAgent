package bap.opm.web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.nutz.dao.Cnd;
import org.nutz.dao.Sqls;
import org.nutz.dao.util.cri.SqlExpressionGroup;

import com.cdao.dto.CPager;
import com.cdao.model.CDo;
import com.cdao.model.CDoBasic;
import com.leavay.common.reflect.TypeToken;
import com.leavay.common.util.GsonUtil;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.md.opm.OpmAlarmRefDo;
import bap.md.opm.OpmMetricMainDo;
import bap.md.opm.cpu.OpmCpuMetricDo;
import bap.md.opm.disk.OpmDiskMetricDo;
import bap.md.opm.io.OpmIoMetricDo;
import bap.md.opm.memory.OpmMemoryMetricDo;
import bap.md.opm.net.OpmNetMetricDo;
import bap.md.opm.pg.OpmPgMetricDo;
import bap.md.opm.sys.OpmSysMetricDo;
import bap.md.opm.io.OpmIoMetricDo;
import bap.md.opm.net.OpmNetMetricDo;
import bap.md.opm.sys.OpmSysMetricDo;
import bap.opm.OpmCenterServiceImpl;
import bap.opm.OpmCollectResult;
import bap.opm.OpmConst;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.md.TsAgentDo;

public class OpmWebServlet extends HttpServlet
{
    private static final long serialVersionUID = 1L;

    public static final String SERVLET_CONTEXT_PATH = "/api/opm/*";

    protected static final String ACTION_PING = "ping";
    protected static final String ACTION_DASHBOARD = "dashboard";
    protected static final int DASHBOARD_LIMIT_DEFAULT = 36;
    protected static final int DASHBOARD_LIMIT_MAX = 60;
    protected static final int DASHBOARD_ALARM_LIMIT = 6;
    protected static final String ACTION_GLOBAL = "global";
    protected static final String ACTION_COLLECT_NOW = "collectNow";
    protected static final String ACTION_CONFIG_SCHEMA = "configSchema";
    protected static final String ACTION_CONFIG_LOAD = "configLoad";
    protected static final String ACTION_CONFIG_SAVE = "configSave";
    protected static final String ACTION_AGENTS = "agents";
    protected static final String ACTION_ALARMS = "alarms";
    protected static final String ACTION_ALARM_DETAIL = "alarm/detail";
    protected static final String ACTION_ALARMS_ACKNOWLEDGE = "alarms/acknowledge";
    protected static final String ACTION_COLLECT_LIST = "collect/list";
    protected static final String ACTION_COLLECT_DETAIL = "collect/detail";
    protected static final String ACTION_COLLECT_SUMMARY = "collect/summary";

    protected static final int LIMIT_MIN = 20;
    protected static final int LIMIT_MAX = 300;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        processRequest(req, resp);
    }

    protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        String pathInfo = req.getPathInfo();
        String action = normalizeAction(pathInfo);

        try
        {
            if (ACTION_PING.equals(action))
            {
                handlePing(resp);
                return;
            }

            if (ACTION_DASHBOARD.equals(action))
            {
                handleDashboard(req, resp);
                return;
            }

            if (ACTION_GLOBAL.equals(action))
            {
                handleGlobal(req, resp);
                return;
            }

            if (ACTION_COLLECT_NOW.equals(action))
            {
                handleCollectNow(req, resp);
                return;
            }

            if (ACTION_CONFIG_SCHEMA.equals(action))
            {
                handleConfigSchema(resp);
                return;
            }

            if (ACTION_CONFIG_LOAD.equals(action))
            {
                handleConfigLoad(req, resp);
                return;
            }

            if (ACTION_CONFIG_SAVE.equals(action))
            {
                handleConfigSave(req, resp);
                return;
            }

            if (ACTION_AGENTS.equals(action))
            {
                handleAgents(req, resp);
                return;
            }

            if (ACTION_ALARMS.equals(action))
            {
                handleAlarms(req, resp);
                return;
            }

            if (ACTION_ALARM_DETAIL.equals(action))
            {
                handleAlarmDetail(req, resp);
                return;
            }

            if (ACTION_ALARMS_ACKNOWLEDGE.equals(action))
            {
                handleAlarmsAcknowledge(req, resp);
                return;
            }

            if (ACTION_COLLECT_LIST.equals(action))
            {
                handleCollectList(req, resp);
                return;
            }

            if (ACTION_COLLECT_DETAIL.equals(action))
            {
                handleCollectDetail(req, resp);
                return;
            }

            if (ACTION_COLLECT_SUMMARY.equals(action))
            {
                handleCollectSummary(req, resp);
                return;
            }

            error(resp, "Unknown action: " + action);
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "[opm.web.error] action=" + action + ", message=" + err.getMessage(), err);
            error(resp, err.getMessage());
        }
    }

    protected String normalizeAction(String pathInfo)
    {
        if (ToolUtilities.isStringEmpty(pathInfo, true) || "/".equals(pathInfo))
            return ACTION_PING;

        String action = pathInfo.substring(1);
        if (ToolUtilities.isStringEmpty(action, true))
            return ACTION_PING;

        return action.trim();
    }

    protected void handlePing(HttpServletResponse resp) throws Exception
    {
        OpmCenterServiceImpl intf = OpmCenterServiceImpl.get();

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("service", "opm-web");
        data.put("now", System.currentTimeMillis());
        data.put("runtimeMeta", intf.queryRuntimeMeta());
        data.put("collectors", intf.listCollectorKeys());
        data.put("webBasePath", MppContext.getString(OpmConst.CONF_WEB_BASE_PATH, OpmConst.DEFAULT_WEB_BASE_PATH));
        data.put("webApiPath", MppContext.getString(OpmConst.CONF_WEB_API_PATH, OpmConst.DEFAULT_WEB_API_PATH));
        success(resp, data);
    }

    protected void handleDashboard(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        int limit = parseDashboardLimit(req.getParameter("limit"));
        OpmCenterServiceImpl intf = OpmCenterServiceImpl.get();
        String agentCode = resolveAgentCode(req, intf);
        String agentName = queryAgentName(agentCode);
        boolean opmEnabled = intf.isAgentOpmEditable(agentCode);

        List<OpmSysMetricDo> sysList = new ArrayList<OpmSysMetricDo>();
        List<OpmCpuMetricDo> cpuList = new ArrayList<OpmCpuMetricDo>();
        List<OpmMemoryMetricDo> memoryList = new ArrayList<OpmMemoryMetricDo>();
        List<OpmDiskMetricDo> diskList = new ArrayList<OpmDiskMetricDo>();
        List<OpmIoMetricDo> ioList = new ArrayList<OpmIoMetricDo>();
        List<OpmNetMetricDo> netList = new ArrayList<OpmNetMetricDo>();
        List<OpmPgMetricDo> pgList = new ArrayList<OpmPgMetricDo>();
        List<OpmAlarmRefDo> alarmList = new ArrayList<OpmAlarmRefDo>();
        if (opmEnabled)
        {
            sysList = queryLatestByAgent(OpmSysMetricDo.class, OpmSysMetricDo.AgentCode, OpmSysMetricDo.CollectTime, agentCode,
                    limit);
            cpuList = queryLatestByAgent(OpmCpuMetricDo.class, OpmCpuMetricDo.AgentCode, OpmCpuMetricDo.CollectTime, agentCode,
                    limit);
            memoryList = queryLatestByAgent(OpmMemoryMetricDo.class, OpmMemoryMetricDo.AgentCode, OpmMemoryMetricDo.CollectTime, agentCode,
                    limit);
            diskList = queryLatestByAgent(OpmDiskMetricDo.class, OpmDiskMetricDo.AgentCode, OpmDiskMetricDo.CollectTime, agentCode,
                    limit);
            ioList = queryLatestByAgent(OpmIoMetricDo.class, OpmIoMetricDo.AgentCode, OpmIoMetricDo.CollectTime, agentCode,
                    limit);
            netList = queryLatestByAgent(OpmNetMetricDo.class, OpmNetMetricDo.AgentCode, OpmNetMetricDo.CollectTime, agentCode,
                    limit);
            pgList = queryLatestByAgent(OpmPgMetricDo.class, OpmPgMetricDo.AgentCode, OpmPgMetricDo.CollectTime, agentCode,
                    limit);
            alarmList = queryLatestByAgent(OpmAlarmRefDo.class, OpmAlarmRefDo.AgentCode, OpmAlarmRefDo.AlarmTime, agentCode,
                    DASHBOARD_ALARM_LIMIT);
        }

        Map<String, Object> runtimeMeta = intf.queryRuntimeMeta();
        LinkedHashMap<String, Object> selectedRuntimeMeta = new LinkedHashMap<String, Object>();
        if (runtimeMeta != null)
            selectedRuntimeMeta.putAll(runtimeMeta);
        selectedRuntimeMeta.put("agentCode", agentCode);
        selectedRuntimeMeta.put("agentName", ToolUtilities.isStringEmpty(agentName, true) ? agentCode : agentName);
        selectedRuntimeMeta.put("runtimeHasConfigRecord", opmEnabled);
        selectedRuntimeMeta.put("runtimeConfigured", opmEnabled);
        selectedRuntimeMeta.put("runtimeCollectorEnabled", opmEnabled);

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("runtimeMeta", runtimeMeta);
        data.put("selectedRuntimeMeta", selectedRuntimeMeta);
        data.put("agentCode", agentCode);
        data.put("selectedAgentCode", agentCode);
        data.put("selectedAgentName", ToolUtilities.isStringEmpty(agentName, true) ? agentCode : agentName);
        data.put("selectedAgentEditable", opmEnabled);
        data.put("selectedAgentOpmEnabled", opmEnabled);
        data.put("collectors", intf.listCollectorKeys());
        data.put("sys", mapSysList(sysList, true));
        data.put("topCpu", mapCpuList(cpuList, true));
        data.put("topMemory", mapMemoryList(memoryList, true));
        data.put("disk", mapDiskList(diskList, true));
        data.put("topIo", mapIoList(ioList, true));
        data.put("topNet", mapNetList(netList, true));
        data.put("pg", mapPgList(pgList, true));
        data.put("alarms", mapAlarmList(filterDashboardAlarms(alarmList), false));
        success(resp, data);
    }

    protected int parseDashboardLimit(String text)
    {
        int value = parseLimit(text);
        if (value <= 0)
            value = DASHBOARD_LIMIT_DEFAULT;
        if (value > DASHBOARD_LIMIT_MAX)
            value = DASHBOARD_LIMIT_MAX;
        return value;
    }

    protected void handleGlobal(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        OpmCenterServiceImpl intf = OpmCenterServiceImpl.get();
        List<Map<String, Object>> agentList = queryAgentList(intf);

        List<Map<String, Object>> nodeList = new ArrayList<Map<String, Object>>();
        int totalAlarms = 0;
        double sumCpu = 0;
        double sumMem = 0;
        int cpuCount = 0;
        int memCount = 0;
        List<Map<String, Object>> alarmList = new ArrayList<Map<String, Object>>();

        for (Map<String, Object> agent : agentList)
        {
            if (agent == null)
                continue;

            String agentCode = ToolUtilities.getString(agent.get("agentCode"), null);
            if (ToolUtilities.isStringEmpty(agentCode, true))
                continue;

            boolean opmEnabled = ToolUtilities.getBoolean(agent.get("opmEnabled"), false);

            LinkedHashMap<String, Object> node = new LinkedHashMap<String, Object>();
            node.put("agentCode", agentCode);
            node.put("agentName", ToolUtilities.getString(agent.get("agentName"), agentCode));
            node.put("myUri", agent.get("myUri"));
            node.put("lastReportTime", agent.get("lastReportTime"));
            node.put("opmEnabled", opmEnabled);

            boolean online = agent.get("lastReportTime") != null && ((Number) agent.get("lastReportTime")).longValue() > 0;
            node.put("online", online);

            double cpuUsage = 0;
            double memUsage = 0;
            int alarmCount = 0;

            if (opmEnabled && online)
            {
                List<OpmCpuMetricDo> cpuList = queryLatestByAgent(OpmCpuMetricDo.class, OpmCpuMetricDo.AgentCode,
                        OpmCpuMetricDo.CollectTime, agentCode, 1);
                if (cpuList != null && !cpuList.isEmpty())
                {
                    OpmCpuMetricDo latest = cpuList.get(0);
                    cpuUsage = normalizeRatio(latest.cpuUsageRate);
                    sumCpu += cpuUsage;
                    cpuCount++;
                    node.put("cpuUsage", cpuUsage);
                }

                List<OpmMemoryMetricDo> memoryList = queryLatestByAgent(OpmMemoryMetricDo.class, OpmMemoryMetricDo.AgentCode,
                        OpmMemoryMetricDo.CollectTime, agentCode, 1);
                if (memoryList != null && !memoryList.isEmpty())
                {
                    OpmMemoryMetricDo latest = memoryList.get(0);
                    memUsage = normalizeRatio(latest.usageRate);
                    sumMem += memUsage;
                    memCount++;
                    node.put("memUsage", memUsage);
                }

                List<OpmNetMetricDo> netList = queryLatestByAgent(OpmNetMetricDo.class, OpmNetMetricDo.AgentCode,
                        OpmNetMetricDo.CollectTime, agentCode, 1);
                if (netList != null && !netList.isEmpty())
                {
                    OpmNetMetricDo latest = netList.get(0);
                    double netIoUsage = calculateNetIoUsage(latest);
                    node.put("netIoUsage", netIoUsage);
                }

                List<OpmAlarmRefDo> alarms = queryLatestByAgent(OpmAlarmRefDo.class, OpmAlarmRefDo.AgentCode,
                        OpmAlarmRefDo.AlarmTime, agentCode, 10);
                if (alarms != null)
                {
                    for (OpmAlarmRefDo a : alarms)
                    {
                        if (a == null)
                            continue;
                        if (!Boolean.TRUE.equals(a.acknowledged))
                            alarmCount++;
                    }
                }
                totalAlarms += alarmCount;

                if (alarms != null)
                {
                    for (OpmAlarmRefDo a : alarms)
                    {
                        if (a == null)
                            continue;
                        LinkedHashMap<String, Object> alarmItem = new LinkedHashMap<String, Object>();
                        alarmItem.put("agentCode", a.agentCode);
                        alarmItem.put("agentName", a.agentName);
                        alarmItem.put("level", a.alarmLevel);
                        alarmItem.put("message", a.message);
                        alarmItem.put("time", a.alarmTime);
                        alarmList.add(alarmItem);
                    }
                }
            }

            node.put("alarmCount", alarmCount);
            nodeList.add(node);
        }

        int alarmAgents = 0;
        for (Map<String, Object> node : nodeList)
        {
            if (node != null && ToolUtilities.getInteger(node.get("alarmCount"), 0) > 0)
                alarmAgents++;
        }

        LinkedHashMap<String, Object> summary = new LinkedHashMap<String, Object>();
        summary.put("totalAgents", nodeList.size());
        summary.put("onlineAgents", countOnlineAgents(nodeList));
        summary.put("opmEnabledAgents", countOpmEnabledAgents(nodeList));
        summary.put("alarmAgents", alarmAgents);
        summary.put("totalAlarms", totalAlarms);
        summary.put("avgCpu", cpuCount > 0 ? sumCpu / cpuCount : 0);
        summary.put("avgMem", memCount > 0 ? sumMem / memCount : 0);

        Collections.sort(alarmList, new Comparator<Map<String, Object>>()
        {
            @Override
            public int compare(Map<String, Object> o1, Map<String, Object> o2)
            {
                int l1 = ToolUtilities.getInteger(o1 == null ? null : o1.get("level"), 0);
                int l2 = ToolUtilities.getInteger(o2 == null ? null : o2.get("level"), 0);
                if (l2 != l1)
                    return Integer.compare(l2, l1);
                long t1 = ToolUtilities.getLong(o1 == null ? null : o1.get("time"), 0L);
                long t2 = ToolUtilities.getLong(o2 == null ? null : o2.get("time"), 0L);
                return Long.compare(t2, t1);
            }
        });

        List<Map<String, Object>> topAlarms = alarmList.size() > 20 ? alarmList.subList(0, 20) : alarmList;

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("nodes", nodeList);
        data.put("summary", summary);
        data.put("topAlarms", topAlarms);
        data.put("now", System.currentTimeMillis());
        success(resp, data);
    }

    private int countOnlineAgents(List<Map<String, Object>> nodeList)
    {
        int count = 0;
        if (nodeList == null)
            return count;
        for (Map<String, Object> node : nodeList)
        {
            if (node != null && ToolUtilities.getBoolean(node.get("online"), false))
                count++;
        }
        return count;
    }

    private int countOpmEnabledAgents(List<Map<String, Object>> nodeList)
    {
        int count = 0;
        if (nodeList == null)
            return count;
        for (Map<String, Object> node : nodeList)
        {
            if (node != null && ToolUtilities.getBoolean(node.get("opmEnabled"), false))
                count++;
        }
        return count;
    }

    private double normalizeRatio(Object value)
    {
        if (value == null)
            return 0;
        double num = ToolUtilities.getDouble(value, 0);
        if (num > 1.00001)
            return num / 100;
        if (num < 0)
            return 0;
        return Math.min(num, 1.0);
    }

    // 计算网络IO使用率百分比（基于网络吞吐量）
    private double calculateNetIoUsage(OpmNetMetricDo netMetric)
    {
        if (netMetric == null)
            return 0;
        
        // 获取网络总吞吐量（Bps）
        Double netTotalRate = netMetric.totalRate;
        if (netTotalRate == null || netTotalRate <= 0)
            return 0;
        
        // 网络IO使用率计算逻辑：
        // 基于实际吞吐量与理论最大值的比例，但需要合理映射到0-100%范围
        // 这里使用对数缩放来处理大范围的网络带宽差异
        
        // 假设1Gbps (125MB/s = 125,000,000 Bps) 为高负载参考点
        double referenceBandwidth = 125000000.0; // 1Gbps in bytes per second
        
        // 计算相对使用率
        double relativeUsage = netTotalRate / referenceBandwidth;
        
        // 使用对数函数平滑大范围值
        double logUsage = Math.log10(1 + relativeUsage * 1000) / 3.0;
        
        // 限制在0-1范围内并转换为百分比
        return Math.min(Math.max(logUsage, 0), 1.0);
    }

    protected void handleCollectNow(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        String collectorKey = req.getParameter("collectorKey");
        if (ToolUtilities.isStringEmpty(collectorKey, true) && "POST".equalsIgnoreCase(req.getMethod()))
        {
            Map<String, Object> body = readBodyMap(req);
            if (body != null)
                collectorKey = ToolUtilities.getString(body.get("collectorKey"), null);
        }

        if (ToolUtilities.isStringEmpty(collectorKey, true))
            throw new Exception("collectorKey is empty");

        OpmCollectResult rs = OpmCenterServiceImpl.get().collectNow(collectorKey.trim());
        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("collectorKey", rs == null ? collectorKey : rs.collectorKey);
        data.put("collectorLabel", rs == null ? null : rs.collectorLabel);
        data.put("collectTime", rs == null ? System.currentTimeMillis() : rs.collectTime);
        data.put("status", rs == null ? 0 : rs.status);
        data.put("summary", rs == null ? null : rs.summary);
        success(resp, data);
    }

    protected void handleConfigSchema(HttpServletResponse resp) throws Exception
    {
        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("schema", OpmCenterServiceImpl.get().queryConfigSchema());
        success(resp, data);
    }

    protected void handleConfigLoad(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        OpmCenterServiceImpl intf = OpmCenterServiceImpl.get();
        String agentCode = resolveAgentCode(req, intf);

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("agentCode", agentCode);
        data.put("runtimeMeta", intf.queryRuntimeMeta());
        data.put("schema", intf.queryConfigSchema());
        data.put("configMap", intf.queryAgentConfigMap(agentCode));
        success(resp, data);
    }

    protected void handleConfigSave(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        Map<String, Object> body = readBodyMap(req);
        if (body == null)
            throw new Exception("request body is empty");

        OpmCenterServiceImpl intf = OpmCenterServiceImpl.get();
        String agentCode = ToolUtilities.getString(body.get("agentCode"), null);
        if (ToolUtilities.isStringEmpty(agentCode, true))
            agentCode = resolveAgentCode(req, intf);

        Map<String, String> mapCfg = convertMapCfg(body.get("configMap"));
        intf.saveAgentConfigMap(agentCode, mapCfg);

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("agentCode", agentCode);
        data.put("configMap", intf.queryAgentConfigMap(agentCode));
        success(resp, data);
    }

    protected void handleAgents(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        OpmCenterServiceImpl intf = OpmCenterServiceImpl.get();
        Map<String, Object> runtimeMeta = intf.queryRuntimeMeta();

        String selectedAgentCode = req.getParameter("agentCode");
        if (ToolUtilities.isStringEmpty(selectedAgentCode, true))
            selectedAgentCode = ToolUtilities.getString(runtimeMeta == null ? null : runtimeMeta.get("agentCode"), null);

        List<Map<String, Object>> agents = queryAgentList(intf);
        if (ToolUtilities.isStringEmpty(selectedAgentCode, true) && !agents.isEmpty())
            selectedAgentCode = ToolUtilities.getString(agents.get(0).get("agentCode"), null);

        String selectedAgentName = selectedAgentCode;
        boolean selectedAgentOpmEnabled = false;
        for (Map<String, Object> one : agents)
        {
            if (one == null)
                continue;

            String code = ToolUtilities.getString(one.get("agentCode"), null);
            if (!ToolUtilities.isStringEqual(code, selectedAgentCode, true))
                continue;

            selectedAgentName = ToolUtilities.getString(one.get("agentName"), selectedAgentCode);
            selectedAgentOpmEnabled = ToolUtilities.getBoolean(one.get("opmEnabled"), false);
            break;
        }

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("runtimeMeta", runtimeMeta);
        data.put("agents", agents);
        data.put("selectedAgentCode", selectedAgentCode);
        data.put("selectedAgentName", selectedAgentName);
        data.put("selectedAgentOpmEnabled", selectedAgentOpmEnabled);
        data.put("selectedAgentEditable", selectedAgentOpmEnabled);
        success(resp, data);
    }

    protected void handleAlarms(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        OpmCenterServiceImpl intf = OpmCenterServiceImpl.get();
        String agentCode = req.getParameter("agentCode");
        String levelParam = req.getParameter("level");
        String ackParam = req.getParameter("acknowledged");
        String keyword = req.getParameter("keyword");
        String sortBy = req.getParameter("sortBy");
        String sortOrder = req.getParameter("sortOrder");
        String needTotal = req.getParameter("needTotal");
        int limit = parseLimit(req.getParameter("limit"));
        int offset = ToolUtilities.getInteger(req.getParameter("offset"), 0);

        List<OpmAlarmRefDo> alarmList = new ArrayList<OpmAlarmRefDo>();
        List<Map<String, Object>> agentList = new ArrayList<Map<String, Object>>();
        int total = -1;

        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = null;

            if (!ToolUtilities.isStringEmpty(agentCode, true))
            {
                String agentCodeTrim = agentCode.trim();
                SqlExpressionGroup agentExp = new SqlExpressionGroup()
                        .or(OpmAlarmRefDo.AgentCode, "=", agentCodeTrim)
                        .or(OpmAlarmRefDo.AgentName, "=", agentCodeTrim);
                cnd = Cnd.where(agentExp).desc(OpmAlarmRefDo.AlarmTime);
            }

            if (!ToolUtilities.isStringEmpty(levelParam, true))
            {
                int level = ToolUtilities.getInteger(levelParam, -1);
                if (level >= 0)
                {
                    if (cnd == null)
                        cnd = Cnd.where(OpmAlarmRefDo.AlarmLevel, "=", level).desc(OpmAlarmRefDo.AlarmTime);
                    else
                        cnd.and(OpmAlarmRefDo.AlarmLevel, "=", level);
                }
            }

            if (!ToolUtilities.isStringEmpty(ackParam, true))
            {
                boolean ack = "true".equalsIgnoreCase(ackParam.trim());
                    if (cnd == null)
                        cnd = Cnd.where(OpmAlarmRefDo.Acknowledged, "=", ack).desc(OpmAlarmRefDo.AlarmTime);
                    else
                        cnd.and(OpmAlarmRefDo.Acknowledged, "=", ack);
            }

            if (!ToolUtilities.isStringEmpty(keyword, true))
            {
                String keywordTrim = keyword.trim();
                SqlExpressionGroup exp = new SqlExpressionGroup()
                        .or(OpmAlarmRefDo.Message, "like", "%" + keywordTrim + "%")
                        .or(OpmAlarmRefDo.AgentName, "like", "%" + keywordTrim + "%")
                        .or(OpmAlarmRefDo.AgentCode, "like", "%" + keywordTrim + "%")
                        .or(OpmAlarmRefDo.RuleLabel, "like", "%" + keywordTrim + "%")
                        .or(OpmAlarmRefDo.CollectorLabel, "like", "%" + keywordTrim + "%");
                if (cnd == null)
                    cnd = Cnd.where(exp);
                else
                    cnd.and(exp);
            }

            String sortField = OpmAlarmRefDo.AlarmTime;
            if ("level".equals(sortBy))
                sortField = OpmAlarmRefDo.AlarmLevel;
            else if ("agent".equals(sortBy))
                sortField = OpmAlarmRefDo.AgentName;

            if (cnd == null)
                cnd = Cnd.orderBy();

            if ("asc".equalsIgnoreCase(sortOrder))
                cnd.asc(sortField);
            else
                cnd.desc(sortField);

            boolean countAll = "true".equalsIgnoreCase(needTotal);
            CPager pager = new CPager(offset, limit, countAll);
            MultiPageResult<OpmAlarmRefDo> pageResult = dao.queryDoPage(OpmAlarmRefDo.class, cnd, pager);
            alarmList = pageResult.getListData();
            if (countAll)
                total = pageResult.getTotalCount();

            List<TsAgentDo> agentDoList = dao.queryDoList(TsAgentDo.class, null, TsAgentDo.Code, TsAgentDo.Name);
            if (agentDoList != null)
            {
                for (TsAgentDo agt : agentDoList)
                {
                    if (agt == null || ToolUtilities.isStringEmpty(agt.getCode(), true))
                        continue;
                    String code = agt.getCode().trim();
                    String name = ToolUtilities.isStringEmpty(agt.getName(), true) ? code : agt.getName().trim();
                    boolean exists = false;
                    for (Map<String, Object> item : agentList)
                    {
                        if (item == null)
                            continue;
                        String itemCode = ToolUtilities.getString(item.get("agentCode"), null);
                        if (ToolUtilities.isEqual(itemCode, code))
                        {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists)
                    {
                        LinkedHashMap<String, Object> item = new LinkedHashMap<String, Object>();
                        item.put("agentCode", code);
                        item.put("agentName", name);
                        agentList.add(item);
                    }
                }
            }
        }

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("alarms", mapAlarmList(alarmList, false));
        data.put("total", total);
        data.put("agents", agentList);
        success(resp, data);
    }

    protected void handleAlarmDetail(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        String alarmUuid = req.getParameter("alarmUuid");
        long alarmTime = ToolUtilities.getLong(req.getParameter("alarmTime"), 0L);
        OpmAlarmRefDo alarm = null;
        try (IDao dao = IDaoService.newIDao())
        {
            if (!ToolUtilities.isStringEmpty(alarmUuid, true))
                alarm = dao.queryDo(OpmAlarmRefDo.class, Cnd.where(OpmAlarmRefDo.AlarmUuid, "=", alarmUuid.trim()));
            if (alarm == null && alarmTime > 0)
                alarm = dao.queryDo(OpmAlarmRefDo.class, Cnd.where(OpmAlarmRefDo.AlarmTime, "=", Long.valueOf(alarmTime)).desc(OpmAlarmRefDo.AlarmTime));
        }

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("alarm", alarm == null ? null : mapAlarmDetail(alarm));
        success(resp, data);
    }

    protected void handleAlarmsAcknowledge(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        Map<String, Object> body = readBodyMap(req);
        if (body == null)
            throw new Exception("request body is empty");

        Object uuidsObj = body.get("alarmUuids");
        Object timesObj = body.get("alarmTimes");

        List<String> alarmUuids = new ArrayList<String>();
        if (uuidsObj instanceof List<?>)
        {
            for (Object obj : (List<?>) uuidsObj)
            {
                String uuid = obj == null ? null : obj.toString();
                if (!ToolUtilities.isStringEmpty(uuid, true))
                    alarmUuids.add(uuid.trim());
            }
        }

        List<Long> alarmTimes = new ArrayList<Long>();
        if (timesObj instanceof List<?>)
        {
            for (Object obj : (List<?>) timesObj)
            {
                if (obj instanceof Number)
                    alarmTimes.add(((Number) obj).longValue());
                else if (obj != null)
                {
                    long t = ToolUtilities.getLong(obj.toString(), 0L);
                    if (t > 0)
                        alarmTimes.add(t);
                }
            }
        }

        if (alarmUuids.isEmpty() && alarmTimes.isEmpty())
            throw new Exception("alarmUuids or alarmTimes is required");

        Object opmUserObj = req.getAttribute("opmUser");
        if (opmUserObj == null)
            throw new Exception("无法获取当前用户信息，请重新登录");

        OpmJwtUtil.OpmUserInfo opmUser = (OpmJwtUtil.OpmUserInfo) opmUserObj;
        String acknowledgeUser = opmUser.userCode;
        if (ToolUtilities.isStringEmpty(acknowledgeUser, true))
            throw new Exception("当前用户信息无效，请重新登录");

        long acknowledgeTime = System.currentTimeMillis();

        int count = 0;
        try (IDao dao = IDaoService.newIDao())
        {
            for (String alarmUuid : alarmUuids)
            {
                if (ToolUtilities.isStringEmpty(alarmUuid, true))
                    continue;

                Cnd cnd = Cnd.where(OpmAlarmRefDo.AlarmUuid, "=", alarmUuid);
                List<OpmAlarmRefDo> list = dao.queryDoList(OpmAlarmRefDo.class, cnd);
                if (list == null || list.isEmpty())
                    continue;

                for (OpmAlarmRefDo alarm : list)
                {
                    if (alarm == null)
                        continue;
                    if (Boolean.TRUE.equals(alarm.acknowledged))
                        continue;
                    alarm.setAcknowledged(true);
                    alarm.setAcknowledgeUser(acknowledgeUser);
                    alarm.setAcknowledgeTime(acknowledgeTime);
                    dao.updateDo(alarm);
                    count++;
                }
            }

            for (Long alarmTime : alarmTimes)
            {
                if (alarmTime == null || alarmTime <= 0)
                    continue;

                Cnd cnd = Cnd.where(OpmAlarmRefDo.AlarmTime, "=", alarmTime);
                List<OpmAlarmRefDo> list = dao.queryDoList(OpmAlarmRefDo.class, cnd);
                if (list == null || list.isEmpty())
                    continue;

                for (OpmAlarmRefDo alarm : list)
                {
                    if (alarm == null)
                        continue;
                    if (Boolean.TRUE.equals(alarm.acknowledged))
                        continue;
                    alarm.setAcknowledged(true);
                    alarm.setAcknowledgeUser(acknowledgeUser);
                    alarm.setAcknowledgeTime(acknowledgeTime);
                    dao.updateDo(alarm);
                    count++;
                }
            }
            dao.commit();
        }

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("success", true);
        data.put("count", count);
        success(resp, data);
    }

    protected void handleCollectList(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        String agentCode = req.getParameter("agentCode");
        String collectorKey = req.getParameter("collectorKey");
        String statusText = req.getParameter("status");
        String keyword = req.getParameter("keyword");
        String sortBy = req.getParameter("sortBy");
        String sortOrder = req.getParameter("sortOrder");
        String needTotal = req.getParameter("needTotal");
        int limit = parseLimit(req.getParameter("limit"));
        int offset = ToolUtilities.getInteger(req.getParameter("offset"), 0);

        List<Map<String, Object>> records = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> agents = new ArrayList<Map<String, Object>>();
        List<String> collectors = new ArrayList<String>();
        int total = -1;

        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = null;

            String agentCodeTrim = ToolUtilities.isStringEmpty(agentCode, true) ? null : agentCode.trim();
            String collectorKeyTrim = ToolUtilities.isStringEmpty(collectorKey, true) ? null : collectorKey.trim();
            String keywordTrim = ToolUtilities.isStringEmpty(keyword, true) ? null : keyword.trim();
            Integer status = ToolUtilities.isStringEmpty(statusText, true) ? null : Integer.valueOf(ToolUtilities.getInteger(statusText, -1));
            if (status != null && status.intValue() < 0)
                status = null;

            if (agentCodeTrim != null)
            {
                SqlExpressionGroup agentExp = new SqlExpressionGroup()
                        .or(bap.md.opm.OpmMetricMainDo.AgentCode, "=", agentCodeTrim)
                        .or(bap.md.opm.OpmMetricMainDo.AgentName, "=", agentCodeTrim);
                cnd = Cnd.where(agentExp);
            }

            if (collectorKeyTrim != null)
            {
                if (cnd == null)
                    cnd = Cnd.where(bap.md.opm.OpmMetricMainDo.CollectorKey, "=", collectorKeyTrim);
                else
                    cnd.and(bap.md.opm.OpmMetricMainDo.CollectorKey, "=", collectorKeyTrim);
            }

            if (status != null)
            {
                if (cnd == null)
                    cnd = Cnd.where(bap.md.opm.OpmMetricMainDo.Status, "=", status);
                else
                    cnd.and(bap.md.opm.OpmMetricMainDo.Status, "=", status);
            }

            if (keywordTrim != null)
            {
                SqlExpressionGroup exp = new SqlExpressionGroup()
                        .or(bap.md.opm.OpmMetricMainDo.Summary, "like", "%" + keywordTrim + "%")
                        .or(bap.md.opm.OpmMetricMainDo.CollectorLabel, "like", "%" + keywordTrim + "%")
                        .or(bap.md.opm.OpmMetricMainDo.CollectorKey, "like", "%" + keywordTrim + "%");
                if (cnd == null)
                    cnd = Cnd.where(exp);
                else
                    cnd.and(exp);
            }

            String sortField = bap.md.opm.OpmMetricMainDo.CollectTime;
            if ("time".equals(sortBy))
                sortField = bap.md.opm.OpmMetricMainDo.CollectTime;
            else if ("collector".equals(sortBy))
                sortField = bap.md.opm.OpmMetricMainDo.CollectorKey;
            else if ("agent".equals(sortBy))
                sortField = bap.md.opm.OpmMetricMainDo.AgentCode;
            else if ("status".equals(sortBy))
                sortField = bap.md.opm.OpmMetricMainDo.Status;
            else if ("cost".equals(sortBy))
                sortField = bap.md.opm.OpmMetricMainDo.CollectCostMs;
            else if ("cost".equals(sortBy))
                sortField = bap.md.opm.OpmMetricMainDo.CollectCostMs;

            if (cnd == null)
                cnd = Cnd.orderBy();
            
            if ("asc".equalsIgnoreCase(sortOrder))
                cnd.asc(sortField);
            else
                cnd.desc(sortField);

            boolean countAll = "true".equalsIgnoreCase(needTotal);
            CPager pager = new CPager(offset, limit, countAll);

            MultiPageResult<bap.md.opm.OpmMetricMainDo> pageResult =
                dao.queryDoPage(bap.md.opm.OpmMetricMainDo.class, cnd, pager);

            if (countAll)
                total = pageResult.getTotalCount();
            
            List<bap.md.opm.OpmMetricMainDo> mainList = pageResult.getListData();
            
            for (bap.md.opm.OpmMetricMainDo m : mainList)
            {
                Map<String, Object> record = new LinkedHashMap<String, Object>();
                record.put("collectTime", m.collectTime);
                record.put("collectorKey", m.collectorKey);
                record.put("collectorLabel", m.collectorLabel);
                record.put("agentCode", m.agentCode);
                record.put("agentName", m.agentName);
                record.put("collectCostMs", m.collectCostMs);
                record.put("status", m.status);
                record.put("alarmUuid", m.alarmUuid);
                record.put("summary", m.summary);
                record.put("statusDetail", normalizeDetailJsonForApi(m.statusDetail));

                records.add(record);

                if (!collectors.contains(m.collectorKey))
                    collectors.add(m.collectorKey);
            }

            List<TsAgentDo> agentDoList = dao.queryDoList(TsAgentDo.class, null, TsAgentDo.Code, TsAgentDo.Name);
            if (agentDoList != null)
            {
                for (TsAgentDo agt : agentDoList)
                {
                    if (agt == null || ToolUtilities.isStringEmpty(agt.getCode(), true))
                        continue;
                    String code = agt.getCode().trim();
                    String name = ToolUtilities.isStringEmpty(agt.getName(), true) ? code : agt.getName().trim();
                    boolean exists = false;
                    for (Map<String, Object> item : agents)
                    {
                        if (item == null)
                            continue;
                        String itemCode = ToolUtilities.getString(item.get("agentCode"), null);
                        if (ToolUtilities.isEqual(itemCode, code))
                        {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists)
                    {
                        LinkedHashMap<String, Object> item = new LinkedHashMap<String, Object>();
                        item.put("agentCode", code);
                        item.put("agentName", name);
                        agents.add(item);
                    }
                }
            }
        }

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("records", records);
        data.put("total", total);
        data.put("agents", agents);
        data.put("collectors", collectors);
        success(resp, data);
    }

    protected void handleCollectDetail(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        String collectorKey = req.getParameter("collectorKey");
        String agentCode = req.getParameter("agentCode");
        long collectTime = ToolUtilities.getLong(req.getParameter("collectTime"), 0L);
        if (ToolUtilities.isStringEmpty(collectorKey, true) || collectTime <= 0L)
            throw new Exception("collectorKey and collectTime are required");

        Map<String, Object> record = null;
        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = Cnd.where(bap.md.opm.OpmMetricMainDo.CollectorKey, "=", collectorKey.trim())
                    .and(bap.md.opm.OpmMetricMainDo.CollectTime, "=", Long.valueOf(collectTime));
            if (!ToolUtilities.isStringEmpty(agentCode, true))
                cnd.and(bap.md.opm.OpmMetricMainDo.AgentCode, "=", agentCode.trim());
            bap.md.opm.OpmMetricMainDo m = dao.queryDo(bap.md.opm.OpmMetricMainDo.class, cnd);
            if (m != null)
            {
                record = new LinkedHashMap<String, Object>();
                record.put("collectTime", m.collectTime);
                record.put("collectorKey", m.collectorKey);
                record.put("collectorLabel", m.collectorLabel);
                record.put("agentCode", m.agentCode);
                record.put("agentName", m.agentName);
                record.put("collectCostMs", m.collectCostMs);
                record.put("status", m.status);
                record.put("alarmUuid", m.alarmUuid);
                record.put("summary", m.summary);
                record.put("statusDetail", normalizeDetailJsonForApi(m.statusDetail));
                record.put("detailJson", queryMetricDetailJson(dao, m));
              }
        }

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("record", record);
        success(resp, data);
    }

    protected void handleCollectSummary(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        String agentCode = req.getParameter("agentCode");

        int totalRecords = 0;
        int normalCount = 0;
        int alarmCount = 0;
        int suppressedCount = 0;
        int errorCount = 0;

        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = null;
            if (!ToolUtilities.isStringEmpty(agentCode, true))
                cnd = Cnd.where(bap.md.opm.OpmMetricMainDo.AgentCode, "=", agentCode.trim());

            List<bap.md.opm.OpmMetricMainDo> mainList = dao.queryDoList(
                    bap.md.opm.OpmMetricMainDo.class,
                    cnd,
                    bap.md.opm.OpmMetricMainDo.Status);

            for (bap.md.opm.OpmMetricMainDo m : mainList)
            {
                totalRecords++;

                if (m.status == null || m.status.intValue() == bap.opm.OpmConst.STATUS_NORMAL)
                    normalCount++;
                else if (m.status.intValue() == bap.opm.OpmConst.STATUS_ALARM)
                    alarmCount++;
                else if (m.status.intValue() == bap.opm.OpmConst.STATUS_SUPPRESSED)
                    suppressedCount++;
                else
                    errorCount++;
            }
        }

        LinkedHashMap<String, Object> statusDist = new LinkedHashMap<String, Object>();
        statusDist.put("normal", normalCount);
        statusDist.put("alarm", alarmCount);
        statusDist.put("suppressed", suppressedCount);
        statusDist.put("error", errorCount);

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("totalRecords", totalRecords);
        data.put("statusDistribution", statusDist);
        success(resp, data);
    }

    protected Map<String, Object> mapSysRecord(OpmSysMetricDo m, String key, String label)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("collectTime", m.collectTime);
        map.put("collectorKey", key);
        map.put("collectorLabel", label);
        map.put("agentCode", m.agentCode);
        map.put("agentName", m.agentName);
        map.put("status", 0);
        map.put("summary", m.summary);
        map.put("detailJson", m.detailJson);
        return map;
    }

    protected Map<String, Object> mapCpuRecord(OpmCpuMetricDo m, String key, String label)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("collectTime", m.collectTime);
        map.put("collectorKey", key);
        map.put("collectorLabel", label);
        map.put("agentCode", m.agentCode);
        map.put("agentName", m.agentName);
        map.put("status", 0);
        map.put("summary", "CPU: " + String.format("%.1f%%", (m.cpuUsageRate != null ? m.cpuUsageRate : 0) * 100));
        map.put("detailJson", m.detailJson);
        return map;
    }

    protected Map<String, Object> mapMemoryRecord(OpmMemoryMetricDo m, String key, String label)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("collectTime", m.collectTime);
        map.put("collectorKey", key);
        map.put("collectorLabel", label);
        map.put("agentCode", m.agentCode);
        map.put("agentName", m.agentName);
        map.put("status", 0);
        map.put("summary", m.summary);
        map.put("detailJson", m.detailJson);
        return map;
    }

    protected Map<String, Object> mapDiskRecord(OpmDiskMetricDo m, String key, String label)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("collectTime", m.collectTime);
        map.put("collectorKey", key);
        map.put("collectorLabel", label);
        map.put("agentCode", m.agentCode);
        map.put("agentName", m.agentName);
        map.put("status", 0);
        map.put("summary", "磁盘: " + String.format("%.1f%%", (m.totalUsageRate != null ? m.totalUsageRate : 0) * 100));
        map.put("detailJson", m.detailJson);
        return map;
    }

    protected Map<String, Object> mapIoRecord(OpmIoMetricDo m, String key, String label)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("collectTime", m.collectTime);
        map.put("collectorKey", key);
        map.put("collectorLabel", label);
        map.put("agentCode", m.agentCode);
        map.put("agentName", m.agentName);
        map.put("status", 0);
        map.put("summary", m.summary);
        map.put("detailJson", m.detailJson);
        return map;
    }

    protected Map<String, Object> mapNetRecord(OpmNetMetricDo m, String key, String label)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("collectTime", m.collectTime);
        map.put("collectorKey", key);
        map.put("collectorLabel", label);
        map.put("agentCode", m.agentCode);
        map.put("agentName", m.agentName);
        map.put("status", 0);
        map.put("summary", m.summary);
        map.put("detailJson", m.detailJson);
        return map;
    }

    protected Map<String, Object> mapPgRecord(OpmPgMetricDo m, String key, String label)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("collectTime", m.collectTime);
        map.put("collectorKey", key);
        map.put("collectorLabel", label);
        map.put("agentCode", m.agentCode);
        map.put("agentName", m.agentName);
        map.put("status", 0);
        map.put("summary", m.summary);
        map.put("detailJson", m.detailJson);
        return map;
    }

    protected List<Map<String, Object>> queryAgentList(OpmCenterServiceImpl intf) throws Exception
    {
        List<TsAgentDo> list;
        try (IDao dao = IDaoService.newIDao())
        {
            list = dao.queryDoList(TsAgentDo.class, null,
                    TsAgentDo.Code,
                    TsAgentDo.Name,
                    TsAgentDo.LastReportTime,
                    TsAgentDo.StarterConf);
        }

        ArrayList<TsAgentDo> arr = new ArrayList<TsAgentDo>();
        if (list != null)
            arr.addAll(list);

        Collections.sort(arr, new Comparator<TsAgentDo>()
        {
            @Override
            public int compare(TsAgentDo o1, TsAgentDo o2)
            {
                long t1 = o1 == null || o1.getLastReportTime() == null ? -1L : o1.getLastReportTime().longValue();
                long t2 = o2 == null || o2.getLastReportTime() == null ? -1L : o2.getLastReportTime().longValue();
                int cmp = Long.compare(t2, t1);
                if (cmp != 0)
                    return cmp;

                String c1 = ToolUtilities.getString(o1 == null ? null : o1.getCode(), "");
                String c2 = ToolUtilities.getString(o2 == null ? null : o2.getCode(), "");
                return c1.compareToIgnoreCase(c2);
            }
        });

        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        for (TsAgentDo one : arr)
        {
            if (one == null)
                continue;

            String code = ToolUtilities.getString(one.getCode(), null);
            if (ToolUtilities.isStringEmpty(code, true))
                continue;

            boolean opmEnabled = false;
            try
            {
                opmEnabled = intf.isAgentOpmEditable(code);
            }
            catch (Throwable err)
            {
                opmEnabled = false;
            }

            String name = ToolUtilities.getString(one.getName(), null);
            if (ToolUtilities.isStringEmpty(name, true))
                name = code;

            LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("agentCode", code);
            m.put("agentName", name);
            m.put("myUri", one.getMyUri());
            m.put("lastReportTime", one.getLastReportTime());
            m.put("opmEnabled", opmEnabled);
            m.put("editable", opmEnabled);
            ret.add(m);
        }
        return ret;
    }

    protected String queryAgentName(String agentCode)
    {
        String code = agentCode == null ? null : agentCode.trim();
        if (ToolUtilities.isStringEmpty(code, true))
            return code;

        try (IDao dao = IDaoService.newIDao())
        {
            TsAgentDo agt = dao.queryDo(TsAgentDo.class,
                    Cnd.where(TsAgentDo.Code, "=", code),
                    TsAgentDo.Code,
                    TsAgentDo.Name);
            if (agt == null)
                return code;

            String name = ToolUtilities.getString(agt.getName(), null);
            if (ToolUtilities.isStringEmpty(name, true))
                name = ToolUtilities.getString(agt.getCode(), code);
            return name;
        }
        catch (Throwable err)
        {
            return code;
        }
    }

    protected <T> List<T> queryLatestByAgent(Class<T> cls, String agentField, String orderField, String agentCode, int limit)
            throws Exception
    {
        String code = agentCode == null ? null : agentCode.trim();
        if (ToolUtilities.isStringEmpty(code, true))
            return new ArrayList<T>();

        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = Cnd.where(agentField, "=", code);
            cnd.desc(orderField);
            List<T> list = dao.queryDoPage(cls, cnd, new CPager(0, Math.max(1, limit))).getListData();
            return list == null ? new ArrayList<T>() : list;
        }
    }

    protected String resolveAgentCode(HttpServletRequest req, OpmCenterServiceImpl intf) throws Exception
    {
        String agentCode = req.getParameter("agentCode");
        if (!ToolUtilities.isStringEmpty(agentCode, true))
            return agentCode.trim();

        Map<String, Object> runtime = intf.queryRuntimeMeta();
        agentCode = ToolUtilities.getString(runtime == null ? null : runtime.get("agentCode"), null);
        if (ToolUtilities.isStringEmpty(agentCode, true))
            throw new Exception("Can not resolve runtime agentCode");
        return agentCode;
    }

    protected Map<String, String> convertMapCfg(Object value)
    {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        if (!(value instanceof Map<?, ?>))
            return map;

        Map<?, ?> src = (Map<?, ?>) value;
        for (Entry<?, ?> one : src.entrySet())
        {
            if (one == null)
                continue;

            String key = ToolUtilities.getString(one.getKey(), null);
            if (ToolUtilities.isStringEmpty(key, true))
                continue;

            String val = ToolUtilities.getString(one.getValue(), null);
            if (val == null)
                val = "";

            map.put(key, val);
        }
        return map;
    }

    protected int parseLimit(String text)
    {
        int defaultLimit = MppContext.getInt(OpmConst.CONF_WEB_DASHBOARD_LIMIT, OpmConst.DEFAULT_WEB_DASHBOARD_LIMIT);
        int one = ToolUtilities.getInteger(text, defaultLimit);
        if (one < LIMIT_MIN)
            one = LIMIT_MIN;
        if (one > LIMIT_MAX)
            one = LIMIT_MAX;
        return one;
    }

    protected List<Map<String, Object>> mapSysList(List<OpmSysMetricDo> list, boolean summaryOnly)
    {
        ArrayList<Map<String, Object>> rs = new ArrayList<Map<String, Object>>();
        if (list == null)
            return rs;

        for (OpmSysMetricDo one : list)
        {
            if (one == null)
                continue;

            LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("collectTime", one.collectTime);
            m.put("cpuUsageRate", one.cpuUsageRate);
            m.put("memUsageRate", one.memUsageRate);
            m.put("diskMaxUsageRate", one.diskMaxUsageRate);
            m.put("diskCount", one.diskCount);
            m.put("netRxRate", one.netRxRate);
            m.put("netTxRate", one.netTxRate);
            m.put("netTotalRate", one.netTotalRate);
            m.put("summary", one.summary);
            if (!summaryOnly || rs.isEmpty())
                m.put("detailJson", one.detailJson);
            rs.add(m);
        }
        return rs;
    }

    protected List<Map<String, Object>> mapCpuList(List<OpmCpuMetricDo> list, boolean summaryOnly)
    {
        ArrayList<Map<String, Object>> rs = new ArrayList<Map<String, Object>>();
        if (list == null)
            return rs;

        for (OpmCpuMetricDo one : list)
        {
            if (one == null)
                continue;

            LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("collectTime", one.collectTime);
            m.put("cpuUsageRate", one.cpuUsageRate);
            m.put("userRate", one.userRate);
            m.put("systemRate", one.systemRate);
            m.put("idleRate", one.idleRate);
            m.put("topProcCount", one.topProcCount);
            m.put("topProcName", one.topProcName);
            m.put("topProcCpuRate", one.topProcCpuRate);
            m.put("summary", one.summary);
            if (!summaryOnly || rs.isEmpty())
                m.put("detailJson", one.detailJson);
            rs.add(m);
        }
        return rs;
    }

    protected List<Map<String, Object>> mapMemoryList(List<OpmMemoryMetricDo> list, boolean summaryOnly)
    {
        ArrayList<Map<String, Object>> rs = new ArrayList<Map<String, Object>>();
        if (list == null)
            return rs;

        for (OpmMemoryMetricDo one : list)
        {
            if (one == null)
                continue;

            LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("collectTime", one.collectTime);
            m.put("usageRate", one.usageRate);
            m.put("usedBytes", one.usedBytes);
            m.put("freeBytes", one.freeBytes);
            m.put("totalBytes", one.totalBytes);
            m.put("swapUsageRate", one.swapUsageRate);
            m.put("swapUsedBytes", one.swapUsedBytes);
            m.put("swapFreeBytes", one.swapFreeBytes);
            m.put("summary", one.summary);
            if (!summaryOnly || rs.isEmpty())
                m.put("detailJson", one.detailJson);
            rs.add(m);
        }
        return rs;
    }

    protected List<Map<String, Object>> mapDiskList(List<OpmDiskMetricDo> list, boolean summaryOnly)
    {
        ArrayList<Map<String, Object>> rs = new ArrayList<Map<String, Object>>();
        if (list == null)
            return rs;

        for (OpmDiskMetricDo one : list)
        {
            if (one == null)
                continue;

            LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("collectTime", one.collectTime);
            m.put("diskCount", one.diskCount);
            m.put("totalBytes", one.totalBytes);
            m.put("totalUsedBytes", one.totalUsedBytes);
            m.put("totalFreeBytes", one.totalFreeBytes);
            m.put("totalUsageRate", one.totalUsageRate);
            m.put("maxUsageRate", one.maxUsageRate);
            m.put("maxUsageMount", one.maxUsageMount);
            m.put("summary", one.summary);
            if (!summaryOnly || rs.isEmpty())
                m.put("detailJson", one.detailJson);
            rs.add(m);
        }
        return rs;
    }

    protected List<Map<String, Object>> mapIoList(List<OpmIoMetricDo> list, boolean summaryOnly)
    {
        ArrayList<Map<String, Object>> rs = new ArrayList<Map<String, Object>>();
        if (list == null)
            return rs;

        for (OpmIoMetricDo one : list)
        {
            if (one == null)
                continue;

            LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("collectTime", one.collectTime);
            m.put("sampleMillis", one.sampleMillis);
            m.put("topProcCount", one.topProcCount);
            m.put("topProcName", one.topProcName);
            m.put("topProcReadRate", one.topProcReadRate);
            m.put("topProcWriteRate", one.topProcWriteRate);
            m.put("summary", one.summary);
            if (!summaryOnly || rs.isEmpty())
                m.put("detailJson", one.detailJson);
            rs.add(m);
        }
        return rs;
    }

    protected List<Map<String, Object>> mapNetList(List<OpmNetMetricDo> list, boolean summaryOnly)
    {
        ArrayList<Map<String, Object>> rs = new ArrayList<Map<String, Object>>();
        if (list == null)
            return rs;

        for (OpmNetMetricDo one : list)
        {
            if (one == null)
                continue;

            LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("collectTime", one.collectTime);
            m.put("sampleMillis", one.sampleMillis);
            m.put("totalRxBytes", one.totalRxBytes);
            m.put("totalTxBytes", one.totalTxBytes);
            m.put("rxRate", one.rxRate);
            m.put("txRate", one.txRate);
            m.put("totalRate", one.totalRate);
            m.put("summary", one.summary);
            if (!summaryOnly || rs.isEmpty())
                m.put("detailJson", one.detailJson);
            rs.add(m);
        }
        return rs;
    }

    protected List<Map<String, Object>> mapPgList(List<OpmPgMetricDo> list, boolean summaryOnly)
    {
        ArrayList<Map<String, Object>> rs = new ArrayList<Map<String, Object>>();
        if (list == null)
            return rs;

        for (OpmPgMetricDo one : list)
        {
            if (one == null)
                continue;

            LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("collectTime", one.collectTime);
            m.put("dbName", one.dbName);
            m.put("longSqlCount", one.longSqlCount);
            m.put("maxSqlDurationSec", one.maxSqlDurationSec);
            m.put("blockedSqlCount", one.blockedSqlCount);
            m.put("dbSizeBytes", one.dbSizeBytes);
            m.put("tablespaceUsageRate", one.tablespaceUsageRate);
            m.put("growthRateBytesPerHour", one.growthRateBytesPerHour);
            m.put("lockWaitCount", one.lockWaitCount);
            m.put("maxLockWaitSec", one.maxLockWaitSec);
            m.put("longLockCount", one.longLockCount);
            m.put("maxLongLockSec", one.maxLongLockSec);
            m.put("deadlockCount", one.deadlockCount);
            m.put("deadlockDeltaCount", one.deadlockDeltaCount);
            m.put("totalConnCount", one.totalConnCount);
            m.put("activeConnCount", one.activeConnCount);
            m.put("idleConnCount", one.idleConnCount);
            m.put("idleInTxnConnCount", one.idleInTxnConnCount);
            m.put("maxConnLimit", one.maxConnLimit);
            m.put("connUsageRate", one.connUsageRate);
            m.put("txnCommitCount", one.txnCommitCount);
            m.put("txnRollbackCount", one.txnRollbackCount);
            m.put("replicationRole", one.replicationRole);
            m.put("replicationLagSec", one.replicationLagSec);
            m.put("replicationState", one.replicationState);
            m.put("replicationConnCount", one.replicationConnCount);
            if (!summaryOnly || rs.isEmpty())
                m.put("detailJson", normalizeDetailJsonForApi(one.detailJson));
            rs.add(m);
        }
        return rs;
    }

    protected List<Map<String, Object>> mapAlarmList(List<OpmAlarmRefDo> list, boolean withDetail)
    {
        ArrayList<Map<String, Object>> rs = new ArrayList<Map<String, Object>>();
        if (list == null)
            return rs;

        for (OpmAlarmRefDo one : list)
        {
            if (one == null)
                continue;

            LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("alarmUuid", one.alarmUuid);
            m.put("alarmTime", one.alarmTime);
            m.put("alarmLevel", one.alarmLevel);
            m.put("collectorKey", one.collectorKey);
            m.put("collectorLabel", one.collectorLabel);
            m.put("ruleKey", one.ruleKey);
            m.put("ruleLabel", one.ruleLabel);
            m.put("configParamKey", normalizeAlarmConfigParamKey(one));
            m.put("agentCode", one.agentCode);
            m.put("agentName", one.agentName);
            m.put("message", one.message);
            if (withDetail)
                m.put("detailJson", normalizeDetailJsonForApi(one.detailJson));
            m.put("acknowledged", one.acknowledged);
            m.put("acknowledgeUser", one.acknowledgeUser);
            m.put("acknowledgeTime", one.acknowledgeTime);
            rs.add(m);
        }
        return rs;
    }

    protected List<OpmAlarmRefDo> filterDashboardAlarms(List<OpmAlarmRefDo> list)
    {
        ArrayList<OpmAlarmRefDo> ret = new ArrayList<OpmAlarmRefDo>();
        if (list == null)
            return ret;
        for (OpmAlarmRefDo one : list)
        {
            if (one == null)
                continue;
            if (Boolean.TRUE.equals(one.acknowledged))
                continue;
            ret.add(one);
            if (ret.size() >= DASHBOARD_ALARM_LIMIT)
                break;
        }
        return ret;
    }

    protected Map<String, Object> mapAlarmDetail(OpmAlarmRefDo one)
    {
        if (one == null)
            return null;
        LinkedHashMap<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("alarmUuid", one.alarmUuid);
        m.put("alarmTime", one.alarmTime);
        m.put("alarmLevel", one.alarmLevel);
        m.put("collectorKey", one.collectorKey);
        m.put("collectorLabel", one.collectorLabel);
        m.put("ruleKey", one.ruleKey);
        m.put("ruleLabel", one.ruleLabel);
        m.put("configParamKey", normalizeAlarmConfigParamKey(one));
        m.put("agentCode", one.agentCode);
        m.put("agentName", one.agentName);
        m.put("message", one.message);
        m.put("detailJson", normalizeDetailJsonForApi(one.detailJson));
        m.put("acknowledged", one.acknowledged);
        m.put("acknowledgeUser", one.acknowledgeUser);
        m.put("acknowledgeTime", one.acknowledgeTime);
        return m;
    }

    protected String normalizeAlarmConfigParamKey(OpmAlarmRefDo one)
    {
        if (one == null)
            return null;
        return bap.opm.registry.OpmConfigRegistry.getInstance().normalizeConfigParamKey(
                one.collectorKey, one.ruleKey, one.alarmLevel, one.configParamKey);
    }

    protected String queryMetricDetailJson(IDao dao, OpmMetricMainDo main)
    {
        if (dao == null || main == null)
            return null;
        if (ToolUtilities.isStringEmpty(main.metricClass, true) || ToolUtilities.isStringEmpty(main.metricUuid, true))
            return null;

        try
        {
            CDo ext = dao.queryDo(main.metricClass, Cnd.where(CDoBasic.UUID, "=", main.metricUuid), "detailJson");
            if (ext == null)
                return null;
            return normalizeDetailJsonForApi(ToolUtilities.getString(ext.get("detailJson"), null));
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG,
                    "[opm.web.metric.detail.error] uuid=" + main.metricUuid + ", class=" + main.metricClass,
                    err);
            return null;
        }
    }

    protected String normalizeDetailJsonForApi(String detailJson)
    {
        if (ToolUtilities.isStringEmpty(detailJson, true))
            return detailJson;

        try
        {
            Object obj = CJson.fromJson(detailJson);
            Object normalized = normalizeCJsonObject(obj);
            if (normalized != null)
                return GsonUtil.toPrettyJson(normalized);
        }
        catch (Throwable ignore)
        {
        }

        try
        {
            Object obj = GsonUtil.fromJson(detailJson, Object.class);
            if (obj != null)
                return GsonUtil.toPrettyJson(obj);
        }
        catch (Throwable ignore)
        {
        }
        return detailJson;
    }

    @SuppressWarnings("unchecked")
    protected Object normalizeCJsonObject(Object obj)
    {
        if (obj == null)
            return null;

        if (obj instanceof Map)
        {
            Map<Object, Object> map = (Map<Object, Object>) obj;

            if (map.containsKey("#O"))
                return normalizeCJsonObject(map.get("#O"));

            if (map.containsKey("#M"))
            {
                Object items = map.get("#M");
                if (items instanceof List)
                {
                    LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
                    for (Object one : (List<Object>) items)
                    {
                        if (!(one instanceof Map))
                            continue;

                        Map<Object, Object> ent = (Map<Object, Object>) one;
                        String k = ToolUtilities.getString(ent.get("$"), null);
                        if (ToolUtilities.isStringEmpty(k, true))
                            continue;
                        ret.put(k, normalizeCJsonObject(ent.get("^")));
                    }
                    return ret;
                }
            }

            if (map.containsKey("#L"))
            {
                Object arr = map.get("#L");
                if (arr instanceof List)
                {
                    ArrayList<Object> ret = new ArrayList<Object>();
                    for (Object one : (List<Object>) arr)
                        ret.add(normalizeCJsonObject(one));
                    return ret;
                }
            }

            if (map.containsKey("@") || map.containsKey("@A"))
                return null;

            LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
            for (Entry<Object, Object> ent : map.entrySet())
            {
                String k = String.valueOf(ent.getKey());
                if (k.startsWith("#"))
                    continue;
                ret.put(k, normalizeCJsonObject(ent.getValue()));
            }
            return ret;
        }

        if (obj instanceof List)
        {
            ArrayList<Object> ret = new ArrayList<Object>();
            for (Object one : (List<Object>) obj)
                ret.add(normalizeCJsonObject(one));
            return ret;
        }

        return obj;
    }

    protected Map<String, Object> readBodyMap(HttpServletRequest req)
    {
        try
        {
            String body = readBody(req);
            if (ToolUtilities.isStringEmpty(body, true))
                return null;
            Type type = new TypeToken<Map<String, Object>>()
            {
            }.getType();
            return GsonUtil.fromJson(body, type);
        }
        catch (Throwable err)
        {
            return null;
        }
    }

    protected String readBody(HttpServletRequest req) throws IOException
    {
        StringBuilder sb = new StringBuilder(256);
        String line;
        BufferedReader reader = req.getReader();
        while ((line = reader.readLine()) != null)
            sb.append(line);
        return sb.toString();
    }

    protected void success(HttpServletResponse resp, Object data) throws IOException
    {
        LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
        ret.put("success", true);
        ret.put("data", data);
        writeJson(resp, ret);
    }

    protected void error(HttpServletResponse resp, String message) throws IOException
    {
        LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
        ret.put("success", false);
        ret.put("message", message);
        writeJson(resp, ret);
    }

    protected void writeJson(HttpServletResponse resp, Object data) throws IOException
    {
        resp.setStatus(200);
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");

        PrintWriter writer = resp.getWriter();
        writer.write(GsonUtil.toJson(data));
        writer.flush();
    }
}
