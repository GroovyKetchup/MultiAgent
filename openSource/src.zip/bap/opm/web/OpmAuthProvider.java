package bap.opm.web;

import javax.servlet.http.HttpServletRequest;

import bap.auth.AuthModuleConfig;
import bap.auth.AuthTokenHelper;
import bap.auth.IAuthProvider;

public class OpmAuthProvider implements IAuthProvider
{
    public static final String TOKEN_COOKIE_NAME = "opm_token";
    public static final String REQ_ATTR_USER = "opmUser";
    public static final String REQ_ATTR_USER_CODE = "opmUserCode";

    @Override
    public String extractToken(HttpServletRequest req, AuthModuleConfig moduleConfig)
    {
        return AuthTokenHelper.extractToken(req, TOKEN_COOKIE_NAME);
    }

    @Override
    public Object authenticate(String token, AuthModuleConfig moduleConfig) throws Exception
    {
        return OpmJwtUtil.parseToken(token);
    }

    @Override
    public void bindAuthContext(HttpServletRequest req, Object authResult, AuthModuleConfig moduleConfig) throws Exception
    {
        if (!(authResult instanceof OpmJwtUtil.OpmUserInfo))
            return;

        OpmJwtUtil.OpmUserInfo user = (OpmJwtUtil.OpmUserInfo) authResult;
        req.setAttribute(REQ_ATTR_USER, user);
        req.setAttribute(REQ_ATTR_USER_CODE, user.userCode);
    }
}
