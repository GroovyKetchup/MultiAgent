package bap.opm.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdao.model.CDoUser;
import com.leavay.common.util.GsonUtil;
import com.leavay.common.util.ToolUtilities;

import bap.opm.OpmConst;
import cell.cdao.IDao;
import cell.cdao.IDaoService;

public class OpmAuthServlet extends HttpServlet
{
    private static final long serialVersionUID = 1L;

    public static final String SERVLET_CONTEXT_PATH = "/api/opm/auth/*";

    protected static final String ACTION_LOGIN = "login";
    protected static final String ACTION_LOGOUT = "logout";
    protected static final String ACTION_CHECK = "check";
    protected static final String ACTION_REFRESH = "refresh";
    protected static final String ACTION_USER_INFO = "userInfo";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        processRequest(req, resp);
    }

    protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        String pathInfo = req.getPathInfo();
        String action = normalizeAction(pathInfo);

        try
        {
            if (ACTION_LOGIN.equals(action))
            {
                handleLogin(req, resp);
                return;
            }

            if (ACTION_LOGOUT.equals(action))
            {
                handleLogout(req, resp);
                return;
            }

            if (ACTION_CHECK.equals(action))
            {
                handleCheck(req, resp);
                return;
            }

            if (ACTION_REFRESH.equals(action))
            {
                handleRefresh(req, resp);
                return;
            }

            if (ACTION_USER_INFO.equals(action))
            {
                handleUserInfo(req, resp);
                return;
            }

            error(resp, "Unknown action: " + action);
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "[opm.auth.error] action=" + action + ", message=" + err.getMessage(), err);
            error(resp, err.getMessage());
        }
    }

    protected String normalizeAction(String pathInfo)
    {
        if (ToolUtilities.isStringEmpty(pathInfo, true) || "/".equals(pathInfo))
            return ACTION_CHECK;

        String action = pathInfo.substring(1);
        if (ToolUtilities.isStringEmpty(action, true))
            return ACTION_CHECK;

        return action.trim();
    }

    protected void handleLogin(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        String body = readBody(req);
        if (ToolUtilities.isStringEmpty(body, true))
            throw new Exception("request body is empty");

        @SuppressWarnings("unchecked")
        java.util.Map<String, Object> bodyMap = GsonUtil.fromJson(body, java.util.Map.class);
        if (bodyMap == null)
            throw new Exception("invalid request body");

        String userName = ToolUtilities.getString(bodyMap.get("userName"), null);
        String password = ToolUtilities.getString(bodyMap.get("password"), null);
        Long expireMinutes = getLongValue(bodyMap.get("expireMinutes"));

        if (ToolUtilities.isStringEmpty(userName, true))
            throw new Exception("userName is required");
        if (ToolUtilities.isStringEmpty(password, true))
            throw new Exception("password is required");

        if (expireMinutes == null || expireMinutes <= 0)
            expireMinutes = OpmJwtUtil.DEFAULT_EXPIRE_MINUTES;
        if (expireMinutes > OpmJwtUtil.MAX_EXPIRE_MINUTES)
            expireMinutes = OpmJwtUtil.MAX_EXPIRE_MINUTES;

        CDoUser user = null;
        try (IDao dao = IDaoService.newIDao())
        {
            user = dao.queryDo(CDoUser.class,
                    org.nutz.dao.Cnd.where(CDoUser.Code, "=", userName.trim()));
        }

        if (user == null)
            throw new Exception("用户名或密码错误");

        String dbPwd = user.getPasswd() == null ? null : user.getPasswd().getPassword();
        if (!ToolUtilities.isStringEqual(password, dbPwd))
            throw new Exception("用户名或密码错误");

        String token = OpmJwtUtil.generateToken(
                user.getCode(),
                user.getUserName(),
                user.getAlias(),
                expireMinutes);

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("token", token);
        data.put("userCode", user.getCode());
        data.put("userName", user.getUserName());
        data.put("alias", user.getAlias());
        data.put("expireMinutes", expireMinutes);

        success(resp, data);
    }

    protected void handleLogout(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        success(resp, new LinkedHashMap<String, Object>());
    }

    protected void handleCheck(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        String token = extractToken(req);
        boolean valid = OpmJwtUtil.validateToken(token);

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("authenticated", valid);

        success(resp, data);
    }

    protected void handleRefresh(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        String token = extractToken(req);
        OpmJwtUtil.OpmUserInfo user = OpmJwtUtil.parseToken(token);

        if (user == null)
            throw new Exception("登录已过期，请重新登录");

        Long expireMinutes = user.expireTime > 0
                ? (user.expireTime - System.currentTimeMillis()) / (60 * 1000)
                : OpmJwtUtil.DEFAULT_EXPIRE_MINUTES;
        if (expireMinutes <= 0)
            expireMinutes = OpmJwtUtil.DEFAULT_EXPIRE_MINUTES;
        if (expireMinutes > OpmJwtUtil.MAX_EXPIRE_MINUTES)
            expireMinutes = OpmJwtUtil.MAX_EXPIRE_MINUTES;

        String newToken = OpmJwtUtil.generateToken(user.userCode, user.userName, user.alias, expireMinutes);

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("token", newToken);
        data.put("userCode", user.userCode);
        data.put("userName", user.userName);
        data.put("alias", user.alias);
        data.put("expireMinutes", expireMinutes);

        success(resp, data);
    }

    protected void handleUserInfo(HttpServletRequest req, HttpServletResponse resp) throws Exception
    {
        String token = extractToken(req);
        OpmJwtUtil.OpmUserInfo user = OpmJwtUtil.parseToken(token);

        if (user == null)
            throw new Exception("invalid token");

        LinkedHashMap<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("userCode", user.userCode);
        data.put("userName", user.userName);
        data.put("alias", user.alias);

        success(resp, data);
    }

    protected String extractToken(HttpServletRequest req)
    {
        String authHeader = req.getHeader("Authorization");
        if (!ToolUtilities.isStringEmpty(authHeader, true) && authHeader.startsWith("Bearer "))
        {
            return authHeader.substring(7);
        }

        String tokenParam = req.getParameter("token");
        if (!ToolUtilities.isStringEmpty(tokenParam, true))
        {
            return tokenParam.trim();
        }

        return null;
    }

    protected String readBody(HttpServletRequest req) throws IOException
    {
        StringBuilder sb = new StringBuilder(256);
        String line;
        java.io.BufferedReader reader = req.getReader();
        while ((line = reader.readLine()) != null)
            sb.append(line);
        return sb.toString();
    }

    protected void success(HttpServletResponse resp, Object data) throws IOException
    {
        LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
        ret.put("success", true);
        ret.put("data", data);
        writeJson(resp, ret);
    }

    protected void error(HttpServletResponse resp, String message) throws IOException
    {
        LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
        ret.put("success", false);
        ret.put("message", message);
        writeJson(resp, ret);
    }

    protected void writeJson(HttpServletResponse resp, Object data) throws IOException
    {
        resp.setStatus(200);
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");

        PrintWriter writer = resp.getWriter();
        writer.write(GsonUtil.toJson(data));
        writer.flush();
    }

    protected Long getLongValue(Object value)
    {
        if (value == null)
            return null;
        if (value instanceof Number)
            return ((Number) value).longValue();
        try
        {
            return Long.parseLong(value.toString());
        }
        catch (Exception e)
        {
            return null;
        }
    }
}