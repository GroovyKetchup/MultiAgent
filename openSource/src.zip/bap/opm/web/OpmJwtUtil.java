package bap.opm.web;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.leavay.common.util.GsonUtil;
import com.leavay.common.util.ToolUtilities;

public class OpmJwtUtil
{
    private static final String JWT_SECRET = "OPM_JWT_SECRET_KEY_2024_BAP_PLATFORM_SECURE_KEY_32BYTES";
    private static final String HMAC_SHA256 = "HmacSHA256";
    public static final long DEFAULT_EXPIRE_MINUTES = 15 * 24 * 60;
    public static final long MAX_EXPIRE_MINUTES = 60 * 24 * 60;

    public static String generateToken(String userCode, String userName, String alias)
    {
        return generateToken(userCode, userName, alias, DEFAULT_EXPIRE_MINUTES);
    }

    public static String generateToken(String userCode, String userName, String alias, long expireMinutes)
    {
        long now = System.currentTimeMillis();
        long expire = now + expireMinutes * 60 * 1000;

        Map<String, Object> payload = new LinkedHashMap<String, Object>();
        payload.put("sub", userCode);
        payload.put("userName", userName);
        payload.put("alias", alias);
        payload.put("iat", now);
        payload.put("exp", expire);

        String header = base64UrlEncode("{\"alg\":\"HS256\",\"typ\":\"JWT\"}");
        String payloadJson = GsonUtil.toJson(payload);
        String payloadEncoded = base64UrlEncode(payloadJson);
        String signature = hmacSha256(header + "." + payloadEncoded);

        return header + "." + payloadEncoded + "." + signature;
    }

    public static OpmUserInfo parseToken(String token)
    {
        if (ToolUtilities.isStringEmpty(token, true))
            return null;

        try
        {
            String[] parts = token.split("\\.");
            if (parts.length != 3)
                return null;

            String header = parts[0];
            String payloadEncoded = parts[1];
            String signature = parts[2];

            String expectedSignature = hmacSha256(header + "." + payloadEncoded);
            if (!ToolUtilities.isStringEqual(signature, expectedSignature))
                return null;

            String payloadJson = base64UrlDecode(payloadEncoded);
            @SuppressWarnings("unchecked")
            Map<String, Object> payload = GsonUtil.fromJson(payloadJson, Map.class);
            if (payload == null)
                return null;

            Long exp = getLong(payload.get("exp"));
            if (exp != null && exp < System.currentTimeMillis())
                return null;

            OpmUserInfo user = new OpmUserInfo();
            user.userCode = getString(payload.get("sub"));
            user.userName = getString(payload.get("userName"));
            user.alias = getString(payload.get("alias"));
            user.expireTime = exp != null ? exp : 0L;

            return user;
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public static boolean validateToken(String token)
    {
        return parseToken(token) != null;
    }

    public static String refreshToken(String token)
    {
        return refreshToken(token, DEFAULT_EXPIRE_MINUTES);
    }

    public static String refreshToken(String token, long expireMinutes)
    {
        OpmUserInfo user = parseToken(token);
        if (user == null)
            return null;
        return generateToken(user.userCode, user.userName, user.alias, expireMinutes);
    }

    private static String base64UrlEncode(String input)
    {
        return Base64.getUrlEncoder().withoutPadding()
                .encodeToString(input.getBytes(StandardCharsets.UTF_8));
    }

    private static String base64UrlDecode(String input)
    {
        return new String(Base64.getUrlDecoder().decode(input), StandardCharsets.UTF_8);
    }

    private static String hmacSha256(String data)
    {
        try
        {
            Mac mac = Mac.getInstance(HMAC_SHA256);
            SecretKeySpec secretKey = new SecretKeySpec(JWT_SECRET.getBytes(StandardCharsets.UTF_8), HMAC_SHA256);
            mac.init(secretKey);
            byte[] hmacBytes = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hmacBytes);
        }
        catch (Exception e)
        {
            return "";
        }
    }

    private static String getString(Object value)
    {
        if (value == null)
            return null;
        return value.toString();
    }

    private static Long getLong(Object value)
    {
        if (value == null)
            return null;
        if (value instanceof Number)
            return ((Number) value).longValue();
        try
        {
            return Long.parseLong(value.toString());
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public static class OpmUserInfo
    {
        public String userCode;
        public String userName;
        public String alias;
        public long expireTime;

        public String toJson()
        {
            return GsonUtil.toJson(this);
        }
    }
}