package bap.opm;

import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.nutz.dao.Cnd;

import com.cdao.model.CDo;
import com.leavay.common.util.ToolUtilities;

import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.cmn.TsHelper;
import tiny.service.md.TsAgentDo;

import bap.md.opm.OpmAlarmRefDo;
import bap.md.opm.OpmMetricMainDo;
import bap.md.opm.cpu.OpmCpuMetricDo;
import bap.md.opm.disk.OpmDiskMetricDo;
import bap.md.opm.io.OpmIoMetricDo;
import bap.md.opm.memory.OpmMemoryMetricDo;
import bap.md.opm.net.OpmNetMetricDo;
import bap.md.opm.sys.OpmSysMetricDo;
import bap.opm.cfg.OpmAgentConfigMgr;
import bap.opm.cfg.OpmConfigSchema;

public class OpmCenterServiceImpl implements OpmCenterService
{
    protected static OpmCenterServiceImpl _me;

    public synchronized static OpmCenterServiceImpl get()
    {
        if (_me == null)
            _me = new OpmCenterServiceImpl();
        return _me;
    }

    protected OpmCenterServiceImpl()
    {
    }

    @Override
    public void ping() throws RemoteException
    {
    }

    @Override
    public Map<String, Object> queryRuntimeMeta() throws Exception
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        OpmCenter center = OpmCenter.get();
        OpmAgentContext ctx = center.getAgentContext();
        map.put("collectorKeys", center.listCollectorKeys());
        map.put("collectors", center.listCollectorKeys());
        map.put("agentCode", ctx == null ? null : ctx.getAgentCode());
        map.put("agentName", ctx == null ? null : ctx.getAgentName());
        map.put("myUri", ctx == null ? null : ctx.getMyUri());
        map.put("agentContextDetectTime", ctx == null ? null : ctx.getDetectTime());
        map.put("runtimeHasConfigRecord", center.hasRuntimeConfigRecord());
        map.put("runtimeConfigured", center.isRuntimeConfigured());
        map.put("runtimeCollectorEnabled", center.hasRuntimeEnabledCollector());
        return map;
    }

    @Override
    public boolean isAgentOpmEditable(String agentCode) throws Exception
    {
        if (!TsHelper.isChief())
            return false;

        OpmCenter center = OpmCenter.get();
        if (!center.isStarted())
            return false;

        String code = normalizeAgentCode(agentCode);
        if (isSelfAgentCode(code))
            return true;

        try (IDao dao = IDaoService.newIDao())
        {
            CDo agt = dao.queryDo(TsAgentDo.class.getName(), Cnd.where(TsAgentDo.Code, "=", code));
            if (agt == null)
                return false;

            String starterConf = agt.getString("starterConf");
            HashSet<String> set = TsAgentDo.convertStarterConfig(starterConf);
            return set != null && set.contains(OpmConst.MODULE_NAME);
        }
    }

    @Override
    public Map<String, String> queryAgentConfigMap(String agentCode) throws Exception
    {
        verifyChiefService();

        String code = normalizeAgentCode(agentCode);
        if (!isAgentOpmEditable(code))
            throw new Exception("Agent OPM module is not enabled: " + code);

        OpmCenter center = OpmCenter.get();
        OpmAgentContext ctx = center.getAgentContext();
        if (ctx != null && isSelfAgentCode(code))
            return OpmAgentConfigMgr.queryConfigMapByAgentCode(ctx.getAgentCode(), ctx.getAgentName(), ctx.getMyUri());
        return OpmAgentConfigMgr.queryConfigMapByAgentCode(code, null, null);
    }

    @Override
    public void saveAgentConfigMap(String agentCode, Map<String, String> mapCfg) throws Exception
    {
        verifyChiefService();

        String code = normalizeAgentCode(agentCode);
        if (!isAgentOpmEditable(code))
            throw new Exception("Agent OPM module is not enabled: " + code);

        OpmCenter center = OpmCenter.get();
        OpmAgentContext ctx = center.getAgentContext();
        if (ctx != null && isSelfAgentCode(code))
            OpmAgentConfigMgr.saveConfigMapByAgentCode(ctx.getAgentCode(), ctx.getAgentName(), ctx.getMyUri(), mapCfg);
        else
            OpmAgentConfigMgr.saveConfigMapByAgentCode(code, null, null, mapCfg);

        center.reloadRuntimeConfigNow();
        center.reloadCollectorsNow();
    }

    @Override
    public Map<String, Object> queryConfigSchema() throws Exception
    {
        verifyChiefService();
        return OpmConfigSchema.buildSchema();
    }

    protected void verifyChiefService() throws Exception
    {
        if (!TsHelper.isChief())
            throw new Exception("OPM center config service is available on chief only");

        if (!OpmCenter.get().isStarted())
            throw new Exception("OPM center service is not started on chief");
    }

    protected String normalizeAgentCode(String agentCode) throws Exception
    {
        String code = agentCode == null ? null : agentCode.trim();
        if (ToolUtilities.isStringEmpty(code, true))
            throw new Exception("agentCode is empty");

        OpmAgentContext ctx = OpmCenter.get().getAgentContext();
        if (ctx != null)
        {
            if (ToolUtilities.isStringEqual(code, ctx.getAgentCode(), true)
                    || ToolUtilities.isStringEqual(code, ctx.getMyUri(), true))
                return ctx.getAgentCode();
        }

        try (IDao dao = IDaoService.newIDao())
        {
            CDo agt = dao.queryDo(TsAgentDo.class.getName(), Cnd.where(TsAgentDo.Code, "=", code));
            if (agt == null)
                return code;

            String c = agt.getString(TsAgentDo.Code);
            if (ToolUtilities.isStringEmpty(c, true))
                c = code;

            String uri = agt.getString("myUri");
            if (ctx != null && ToolUtilities.isStringEqual(uri, ctx.getMyUri(), true))
                return ctx.getAgentCode();

            return c;
        }
    }

    protected boolean isSelfAgentCode(String code)
    {
        OpmAgentContext ctx = OpmCenter.get().getAgentContext();
        if (ctx == null)
            return false;
        return ToolUtilities.isStringEqual(code, ctx.getAgentCode(), true)
                || ToolUtilities.isStringEqual(code, ctx.getMyUri(), true);
    }

    @Override
    public List<String> listCollectorKeys() throws Exception
    {
        return OpmCenter.get().listCollectorKeys();
    }

    @Override
    public OpmCollectResult collectNow(String collectorKey) throws Exception
    {
        return OpmCenter.get().collectNow(collectorKey);
    }

    @Override
    public List<OpmMetricMainDo> queryLatestMain(int count) throws Exception
    {
        return OpmCenter.get().queryLatestMain(count);
    }

    @Override
    public List<OpmAlarmRefDo> queryLatestAlarmRef(int count) throws Exception
    {
        return OpmCenter.get().queryLatestAlarmRef(count);
    }

    @Override
    public List<OpmSysMetricDo> queryLatestSysMetric(int count) throws Exception
    {
        return OpmCenter.get().queryLatestSysMetric(count);
    }

    @Override
    public List<OpmCpuMetricDo> queryLatestCpuMetric(int count) throws Exception
    {
        return OpmCenter.get().queryLatestCpuMetric(count);
    }

    @Override
    public List<OpmMemoryMetricDo> queryLatestMemoryMetric(int count) throws Exception
    {
        return OpmCenter.get().queryLatestMemoryMetric(count);
    }

    @Override
    public List<OpmDiskMetricDo> queryLatestDiskMetric(int count) throws Exception
    {
        return OpmCenter.get().queryLatestDiskMetric(count);
    }

    @Override
    public List<OpmIoMetricDo> queryLatestIoMetric(int count) throws Exception
    {
        return OpmCenter.get().queryLatestIoMetric(count);
    }

    @Override
    public List<OpmNetMetricDo> queryLatestNetMetric(int count) throws Exception
    {
        return OpmCenter.get().queryLatestNetMetric(count);
    }
}
