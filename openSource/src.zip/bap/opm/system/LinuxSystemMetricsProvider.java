package bap.opm.system;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bap.opm.collector.topcpu.OpmTopCpuConst;
import bap.opm.collector.topio.OpmTopIoConst;

public class LinuxSystemMetricsProvider extends AbstractSystemMetricsProvider
{
    private static final String PROC_MEMINFO_PATH = "/proc/meminfo";
    private static final String PROC_STAT_PATH = "/proc/stat";

    @Override
    public boolean supports(String osName)
    {
        return lower(osName).contains("linux");
    }

    @Override
    public String getName()
    {
        return "linux";
    }

    @Override
    public SystemMetrics collect(long cpuSampleMillis)
    {
        return collect(cpuSampleMillis, SystemMetricsCollectSpec.all());
    }

    @Override
    public SystemMetrics collect(long cpuSampleMillis, SystemMetricsCollectSpec spec)
    {
        SystemMetricsCollectSpec collectSpec = normalizeCollectSpec(spec);
        long sampleMillis = normalizeSampleMillis(cpuSampleMillis);
        SystemMetrics metrics = newBaseMetrics();

        long totalStart = System.currentTimeMillis();
        debugCollectStart(getName(), collectSpec, sampleMillis);

        if (collectSpec.needCpu())
        {
            long st = System.currentTimeMillis();
            metrics.cpu = collectCpuUsage(sampleMillis);
            debugCollectStage(getName(), "topCpu", st);
        }

        if (collectSpec.needMemory())
        {
            long st = System.currentTimeMillis();
            metrics.memory = collectMemoryUsage();
            debugCollectStage(getName(), "topMemory", st);
        }

        if (collectSpec.needDisk())
        {
            long st = System.currentTimeMillis();
            metrics.disks = collectDiskUsage();
            debugCollectStage(getName(), "disk", st);
        }

        if (collectSpec.needCpuProcesses())
        {
            long st = System.currentTimeMillis();
            metrics.cpuProcesses = collectCpuProcessUsage();
            debugCollectStage(getName(), "cpuProcesses", st);
        }

        if (collectSpec.needMemoryProcesses())
        {
            long st = System.currentTimeMillis();
            metrics.memoryProcesses = collectMemoryProcessUsage();
            debugCollectStage(getName(), "memoryProcesses", st);
        }

        if (collectSpec.needIo())
        {
            long st = System.currentTimeMillis();
            metrics.io = collectIoUsage(sampleMillis);
            debugCollectStage(getName(), "topIo", st);
        }

        if (collectSpec.needNetwork())
        {
            long st = System.currentTimeMillis();
            metrics.network = collectNetworkUsage(sampleMillis);
            debugCollectStage(getName(), "network", st);
        }

        debugCollectEnd(getName(), collectSpec, totalStart);
        return metrics;
    }

    private SystemMetrics.CpuUsage collectCpuUsage(long sampleMillis)
    {
        CpuSnapshot first = readCpuSnapshotFromProc();
        if (first != null)
        {
            sleepSilently(sampleMillis);
            CpuSnapshot second = readCpuSnapshotFromProc();
            if (second != null)
                return buildCpuUsage(first, second, sampleMillis, "proc_stat");
        }

        return collectCpuByMxBean(sampleMillis);
    }

    private SystemMetrics.MemoryUsage collectMemoryUsage()
    {
        SystemMetrics.MemoryUsage usage = collectMemoryUsageFromProc();
        if (usage != null)
            return usage;

        usage = collectMemoryUsageFromFree();
        if (usage != null)
            return usage;

        return collectMemoryByMxBean();
    }

    private List<SystemMetrics.DiskUsage> collectDiskUsage()
    {
        List<SystemMetrics.DiskUsage> list = collectDiskByDf();
        if (!list.isEmpty())
            return list;
        return collectDiskByFileStore();
    }

    private SystemMetrics.NetworkUsage collectNetworkUsage(long sampleMillis)
    {
        Map<String, NetCounter> first = readNetworkCountersFromProc();
        if (first.isEmpty())
        {
            SystemMetrics.NetworkUsage usage = new SystemMetrics.NetworkUsage();
            usage.available = false;
            usage.sampleMillis = sampleMillis;
            usage.source = "proc_net_dev";
            usage.error = "No network counters in /proc/net/dev";
            return usage;
        }

        sleepSilently(sampleMillis);
        Map<String, NetCounter> second = readNetworkCountersFromProc();
        SystemMetrics.NetworkUsage usage = buildNetworkUsageFromSnapshot(first, second, sampleMillis, "proc_net_dev");
        usage.processes = collectProcessNetworkUsageByNethogs(sampleMillis);
        if (usage.processes == null || usage.processes.isEmpty())
            usage.processes = collectProcessNetworkUsageBySs(usage.totalThroughputBytesPerSec);
        return usage;
    }

    private List<SystemMetrics.ProcessCpuUsage> collectCpuProcessUsage()
    {
        List<SystemMetrics.ProcessCpuUsage> list = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        CommandResult result = executeCommand(5000L, "ps", "-eo", "pid,comm,%cpu", "--sort=-%cpu");
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        for (int i = 1; i < lines.length; i++)
        {
            String line = lines[i];
            if (!hasText(line))
                continue;

            String[] arr = line.trim().split("\\s+", 3);
            if (arr.length < 3)
                continue;

            int pid = (int) parseLong(arr[0], -1L);
            if (pid < 0)
                continue;

            double cpuPct = parseDouble(arr[2], -1D);
            if (cpuPct < 0D)
                continue;

            SystemMetrics.ProcessCpuUsage p = new SystemMetrics.ProcessCpuUsage();
            p.available = true;
            p.source = "ps";
            p.pid = pid;
            p.processName = arr[1];
            p.processPath = readProcessExePath(Paths.get("/proc", String.valueOf(pid)));
            p.memoryBytes = readProcessMemoryBytes(Paths.get("/proc", String.valueOf(pid)));
            p.cpuRate = normalizeProcessCpuRateFromPercent(cpuPct);
            list.add(p);
        }
        return list;
    }

    private List<SystemMetrics.ProcessMemoryUsage> collectMemoryProcessUsage()
    {
        List<SystemMetrics.ProcessMemoryUsage> list = new ArrayList<SystemMetrics.ProcessMemoryUsage>();
        CommandResult result = executeCommand(5000L, "ps", "-eo", "pid,comm,rss", "--sort=-rss");
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        for (int i = 1; i < lines.length; i++)
        {
            String line = lines[i];
            if (!hasText(line))
                continue;

            String[] arr = line.trim().split("\\s+", 3);
            if (arr.length < 3)
                continue;

            int pid = (int) parseLong(arr[0], -1L);
            if (pid < 0)
                continue;

            SystemMetrics.ProcessMemoryUsage p = new SystemMetrics.ProcessMemoryUsage();
            p.available = true;
            p.source = "ps";
            p.pid = pid;
            p.processName = arr[1];
            Path procPath = Paths.get("/proc", String.valueOf(pid));
            p.processPath = readProcessExePath(procPath);
            p.memoryBytes = kbToBytes(parseLong(arr[2], 0L));
            list.add(p);
        }
        return list;
    }

    private SystemMetrics.IoUsage collectIoUsage(long sampleMillis)
    {
        SystemMetrics.IoUsage usage = new SystemMetrics.IoUsage();
        usage.sampleMillis = sampleMillis;
        usage.source = "proc_pid_io";

        Map<Integer, ProcIoCounter> first = readProcIoCounters();
        if (first.isEmpty())
        {
            usage.available = false;
            usage.error = "No process io counters in /proc/[pid]/io";
            return usage;
        }

        sleepSilently(sampleMillis);
        Map<Integer, ProcIoCounter> second = readProcIoCounters();
        if (second.isEmpty())
        {
            usage.available = false;
            usage.error = "No second process io snapshot";
            return usage;
        }

        for (Map.Entry<Integer, ProcIoCounter> ent : second.entrySet())
        {
            ProcIoCounter s = ent.getValue();
            ProcIoCounter f = first.get(ent.getKey());
            if (s == null || f == null)
                continue;

            long deltaRead = s.readBytes - f.readBytes;
            long deltaWrite = s.writeBytes - f.writeBytes;
            if (deltaRead < 0L)
                deltaRead = 0L;
            if (deltaWrite < 0L)
                deltaWrite = 0L;

            SystemMetrics.ProcessIoUsage p = new SystemMetrics.ProcessIoUsage();
            p.available = true;
            p.source = "proc_pid_io";
            p.pid = s.pid;
            p.processName = hasText(s.name) ? s.name : f.name;
            Path procPath = Paths.get("/proc", String.valueOf(s.pid));
            p.processPath = readProcessExePath(procPath);
            p.memoryBytes = readProcessMemoryBytes(procPath);
            p.readBytes = s.readBytes;
            p.writeBytes = s.writeBytes;
            p.readRateBytesPerSec = deltaRead * 1000D / (double) sampleMillis;
            p.writeRateBytesPerSec = deltaWrite * 1000D / (double) sampleMillis;
            p.ioRateBytesPerSec = p.readRateBytesPerSec + p.writeRateBytesPerSec;
            usage.processes.add(p);
        }

        Collections.sort(usage.processes, new Comparator<SystemMetrics.ProcessIoUsage>()
        {
            @Override
            public int compare(SystemMetrics.ProcessIoUsage a, SystemMetrics.ProcessIoUsage b)
            {
                double av = a == null ? -1D : a.ioRateBytesPerSec;
                double bv = b == null ? -1D : b.ioRateBytesPerSec;
                return Double.compare(bv, av);
            }
        });

        int max = Math.max(1, OpmTopIoConst.getTopProcSize());
        while (usage.processes.size() > max)
            usage.processes.remove(usage.processes.size() - 1);

        usage.available = !usage.processes.isEmpty();
        if (!usage.available)
            usage.error = "No process io delta found";
        return usage;
    }

    private Map<Integer, ProcIoCounter> readProcIoCounters()
    {
        Map<Integer, ProcIoCounter> map = new HashMap<Integer, ProcIoCounter>();
        Path proc = Paths.get("/proc");
        if (!Files.isDirectory(proc))
            return map;

        try (DirectoryStream<Path> ds = Files.newDirectoryStream(proc))
        {
            for (Path pidPath : ds)
            {
                String pidText = pidPath.getFileName().toString();
                if (!isDigits(pidText))
                    continue;

                int pid = (int) parseLong(pidText, -1L);
                if (pid < 0)
                    continue;

                Path ioFile = pidPath.resolve("topIo");
                if (!Files.isRegularFile(ioFile))
                    continue;

                long readBytes = -1L;
                long writeBytes = -1L;
                try
                {
                    List<String> lines = Files.readAllLines(ioFile, StandardCharsets.UTF_8);
                    for (String line : lines)
                    {
                        if (!hasText(line) || line.indexOf(':') < 0)
                            continue;
                        String[] kv = line.split(":", 2);
                        if (kv.length < 2)
                            continue;
                        String key = kv[0].trim();
                        String value = kv[1].trim();
                        if ("read_bytes".equals(key))
                            readBytes = parseLong(value, -1L);
                        else if ("write_bytes".equals(key))
                            writeBytes = parseLong(value, -1L);
                    }
                }
                catch (Throwable e)
                {
                    continue;
                }

                if (readBytes < 0L || writeBytes < 0L)
                    continue;

                ProcIoCounter c = new ProcIoCounter();
                c.pid = pid;
                c.name = readProcessName(pidPath, pidText);
                c.readBytes = readBytes;
                c.writeBytes = writeBytes;
                map.put(Integer.valueOf(pid), c);
            }
        }
        catch (Throwable e)
        {
            return new HashMap<Integer, ProcIoCounter>();
        }

        return map;
    }

    private String readProcessName(Path pidPath, String pidText)
    {
        try
        {
            Path comm = pidPath.resolve("comm");
            if (Files.isRegularFile(comm))
            {
                List<String> lines = Files.readAllLines(comm, StandardCharsets.UTF_8);
                if (!lines.isEmpty() && hasText(lines.get(0)))
                    return lines.get(0).trim();
            }
        }
        catch (Throwable e)
        {
        }
        return pidText;
    }

    private String readProcessExePath(Path pidPath)
    {
        if (pidPath == null)
            return null;
        try
        {
            Path exe = pidPath.resolve("exe");
            if (Files.exists(exe))
                return Files.readSymbolicLink(exe).toString();
        }
        catch (Throwable e)
        {
        }
        return null;
    }

    private long readProcessMemoryBytes(Path pidPath)
    {
        if (pidPath == null)
            return 0L;
        try
        {
            Path status = pidPath.resolve("status");
            if (!Files.isRegularFile(status))
                return 0L;
            List<String> lines = Files.readAllLines(status, StandardCharsets.UTF_8);
            for (String line : lines)
            {
                if (!hasText(line) || !line.startsWith("VmRSS:"))
                    continue;
                String[] arr = line.substring("VmRSS:".length()).trim().split("\\s+");
                if (arr.length <= 0)
                    continue;
                return kbToBytes(parseLong(arr[0], 0L));
            }
        }
        catch (Throwable e)
        {
        }
        return 0L;
    }

    private boolean isDigits(String text)
    {
        if (!hasText(text))
            return false;
        for (int i = 0; i < text.length(); i++)
            if (!Character.isDigit(text.charAt(i)))
                return false;
        return true;
    }

    private SystemMetrics.MemoryUsage collectMemoryUsageFromFree()
    {
        CommandResult result = executeCommand(4000L, "free", "-b");
        if (!result.isSuccess() || !hasText(result.output))
            return null;

        String[] lines = result.output.split("\\r?\\n");
        long total = -1L;
        long used = -1L;
        long free = -1L;
        long swapTotal = 0L;
        long swapUsed = 0L;
        long swapFree = 0L;

        for (String line : lines)
        {
            if (line == null)
                continue;

            String t = line.trim();
            if (t.startsWith("Mem:"))
            {
                String[] arr = t.split("\\s+");
                if (arr.length >= 4)
                {
                    total = parseLong(arr[1], -1L);
                    used = parseLong(arr[2], -1L);
                    free = parseLong(arr[3], -1L);
                }
            }
            else if (t.startsWith("Swap:"))
            {
                String[] arr = t.split("\\s+");
                if (arr.length >= 4)
                {
                    swapTotal = safeNonNegative(parseLong(arr[1], 0L));
                    swapUsed = safeNonNegative(parseLong(arr[2], 0L));
                    swapFree = safeNonNegative(parseLong(arr[3], 0L));
                }
            }
        }

        if (total <= 0L || used < 0L || free < 0L)
            return null;

        if (free > total)
            free = total;
        if (used > total)
            used = total;

        SystemMetrics.MemoryUsage usage = new SystemMetrics.MemoryUsage();
        usage.available = true;
        usage.source = "free";
        usage.totalBytes = total;
        usage.usedBytes = used;
        usage.freeBytes = free;
        usage.usageRate = calcRate(usage.usedBytes, usage.totalBytes);
        usage.swapTotalBytes = swapTotal;
        usage.swapUsedBytes = swapUsed;
        usage.swapFreeBytes = swapFree;
        usage.swapUsageRate = calcRate(usage.swapUsedBytes, usage.swapTotalBytes);
        return usage;
    }

    private SystemMetrics.MemoryUsage collectMemoryUsageFromProc()
    {
        Path path = Paths.get(PROC_MEMINFO_PATH);
        if (!Files.isRegularFile(path))
            return null;

        Map<String, Long> kv = new HashMap<String, Long>();
        try
        {
            List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (String line : lines)
            {
                if (line == null)
                    continue;

                int index = line.indexOf(':');
                if (index <= 0)
                    continue;

                String key = line.substring(0, index).trim();
                String valuePart = line.substring(index + 1).trim();
                if (key.length() == 0 || valuePart.length() == 0)
                    continue;

                String[] tokens = valuePart.split("\\s+");
                if (tokens.length == 0)
                    continue;

                long value = parseLong(tokens[0], -1L);
                if (value >= 0L)
                    kv.put(key, Long.valueOf(value));
            }
        }
        catch (Throwable e)
        {
            return null;
        }

        long totalKb = getOrDefault(kv, "MemTotal", -1L);
        if (totalKb <= 0L)
            return null;

        long availableKb = getOrDefault(kv, "MemAvailable", -1L);
        if (availableKb < 0L)
        {
            long memFree = getOrDefault(kv, "MemFree", 0L);
            long buffers = getOrDefault(kv, "Buffers", 0L);
            long cached = getOrDefault(kv, "Cached", 0L);
            long sreclaimable = getOrDefault(kv, "SReclaimable", 0L);
            long shmem = getOrDefault(kv, "Shmem", 0L);
            availableKb = memFree + buffers + cached + sreclaimable - shmem;
        }

        if (availableKb < 0L)
            availableKb = 0L;
        if (availableKb > totalKb)
            availableKb = totalKb;

        long usedKb = totalKb - availableKb;
        if (usedKb < 0L)
            usedKb = 0L;

        SystemMetrics.MemoryUsage usage = new SystemMetrics.MemoryUsage();
        usage.available = true;
        usage.source = "proc_meminfo";
        usage.totalBytes = kbToBytes(totalKb);
        usage.freeBytes = kbToBytes(availableKb);
        usage.usedBytes = kbToBytes(usedKb);
        usage.usageRate = calcRate(usage.usedBytes, usage.totalBytes);

        long swapTotalKb = getOrDefault(kv, "SwapTotal", 0L);
        long swapFreeKb = getOrDefault(kv, "SwapFree", 0L);
        if (swapTotalKb < 0L)
            swapTotalKb = 0L;
        if (swapFreeKb < 0L)
            swapFreeKb = 0L;
        if (swapFreeKb > swapTotalKb)
            swapFreeKb = swapTotalKb;

        usage.swapTotalBytes = kbToBytes(swapTotalKb);
        usage.swapFreeBytes = kbToBytes(swapFreeKb);
        usage.swapUsedBytes = safeNonNegative(usage.swapTotalBytes - usage.swapFreeBytes);
        usage.swapUsageRate = calcRate(usage.swapUsedBytes, usage.swapTotalBytes);
        return usage;
    }

    private Map<String, NetCounter> readNetworkCountersFromProc()
    {
        Map<String, NetCounter> map = new HashMap<String, NetCounter>();
        Path path = Paths.get("/proc/net/dev");
        if (!Files.isRegularFile(path))
            return map;

        try
        {
            List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (int i = 2; i < lines.size(); i++)
            {
                String line = lines.get(i);
                if (!hasText(line))
                    continue;

                int idx = line.indexOf(':');
                if (idx <= 0)
                    continue;

                String name = line.substring(0, idx).trim();
                if (!hasText(name))
                    continue;

                String right = line.substring(idx + 1).trim();
                String[] arr = right.split("\\s+");
                if (arr.length < 16)
                    continue;

                long rx = parseLong(arr[0], -1L);
                long tx = parseLong(arr[8], -1L);
                if (rx < 0L || tx < 0L)
                    continue;

                NetCounter c = new NetCounter();
                c.name = name;
                c.displayName = name;
                c.rxBytes = rx;
                c.txBytes = tx;
                map.put(name, c);
            }
        }
        catch (Throwable e)
        {
            return new HashMap<String, NetCounter>();
        }

        return map;
    }

    private List<SystemMetrics.ProcessNetworkUsage> collectProcessNetworkUsageByNethogs(long sampleMillis)
    {
        List<SystemMetrics.ProcessNetworkUsage> list = new ArrayList<SystemMetrics.ProcessNetworkUsage>();
        long seconds = sampleMillis / 1000L;
        if (seconds <= 0L)
            seconds = 1L;

        CommandResult result = executeCommand(10000L, "nethogs", "-t", "-c", "1", "-d", String.valueOf(seconds));
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line))
                continue;

            String t = line.trim();
            if (t.startsWith("Refreshing") || t.startsWith("TOTAL"))
                continue;

            String[] arr = t.split("\\s+");
            if (arr.length < 3)
                continue;

            double txKbPerSec = parseDouble(arr[arr.length - 2], -1D);
            double rxKbPerSec = parseDouble(arr[arr.length - 1], -1D);
            if (txKbPerSec < 0D || rxKbPerSec < 0D)
                continue;

            String processToken = arr[arr.length - 3];

            SystemMetrics.ProcessNetworkUsage p = new SystemMetrics.ProcessNetworkUsage();
            p.available = true;
            p.source = "nethogs";
            p.pid = parseLeadingPid(processToken);
            p.processName = parseProcessName(processToken);
            p.txRateBytesPerSec = txKbPerSec * 1024D;
            p.rxRateBytesPerSec = rxKbPerSec * 1024D;
            p.throughputBytesPerSec = p.txRateBytesPerSec + p.rxRateBytesPerSec;
            list.add(p);
        }

        Collections.sort(list, new Comparator<SystemMetrics.ProcessNetworkUsage>()
        {
            @Override
            public int compare(SystemMetrics.ProcessNetworkUsage a, SystemMetrics.ProcessNetworkUsage b)
            {
                double av = a == null ? -1D : a.throughputBytesPerSec;
                double bv = b == null ? -1D : b.throughputBytesPerSec;
                return Double.compare(bv, av);
            }
        });
        return list;
    }

    private List<SystemMetrics.ProcessNetworkUsage> collectProcessNetworkUsageBySs(double totalThroughput)
    {
        List<SystemMetrics.ProcessNetworkUsage> list = new ArrayList<SystemMetrics.ProcessNetworkUsage>();
        CommandResult result = executeCommand(5000L, "ss", "-tnp");
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        Map<Integer, ProcConnCounter> map = new HashMap<Integer, ProcConnCounter>();
        long totalConn = 0L;

        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf("pid=") < 0)
                continue;

            int pidIdx = line.indexOf("pid=");
            if (pidIdx < 0)
                continue;

            int start = pidIdx + 4;
            int end = start;
            while (end < line.length() && Character.isDigit(line.charAt(end)))
                end++;
            if (end <= start)
                continue;

            int pid = (int) parseLong(line.substring(start, end), -1L);
            if (pid < 0)
                continue;

            String name = parseProcessNameFromSs(line);
            ProcConnCounter c = map.get(Integer.valueOf(pid));
            if (c == null)
            {
                c = new ProcConnCounter();
                c.pid = pid;
                c.name = name;
                c.conn = 0L;
                map.put(Integer.valueOf(pid), c);
            }
            c.conn++;
            totalConn++;
        }

        if (totalConn <= 0L || map.isEmpty())
            return list;

        for (ProcConnCounter c : map.values())
        {
            double ratio = (double) c.conn / (double) totalConn;
            double throughput = totalThroughput * ratio;

            SystemMetrics.ProcessNetworkUsage p = new SystemMetrics.ProcessNetworkUsage();
            p.available = true;
            p.pid = c.pid;
            p.processName = c.name;
            p.source = "ss_connection_share";
            p.rxRateBytesPerSec = throughput / 2D;
            p.txRateBytesPerSec = throughput / 2D;
            p.throughputBytesPerSec = throughput;
            list.add(p);
        }

        Collections.sort(list, new Comparator<SystemMetrics.ProcessNetworkUsage>()
        {
            @Override
            public int compare(SystemMetrics.ProcessNetworkUsage a, SystemMetrics.ProcessNetworkUsage b)
            {
                double av = a == null ? -1D : a.throughputBytesPerSec;
                double bv = b == null ? -1D : b.throughputBytesPerSec;
                return Double.compare(bv, av);
            }
        });
        return list;
    }

    private String parseProcessNameFromSs(String line)
    {
        if (!hasText(line))
            return "";

        int quoteStart = line.indexOf('"');
        if (quoteStart < 0 || quoteStart + 1 >= line.length())
            return "";
        int quoteEnd = line.indexOf('"', quoteStart + 1);
        if (quoteEnd <= quoteStart)
            return "";
        return line.substring(quoteStart + 1, quoteEnd).trim();
    }

    private int parseLeadingPid(String token)
    {
        if (!hasText(token))
            return -1;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < token.length(); i++)
        {
            char c = token.charAt(i);
            if (Character.isDigit(c))
                sb.append(c);
            else
                break;
        }
        if (sb.length() == 0)
            return -1;
        long pid = parseLong(sb.toString(), -1L);
        if (pid < 0L || pid > Integer.MAX_VALUE)
            return -1;
        return (int) pid;
    }

    private String parseProcessName(String token)
    {
        if (!hasText(token))
            return "";
        int slash = token.lastIndexOf('/');
        if (slash >= 0 && slash < token.length() - 1)
            return token.substring(slash + 1);
        return token;
    }

    private static class ProcConnCounter
    {
        int pid;
        String name;
        long conn;
    }

    private static class ProcIoCounter
    {
        int pid;
        String name;
        long readBytes;
        long writeBytes;
    }

    private CpuSnapshot readCpuSnapshotFromProc()
    {
        Path path = Paths.get(PROC_STAT_PATH);
        if (!Files.isRegularFile(path))
            return null;

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8))
        {
            String line = reader.readLine();
            if (line == null)
                return null;

            line = line.trim();
            if (!line.startsWith("cpu "))
                return null;

            String[] arr = line.split("\\s+");
            if (arr.length < 8)
                return null;

            CpuSnapshot snapshot = new CpuSnapshot();
            snapshot.user = parseLong(arr[1], 0L);
            snapshot.nice = parseLong(arr[2], 0L);
            snapshot.system = parseLong(arr[3], 0L);
            snapshot.idle = parseLong(arr[4], 0L);
            snapshot.ioWait = parseLong(arr[5], 0L);
            snapshot.irq = parseLong(arr[6], 0L);
            snapshot.softIrq = parseLong(arr[7], 0L);
            snapshot.steal = arr.length > 8 ? parseLong(arr[8], 0L) : 0L;

            snapshot.idleAll = snapshot.idle + snapshot.ioWait;
            snapshot.total = snapshot.user + snapshot.nice + snapshot.system + snapshot.idle + snapshot.ioWait + snapshot.irq + snapshot.softIrq + snapshot.steal;
            return snapshot;
        }
        catch (Throwable e)
        {
            return null;
        }
    }

    private SystemMetrics.CpuUsage buildCpuUsage(CpuSnapshot first, CpuSnapshot second, long sampleMillis, String source)
    {
        SystemMetrics.CpuUsage usage = new SystemMetrics.CpuUsage();
        usage.sampleMillis = sampleMillis;
        usage.source = source;

        long deltaTotal = second.total - first.total;
        long deltaIdle = second.idleAll - first.idleAll;
        long deltaUser = (second.user + second.nice) - (first.user + first.nice);
        long deltaSystem = (second.system + second.irq + second.softIrq) - (first.system + first.irq + first.softIrq);
        long deltaIoWait = second.ioWait - first.ioWait;

        if (deltaTotal <= 0L)
        {
            usage.available = false;
            usage.error = "Invalid CPU delta sample";
            usage.usageRate = -1D;
            usage.userRate = -1D;
            usage.systemRate = -1D;
            usage.idleRate = -1D;
            usage.ioWaitRate = -1D;
            return usage;
        }

        usage.available = true;
        usage.idleRate = clampRate((double) deltaIdle / (double) deltaTotal);
        usage.usageRate = clampRate(1D - usage.idleRate);
        usage.userRate = clampRate((double) deltaUser / (double) deltaTotal);
        usage.systemRate = clampRate((double) deltaSystem / (double) deltaTotal);
        usage.ioWaitRate = clampRate((double) deltaIoWait / (double) deltaTotal);
        return usage;
    }

    private static long getOrDefault(Map<String, Long> map, String key, long defaultValue)
    {
        Long value = map.get(key);
        if (value == null)
            return defaultValue;
        return value.longValue();
    }

    private static class CpuSnapshot
    {
        long user;
        long nice;
        long system;
        long idle;
        long ioWait;
        long irq;
        long softIrq;
        long steal;
        long idleAll;
        long total;
    }
}
