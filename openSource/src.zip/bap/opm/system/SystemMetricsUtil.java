package bap.opm.system;

public class SystemMetricsUtil
{
    private static final long DEFAULT_CPU_SAMPLE_MILLIS = 1000L;

    private SystemMetricsUtil()
    {
    }

    public static SystemMetrics collect()
    {
        return collect(DEFAULT_CPU_SAMPLE_MILLIS);
    }

    public static SystemMetrics collect(long cpuSampleMillis)
    {
        SystemMetricsProvider provider = SystemMetricsProviderFactory.resolveProvider();
        return provider.collect(cpuSampleMillis);
    }

    public static SystemMetrics collect(long cpuSampleMillis, SystemMetricsCollectSpec spec)
    {
        SystemMetricsProvider provider = SystemMetricsProviderFactory.resolveProvider();
        return provider.collect(cpuSampleMillis, spec == null ? SystemMetricsCollectSpec.all() : spec);
    }

    public static String formatPercent(double rate)
    {
        return AbstractSystemMetricsProvider.formatPercent(rate);
    }

    public static String formatBytes(long bytes)
    {
        return AbstractSystemMetricsProvider.formatBytes(bytes);
    }

    public static String formatRate(double bytesPerSec)
    {
        return AbstractSystemMetricsProvider.formatRate(bytesPerSec);
    }

    public static void main(String[] args)
    {
        long sampleMillis = DEFAULT_CPU_SAMPLE_MILLIS;
        if (args != null && args.length > 0)
            sampleMillis = parseLong(args[0], DEFAULT_CPU_SAMPLE_MILLIS);

        SystemMetrics metrics = collect(sampleMillis);
        AbstractSystemMetricsProvider.printMetrics(metrics, sampleMillis);
    }

    private static long parseLong(String text, long defaultValue)
    {
        if (text == null)
            return defaultValue;
        try
        {
            return Long.parseLong(text.trim());
        }
        catch (Throwable e)
        {
            return defaultValue;
        }
    }
}
