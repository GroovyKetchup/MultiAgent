package bap.opm.system;

public class LinuxSystemMetricsUtil
{
    private LinuxSystemMetricsUtil()
    {
    }

    public static SystemMetrics collect()
    {
        return wrap(SystemMetricsUtil.collect());
    }

    public static SystemMetrics collect(long cpuSampleMillis)
    {
        return wrap(SystemMetricsUtil.collect(cpuSampleMillis));
    }

    public static String formatPercent(double rate)
    {
        return SystemMetricsUtil.formatPercent(rate);
    }

    public static String formatBytes(long bytes)
    {
        return SystemMetricsUtil.formatBytes(bytes);
    }

    public static String formatRate(double bytesPerSec)
    {
        return SystemMetricsUtil.formatRate(bytesPerSec);
    }

    public static void main(String[] args)
    {
        SystemMetricsUtil.main(args);
    }

    private static SystemMetrics wrap(SystemMetrics raw)
    {
        SystemMetrics metrics = new SystemMetrics();
        if (raw == null)
            return metrics;

        metrics.timestamp = raw.timestamp;
        metrics.hostName = raw.hostName;
        metrics.osName = raw.osName;
        metrics.provider = raw.provider;
        metrics.cpu = raw.cpu;
        metrics.memory = raw.memory;
        metrics.disks = raw.disks;
        metrics.network = raw.network;
        return metrics;
    }
}
