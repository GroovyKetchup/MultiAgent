package bap.opm.system;

public class SystemMetricsCollectSpec
{
    protected final boolean _cpu;
    protected final boolean _memory;
    protected final boolean _disk;
    protected final boolean _cpuProcesses;
    protected final boolean _memoryProcesses;
    protected final boolean _io;
    protected final boolean _network;
    protected final boolean _networkProcesses;

    protected static final SystemMetricsCollectSpec SPEC_ALL = new SystemMetricsCollectSpec(true, true, true, true, true, true, true, true);
    protected static final SystemMetricsCollectSpec SPEC_SYS = new SystemMetricsCollectSpec(true, true, true, false, false, false, true, false);
    protected static final SystemMetricsCollectSpec SPEC_CPU = new SystemMetricsCollectSpec(true, false, false, true, false, false, false, false);
    protected static final SystemMetricsCollectSpec SPEC_MEMORY = new SystemMetricsCollectSpec(false, true, false, false, true, false, false, false);
    protected static final SystemMetricsCollectSpec SPEC_DISK = new SystemMetricsCollectSpec(false, false, true, false, false, false, false, false);
    protected static final SystemMetricsCollectSpec SPEC_IO = new SystemMetricsCollectSpec(false, false, false, false, false, true, false, false);
    protected static final SystemMetricsCollectSpec SPEC_NET = new SystemMetricsCollectSpec(false, false, false, false, false, false, true, true);

    protected SystemMetricsCollectSpec(boolean cpu, boolean memory, boolean disk, boolean cpuProcesses,
            boolean memoryProcesses, boolean io, boolean network, boolean networkProcesses)
    {
        _cpu = cpu;
        _memory = memory;
        _disk = disk;
        _cpuProcesses = cpuProcesses;
        _memoryProcesses = memoryProcesses;
        _io = io;
        _network = network;
        _networkProcesses = networkProcesses;
    }

    public static SystemMetricsCollectSpec all()
    {
        return SPEC_ALL;
    }

    public static SystemMetricsCollectSpec forSysCollector()
    {
        return SPEC_SYS;
    }

    public static SystemMetricsCollectSpec forCpuCollector()
    {
        return SPEC_CPU;
    }

    public static SystemMetricsCollectSpec forMemoryCollector()
    {
        return SPEC_MEMORY;
    }

    public static SystemMetricsCollectSpec forDiskCollector()
    {
        return SPEC_DISK;
    }

    public static SystemMetricsCollectSpec forIoCollector()
    {
        return SPEC_IO;
    }

    public static SystemMetricsCollectSpec forNetCollector()
    {
        return SPEC_NET;
    }

    public boolean needCpu()
    {
        return _cpu;
    }

    public boolean needMemory()
    {
        return _memory;
    }

    public boolean needDisk()
    {
        return _disk;
    }

    public boolean needCpuProcesses()
    {
        return _cpuProcesses;
    }

    public boolean needMemoryProcesses()
    {
        return _memoryProcesses;
    }

    public boolean needIo()
    {
        return _io;
    }

    public boolean needNetwork()
    {
        return _network;
    }

    public boolean needNetworkProcesses()
    {
        return _networkProcesses;
    }

    public boolean isAllEnabled()
    {
        return _cpu && _memory && _disk && _cpuProcesses && _memoryProcesses && _io && _network && _networkProcesses;
    }

    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder(96);
        appendPart(sb, "topCpu", _cpu);
        appendPart(sb, "topMemory", _memory);
        appendPart(sb, "disk", _disk);
        appendPart(sb, "cpuProc", _cpuProcesses);
        appendPart(sb, "memProc", _memoryProcesses);
        appendPart(sb, "topIo", _io);
        appendPart(sb, "network", _network);
        appendPart(sb, "netProc", _networkProcesses);
        return sb.toString();
    }

    protected static void appendPart(StringBuilder sb, String name, boolean enabled)
    {
        if (!enabled)
            return;

        if (sb.length() > 0)
            sb.append(',');
        sb.append(name);
    }
}
