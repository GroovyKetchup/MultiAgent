package bap.opm.system;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import bap.opm.collector.topcpu.OpmTopCpuConst;
import bap.opm.collector.topio.OpmTopIoConst;

public class MacSystemMetricsProvider extends AbstractSystemMetricsProvider
{
    @Override
    public boolean supports(String osName)
    {
        String os = lower(osName);
        return os.contains("mac") || os.contains("darwin");
    }

    @Override
    public String getName()
    {
        return "mac";
    }

    @Override
    public SystemMetrics collect(long cpuSampleMillis)
    {
        return collect(cpuSampleMillis, SystemMetricsCollectSpec.all());
    }

    @Override
    public SystemMetrics collect(long cpuSampleMillis, SystemMetricsCollectSpec spec)
    {
        SystemMetricsCollectSpec collectSpec = normalizeCollectSpec(spec);
        long sampleMillis = normalizeSampleMillis(cpuSampleMillis);
        SystemMetrics metrics = newBaseMetrics();

        long totalStart = System.currentTimeMillis();
        debugCollectStart(getName(), collectSpec, sampleMillis);

        if (collectSpec.needCpu())
        {
            long st = System.currentTimeMillis();
            metrics.cpu = collectCpuUsage(sampleMillis);
            debugCollectStage(getName(), "topCpu", st);
        }

        if (collectSpec.needMemory())
        {
            long st = System.currentTimeMillis();
            metrics.memory = collectMemoryUsage();
            debugCollectStage(getName(), "topMemory", st);
        }

        if (collectSpec.needDisk())
        {
            long st = System.currentTimeMillis();
            metrics.disks = collectDiskUsage();
            debugCollectStage(getName(), "disk", st);
        }

        if (collectSpec.needCpuProcesses())
        {
            long st = System.currentTimeMillis();
            metrics.cpuProcesses = collectCpuProcessUsage();
            debugCollectStage(getName(), "cpuProcesses", st);
        }

        if (collectSpec.needMemoryProcesses())
        {
            long st = System.currentTimeMillis();
            metrics.memoryProcesses = collectMemoryProcessUsage();
            debugCollectStage(getName(), "memoryProcesses", st);
        }

        if (collectSpec.needIo())
        {
            long st = System.currentTimeMillis();
            metrics.io = collectIoUsage(sampleMillis);
            debugCollectStage(getName(), "topIo", st);
        }

        if (collectSpec.needNetwork())
        {
            long st = System.currentTimeMillis();
            metrics.network = collectNetworkUsage(sampleMillis);
            debugCollectStage(getName(), "network", st);
        }

        debugCollectEnd(getName(), collectSpec, totalStart);
        return metrics;
    }

    private SystemMetrics.CpuUsage collectCpuUsage(long sampleMillis)
    {
        SystemMetrics.CpuUsage usage = collectCpuByTop(sampleMillis);
        if (usage != null)
            return usage;
        return collectCpuByMxBean(sampleMillis);
    }

    private SystemMetrics.MemoryUsage collectMemoryUsage()
    {
        SystemMetrics.MemoryUsage usage = collectMemoryByVmStat();
        if (usage != null)
            return usage;
        return collectMemoryByMxBean();
    }

    private List<SystemMetrics.DiskUsage> collectDiskUsage()
    {
        List<SystemMetrics.DiskUsage> list = collectDiskByDf();
        if (!list.isEmpty())
            return list;
        return collectDiskByFileStore();
    }

    private SystemMetrics.NetworkUsage collectNetworkUsage(long sampleMillis)
    {
        Map<String, NetCounter> first = readInterfaceCountersByNetstat();
        if (first.isEmpty())
        {
            SystemMetrics.NetworkUsage usage = new SystemMetrics.NetworkUsage();
            usage.available = false;
            usage.sampleMillis = sampleMillis;
            usage.source = "netstat_ib";
            usage.error = "No interface counters from netstat -ib";
            return usage;
        }

        sleepSilently(sampleMillis);
        Map<String, NetCounter> second = readInterfaceCountersByNetstat();
        SystemMetrics.NetworkUsage usage = buildNetworkUsageFromSnapshot(first, second, sampleMillis, "netstat_ib");
        usage.processes = collectProcessNetworkUsage(sampleMillis, usage.totalThroughputBytesPerSec);
        return usage;
    }

    private List<SystemMetrics.ProcessCpuUsage> collectCpuProcessUsage()
    {
        List<SystemMetrics.ProcessCpuUsage> list = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        CommandResult result = executeCommand(5000L, "ps", "-Ao", "pid,comm,%cpu", "-r");
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        for (int i = 1; i < lines.length; i++)
        {
            String line = lines[i];
            if (!hasText(line))
                continue;

            String[] arr = line.trim().split("\\s+", 3);
            if (arr.length < 3)
                continue;

            int pid = (int) parseLong(arr[0], -1L);
            if (pid < 0)
                continue;

            double cpu = parseDouble(arr[2], -1D);
            if (cpu < 0D)
                continue;

            SystemMetrics.ProcessCpuUsage p = new SystemMetrics.ProcessCpuUsage();
            p.available = true;
            p.source = "ps";
            p.pid = pid;
            p.processName = arr[1];
            p.processPath = readProcessPath(pid);
            p.memoryBytes = readProcessMemoryBytes(pid);
            p.cpuRate = normalizeProcessCpuRateFromPercent(cpu);
            list.add(p);
        }
        return list;
    }

    private List<SystemMetrics.ProcessMemoryUsage> collectMemoryProcessUsage()
    {
        List<SystemMetrics.ProcessMemoryUsage> list = new ArrayList<SystemMetrics.ProcessMemoryUsage>();
        CommandResult result = executeCommand(5000L, "ps", "-Ao", "pid,comm,rss", "-r");
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        for (int i = 1; i < lines.length; i++)
        {
            String line = lines[i];
            if (!hasText(line))
                continue;

            String[] arr = line.trim().split("\\s+", 3);
            if (arr.length < 3)
                continue;

            int pid = (int) parseLong(arr[0], -1L);
            if (pid < 0)
                continue;

            SystemMetrics.ProcessMemoryUsage p = new SystemMetrics.ProcessMemoryUsage();
            p.available = true;
            p.source = "ps";
            p.pid = pid;
            p.processName = arr[1];
            p.processPath = readProcessPath(pid);
            p.memoryBytes = kbToBytes(parseLong(arr[2], 0L));
            list.add(p);
        }
        return list;
    }

    private SystemMetrics.IoUsage collectIoUsage(long sampleMillis)
    {
        SystemMetrics.IoUsage usage = new SystemMetrics.IoUsage();
        usage.sampleMillis = sampleMillis;
        usage.source = "lsof_connection_share";

        List<TempProc> first = readProcessConnectionSnapshot();
        if (first.isEmpty())
        {
            usage.available = false;
            usage.error = "No process connection snapshot";
            return usage;
        }

        sleepSilently(sampleMillis);
        List<TempProc> second = readProcessConnectionSnapshot();
        if (second.isEmpty())
        {
            usage.available = false;
            usage.error = "No second process connection snapshot";
            return usage;
        }

        Map<String, TempProc> mapFirst = new HashMap<String, TempProc>();
        for (TempProc s : first)
            mapFirst.put(buildProcKey(s.pid, s.name), s);

        for (TempProc s : second)
        {
            TempProc f = mapFirst.get(buildProcKey(s.pid, s.name));
            if (f == null)
                continue;

            long delta = s.conn - f.conn;
            if (delta <= 0L)
                continue;

            double ioRate = delta * 1024D;
            SystemMetrics.ProcessIoUsage p = new SystemMetrics.ProcessIoUsage();
            p.available = true;
            p.source = "lsof_connection_share";
            p.pid = s.pid;
            p.processName = s.name;
            p.processPath = readProcessPath(s.pid);
            p.memoryBytes = readProcessMemoryBytes(s.pid);
            p.readBytes = 0L;
            p.writeBytes = 0L;
            p.readRateBytesPerSec = ioRate / 2D;
            p.writeRateBytesPerSec = ioRate / 2D;
            p.ioRateBytesPerSec = ioRate;
            usage.processes.add(p);
        }

        Collections.sort(usage.processes, new Comparator<SystemMetrics.ProcessIoUsage>()
        {
            @Override
            public int compare(SystemMetrics.ProcessIoUsage a, SystemMetrics.ProcessIoUsage b)
            {
                double av = a == null ? -1D : a.ioRateBytesPerSec;
                double bv = b == null ? -1D : b.ioRateBytesPerSec;
                return Double.compare(bv, av);
            }
        });

        int max = Math.max(1, OpmTopIoConst.getTopProcSize());
        while (usage.processes.size() > max)
            usage.processes.remove(usage.processes.size() - 1);

        usage.available = !usage.processes.isEmpty();
        if (!usage.available)
            usage.error = "No process io delta found";
        return usage;
    }

    private List<TempProc> readProcessConnectionSnapshot()
    {
        List<TempProc> list = new ArrayList<TempProc>();
        CommandResult result = executeCommand(9000L, "lsof", "-nP", "-iTCP", "-sTCP:ESTABLISHED");
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        if (lines.length <= 1)
            return list;

        Map<String, TempProc> map = new HashMap<String, TempProc>();
        for (int i = 1; i < lines.length; i++)
        {
            String line = lines[i];
            if (!hasText(line))
                continue;

            String[] arr = line.trim().split("\\s+");
            if (arr.length < 2)
                continue;

            int pid = (int) parseLong(arr[1], -1L);
            if (pid < 0)
                continue;

            String name = arr[0].trim();
            String key = buildProcKey(pid, name);
            TempProc s = map.get(key);
            if (s == null)
            {
                s = new TempProc();
                s.pid = pid;
                s.name = name;
                s.conn = 0L;
                map.put(key, s);
            }
            s.conn++;
        }

        list.addAll(map.values());
        return list;
    }

    private String readProcessPath(int pid)
    {
        if (pid < 0)
            return null;
        CommandResult result = executeCommand(4000L, "ps", "-p", String.valueOf(pid), "-o", "comm=");
        if (!result.isSuccess() || !hasText(result.output))
            return null;
        return firstLine(result.output);
    }

    private long readProcessMemoryBytes(int pid)
    {
        if (pid < 0)
            return 0L;
        CommandResult result = executeCommand(4000L, "ps", "-p", String.valueOf(pid), "-o", "rss=");
        if (!result.isSuccess() || !hasText(result.output))
            return 0L;
        return kbToBytes(parseLong(firstLine(result.output), 0L));
    }

    private String buildProcKey(int pid, String name)
    {
        return pid + "|" + (name == null ? "" : name);
    }

    private SystemMetrics.CpuUsage collectCpuByTop(long sampleMillis)
    {
        CommandResult result = executeCommand(6000L, "top", "-l", "2", "-n", "0");
        if (!result.isSuccess() || !hasText(result.output))
            return null;

        String[] lines = result.output.split("\\r?\\n");
        String target = null;
        for (String line : lines)
        {
            if (line != null && line.contains("CPU usage"))
                target = line.trim();
        }
        if (!hasText(target))
            return null;

        Double user = null;
        Double sys = null;
        Double idle = null;

        String[] parts = target.split(",");
        for (String part : parts)
        {
            if (!hasText(part))
                continue;
            String t = part.trim();
            t = t.replace("CPU usage:", "").trim();

            double value = parseFirstPercent(t);
            if (value < 0D)
                continue;

            String lowerPart = lower(t);
            if (lowerPart.contains("user"))
                user = Double.valueOf(value / 100D);
            else if (lowerPart.contains("sys"))
                sys = Double.valueOf(value / 100D);
            else if (lowerPart.contains("idle"))
                idle = Double.valueOf(value / 100D);
        }

        if (idle == null && user == null && sys == null)
            return null;

        SystemMetrics.CpuUsage usage = new SystemMetrics.CpuUsage();
        usage.available = true;
        usage.sampleMillis = sampleMillis;
        usage.source = "top";
        usage.userRate = user == null ? -1D : clampRate(user.doubleValue());
        usage.systemRate = sys == null ? -1D : clampRate(sys.doubleValue());
        usage.idleRate = idle == null ? -1D : clampRate(idle.doubleValue());
        usage.ioWaitRate = -1D;

        if (idle != null)
            usage.usageRate = clampRate(1D - usage.idleRate);
        else
            usage.usageRate = clampRate(nonNegative(usage.userRate) + nonNegative(usage.systemRate));
        return usage;
    }

    private SystemMetrics.MemoryUsage collectMemoryByVmStat()
    {
        CommandResult vmResult = executeCommand(5000L, "vm_stat");
        CommandResult totalResult = executeCommand(3000L, "sysctl", "-n", "hw.memsize");
        if (!vmResult.isSuccess() || !hasText(vmResult.output) || !totalResult.isSuccess() || !hasText(totalResult.output))
            return null;

        long totalBytes = parseLong(firstLine(totalResult.output), -1L);
        if (totalBytes <= 0L)
            return null;

        String[] lines = vmResult.output.split("\\r?\\n");
        long pageSize = 4096L;
        Map<String, Long> pages = new HashMap<String, Long>();

        for (String line : lines)
        {
            if (!hasText(line))
                continue;

            String t = line.trim();
            if (t.contains("page size of") && t.contains("bytes"))
            {
                int start = t.indexOf("page size of") + "page size of".length();
                int end = t.indexOf("bytes", start);
                if (end > start)
                {
                    long size = parseLong(t.substring(start, end).trim(), -1L);
                    if (size > 0L)
                        pageSize = size;
                }
                continue;
            }

            int idx = t.indexOf(':');
            if (idx <= 0)
                continue;
            String key = t.substring(0, idx).trim();
            String valueText = t.substring(idx + 1).trim();
            if (valueText.endsWith("."))
                valueText = valueText.substring(0, valueText.length() - 1);
            valueText = valueText.replace(".", "").trim();
            long count = parseLong(valueText, -1L);
            if (count >= 0L)
                pages.put(key, Long.valueOf(count));
        }

        long freePages = getOrDefault(pages, "Pages free", 0L)
                + getOrDefault(pages, "Pages inactive", 0L)
                + getOrDefault(pages, "Pages speculative", 0L);

        long freeBytes = safeMultiply(freePages, pageSize);
        if (freeBytes > totalBytes)
            freeBytes = totalBytes;
        long usedBytes = safeNonNegative(totalBytes - freeBytes);

        SystemMetrics.MemoryUsage usage = new SystemMetrics.MemoryUsage();
        usage.available = true;
        usage.source = "vm_stat";
        usage.totalBytes = totalBytes;
        usage.freeBytes = freeBytes;
        usage.usedBytes = usedBytes;
        usage.usageRate = calcRate(usage.usedBytes, usage.totalBytes);

        fillSwapBySysctl(usage);
        return usage;
    }

    private void fillSwapBySysctl(SystemMetrics.MemoryUsage usage)
    {
        CommandResult swap = executeCommand(3000L, "sysctl", "vm.swapusage");
        if (!swap.isSuccess() || !hasText(swap.output))
            return;

        String text = swap.output;
        long totalBytes = parseSizeByKey(text, "total");
        long usedBytes = parseSizeByKey(text, "used");
        long freeBytes = parseSizeByKey(text, "free");

        if (totalBytes <= 0L)
            return;
        if (freeBytes < 0L)
            freeBytes = safeNonNegative(totalBytes - usedBytes);
        if (usedBytes < 0L)
            usedBytes = safeNonNegative(totalBytes - freeBytes);

        if (freeBytes > totalBytes)
            freeBytes = totalBytes;
        if (usedBytes > totalBytes)
            usedBytes = totalBytes;

        usage.swapTotalBytes = totalBytes;
        usage.swapUsedBytes = usedBytes;
        usage.swapFreeBytes = freeBytes;
        usage.swapUsageRate = calcRate(usage.swapUsedBytes, usage.swapTotalBytes);
    }

    private Map<String, NetCounter> readInterfaceCountersByNetstat()
    {
        Map<String, NetCounter> map = new HashMap<String, NetCounter>();
        CommandResult result = executeCommand(5000L, "netstat", "-ib");
        if (!result.isSuccess() || !hasText(result.output))
            return map;

        String[] lines = result.output.split("\\r?\\n");
        if (lines.length == 0)
            return map;

        int nameIdx = -1;
        int rxIdx = -1;
        int txIdx = -1;

        String[] header = lines[0].trim().split("\\s+");
        for (int i = 0; i < header.length; i++)
        {
            String col = header[i];
            if ("Name".equalsIgnoreCase(col))
                nameIdx = i;
            else if ("Ibytes".equalsIgnoreCase(col))
                rxIdx = i;
            else if ("Obytes".equalsIgnoreCase(col))
                txIdx = i;
        }

        if (nameIdx < 0 || rxIdx < 0 || txIdx < 0)
            return map;

        for (int i = 1; i < lines.length; i++)
        {
            String line = lines[i];
            if (!hasText(line))
                continue;

            String[] arr = line.trim().split("\\s+");
            if (arr.length <= txIdx)
                continue;

            String name = arr[nameIdx].trim();
            if (!hasText(name))
                continue;

            long rx = parseLong(arr[rxIdx], -1L);
            long tx = parseLong(arr[txIdx], -1L);
            if (rx < 0L || tx < 0L)
                continue;

            NetCounter c = map.get(name);
            if (c == null)
            {
                c = new NetCounter();
                c.name = name;
                c.displayName = name;
                c.rxBytes = 0L;
                c.txBytes = 0L;
                map.put(name, c);
            }

            c.rxBytes = safeNonNegative(c.rxBytes + rx);
            c.txBytes = safeNonNegative(c.txBytes + tx);
        }

        return map;
    }

    private List<SystemMetrics.ProcessNetworkUsage> collectProcessNetworkUsage(long sampleMillis, double totalThroughput)
    {
        List<SystemMetrics.ProcessNetworkUsage> list = new ArrayList<SystemMetrics.ProcessNetworkUsage>();
        CommandResult result = executeCommand(9000L, "lsof", "-nP", "-iTCP", "-sTCP:ESTABLISHED");
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        if (lines.length <= 1)
            return list;

        Map<Integer, TempProc> counter = new HashMap<Integer, TempProc>();
        long totalConn = 0L;

        for (int i = 1; i < lines.length; i++)
        {
            String line = lines[i];
            if (!hasText(line))
                continue;

            String[] arr = line.trim().split("\\s+");
            if (arr.length < 2)
                continue;

            String processName = arr[0].trim();
            int pid = (int) parseLong(arr[1], -1L);
            if (pid < 0)
                continue;

            TempProc p = counter.get(Integer.valueOf(pid));
            if (p == null)
            {
                p = new TempProc();
                p.pid = pid;
                p.name = processName;
                p.conn = 0L;
                counter.put(Integer.valueOf(pid), p);
            }
            p.conn++;
            totalConn++;
        }

        if (totalConn <= 0L || counter.isEmpty())
            return list;

        for (TempProc p : counter.values())
        {
            double ratio = (double) p.conn / (double) totalConn;
            double throughput = totalThroughput * ratio;

            SystemMetrics.ProcessNetworkUsage item = new SystemMetrics.ProcessNetworkUsage();
            item.available = true;
            item.pid = p.pid;
            item.processName = p.name;
            item.source = "lsof_established_connection_share";
            item.rxRateBytesPerSec = throughput / 2D;
            item.txRateBytesPerSec = throughput / 2D;
            item.throughputBytesPerSec = throughput;
            list.add(item);
        }

        Collections.sort(list, new Comparator<SystemMetrics.ProcessNetworkUsage>()
        {
            @Override
            public int compare(SystemMetrics.ProcessNetworkUsage a, SystemMetrics.ProcessNetworkUsage b)
            {
                double av = a == null ? -1D : a.throughputBytesPerSec;
                double bv = b == null ? -1D : b.throughputBytesPerSec;
                return Double.compare(bv, av);
            }
        });
        return list;
    }

    private static long parseSizeByKey(String text, String key)
    {
        if (!hasText(text) || !hasText(key))
            return -1L;

        String lowerText = lower(text);
        String lowerKey = lower(key) + " =";
        int idx = lowerText.indexOf(lowerKey);
        if (idx < 0)
            return -1L;

        String remain = text.substring(idx + lowerKey.length()).trim();
        StringBuilder token = new StringBuilder();
        for (int i = 0; i < remain.length(); i++)
        {
            char c = remain.charAt(i);
            if (Character.isDigit(c) || c == '.' || c == ',')
                token.append(c);
            else
                break;
        }
        if (token.length() == 0)
            return -1L;

        String numberText = token.toString().replace(',', '.');
        double number;
        try
        {
            number = Double.parseDouble(numberText);
        }
        catch (Throwable e)
        {
            return -1L;
        }

        int unitIndex = idx + lowerKey.length() + token.length();
        if (unitIndex >= text.length())
            return -1L;

        char unit = Character.toUpperCase(text.charAt(unitIndex));
        long base = 1L;
        if (unit == 'K')
            base = 1024L;
        else if (unit == 'M')
            base = 1024L * 1024L;
        else if (unit == 'G')
            base = 1024L * 1024L * 1024L;
        else if (unit == 'T')
            base = 1024L * 1024L * 1024L * 1024L;

        double bytes = number * base;
        if (bytes < 0D)
            return -1L;
        if (bytes > Long.MAX_VALUE)
            return Long.MAX_VALUE;
        return (long) bytes;
    }

    private static long safeMultiply(long a, long b)
    {
        if (a <= 0L || b <= 0L)
            return 0L;
        if (a > Long.MAX_VALUE / b)
            return Long.MAX_VALUE;
        return a * b;
    }

    private static String firstLine(String text)
    {
        if (!hasText(text))
            return "";
        String[] arr = text.split("\\r?\\n");
        for (String s : arr)
        {
            if (hasText(s))
                return s.trim();
        }
        return "";
    }

    private static long getOrDefault(Map<String, Long> map, String key, long defaultValue)
    {
        Long value = map.get(key);
        if (value == null)
            return defaultValue;
        return value.longValue();
    }

    private static double parseFirstPercent(String text)
    {
        if (!hasText(text))
            return -1D;

        String t = text.trim();
        int p = t.indexOf('%');
        if (p <= 0)
            return -1D;
        String numberText = t.substring(0, p).trim().replace(',', '.');
        try
        {
            return Double.parseDouble(numberText);
        }
        catch (Throwable e)
        {
            return -1D;
        }
    }

    private static double nonNegative(double value)
    {
        return value < 0D ? 0D : value;
    }

    private static class TempProc
    {
        int pid;
        String name;
        long conn;
    }
}
