package bap.opm.system;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileStore;
import java.nio.file.FileSystems;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.leavay.common.util.ToolUtilities;

import bap.opm.OpmBackendConfig;
import bap.opm.OpmConst;

public abstract class AbstractSystemMetricsProvider implements SystemMetricsProvider
{
    protected static final long DEFAULT_CPU_SAMPLE_MILLIS = 1000L;
    protected static final long MIN_CPU_SAMPLE_MILLIS = 100L;

    @Override
    public SystemMetrics collect(long cpuSampleMillis)
    {
        return collect(cpuSampleMillis, SystemMetricsCollectSpec.all());
    }

    @Override
    public abstract SystemMetrics collect(long cpuSampleMillis, SystemMetricsCollectSpec spec);

    protected SystemMetrics newBaseMetrics()
    {
        SystemMetrics metrics = new SystemMetrics();
        metrics.timestamp = System.currentTimeMillis();
        metrics.hostName = resolveHostName();
        metrics.osName = System.getProperty("os.name");
        metrics.provider = getName();
        return metrics;
    }

    protected long normalizeSampleMillis(long sampleMillis)
    {
        if (sampleMillis <= 0L)
            return DEFAULT_CPU_SAMPLE_MILLIS;
        return Math.max(MIN_CPU_SAMPLE_MILLIS, sampleMillis);
    }

    protected SystemMetrics.CpuUsage collectCpuByMxBean(long sampleMillis)
    {
        SystemMetrics.CpuUsage usage = new SystemMetrics.CpuUsage();
        usage.sampleMillis = normalizeSampleMillis(sampleMillis);
        usage.source = "mxbean";

        java.lang.management.OperatingSystemMXBean bean = ManagementFactory.getOperatingSystemMXBean();
        double load = invokeDoubleMethod(bean, "getSystemCpuLoad", -1D);
        if (load < 0D)
            load = invokeDoubleMethod(bean, "getCpuLoad", -1D);

        if (load >= 0D)
        {
            usage.available = true;
            usage.usageRate = clampRate(load);
            usage.idleRate = clampRate(1D - usage.usageRate);
            usage.userRate = -1D;
            usage.systemRate = -1D;
            usage.ioWaitRate = -1D;
            return usage;
        }

        usage.available = false;
        usage.error = "CPU usage is not available";
        usage.usageRate = -1D;
        usage.userRate = -1D;
        usage.systemRate = -1D;
        usage.idleRate = -1D;
        usage.ioWaitRate = -1D;
        return usage;
    }

    protected SystemMetrics.MemoryUsage collectMemoryByMxBean()
    {
        SystemMetrics.MemoryUsage usage = new SystemMetrics.MemoryUsage();
        usage.source = "mxbean";

        java.lang.management.OperatingSystemMXBean bean = ManagementFactory.getOperatingSystemMXBean();
        long totalBytes = firstNonNegative(invokeLongMethod(bean, "getTotalPhysicalMemorySize", -1L), invokeLongMethod(bean, "getTotalMemorySize", -1L));
        long freeBytes = firstNonNegative(invokeLongMethod(bean, "getFreePhysicalMemorySize", -1L), invokeLongMethod(bean, "getFreeMemorySize", -1L));

        if (totalBytes > 0L && freeBytes >= 0L)
        {
            if (freeBytes > totalBytes)
                freeBytes = totalBytes;
            usage.totalBytes = safeNonNegative(totalBytes);
            usage.freeBytes = safeNonNegative(freeBytes);
            usage.usedBytes = safeNonNegative(usage.totalBytes - usage.freeBytes);
            usage.usageRate = calcRate(usage.usedBytes, usage.totalBytes);

            long swapTotalBytes = invokeLongMethod(bean, "getTotalSwapSpaceSize", 0L);
            long swapFreeBytes = invokeLongMethod(bean, "getFreeSwapSpaceSize", 0L);
            if (swapFreeBytes > swapTotalBytes)
                swapFreeBytes = swapTotalBytes;

            usage.swapTotalBytes = safeNonNegative(swapTotalBytes);
            usage.swapFreeBytes = safeNonNegative(swapFreeBytes);
            usage.swapUsedBytes = safeNonNegative(usage.swapTotalBytes - usage.swapFreeBytes);
            usage.swapUsageRate = calcRate(usage.swapUsedBytes, usage.swapTotalBytes);
            usage.available = true;
            return usage;
        }

        usage.available = false;
        usage.error = "Memory usage is not available";
        return usage;
    }

    protected List<SystemMetrics.DiskUsage> collectDiskByFileStore()
    {
        List<SystemMetrics.DiskUsage> list = new ArrayList<SystemMetrics.DiskUsage>();
        try
        {
            for (FileStore fileStore : FileSystems.getDefault().getFileStores())
            {
                long total = safeSpace(fileStore, true);
                long usable = safeSpace(fileStore, false);
                if (total <= 0L)
                    continue;

                SystemMetrics.DiskUsage usage = new SystemMetrics.DiskUsage();
                usage.fileSystem = safeString(fileStore.name());
                usage.mountPath = safeString(fileStore.toString());
                usage.type = safeString(fileStore.type());
                usage.totalBytes = total;
                usage.freeBytes = usable;
                usage.usedBytes = safeNonNegative(total - usable);
                usage.usageRate = calcRate(usage.usedBytes, usage.totalBytes);
                usage.source = "filestore";
                usage.available = true;
                list.add(usage);
            }
        }
        catch (Throwable e)
        {
        }
        return list;
    }

    protected List<SystemMetrics.DiskUsage> collectDiskByDf()
    {
        List<SystemMetrics.DiskUsage> list = new ArrayList<SystemMetrics.DiskUsage>();

        try
        {
            Process process = new ProcessBuilder("df", "-P", "-k").start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8)))
            {
                String line;
                boolean headerSkipped = false;
                while ((line = reader.readLine()) != null)
                {
                    line = line.trim();
                    if (line.length() == 0)
                        continue;

                    if (!headerSkipped)
                    {
                        headerSkipped = true;
                        continue;
                    }

                    String[] cols = line.split("\\s+");
                    if (cols.length < 6)
                        continue;

                    int mountIndex = cols.length - 1;
                    int percentIndex = cols.length - 2;
                    int availableIndex = cols.length - 3;
                    int usedIndex = cols.length - 4;
                    int totalIndex = cols.length - 5;

                    StringBuilder fs = new StringBuilder(cols[0]);
                    for (int i = 1; i < totalIndex; i++)
                        fs.append(' ').append(cols[i]);

                    long totalKb = parseLong(cols[totalIndex], -1L);
                    long usedKb = parseLong(cols[usedIndex], -1L);
                    long availableKb = parseLong(cols[availableIndex], -1L);
                    if (totalKb < 0L || usedKb < 0L || availableKb < 0L)
                        continue;

                    SystemMetrics.DiskUsage usage = new SystemMetrics.DiskUsage();
                    usage.fileSystem = fs.toString();
                    usage.mountPath = cols[mountIndex];
                    usage.totalBytes = kbToBytes(totalKb);
                    usage.usedBytes = kbToBytes(usedKb);
                    usage.freeBytes = kbToBytes(availableKb);
                    usage.usageRate = parsePercent(cols[percentIndex]);
                    if (usage.usageRate < 0D)
                        usage.usageRate = calcRate(usage.usedBytes, usage.totalBytes);
                    usage.source = "df";
                    usage.available = true;
                    list.add(usage);
                }
            }
            process.waitFor();
        }
        catch (Throwable e)
        {
            return Collections.emptyList();
        }

        return list;
    }

    protected static long invokeLongMethod(Object target, String methodName, long defaultValue)
    {
        if (target == null || methodName == null || methodName.trim().length() == 0)
            return defaultValue;

        try
        {
            Method method = target.getClass().getMethod(methodName);
            Object value = method.invoke(target);
            if (value instanceof Number)
                return ((Number) value).longValue();
            return defaultValue;
        }
        catch (Throwable e)
        {
            return defaultValue;
        }
    }

    protected static double invokeDoubleMethod(Object target, String methodName, double defaultValue)
    {
        if (target == null || methodName == null || methodName.trim().length() == 0)
            return defaultValue;

        try
        {
            Method method = target.getClass().getMethod(methodName);
            Object value = method.invoke(target);
            if (value instanceof Number)
                return ((Number) value).doubleValue();
            return defaultValue;
        }
        catch (Throwable e)
        {
            return defaultValue;
        }
    }

    protected static long firstNonNegative(long first, long second)
    {
        if (first >= 0L)
            return first;
        return second;
    }

    protected static long parseLong(String text, long defaultValue)
    {
        if (text == null)
            return defaultValue;
        try
        {
            return Long.parseLong(text.trim());
        }
        catch (Throwable e)
        {
            return defaultValue;
        }
    }

    protected SystemMetricsCollectSpec normalizeCollectSpec(SystemMetricsCollectSpec spec)
    {
        return spec == null ? SystemMetricsCollectSpec.all() : spec;
    }

    protected boolean isCollectDebugEnabled()
    {
        String force = System.getProperty("opm.collect.debug");
        if ("1".equals(force)
                || "true".equalsIgnoreCase(force)
                || "yes".equalsIgnoreCase(force)
                || "on".equalsIgnoreCase(force))
            return true;

        String forceEnv = System.getenv("OPM_COLLECT_DEBUG");
        if ("1".equals(forceEnv)
                || "true".equalsIgnoreCase(forceEnv)
                || "yes".equalsIgnoreCase(forceEnv)
                || "on".equalsIgnoreCase(forceEnv))
            return true;

        try
        {
            return OpmBackendConfig.isDebugEnable();
        }
        catch (Throwable err)
        {
            return false;
        }
    }

    protected void debugCollectStart(String provider, SystemMetricsCollectSpec spec, long sampleMillis)
    {
        if (!isCollectDebugEnabled())
            return;
        ToolUtilities.info(OpmConst.LOG, "[opm.collect.start] provider=" + safeString(provider)
                + ", sampleMillis=" + sampleMillis
                + ", spec=" + safeString(spec == null ? null : spec.toString()));
    }

    protected void debugCollectStage(String provider, String stage, long startMillis)
    {
        if (!isCollectDebugEnabled())
            return;

        long cost = System.currentTimeMillis() - startMillis;
        ToolUtilities.info(OpmConst.LOG, "[opm.collect.stage] provider=" + safeString(provider)
                + ", stage=" + safeString(stage)
                + ", costMs=" + cost);
    }

    protected void debugCollectEnd(String provider, SystemMetricsCollectSpec spec, long startMillis)
    {
        if (!isCollectDebugEnabled())
            return;

        long cost = System.currentTimeMillis() - startMillis;
        ToolUtilities.info(OpmConst.LOG, "[opm.collect.end] provider=" + safeString(provider)
                + ", costMs=" + cost
                + ", spec=" + safeString(spec == null ? null : spec.toString()));
    }

    protected static String buildCommandText(String... command)
    {
        if (command == null || command.length == 0)
            return "";

        StringBuilder sb = new StringBuilder(128);
        for (String one : command)
        {
            if (sb.length() > 0)
                sb.append(' ');

            if (one == null)
                continue;

            String t = one;
            if (t.indexOf(' ') >= 0)
                sb.append('"').append(t.replace("\"", "\\\"")).append('"');
            else
                sb.append(t);
        }
        return sb.toString();
    }

    protected CommandResult executeCommand(long timeoutMillis, String... command)
    {
        if (command == null || command.length == 0)
            return new CommandResult(-1, "", "Empty command", false);

        Process process = null;
        long start = System.currentTimeMillis();
        String cmd = buildCommandText(command);
        OutputCollector collector = null;
        try
        {
            if (isCollectDebugEnabled())
            {
                ToolUtilities.info(OpmConst.LOG, "[opm.cmd.start] provider=" + getName()
                        + ", timeoutMs=" + timeoutMillis
                        + ", cmd=" + cmd);
            }

            process = new ProcessBuilder(command).redirectErrorStream(true).start();
            collector = OutputCollector.start(process.getInputStream());

            boolean finished = process.waitFor(timeoutMillis, TimeUnit.MILLISECONDS);
            if (!finished)
            {
                process.destroyForcibly();
                String output = collector == null ? "" : collector.awaitText(1500L);
                long cost = System.currentTimeMillis() - start;
                ToolUtilities.warning(OpmConst.LOG, "[opm.cmd.timeout] provider=" + getName()
                        + ", timeoutMs=" + timeoutMillis
                        + ", costMs=" + cost
                        + ", outputLen=" + (output == null ? 0 : output.length())
                        + ", cmd=" + cmd);
                return new CommandResult(-1, output == null ? "" : output, "Command timeout", false);
            }

            int exitCode = process.exitValue();
            String output = collector == null ? "" : collector.awaitText(1500L);
            if (output == null)
                output = "";
            if (isCollectDebugEnabled())
            {
                long cost = System.currentTimeMillis() - start;
                ToolUtilities.info(OpmConst.LOG, "[opm.cmd.end] provider=" + getName()
                        + ", exit=" + exitCode
                        + ", costMs=" + cost
                        + ", outputLen=" + (output == null ? 0 : output.length())
                        + ", cmd=" + cmd);
            }
            return new CommandResult(exitCode, output, null, true);
        }
        catch (Throwable e)
        {
            long cost = System.currentTimeMillis() - start;
            ToolUtilities.warning(OpmConst.LOG, "[opm.cmd.error] provider=" + getName()
                    + ", costMs=" + cost
                    + ", cmd=" + cmd, e);
            return new CommandResult(-1, "", e.getMessage(), false);
        }
    }

    protected static Map<String, String> parseKeyValueLines(String text)
    {
        Map<String, String> map = new LinkedHashMap<String, String>();
        if (text == null || text.trim().length() == 0)
            return map;

        String[] lines = text.split("\\r?\\n");
        for (String line : lines)
        {
            if (line == null)
                continue;

            String t = line.trim();
            if (t.length() == 0)
                continue;

            int idx = t.indexOf('=');
            if (idx <= 0)
                continue;

            String key = t.substring(0, idx).trim();
            String value = t.substring(idx + 1).trim();
            if (key.length() == 0)
                continue;
            map.put(key, value);
        }

        return map;
    }

    protected static boolean hasText(String text)
    {
        return text != null && text.trim().length() > 0;
    }

    protected static String lower(String text)
    {
        if (text == null)
            return "";
        return text.toLowerCase(java.util.Locale.ROOT);
    }

    protected static double parsePercent(String raw)
    {
        if (raw == null)
            return -1D;
        String v = raw.trim();
        if (v.endsWith("%"))
            v = v.substring(0, v.length() - 1);
        long p = parseLong(v, -1L);
        if (p < 0L)
            return -1D;
        return clampRate((double) p / 100D);
    }

    /**
     * 将进程CPU百分比（可能基于单核且可>100）归一化为“占整机总CPU资源”的绝对占比（0~1）。
     */
    protected static double normalizeProcessCpuRateFromPercent(double processCpuPercent)
    {
        if (Double.isNaN(processCpuPercent) || Double.isInfinite(processCpuPercent) || processCpuPercent < 0D)
            return -1D;

        int cores = Runtime.getRuntime().availableProcessors();
        if (cores <= 0)
            cores = 1;

        double rate = processCpuPercent / (100D * (double) cores);
        return clampRate(rate);
    }

    protected static long kbToBytes(long kb)
    {
        if (kb <= 0L)
            return 0L;
        if (kb > Long.MAX_VALUE / 1024L)
            return Long.MAX_VALUE;
        return kb * 1024L;
    }

    protected static double calcRate(long used, long total)
    {
        if (total <= 0L)
            return -1D;
        return clampRate((double) used / (double) total);
    }

    protected static double clampRate(double value)
    {
        if (Double.isNaN(value) || Double.isInfinite(value))
            return -1D;
        if (value < 0D)
            return 0D;
        if (value > 1D)
            return 1D;
        return value;
    }

    protected static void sleepSilently(long millis)
    {
        try
        {
            Thread.sleep(millis);
        }
        catch (InterruptedException e)
        {
            Thread.currentThread().interrupt();
        }
    }

    protected static long safeNonNegative(long value)
    {
        return value < 0L ? 0L : value;
    }

    protected static String resolveHostName()
    {
        try
        {
            return InetAddress.getLocalHost().getHostName();
        }
        catch (Throwable e)
        {
            String hostName = System.getenv("HOSTNAME");
            if (hostName != null && hostName.trim().length() > 0)
                return hostName.trim();
            return "unknown";
        }
    }

    protected static String safeString(String text)
    {
        if (text == null)
            return "";
        return text;
    }

    protected static double parseDouble(String text, double defaultValue)
    {
        if (!hasText(text))
            return defaultValue;
        try
        {
            return Double.parseDouble(text.trim().replace(',', '.'));
        }
        catch (Throwable e)
        {
            return defaultValue;
        }
    }

    protected static long safeSpace(FileStore fileStore, boolean total)
    {
        try
        {
            return total ? fileStore.getTotalSpace() : fileStore.getUsableSpace();
        }
        catch (Throwable e)
        {
            return -1L;
        }
    }

    public static String formatPercent(double rate)
    {
        if (rate < 0D)
            return "N/A";
        return String.format(java.util.Locale.US, "%.2f%%", Double.valueOf(rate * 100D));
    }

    public static String formatBytes(long bytes)
    {
        if (bytes < 0L)
            return "N/A";

        String[] units = new String[] { "B", "KB", "MB", "GB", "TB", "PB" };
        double value = bytes;
        int idx = 0;
        while (value >= 1024D && idx < units.length - 1)
        {
            value = value / 1024D;
            idx++;
        }

        if (idx == 0)
            return Long.toString(bytes) + " " + units[idx];
        return String.format(java.util.Locale.US, "%.2f %s", Double.valueOf(value), units[idx]);
    }

    public static String formatRate(double bytesPerSec)
    {
        if (bytesPerSec < 0D || Double.isNaN(bytesPerSec) || Double.isInfinite(bytesPerSec))
            return "N/A";

        String[] units = new String[] { "B/s", "KB/s", "MB/s", "GB/s", "TB/s" };
        double value = bytesPerSec;
        int idx = 0;
        while (value >= 1024D && idx < units.length - 1)
        {
            value = value / 1024D;
            idx++;
        }
        return String.format(java.util.Locale.US, "%.2f %s", Double.valueOf(value), units[idx]);
    }

    protected SystemMetrics.NetworkUsage buildNetworkUsageFromSnapshot(Map<String, NetCounter> first, Map<String, NetCounter> second, long sampleMillis, String source)
    {
        SystemMetrics.NetworkUsage usage = new SystemMetrics.NetworkUsage();
        usage.sampleMillis = sampleMillis;
        usage.source = source;

        if (first == null || second == null || first.isEmpty() || second.isEmpty())
        {
            usage.available = false;
            usage.error = "Network counters are not available";
            return usage;
        }

        double rxRateSum = 0D;
        double txRateSum = 0D;
        long totalRxBytes = 0L;
        long totalTxBytes = 0L;

        for (Map.Entry<String, NetCounter> e : second.entrySet())
        {
            String key = e.getKey();
            NetCounter s = e.getValue();
            NetCounter f = first.get(key);
            if (s == null || f == null)
                continue;

            long deltaRx = s.rxBytes - f.rxBytes;
            long deltaTx = s.txBytes - f.txBytes;
            if (deltaRx < 0L)
                deltaRx = 0L;
            if (deltaTx < 0L)
                deltaTx = 0L;

            double rxRate = deltaRx * 1000D / (double) sampleMillis;
            double txRate = deltaTx * 1000D / (double) sampleMillis;

            SystemMetrics.NetworkInterfaceUsage itf = new SystemMetrics.NetworkInterfaceUsage();
            itf.available = true;
            itf.name = safeString(s.name);
            itf.displayName = safeString(s.displayName);
            itf.rxBytes = s.rxBytes;
            itf.txBytes = s.txBytes;
            itf.rxRateBytesPerSec = rxRate;
            itf.txRateBytesPerSec = txRate;
            itf.throughputBytesPerSec = rxRate + txRate;
            usage.interfaces.add(itf);

            rxRateSum += rxRate;
            txRateSum += txRate;
            totalRxBytes = safeNonNegative(totalRxBytes + safeNonNegative(s.rxBytes));
            totalTxBytes = safeNonNegative(totalTxBytes + safeNonNegative(s.txBytes));
        }

        usage.totalRxBytes = totalRxBytes;
        usage.totalTxBytes = totalTxBytes;
        usage.totalRxRateBytesPerSec = rxRateSum;
        usage.totalTxRateBytesPerSec = txRateSum;
        usage.totalThroughputBytesPerSec = rxRateSum + txRateSum;
        usage.available = !usage.interfaces.isEmpty();
        if (!usage.available)
            usage.error = "No network interface counters found";
        return usage;
    }

    public static void printMetrics(SystemMetrics metrics, long sampleMillis)
    {
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(metrics.timestamp));
        System.out.println("=== System Metrics ===");
        System.out.println("time=" + time
                + ", host=" + safeString(metrics.hostName)
                + ", os=" + safeString(metrics.osName)
                + ", provider=" + safeString(metrics.provider)
                + ", cpuSampleMillis=" + sampleMillis);
        System.out.println();

        printCpu(metrics.cpu);
        System.out.println();
        printMemory(metrics.memory);
        System.out.println();
        printDisks(metrics.disks);
        System.out.println();
        printNetwork(metrics.network);
    }

    private static void printCpu(SystemMetrics.CpuUsage cpu)
    {
        System.out.println("[CPU]");
        if (cpu == null || !cpu.available)
        {
            String msg = cpu == null ? "CPU info is null" : cpu.error;
            System.out.println("available=false, error=" + safeString(msg));
            return;
        }

        System.out.println("available=true"
                + ", source=" + safeString(cpu.source)
                + ", usage=" + formatPercent(cpu.usageRate)
                + ", user=" + formatPercent(cpu.userRate)
                + ", system=" + formatPercent(cpu.systemRate)
                + ", iowait=" + formatPercent(cpu.ioWaitRate)
                + ", idle=" + formatPercent(cpu.idleRate));
    }

    private static void printMemory(SystemMetrics.MemoryUsage memory)
    {
        System.out.println("[MEMORY]");
        if (memory == null || !memory.available)
        {
            String msg = memory == null ? "Memory info is null" : memory.error;
            System.out.println("available=false, error=" + safeString(msg));
            return;
        }

        System.out.println("available=true"
                + ", source=" + safeString(memory.source)
                + ", used=" + formatBytes(memory.usedBytes)
                + ", total=" + formatBytes(memory.totalBytes)
                + ", usage=" + formatPercent(memory.usageRate));
        System.out.println("swapUsed=" + formatBytes(memory.swapUsedBytes)
                + ", swapTotal=" + formatBytes(memory.swapTotalBytes)
                + ", swapUsage=" + formatPercent(memory.swapUsageRate));
    }

    private static void printDisks(List<SystemMetrics.DiskUsage> disks)
    {
        System.out.println("[DISK]");
        if (disks == null || disks.isEmpty())
        {
            System.out.println("No disk info found");
            return;
        }

        List<SystemMetrics.DiskUsage> ordered = new ArrayList<SystemMetrics.DiskUsage>(disks);
        Collections.sort(ordered, new Comparator<SystemMetrics.DiskUsage>()
        {
            @Override
            public int compare(SystemMetrics.DiskUsage a, SystemMetrics.DiskUsage b)
            {
                double av = a == null ? -1D : a.usageRate;
                double bv = b == null ? -1D : b.usageRate;
                return Double.compare(bv, av);
            }
        });

        for (SystemMetrics.DiskUsage disk : ordered)
        {
            if (disk == null)
                continue;
            System.out.println("mount=" + safeString(disk.mountPath)
                    + ", fs=" + safeString(disk.fileSystem)
                    + ", used=" + formatBytes(disk.usedBytes)
                    + ", total=" + formatBytes(disk.totalBytes)
                    + ", usage=" + formatPercent(disk.usageRate)
                    + ", source=" + safeString(disk.source));
        }
    }

    private static void printNetwork(SystemMetrics.NetworkUsage network)
    {
        System.out.println("[NETWORK]");
        if (network == null || !network.available)
        {
            String msg = network == null ? "Network info is null" : network.error;
            System.out.println("available=false, error=" + safeString(msg));
            return;
        }

        System.out.println("available=true"
                + ", source=" + safeString(network.source)
                + ", rxRate=" + formatRate(network.totalRxRateBytesPerSec)
                + ", txRate=" + formatRate(network.totalTxRateBytesPerSec)
                + ", throughput=" + formatRate(network.totalThroughputBytesPerSec));

        if (network.interfaces != null)
        {
            for (int i = 0; i < network.interfaces.size() && i < 8; i++)
            {
                SystemMetrics.NetworkInterfaceUsage itf = network.interfaces.get(i);
                if (itf == null)
                    continue;
                System.out.println("if=" + safeString(itf.name)
                        + ", rxRate=" + formatRate(itf.rxRateBytesPerSec)
                        + ", txRate=" + formatRate(itf.txRateBytesPerSec)
                        + ", throughput=" + formatRate(itf.throughputBytesPerSec));
            }
        }

        if (network.processes != null && !network.processes.isEmpty())
        {
            System.out.println("topProcessNetwork:");
            for (int i = 0; i < network.processes.size() && i < 8; i++)
            {
                SystemMetrics.ProcessNetworkUsage p = network.processes.get(i);
                if (p == null)
                    continue;
                System.out.println("pid=" + p.pid
                        + ", name=" + safeString(p.processName)
                        + ", rxRate=" + formatRate(p.rxRateBytesPerSec)
                        + ", txRate=" + formatRate(p.txRateBytesPerSec)
                        + ", throughput=" + formatRate(p.throughputBytesPerSec)
                        + ", source=" + safeString(p.source));
            }
        }
    }

    protected static class NetCounter
    {
        public String name;
        public String displayName;
        public long rxBytes;
        public long txBytes;
    }

    protected static class CommandResult
    {
        public final int exitCode;
        public final String output;
        public final String error;
        public final boolean started;

        CommandResult(int exitCode, String output, String error, boolean started)
        {
            this.exitCode = exitCode;
            this.output = output;
            this.error = error;
            this.started = started;
        }

        public boolean isSuccess()
        {
            return started && exitCode == 0;
        }
    }

    protected static class OutputCollector implements Runnable
    {
        protected final InputStream _in;
        protected final ByteArrayOutputStream _out = new ByteArrayOutputStream();
        protected final Thread _thread;

        protected OutputCollector(InputStream in)
        {
            _in = in;
            _thread = new Thread(this, "OPM-CmdOutput-" + System.nanoTime());
            _thread.setDaemon(true);
        }

        public static OutputCollector start(InputStream in)
        {
            OutputCollector collector = new OutputCollector(in);
            collector._thread.start();
            return collector;
        }

        @Override
        public void run()
        {
            if (_in == null)
                return;

            byte[] buf = new byte[4096];
            int len;
            try
            {
                while ((len = _in.read(buf)) >= 0)
                    _out.write(buf, 0, len);
            }
            catch (Throwable ignore)
            {
            }
            finally
            {
                try
                {
                    _in.close();
                }
                catch (Throwable ignore)
                {
                }
            }
        }

        public String awaitText(long waitMillis)
        {
            try
            {
                _thread.join(waitMillis);
            }
            catch (InterruptedException e)
            {
                Thread.currentThread().interrupt();
            }
            return new String(_out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
