package bap.opm.system;

import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import com.leavay.common.util.ToolUtilities;

import bap.opm.OpmConst;
import bap.opm.collector.topcpu.OpmTopCpuConst;
import bap.opm.collector.topio.OpmTopIoConst;

public class WindowsSystemMetricsProvider extends AbstractSystemMetricsProvider
{
    protected static final int COLLECTOR_WORKERS = Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors()));
    protected static final AtomicInteger COLLECTOR_THREAD_SEQ = new AtomicInteger(1);
    protected static final ExecutorService COLLECTOR_EXECUTOR = Executors.newFixedThreadPool(COLLECTOR_WORKERS, new ThreadFactory()
    {
        @Override
        public Thread newThread(Runnable run)
        {
            Thread t = new Thread(run, "OPM-WindowsCollect-" + COLLECTOR_THREAD_SEQ.getAndIncrement());
            t.setDaemon(true);
            return t;
        }
    });

    @Override
    public boolean supports(String osName)
    {
        return lower(osName).contains("win");
    }

    @Override
    public String getName()
    {
        return "windows";
    }

    @Override
    public SystemMetrics collect(long cpuSampleMillis)
    {
        return collect(cpuSampleMillis, SystemMetricsCollectSpec.all());
    }

    @Override
    public SystemMetrics collect(long cpuSampleMillis, SystemMetricsCollectSpec spec)
    {
        SystemMetricsCollectSpec collectSpec = normalizeCollectSpec(spec);
        long sampleMillis = normalizeSampleMillis(cpuSampleMillis);
        final long sample = sampleMillis;
        SystemMetrics metrics = newBaseMetrics();

        long totalStart = System.currentTimeMillis();
        debugCollectStart(getName(), collectSpec, sampleMillis);

        Future<SystemMetrics.CpuUsage> cpuTask = null;
        Future<SystemMetrics.MemoryUsage> memoryTask = null;
        Future<List<SystemMetrics.DiskUsage>> diskTask = null;
        Future<List<SystemMetrics.ProcessCpuUsage>> cpuProcTask = null;
        Future<SystemMetrics.IoUsage> ioTask = null;
        Future<SystemMetrics.NetworkUsage> netTask = null;

        if (collectSpec.needCpu())
            cpuTask = submitStageTask("topCpu", new StageCallable<SystemMetrics.CpuUsage>()
            {
                @Override
                public SystemMetrics.CpuUsage call() throws Exception
                {
                    return collectCpuUsage(sample);
                }
            });

        if (collectSpec.needMemory())
            memoryTask = submitStageTask("topMemory", new StageCallable<SystemMetrics.MemoryUsage>()
            {
                @Override
                public SystemMetrics.MemoryUsage call() throws Exception
                {
                    return collectMemoryUsage();
                }
            });

        if (collectSpec.needDisk())
            diskTask = submitStageTask("disk", new StageCallable<List<SystemMetrics.DiskUsage>>()
            {
                @Override
                public List<SystemMetrics.DiskUsage> call() throws Exception
                {
                    return collectDiskUsage();
                }
            });

        if (collectSpec.needCpuProcesses())
            cpuProcTask = submitStageTask("cpuProcesses", new StageCallable<List<SystemMetrics.ProcessCpuUsage>>()
            {
                @Override
                public List<SystemMetrics.ProcessCpuUsage> call() throws Exception
                {
                    return collectCpuProcessUsage();
                }
            });

        Future<List<SystemMetrics.ProcessMemoryUsage>> memoryProcTask = null;
        if (collectSpec.needMemoryProcesses())
            memoryProcTask = submitStageTask("memoryProcesses", new StageCallable<List<SystemMetrics.ProcessMemoryUsage>>()
            {
                @Override
                public List<SystemMetrics.ProcessMemoryUsage> call() throws Exception
                {
                    return collectMemoryProcessUsage();
                }
            });

        if (collectSpec.needIo())
            ioTask = submitStageTask("topIo", new StageCallable<SystemMetrics.IoUsage>()
            {
                @Override
                public SystemMetrics.IoUsage call() throws Exception
                {
                    return collectIoUsage(sample);
                }
            });

        if (collectSpec.needNetwork())
            netTask = submitStageTask("network", new StageCallable<SystemMetrics.NetworkUsage>()
            {
                @Override
                public SystemMetrics.NetworkUsage call() throws Exception
                {
                    return collectNetworkUsage(sample, collectSpec.needNetworkProcesses());
                }
            });

        if (cpuTask != null)
        {
            SystemMetrics.CpuUsage cpu = awaitStageTask(cpuTask, "topCpu");
            if (cpu != null)
                metrics.cpu = cpu;
        }

        if (memoryTask != null)
        {
            SystemMetrics.MemoryUsage memory = awaitStageTask(memoryTask, "topMemory");
            if (memory != null)
                metrics.memory = memory;
        }

        if (diskTask != null)
        {
            List<SystemMetrics.DiskUsage> disks = awaitStageTask(diskTask, "disk");
            if (disks != null)
                metrics.disks = disks;
        }

        if (cpuProcTask != null)
        {
            List<SystemMetrics.ProcessCpuUsage> cpuProcesses = awaitStageTask(cpuProcTask, "cpuProcesses");
            if (cpuProcesses != null)
                metrics.cpuProcesses = cpuProcesses;
        }

        if (memoryProcTask != null)
        {
            List<SystemMetrics.ProcessMemoryUsage> memoryProcesses = awaitStageTask(memoryProcTask, "memoryProcesses");
            if (memoryProcesses != null)
                metrics.memoryProcesses = memoryProcesses;
        }

        if (ioTask != null)
        {
            SystemMetrics.IoUsage io = awaitStageTask(ioTask, "topIo");
            if (io != null)
                metrics.io = io;
        }

        if (netTask != null)
        {
            SystemMetrics.NetworkUsage net = awaitStageTask(netTask, "network");
            if (net != null)
                metrics.network = net;
        }

        debugCollectEnd(getName(), collectSpec, totalStart);
        return metrics;
    }

    private <T> Future<T> submitStageTask(final String stage, final StageCallable<T> callable)
    {
        return COLLECTOR_EXECUTOR.submit(new Callable<T>()
        {
            @Override
            public T call() throws Exception
            {
                long st = System.currentTimeMillis();
                try
                {
                    return callable.call();
                }
                finally
                {
                    debugCollectStage(getName(), stage, st);
                }
            }
        });
    }

    private <T> T awaitStageTask(Future<T> task, String stage)
    {
        if (task == null)
            return null;

        try
        {
            return task.get();
        }
        catch (InterruptedException e)
        {
            Thread.currentThread().interrupt();
            ToolUtilities.warning(OpmConst.LOG, "[opm.collect.stage.error] provider=" + getName() + ", stage=" + stage + ", interrupted");
            return null;
        }
        catch (Throwable err)
        {
            ToolUtilities.warning(OpmConst.LOG, "[opm.collect.stage.error] provider=" + getName() + ", stage=" + stage, err);
            return null;
        }
    }

    private static interface StageCallable<T>
    {
        T call() throws Exception;
    }

    private SystemMetrics.CpuUsage collectCpuUsage(long sampleMillis)
    {
        SystemMetrics.CpuUsage usage = collectCpuByWmic(sampleMillis);
        if (usage != null)
            return usage;

        usage = collectCpuByPowerShell(sampleMillis);
        if (usage != null)
            return usage;

        return collectCpuByMxBean(sampleMillis);
    }

    private SystemMetrics.MemoryUsage collectMemoryUsage()
    {
        SystemMetrics.MemoryUsage usage = collectMemoryByWmic();
        if (usage != null)
            return usage;

        usage = collectMemoryByPowerShell();
        if (usage != null)
            return usage;

        return collectMemoryByMxBean();
    }

    private List<SystemMetrics.DiskUsage> collectDiskUsage()
    {
        List<SystemMetrics.DiskUsage> list = collectDiskByWmic();
        if (!list.isEmpty())
            return list;

        list = collectDiskByPowerShell();
        if (!list.isEmpty())
            return list;

        return collectDiskByFileStore();
    }

    private List<SystemMetrics.ProcessCpuUsage> collectCpuProcessUsage()
    {
        List<SystemMetrics.ProcessCpuUsage> list = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        Map<Integer, ProcMeta> metaMap = readProcessMetaMap();
        String script = "Get-Counter '\\Process(*)\\% Processor Time' | Select-Object -ExpandProperty CounterSamples | "
                + "Sort-Object CookedValue -Descending | Select-Object -First 256"
                + " | ForEach-Object { Write-Output ($_.Path + ',' + $_.CookedValue) }";
        CommandResult result = executeCommand(8000L, "powershell", "-NoProfile", "-Command", script);
        if (!hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf(',') < 0)
                continue;

            int idx = line.lastIndexOf(',');
            if (idx <= 0)
                continue;

            String path = line.substring(0, idx).trim();
            double cpu = parseDouble(line.substring(idx + 1).trim(), -1D);
            if (cpu < 0D)
                continue;

            String procName = parseProcessNameFromPerfPath(path);
            if (!hasText(procName) || "_total".equalsIgnoreCase(procName) || "idle".equalsIgnoreCase(procName))
                continue;

            SystemMetrics.ProcessCpuUsage p = new SystemMetrics.ProcessCpuUsage();
            p.available = true;
            p.source = "powershell_perfcounter";
            p.pid = -1;
            p.processName = procName;
            p.cpuRate = normalizeProcessCpuRateFromPercent(cpu);
            fillProcessMeta(p, metaMap.get(Integer.valueOf(p.pid)));
            list.add(p);
        }

        if (list.isEmpty())
            list.addAll(readCpuProcessByWmic(256, metaMap));
        return list;
    }

    private List<SystemMetrics.ProcessMemoryUsage> collectMemoryProcessUsage()
    {
        List<SystemMetrics.ProcessMemoryUsage> list = new ArrayList<SystemMetrics.ProcessMemoryUsage>();
        Map<Integer, ProcMeta> metaMap = readProcessMetaMap();
        for (ProcMeta meta : metaMap.values())
        {
            if (meta == null)
                continue;
            SystemMetrics.ProcessMemoryUsage p = new SystemMetrics.ProcessMemoryUsage();
            p.available = true;
            p.source = "cim_win32_process";
            p.pid = meta.pid;
            p.processName = meta.processName;
            p.processPath = meta.processPath;
            p.memoryBytes = meta.memoryBytes;
            list.add(p);
        }
        Collections.sort(list, new Comparator<SystemMetrics.ProcessMemoryUsage>()
        {
            @Override
            public int compare(SystemMetrics.ProcessMemoryUsage a, SystemMetrics.ProcessMemoryUsage b)
            {
                long av = a == null ? -1L : a.memoryBytes;
                long bv = b == null ? -1L : b.memoryBytes;
                return Long.compare(bv, av);
            }
        });
        return list;
    }

    private List<SystemMetrics.ProcessCpuUsage> readCpuProcessByWmic(int max, Map<Integer, ProcMeta> metaMap)
    {
        List<SystemMetrics.ProcessCpuUsage> list = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        CommandResult result = executeCommand(8000L, "cmd", "/c",
                "wmic path Win32_PerfFormattedData_PerfProc_Process get IDProcess,Name,PercentProcessorTime /format:csv");
        if (!hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf(',') < 0)
                continue;

            String[] arr = line.trim().split(",");
            if (arr.length < 4)
                continue;

            int len = arr.length;
            int pid = (int) parseLong(arr[len - 3], -1L);
            String name = arr[len - 2].trim();
            double pct = parseDouble(arr[len - 1], -1D);
            if (pid < 0 || !hasText(name) || pct < 0D)
                continue;
            if ("_Total".equalsIgnoreCase(name) || "Idle".equalsIgnoreCase(name))
                continue;

            SystemMetrics.ProcessCpuUsage p = new SystemMetrics.ProcessCpuUsage();
            p.available = true;
            p.source = "wmic_perfproc";
            p.pid = pid;
            p.processName = name;
            p.cpuRate = normalizeProcessCpuRateFromPercent(pct);
            fillProcessMeta(p, metaMap == null ? null : metaMap.get(Integer.valueOf(pid)));
            list.add(p);
        }

        Collections.sort(list, new Comparator<SystemMetrics.ProcessCpuUsage>()
        {
            @Override
            public int compare(SystemMetrics.ProcessCpuUsage a, SystemMetrics.ProcessCpuUsage b)
            {
                double av = a == null ? -1D : a.cpuRate;
                double bv = b == null ? -1D : b.cpuRate;
                return Double.compare(bv, av);
            }
        });

        while (list.size() > max)
            list.remove(list.size() - 1);

        return list;
    }

    private SystemMetrics.IoUsage collectIoUsage(long sampleMillis)
    {
        SystemMetrics.IoUsage usage = new SystemMetrics.IoUsage();
        usage.sampleMillis = sampleMillis;
        usage.source = "powershell_getprocess";
        Map<Integer, ProcMeta> metaMap = readProcessMetaMap();

        List<ProcIoSnapshot> first = readProcessIoSnapshot();
        if (first.isEmpty())
        {
            usage.processes.addAll(readProcessIoRateByCounter(metaMap));
            usage.available = !usage.processes.isEmpty();
            if (!usage.available)
                usage.error = "No process IO snapshot";
            return usage;
        }

        sleepSilently(sampleMillis);
        List<ProcIoSnapshot> second = readProcessIoSnapshot();
        if (second.isEmpty())
        {
            usage.processes.addAll(readProcessIoRateByCounter(metaMap));
            usage.available = !usage.processes.isEmpty();
            if (!usage.available)
                usage.error = "No second process IO snapshot";
            return usage;
        }

        Map<String, ProcIoSnapshot> mapFirst = new java.util.HashMap<String, ProcIoSnapshot>();
        for (ProcIoSnapshot s : first)
            mapFirst.put(buildProcKey(s.pid, s.name), s);

        for (ProcIoSnapshot s : second)
        {
            ProcIoSnapshot f = mapFirst.get(buildProcKey(s.pid, s.name));
            if (f == null)
                continue;

            long deltaRead = s.readBytes - f.readBytes;
            long deltaWrite = s.writeBytes - f.writeBytes;
            if (deltaRead < 0L)
                deltaRead = 0L;
            if (deltaWrite < 0L)
                deltaWrite = 0L;

            SystemMetrics.ProcessIoUsage p = new SystemMetrics.ProcessIoUsage();
            p.available = true;
            p.source = "powershell_getprocess";
            p.pid = s.pid;
            p.processName = s.name;
            fillProcessMeta(p, metaMap.get(Integer.valueOf(s.pid)));
            p.readBytes = s.readBytes;
            p.writeBytes = s.writeBytes;
            p.readRateBytesPerSec = deltaRead * 1000D / (double) sampleMillis;
            p.writeRateBytesPerSec = deltaWrite * 1000D / (double) sampleMillis;
            p.ioRateBytesPerSec = p.readRateBytesPerSec + p.writeRateBytesPerSec;
            usage.processes.add(p);
        }

        if (usage.processes.isEmpty())
            usage.processes.addAll(readProcessIoRateByCounter(metaMap));

        Collections.sort(usage.processes, new Comparator<SystemMetrics.ProcessIoUsage>()
        {
            @Override
            public int compare(SystemMetrics.ProcessIoUsage a, SystemMetrics.ProcessIoUsage b)
            {
                double av = a == null ? -1D : a.ioRateBytesPerSec;
                double bv = b == null ? -1D : b.ioRateBytesPerSec;
                return Double.compare(bv, av);
            }
        });

        int max = Math.max(1, OpmTopIoConst.getTopProcSize());
        while (usage.processes.size() > max)
            usage.processes.remove(usage.processes.size() - 1);

        usage.available = !usage.processes.isEmpty();
        if (!usage.available)
            usage.error = "No process io delta found";
        return usage;
    }

    private List<SystemMetrics.ProcessIoUsage> readProcessIoRateByCounter(Map<Integer, ProcMeta> metaMap)
    {
        List<SystemMetrics.ProcessIoUsage> list = new ArrayList<SystemMetrics.ProcessIoUsage>();
        int max = Math.max(1, OpmTopIoConst.getTopProcSize());

        String script = "Get-Counter '\\Process(*)\\IO Data Bytes/sec' | Select-Object -ExpandProperty CounterSamples | "
                + "Sort-Object CookedValue -Descending | Select-Object -First " + (max + 8)
                + " | ForEach-Object { Write-Output ($_.Path + ',' + $_.CookedValue) }";
        CommandResult result = executeCommand(8000L, "powershell", "-NoProfile", "-Command", script);
        if (!hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf(',') < 0)
                continue;

            int idx = line.lastIndexOf(',');
            if (idx <= 0)
                continue;

            String path = line.substring(0, idx).trim();
            String procName = parseProcessNameFromPerfPath(path);
            if (!hasText(procName) || "_total".equalsIgnoreCase(procName) || "idle".equalsIgnoreCase(procName))
                continue;

            double ioRate = parseDouble(line.substring(idx + 1).trim(), -1D);
            if (ioRate <= 0D)
                continue;

            SystemMetrics.ProcessIoUsage p = new SystemMetrics.ProcessIoUsage();
            p.available = true;
            p.pid = -1;
            p.processName = procName;
            p.source = "powershell_perfcounter";
            fillProcessMeta(p, metaMap.get(Integer.valueOf(p.pid)));
            p.readBytes = -1L;
            p.writeBytes = -1L;
            p.readRateBytesPerSec = ioRate / 2D;
            p.writeRateBytesPerSec = ioRate / 2D;
            p.ioRateBytesPerSec = ioRate;
            list.add(p);
            if (list.size() >= max)
                break;
        }
        return list;
    }

    private Map<Integer, ProcMeta> readProcessMetaMap()
    {
        Map<Integer, ProcMeta> map = new HashMap<Integer, ProcMeta>();
        String script = "Get-Process | ForEach-Object { "
                + "Write-Output ($_.Id.ToString() + ',' + $_.ProcessName + ',' + ($_.Path -replace ',', ' ') + ',' + $_.WorkingSet64.ToString()) }";
        CommandResult result = executeCommand(5000L, "powershell", "-NoProfile", "-Command", script);
        if (!result.isSuccess() || !hasText(result.output))
            return map;

        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf(',') < 0)
                continue;

            String[] arr = line.trim().split(",", 4);
            if (arr.length < 4)
                continue;

            int pid = (int) parseLong(arr[0], -1L);
            if (pid < 0)
                continue;

            ProcMeta meta = new ProcMeta();
            meta.pid = pid;
            meta.processName = arr[1].trim();
            meta.processPath = arr[2].trim();
            meta.memoryBytes = safeNonNegative(parseLong(arr[3], 0L));
            map.put(Integer.valueOf(pid), meta);
        }
        return map;
    }

    private void fillProcessMeta(SystemMetrics.ProcessCpuUsage process, ProcMeta meta)
    {
        if (process == null || meta == null)
            return;
        if (!hasText(process.processName))
            process.processName = meta.processName;
        process.processPath = meta.processPath;
        process.memoryBytes = meta.memoryBytes;
    }

    private void fillProcessMeta(SystemMetrics.ProcessIoUsage process, ProcMeta meta)
    {
        if (process == null || meta == null)
            return;
        if (!hasText(process.processName))
            process.processName = meta.processName;
        process.processPath = meta.processPath;
        process.memoryBytes = meta.memoryBytes;
    }

    private List<ProcIoSnapshot> readProcessIoSnapshot()
    {
        List<ProcIoSnapshot> list = new ArrayList<ProcIoSnapshot>();
        String script = "Get-Process | ForEach-Object { try { Write-Output ($_.Id.ToString() + ',' + $_.ProcessName + ',' + $_.IOReadBytes.ToString() + ',' + $_.IOWriteBytes.ToString()) } catch {} }";
        CommandResult result = executeCommand(8000L, "powershell", "-NoProfile", "-Command", script);
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf(',') < 0)
                continue;

            String[] arr = line.trim().split(",", 4);
            if (arr.length < 4)
                continue;

            int pid = (int) parseLong(arr[0], -1L);
            if (pid < 0)
                continue;

            ProcIoSnapshot s = new ProcIoSnapshot();
            s.pid = pid;
            s.name = arr[1].trim();
            s.readBytes = parseLong(arr[2], -1L);
            s.writeBytes = parseLong(arr[3], -1L);
            if (s.readBytes < 0L || s.writeBytes < 0L)
                continue;
            list.add(s);
        }
        return list;
    }

    private String buildProcKey(int pid, String name)
    {
        return pid + "|" + (name == null ? "" : name);
    }

    private String parseProcessNameFromPerfPath(String path)
    {
        if (!hasText(path))
            return "";
        int p1 = path.indexOf("("
                );
        int p2 = path.indexOf(")", p1 + 1);
        if (p1 < 0 || p2 <= p1)
            return path;
        String name = path.substring(p1 + 1, p2).trim();
        int idx = name.indexOf('#');
        if (idx > 0)
            name = name.substring(0, idx);
        return name;
    }

    private SystemMetrics.CpuUsage collectCpuByWmic(long sampleMillis)
    {
        CommandResult result = executeCommand(5000L, "cmd", "/c", "wmic cpu get loadpercentage /value");
        if (!result.isSuccess() || !hasText(result.output))
            return null;

        Map<String, String> map = parseKeyValueLines(result.output);
        long percent = parseLong(map.get("LoadPercentage"), -1L);
        if (percent < 0L)
            return null;

        SystemMetrics.CpuUsage usage = new SystemMetrics.CpuUsage();
        usage.available = true;
        usage.sampleMillis = sampleMillis;
        usage.source = "wmic";
        usage.usageRate = clampRate((double) percent / 100D);
        usage.idleRate = clampRate(1D - usage.usageRate);
        usage.userRate = -1D;
        usage.systemRate = -1D;
        usage.ioWaitRate = -1D;
        return usage;
    }

    private SystemMetrics.CpuUsage collectCpuByPowerShell(long sampleMillis)
    {
        String script = "$v=(Get-Counter '\\Processor(_Total)\\% Processor Time').CounterSamples[0].CookedValue; Write-Output $v";
        CommandResult result = executeCommand(6000L, "powershell", "-NoProfile", "-Command", script);
        if (!result.isSuccess())
            return null;

        Double number = parseDoubleFromText(result.output);
        if (number == null)
            return null;

        SystemMetrics.CpuUsage usage = new SystemMetrics.CpuUsage();
        usage.available = true;
        usage.sampleMillis = sampleMillis;
        usage.source = "powershell";
        usage.usageRate = clampRate(number.doubleValue() / 100D);
        usage.idleRate = clampRate(1D - usage.usageRate);
        usage.userRate = -1D;
        usage.systemRate = -1D;
        usage.ioWaitRate = -1D;
        return usage;
    }

    private SystemMetrics.MemoryUsage collectMemoryByWmic()
    {
        CommandResult result = executeCommand(5000L, "cmd", "/c", "wmic OS get FreePhysicalMemory,TotalVisibleMemorySize,FreeVirtualMemory,TotalVirtualMemorySize /value");
        if (!result.isSuccess() || !hasText(result.output))
            return null;

        Map<String, String> map = parseKeyValueLines(result.output);
        long totalKb = parseLong(map.get("TotalVisibleMemorySize"), -1L);
        long freeKb = parseLong(map.get("FreePhysicalMemory"), -1L);
        if (totalKb <= 0L || freeKb < 0L)
            return null;

        if (freeKb > totalKb)
            freeKb = totalKb;
        long usedKb = totalKb - freeKb;

        long totalVirtualKb = parseLong(map.get("TotalVirtualMemorySize"), -1L);
        long freeVirtualKb = parseLong(map.get("FreeVirtualMemory"), -1L);

        SystemMetrics.MemoryUsage usage = new SystemMetrics.MemoryUsage();
        usage.available = true;
        usage.source = "wmic";
        usage.totalBytes = kbToBytes(totalKb);
        usage.freeBytes = kbToBytes(freeKb);
        usage.usedBytes = kbToBytes(usedKb);
        usage.usageRate = calcRate(usage.usedBytes, usage.totalBytes);

        if (totalVirtualKb > 0L && freeVirtualKb >= 0L && totalVirtualKb >= totalKb)
        {
            long swapTotalKb = totalVirtualKb - totalKb;
            long swapFreeKb = freeVirtualKb - freeKb;
            if (swapFreeKb < 0L)
                swapFreeKb = 0L;
            if (swapFreeKb > swapTotalKb)
                swapFreeKb = swapTotalKb;

            usage.swapTotalBytes = kbToBytes(swapTotalKb);
            usage.swapFreeBytes = kbToBytes(swapFreeKb);
            usage.swapUsedBytes = safeNonNegative(usage.swapTotalBytes - usage.swapFreeBytes);
            usage.swapUsageRate = calcRate(usage.swapUsedBytes, usage.swapTotalBytes);
        }

        return usage;
    }

    private SystemMetrics.MemoryUsage collectMemoryByPowerShell()
    {
        String script = "$os=Get-CimInstance Win32_OperatingSystem; "
                + "Write-Output ($os.TotalVisibleMemorySize.ToString() + ',' + $os.FreePhysicalMemory.ToString() + ',' + $os.TotalVirtualMemorySize.ToString() + ',' + $os.FreeVirtualMemory.ToString())";
        CommandResult result = executeCommand(6000L, "powershell", "-NoProfile", "-Command", script);
        if (!result.isSuccess() || !hasText(result.output))
            return null;

        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf(',') < 0)
                continue;

            String[] arr = line.trim().split(",");
            if (arr.length < 2)
                continue;

            long totalKb = parseLong(arr[0], -1L);
            long freeKb = parseLong(arr[1], -1L);
            if (totalKb <= 0L || freeKb < 0L)
                continue;

            if (freeKb > totalKb)
                freeKb = totalKb;
            long usedKb = totalKb - freeKb;

            SystemMetrics.MemoryUsage usage = new SystemMetrics.MemoryUsage();
            usage.available = true;
            usage.source = "powershell";
            usage.totalBytes = kbToBytes(totalKb);
            usage.freeBytes = kbToBytes(freeKb);
            usage.usedBytes = kbToBytes(usedKb);
            usage.usageRate = calcRate(usage.usedBytes, usage.totalBytes);

            if (arr.length >= 4)
            {
                long totalVirtualKb = parseLong(arr[2], -1L);
                long freeVirtualKb = parseLong(arr[3], -1L);
                if (totalVirtualKb > 0L && freeVirtualKb >= 0L && totalVirtualKb >= totalKb)
                {
                    long swapTotalKb = totalVirtualKb - totalKb;
                    long swapFreeKb = freeVirtualKb - freeKb;
                    if (swapFreeKb < 0L)
                        swapFreeKb = 0L;
                    if (swapFreeKb > swapTotalKb)
                        swapFreeKb = swapTotalKb;

                    usage.swapTotalBytes = kbToBytes(swapTotalKb);
                    usage.swapFreeBytes = kbToBytes(swapFreeKb);
                    usage.swapUsedBytes = safeNonNegative(usage.swapTotalBytes - usage.swapFreeBytes);
                    usage.swapUsageRate = calcRate(usage.swapUsedBytes, usage.swapTotalBytes);
                }
            }
            return usage;
        }
        return null;
    }

    private List<SystemMetrics.DiskUsage> collectDiskByWmic()
    {
        CommandResult result = executeCommand(6000L, "cmd", "/c", "wmic logicaldisk where \"DriveType=3\" get DeviceID,Size,FreeSpace /format:value");
        if (!result.isSuccess() || !hasText(result.output))
            return new ArrayList<SystemMetrics.DiskUsage>();

        List<SystemMetrics.DiskUsage> list = new ArrayList<SystemMetrics.DiskUsage>();
        String[] lines = result.output.split("\\r?\\n");

        String deviceId = null;
        long size = -1L;
        long freeSpace = -1L;

        for (String line : lines)
        {
            if (!hasText(line))
                continue;

            String t = line.trim();
            int idx = t.indexOf('=');
            if (idx <= 0)
                continue;

            String key = t.substring(0, idx).trim();
            String value = t.substring(idx + 1).trim();

            if ("DeviceID".equalsIgnoreCase(key))
            {
                if (hasText(deviceId))
                    addDisk(list, deviceId, size, freeSpace, "wmic");
                deviceId = value;
                size = -1L;
                freeSpace = -1L;
            }
            else if ("Size".equalsIgnoreCase(key))
            {
                size = parseLong(value, -1L);
            }
            else if ("FreeSpace".equalsIgnoreCase(key))
            {
                freeSpace = parseLong(value, -1L);
            }
        }

        if (hasText(deviceId))
            addDisk(list, deviceId, size, freeSpace, "wmic");

        return list;
    }

    private List<SystemMetrics.DiskUsage> collectDiskByPowerShell()
    {
        String script = "Get-CimInstance Win32_LogicalDisk -Filter \"DriveType=3\" | ForEach-Object { Write-Output ($_.DeviceID + ',' + $_.Size + ',' + $_.FreeSpace) }";
        CommandResult result = executeCommand(7000L, "powershell", "-NoProfile", "-Command", script);
        if (!result.isSuccess() || !hasText(result.output))
            return new ArrayList<SystemMetrics.DiskUsage>();

        List<SystemMetrics.DiskUsage> list = new ArrayList<SystemMetrics.DiskUsage>();
        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf(',') < 0)
                continue;

            String[] arr = line.trim().split(",");
            if (arr.length < 3)
                continue;

            String device = arr[0].trim();
            long size = parseLong(arr[1], -1L);
            long free = parseLong(arr[2], -1L);
            addDisk(list, device, size, free, "powershell");
        }
        return list;
    }

    private void addDisk(List<SystemMetrics.DiskUsage> list, String device, long size, long free, String source)
    {
        if (!hasText(device) || size <= 0L || free < 0L)
            return;

        if (free > size)
            free = size;

        SystemMetrics.DiskUsage usage = new SystemMetrics.DiskUsage();
        usage.available = true;
        usage.source = source;
        usage.fileSystem = device;
        usage.mountPath = device;
        usage.totalBytes = size;
        usage.freeBytes = free;
        usage.usedBytes = safeNonNegative(size - free);
        usage.usageRate = calcRate(usage.usedBytes, usage.totalBytes);
        list.add(usage);
    }

    private SystemMetrics.NetworkUsage collectNetworkUsage(long sampleMillis, boolean needProcesses)
    {
        Map<String, NetCounter> first = readInterfaceCountersByPowerShell();
        if (first.isEmpty())
            first = readInterfaceCountersByNetstat();

        if (first.isEmpty())
        {
            SystemMetrics.NetworkUsage usage = new SystemMetrics.NetworkUsage();
            usage.available = false;
            usage.sampleMillis = sampleMillis;
            usage.source = "windows_network";
            usage.error = "No interface counters found";
            return usage;
        }

        sleepSilently(sampleMillis);

        Map<String, NetCounter> second = readInterfaceCountersByPowerShell();
        String source = "powershell_netadapter";
        if (second.isEmpty())
        {
            second = readInterfaceCountersByNetstat();
            source = "netstat_e";
        }

        SystemMetrics.NetworkUsage usage = buildNetworkUsageFromSnapshot(first, second, sampleMillis, source);
        if (needProcesses)
            usage.processes = collectProcessNetworkUsageByPowerShell(usage.totalThroughputBytesPerSec);
        return usage;
    }

    private Map<String, NetCounter> readInterfaceCountersByPowerShell()
    {
        Map<String, NetCounter> map = new java.util.LinkedHashMap<String, NetCounter>();
        String script = "Get-NetAdapterStatistics | ForEach-Object { Write-Output ($_.Name + ',' + $_.ReceivedBytes + ',' + $_.SentBytes) }";
        CommandResult result = executeCommand(7000L, "powershell", "-NoProfile", "-Command", script);
        if (!result.isSuccess() || !hasText(result.output))
            return map;

        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf(',') < 0)
                continue;

            String[] arr = line.trim().split(",");
            if (arr.length < 3)
                continue;

            String name = arr[0].trim();
            long rx = parseLong(arr[1], -1L);
            long tx = parseLong(arr[2], -1L);
            if (!hasText(name) || rx < 0L || tx < 0L)
                continue;

            NetCounter c = new NetCounter();
            c.name = name;
            c.displayName = name;
            c.rxBytes = rx;
            c.txBytes = tx;
            map.put(name, c);
        }
        return map;
    }

    private Map<String, NetCounter> readInterfaceCountersByNetstat()
    {
        Map<String, NetCounter> map = new java.util.LinkedHashMap<String, NetCounter>();
        CommandResult result = executeCommand(4000L, "netstat", "-e");
        if (!result.isSuccess() || !hasText(result.output))
            return map;

        String[] lines = result.output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line))
                continue;
            String t = line.trim();
            if (!t.startsWith("Bytes"))
                continue;

            String[] arr = t.split("\\s+");
            if (arr.length < 3)
                continue;

            long rx = parseLong(arr[1], -1L);
            long tx = parseLong(arr[2], -1L);
            if (rx < 0L || tx < 0L)
                continue;

            NetCounter c = new NetCounter();
            c.name = "total";
            c.displayName = "total";
            c.rxBytes = rx;
            c.txBytes = tx;
            map.put(c.name, c);
        }

        return map;
    }

    private List<SystemMetrics.ProcessNetworkUsage> collectProcessNetworkUsageByPowerShell(double totalThroughput)
    {
        List<SystemMetrics.ProcessNetworkUsage> list = new ArrayList<SystemMetrics.ProcessNetworkUsage>();
        String script = "Get-NetTCPConnection -State Established | Group-Object OwningProcess | "
                + "ForEach-Object { $p=Get-Process -Id $_.Name -ErrorAction SilentlyContinue; "
                + "$n=if($p){$p.ProcessName}else{'unknown'}; "
                + "Write-Output ($_.Name + ',' + $n + ',' + $_.Count) }";
        CommandResult result = executeCommand(9000L, "powershell", "-NoProfile", "-Command", script);
        if (!result.isSuccess() || !hasText(result.output))
            return list;

        String[] lines = result.output.split("\\r?\\n");
        long totalConn = 0L;
        List<TempConn> temp = new ArrayList<TempConn>();
        for (String line : lines)
        {
            if (!hasText(line) || line.indexOf(',') < 0)
                continue;
            String[] arr = line.trim().split(",");
            if (arr.length < 3)
                continue;

            int pid = (int) parseLong(arr[0], -1L);
            String name = arr[1].trim();
            long count = parseLong(arr[2], -1L);
            if (pid < 0 || count <= 0L)
                continue;

            TempConn t = new TempConn();
            t.pid = pid;
            t.name = name;
            t.count = count;
            temp.add(t);
            totalConn += count;
        }

        if (totalConn <= 0L || temp.isEmpty())
            return list;

        for (TempConn t : temp)
        {
            double ratio = (double) t.count / (double) totalConn;
            double throughput = totalThroughput * ratio;

            SystemMetrics.ProcessNetworkUsage p = new SystemMetrics.ProcessNetworkUsage();
            p.available = true;
            p.pid = t.pid;
            p.processName = t.name;
            p.source = "powershell_established_connection_share";
            p.rxRateBytesPerSec = throughput / 2D;
            p.txRateBytesPerSec = throughput / 2D;
            p.throughputBytesPerSec = throughput;
            list.add(p);
        }

        Collections.sort(list, new Comparator<SystemMetrics.ProcessNetworkUsage>()
        {
            @Override
            public int compare(SystemMetrics.ProcessNetworkUsage a, SystemMetrics.ProcessNetworkUsage b)
            {
                double av = a == null ? -1D : a.throughputBytesPerSec;
                double bv = b == null ? -1D : b.throughputBytesPerSec;
                return Double.compare(bv, av);
            }
        });
        return list;
    }

    private static class TempConn
    {
        int pid;
        String name;
        long count;
    }

    private static class ProcIoSnapshot
    {
        int pid;
        String name;
        long readBytes;
        long writeBytes;
    }

    private static class ProcMeta
    {
        int pid;
        String processName;
        String processPath;
        long memoryBytes;
    }

    private static Double parseDoubleFromText(String output)
    {
        if (!hasText(output))
            return null;

        String[] lines = output.split("\\r?\\n");
        for (String line : lines)
        {
            if (!hasText(line))
                continue;
            String t = line.trim().replace(',', '.');
            try
            {
                return Double.valueOf(Double.parseDouble(t));
            }
            catch (Throwable ignore)
            {
            }
        }
        return null;
    }
}
