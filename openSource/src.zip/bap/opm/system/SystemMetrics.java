package bap.opm.system;

import java.util.ArrayList;
import java.util.List;

public class SystemMetrics
{
    public long timestamp;
    public String hostName;
    public String osName;
    public String provider;
    public CpuUsage cpu = new CpuUsage();
    public MemoryUsage memory = new MemoryUsage();
    public List<DiskUsage> disks = new ArrayList<DiskUsage>();
    public List<ProcessCpuUsage> cpuProcesses = new ArrayList<ProcessCpuUsage>();
    public List<ProcessMemoryUsage> memoryProcesses = new ArrayList<ProcessMemoryUsage>();
    public IoUsage io = new IoUsage();
    public NetworkUsage network = new NetworkUsage();

    public static class CpuUsage
    {
        public boolean available;
        public long sampleMillis;
        public String source;
        public String error;
        public double usageRate;
        public double userRate;
        public double systemRate;
        public double idleRate;
        public double ioWaitRate;
    }

    public static class MemoryUsage
    {
        public boolean available;
        public String source;
        public String error;
        public long totalBytes;
        public long usedBytes;
        public long freeBytes;
        public double usageRate;
        public long swapTotalBytes;
        public long swapUsedBytes;
        public long swapFreeBytes;
        public double swapUsageRate;
    }

    public static class DiskUsage
    {
        public boolean available;
        public String source;
        public String fileSystem;
        public String mountPath;
        public String type;
        public long totalBytes;
        public long usedBytes;
        public long freeBytes;
        public double usageRate;
    }

    public static class ProcessCpuUsage
    {
        public boolean available;
        public int pid;
        public String processName;
        public String processPath;
        public long memoryBytes;
        public String source;
        public double cpuRate;
    }

    public static class ProcessMemoryUsage
    {
        public boolean available;
        public int pid;
        public String processName;
        public String processPath;
        public long memoryBytes;
        public String source;
    }

    public static class IoUsage
    {
        public boolean available;
        public String source;
        public String error;
        public long sampleMillis;
        public List<ProcessIoUsage> processes = new ArrayList<ProcessIoUsage>();
    }

    public static class ProcessIoUsage
    {
        public boolean available;
        public int pid;
        public String processName;
        public String processPath;
        public long memoryBytes;
        public String source;
        public long readBytes;
        public long writeBytes;
        public double readRateBytesPerSec;
        public double writeRateBytesPerSec;
        public double ioRateBytesPerSec;
    }

    public static class NetworkUsage
    {
        public boolean available;
        public String source;
        public String error;
        public long sampleMillis;
        public long totalRxBytes;
        public long totalTxBytes;
        public double totalRxRateBytesPerSec;
        public double totalTxRateBytesPerSec;
        public double totalThroughputBytesPerSec;
        public List<NetworkInterfaceUsage> interfaces = new ArrayList<NetworkInterfaceUsage>();
        public List<ProcessNetworkUsage> processes = new ArrayList<ProcessNetworkUsage>();
    }

    public static class NetworkInterfaceUsage
    {
        public boolean available;
        public String name;
        public String displayName;
        public long rxBytes;
        public long txBytes;
        public double rxRateBytesPerSec;
        public double txRateBytesPerSec;
        public double throughputBytesPerSec;
    }

    public static class ProcessNetworkUsage
    {
        public boolean available;
        public int pid;
        public String processName;
        public String source;
        public double rxRateBytesPerSec;
        public double txRateBytesPerSec;
        public double throughputBytesPerSec;
    }
}
