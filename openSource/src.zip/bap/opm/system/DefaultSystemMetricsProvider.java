package bap.opm.system;

import java.util.List;

public class DefaultSystemMetricsProvider extends AbstractSystemMetricsProvider
{
    @Override
    public boolean supports(String osName)
    {
        return true;
    }

    @Override
    public String getName()
    {
        return "default";
    }

    @Override
    public SystemMetrics collect(long cpuSampleMillis)
    {
        return collect(cpuSampleMillis, SystemMetricsCollectSpec.all());
    }

    @Override
    public SystemMetrics collect(long cpuSampleMillis, SystemMetricsCollectSpec spec)
    {
        SystemMetricsCollectSpec collectSpec = normalizeCollectSpec(spec);
        long sampleMillis = normalizeSampleMillis(cpuSampleMillis);
        SystemMetrics metrics = newBaseMetrics();

        long totalStart = System.currentTimeMillis();
        debugCollectStart(getName(), collectSpec, sampleMillis);

        if (collectSpec.needCpu())
        {
            long st = System.currentTimeMillis();
            metrics.cpu = collectCpuByMxBean(sampleMillis);
            debugCollectStage(getName(), "topCpu", st);
        }

        if (collectSpec.needMemory())
        {
            long st = System.currentTimeMillis();
            metrics.memory = collectMemoryByMxBean();
            debugCollectStage(getName(), "topMemory", st);
        }

        if (collectSpec.needDisk())
        {
            long st = System.currentTimeMillis();
            List<SystemMetrics.DiskUsage> list = collectDiskByDf();
            if (list.isEmpty())
                list = collectDiskByFileStore();
            metrics.disks = list;
            debugCollectStage(getName(), "disk", st);
        }

        if (collectSpec.needCpuProcesses())
            metrics.cpuProcesses = new java.util.ArrayList<SystemMetrics.ProcessCpuUsage>();

        if (collectSpec.needMemoryProcesses())
            metrics.memoryProcesses = new java.util.ArrayList<SystemMetrics.ProcessMemoryUsage>();

        if (collectSpec.needIo())
        {
            long st = System.currentTimeMillis();
            metrics.io = collectIoUsage(sampleMillis);
            debugCollectStage(getName(), "topIo", st);
        }

        if (collectSpec.needNetwork())
        {
            long st = System.currentTimeMillis();
            metrics.network = collectNetworkUsage(sampleMillis);
            debugCollectStage(getName(), "network", st);
        }

        debugCollectEnd(getName(), collectSpec, totalStart);
        return metrics;
    }

    private SystemMetrics.IoUsage collectIoUsage(long sampleMillis)
    {
        SystemMetrics.IoUsage usage = new SystemMetrics.IoUsage();
        usage.available = false;
        usage.sampleMillis = sampleMillis;
        usage.source = "default";
        usage.error = "IO metrics provider is not implemented for this OS";
        return usage;
    }

    private SystemMetrics.NetworkUsage collectNetworkUsage(long sampleMillis)
    {
        SystemMetrics.NetworkUsage usage = new SystemMetrics.NetworkUsage();
        usage.available = false;
        usage.sampleMillis = sampleMillis;
        usage.source = "default";
        usage.error = "Network metrics provider is not implemented for this OS";
        return usage;
    }
}
