package bap.opm.system;

public interface SystemMetricsProvider
{
    boolean supports(String osName);

    String getName();

    SystemMetrics collect(long cpuSampleMillis);

    SystemMetrics collect(long cpuSampleMillis, SystemMetricsCollectSpec spec);
}
