package bap.opm.system;

import java.util.ArrayList;
import java.util.List;

public class SystemMetricsProviderFactory
{
    private static final List<SystemMetricsProvider> PROVIDERS = new ArrayList<SystemMetricsProvider>();

    static
    {
        PROVIDERS.add(new LinuxSystemMetricsProvider());
        PROVIDERS.add(new WindowsSystemMetricsProvider());
        PROVIDERS.add(new MacSystemMetricsProvider());
        PROVIDERS.add(new DefaultSystemMetricsProvider());
    }

    private SystemMetricsProviderFactory()
    {
    }

    public static synchronized void registerFirst(SystemMetricsProvider provider)
    {
        if (provider == null)
            return;
        PROVIDERS.add(0, provider);
    }

    public static synchronized SystemMetricsProvider resolveProvider()
    {
        return resolveProvider(System.getProperty("os.name"));
    }

    public static synchronized SystemMetricsProvider resolveProvider(String osName)
    {
        for (SystemMetricsProvider provider : PROVIDERS)
        {
            if (provider != null && provider.supports(osName))
                return provider;
        }
        return new DefaultSystemMetricsProvider();
    }

    public static synchronized List<String> listProviderNames()
    {
        List<String> names = new ArrayList<String>();
        for (SystemMetricsProvider provider : PROVIDERS)
        {
            if (provider != null)
                names.add(provider.getName());
        }
        return names;
    }
}
