package bap.opm;

public class OpmConst
{
    public static final String MODULE_NAME = "opm";
    public static final String MODULE_ATTR_CLASS_NAME = "class_name";
    public static final String MODULE_ATTR_ENABLE = "enable";
    public static final String LOG = "OPM";

    public static final int STATUS_NORMAL = 0;
    public static final int STATUS_ALARM = 1;
    public static final int STATUS_SUPPRESSED = 2;
    public static final int STATUS_ERROR = 3;

    public static final String SERVICE_TYPE = "opm";

    public static final String CONF_CORE_COLLECT_INTERVAL_SEC = "opm.core.collectIntervalSec";
    public static final String CONF_CORE_COLLECTOR_CLASSES = "opm.core.collectorClasses";
    public static final String CONF_CORE_PERSIST_ENABLE = "opm.core.persistEnable";
    public static final String CONF_CORE_RETENTION_DAY = "opm.core.retentionDay";
    public static final String CONF_CORE_DEBUG_ENABLE = "opm.core.debugEnable";

    public static final String CONF_ALARM_ENABLE = "opm.alarm.enable";
    public static final String CONF_ALARM_DEFAULT_COOLDOWN_SEC = "opm.alarm.defaultCooldownSec";
    public static final String CONF_ALARM_SUPPRESS_SEC = "opm.alarm.suppressSec";

    public static final String CONF_WEB_ENABLE = "opm.web.enable";
    public static final String CONF_WEB_BASE_PATH = "opm.web.base.path";
    public static final String CONF_WEB_API_PATH = "opm.web.api.path";
    public static final String CONF_WEB_DEPLOY_DIR = "opm.web.deploy.dir";
    public static final String CONF_WEB_DASHBOARD_LIMIT = "opm.web.dashboard.limit";

    public static final String AUTH_LOGIN_PATH = "/api/opm/auth/login";
    public static final String AUTH_CHECK_PATH = "/api/opm/auth/check";
    public static final String AUTH_REFRESH_PATH = "/api/opm/auth/refresh";
    public static final String AUTH_USER_INFO_PATH = "/api/opm/auth/userInfo";
    public static final String WEB_PING_PATH = "/api/opm/ping";
    public static final String WEB_ROOT_PATH = "/opm";
    public static final String FAVICON_PATH = "/favicon.ico";
    public static final String WEB_INDEX_PATH = "/opm/index.html";
    public static final String WEB_LOGIN_REDIRECT_PATH = "/opm/#/login";

    public static final String LABEL_CORE_COLLECT_INTERVAL_SEC = "默认采集周期秒";
    public static final String LABEL_CORE_COLLECTOR_CLASSES = "采集器接口类列表";
    public static final String LABEL_CORE_PERSIST_ENABLE = "采集数据入库";
    public static final String LABEL_CORE_RETENTION_DAY = "数据保留天数";
    public static final String LABEL_CORE_DEBUG_ENABLE = "启用调试模式";
    public static final String LABEL_ALARM_ENABLE = "启用告警";
    public static final String LABEL_ALARM_DEFAULT_COOLDOWN_SEC = "默认告警冷却秒";
    public static final String LABEL_ALARM_SUPPRESS_SEC = "告警抑制秒数";
    public static final String LABEL_WEB_ENABLE = "启用OPM网页";
    public static final String LABEL_WEB_BASE_PATH = "OPM网页访问路径";
    public static final String LABEL_WEB_API_PATH = "OPM网页API路径";
    public static final String LABEL_WEB_DEPLOY_DIR = "OPM网页部署目录";
    public static final String LABEL_WEB_DASHBOARD_LIMIT = "OPM网页默认查询条数";

    public static final int DEFAULT_CORE_COLLECT_INTERVAL_SEC = 5;
    public static final String DEFAULT_CORE_COLLECTOR_CLASSES =
            "cell.bap.opm.collector.system.IOpmSysCollector,"
                    + "cell.bap.opm.collector.focus.IOpmFocusCollector,"
                    + "cell.bap.opm.collector.diskpartition.IOpmDiskPartitionCollector,"
                    + "cell.bap.opm.collector.topcpu.IOpmTopCpuCollector,"
                    + "cell.bap.opm.collector.topmemory.IOpmTopMemoryCollector,"
                    + "cell.bap.opm.collector.disk.IOpmDiskCollector,"
                    + "cell.bap.opm.collector.topio.IOpmTopIoCollector,"
                    + "cell.bap.opm.collector.topnet.IOpmTopNetCollector,"
                    + "cell.bap.opm.collector.pg.IOpmPgCollector";
    public static final boolean DEFAULT_CORE_PERSIST_ENABLE = true;
    public static final int DEFAULT_CORE_RETENTION_DAY = 7;
    public static final boolean DEFAULT_CORE_DEBUG_ENABLE = false;

    public static final boolean DEFAULT_ALARM_ENABLE = true;
    public static final int DEFAULT_ALARM_DEFAULT_COOLDOWN_SEC = 300;
    public static final int DEFAULT_ALARM_SUPPRESS_SEC = 300;

    public static final boolean DEFAULT_WEB_ENABLE = true;
    public static final String DEFAULT_WEB_BASE_PATH = "/opm/";
    public static final String DEFAULT_WEB_API_PATH = "/api/opm";
    public static final String DEFAULT_WEB_DEPLOY_DIR = "/webapps/opm";
    public static final int DEFAULT_WEB_DASHBOARD_LIMIT = 120;

    private OpmConst()
    {
    }
}
