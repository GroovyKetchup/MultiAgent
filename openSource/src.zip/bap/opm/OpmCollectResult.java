package bap.opm;

import java.io.Serializable;

import bap.md.opm.OpmMetricExtDo;

public class OpmCollectResult implements Serializable
{
    private static final long serialVersionUID = -6692377473152928192L;

    public String collectorKey;
    public String collectorLabel;
    public long collectTime;
    public long collectCostMs;
    public int status = OpmConst.STATUS_NORMAL;
    public String summary;
    public String alarmUuid;
    public String statusDetailJson;
    public OpmMetricExtDo metricExt;
}
