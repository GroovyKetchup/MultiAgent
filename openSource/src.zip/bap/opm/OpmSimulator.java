package bap.opm;

/**
 * OPM采集器仿真器对象。
 * 存储仿真器的Cell接口类名，通过Cells.get()动态获取实例。
 * 
 * 使用方式：
 * 1. 制作Cell实现IOpmCollectorSimulator接口
 * 2. 提交到内部插件工程，发布为插件
 * 3. 调用OpmCenter.setSimulator(collectorKey, cellClassName)挂载
 * 
 * 示例：
 * <pre>
 * // 挂载仿真器
 * OpmCenter.setSimulator("sys", "com.example.MySysSimulator");
 * 
 * // 解挂仿真器
 * OpmCenter.setSimulator(null, null);
 * </pre>
 */
public class OpmSimulator
{
    protected String _collectorKey;
    protected String _cellClassName;
    protected long _createTime;

    public OpmSimulator()
    {
        _createTime = System.currentTimeMillis();
    }

    public String getCollectorKey()
    {
        return _collectorKey;
    }

    public void setCollectorKey(String collectorKey)
    {
        _collectorKey = collectorKey;
    }

    public String getCellClassName()
    {
        return _cellClassName;
    }

    public void setCellClassName(String cellClassName)
    {
        _cellClassName = cellClassName;
    }

    public long getCreateTime()
    {
        return _createTime;
    }

    @Override
    public String toString()
    {
        return "OpmSimulator{collectorKey='" + _collectorKey + "', cellClassName='" + _cellClassName + "', createTime=" + _createTime + "}";
    }
}