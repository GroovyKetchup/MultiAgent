package bap.opm.collector.system;

import bap.opm.registry.IOpmCollectorRegistry;
import bap.opm.registry.OpmAlarmRuleMeta;
import bap.opm.registry.OpmConfigParamMeta;
import bap.opm.registry.OpmConfigRegistry;

public class OpmSysCollectorRegistry implements IOpmCollectorRegistry
{
    public static final String COLLECTOR_KEY = "sys";

    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.sys.collectIntervalSec";
    
    public static final String CONF_CPU_WARN_RATE = "opm.sys.cpu.warnRate";
    public static final String CONF_CPU_MINOR_RATE = "opm.sys.cpu.minorRate";
    public static final String CONF_CPU_MAJOR_RATE = "opm.sys.cpu.majorRate";
    public static final String CONF_CPU_CRITICAL_RATE = "opm.sys.cpu.criticalRate";

    public static final String CONF_MEM_WARN_RATE = "opm.sys.mem.warnRate";
    public static final String CONF_MEM_MINOR_RATE = "opm.sys.mem.minorRate";
    public static final String CONF_MEM_MAJOR_RATE = "opm.sys.mem.majorRate";
    public static final String CONF_MEM_CRITICAL_RATE = "opm.sys.mem.criticalRate";

    @Override
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        registry.registerConfigParam(
                new OpmConfigParamMeta(CONF_COLLECT_INTERVAL_SEC, "采集周期", "int", "60")
                        .setDesc("系统采集周期（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("collect")
                        .setSingleParam(CONF_COLLECT_INTERVAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta("sys.cpu", "系统CPU使用率阈值", "string", "0.8")
                        .setDesc("系统CPU使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_CPU_WARN_RATE, CONF_CPU_MINOR_RATE, CONF_CPU_MAJOR_RATE, CONF_CPU_CRITICAL_RATE));

        registry.registerConfigParam(
                new OpmConfigParamMeta("sys.mem", "系统内存使用率阈值", "string", "0.8")
                        .setDesc("系统内存使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_MEM_WARN_RATE, CONF_MEM_MINOR_RATE, CONF_MEM_MAJOR_RATE, CONF_MEM_CRITICAL_RATE));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta("cpuUsageThreshold", "系统CPU使用率过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta("sys.cpu")
                        .setDesc("系统CPU使用率超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta("memUsageThreshold", "系统内存使用率过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta("sys.mem")
                        .setDesc("系统内存使用率超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta("collectExpectation.sys", "采集周期未达预期")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_COLLECT_INTERVAL_SEC)
                        .setDesc("系统采集周期未达到配置要求"));
    }
}
