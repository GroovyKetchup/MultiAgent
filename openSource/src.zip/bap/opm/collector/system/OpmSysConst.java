package bap.opm.collector.system;

import com.leavay.common.util.ToolUtilities;

import bap.opm.cfg.OpmRuntimeConfig;

public class OpmSysConst
{
    public static final String COLLECTOR_KEY = "sys";
    public static final String COLLECTOR_LABEL = "系统基础监控";

    public static final String CONF_ENABLE = "opm.sys.enable";
    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.sys.collectIntervalSec";
    public static final String CONF_CPU_SAMPLE_MILLIS = "opm.sys.cpu.sampleMillis";
    public static final String CONF_DISK_COLLECT_INTERVAL_SEC = "opm.sys.disk.collectIntervalSec";
    // CPU 四级门限配置
    public static final String CONF_CPU_WARN_RATE = "opm.sys.cpu.warnRate";
    public static final String CONF_CPU_WARN_DURATION_SEC = "opm.sys.cpu.warnDurationSec";
    public static final String CONF_CPU_MINOR_RATE = "opm.sys.cpu.minorRate";
    public static final String CONF_CPU_MINOR_DURATION_SEC = "opm.sys.cpu.minorDurationSec";
    public static final String CONF_CPU_MAJOR_RATE = "opm.sys.cpu.majorRate";
    public static final String CONF_CPU_MAJOR_DURATION_SEC = "opm.sys.cpu.majorDurationSec";
    public static final String CONF_CPU_CRITICAL_RATE = "opm.sys.cpu.criticalRate";
    public static final String CONF_CPU_CRITICAL_DURATION_SEC = "opm.sys.cpu.criticalDurationSec";

    // 内存 四级门限配置
    public static final String CONF_MEM_WARN_RATE = "opm.sys.mem.warnRate";
    public static final String CONF_MEM_WARN_DURATION_SEC = "opm.sys.mem.warnDurationSec";
    public static final String CONF_MEM_MINOR_RATE = "opm.sys.mem.minorRate";
    public static final String CONF_MEM_MINOR_DURATION_SEC = "opm.sys.mem.minorDurationSec";
    public static final String CONF_MEM_MAJOR_RATE = "opm.sys.mem.majorRate";
    public static final String CONF_MEM_MAJOR_DURATION_SEC = "opm.sys.mem.majorDurationSec";
    public static final String CONF_MEM_CRITICAL_RATE = "opm.sys.mem.criticalRate";
    public static final String CONF_MEM_CRITICAL_DURATION_SEC = "opm.sys.mem.criticalDurationSec";

    // IO 四级门限配置（新增）
    public static final String CONF_IO_COLLECT_INTERVAL_SEC = "opm.sys.io.collectIntervalSec";
    public static final String CONF_IO_SAMPLE_MILLIS = "opm.sys.io.sampleMillis";
    public static final String CONF_IO_WARN_RATE = "opm.sys.io.warnRateBytesPerSec";
    public static final String CONF_IO_WARN_DURATION_SEC = "opm.sys.io.warnDurationSec";
    public static final String CONF_IO_MINOR_RATE = "opm.sys.io.minorRateBytesPerSec";
    public static final String CONF_IO_MINOR_DURATION_SEC = "opm.sys.io.minorDurationSec";
    public static final String CONF_IO_MAJOR_RATE = "opm.sys.io.majorRateBytesPerSec";
    public static final String CONF_IO_MAJOR_DURATION_SEC = "opm.sys.io.majorDurationSec";
    public static final String CONF_IO_CRITICAL_RATE = "opm.sys.io.criticalRateBytesPerSec";
    public static final String CONF_IO_CRITICAL_DURATION_SEC = "opm.sys.io.criticalDurationSec";

    // 网络 四级门限配置（新增）
    public static final String CONF_NET_COLLECT_INTERVAL_SEC = "opm.sys.net.collectIntervalSec";
    public static final String CONF_NET_SAMPLE_MILLIS = "opm.sys.net.sampleMillis";
    public static final String CONF_NET_WARN_RATE = "opm.sys.net.warnRateBytesPerSec";
    public static final String CONF_NET_WARN_DURATION_SEC = "opm.sys.net.warnDurationSec";
    public static final String CONF_NET_MINOR_RATE = "opm.sys.net.minorRateBytesPerSec";
    public static final String CONF_NET_MINOR_DURATION_SEC = "opm.sys.net.minorDurationSec";
    public static final String CONF_NET_MAJOR_RATE = "opm.sys.net.majorRateBytesPerSec";
    public static final String CONF_NET_MAJOR_DURATION_SEC = "opm.sys.net.majorDurationSec";
    public static final String CONF_NET_CRITICAL_RATE = "opm.sys.net.criticalRateBytesPerSec";
    public static final String CONF_NET_CRITICAL_DURATION_SEC = "opm.sys.net.criticalDurationSec";

    public static final String CONF_RULE_COOLDOWN_SEC = "opm.sys.rule.cooldownSec";

    // 标签
    public static final String LABEL_ENABLE = "启用系统采集器";
    public static final String LABEL_COLLECT_INTERVAL_SEC = "系统采集周期秒";
    public static final String LABEL_CPU_SAMPLE_MILLIS = "CPU采样毫秒";
    public static final String LABEL_DISK_COLLECT_INTERVAL_SEC = "磁盘采集周期秒";
    public static final String LABEL_CPU_WARN_RATE = "CPU警告阈值";
    public static final String LABEL_CPU_WARN_DURATION_SEC = "CPU警告持续时间秒";
    public static final String LABEL_CPU_MINOR_RATE = "CPU次要阈值";
    public static final String LABEL_CPU_MINOR_DURATION_SEC = "CPU次要持续时间秒";
    public static final String LABEL_CPU_MAJOR_RATE = "CPU主要阈值";
    public static final String LABEL_CPU_MAJOR_DURATION_SEC = "CPU主要持续时间秒";
    public static final String LABEL_CPU_CRITICAL_RATE = "CPU严重阈值";
    public static final String LABEL_CPU_CRITICAL_DURATION_SEC = "CPU严重持续时间秒";

    public static final String LABEL_MEM_WARN_RATE = "内存警告阈值";
    public static final String LABEL_MEM_WARN_DURATION_SEC = "内存警告持续时间秒";
    public static final String LABEL_MEM_MINOR_RATE = "内存次要阈值";
    public static final String LABEL_MEM_MINOR_DURATION_SEC = "内存次要持续时间秒";
    public static final String LABEL_MEM_MAJOR_RATE = "内存主要阈值";
    public static final String LABEL_MEM_MAJOR_DURATION_SEC = "内存主要持续时间秒";
    public static final String LABEL_MEM_CRITICAL_RATE = "内存严重阈值";
    public static final String LABEL_MEM_CRITICAL_DURATION_SEC = "内存严重持续时间秒";

    // IO 标签（新增）
    public static final String LABEL_IO_COLLECT_INTERVAL_SEC = "IO采集周期秒";
    public static final String LABEL_IO_SAMPLE_MILLIS = "IO采样毫秒";
    public static final String LABEL_IO_WARN_RATE = "IO警告阈值(B/s)";
    public static final String LABEL_IO_WARN_DURATION_SEC = "IO警告持续时间秒";
    public static final String LABEL_IO_MINOR_RATE = "IO次要阈值(B/s)";
    public static final String LABEL_IO_MINOR_DURATION_SEC = "IO次要持续时间秒";
    public static final String LABEL_IO_MAJOR_RATE = "IO主要阈值(B/s)";
    public static final String LABEL_IO_MAJOR_DURATION_SEC = "IO主要持续时间秒";
    public static final String LABEL_IO_CRITICAL_RATE = "IO严重阈值(B/s)";
    public static final String LABEL_IO_CRITICAL_DURATION_SEC = "IO严重持续时间秒";

    // 网络标签（新增）
    public static final String LABEL_NET_COLLECT_INTERVAL_SEC = "网络采集周期秒";
    public static final String LABEL_NET_SAMPLE_MILLIS = "网络采样毫秒";
    public static final String LABEL_NET_WARN_RATE = "网络警告阈值(B/s)";
    public static final String LABEL_NET_WARN_DURATION_SEC = "网络警告持续时间秒";
    public static final String LABEL_NET_MINOR_RATE = "网络次要阈值(B/s)";
    public static final String LABEL_NET_MINOR_DURATION_SEC = "网络次要持续时间秒";
    public static final String LABEL_NET_MAJOR_RATE = "网络主要阈值(B/s)";
    public static final String LABEL_NET_MAJOR_DURATION_SEC = "网络主要持续时间秒";
    public static final String LABEL_NET_CRITICAL_RATE = "网络严重阈值(B/s)";
    public static final String LABEL_NET_CRITICAL_DURATION_SEC = "网络严重持续时间秒";

    public static final String LABEL_RULE_COOLDOWN_SEC = "系统规则冷却秒";

    // 默认值
    public static final boolean DEFAULT_ENABLE = true;
    public static final int DEFAULT_COLLECT_INTERVAL_SEC = 5;
    public static final int DEFAULT_CPU_SAMPLE_MILLIS = 1000;
    public static final int DEFAULT_DISK_COLLECT_INTERVAL_SEC = 3600;
    // CPU 默认门限（四级）
    public static final double DEFAULT_CPU_WARN_RATE = 0.70D;
    public static final int DEFAULT_CPU_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_CPU_MINOR_RATE = 0.80D;
    public static final int DEFAULT_CPU_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_CPU_MAJOR_RATE = 0.90D;
    public static final int DEFAULT_CPU_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_CPU_CRITICAL_RATE = 0.95D;
    public static final int DEFAULT_CPU_CRITICAL_DURATION_SEC = 5;

    // 内存 默认门限（四级）
    public static final double DEFAULT_MEM_WARN_RATE = 0.70D;
    public static final int DEFAULT_MEM_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_MEM_MINOR_RATE = 0.80D;
    public static final int DEFAULT_MEM_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_MEM_MAJOR_RATE = 0.90D;
    public static final int DEFAULT_MEM_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_MEM_CRITICAL_RATE = 0.95D;
    public static final int DEFAULT_MEM_CRITICAL_DURATION_SEC = 5;

    // IO 默认门限（四级，新增）
    public static final int DEFAULT_IO_COLLECT_INTERVAL_SEC = 5;
    public static final int DEFAULT_IO_SAMPLE_MILLIS = 1000;
    public static final double DEFAULT_IO_WARN_RATE = 10D * 1024D * 1024D;  // 10MB/s
    public static final int DEFAULT_IO_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_IO_MINOR_RATE = 30D * 1024D * 1024D;  // 30MB/s
    public static final int DEFAULT_IO_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_IO_MAJOR_RATE = 80D * 1024D * 1024D;  // 80MB/s
    public static final int DEFAULT_IO_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_IO_CRITICAL_RATE = 150D * 1024D * 1024D;  // 150MB/s
    public static final int DEFAULT_IO_CRITICAL_DURATION_SEC = 5;

    // 网络默认门限（四级，新增）
    public static final int DEFAULT_NET_COLLECT_INTERVAL_SEC = 5;
    public static final int DEFAULT_NET_SAMPLE_MILLIS = 1000;
    public static final double DEFAULT_NET_WARN_RATE = 10D * 1024D * 1024D;  // 10MB/s
    public static final int DEFAULT_NET_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_NET_MINOR_RATE = 30D * 1024D * 1024D;  // 30MB/s
    public static final int DEFAULT_NET_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_NET_MAJOR_RATE = 80D * 1024D * 1024D;  // 80MB/s
    public static final int DEFAULT_NET_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_NET_CRITICAL_RATE = 150D * 1024D * 1024D;  // 150MB/s
    public static final int DEFAULT_NET_CRITICAL_DURATION_SEC = 5;

    public static final int DEFAULT_RULE_COOLDOWN_SEC = 300;

    private OpmSysConst()
    {
    }

    public static boolean isEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_ENABLE, DEFAULT_ENABLE);
    }

    public static long getCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_COLLECT_INTERVAL_SEC, DEFAULT_COLLECT_INTERVAL_SEC);
    }

    public static int getCpuSampleMillis()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_SAMPLE_MILLIS, DEFAULT_CPU_SAMPLE_MILLIS);
    }

    public static long getDiskCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_DISK_COLLECT_INTERVAL_SEC, DEFAULT_DISK_COLLECT_INTERVAL_SEC);
    }

    // CPU 配置读取
    public static double getCpuWarnRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CPU_WARN_RATE, String.valueOf(DEFAULT_CPU_WARN_RATE)), DEFAULT_CPU_WARN_RATE);
    }

    public static int getCpuWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_WARN_DURATION_SEC, DEFAULT_CPU_WARN_DURATION_SEC);
    }

    public static double getCpuMinorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CPU_MINOR_RATE, String.valueOf(DEFAULT_CPU_MINOR_RATE)), DEFAULT_CPU_MINOR_RATE);
    }

    public static int getCpuMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_MINOR_DURATION_SEC, DEFAULT_CPU_MINOR_DURATION_SEC);
    }

    public static double getCpuMajorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CPU_MAJOR_RATE, String.valueOf(DEFAULT_CPU_MAJOR_RATE)), DEFAULT_CPU_MAJOR_RATE);
    }

    public static int getCpuMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_MAJOR_DURATION_SEC, DEFAULT_CPU_MAJOR_DURATION_SEC);
    }

    public static double getCpuCriticalRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CPU_CRITICAL_RATE, String.valueOf(DEFAULT_CPU_CRITICAL_RATE)), DEFAULT_CPU_CRITICAL_RATE);
    }

    public static int getCpuCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_CRITICAL_DURATION_SEC, DEFAULT_CPU_CRITICAL_DURATION_SEC);
    }

    // 内存 配置读取
    public static double getMemWarnRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_MEM_WARN_RATE, String.valueOf(DEFAULT_MEM_WARN_RATE)), DEFAULT_MEM_WARN_RATE);
    }

    public static int getMemWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MEM_WARN_DURATION_SEC, DEFAULT_MEM_WARN_DURATION_SEC);
    }

    public static double getMemMinorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_MEM_MINOR_RATE, String.valueOf(DEFAULT_MEM_MINOR_RATE)), DEFAULT_MEM_MINOR_RATE);
    }

    public static int getMemMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MEM_MINOR_DURATION_SEC, DEFAULT_MEM_MINOR_DURATION_SEC);
    }

    public static double getMemMajorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_MEM_MAJOR_RATE, String.valueOf(DEFAULT_MEM_MAJOR_RATE)), DEFAULT_MEM_MAJOR_RATE);
    }

    public static int getMemMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MEM_MAJOR_DURATION_SEC, DEFAULT_MEM_MAJOR_DURATION_SEC);
    }

    public static double getMemCriticalRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_MEM_CRITICAL_RATE, String.valueOf(DEFAULT_MEM_CRITICAL_RATE)), DEFAULT_MEM_CRITICAL_RATE);
    }

    public static int getMemCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MEM_CRITICAL_DURATION_SEC, DEFAULT_MEM_CRITICAL_DURATION_SEC);
    }

    // IO 配置读取（新增）
    public static long getIoCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_IO_COLLECT_INTERVAL_SEC, DEFAULT_IO_COLLECT_INTERVAL_SEC);
    }

    public static int getIoSampleMillis()
    {
        return OpmRuntimeConfig.getInt(CONF_IO_SAMPLE_MILLIS, DEFAULT_IO_SAMPLE_MILLIS);
    }

    public static double getIoWarnRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_IO_WARN_RATE, String.valueOf(DEFAULT_IO_WARN_RATE)), DEFAULT_IO_WARN_RATE);
    }

    public static int getIoWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_IO_WARN_DURATION_SEC, DEFAULT_IO_WARN_DURATION_SEC);
    }

    public static double getIoMinorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_IO_MINOR_RATE, String.valueOf(DEFAULT_IO_MINOR_RATE)), DEFAULT_IO_MINOR_RATE);
    }

    public static int getIoMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_IO_MINOR_DURATION_SEC, DEFAULT_IO_MINOR_DURATION_SEC);
    }

    public static double getIoMajorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_IO_MAJOR_RATE, String.valueOf(DEFAULT_IO_MAJOR_RATE)), DEFAULT_IO_MAJOR_RATE);
    }

    public static int getIoMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_IO_MAJOR_DURATION_SEC, DEFAULT_IO_MAJOR_DURATION_SEC);
    }

    public static double getIoCriticalRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_IO_CRITICAL_RATE, String.valueOf(DEFAULT_IO_CRITICAL_RATE)), DEFAULT_IO_CRITICAL_RATE);
    }

    public static int getIoCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_IO_CRITICAL_DURATION_SEC, DEFAULT_IO_CRITICAL_DURATION_SEC);
    }

    // 网络配置读取（新增）
    public static long getNetCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_NET_COLLECT_INTERVAL_SEC, DEFAULT_NET_COLLECT_INTERVAL_SEC);
    }

    public static int getNetSampleMillis()
    {
        return OpmRuntimeConfig.getInt(CONF_NET_SAMPLE_MILLIS, DEFAULT_NET_SAMPLE_MILLIS);
    }

    public static double getNetWarnRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_NET_WARN_RATE, String.valueOf(DEFAULT_NET_WARN_RATE)), DEFAULT_NET_WARN_RATE);
    }

    public static int getNetWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_NET_WARN_DURATION_SEC, DEFAULT_NET_WARN_DURATION_SEC);
    }

    public static double getNetMinorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_NET_MINOR_RATE, String.valueOf(DEFAULT_NET_MINOR_RATE)), DEFAULT_NET_MINOR_RATE);
    }

    public static int getNetMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_NET_MINOR_DURATION_SEC, DEFAULT_NET_MINOR_DURATION_SEC);
    }

    public static double getNetMajorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_NET_MAJOR_RATE, String.valueOf(DEFAULT_NET_MAJOR_RATE)), DEFAULT_NET_MAJOR_RATE);
    }

    public static int getNetMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_NET_MAJOR_DURATION_SEC, DEFAULT_NET_MAJOR_DURATION_SEC);
    }

    public static double getNetCriticalRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_NET_CRITICAL_RATE, String.valueOf(DEFAULT_NET_CRITICAL_RATE)), DEFAULT_NET_CRITICAL_RATE);
    }

    public static int getNetCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_NET_CRITICAL_DURATION_SEC, DEFAULT_NET_CRITICAL_DURATION_SEC);
    }

    public static int getRuleCooldownSec()
    {
        return bap.opm.OpmBackendConfig.getDefaultAlarmCooldownSec();
    }
}
