package bap.opm.collector.pg;

import com.leavay.common.util.ToolUtilities;

import bap.opm.cfg.OpmRuntimeConfig;

public class OpmPgConst
{
    public static final String COLLECTOR_KEY = "pg";
    public static final String COLLECTOR_LABEL = "PG数据库监控";

    public static final String CONF_ENABLE = "opm.pg.enable";
    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.pg.collectIntervalSec";
    public static final String CONF_DB_NAME = "opm.pg.dbName";
    public static final String CONF_LOW_FREQ_COLLECT_INTERVAL_SEC = "opm.pg.lowFreq.collectIntervalSec";
    public static final String CONF_SQL_ENABLE = "opm.pg.sql.enable";
    public static final String CONF_SPACE_ENABLE = "opm.pg.space.enable";
    public static final String CONF_LOCK_ENABLE = "opm.pg.lock.enable";
    public static final String CONF_CONN_ENABLE = "opm.pg.conn.enable";

    public static final String CONF_STORE_SQL_DETAIL = "opm.pg.storeSqlDetail";
    public static final String CONF_SQL_DETAIL_MAX_ROWS = "opm.pg.sqlDetailMaxRows";

    public static final String CONF_SQL_WARN_SEC = "opm.pg.sql.warnSec";
    public static final String CONF_SQL_MINOR_SEC = "opm.pg.sql.minorSec";
    public static final String CONF_SQL_MAJOR_SEC = "opm.pg.sql.majorSec";
    public static final String CONF_SQL_CRITICAL_SEC = "opm.pg.sql.criticalSec";

    public static final String CONF_SPACE_WARN_RATE = "opm.pg.space.warnRate";
    public static final String CONF_SPACE_WARN_DURATION_SEC = "opm.pg.space.warnDurationSec";
    public static final String CONF_SPACE_MINOR_RATE = "opm.pg.space.minorRate";
    public static final String CONF_SPACE_MINOR_DURATION_SEC = "opm.pg.space.minorDurationSec";
    public static final String CONF_SPACE_MAJOR_RATE = "opm.pg.space.majorRate";
    public static final String CONF_SPACE_MAJOR_DURATION_SEC = "opm.pg.space.majorDurationSec";
    public static final String CONF_SPACE_CRITICAL_RATE = "opm.pg.space.criticalRate";
    public static final String CONF_SPACE_CRITICAL_DURATION_SEC = "opm.pg.space.criticalDurationSec";

    public static final String CONF_LOCK_WARN_SEC = "opm.pg.lock.warnSec";
    public static final String CONF_LOCK_MINOR_SEC = "opm.pg.lock.minorSec";
    public static final String CONF_LOCK_MAJOR_SEC = "opm.pg.lock.majorSec";
    public static final String CONF_LOCK_CRITICAL_SEC = "opm.pg.lock.criticalSec";
    public static final String CONF_DEADLOCK_WARN_COUNT = "opm.pg.deadlock.warnCount";
    public static final String CONF_DEADLOCK_MINOR_COUNT = "opm.pg.deadlock.minorCount";
    public static final String CONF_DEADLOCK_MAJOR_COUNT = "opm.pg.deadlock.majorCount";
    public static final String CONF_DEADLOCK_CRITICAL_COUNT = "opm.pg.deadlock.criticalCount";

    public static final String CONF_CONN_WARN_RATE = "opm.pg.conn.warnRate";
    public static final String CONF_CONN_WARN_DURATION_SEC = "opm.pg.conn.warnDurationSec";
    public static final String CONF_CONN_MINOR_RATE = "opm.pg.conn.minorRate";
    public static final String CONF_CONN_MINOR_DURATION_SEC = "opm.pg.conn.minorDurationSec";
    public static final String CONF_CONN_MAJOR_RATE = "opm.pg.conn.majorRate";
    public static final String CONF_CONN_MAJOR_DURATION_SEC = "opm.pg.conn.majorDurationSec";
    public static final String CONF_CONN_CRITICAL_RATE = "opm.pg.conn.criticalRate";
    public static final String CONF_CONN_CRITICAL_DURATION_SEC = "opm.pg.conn.criticalDurationSec";

    public static final String CONF_REPLICATION_WARN_SEC = "opm.pg.replication.warnSec";
    public static final String CONF_REPLICATION_WARN_DURATION_SEC = "opm.pg.replication.warnDurationSec";
    public static final String CONF_REPLICATION_MINOR_SEC = "opm.pg.replication.minorSec";
    public static final String CONF_REPLICATION_MINOR_DURATION_SEC = "opm.pg.replication.minorDurationSec";
    public static final String CONF_REPLICATION_MAJOR_SEC = "opm.pg.replication.majorSec";
    public static final String CONF_REPLICATION_MAJOR_DURATION_SEC = "opm.pg.replication.majorDurationSec";
    public static final String CONF_REPLICATION_CRITICAL_SEC = "opm.pg.replication.criticalSec";
    public static final String CONF_REPLICATION_CRITICAL_DURATION_SEC = "opm.pg.replication.criticalDurationSec";
    public static final String CONF_REPLICATION_ENABLE = "opm.pg.replication.enable";

    public static final String CONF_RULE_COOLDOWN_SEC = "opm.pg.rule.cooldownSec";

    public static final String LABEL_ENABLE = "启用PG采集器";
    public static final String LABEL_COLLECT_INTERVAL_SEC = "采集周期秒";
    public static final String LABEL_DB_NAME = "监控数据库名";
    public static final String LABEL_LOW_FREQ_COLLECT_INTERVAL_SEC = "低频采集周期秒";
    public static final String LABEL_SQL_ENABLE = "启用长时SQL监控";
    public static final String LABEL_SPACE_ENABLE = "启用空间低频监控";
    public static final String LABEL_LOCK_ENABLE = "启用长时锁监控";
    public static final String LABEL_CONN_ENABLE = "启用连接监控";

    public static final String LABEL_STORE_SQL_DETAIL = "存储SQL详情";
    public static final String LABEL_SQL_DETAIL_MAX_ROWS = "SQL详情最大行数";

    public static final String LABEL_SQL_WARN_SEC = "SQL警告时长秒";
    public static final String LABEL_SQL_MINOR_SEC = "SQL次要时长秒";
    public static final String LABEL_SQL_MAJOR_SEC = "SQL主要时长秒";
    public static final String LABEL_SQL_CRITICAL_SEC = "SQL严重时长秒";

    public static final String LABEL_SPACE_WARN_RATE = "空间警告阈值";
    public static final String LABEL_SPACE_WARN_DURATION_SEC = "空间警告持续时间秒";
    public static final String LABEL_SPACE_MINOR_RATE = "空间次要阈值";
    public static final String LABEL_SPACE_MINOR_DURATION_SEC = "空间次要持续时间秒";
    public static final String LABEL_SPACE_MAJOR_RATE = "空间主要阈值";
    public static final String LABEL_SPACE_MAJOR_DURATION_SEC = "空间主要持续时间秒";
    public static final String LABEL_SPACE_CRITICAL_RATE = "空间严重阈值";
    public static final String LABEL_SPACE_CRITICAL_DURATION_SEC = "空间严重持续时间秒";

    public static final String LABEL_LOCK_WARN_SEC = "长时锁警告秒";
    public static final String LABEL_LOCK_MINOR_SEC = "长时锁次要秒";
    public static final String LABEL_LOCK_MAJOR_SEC = "长时锁主要秒";
    public static final String LABEL_LOCK_CRITICAL_SEC = "长时锁严重秒";
    public static final String LABEL_DEADLOCK_WARN_COUNT = "死锁警告次数";
    public static final String LABEL_DEADLOCK_MINOR_COUNT = "死锁次要次数";
    public static final String LABEL_DEADLOCK_MAJOR_COUNT = "死锁主要次数";
    public static final String LABEL_DEADLOCK_CRITICAL_COUNT = "死锁严重次数";

    public static final String LABEL_CONN_WARN_RATE = "连接警告阈值";
    public static final String LABEL_CONN_WARN_DURATION_SEC = "连接警告持续时间秒";
    public static final String LABEL_CONN_MINOR_RATE = "连接次要阈值";
    public static final String LABEL_CONN_MINOR_DURATION_SEC = "连接次要持续时间秒";
    public static final String LABEL_CONN_MAJOR_RATE = "连接主要阈值";
    public static final String LABEL_CONN_MAJOR_DURATION_SEC = "连接主要持续时间秒";
    public static final String LABEL_CONN_CRITICAL_RATE = "连接严重阈值";
    public static final String LABEL_CONN_CRITICAL_DURATION_SEC = "连接严重持续时间秒";

    public static final String LABEL_REPLICATION_WARN_SEC = "复制延迟警告秒";
    public static final String LABEL_REPLICATION_WARN_DURATION_SEC = "复制延迟警告持续时间秒";
    public static final String LABEL_REPLICATION_MINOR_SEC = "复制延迟次要秒";
    public static final String LABEL_REPLICATION_MINOR_DURATION_SEC = "复制延迟次要持续时间秒";
    public static final String LABEL_REPLICATION_MAJOR_SEC = "复制延迟主要秒";
    public static final String LABEL_REPLICATION_MAJOR_DURATION_SEC = "复制延迟主要持续时间秒";
    public static final String LABEL_REPLICATION_CRITICAL_SEC = "复制延迟严重秒";
    public static final String LABEL_REPLICATION_CRITICAL_DURATION_SEC = "复制延迟严重持续时间秒";
    public static final String LABEL_REPLICATION_ENABLE = "启用复制延迟告警";

    public static final String LABEL_RULE_COOLDOWN_SEC = "规则冷却秒";

    public static final boolean DEFAULT_ENABLE = true;
    public static final int DEFAULT_COLLECT_INTERVAL_SEC = 30;
    public static final String DEFAULT_DB_NAME = "postgres";
    public static final int DEFAULT_LOW_FREQ_COLLECT_INTERVAL_SEC = 86400;
    public static final boolean DEFAULT_SQL_ENABLE = true;
    public static final boolean DEFAULT_SPACE_ENABLE = true;
    public static final boolean DEFAULT_LOCK_ENABLE = true;
    public static final boolean DEFAULT_CONN_ENABLE = true;

    public static final boolean DEFAULT_STORE_SQL_DETAIL = true;
    public static final int DEFAULT_SQL_DETAIL_MAX_ROWS = 20;

    public static final int DEFAULT_SQL_WARN_SEC = 30;
    public static final int DEFAULT_SQL_MINOR_SEC = 60;
    public static final int DEFAULT_SQL_MAJOR_SEC = 120;
    public static final int DEFAULT_SQL_CRITICAL_SEC = 300;

    public static final double DEFAULT_SPACE_WARN_RATE = 0.70D;
    public static final int DEFAULT_SPACE_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_SPACE_MINOR_RATE = 0.80D;
    public static final int DEFAULT_SPACE_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_SPACE_MAJOR_RATE = 0.90D;
    public static final int DEFAULT_SPACE_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_SPACE_CRITICAL_RATE = 0.95D;
    public static final int DEFAULT_SPACE_CRITICAL_DURATION_SEC = 5;

    public static final int DEFAULT_LOCK_WARN_SEC = 10;
    public static final int DEFAULT_LOCK_MINOR_SEC = 30;
    public static final int DEFAULT_LOCK_MAJOR_SEC = 60;
    public static final int DEFAULT_LOCK_CRITICAL_SEC = 120;
    public static final int DEFAULT_DEADLOCK_WARN_COUNT = 1;
    public static final int DEFAULT_DEADLOCK_MINOR_COUNT = 3;
    public static final int DEFAULT_DEADLOCK_MAJOR_COUNT = 5;
    public static final int DEFAULT_DEADLOCK_CRITICAL_COUNT = 10;

    public static final double DEFAULT_CONN_WARN_RATE = 0.70D;
    public static final int DEFAULT_CONN_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_CONN_MINOR_RATE = 0.80D;
    public static final int DEFAULT_CONN_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_CONN_MAJOR_RATE = 0.90D;
    public static final int DEFAULT_CONN_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_CONN_CRITICAL_RATE = 0.95D;
    public static final int DEFAULT_CONN_CRITICAL_DURATION_SEC = 5;

    public static final int DEFAULT_REPLICATION_WARN_SEC = 10;
    public static final int DEFAULT_REPLICATION_WARN_DURATION_SEC = 60;
    public static final int DEFAULT_REPLICATION_MINOR_SEC = 30;
    public static final int DEFAULT_REPLICATION_MINOR_DURATION_SEC = 30;
    public static final int DEFAULT_REPLICATION_MAJOR_SEC = 60;
    public static final int DEFAULT_REPLICATION_MAJOR_DURATION_SEC = 15;
    public static final int DEFAULT_REPLICATION_CRITICAL_SEC = 120;
    public static final int DEFAULT_REPLICATION_CRITICAL_DURATION_SEC = 5;
    public static final boolean DEFAULT_REPLICATION_ENABLE = false;

    public static final int DEFAULT_RULE_COOLDOWN_SEC = 300;

    private OpmPgConst()
    {
    }

    public static boolean isEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_ENABLE, DEFAULT_ENABLE);
    }

    public static long getCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_COLLECT_INTERVAL_SEC, DEFAULT_COLLECT_INTERVAL_SEC);
    }

    public static String getDbName()
    {
        return OpmRuntimeConfig.getString(CONF_DB_NAME, DEFAULT_DB_NAME);
    }

    public static boolean isSqlEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_SQL_ENABLE, DEFAULT_SQL_ENABLE);
    }

    public static boolean isSpaceEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_SPACE_ENABLE, DEFAULT_SPACE_ENABLE);
    }

    public static boolean isLockEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_LOCK_ENABLE, DEFAULT_LOCK_ENABLE);
    }

    public static boolean isConnEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_CONN_ENABLE, DEFAULT_CONN_ENABLE);
    }

    public static long getLowFreqCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_LOW_FREQ_COLLECT_INTERVAL_SEC, DEFAULT_LOW_FREQ_COLLECT_INTERVAL_SEC);
    }

    public static boolean isStoreSqlDetail()
    {
        return OpmRuntimeConfig.getBoolean(CONF_STORE_SQL_DETAIL, DEFAULT_STORE_SQL_DETAIL);
    }

    public static int getSqlDetailMaxRows()
    {
        return OpmRuntimeConfig.getInt(CONF_SQL_DETAIL_MAX_ROWS, DEFAULT_SQL_DETAIL_MAX_ROWS);
    }

    public static int getSqlWarnSec()
    {
        return OpmRuntimeConfig.getInt(CONF_SQL_WARN_SEC, DEFAULT_SQL_WARN_SEC);
    }

    public static int getSqlMinorSec()
    {
        return OpmRuntimeConfig.getInt(CONF_SQL_MINOR_SEC, DEFAULT_SQL_MINOR_SEC);
    }

    public static int getSqlMajorSec()
    {
        return OpmRuntimeConfig.getInt(CONF_SQL_MAJOR_SEC, DEFAULT_SQL_MAJOR_SEC);
    }

    public static int getSqlCriticalSec()
    {
        return OpmRuntimeConfig.getInt(CONF_SQL_CRITICAL_SEC, DEFAULT_SQL_CRITICAL_SEC);
    }

    public static double getSpaceWarnRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_SPACE_WARN_RATE, String.valueOf(DEFAULT_SPACE_WARN_RATE)), DEFAULT_SPACE_WARN_RATE);
    }

    public static int getSpaceWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_SPACE_WARN_DURATION_SEC, DEFAULT_SPACE_WARN_DURATION_SEC);
    }

    public static double getSpaceMinorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_SPACE_MINOR_RATE, String.valueOf(DEFAULT_SPACE_MINOR_RATE)), DEFAULT_SPACE_MINOR_RATE);
    }

    public static int getSpaceMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_SPACE_MINOR_DURATION_SEC, DEFAULT_SPACE_MINOR_DURATION_SEC);
    }

    public static double getSpaceMajorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_SPACE_MAJOR_RATE, String.valueOf(DEFAULT_SPACE_MAJOR_RATE)), DEFAULT_SPACE_MAJOR_RATE);
    }

    public static int getSpaceMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_SPACE_MAJOR_DURATION_SEC, DEFAULT_SPACE_MAJOR_DURATION_SEC);
    }

    public static double getSpaceCriticalRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_SPACE_CRITICAL_RATE, String.valueOf(DEFAULT_SPACE_CRITICAL_RATE)), DEFAULT_SPACE_CRITICAL_RATE);
    }

    public static int getSpaceCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_SPACE_CRITICAL_DURATION_SEC, DEFAULT_SPACE_CRITICAL_DURATION_SEC);
    }

    public static int getLockWarnSec()
    {
        return OpmRuntimeConfig.getInt(CONF_LOCK_WARN_SEC, DEFAULT_LOCK_WARN_SEC);
    }

    public static int getLockMinorSec()
    {
        return OpmRuntimeConfig.getInt(CONF_LOCK_MINOR_SEC, DEFAULT_LOCK_MINOR_SEC);
    }

    public static int getLockMajorSec()
    {
        return OpmRuntimeConfig.getInt(CONF_LOCK_MAJOR_SEC, DEFAULT_LOCK_MAJOR_SEC);
    }

    public static int getLockCriticalSec()
    {
        return OpmRuntimeConfig.getInt(CONF_LOCK_CRITICAL_SEC, DEFAULT_LOCK_CRITICAL_SEC);
    }

    public static int getDeadlockWarnCount()
    {
        return OpmRuntimeConfig.getInt(CONF_DEADLOCK_WARN_COUNT, DEFAULT_DEADLOCK_WARN_COUNT);
    }

    public static int getDeadlockMinorCount()
    {
        return OpmRuntimeConfig.getInt(CONF_DEADLOCK_MINOR_COUNT, DEFAULT_DEADLOCK_MINOR_COUNT);
    }

    public static int getDeadlockMajorCount()
    {
        return OpmRuntimeConfig.getInt(CONF_DEADLOCK_MAJOR_COUNT, DEFAULT_DEADLOCK_MAJOR_COUNT);
    }

    public static int getDeadlockCriticalCount()
    {
        return OpmRuntimeConfig.getInt(CONF_DEADLOCK_CRITICAL_COUNT, DEFAULT_DEADLOCK_CRITICAL_COUNT);
    }

    public static double getConnWarnRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CONN_WARN_RATE, String.valueOf(DEFAULT_CONN_WARN_RATE)), DEFAULT_CONN_WARN_RATE);
    }

    public static int getConnWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CONN_WARN_DURATION_SEC, DEFAULT_CONN_WARN_DURATION_SEC);
    }

    public static double getConnMinorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CONN_MINOR_RATE, String.valueOf(DEFAULT_CONN_MINOR_RATE)), DEFAULT_CONN_MINOR_RATE);
    }

    public static int getConnMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CONN_MINOR_DURATION_SEC, DEFAULT_CONN_MINOR_DURATION_SEC);
    }

    public static double getConnMajorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CONN_MAJOR_RATE, String.valueOf(DEFAULT_CONN_MAJOR_RATE)), DEFAULT_CONN_MAJOR_RATE);
    }

    public static int getConnMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CONN_MAJOR_DURATION_SEC, DEFAULT_CONN_MAJOR_DURATION_SEC);
    }

    public static double getConnCriticalRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CONN_CRITICAL_RATE, String.valueOf(DEFAULT_CONN_CRITICAL_RATE)), DEFAULT_CONN_CRITICAL_RATE);
    }

    public static int getConnCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CONN_CRITICAL_DURATION_SEC, DEFAULT_CONN_CRITICAL_DURATION_SEC);
    }

    public static int getReplicationWarnSec()
    {
        return OpmRuntimeConfig.getInt(CONF_REPLICATION_WARN_SEC, DEFAULT_REPLICATION_WARN_SEC);
    }

    public static int getReplicationWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_REPLICATION_WARN_DURATION_SEC, DEFAULT_REPLICATION_WARN_DURATION_SEC);
    }

    public static int getReplicationMinorSec()
    {
        return OpmRuntimeConfig.getInt(CONF_REPLICATION_MINOR_SEC, DEFAULT_REPLICATION_MINOR_SEC);
    }

    public static int getReplicationMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_REPLICATION_MINOR_DURATION_SEC, DEFAULT_REPLICATION_MINOR_DURATION_SEC);
    }

    public static int getReplicationMajorSec()
    {
        return OpmRuntimeConfig.getInt(CONF_REPLICATION_MAJOR_SEC, DEFAULT_REPLICATION_MAJOR_SEC);
    }

    public static int getReplicationMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_REPLICATION_MAJOR_DURATION_SEC, DEFAULT_REPLICATION_MAJOR_DURATION_SEC);
    }

    public static int getReplicationCriticalSec()
    {
        return OpmRuntimeConfig.getInt(CONF_REPLICATION_CRITICAL_SEC, DEFAULT_REPLICATION_CRITICAL_SEC);
    }

    public static int getReplicationCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_REPLICATION_CRITICAL_DURATION_SEC, DEFAULT_REPLICATION_CRITICAL_DURATION_SEC);
    }

    public static boolean isReplicationEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_REPLICATION_ENABLE, DEFAULT_REPLICATION_ENABLE);
    }

    public static int getRuleCooldownSec()
    {
        return bap.opm.OpmBackendConfig.getDefaultAlarmCooldownSec();
    }
}
