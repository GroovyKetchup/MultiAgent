package bap.opm.collector.pg;

public class PgSqlQueries
{
    public static String queryLongSql(int minDurationSec, int limit)
    {
        return "SELECT pid, query, state, query_start, "
                + "EXTRACT(EPOCH FROM (now()-query_start)) as duration_sec, "
                + "wait_event_type, wait_event, application_name, client_addr::text "
                + "FROM pg_stat_activity "
                + "WHERE state = 'active' "
                + "AND query NOT LIKE '%autovacuum%' "
                + "AND query NOT LIKE 'pg_stat_activity%' "
                + "AND query_start < now() - interval '" + minDurationSec + " seconds' "
                + "ORDER BY duration_sec DESC "
                + "LIMIT " + limit;
    }

    public static String queryBlockedSql()
    {
        return "SELECT count(*) as blocked_count "
                + "FROM pg_stat_activity "
                + "WHERE wait_event_type = 'Lock' AND state = 'active'";
    }

    public static String queryDbSize()
    {
        return "SELECT datname, pg_database_size(datname) as size_bytes "
                + "FROM pg_database WHERE datistemplate = false";
    }

    public static String queryTablespaceSize()
    {
        return "SELECT spcname, pg_tablespace_size(oid) as size_bytes "
                + "FROM pg_tablespace";
    }

    public static String queryTableSizeTop(int limit)
    {
        return "SELECT relname, pg_total_relation_size(relid) as size_bytes "
                + "FROM pg_stat_user_tables "
                + "ORDER BY size_bytes DESC "
                + "LIMIT " + limit;
    }

    public static String queryLockWait(int limit)
    {
        return "SELECT blocked.pid as blocked_pid, blocked.usename as blocked_user_name, "
                + "blocked.application_name as blocked_application_name, blocked.client_addr::text as blocked_client_addr, "
                + "blocked.state as blocked_state, blocked.wait_event_type as blocked_wait_event_type, "
                + "blocked.wait_event as blocked_wait_event, blocked.backend_xid::text as blocked_backend_xid, "
                + "blocked.backend_xmin::text as blocked_backend_xmin, LEFT(blocked.query, 4000) as blocked_query, "
                + "EXTRACT(EPOCH FROM (now()-COALESCE(blocked.query_start, blocked.xact_start, blocked.state_change))) as wait_sec, "
                + "blocking.pid as blocking_pid, blocking.usename as blocking_user_name, "
                + "blocking.application_name as blocking_application_name, blocking.client_addr::text as blocking_client_addr, "
                + "blocking.state as blocking_state, blocking.wait_event_type as blocking_wait_event_type, "
                + "blocking.wait_event as blocking_wait_event, blocking.backend_xid::text as blocking_backend_xid, "
                + "blocking.backend_xmin::text as blocking_backend_xmin, LEFT(blocking.query, 4000) as blocking_query, "
                + "waiting.locktype as lock_type, waiting.mode as lock_mode, "
                + "CASE WHEN waiting.relation IS NULL THEN NULL ELSE waiting.relation::regclass::text END as relation_name, "
                + "waiting.page, waiting.tuple, waiting.virtualxid as virtual_xid, waiting.transactionid::text as transaction_id "
                + "FROM pg_stat_activity blocked "
                + "JOIN LATERAL unnest(pg_blocking_pids(blocked.pid)) AS blockers(blocking_pid) ON TRUE "
                + "LEFT JOIN pg_stat_activity blocking ON blocking.pid = blockers.blocking_pid "
                + "LEFT JOIN pg_locks waiting ON waiting.pid = blocked.pid AND NOT waiting.granted "
                + "WHERE blocked.datname = current_database() "
                + "AND blocked.pid <> pg_backend_pid() "
                + "ORDER BY wait_sec DESC NULLS LAST, blocked.pid "
                + "LIMIT " + limit;
    }

    public static String queryLongLockSessions(int limit)
    {
        return "SELECT a.pid, a.usename as user_name, a.application_name, a.client_addr::text as client_addr, "
                + "a.state, a.wait_event_type, a.wait_event, "
                + "a.backend_xid::text as backend_xid, a.backend_xmin::text as backend_xmin, "
                + "EXTRACT(EPOCH FROM a.xact_start) as xact_start_epoch, "
                + "EXTRACT(EPOCH FROM a.query_start) as query_start_epoch, "
                + "EXTRACT(EPOCH FROM a.state_change) as state_change_epoch, "
                + "EXTRACT(EPOCH FROM (now() - a.xact_start)) as xact_age_sec, "
                + "EXTRACT(EPOCH FROM (now() - a.query_start)) as query_age_sec, "
                + "EXTRACT(EPOCH FROM (now() - a.state_change)) as state_age_sec, "
                + "COALESCE(array_to_string(pg_blocking_pids(a.pid), ','), '') as blocking_pids, "
                + "rels.relation_names, rels.lock_modes, rels.granted_lock_count, LEFT(a.query, 4000) as query "
                + "FROM pg_stat_activity a "
                + "JOIN ("
                + "SELECT l.pid, "
                + "array_to_string(array_agg(DISTINCT c.relname ORDER BY c.relname), ',') as relation_names, "
                + "array_to_string(array_agg(DISTINCT l.mode ORDER BY l.mode), ',') as lock_modes, "
                + "count(*) as granted_lock_count "
                + "FROM pg_locks l "
                + "LEFT JOIN pg_class c ON l.relation = c.oid AND c.relkind = 'r' "
                + "WHERE l.granted "
                + "GROUP BY l.pid"
                + ") rels ON rels.pid = a.pid "
                + "WHERE a.datname = current_database() "
                + "AND a.pid <> pg_backend_pid() "
                + "AND a.state = 'active' "
                + "AND a.query_start IS NOT NULL "
                + "AND a.query IS NOT NULL AND a.query <> '' "
                + "ORDER BY COALESCE(EXTRACT(EPOCH FROM (now() - a.query_start)), 0) DESC, "
                + "COALESCE(EXTRACT(EPOCH FROM (now() - a.xact_start)), 0) DESC, a.pid "
                + "LIMIT " + limit;
    }

    public static String queryDeadlockStats()
    {
        return "SELECT datname, deadlocks, conflicts "
                + "FROM pg_stat_database "
                + "WHERE datname = current_database()";
    }

    public static String queryDeadlockSessionSnapshot(int limit)
    {
        return "SELECT a.pid, a.usename as user_name, a.application_name, a.client_addr::text as client_addr, "
                + "a.state, a.wait_event_type, a.wait_event, "
                + "a.backend_xid::text as backend_xid, a.backend_xmin::text as backend_xmin, "
                + "EXTRACT(EPOCH FROM (now() - a.xact_start)) as xact_age_sec, "
                + "EXTRACT(EPOCH FROM (now() - a.query_start)) as query_age_sec, "
                + "EXTRACT(EPOCH FROM (now() - a.state_change)) as state_age_sec, "
                + "COALESCE(array_to_string(pg_blocking_pids(a.pid), ','), '') as blocking_pids, "
                + "LEFT(a.query, 4000) as query "
                + "FROM pg_stat_activity a "
                + "WHERE a.datname = current_database() "
                + "AND a.pid <> pg_backend_pid() "
                + "AND ("
                + "a.state = 'idle in transaction (aborted)' "
                + "OR a.wait_event_type = 'Lock' "
                + "OR COALESCE(array_length(pg_blocking_pids(a.pid), 1), 0) > 0 "
                + "OR (a.state = 'active' AND a.query IS NOT NULL AND a.query <> '' "
                + "AND a.query NOT LIKE '%pg_stat_activity%' "
                + "AND a.query NOT LIKE '%pg_locks%')) "
                + "ORDER BY CASE "
                + "WHEN a.state = 'idle in transaction (aborted)' THEN 0 "
                + "WHEN a.wait_event_type = 'Lock' THEN 1 "
                + "WHEN COALESCE(array_length(pg_blocking_pids(a.pid), 1), 0) > 0 THEN 2 "
                + "ELSE 3 END, "
                + "COALESCE(a.state_change, a.query_start, a.xact_start) DESC NULLS LAST "
                + "LIMIT " + limit;
    }

    public static String queryDeadlockLockSnapshot(int limit)
    {
        return queryLockWait(limit);
    }

    public static String querySessionByPidOrXid(String pidArraySql, String xidArraySql, String txIdArraySql, int limit)
    {
        return "SELECT a.pid, a.usename as user_name, a.application_name, a.client_addr::text as client_addr, "
                + "a.state, a.wait_event_type, a.wait_event, "
                + "a.backend_xid::text as backend_xid, a.backend_xmin::text as backend_xmin, "
                + "EXTRACT(EPOCH FROM (now() - a.query_start)) as query_age_sec, "
                + "EXTRACT(EPOCH FROM (now() - a.xact_start)) as xact_age_sec, "
                + "COALESCE(array_to_string(pg_blocking_pids(a.pid), ','), '') as blocking_pids, "
                + "LEFT(a.query, 4000) as query "
                + "FROM pg_stat_activity a "
                + "WHERE a.datname = current_database() "
                + "AND a.pid <> pg_backend_pid() "
                + "AND ("
                + "a.pid = ANY(" + pidArraySql + ") "
                + "OR a.backend_xid::text = ANY(" + xidArraySql + ") "
                + "OR EXISTS (SELECT 1 FROM pg_locks l WHERE l.pid = a.pid AND l.transactionid::text = ANY(" + txIdArraySql + "))"
                + ") "
                + "ORDER BY COALESCE(a.state_change, a.query_start, a.xact_start) DESC NULLS LAST "
                + "LIMIT " + limit;
    }

    public static String queryTableLockRelatedSql(int limit)
    {
        return "SELECT a.pid, a.state, a.usename as user_name, a.application_name, a.client_addr::text as client_addr, "
                + "a.wait_event_type, a.wait_event, a.backend_xid::text as backend_xid, a.backend_xmin::text as backend_xmin, "
                + "EXTRACT(EPOCH FROM (now() - a.query_start)) as query_age_sec, "
                + "EXTRACT(EPOCH FROM (now() - a.xact_start)) as xact_age_sec, "
                + "COALESCE(array_to_string(pg_blocking_pids(a.pid), ','), '') as blocking_pids, "
                + "rels.relation_names, LEFT(a.query, 4000) as query "
                + "FROM pg_stat_activity a "
                + "JOIN ("
                + "SELECT l.pid, array_to_string(array_agg(DISTINCT t.relname ORDER BY t.relname), ',') as relation_names "
                + "FROM pg_locks l "
                + "JOIN pg_class t ON l.relation = t.oid AND t.relkind = 'r' "
                + "GROUP BY l.pid"
                + ") rels ON rels.pid = a.pid "
                + "WHERE a.datname = current_database() "
                + "AND a.pid <> pg_backend_pid() "
                + "AND a.state IS DISTINCT FROM 'idle' "
                + "ORDER BY CASE "
                + "WHEN a.wait_event_type = 'Lock' THEN 0 "
                + "WHEN a.state = 'idle in transaction' THEN 1 "
                + "WHEN a.state = 'idle in transaction (aborted)' THEN 2 "
                + "ELSE 3 END, "
                + "COALESCE(a.query_start, a.xact_start, a.state_change) DESC NULLS LAST "
                + "LIMIT " + limit;
    }

    public static String queryIdleInTransactionSql(int limit)
    {
        return "SELECT a.pid, a.state, a.usename as user_name, a.application_name, a.client_addr::text as client_addr, "
                + "a.wait_event_type, a.wait_event, a.backend_xid::text as backend_xid, a.backend_xmin::text as backend_xmin, "
                + "EXTRACT(EPOCH FROM (now() - a.query_start)) as query_age_sec, "
                + "EXTRACT(EPOCH FROM (now() - a.xact_start)) as xact_age_sec, "
                + "COALESCE(array_to_string(pg_blocking_pids(a.pid), ','), '') as blocking_pids, "
                + "rels.relation_names, LEFT(a.query, 4000) as query "
                + "FROM pg_stat_activity a "
                + "LEFT JOIN ("
                + "SELECT l.pid, array_to_string(array_agg(DISTINCT t.relname ORDER BY t.relname), ',') as relation_names "
                + "FROM pg_locks l "
                + "LEFT JOIN pg_class t ON l.relation = t.oid AND t.relkind = 'r' "
                + "WHERE l.granted "
                + "GROUP BY l.pid"
                + ") rels ON rels.pid = a.pid "
                + "WHERE a.datname = current_database() "
                + "AND a.pid <> pg_backend_pid() "
                + "AND a.state like 'idle in transaction%' "
                + "AND a.query IS NOT NULL AND a.query <> '' "
                + "ORDER BY COALESCE(a.xact_start, a.query_start, a.state_change) DESC NULLS LAST "
                + "LIMIT " + limit;
    }

    public static String queryConnectionStats()
    {
        return "SELECT "
                + "count(*) as total_conn, "
                + "count(*) FILTER (WHERE state = 'active') as active_conn, "
                + "count(*) FILTER (WHERE state = 'idle') as idle_conn, "
                + "count(*) FILTER (WHERE state = 'idle in transaction') as idle_in_txn_conn "
                + "FROM pg_stat_activity "
                + "WHERE backend_type = 'client backend'";
    }

    public static String queryConnectionStatsLegacy()
    {
        return "SELECT "
                + "count(*) as total_conn, "
                + "count(*) FILTER (WHERE state = 'active') as active_conn, "
                + "count(*) FILTER (WHERE state = 'idle') as idle_conn, "
                + "count(*) FILTER (WHERE state = 'idle in transaction') as idle_in_txn_conn "
                + "FROM pg_stat_activity "
                + "WHERE datname = current_database() "
                + "AND pid <> pg_backend_pid()";
    }

    public static String queryMaxConnections()
    {
        return "SELECT setting::int as max_conn FROM pg_settings WHERE name = 'max_connections'";
    }

    public static String queryTransactionStats()
    {
        return "SELECT xact_commit, xact_rollback "
                + "FROM pg_stat_database "
                + "WHERE datname = current_database()";
    }

    public static String queryReplicationPrimary()
    {
        return "SELECT 'primary' as role, "
                + "client_addr::text, state, sync_state, "
                + "EXTRACT(EPOCH FROM (now()-reply_time)) as lag_sec "
                + "FROM pg_stat_replication";
    }

    public static String queryReplicationStandby()
    {
        return "SELECT 'standby' as role, "
                + "pg_last_wal_receive_lsn() as receive_lsn, "
                + "pg_last_wal_replay_lsn() as replay_lsn, "
                + "CASE WHEN pg_last_wal_receive_lsn() = pg_last_wal_replay_lsn() "
                + "THEN 0 "
                + "ELSE EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp())) "
                + "END as lag_sec";
    }

    public static String queryIsInRecovery()
    {
        return "SELECT pg_is_in_recovery()";
    }

    private PgSqlQueries()
    {
    }
}
