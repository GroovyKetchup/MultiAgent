package bap.opm.collector.pg;

import bap.opm.registry.IOpmCollectorRegistry;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.registry.OpmAlarmRuleMeta;
import bap.opm.registry.OpmConfigParamMeta;
import bap.opm.registry.OpmConfigRegistry;

public class OpmPgCollectorRegistry implements IOpmCollectorRegistry
{
    public static final String COLLECTOR_KEY = "pg";

    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.pg.collectIntervalSec";

    public static final String CONF_SQL_WARN_SEC = "opm.pg.sql.warnSec";
    public static final String CONF_SQL_MINOR_SEC = "opm.pg.sql.minorSec";
    public static final String CONF_SQL_MAJOR_SEC = "opm.pg.sql.majorSec";
    public static final String CONF_SQL_CRITICAL_SEC = "opm.pg.sql.criticalSec";

    public static final String CONF_SPACE_WARN_RATE = "opm.pg.space.warnRate";
    public static final String CONF_SPACE_MINOR_RATE = "opm.pg.space.minorRate";
    public static final String CONF_SPACE_MAJOR_RATE = "opm.pg.space.majorRate";
    public static final String CONF_SPACE_CRITICAL_RATE = "opm.pg.space.criticalRate";

    public static final String CONF_DEADLOCK_WARN_COUNT = OpmPgConst.CONF_DEADLOCK_WARN_COUNT;
    public static final String CONF_DEADLOCK_MINOR_COUNT = OpmPgConst.CONF_DEADLOCK_MINOR_COUNT;
    public static final String CONF_DEADLOCK_MAJOR_COUNT = OpmPgConst.CONF_DEADLOCK_MAJOR_COUNT;
    public static final String CONF_DEADLOCK_CRITICAL_COUNT = OpmPgConst.CONF_DEADLOCK_CRITICAL_COUNT;

    public static final String CONF_LOCK_WARN_SEC = "opm.pg.lock.warnSec";
    public static final String CONF_LOCK_MINOR_SEC = "opm.pg.lock.minorSec";
    public static final String CONF_LOCK_MAJOR_SEC = "opm.pg.lock.majorSec";
    public static final String CONF_LOCK_CRITICAL_SEC = "opm.pg.lock.criticalSec";

    public static final String CONF_CONN_WARN_RATE = "opm.pg.conn.warnRate";
    public static final String CONF_CONN_MINOR_RATE = "opm.pg.conn.minorRate";
    public static final String CONF_CONN_MAJOR_RATE = "opm.pg.conn.majorRate";
    public static final String CONF_CONN_CRITICAL_RATE = "opm.pg.conn.criticalRate";

    public static final String CONF_REPLICATION_WARN_SEC = "opm.pg.replication.warnSec";
    public static final String CONF_REPLICATION_MINOR_SEC = "opm.pg.replication.minorSec";
    public static final String CONF_REPLICATION_MAJOR_SEC = "opm.pg.replication.majorSec";
    public static final String CONF_REPLICATION_CRITICAL_SEC = "opm.pg.replication.criticalSec";

    public static final String CONF_PROC_CPU_WARN_RATE = "opm.pg.proc.cpu.warnRate";
    public static final String CONF_PROC_CPU_MINOR_RATE = "opm.pg.proc.cpu.minorRate";
    public static final String CONF_PROC_CPU_MAJOR_RATE = "opm.pg.proc.cpu.majorRate";
    public static final String CONF_PROC_CPU_CRITICAL_RATE = "opm.pg.proc.cpu.criticalRate";

    @Override
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        registry.registerConfigParam(
                new OpmConfigParamMeta(CONF_COLLECT_INTERVAL_SEC, "采集周期", "int", "60")
                        .setDesc("PG采集周期（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("collect")
                        .setSingleParam(CONF_COLLECT_INTERVAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_PG_SQL, "SQL执行时长阈值", "int", "30")
                        .setDesc("SQL执行时长告警阈值（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_SQL_WARN_SEC, CONF_SQL_MINOR_SEC, CONF_SQL_MAJOR_SEC, CONF_SQL_CRITICAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_PG_SPACE, "表空间使用率阈值", "string", "0.8")
                        .setDesc("表空间使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_SPACE_WARN_RATE, CONF_SPACE_MINOR_RATE, CONF_SPACE_MAJOR_RATE, CONF_SPACE_CRITICAL_RATE));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_PG_DEADLOCK, "死锁数量阈值", "int", "1")
                        .setDesc("死锁数量告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_DEADLOCK_WARN_COUNT, CONF_DEADLOCK_MINOR_COUNT, CONF_DEADLOCK_MAJOR_COUNT, CONF_DEADLOCK_CRITICAL_COUNT));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_PG_LOCK, "长时锁阈值", "int", "30")
                        .setDesc("长时锁告警阈值（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_LOCK_WARN_SEC, CONF_LOCK_MINOR_SEC, CONF_LOCK_MAJOR_SEC, CONF_LOCK_CRITICAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_PG_CONN, "连接数使用率阈值", "string", "0.8")
                        .setDesc("连接数使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_CONN_WARN_RATE, CONF_CONN_MINOR_RATE, CONF_CONN_MAJOR_RATE, CONF_CONN_CRITICAL_RATE));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_PG_REPLICATION, "复制延迟阈值", "int", "30")
                        .setDesc("复制延迟告警阈值（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_REPLICATION_WARN_SEC, CONF_REPLICATION_MINOR_SEC, CONF_REPLICATION_MAJOR_SEC, CONF_REPLICATION_CRITICAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_PG_PROC_CPU, "进程CPU使用率阈值", "string", "0.8")
                        .setDesc("PG进程CPU使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_PROC_CPU_WARN_RATE, CONF_PROC_CPU_MINOR_RATE, CONF_PROC_CPU_MAJOR_RATE, CONF_PROC_CPU_CRITICAL_RATE));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_PG_SQL, "SQL执行时长过长")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_PG_SQL)
                        .setDesc("SQL执行时长超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_PG_SPACE, "表空间使用率过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_PG_SPACE)
                        .setDesc("表空间使用率超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_PG_DEADLOCK, "检测到死锁")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_PG_DEADLOCK)
                        .setDesc("检测到死锁数量超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_PG_LOCK, "长时锁")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_PG_LOCK)
                        .setDesc("检测到长时锁超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_PG_CONN, "连接数使用率过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_PG_CONN)
                        .setDesc("连接数使用率超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_PG_REPLICATION, "复制延迟过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_PG_REPLICATION)
                        .setDesc("复制延迟超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_PG_PROC_CPU, "进程CPU使用率过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_PG_PROC_CPU)
                        .setDesc("PG进程CPU使用率超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.buildExpectationRuleKey(COLLECTOR_KEY), "采集周期未达预期")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_COLLECT_INTERVAL_SEC)
                        .setDesc("PG采集周期未达到配置要求"));
    }
}
