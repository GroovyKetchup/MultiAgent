package bap.opm.collector.topcpu;

import bap.opm.registry.IOpmCollectorRegistry;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.registry.OpmAlarmRuleMeta;
import bap.opm.registry.OpmConfigParamMeta;
import bap.opm.registry.OpmConfigRegistry;
import tiny.service.md.TsAlarm;

/**
 * CPU采集器配置注册
 * 
 * <pre>
 * 示例：展示如何使用注册表模式
 * 
 * 优势：
 * 1. 配置项和规则集中定义
 * 2. 映射关系自动建立
 * 3. 新增规则只需添加一行代码
 * 4. 编译期就能发现错误
 * </pre>
 */
public class OpmTopCpuCollectorRegistry implements IOpmCollectorRegistry
{
    public static final String COLLECTOR_KEY = "topCpu";

    // 配置项常量
    public static final String CONF_COLLECT_INTERVAL_SEC = OpmTopCpuConst.CONF_COLLECT_INTERVAL_SEC;
    public static final String CONF_WARN_RATE = OpmTopCpuConst.CONF_WARN_RATE;
    public static final String CONF_MINOR_RATE = OpmTopCpuConst.CONF_MINOR_RATE;
    public static final String CONF_MAJOR_RATE = OpmTopCpuConst.CONF_MAJOR_RATE;
    public static final String CONF_CRITICAL_RATE = OpmTopCpuConst.CONF_CRITICAL_RATE;

    @Override
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        // 1. 注册采集周期配置项
        registry.registerConfigParam(
                new OpmConfigParamMeta(CONF_COLLECT_INTERVAL_SEC, "采集周期", "int", "60")
                        .setDesc("CPU采集周期（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("collect")
                        .setSingleParam(CONF_COLLECT_INTERVAL_SEC));

        // 2. 注册CPU使用率告警配置项（多级）
        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_TOP_CPU, "CPU使用率阈值", "string", "0.8")
                        .setDesc("CPU使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_WARN_RATE, CONF_MINOR_RATE, CONF_MAJOR_RATE, CONF_CRITICAL_RATE));

        // 3. 注册CPU使用率告警规则
        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_TOP_CPU, "CPU使用率过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_TOP_CPU)
                        .setDesc("CPU使用率超过阈值"));

        // 4. 注册采集周期预期告警规则
        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.buildExpectationRuleKey(COLLECTOR_KEY), "采集周期未达预期")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_COLLECT_INTERVAL_SEC)
                        .setDesc("CPU采集周期未达到配置要求"));
    }
}
