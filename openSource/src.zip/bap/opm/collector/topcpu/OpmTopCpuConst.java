package bap.opm.collector.topcpu;

import bap.opm.cfg.OpmRuntimeConfig;

public class OpmTopCpuConst
{
    public static final String COLLECTOR_KEY = "topCpu";
    public static final String COLLECTOR_LABEL = "TOP进程CPU监控";

    public static final String CONF_ENABLE = "opm.topCpu.enable";
    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.topCpu.collectIntervalSec";
    public static final String CONF_CPU_SAMPLE_MILLIS = "opm.topCpu.sampleMillis";
    public static final String CONF_TOP_PROC_SIZE = "opm.topCpu.topProcSize";
    public static final String CONF_WARN_RATE = "opm.topCpu.warnRate";
    public static final String CONF_WARN_DURATION_SEC = "opm.topCpu.warnDurationSec";
    public static final String CONF_MINOR_RATE = "opm.topCpu.minorRate";
    public static final String CONF_MINOR_DURATION_SEC = "opm.topCpu.minorDurationSec";
    public static final String CONF_MAJOR_RATE = "opm.topCpu.majorRate";
    public static final String CONF_MAJOR_DURATION_SEC = "opm.topCpu.majorDurationSec";
    public static final String CONF_CRITICAL_RATE = "opm.topCpu.criticalRate";
    public static final String CONF_CRITICAL_DURATION_SEC = "opm.topCpu.criticalDurationSec";
    public static final String CONF_RULE_COOLDOWN_SEC = "opm.topCpu.rule.cooldownSec";

    public static final String LABEL_ENABLE = "启用CPU采集器";
    public static final String LABEL_COLLECT_INTERVAL_SEC = "CPU采集周期秒";
    public static final String LABEL_CPU_SAMPLE_MILLIS = "CPU采样毫秒";
    public static final String LABEL_TOP_PROC_SIZE = "CPU Top进程数";
    public static final String LABEL_WARN_RATE = "CPU警告阈值";
    public static final String LABEL_WARN_DURATION_SEC = "CPU警告持续时间秒";
    public static final String LABEL_MINOR_RATE = "CPU次要阈值";
    public static final String LABEL_MINOR_DURATION_SEC = "CPU次要持续时间秒";
    public static final String LABEL_MAJOR_RATE = "CPU主要阈值";
    public static final String LABEL_MAJOR_DURATION_SEC = "CPU主要持续时间秒";
    public static final String LABEL_CRITICAL_RATE = "CPU严重阈值";
    public static final String LABEL_CRITICAL_DURATION_SEC = "CPU严重持续时间秒";
    public static final String LABEL_RULE_COOLDOWN_SEC = "CPU规则冷却秒";

    public static final boolean DEFAULT_ENABLE = true;
    public static final int DEFAULT_COLLECT_INTERVAL_SEC = 5;
    public static final int DEFAULT_CPU_SAMPLE_MILLIS = 1000;
    public static final int DEFAULT_TOP_PROC_SIZE = 20;
    public static final double DEFAULT_WARN_RATE = 0.70D;
    public static final int DEFAULT_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_MINOR_RATE = 0.80D;
    public static final int DEFAULT_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_MAJOR_RATE = 0.90D;
    public static final int DEFAULT_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_CRITICAL_RATE = 0.95D;
    public static final int DEFAULT_CRITICAL_DURATION_SEC = 5;
    public static final int DEFAULT_RULE_COOLDOWN_SEC = 300;

    private OpmTopCpuConst()
    {
    }

    public static boolean isEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_ENABLE, DEFAULT_ENABLE);
    }

    public static long getCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_COLLECT_INTERVAL_SEC, DEFAULT_COLLECT_INTERVAL_SEC);
    }

    public static int getCpuSampleMillis()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_SAMPLE_MILLIS, DEFAULT_CPU_SAMPLE_MILLIS);
    }

    public static int getTopProcSize()
    {
        return OpmRuntimeConfig.getInt(CONF_TOP_PROC_SIZE, DEFAULT_TOP_PROC_SIZE);
    }

    public static double getWarnRate()
    {
        return com.leavay.common.util.ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_WARN_RATE, String.valueOf(DEFAULT_WARN_RATE)), DEFAULT_WARN_RATE);
    }

    public static int getWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_WARN_DURATION_SEC, DEFAULT_WARN_DURATION_SEC);
    }

    public static double getMinorRate()
    {
        return com.leavay.common.util.ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_MINOR_RATE, String.valueOf(DEFAULT_MINOR_RATE)), DEFAULT_MINOR_RATE);
    }

    public static int getMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MINOR_DURATION_SEC, DEFAULT_MINOR_DURATION_SEC);
    }

    public static double getMajorRate()
    {
        return com.leavay.common.util.ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_MAJOR_RATE, String.valueOf(DEFAULT_MAJOR_RATE)), DEFAULT_MAJOR_RATE);
    }

    public static int getMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MAJOR_DURATION_SEC, DEFAULT_MAJOR_DURATION_SEC);
    }

    public static double getCriticalRate()
    {
        return com.leavay.common.util.ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CRITICAL_RATE, String.valueOf(DEFAULT_CRITICAL_RATE)), DEFAULT_CRITICAL_RATE);
    }

    public static int getCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CRITICAL_DURATION_SEC, DEFAULT_CRITICAL_DURATION_SEC);
    }

    public static int getRuleCooldownSec()
    {
        return bap.opm.OpmBackendConfig.getDefaultAlarmCooldownSec();
    }
}
