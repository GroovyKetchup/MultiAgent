package bap.opm.collector.topnet;

import bap.opm.registry.IOpmCollectorRegistry;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.registry.OpmAlarmRuleMeta;
import bap.opm.registry.OpmConfigParamMeta;
import bap.opm.registry.OpmConfigRegistry;

public class OpmTopNetCollectorRegistry implements IOpmCollectorRegistry
{
    public static final String COLLECTOR_KEY = "topNet";

    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.topNet.collectIntervalSec";
    public static final String CONF_WARN_RATE = "opm.topNet.warnRateBytesPerSec";
    public static final String CONF_MINOR_RATE = "opm.topNet.minorRateBytesPerSec";
    public static final String CONF_MAJOR_RATE = "opm.topNet.majorRateBytesPerSec";
    public static final String CONF_CRITICAL_RATE = "opm.topNet.criticalRateBytesPerSec";

    @Override
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        registry.registerConfigParam(
                new OpmConfigParamMeta(CONF_COLLECT_INTERVAL_SEC, "采集周期", "int", "5")
                        .setDesc("网络采集周期（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("collect")
                        .setSingleParam(CONF_COLLECT_INTERVAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_TOP_NET, "TOP进程网络阈值", "string", String.valueOf(5 * 1024 * 1024))
                        .setDesc("TOP进程网络吞吐告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_WARN_RATE, CONF_MINOR_RATE, CONF_MAJOR_RATE, CONF_CRITICAL_RATE));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_TOP_NET, "TOP进程网络过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_TOP_NET)
                        .setDesc("TOP进程网络吞吐超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.buildExpectationRuleKey(COLLECTOR_KEY), "采集周期未达预期")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_COLLECT_INTERVAL_SEC)
                        .setDesc("网络采集周期未达到配置要求"));
    }
}
