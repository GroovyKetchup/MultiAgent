package bap.opm.collector.topnet;

import bap.opm.cfg.OpmRuntimeConfig;

public class OpmTopNetConst
{
    public static final String COLLECTOR_KEY = "topNet";
    public static final String COLLECTOR_LABEL = "TOP进程网络监控";

    public static final String CONF_ENABLE = "opm.topNet.enable";
    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.topNet.collectIntervalSec";
    public static final String CONF_SAMPLE_MILLIS = "opm.topNet.sampleMillis";
    public static final String CONF_TOP_PROC_SIZE = "opm.topNet.topProcSize";
    public static final String CONF_WARN_RATE = "opm.topNet.warnRateBytesPerSec";
    public static final String CONF_WARN_DURATION_SEC = "opm.topNet.warnDurationSec";
    public static final String CONF_MINOR_RATE = "opm.topNet.minorRateBytesPerSec";
    public static final String CONF_MINOR_DURATION_SEC = "opm.topNet.minorDurationSec";
    public static final String CONF_MAJOR_RATE = "opm.topNet.majorRateBytesPerSec";
    public static final String CONF_MAJOR_DURATION_SEC = "opm.topNet.majorDurationSec";
    public static final String CONF_CRITICAL_RATE = "opm.topNet.criticalRateBytesPerSec";
    public static final String CONF_CRITICAL_DURATION_SEC = "opm.topNet.criticalDurationSec";
    public static final String CONF_RULE_COOLDOWN_SEC = "opm.topNet.rule.cooldownSec";

    public static final String LABEL_ENABLE = "启用网络采集器";
    public static final String LABEL_COLLECT_INTERVAL_SEC = "网络采集周期秒";
    public static final String LABEL_SAMPLE_MILLIS = "网络采样毫秒";
    public static final String LABEL_TOP_PROC_SIZE = "网络Top进程数";
    public static final String LABEL_WARN_RATE = "TOP进程网络警告阈值(Bps)";
    public static final String LABEL_WARN_DURATION_SEC = "TOP进程网络警告持续时间秒";
    public static final String LABEL_MINOR_RATE = "TOP进程网络次要阈值(Bps)";
    public static final String LABEL_MINOR_DURATION_SEC = "TOP进程网络次要持续时间秒";
    public static final String LABEL_MAJOR_RATE = "TOP进程网络主要阈值(Bps)";
    public static final String LABEL_MAJOR_DURATION_SEC = "TOP进程网络主要持续时间秒";
    public static final String LABEL_CRITICAL_RATE = "TOP进程网络严重阈值(Bps)";
    public static final String LABEL_CRITICAL_DURATION_SEC = "TOP进程网络严重持续时间秒";
    public static final String LABEL_RULE_COOLDOWN_SEC = "TOP进程网络规则冷却秒";

    public static final boolean DEFAULT_ENABLE = true;
    public static final int DEFAULT_COLLECT_INTERVAL_SEC = 5;
    public static final int DEFAULT_SAMPLE_MILLIS = 1000;
    public static final int DEFAULT_TOP_PROC_SIZE = 8;
    public static final double DEFAULT_WARN_RATE = 5D * 1024D * 1024D;
    public static final int DEFAULT_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_MINOR_RATE = 15D * 1024D * 1024D;
    public static final int DEFAULT_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_MAJOR_RATE = 30D * 1024D * 1024D;
    public static final int DEFAULT_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_CRITICAL_RATE = 50D * 1024D * 1024D;
    public static final int DEFAULT_CRITICAL_DURATION_SEC = 5;
    public static final int DEFAULT_RULE_COOLDOWN_SEC = 300;

    private OpmTopNetConst()
    {
    }

    public static boolean isEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_ENABLE, DEFAULT_ENABLE);
    }

    public static long getCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_COLLECT_INTERVAL_SEC, DEFAULT_COLLECT_INTERVAL_SEC);
    }

    public static int getSampleMillis()
    {
        return OpmRuntimeConfig.getInt(CONF_SAMPLE_MILLIS, DEFAULT_SAMPLE_MILLIS);
    }

    public static int getTopProcSize()
    {
        return OpmRuntimeConfig.getInt(CONF_TOP_PROC_SIZE, DEFAULT_TOP_PROC_SIZE);
    }

    public static double getWarnRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_WARN_RATE, DEFAULT_WARN_RATE);
    }

    public static int getWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_WARN_DURATION_SEC, DEFAULT_WARN_DURATION_SEC);
    }

    public static double getMinorRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_MINOR_RATE, DEFAULT_MINOR_RATE);
    }

    public static int getMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MINOR_DURATION_SEC, DEFAULT_MINOR_DURATION_SEC);
    }

    public static double getMajorRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_MAJOR_RATE, DEFAULT_MAJOR_RATE);
    }

    public static int getMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MAJOR_DURATION_SEC, DEFAULT_MAJOR_DURATION_SEC);
    }

    public static double getCriticalRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_CRITICAL_RATE, DEFAULT_CRITICAL_RATE);
    }

    public static int getCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CRITICAL_DURATION_SEC, DEFAULT_CRITICAL_DURATION_SEC);
    }

    public static int getRuleCooldownSec()
    {
        return bap.opm.OpmBackendConfig.getDefaultAlarmCooldownSec();
    }
}
