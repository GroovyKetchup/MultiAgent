package bap.opm.collector.diskpartition;

import bap.opm.cfg.OpmRuntimeConfig;
import bap.opm.collector.disk.OpmDiskConst;

public class OpmDiskPartitionConst
{
    public static final String COLLECTOR_KEY = "diskPartition";
    public static final String COLLECTOR_LABEL = "磁盘分区监控";

    public static final String CONF_ENABLE = "opm.diskPartition.enable";

    public static final String CONF_WARN_RATE = "opm.diskPartition.warnRate";
    public static final String CONF_CRITICAL_RATE = "opm.diskPartition.criticalRate";

    public static final String LABEL_ENABLE = "启用磁盘分区告警";
    public static final String LABEL_WARN_RATE = "分区预警阈值";
    public static final String LABEL_CRITICAL_RATE = "分区严重阈值";

    public static final boolean DEFAULT_ENABLE = true;
    public static final double DEFAULT_WARN_RATE = 0.90D;
    public static final double DEFAULT_CRITICAL_RATE = 0.97D;

    private OpmDiskPartitionConst()
    {
    }

    public static boolean isEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_ENABLE, DEFAULT_ENABLE);
    }

    public static long getCollectIntervalMs()
    {
        return OpmDiskConst.getCollectIntervalMs();
    }

    public static double getWarnRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_WARN_RATE, DEFAULT_WARN_RATE);
    }

    public static double getCriticalRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_CRITICAL_RATE, DEFAULT_CRITICAL_RATE);
    }
}