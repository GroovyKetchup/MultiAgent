package bap.opm.collector.diskpartition;

import bap.opm.registry.IOpmCollectorRegistry;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.registry.OpmAlarmRuleMeta;
import bap.opm.registry.OpmConfigParamMeta;
import bap.opm.registry.OpmConfigRegistry;

public class OpmDiskPartitionCollectorRegistry implements IOpmCollectorRegistry
{
    public static final String COLLECTOR_KEY = "diskPartition";
    
    public static final String CONF_WARN_RATE = "opm.diskPartition.warnRate";
    public static final String CONF_CRITICAL_RATE = "opm.diskPartition.criticalRate";

    @Override
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_DISK_PARTITION_USAGE, "分区使用率阈值", "string", "0.9")
                        .setDesc("磁盘分区使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_WARN_RATE, CONF_WARN_RATE, CONF_WARN_RATE, CONF_CRITICAL_RATE));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_DISK_PARTITION_WARN_PATTERN, "分区使用率过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_WARN_RATE)
                        .setDesc("磁盘分区使用率超过警告阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_DISK_PARTITION_CRITICAL_PATTERN, "分区使用率严重过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_CRITICAL_RATE)
                        .setDesc("磁盘分区使用率超过严重阈值"));
    }
}
