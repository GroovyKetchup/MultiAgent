package bap.opm.collector.topmemory;

import bap.opm.cfg.OpmRuntimeConfig;

public class OpmTopMemoryConst
{
    public static final String COLLECTOR_KEY = "topMemory";
    public static final String COLLECTOR_LABEL = "TOP进程内存监控";

    public static final String CONF_ENABLE = "opm.topMemory.enable";
    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.topMemory.collectIntervalSec";
    public static final String CONF_WARN_RATE = "opm.topMemory.warnRate";
    public static final String CONF_WARN_DURATION_SEC = "opm.topMemory.warnDurationSec";
    public static final String CONF_MINOR_RATE = "opm.topMemory.minorRate";
    public static final String CONF_MINOR_DURATION_SEC = "opm.topMemory.minorDurationSec";
    public static final String CONF_MAJOR_RATE = "opm.topMemory.majorRate";
    public static final String CONF_MAJOR_DURATION_SEC = "opm.topMemory.majorDurationSec";
    public static final String CONF_CRITICAL_RATE = "opm.topMemory.criticalRate";
    public static final String CONF_CRITICAL_DURATION_SEC = "opm.topMemory.criticalDurationSec";
    public static final String CONF_RULE_COOLDOWN_SEC = "opm.topMemory.rule.cooldownSec";

    public static final String LABEL_ENABLE = "启用内存采集器";
    public static final String LABEL_COLLECT_INTERVAL_SEC = "内存采集周期秒";
    public static final String LABEL_WARN_RATE = "内存警告阈值";
    public static final String LABEL_WARN_DURATION_SEC = "内存警告持续时间秒";
    public static final String LABEL_MINOR_RATE = "内存次要阈值";
    public static final String LABEL_MINOR_DURATION_SEC = "内存次要持续时间秒";
    public static final String LABEL_MAJOR_RATE = "内存主要阈值";
    public static final String LABEL_MAJOR_DURATION_SEC = "内存主要持续时间秒";
    public static final String LABEL_CRITICAL_RATE = "内存严重阈值";
    public static final String LABEL_CRITICAL_DURATION_SEC = "内存严重持续时间秒";
    public static final String LABEL_RULE_COOLDOWN_SEC = "内存规则冷却秒";

    public static final boolean DEFAULT_ENABLE = true;
    public static final int DEFAULT_COLLECT_INTERVAL_SEC = 5;
    public static final double DEFAULT_WARN_RATE = 0.70D;
    public static final int DEFAULT_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_MINOR_RATE = 0.80D;
    public static final int DEFAULT_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_MAJOR_RATE = 0.90D;
    public static final int DEFAULT_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_CRITICAL_RATE = 0.95D;
    public static final int DEFAULT_CRITICAL_DURATION_SEC = 5;
    public static final int DEFAULT_RULE_COOLDOWN_SEC = 300;

    private OpmTopMemoryConst()
    {
    }

    public static boolean isEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_ENABLE, DEFAULT_ENABLE);
    }

    public static long getCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_COLLECT_INTERVAL_SEC, DEFAULT_COLLECT_INTERVAL_SEC);
    }

    public static double getWarnRate()
    {
        return com.leavay.common.util.ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_WARN_RATE, String.valueOf(DEFAULT_WARN_RATE)), DEFAULT_WARN_RATE);
    }

    public static int getWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_WARN_DURATION_SEC, DEFAULT_WARN_DURATION_SEC);
    }

    public static double getMinorRate()
    {
        return com.leavay.common.util.ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_MINOR_RATE, String.valueOf(DEFAULT_MINOR_RATE)), DEFAULT_MINOR_RATE);
    }

    public static int getMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MINOR_DURATION_SEC, DEFAULT_MINOR_DURATION_SEC);
    }

    public static double getMajorRate()
    {
        return com.leavay.common.util.ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_MAJOR_RATE, String.valueOf(DEFAULT_MAJOR_RATE)), DEFAULT_MAJOR_RATE);
    }

    public static int getMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MAJOR_DURATION_SEC, DEFAULT_MAJOR_DURATION_SEC);
    }

    public static double getCriticalRate()
    {
        return com.leavay.common.util.ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CRITICAL_RATE, String.valueOf(DEFAULT_CRITICAL_RATE)), DEFAULT_CRITICAL_RATE);
    }

    public static int getCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CRITICAL_DURATION_SEC, DEFAULT_CRITICAL_DURATION_SEC);
    }

    public static int getRuleCooldownSec()
    {
        return bap.opm.OpmBackendConfig.getDefaultAlarmCooldownSec();
    }
}
