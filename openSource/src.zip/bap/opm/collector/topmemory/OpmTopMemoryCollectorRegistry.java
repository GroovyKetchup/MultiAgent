package bap.opm.collector.topmemory;

import bap.opm.registry.IOpmCollectorRegistry;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.registry.OpmAlarmRuleMeta;
import bap.opm.registry.OpmConfigParamMeta;
import bap.opm.registry.OpmConfigRegistry;

public class OpmTopMemoryCollectorRegistry implements IOpmCollectorRegistry
{
    public static final String COLLECTOR_KEY = "topMemory";

    public static final String CONF_COLLECT_INTERVAL_SEC = OpmTopMemoryConst.CONF_COLLECT_INTERVAL_SEC;
    public static final String CONF_WARN_RATE = OpmTopMemoryConst.CONF_WARN_RATE;
    public static final String CONF_MINOR_RATE = OpmTopMemoryConst.CONF_MINOR_RATE;
    public static final String CONF_MAJOR_RATE = OpmTopMemoryConst.CONF_MAJOR_RATE;
    public static final String CONF_CRITICAL_RATE = OpmTopMemoryConst.CONF_CRITICAL_RATE;

    @Override
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        registry.registerConfigParam(
                new OpmConfigParamMeta(CONF_COLLECT_INTERVAL_SEC, "采集周期", "int", "60")
                        .setDesc("内存采集周期（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("collect")
                        .setSingleParam(CONF_COLLECT_INTERVAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_TOP_MEMORY, "内存使用率阈值", "string", "0.8")
                        .setDesc("内存使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_WARN_RATE, CONF_MINOR_RATE, CONF_MAJOR_RATE, CONF_CRITICAL_RATE));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_TOP_MEMORY, "内存使用率过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_TOP_MEMORY)
                        .setDesc("内存使用率超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.buildExpectationRuleKey(COLLECTOR_KEY), "采集周期未达预期")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_COLLECT_INTERVAL_SEC)
                        .setDesc("内存采集周期未达到配置要求"));
    }
}
