package bap.opm.collector.disk;

import bap.opm.cfg.OpmRuntimeConfig;

public class OpmDiskConst
{
    public static final String COLLECTOR_KEY = "disk";
    public static final String COLLECTOR_LABEL = "磁盘监控";

    public static final String CONF_ENABLE = "opm.disk.enable";
    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.disk.collectIntervalSec";
    public static final String CONF_WARN_RATE = "opm.disk.warnRate";
    public static final String CONF_CRITICAL_RATE = "opm.disk.criticalRate";

    public static final String LABEL_ENABLE = "启用磁盘采集器";
    public static final String LABEL_COLLECT_INTERVAL_SEC = "磁盘采集周期秒";
    public static final String LABEL_WARN_RATE = "总体预警阈值";
    public static final String LABEL_CRITICAL_RATE = "总体严重阈值";

    public static final boolean DEFAULT_ENABLE = true;
    public static final int DEFAULT_COLLECT_INTERVAL_SEC = 600;
    public static final double DEFAULT_WARN_RATE = 0.85D;
    public static final double DEFAULT_CRITICAL_RATE = 0.95D;

    private OpmDiskConst()
    {
    }

    public static boolean isEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_ENABLE, DEFAULT_ENABLE);
    }

    public static long getCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_COLLECT_INTERVAL_SEC, DEFAULT_COLLECT_INTERVAL_SEC);
    }

    public static double getWarnRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_WARN_RATE, DEFAULT_WARN_RATE);
    }

    public static double getCriticalRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_CRITICAL_RATE, DEFAULT_CRITICAL_RATE);
    }
}
