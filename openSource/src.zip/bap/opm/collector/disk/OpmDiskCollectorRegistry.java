package bap.opm.collector.disk;

import bap.opm.registry.IOpmCollectorRegistry;
import bap.opm.registry.OpmAlarmRuleMeta;
import bap.opm.registry.OpmConfigParamMeta;
import bap.opm.registry.OpmConfigRegistry;

public class OpmDiskCollectorRegistry implements IOpmCollectorRegistry
{
    public static final String COLLECTOR_KEY = "disk";

    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.disk.collectIntervalSec";
    public static final String CONF_WARN_RATE = "opm.disk.warnRate";
    public static final String CONF_CRITICAL_RATE = "opm.disk.criticalRate";

    @Override
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        registry.registerConfigParam(
                new OpmConfigParamMeta(CONF_COLLECT_INTERVAL_SEC, "采集周期", "int", "600")
                        .setDesc("磁盘采集周期（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("collect")
                        .setSingleParam(CONF_COLLECT_INTERVAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta("disk.usage", "磁盘总体使用率阈值", "string", "0.85")
                        .setDesc("磁盘总体使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_WARN_RATE, CONF_WARN_RATE, CONF_WARN_RATE, CONF_CRITICAL_RATE));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta("disk.usageThreshold", "磁盘总体使用率过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta("disk.usage")
                        .setDesc("磁盘总体使用率超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta("collectExpectation.disk", "采集周期未达预期")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_COLLECT_INTERVAL_SEC)
                        .setDesc("磁盘采集周期未达到配置要求"));
    }
}
