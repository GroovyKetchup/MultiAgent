package bap.opm.collector.topio;

import bap.opm.registry.IOpmCollectorRegistry;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.registry.OpmAlarmRuleMeta;
import bap.opm.registry.OpmConfigParamMeta;
import bap.opm.registry.OpmConfigRegistry;

public class OpmTopIoCollectorRegistry implements IOpmCollectorRegistry
{
    public static final String COLLECTOR_KEY = "topIo";

    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.topIo.collectIntervalSec";
    public static final String CONF_WARN_RATE = "opm.topIo.warnRateBytesPerSec";
    public static final String CONF_MINOR_RATE = "opm.topIo.minorRateBytesPerSec";
    public static final String CONF_MAJOR_RATE = "opm.topIo.majorRateBytesPerSec";
    public static final String CONF_CRITICAL_RATE = "opm.topIo.criticalRateBytesPerSec";
    
    @Override
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        registry.registerConfigParam(
                new OpmConfigParamMeta(CONF_COLLECT_INTERVAL_SEC, "采集周期", "int", "60")
                        .setDesc("IO采集周期（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("collect")
                        .setSingleParam(CONF_COLLECT_INTERVAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_TOP_IO, "TOP进程IO阈值", "string", String.valueOf(10 * 1024 * 1024))
                        .setDesc("TOP进程 IO 吞吐告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("alarm")
                        .setLevelParams(CONF_WARN_RATE, CONF_MINOR_RATE, CONF_MAJOR_RATE, CONF_CRITICAL_RATE));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_TOP_IO, "TOP进程IO过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_TOP_IO)
                        .setDesc("TOP进程 IO 吞吐超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.buildExpectationRuleKey(COLLECTOR_KEY), "采集周期未达预期")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_COLLECT_INTERVAL_SEC)
                        .setDesc("IO采集周期未达到配置要求"));
    }
}
