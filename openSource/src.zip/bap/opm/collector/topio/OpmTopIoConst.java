package bap.opm.collector.topio;

import bap.opm.cfg.OpmRuntimeConfig;

public class OpmTopIoConst
{
    public static final String COLLECTOR_KEY = "topIo";
    public static final String COLLECTOR_LABEL = "TOP进程IO监控";

    public static final String CONF_ENABLE = "opm.topIo.enable";
    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.topIo.collectIntervalSec";
    public static final String CONF_SAMPLE_MILLIS = "opm.topIo.sampleMillis";
    public static final String CONF_TOP_PROC_SIZE = "opm.topIo.topProcSize";
    public static final String CONF_WARN_RATE = "opm.topIo.warnRateBytesPerSec";
    public static final String CONF_WARN_DURATION_SEC = "opm.topIo.warnDurationSec";
    public static final String CONF_MINOR_RATE = "opm.topIo.minorRateBytesPerSec";
    public static final String CONF_MINOR_DURATION_SEC = "opm.topIo.minorDurationSec";
    public static final String CONF_MAJOR_RATE = "opm.topIo.majorRateBytesPerSec";
    public static final String CONF_MAJOR_DURATION_SEC = "opm.topIo.majorDurationSec";
    public static final String CONF_CRITICAL_RATE = "opm.topIo.criticalRateBytesPerSec";
    public static final String CONF_CRITICAL_DURATION_SEC = "opm.topIo.criticalDurationSec";
    public static final String CONF_RULE_COOLDOWN_SEC = "opm.topIo.rule.cooldownSec";

    public static final String LABEL_ENABLE = "启用IO采集器";
    public static final String LABEL_COLLECT_INTERVAL_SEC = "IO采集周期秒";
    public static final String LABEL_SAMPLE_MILLIS = "IO采样毫秒";
    public static final String LABEL_TOP_PROC_SIZE = "IO Top进程数";
    public static final String LABEL_WARN_RATE = "TOP进程IO警告阈值(Bps)";
    public static final String LABEL_WARN_DURATION_SEC = "TOP进程IO警告持续时间秒";
    public static final String LABEL_MINOR_RATE = "TOP进程IO次要阈值(Bps)";
    public static final String LABEL_MINOR_DURATION_SEC = "TOP进程IO次要持续时间秒";
    public static final String LABEL_MAJOR_RATE = "TOP进程IO主要阈值(Bps)";
    public static final String LABEL_MAJOR_DURATION_SEC = "TOP进程IO主要持续时间秒";
    public static final String LABEL_CRITICAL_RATE = "TOP进程IO严重阈值(Bps)";
    public static final String LABEL_CRITICAL_DURATION_SEC = "TOP进程IO严重持续时间秒";
    public static final String LABEL_RULE_COOLDOWN_SEC = "TOP进程IO规则冷却秒";

    public static final boolean DEFAULT_ENABLE = true;
    public static final int DEFAULT_COLLECT_INTERVAL_SEC = 5;
    public static final int DEFAULT_SAMPLE_MILLIS = 1000;
    public static final int DEFAULT_TOP_PROC_SIZE = 8;
    public static final double DEFAULT_WARN_RATE = 10D * 1024D * 1024D;
    public static final int DEFAULT_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_MINOR_RATE = 30D * 1024D * 1024D;
    public static final int DEFAULT_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_MAJOR_RATE = 60D * 1024D * 1024D;
    public static final int DEFAULT_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_CRITICAL_RATE = 100D * 1024D * 1024D;
    public static final int DEFAULT_CRITICAL_DURATION_SEC = 5;
    public static final int DEFAULT_RULE_COOLDOWN_SEC = 300;

    private OpmTopIoConst()
    {
    }

    public static boolean isEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_ENABLE, DEFAULT_ENABLE);
    }

    public static long getCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_COLLECT_INTERVAL_SEC, DEFAULT_COLLECT_INTERVAL_SEC);
    }

    public static int getSampleMillis()
    {
        return OpmRuntimeConfig.getInt(CONF_SAMPLE_MILLIS, DEFAULT_SAMPLE_MILLIS);
    }

    public static int getTopProcSize()
    {
        return OpmRuntimeConfig.getInt(CONF_TOP_PROC_SIZE, DEFAULT_TOP_PROC_SIZE);
    }

    public static double getWarnRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_WARN_RATE, DEFAULT_WARN_RATE);
    }

    public static int getWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_WARN_DURATION_SEC, DEFAULT_WARN_DURATION_SEC);
    }

    public static double getMinorRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_MINOR_RATE, DEFAULT_MINOR_RATE);
    }

    public static int getMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MINOR_DURATION_SEC, DEFAULT_MINOR_DURATION_SEC);
    }

    public static double getMajorRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_MAJOR_RATE, DEFAULT_MAJOR_RATE);
    }

    public static int getMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MAJOR_DURATION_SEC, DEFAULT_MAJOR_DURATION_SEC);
    }

    public static double getCriticalRate()
    {
        return OpmRuntimeConfig.getDouble(CONF_CRITICAL_RATE, DEFAULT_CRITICAL_RATE);
    }

    public static int getCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CRITICAL_DURATION_SEC, DEFAULT_CRITICAL_DURATION_SEC);
    }

    public static int getRuleCooldownSec()
    {
        return bap.opm.OpmBackendConfig.getDefaultAlarmCooldownSec();
    }
}
