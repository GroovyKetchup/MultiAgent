package bap.opm.collector.focus;

import bap.opm.OpmParamDef;
import bap.opm.cfg.OpmConfigGroup;

public class OpmFocusConfigSupport
{
    private OpmFocusConfigSupport()
    {
    }

    public static OpmConfigGroup buildFocusGroup()
    {
        OpmConfigGroup root = new OpmConfigGroup(OpmFocusConst.COLLECTOR_KEY, OpmFocusConst.COLLECTOR_LABEL)
                .setDesc("统一配置重点进程特征，并对匹配进程的 CPU / IO / 内存指标进行持续性分级告警。 ");

        root.addParam(new OpmParamDef(OpmFocusConst.CONF_ENABLE, OpmFocusConst.LABEL_ENABLE, "boolean", String.valueOf(OpmFocusConst.DEFAULT_ENABLE)));
        root.addParam(new OpmParamDef(OpmFocusConst.CONF_COLLECT_INTERVAL_SEC, OpmFocusConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_COLLECT_INTERVAL_SEC)));

        OpmConfigGroup identity = new OpmConfigGroup("identity", "进程特征")
                .setDesc("通过 PID、进程名、可执行路径匹配重点进程；三类条件任一命中即视为重点进程。");
        
        OpmParamDef pidParam = new OpmParamDef(OpmFocusConst.CONF_MATCH_PIDS, OpmFocusConst.LABEL_MATCH_PIDS, "string", OpmFocusConst.DEFAULT_MATCH_PIDS);
        pidParam.setDesc("重点进程PID列表，多项用逗号分隔。支持通配符: *匹配任意字符，?匹配单个字符。例如: 12345,23456 或 123* 匹配123开头的PID");
        identity.addParam(pidParam);
        
        OpmParamDef nameParam = new OpmParamDef(OpmFocusConst.CONF_MATCH_PROCESS_NAMES, OpmFocusConst.LABEL_MATCH_PROCESS_NAMES, "string", OpmFocusConst.DEFAULT_MATCH_PROCESS_NAMES);
        nameParam.setDesc("重点进程名称列表，多项用逗号分隔。支持通配符(*和?)和叠加符(+)。\n" +
                "通配符: *匹配任意字符，?匹配单个字符。例如: java* 匹配java、javaw等；post*sql 匹配postgresql等。\n" +
                "叠加符+: 结尾加+表示将该模式匹配的所有进程指标叠加计算。例如: postgresql+ 会将所有postgresql进程的CPU/内存/IO叠加后作为整体进行告警判断。\n" +
                "组合示例: java*,postgres+ 表示java开头的进程单独监控，所有postgres进程叠加监控。");
        identity.addParam(nameParam);
        
        OpmParamDef pathParam = new OpmParamDef(OpmFocusConst.CONF_MATCH_PROCESS_PATHS, OpmFocusConst.LABEL_MATCH_PROCESS_PATHS, "string", OpmFocusConst.DEFAULT_MATCH_PROCESS_PATHS);
        pathParam.setDesc("重点进程路径列表，多项用逗号分隔。支持通配符(*和?)和叠加符(+)。\n" +
                "通配符: *匹配任意字符，?匹配单个字符。例如: */bin/java 匹配任意目录下的bin/java。\n" +
                "叠加符+: 结尾加+表示将该模式匹配的所有进程指标叠加计算。例如: */app/myapp+ 会将所有匹配该路径的进程叠加监控。\n" +
                "注意: +只能出现在结尾，否则配置校验会报错。");
        identity.addParam(pathParam);
        
        root.addGroup(identity);

        OpmConfigGroup cpu = new OpmConfigGroup("focusCpu", "重点进程CPU")
                .setDesc("按重点进程 CPU 占整机总 CPU 资源的比例进行持续超阈值告警。 ");
        cpu.addParam(new OpmParamDef(OpmFocusConst.CONF_CPU_WARN_RATE, OpmFocusConst.LABEL_CPU_WARN_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_CPU_WARN_RATE)));
        cpu.addParam(new OpmParamDef(OpmFocusConst.CONF_CPU_WARN_DURATION_SEC, OpmFocusConst.LABEL_CPU_WARN_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_CPU_WARN_DURATION_SEC)));
        cpu.addParam(new OpmParamDef(OpmFocusConst.CONF_CPU_MINOR_RATE, OpmFocusConst.LABEL_CPU_MINOR_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_CPU_MINOR_RATE)));
        cpu.addParam(new OpmParamDef(OpmFocusConst.CONF_CPU_MINOR_DURATION_SEC, OpmFocusConst.LABEL_CPU_MINOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_CPU_MINOR_DURATION_SEC)));
        cpu.addParam(new OpmParamDef(OpmFocusConst.CONF_CPU_MAJOR_RATE, OpmFocusConst.LABEL_CPU_MAJOR_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_CPU_MAJOR_RATE)));
        cpu.addParam(new OpmParamDef(OpmFocusConst.CONF_CPU_MAJOR_DURATION_SEC, OpmFocusConst.LABEL_CPU_MAJOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_CPU_MAJOR_DURATION_SEC)));
        cpu.addParam(new OpmParamDef(OpmFocusConst.CONF_CPU_CRITICAL_RATE, OpmFocusConst.LABEL_CPU_CRITICAL_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_CPU_CRITICAL_RATE)));
        cpu.addParam(new OpmParamDef(OpmFocusConst.CONF_CPU_CRITICAL_DURATION_SEC, OpmFocusConst.LABEL_CPU_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_CPU_CRITICAL_DURATION_SEC)));
        root.addGroup(cpu);

        OpmConfigGroup io = new OpmConfigGroup("focusIo", "重点进程IO")
                .setDesc("按重点进程读写总吞吐速率进行持续超阈值告警，阈值单位为字节每秒。 ");
        io.addParam(new OpmParamDef(OpmFocusConst.CONF_IO_WARN_RATE, OpmFocusConst.LABEL_IO_WARN_RATE, "string", String.valueOf((long) OpmFocusConst.DEFAULT_IO_WARN_RATE)));
        io.addParam(new OpmParamDef(OpmFocusConst.CONF_IO_WARN_DURATION_SEC, OpmFocusConst.LABEL_IO_WARN_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_IO_WARN_DURATION_SEC)));
        io.addParam(new OpmParamDef(OpmFocusConst.CONF_IO_MINOR_RATE, OpmFocusConst.LABEL_IO_MINOR_RATE, "string", String.valueOf((long) OpmFocusConst.DEFAULT_IO_MINOR_RATE)));
        io.addParam(new OpmParamDef(OpmFocusConst.CONF_IO_MINOR_DURATION_SEC, OpmFocusConst.LABEL_IO_MINOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_IO_MINOR_DURATION_SEC)));
        io.addParam(new OpmParamDef(OpmFocusConst.CONF_IO_MAJOR_RATE, OpmFocusConst.LABEL_IO_MAJOR_RATE, "string", String.valueOf((long) OpmFocusConst.DEFAULT_IO_MAJOR_RATE)));
        io.addParam(new OpmParamDef(OpmFocusConst.CONF_IO_MAJOR_DURATION_SEC, OpmFocusConst.LABEL_IO_MAJOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_IO_MAJOR_DURATION_SEC)));
        io.addParam(new OpmParamDef(OpmFocusConst.CONF_IO_CRITICAL_RATE, OpmFocusConst.LABEL_IO_CRITICAL_RATE, "string", String.valueOf((long) OpmFocusConst.DEFAULT_IO_CRITICAL_RATE)));
        io.addParam(new OpmParamDef(OpmFocusConst.CONF_IO_CRITICAL_DURATION_SEC, OpmFocusConst.LABEL_IO_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_IO_CRITICAL_DURATION_SEC)));
        root.addGroup(io);

        OpmConfigGroup memory = new OpmConfigGroup("focusMemory", "重点进程内存")
                .setDesc("按重点进程常驻内存占用进行持续超阈值告警，阈值单位为字节。 ");
        memory.addParam(new OpmParamDef(OpmFocusConst.CONF_MEMORY_WARN_BYTES, OpmFocusConst.LABEL_MEMORY_WARN_BYTES, "string", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_WARN_BYTES)));
        memory.addParam(new OpmParamDef(OpmFocusConst.CONF_MEMORY_WARN_DURATION_SEC, OpmFocusConst.LABEL_MEMORY_WARN_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_WARN_DURATION_SEC)));
        memory.addParam(new OpmParamDef(OpmFocusConst.CONF_MEMORY_MINOR_BYTES, OpmFocusConst.LABEL_MEMORY_MINOR_BYTES, "string", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_MINOR_BYTES)));
        memory.addParam(new OpmParamDef(OpmFocusConst.CONF_MEMORY_MINOR_DURATION_SEC, OpmFocusConst.LABEL_MEMORY_MINOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_MINOR_DURATION_SEC)));
        memory.addParam(new OpmParamDef(OpmFocusConst.CONF_MEMORY_MAJOR_BYTES, OpmFocusConst.LABEL_MEMORY_MAJOR_BYTES, "string", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_MAJOR_BYTES)));
        memory.addParam(new OpmParamDef(OpmFocusConst.CONF_MEMORY_MAJOR_DURATION_SEC, OpmFocusConst.LABEL_MEMORY_MAJOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_MAJOR_DURATION_SEC)));
        memory.addParam(new OpmParamDef(OpmFocusConst.CONF_MEMORY_CRITICAL_BYTES, OpmFocusConst.LABEL_MEMORY_CRITICAL_BYTES, "string", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_CRITICAL_BYTES)));
        memory.addParam(new OpmParamDef(OpmFocusConst.CONF_MEMORY_CRITICAL_DURATION_SEC, OpmFocusConst.LABEL_MEMORY_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_CRITICAL_DURATION_SEC)));
        root.addGroup(memory);

        return root;
    }
}
