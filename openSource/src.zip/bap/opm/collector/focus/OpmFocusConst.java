package bap.opm.collector.focus;

import com.leavay.common.util.ToolUtilities;

import bap.opm.cfg.OpmRuntimeConfig;

public class OpmFocusConst
{
    public static final String COLLECTOR_KEY = "focus";
    public static final String COLLECTOR_LABEL = "重点进程监控";

    public static final String CONF_ENABLE = "opm.focus.enable";
    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.focus.collectIntervalSec";

    public static final String CONF_MATCH_PIDS = "opm.focus.match.pids";
    public static final String CONF_MATCH_PROCESS_NAMES = "opm.focus.match.processNames";
    public static final String CONF_MATCH_PROCESS_PATHS = "opm.focus.match.processPaths";

    public static final String CONF_CPU_WARN_RATE = "opm.focus.cpu.warnRate";
    public static final String CONF_CPU_WARN_DURATION_SEC = "opm.focus.cpu.warnDurationSec";
    public static final String CONF_CPU_MINOR_RATE = "opm.focus.cpu.minorRate";
    public static final String CONF_CPU_MINOR_DURATION_SEC = "opm.focus.cpu.minorDurationSec";
    public static final String CONF_CPU_MAJOR_RATE = "opm.focus.cpu.majorRate";
    public static final String CONF_CPU_MAJOR_DURATION_SEC = "opm.focus.cpu.majorDurationSec";
    public static final String CONF_CPU_CRITICAL_RATE = "opm.focus.cpu.criticalRate";
    public static final String CONF_CPU_CRITICAL_DURATION_SEC = "opm.focus.cpu.criticalDurationSec";

    public static final String CONF_MEMORY_WARN_BYTES = "opm.focus.memory.warnBytes";
    public static final String CONF_MEMORY_WARN_DURATION_SEC = "opm.focus.memory.warnDurationSec";
    public static final String CONF_MEMORY_MINOR_BYTES = "opm.focus.memory.minorBytes";
    public static final String CONF_MEMORY_MINOR_DURATION_SEC = "opm.focus.memory.minorDurationSec";
    public static final String CONF_MEMORY_MAJOR_BYTES = "opm.focus.memory.majorBytes";
    public static final String CONF_MEMORY_MAJOR_DURATION_SEC = "opm.focus.memory.majorDurationSec";
    public static final String CONF_MEMORY_CRITICAL_BYTES = "opm.focus.memory.criticalBytes";
    public static final String CONF_MEMORY_CRITICAL_DURATION_SEC = "opm.focus.memory.criticalDurationSec";

    public static final String CONF_IO_WARN_RATE = "opm.focus.io.warnRateBytesPerSec";
    public static final String CONF_IO_WARN_DURATION_SEC = "opm.focus.io.warnDurationSec";
    public static final String CONF_IO_MINOR_RATE = "opm.focus.io.minorRateBytesPerSec";
    public static final String CONF_IO_MINOR_DURATION_SEC = "opm.focus.io.minorDurationSec";
    public static final String CONF_IO_MAJOR_RATE = "opm.focus.io.majorRateBytesPerSec";
    public static final String CONF_IO_MAJOR_DURATION_SEC = "opm.focus.io.majorDurationSec";
    public static final String CONF_IO_CRITICAL_RATE = "opm.focus.io.criticalRateBytesPerSec";
    public static final String CONF_IO_CRITICAL_DURATION_SEC = "opm.focus.io.criticalDurationSec";

    public static final String CONF_RULE_COOLDOWN_SEC = "opm.focus.rule.cooldownSec";

    public static final String LABEL_ENABLE = "启用重点进程监控";
    public static final String LABEL_COLLECT_INTERVAL_SEC = "重点进程采集周期秒";

    public static final String LABEL_MATCH_PIDS = "重点进程PID列表";
    public static final String LABEL_MATCH_PROCESS_NAMES = "重点进程名称列表";
    public static final String LABEL_MATCH_PROCESS_PATHS = "重点进程路径列表";

    public static final String LABEL_CPU_WARN_RATE = "重点进程CPU警告阈值";
    public static final String LABEL_CPU_WARN_DURATION_SEC = "重点进程CPU警告持续时间秒";
    public static final String LABEL_CPU_MINOR_RATE = "重点进程CPU次要阈值";
    public static final String LABEL_CPU_MINOR_DURATION_SEC = "重点进程CPU次要持续时间秒";
    public static final String LABEL_CPU_MAJOR_RATE = "重点进程CPU主要阈值";
    public static final String LABEL_CPU_MAJOR_DURATION_SEC = "重点进程CPU主要持续时间秒";
    public static final String LABEL_CPU_CRITICAL_RATE = "重点进程CPU严重阈值";
    public static final String LABEL_CPU_CRITICAL_DURATION_SEC = "重点进程CPU严重持续时间秒";

    public static final String LABEL_MEMORY_WARN_BYTES = "重点进程内存警告阈值";
    public static final String LABEL_MEMORY_WARN_DURATION_SEC = "重点进程内存警告持续时间秒";
    public static final String LABEL_MEMORY_MINOR_BYTES = "重点进程内存次要阈值";
    public static final String LABEL_MEMORY_MINOR_DURATION_SEC = "重点进程内存次要持续时间秒";
    public static final String LABEL_MEMORY_MAJOR_BYTES = "重点进程内存主要阈值";
    public static final String LABEL_MEMORY_MAJOR_DURATION_SEC = "重点进程内存主要持续时间秒";
    public static final String LABEL_MEMORY_CRITICAL_BYTES = "重点进程内存严重阈值";
    public static final String LABEL_MEMORY_CRITICAL_DURATION_SEC = "重点进程内存严重持续时间秒";

    public static final String LABEL_IO_WARN_RATE = "重点进程IO警告阈值(B/s)";
    public static final String LABEL_IO_WARN_DURATION_SEC = "重点进程IO警告持续时间秒";
    public static final String LABEL_IO_MINOR_RATE = "重点进程IO次要阈值(B/s)";
    public static final String LABEL_IO_MINOR_DURATION_SEC = "重点进程IO次要持续时间秒";
    public static final String LABEL_IO_MAJOR_RATE = "重点进程IO主要阈值(B/s)";
    public static final String LABEL_IO_MAJOR_DURATION_SEC = "重点进程IO主要持续时间秒";
    public static final String LABEL_IO_CRITICAL_RATE = "重点进程IO严重阈值(B/s)";
    public static final String LABEL_IO_CRITICAL_DURATION_SEC = "重点进程IO严重持续时间秒";

    public static final String LABEL_RULE_COOLDOWN_SEC = "重点进程规则冷却秒";

    public static final boolean DEFAULT_ENABLE = true;
    public static final int DEFAULT_COLLECT_INTERVAL_SEC = 5;

    public static final String DEFAULT_MATCH_PIDS = "";
    public static final String DEFAULT_MATCH_PROCESS_NAMES = "";
    public static final String DEFAULT_MATCH_PROCESS_PATHS = "";

    public static final double DEFAULT_CPU_WARN_RATE = 0.50D;
    public static final int DEFAULT_CPU_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_CPU_MINOR_RATE = 0.70D;
    public static final int DEFAULT_CPU_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_CPU_MAJOR_RATE = 0.85D;
    public static final int DEFAULT_CPU_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_CPU_CRITICAL_RATE = 0.95D;
    public static final int DEFAULT_CPU_CRITICAL_DURATION_SEC = 5;

    public static final long DEFAULT_MEMORY_WARN_BYTES = 512L * 1024L * 1024L;
    public static final int DEFAULT_MEMORY_WARN_DURATION_SEC = 60;
    public static final long DEFAULT_MEMORY_MINOR_BYTES = 1024L * 1024L * 1024L;
    public static final int DEFAULT_MEMORY_MINOR_DURATION_SEC = 30;
    public static final long DEFAULT_MEMORY_MAJOR_BYTES = 2L * 1024L * 1024L * 1024L;
    public static final int DEFAULT_MEMORY_MAJOR_DURATION_SEC = 15;
    public static final long DEFAULT_MEMORY_CRITICAL_BYTES = 4L * 1024L * 1024L * 1024L;
    public static final int DEFAULT_MEMORY_CRITICAL_DURATION_SEC = 5;

    public static final double DEFAULT_IO_WARN_RATE = 10D * 1024D * 1024D;
    public static final int DEFAULT_IO_WARN_DURATION_SEC = 60;
    public static final double DEFAULT_IO_MINOR_RATE = 30D * 1024D * 1024D;
    public static final int DEFAULT_IO_MINOR_DURATION_SEC = 30;
    public static final double DEFAULT_IO_MAJOR_RATE = 80D * 1024D * 1024D;
    public static final int DEFAULT_IO_MAJOR_DURATION_SEC = 15;
    public static final double DEFAULT_IO_CRITICAL_RATE = 150D * 1024D * 1024D;
    public static final int DEFAULT_IO_CRITICAL_DURATION_SEC = 5;

    public static final int DEFAULT_RULE_COOLDOWN_SEC = 300;

    private OpmFocusConst()
    {
    }

    public static boolean isEnable()
    {
        return OpmRuntimeConfig.getBoolean(CONF_ENABLE, DEFAULT_ENABLE);
    }

    public static long getCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(CONF_COLLECT_INTERVAL_SEC, DEFAULT_COLLECT_INTERVAL_SEC);
    }

    public static String getMatchPids()
    {
        return OpmRuntimeConfig.getString(CONF_MATCH_PIDS, DEFAULT_MATCH_PIDS);
    }

    public static String getMatchProcessNames()
    {
        return OpmRuntimeConfig.getString(CONF_MATCH_PROCESS_NAMES, DEFAULT_MATCH_PROCESS_NAMES);
    }

    public static String getMatchProcessPaths()
    {
        return OpmRuntimeConfig.getString(CONF_MATCH_PROCESS_PATHS, DEFAULT_MATCH_PROCESS_PATHS);
    }

    public static double getCpuWarnRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CPU_WARN_RATE, String.valueOf(DEFAULT_CPU_WARN_RATE)), DEFAULT_CPU_WARN_RATE);
    }

    public static int getCpuWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_WARN_DURATION_SEC, DEFAULT_CPU_WARN_DURATION_SEC);
    }

    public static double getCpuMinorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CPU_MINOR_RATE, String.valueOf(DEFAULT_CPU_MINOR_RATE)), DEFAULT_CPU_MINOR_RATE);
    }

    public static int getCpuMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_MINOR_DURATION_SEC, DEFAULT_CPU_MINOR_DURATION_SEC);
    }

    public static double getCpuMajorRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CPU_MAJOR_RATE, String.valueOf(DEFAULT_CPU_MAJOR_RATE)), DEFAULT_CPU_MAJOR_RATE);
    }

    public static int getCpuMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_MAJOR_DURATION_SEC, DEFAULT_CPU_MAJOR_DURATION_SEC);
    }

    public static double getCpuCriticalRate()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_CPU_CRITICAL_RATE, String.valueOf(DEFAULT_CPU_CRITICAL_RATE)), DEFAULT_CPU_CRITICAL_RATE);
    }

    public static int getCpuCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_CPU_CRITICAL_DURATION_SEC, DEFAULT_CPU_CRITICAL_DURATION_SEC);
    }

    public static long getMemoryWarnBytes()
    {
        return OpmRuntimeConfig.getLong(CONF_MEMORY_WARN_BYTES, DEFAULT_MEMORY_WARN_BYTES);
    }

    public static int getMemoryWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MEMORY_WARN_DURATION_SEC, DEFAULT_MEMORY_WARN_DURATION_SEC);
    }

    public static long getMemoryMinorBytes()
    {
        return OpmRuntimeConfig.getLong(CONF_MEMORY_MINOR_BYTES, DEFAULT_MEMORY_MINOR_BYTES);
    }

    public static int getMemoryMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MEMORY_MINOR_DURATION_SEC, DEFAULT_MEMORY_MINOR_DURATION_SEC);
    }

    public static long getMemoryMajorBytes()
    {
        return OpmRuntimeConfig.getLong(CONF_MEMORY_MAJOR_BYTES, DEFAULT_MEMORY_MAJOR_BYTES);
    }

    public static int getMemoryMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MEMORY_MAJOR_DURATION_SEC, DEFAULT_MEMORY_MAJOR_DURATION_SEC);
    }

    public static long getMemoryCriticalBytes()
    {
        return OpmRuntimeConfig.getLong(CONF_MEMORY_CRITICAL_BYTES, DEFAULT_MEMORY_CRITICAL_BYTES);
    }

    public static int getMemoryCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_MEMORY_CRITICAL_DURATION_SEC, DEFAULT_MEMORY_CRITICAL_DURATION_SEC);
    }

    public static double getIoWarnRateBytesPerSec()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_IO_WARN_RATE, String.valueOf(DEFAULT_IO_WARN_RATE)), DEFAULT_IO_WARN_RATE);
    }

    public static int getIoWarnDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_IO_WARN_DURATION_SEC, DEFAULT_IO_WARN_DURATION_SEC);
    }

    public static double getIoMinorRateBytesPerSec()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_IO_MINOR_RATE, String.valueOf(DEFAULT_IO_MINOR_RATE)), DEFAULT_IO_MINOR_RATE);
    }

    public static int getIoMinorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_IO_MINOR_DURATION_SEC, DEFAULT_IO_MINOR_DURATION_SEC);
    }

    public static double getIoMajorRateBytesPerSec()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_IO_MAJOR_RATE, String.valueOf(DEFAULT_IO_MAJOR_RATE)), DEFAULT_IO_MAJOR_RATE);
    }

    public static int getIoMajorDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_IO_MAJOR_DURATION_SEC, DEFAULT_IO_MAJOR_DURATION_SEC);
    }

    public static double getIoCriticalRateBytesPerSec()
    {
        return ToolUtilities.getDouble(OpmRuntimeConfig.getString(CONF_IO_CRITICAL_RATE, String.valueOf(DEFAULT_IO_CRITICAL_RATE)), DEFAULT_IO_CRITICAL_RATE);
    }

    public static int getIoCriticalDurationSec()
    {
        return OpmRuntimeConfig.getInt(CONF_IO_CRITICAL_DURATION_SEC, DEFAULT_IO_CRITICAL_DURATION_SEC);
    }

    public static int getRuleCooldownSec()
    {
        return bap.opm.OpmBackendConfig.getDefaultAlarmCooldownSec();
    }
}