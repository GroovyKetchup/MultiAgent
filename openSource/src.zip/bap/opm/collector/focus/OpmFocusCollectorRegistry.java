package bap.opm.collector.focus;

import bap.opm.registry.IOpmCollectorRegistry;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.registry.OpmAlarmRuleMeta;
import bap.opm.registry.OpmConfigParamMeta;
import bap.opm.registry.OpmConfigRegistry;

public class OpmFocusCollectorRegistry implements IOpmCollectorRegistry
{
    public static final String COLLECTOR_KEY = "focus";

    public static final String CONF_COLLECT_INTERVAL_SEC = "opm.focus.collectIntervalSec";
    
    public static final String CONF_CPU_WARN_RATE = OpmFocusConst.CONF_CPU_WARN_RATE;
    public static final String CONF_CPU_MINOR_RATE = OpmFocusConst.CONF_CPU_MINOR_RATE;
    public static final String CONF_CPU_MAJOR_RATE = OpmFocusConst.CONF_CPU_MAJOR_RATE;
    public static final String CONF_CPU_CRITICAL_RATE = OpmFocusConst.CONF_CPU_CRITICAL_RATE;

    public static final String CONF_MEMORY_WARN_BYTES = OpmFocusConst.CONF_MEMORY_WARN_BYTES;
    public static final String CONF_MEMORY_MINOR_BYTES = OpmFocusConst.CONF_MEMORY_MINOR_BYTES;
    public static final String CONF_MEMORY_MAJOR_BYTES = OpmFocusConst.CONF_MEMORY_MAJOR_BYTES;
    public static final String CONF_MEMORY_CRITICAL_BYTES = OpmFocusConst.CONF_MEMORY_CRITICAL_BYTES;

    public static final String CONF_IO_WARN_RATE = OpmFocusConst.CONF_IO_WARN_RATE;
    public static final String CONF_IO_MINOR_RATE = OpmFocusConst.CONF_IO_MINOR_RATE;
    public static final String CONF_IO_MAJOR_RATE = OpmFocusConst.CONF_IO_MAJOR_RATE;
    public static final String CONF_IO_CRITICAL_RATE = OpmFocusConst.CONF_IO_CRITICAL_RATE;

    @Override
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        registry.registerConfigParam(
                new OpmConfigParamMeta(CONF_COLLECT_INTERVAL_SEC, "采集周期", "int", "5")
                        .setDesc("重点进程采集周期（秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("collect")
                        .setSingleParam(CONF_COLLECT_INTERVAL_SEC));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_FOCUS_CPU, "重点进程CPU阈值", "string", "0.5")
                        .setDesc("重点进程CPU使用率告警阈值")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("focus")
                        .setLevelParams(CONF_CPU_WARN_RATE, CONF_CPU_MINOR_RATE, CONF_CPU_MAJOR_RATE, CONF_CPU_CRITICAL_RATE));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_FOCUS_MEMORY, "重点进程内存阈值", "string", "2147483648")
                        .setDesc("重点进程内存告警阈值（字节）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("focus")
                        .setLevelParams(CONF_MEMORY_WARN_BYTES, CONF_MEMORY_MINOR_BYTES, CONF_MEMORY_MAJOR_BYTES, CONF_MEMORY_CRITICAL_BYTES));

        registry.registerConfigParam(
                new OpmConfigParamMeta(OpmAlarmConfigKeys.META_FOCUS_IO, "重点进程IO阈值", "string", "10485760")
                        .setDesc("重点进程IO速率告警阈值（字节/秒）")
                        .setCollector(COLLECTOR_KEY)
                        .setCategory("focus")
                        .setLevelParams(CONF_IO_WARN_RATE, CONF_IO_MINOR_RATE, CONF_IO_MAJOR_RATE, CONF_IO_CRITICAL_RATE));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_FOCUS_CPU_PATTERN, "重点进程CPU持续过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_FOCUS_CPU)
                        .setDesc("重点进程CPU使用率持续超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_FOCUS_MEMORY_PATTERN, "重点进程内存持续过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_FOCUS_MEMORY)
                        .setDesc("重点进程内存使用持续超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.RULE_FOCUS_IO_PATTERN, "重点进程IO持续过高")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParamMeta(OpmAlarmConfigKeys.META_FOCUS_IO)
                        .setDesc("重点进程IO速率持续超过阈值"));

        registry.registerAlarmRule(
                new OpmAlarmRuleMeta(OpmAlarmConfigKeys.buildExpectationRuleKey(COLLECTOR_KEY), "采集周期未达预期")
                        .setCollector(COLLECTOR_KEY)
                        .setConfigParam(CONF_COLLECT_INTERVAL_SEC)
                        .setDesc("重点进程采集周期未达到配置要求"));
    }
}
