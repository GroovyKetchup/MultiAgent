package bap.opm.collector.focus;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import com.leavay.common.util.ToolUtilities;

public class OpmFocusMatcher
{
    public static class RuleSet
    {
        public final Set<Integer> pidSet = new LinkedHashSet<Integer>();
        public final List<String> pidPatterns = new ArrayList<String>();
        public final Set<String> nameSet = new LinkedHashSet<String>();
        public final List<Pattern> namePatterns = new ArrayList<Pattern>();
        public final List<Pattern> nameAggregatePatterns = new ArrayList<Pattern>();
        public final Set<String> pathSet = new LinkedHashSet<String>();
        public final List<Pattern> pathPatterns = new ArrayList<Pattern>();
        public final List<Pattern> pathAggregatePatterns = new ArrayList<Pattern>();

        public boolean isEmpty()
        {
            return pidSet.isEmpty() && pidPatterns.isEmpty()
                    && nameSet.isEmpty() && namePatterns.isEmpty() && nameAggregatePatterns.isEmpty()
                    && pathSet.isEmpty() && pathPatterns.isEmpty() && pathAggregatePatterns.isEmpty();
        }

        public boolean hasAggregateRules()
        {
            return !nameAggregatePatterns.isEmpty() || !pathAggregatePatterns.isEmpty();
        }
    }

    public static class MatchResult
    {
        public boolean matched;
        public boolean aggregate;
        public String aggregateKey;

        public static final MatchResult NO_MATCH = new MatchResult(false, false, null);
        public static final MatchResult MATCH_NORMAL = new MatchResult(true, false, null);

        public MatchResult(boolean matched, boolean aggregate, String aggregateKey)
        {
            this.matched = matched;
            this.aggregate = aggregate;
            this.aggregateKey = aggregateKey;
        }

        public static MatchResult aggregate(String key)
        {
            return new MatchResult(true, true, key);
        }
    }

    public static class MatchSet
    {
        public boolean matched;
        public boolean singleMatched;
        public final List<String> aggregateKeys = new ArrayList<String>();

        public boolean hasAggregateMatch()
        {
            return !aggregateKeys.isEmpty();
        }

        public void addAggregateKey(String key)
        {
            if (ToolUtilities.isStringEmpty(key, true))
                return;
            if (!aggregateKeys.contains(key))
                aggregateKeys.add(key);
            matched = true;
        }

        public void markSingleMatched()
        {
            singleMatched = true;
            matched = true;
        }
    }

    public static class ProcIdentity
    {
        public int pid;
        public String processName;
        public String processPath;

        public String getStableKey()
        {
            if (pid >= 0)
                return "pid:" + pid;
            String path = normalizePath(processPath);
            if (!ToolUtilities.isStringEmpty(path, true))
                return "path:" + path;
            String name = normalizeName(processName);
            if (!ToolUtilities.isStringEmpty(name, true))
                return "name:" + name;
            return "unknown";
        }
    }

    private OpmFocusMatcher()
    {
    }

    public static String validateConfig(String pids, String names, String paths)
    {
        String error = validatePatternList(pids, "PID");
        if (error != null)
            return error;
        error = validatePatternList(names, "进程名");
        if (error != null)
            return error;
        error = validatePatternList(paths, "进程路径");
        if (error != null)
            return error;
        return null;
    }

    protected static String validatePatternList(String text, String fieldName)
    {
        if (ToolUtilities.isStringEmpty(text, true))
            return null;
        String[] arr = text.split("[,;\\r\\n]");
        for (String one : arr)
        {
            String trimmed = one.trim();
            if (ToolUtilities.isStringEmpty(trimmed, true))
                continue;
            int plusIndex = trimmed.indexOf('+');
            if (plusIndex >= 0 && plusIndex != trimmed.length() - 1)
            {
                return fieldName + "配置错误: '+' 只能出现在结尾，当前配置: " + trimmed;
            }
        }
        return null;
    }

    public static RuleSet loadRuleSet()
    {
        return buildRuleSet(OpmFocusConst.getMatchPids(), OpmFocusConst.getMatchProcessNames(), OpmFocusConst.getMatchProcessPaths());
    }

    public static RuleSet buildRuleSet(String pids, String names, String paths)
    {
        RuleSet rules = new RuleSet();
        parsePidRules(pids, rules.pidSet, rules.pidPatterns);
        parseNameRules(names, rules.nameSet, rules.namePatterns, rules.nameAggregatePatterns);
        parsePathRules(paths, rules.pathSet, rules.pathPatterns, rules.pathAggregatePatterns);
        return rules;
    }

    public static boolean matches(RuleSet rules, int pid, String processName, String processPath)
    {
        return matchAll(rules, pid, processName, processPath).matched;
    }

    public static MatchResult match(RuleSet rules, int pid, String processName, String processPath)
    {
        MatchSet set = matchAll(rules, pid, processName, processPath);
        if (!set.matched)
            return MatchResult.NO_MATCH;
        if (set.singleMatched)
            return MatchResult.MATCH_NORMAL;
        if (set.hasAggregateMatch())
            return MatchResult.aggregate(set.aggregateKeys.get(0));
        return MatchResult.NO_MATCH;
    }

    public static MatchSet matchAll(RuleSet rules, int pid, String processName, String processPath)
    {
        MatchSet result = new MatchSet();
        if (rules == null || rules.isEmpty())
            return result;

        if (rules.pidSet.contains(Integer.valueOf(pid)))
            result.markSingleMatched();

        if (!rules.pidPatterns.isEmpty())
        {
            String pidStr = String.valueOf(pid);
            for (String pattern : rules.pidPatterns)
            {
                if (matchesWildcard(pidStr, pattern))
                {
                    result.markSingleMatched();
                    break;
                }
            }
        }

        String normalizedName = normalizeName(processName);
        if (!ToolUtilities.isStringEmpty(normalizedName, true))
        {
            if (rules.nameSet.contains(normalizedName))
                result.markSingleMatched();

            for (Pattern pattern : rules.namePatterns)
            {
                if (pattern.matcher(normalizedName).matches())
                {
                    result.markSingleMatched();
                    break;
                }
            }

            for (Pattern pattern : rules.nameAggregatePatterns)
            {
                if (pattern.matcher(normalizedName).matches())
                    result.addAggregateKey("name:" + pattern.pattern());
            }
        }

        String normalizedPath = normalizePath(processPath);
        if (!ToolUtilities.isStringEmpty(normalizedPath, true))
        {
            if (rules.pathSet.contains(normalizedPath))
                result.markSingleMatched();

            for (Pattern pattern : rules.pathPatterns)
            {
                if (pattern.matcher(normalizedPath).matches())
                {
                    result.markSingleMatched();
                    break;
                }
            }

            for (Pattern pattern : rules.pathAggregatePatterns)
            {
                if (pattern.matcher(normalizedPath).matches())
                    result.addAggregateKey("path:" + pattern.pattern());
            }
        }

        return result;
    }

    protected static boolean matchesWildcard(String text, String pattern)
    {
        if (ToolUtilities.isStringEmpty(text) || ToolUtilities.isStringEmpty(pattern))
            return false;
        String regex = wildcardToRegex(pattern);
        return text.matches(regex);
    }

    protected static String wildcardToRegex(String pattern)
    {
        if (ToolUtilities.isStringEmpty(pattern))
            return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < pattern.length(); i++)
        {
            char c = pattern.charAt(i);
            switch (c)
            {
            case '*':
                sb.append(".*");
                break;
            case '?':
                sb.append(".");
                break;
            case '.':
            case '^':
            case '$':
            case '+':
            case '[':
            case ']':
            case '(':
            case ')':
            case '{':
            case '}':
            case '\\':
            case '|':
                sb.append('\\').append(c);
                break;
            default:
                sb.append(c);
                break;
            }
        }
        return sb.toString();
    }

    protected static void parsePidRules(String text, Set<Integer> pidSet, List<String> pidPatterns)
    {
        if (ToolUtilities.isStringEmpty(text, true))
            return;
        String[] arr = text.split("[,;\\r\\n]");
        for (String one : arr)
        {
            String trimmed = one.trim();
            if (ToolUtilities.isStringEmpty(trimmed, true))
                continue;
            if (trimmed.contains("*") || trimmed.contains("?"))
            {
                pidPatterns.add(trimmed.toLowerCase());
            }
            else
            {
                int pid = ToolUtilities.getInteger(trimmed, -1);
                if (pid >= 0)
                    pidSet.add(Integer.valueOf(pid));
            }
        }
    }

    protected static void parseNameRules(String text, Set<String> nameSet, List<Pattern> namePatterns, List<Pattern> nameAggregatePatterns)
    {
        if (ToolUtilities.isStringEmpty(text, true))
            return;
        String[] arr = text.split("[,;\\r\\n]");
        for (String one : arr)
        {
            String trimmed = one.trim();
            if (ToolUtilities.isStringEmpty(trimmed, true))
                continue;

            boolean isAggregate = trimmed.endsWith("+");
            String patternStr = isAggregate ? trimmed.substring(0, trimmed.length() - 1) : trimmed;
            String normalized = normalizeName(patternStr);
            if (ToolUtilities.isStringEmpty(normalized, true))
                continue;

            if (patternStr.contains("*") || patternStr.contains("?"))
            {
                String regex = wildcardToRegex(normalized);
                Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
                if (isAggregate)
                    nameAggregatePatterns.add(pattern);
                else
                    namePatterns.add(pattern);
            }
            else
            {
                if (isAggregate)
                {
                    String regex = wildcardToRegex(normalized);
                    nameAggregatePatterns.add(Pattern.compile(regex, Pattern.CASE_INSENSITIVE));
                }
                else
                {
                    nameSet.add(normalized);
                }
            }
        }
    }

    protected static void parsePathRules(String text, Set<String> pathSet, List<Pattern> pathPatterns, List<Pattern> pathAggregatePatterns)
    {
        if (ToolUtilities.isStringEmpty(text, true))
            return;
        String[] arr = text.split("[,;\\r\\n]");
        for (String one : arr)
        {
            String trimmed = one.trim();
            if (ToolUtilities.isStringEmpty(trimmed, true))
                continue;

            boolean isAggregate = trimmed.endsWith("+");
            String patternStr = isAggregate ? trimmed.substring(0, trimmed.length() - 1) : trimmed;
            String normalized = normalizePath(patternStr);
            if (ToolUtilities.isStringEmpty(normalized, true))
                continue;

            if (patternStr.contains("*") || patternStr.contains("?"))
            {
                String regex = wildcardToRegex(normalized);
                Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
                if (isAggregate)
                    pathAggregatePatterns.add(pattern);
                else
                    pathPatterns.add(pattern);
            }
            else
            {
                if (isAggregate)
                {
                    String regex = wildcardToRegex(normalized);
                    pathAggregatePatterns.add(Pattern.compile(regex, Pattern.CASE_INSENSITIVE));
                }
                else
                {
                    pathSet.add(normalized);
                }
            }
        }
    }

    public static Set<Integer> parsePidSet(String text)
    {
        LinkedHashSet<Integer> set = new LinkedHashSet<Integer>();
        if (ToolUtilities.isStringEmpty(text, true))
            return set;
        String[] arr = text.split("[,;\\r\\n]");
        for (String one : arr)
        {
            int pid = ToolUtilities.getInteger(one, -1);
            if (pid >= 0)
                set.add(Integer.valueOf(pid));
        }
        return set;
    }

    public static Set<String> parseTextSet(String text, boolean pathMode)
    {
        LinkedHashSet<String> set = new LinkedHashSet<String>();
        if (ToolUtilities.isStringEmpty(text, true))
            return set;
        String[] arr = text.split("[,;\\r\\n]");
        for (String one : arr)
        {
            String value = pathMode ? normalizePath(one) : normalizeName(one);
            if (!ToolUtilities.isStringEmpty(value, true))
                set.add(value);
        }
        return set;
    }

    public static String normalizeName(String text)
    {
        String name = ToolUtilities.getString(text, "").trim().toLowerCase();
        if (ToolUtilities.isStringEmpty(name, true))
            return name;
        int idx = name.indexOf('#');
        if (idx > 0)
            name = name.substring(0, idx);
        if (name.endsWith(".exe"))
            name = name.substring(0, name.length() - 4);
        return name;
    }

    public static String normalizePath(String text)
    {
        String path = ToolUtilities.getString(text, "").trim().replace('\\', '/').toLowerCase();
        if (ToolUtilities.isStringEmpty(path, true))
            return path;
        while (path.endsWith("/"))
            path = path.substring(0, path.length() - 1);
        return path;
    }

    public static List<String> toPidStringList(Set<Integer> pidSet)
    {
        ArrayList<String> list = new ArrayList<String>();
        if (pidSet == null)
            return list;
        for (Integer one : pidSet)
            if (one != null)
                list.add(String.valueOf(one.intValue()));
        return list;
    }
}
