package bap.opm.collector.focus;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.opm.system.SystemMetrics;

public class OpmFocusProcessGrouper
{
    public interface IProcessAdapter<T>
    {
        int getPid(T process);

        String getProcessName(T process);

        String getProcessPath(T process);

        long getMemoryBytes(T process);

        double getCpuRate(T process);

        double getReadRateBytesPerSec(T process);

        double getWriteRateBytesPerSec(T process);

        double getIoRateBytesPerSec(T process);

        String getSource(T process);
    }

    public static class ProcessSnapshot
    {
        public Integer pid;
        public String processName;
        public String processPath;
        public Long memoryBytes;
        public Double cpuRate;
        public Double readRateBytesPerSec;
        public Double writeRateBytesPerSec;
        public Double ioRateBytesPerSec;
        public String source;

        public Map<String, Object> toMap()
        {
            LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
            map.put("pid", pid);
            map.put("processName", processName);
            map.put("processPath", processPath);
            map.put("memoryBytes", memoryBytes);
            map.put("cpuRate", cpuRate);
            map.put("readRateBytesPerSec", readRateBytesPerSec);
            map.put("writeRateBytesPerSec", writeRateBytesPerSec);
            map.put("ioRateBytesPerSec", ioRateBytesPerSec);
            map.put("source", source);
            return map;
        }
    }

    public static class ProcessGroup
    {
        public String groupKey;
        public boolean aggregate;
        public String aggregateKey;
        public String groupName;
        public String groupPath;
        public Integer pid;
        public Integer groupCount;
        public Long memoryBytes;
        public Double cpuRate;
        public Double readRateBytesPerSec;
        public Double writeRateBytesPerSec;
        public Double ioRateBytesPerSec;
        public String source;
        public final List<ProcessSnapshot> groupProcesses = new ArrayList<ProcessSnapshot>();

        public Map<String, Object> toMap()
        {
            LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
            map.put("groupKey", groupKey);
            map.put("aggregate", Boolean.valueOf(aggregate));
            map.put("aggregateKey", aggregateKey);
            map.put("groupName", groupName);
            map.put("groupPath", groupPath);
            map.put("processName", groupName);
            map.put("processPath", groupPath);
            map.put("pid", pid);
            map.put("groupCount", groupCount);
            map.put("aggregateCount", aggregate ? groupCount : null);
            map.put("memoryBytes", memoryBytes);
            map.put("cpuRate", cpuRate);
            map.put("readRateBytesPerSec", readRateBytesPerSec);
            map.put("writeRateBytesPerSec", writeRateBytesPerSec);
            map.put("ioRateBytesPerSec", ioRateBytesPerSec);
            map.put("source", source);
            map.put("groupProcesses", toProcessMapList(groupProcesses));
            map.put("aggregateProcesses", aggregate ? toProcessMapList(groupProcesses) : null);
            return map;
        }
    }

    private static final IProcessAdapter<SystemMetrics.ProcessCpuUsage> CPU_ADAPTER = new IProcessAdapter<SystemMetrics.ProcessCpuUsage>()
    {
        @Override
        public int getPid(SystemMetrics.ProcessCpuUsage process)
        {
            return process == null ? -1 : process.pid;
        }

        @Override
        public String getProcessName(SystemMetrics.ProcessCpuUsage process)
        {
            return process == null ? null : process.processName;
        }

        @Override
        public String getProcessPath(SystemMetrics.ProcessCpuUsage process)
        {
            return process == null ? null : process.processPath;
        }

        @Override
        public long getMemoryBytes(SystemMetrics.ProcessCpuUsage process)
        {
            return process == null ? 0L : process.memoryBytes;
        }

        @Override
        public double getCpuRate(SystemMetrics.ProcessCpuUsage process)
        {
            return process == null ? 0D : process.cpuRate;
        }

        @Override
        public double getReadRateBytesPerSec(SystemMetrics.ProcessCpuUsage process)
        {
            return 0D;
        }

        @Override
        public double getWriteRateBytesPerSec(SystemMetrics.ProcessCpuUsage process)
        {
            return 0D;
        }

        @Override
        public double getIoRateBytesPerSec(SystemMetrics.ProcessCpuUsage process)
        {
            return 0D;
        }

        @Override
        public String getSource(SystemMetrics.ProcessCpuUsage process)
        {
            return process == null ? null : process.source;
        }
    };

    private static final IProcessAdapter<SystemMetrics.ProcessMemoryUsage> MEMORY_ADAPTER = new IProcessAdapter<SystemMetrics.ProcessMemoryUsage>()
    {
        @Override
        public int getPid(SystemMetrics.ProcessMemoryUsage process)
        {
            return process == null ? -1 : process.pid;
        }

        @Override
        public String getProcessName(SystemMetrics.ProcessMemoryUsage process)
        {
            return process == null ? null : process.processName;
        }

        @Override
        public String getProcessPath(SystemMetrics.ProcessMemoryUsage process)
        {
            return process == null ? null : process.processPath;
        }

        @Override
        public long getMemoryBytes(SystemMetrics.ProcessMemoryUsage process)
        {
            return process == null ? 0L : process.memoryBytes;
        }

        @Override
        public double getCpuRate(SystemMetrics.ProcessMemoryUsage process)
        {
            return 0D;
        }

        @Override
        public double getReadRateBytesPerSec(SystemMetrics.ProcessMemoryUsage process)
        {
            return 0D;
        }

        @Override
        public double getWriteRateBytesPerSec(SystemMetrics.ProcessMemoryUsage process)
        {
            return 0D;
        }

        @Override
        public double getIoRateBytesPerSec(SystemMetrics.ProcessMemoryUsage process)
        {
            return 0D;
        }

        @Override
        public String getSource(SystemMetrics.ProcessMemoryUsage process)
        {
            return process == null ? null : process.source;
        }
    };

    private static final IProcessAdapter<SystemMetrics.ProcessIoUsage> IO_ADAPTER = new IProcessAdapter<SystemMetrics.ProcessIoUsage>()
    {
        @Override
        public int getPid(SystemMetrics.ProcessIoUsage process)
        {
            return process == null ? -1 : process.pid;
        }

        @Override
        public String getProcessName(SystemMetrics.ProcessIoUsage process)
        {
            return process == null ? null : process.processName;
        }

        @Override
        public String getProcessPath(SystemMetrics.ProcessIoUsage process)
        {
            return process == null ? null : process.processPath;
        }

        @Override
        public long getMemoryBytes(SystemMetrics.ProcessIoUsage process)
        {
            return process == null ? 0L : process.memoryBytes;
        }

        @Override
        public double getCpuRate(SystemMetrics.ProcessIoUsage process)
        {
            return 0D;
        }

        @Override
        public double getReadRateBytesPerSec(SystemMetrics.ProcessIoUsage process)
        {
            return process == null ? 0D : process.readRateBytesPerSec;
        }

        @Override
        public double getWriteRateBytesPerSec(SystemMetrics.ProcessIoUsage process)
        {
            return process == null ? 0D : process.writeRateBytesPerSec;
        }

        @Override
        public double getIoRateBytesPerSec(SystemMetrics.ProcessIoUsage process)
        {
            return process == null ? 0D : process.ioRateBytesPerSec;
        }

        @Override
        public String getSource(SystemMetrics.ProcessIoUsage process)
        {
            return process == null ? null : process.source;
        }
    };

    private OpmFocusProcessGrouper()
    {
    }

    public static List<ProcessGroup> groupCpuProcesses(List<SystemMetrics.ProcessCpuUsage> src, OpmFocusMatcher.RuleSet ruleSet)
    {
        return groupProcesses(src, ruleSet, CPU_ADAPTER);
    }

    public static List<ProcessGroup> groupMemoryProcesses(List<SystemMetrics.ProcessMemoryUsage> src, OpmFocusMatcher.RuleSet ruleSet)
    {
        return groupProcesses(src, ruleSet, MEMORY_ADAPTER);
    }

    public static List<ProcessGroup> groupIoProcesses(List<SystemMetrics.ProcessIoUsage> src, OpmFocusMatcher.RuleSet ruleSet)
    {
        return groupProcesses(src, ruleSet, IO_ADAPTER);
    }

    public static <T> List<ProcessGroup> groupProcesses(List<T> src, OpmFocusMatcher.RuleSet ruleSet, IProcessAdapter<T> adapter)
    {
        ArrayList<ProcessGroup> result = new ArrayList<ProcessGroup>();
        if (src == null || src.isEmpty() || ruleSet == null || ruleSet.isEmpty() || adapter == null)
            return result;

        LinkedHashMap<String, ProcessGroup> groupMap = new LinkedHashMap<String, ProcessGroup>();
        for (T one : src)
        {
            if (one == null)
                continue;

            int pid = adapter.getPid(one);
            String processName = adapter.getProcessName(one);
            String processPath = adapter.getProcessPath(one);
            OpmFocusMatcher.MatchSet matchSet = OpmFocusMatcher.matchAll(ruleSet, pid, processName, processPath);
            if (!matchSet.matched)
                continue;

            ProcessSnapshot snapshot = toSnapshot(one, adapter);
            if (matchSet.singleMatched)
            {
                String singleGroupKey = buildSingleGroupKey(pid, processName, processPath);
                ProcessGroup singleGroup = ensureGroup(groupMap, singleGroupKey, false, null);
                singleGroup.groupProcesses.add(copySnapshot(snapshot));
            }

            for (String aggregateKey : matchSet.aggregateKeys)
            {
                ProcessGroup aggregateGroup = ensureGroup(groupMap, aggregateKey, true, aggregateKey);
                aggregateGroup.groupProcesses.add(copySnapshot(snapshot));
            }
        }

        for (ProcessGroup group : groupMap.values())
        {
            finalizeGroup(group);
            result.add(group);
        }
        return result;
    }

    protected static <T> ProcessSnapshot toSnapshot(T process, IProcessAdapter<T> adapter)
    {
        ProcessSnapshot snapshot = new ProcessSnapshot();
        snapshot.pid = Integer.valueOf(adapter.getPid(process));
        snapshot.processName = adapter.getProcessName(process);
        snapshot.processPath = adapter.getProcessPath(process);
        snapshot.memoryBytes = Long.valueOf(adapter.getMemoryBytes(process));
        snapshot.cpuRate = Double.valueOf(adapter.getCpuRate(process));
        snapshot.readRateBytesPerSec = Double.valueOf(adapter.getReadRateBytesPerSec(process));
        snapshot.writeRateBytesPerSec = Double.valueOf(adapter.getWriteRateBytesPerSec(process));
        snapshot.ioRateBytesPerSec = Double.valueOf(adapter.getIoRateBytesPerSec(process));
        snapshot.source = adapter.getSource(process);
        return snapshot;
    }

    protected static ProcessSnapshot copySnapshot(ProcessSnapshot src)
    {
        if (src == null)
            return null;
        ProcessSnapshot snapshot = new ProcessSnapshot();
        snapshot.pid = src.pid;
        snapshot.processName = src.processName;
        snapshot.processPath = src.processPath;
        snapshot.memoryBytes = src.memoryBytes;
        snapshot.cpuRate = src.cpuRate;
        snapshot.readRateBytesPerSec = src.readRateBytesPerSec;
        snapshot.writeRateBytesPerSec = src.writeRateBytesPerSec;
        snapshot.ioRateBytesPerSec = src.ioRateBytesPerSec;
        snapshot.source = src.source;
        return snapshot;
    }

    protected static ProcessGroup ensureGroup(Map<String, ProcessGroup> groupMap, String groupKey, boolean aggregate, String aggregateKey)
    {
        ProcessGroup group = groupMap.get(groupKey);
        if (group != null)
            return group;
        group = new ProcessGroup();
        group.groupKey = groupKey;
        group.aggregate = aggregate;
        group.aggregateKey = aggregate ? aggregateKey : null;
        groupMap.put(groupKey, group);
        return group;
    }

    protected static void finalizeGroup(ProcessGroup group)
    {
        if (group == null)
            return;

        group.groupCount = Integer.valueOf(group.groupProcesses.size());
        if (group.groupProcesses.isEmpty())
            return;

        if (group.aggregate)
        {
            long totalMemoryBytes = 0L;
            double totalCpuRate = 0D;
            double totalReadRate = 0D;
            double totalWriteRate = 0D;
            double totalIoRate = 0D;
            StringBuilder nameBuilder = new StringBuilder();

            for (int i = 0; i < group.groupProcesses.size(); i++)
            {
                ProcessSnapshot proc = group.groupProcesses.get(i);
                totalMemoryBytes += ToolUtilities.getLong(proc.memoryBytes, 0L);
                totalCpuRate += ToolUtilities.getDouble(proc.cpuRate, 0D);
                totalReadRate += ToolUtilities.getDouble(proc.readRateBytesPerSec, 0D);
                totalWriteRate += ToolUtilities.getDouble(proc.writeRateBytesPerSec, 0D);
                totalIoRate += ToolUtilities.getDouble(proc.ioRateBytesPerSec, 0D);
                if (i > 0)
                    nameBuilder.append(",");
                nameBuilder.append(ToolUtilities.getString(proc.processName, "?"));
                if (ToolUtilities.isStringEmpty(group.source, true))
                    group.source = proc.source;
            }

            int count = group.groupProcesses.size();
            group.groupName = nameBuilder.toString() + "(聚合" + count + "进程)";
            group.groupPath = group.aggregateKey;
            group.pid = Integer.valueOf(-1);
            group.memoryBytes = Long.valueOf(totalMemoryBytes);
            group.cpuRate = Double.valueOf(totalCpuRate);
            group.readRateBytesPerSec = Double.valueOf(totalReadRate);
            group.writeRateBytesPerSec = Double.valueOf(totalWriteRate);
            group.ioRateBytesPerSec = Double.valueOf(totalIoRate);
            return;
        }

        ProcessSnapshot best = group.groupProcesses.get(0);
        long maxMemoryBytes = ToolUtilities.getLong(best.memoryBytes, 0L);
        double maxCpuRate = ToolUtilities.getDouble(best.cpuRate, 0D);
        double maxReadRate = ToolUtilities.getDouble(best.readRateBytesPerSec, 0D);
        double maxWriteRate = ToolUtilities.getDouble(best.writeRateBytesPerSec, 0D);
        double maxIoRate = ToolUtilities.getDouble(best.ioRateBytesPerSec, 0D);

        for (int i = 1; i < group.groupProcesses.size(); i++)
        {
            ProcessSnapshot proc = group.groupProcesses.get(i);
            maxMemoryBytes = Math.max(maxMemoryBytes, ToolUtilities.getLong(proc.memoryBytes, 0L));
            maxCpuRate = Math.max(maxCpuRate, ToolUtilities.getDouble(proc.cpuRate, 0D));
            maxReadRate = Math.max(maxReadRate, ToolUtilities.getDouble(proc.readRateBytesPerSec, 0D));
            maxWriteRate = Math.max(maxWriteRate, ToolUtilities.getDouble(proc.writeRateBytesPerSec, 0D));
            maxIoRate = Math.max(maxIoRate, ToolUtilities.getDouble(proc.ioRateBytesPerSec, 0D));
        }

        group.groupName = best.processName;
        group.groupPath = best.processPath;
        group.pid = best.pid;
        group.memoryBytes = Long.valueOf(maxMemoryBytes);
        group.cpuRate = Double.valueOf(maxCpuRate);
        group.readRateBytesPerSec = Double.valueOf(maxReadRate);
        group.writeRateBytesPerSec = Double.valueOf(maxWriteRate);
        group.ioRateBytesPerSec = Double.valueOf(maxIoRate);
        group.source = best.source;
    }

    protected static String buildSingleGroupKey(int pid, String processName, String processPath)
    {
        if (pid >= 0)
            return "pid:" + pid;
        String path = OpmFocusMatcher.normalizePath(processPath);
        if (!ToolUtilities.isStringEmpty(path, true))
            return "path:" + path;
        String name = OpmFocusMatcher.normalizeName(processName);
        if (!ToolUtilities.isStringEmpty(name, true))
            return "name:" + name;
        return "unknown";
    }

    public static List<Map<String, Object>> toGroupMapList(List<ProcessGroup> groups)
    {
        ArrayList<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        if (groups == null)
            return list;
        for (ProcessGroup one : groups)
        {
            if (one != null)
                list.add(one.toMap());
        }
        return list;
    }

    public static List<Map<String, Object>> toProcessMapList(List<ProcessSnapshot> processes)
    {
        ArrayList<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        if (processes == null)
            return list;
        for (ProcessSnapshot one : processes)
        {
            if (one != null)
                list.add(one.toMap());
        }
        return list;
    }

    public static ProcessGroup findTopCpuGroup(List<ProcessGroup> groups)
    {
        ProcessGroup best = null;
        double bestRate = -1D;
        if (groups == null)
            return null;
        for (ProcessGroup one : groups)
        {
            double rate = ToolUtilities.getDouble(one == null ? null : one.cpuRate, -1D);
            if (rate > bestRate)
            {
                bestRate = rate;
                best = one;
            }
        }
        return best;
    }

    public static ProcessGroup findTopMemoryGroup(List<ProcessGroup> groups)
    {
        ProcessGroup best = null;
        long bestBytes = -1L;
        if (groups == null)
            return null;
        for (ProcessGroup one : groups)
        {
            long bytes = ToolUtilities.getLong(one == null ? null : one.memoryBytes, -1L);
            if (bytes > bestBytes)
            {
                bestBytes = bytes;
                best = one;
            }
        }
        return best;
    }

    public static ProcessGroup findTopIoGroup(List<ProcessGroup> groups)
    {
        ProcessGroup best = null;
        double bestRate = -1D;
        if (groups == null)
            return null;
        for (ProcessGroup one : groups)
        {
            double rate = ToolUtilities.getDouble(one == null ? null : one.ioRateBytesPerSec, -1D);
            if (rate > bestRate)
            {
                bestRate = rate;
                best = one;
            }
        }
        return best;
    }

    @SuppressWarnings("unchecked")
    public static List<Map<String, Object>> parseGroupMapList(String detailJson, String key)
    {
        if (ToolUtilities.isStringEmpty(detailJson, true))
            return null;
        try
        {
            Object obj = normalizeCJsonObject(CJson.fromJson(detailJson));
            if (!(obj instanceof Map))
                return null;
            Object value = ((Map<String, Object>) obj).get(key);
            if (value instanceof List)
                return (List<Map<String, Object>>) value;
        }
        catch (Throwable ignore)
        {
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    protected static Object normalizeCJsonObject(Object obj)
    {
        if (obj == null)
            return null;
        if (obj instanceof Map)
        {
            Map<Object, Object> map = (Map<Object, Object>) obj;
            if (map.containsKey("#O"))
                return normalizeCJsonObject(map.get("#O"));
            if (map.containsKey("#M"))
            {
                Object items = map.get("#M");
                if (items instanceof List)
                {
                    LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
                    for (Object one : (List<Object>) items)
                    {
                        if (!(one instanceof Map))
                            continue;
                        Map<Object, Object> entry = (Map<Object, Object>) one;
                        String k = ToolUtilities.getString(entry.get("$"), null);
                        if (ToolUtilities.isStringEmpty(k, true))
                            continue;
                        ret.put(k, normalizeCJsonObject(entry.get("^")));
                    }
                    return ret;
                }
            }
            if (map.containsKey("#L"))
            {
                Object arr = map.get("#L");
                if (arr instanceof List)
                {
                    ArrayList<Object> ret = new ArrayList<Object>();
                    for (Object one : (List<Object>) arr)
                        ret.add(normalizeCJsonObject(one));
                    return ret;
                }
            }
        }
        return obj;
    }
}
