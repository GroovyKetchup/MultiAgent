package bap.opm;

import bap.md.opm.OpmAlarmExtDo;

public class OpmRuleResult
{
    public boolean triggered;
    public int alarmLevel;
    public String ruleKey;
    public String ruleLabel;
    public String configParamKey;
    public String message;
    public String detailJson;
    public OpmAlarmExtDo alarmExt;
}
