package bap.opm.registry;

import com.leavay.common.util.ToolUtilities;

import bap.opm.collector.disk.OpmDiskConst;
import bap.opm.collector.diskpartition.OpmDiskPartitionConst;
import bap.opm.collector.focus.OpmFocusConst;
import bap.opm.collector.pg.OpmPgConst;
import bap.opm.collector.system.OpmSysConst;
import bap.opm.collector.topcpu.OpmTopCpuConst;
import bap.opm.collector.topio.OpmTopIoConst;
import bap.opm.collector.topmemory.OpmTopMemoryConst;
import bap.opm.collector.topnet.OpmTopNetConst;

/**
 * 统一管理 OPM 告警规则 key、配置元数据 key 与配置项 key 的映射常量。
 */
public class OpmAlarmConfigKeys
{
    private OpmAlarmConfigKeys()
    {
    }

    public static final String RULE_EXPECTATION_PREFIX = "collectExpectation.";

    public static final String META_SYS_CPU = "sys.cpu";
    public static final String META_SYS_MEM = "sys.mem";
    public static final String META_SYS_IO = "sys.io";
    public static final String META_SYS_NET = "sys.net";

    public static final String RULE_SYS_CPU = "cpuUsageThreshold";
    public static final String RULE_SYS_MEM = "memUsageThreshold";
    public static final String RULE_SYS_IO = "ioUsageThreshold";
    public static final String RULE_SYS_NET = "netUsageThreshold";

    public static final String META_TOP_CPU = "topCpu.usage";
    public static final String META_TOP_MEMORY = "topMemory.usage";
    public static final String META_TOP_IO = "topIo.usage";
    public static final String META_TOP_NET = "topNet.usage";

    public static final String RULE_TOP_CPU = "topCpu.usageThreshold";
    public static final String RULE_TOP_MEMORY = "topMemory.usageThreshold";
    public static final String RULE_TOP_IO = "topIo.usageThreshold";
    public static final String RULE_TOP_NET = "topNet.usageThreshold";

    public static final String META_FOCUS_CPU = "focus.cpu";
    public static final String META_FOCUS_MEMORY = "focus.memory";
    public static final String META_FOCUS_IO = "focus.io";

    public static final String RULE_FOCUS_CPU_PATTERN = "focus.cpu.*.*";
    public static final String RULE_FOCUS_MEMORY_PATTERN = "focus.memory.*.*";
    public static final String RULE_FOCUS_IO_PATTERN = "focus.io.*.*";
    public static final String RULE_FOCUS_CPU_AGG_PREFIX = "focus.cpu.aggregate.";
    public static final String RULE_FOCUS_MEMORY_AGG_PREFIX = "focus.memory.aggregate.";
    public static final String RULE_FOCUS_IO_AGG_PREFIX = "focus.io.aggregate.";
    public static final String RULE_FOCUS_CPU_PROC_PREFIX = "focus.cpu.";
    public static final String RULE_FOCUS_MEMORY_PROC_PREFIX = "focus.memory.";
    public static final String RULE_FOCUS_IO_PROC_PREFIX = "focus.io.";

    public static final String META_DISK_USAGE = "disk.usage";
    public static final String RULE_DISK_USAGE = "disk.usageThreshold";

    public static final String META_DISK_PARTITION_USAGE = "diskPartition.usage";
    public static final String RULE_DISK_PARTITION_WARN_PATTERN = "diskPartition.warn.*";
    public static final String RULE_DISK_PARTITION_CRITICAL_PATTERN = "diskPartition.critical.*";
    public static final String RULE_DISK_PARTITION_WARN_PREFIX = "diskPartition.warn.";
    public static final String RULE_DISK_PARTITION_CRITICAL_PREFIX = "diskPartition.critical.";

    public static final String META_PG_SQL = "pg.sql";
    public static final String META_PG_SPACE = "pg.space";
    public static final String META_PG_DEADLOCK = "pg.deadlock";
    public static final String META_PG_LOCK = "pg.lock";
    public static final String META_PG_CONN = "pg.conn";
    public static final String META_PG_REPLICATION = "pg.replication";
    public static final String META_PG_PROC_CPU = "pg.proc.cpu";

    public static final String RULE_PG_SQL = "sql.longDuration";
    public static final String RULE_PG_SPACE = "space.usageRate";
    public static final String RULE_PG_DEADLOCK = "lock.deadlockCount";
    public static final String RULE_PG_LOCK = "lock.longLock";
    public static final String RULE_PG_CONN = "conn.usageRate";
    public static final String RULE_PG_REPLICATION = "replication.lag";
    public static final String RULE_PG_PROC_CPU = "proc.cpu";

    public static String buildExpectationRuleKey(String collectorKey)
    {
        return RULE_EXPECTATION_PREFIX + ToolUtilities.getString(collectorKey, "unknown");
    }

    public static String buildFocusCpuRuleKey(boolean aggregate, String normalizedKey, int pid)
    {
        return aggregate ? RULE_FOCUS_CPU_AGG_PREFIX + normalizedKey : RULE_FOCUS_CPU_PROC_PREFIX + normalizedKey + "." + pid;
    }

    public static String buildFocusMemoryRuleKey(boolean aggregate, String normalizedKey, int pid)
    {
        return aggregate ? RULE_FOCUS_MEMORY_AGG_PREFIX + normalizedKey : RULE_FOCUS_MEMORY_PROC_PREFIX + normalizedKey + "." + pid;
    }

    public static String buildFocusIoRuleKey(boolean aggregate, String normalizedKey, int pid)
    {
        return aggregate ? RULE_FOCUS_IO_AGG_PREFIX + normalizedKey : RULE_FOCUS_IO_PROC_PREFIX + normalizedKey + "." + pid;
    }

    public static String buildDiskPartitionRuleKey(boolean criticalLevel, String mountKey)
    {
        return (criticalLevel ? RULE_DISK_PARTITION_CRITICAL_PREFIX : RULE_DISK_PARTITION_WARN_PREFIX)
                + ToolUtilities.getString(mountKey, "unknown");
    }

    public static String formatConfigSourcePrefix(String key)
    {
        if (ToolUtilities.isStringEmpty(key, true))
            return "配置项";
        if (key.startsWith("opm.focus.cpu."))
            return "重点进程CPU";
        if (key.startsWith("opm.focus.io."))
            return "重点进程IO";
        if (key.startsWith("opm.focus.memory."))
            return "重点进程内存";
        if (key.startsWith("opm.focus.match."))
            return "重点进程特征";
        if (key.startsWith("opm.topCpu."))
            return "TOP进程CPU";
        if (key.startsWith("opm.topMemory."))
            return "TOP进程内存";
        if (key.startsWith("opm.topIo."))
            return "TOP进程IO";
        if (key.startsWith("opm.topNet."))
            return "TOP进程网络";
        if (key.startsWith("opm.sys.cpu."))
            return "系统CPU";
        if (key.startsWith("opm.sys.mem."))
            return "系统内存";
        if (key.startsWith("opm.sys.io."))
            return "系统IO";
        if (key.startsWith("opm.sys.net."))
            return "系统网络";
        if (key.startsWith("opm.diskPartition."))
            return "磁盘分区监控";
        if (key.startsWith("opm.disk."))
            return "磁盘监控";
        if (key.startsWith("opm.pg.sql."))
            return "PG长SQL";
        if (key.startsWith("opm.pg.space."))
            return "PG空间";
        if (key.startsWith("opm.pg.lock."))
            return "PG长时锁";
        if (key.startsWith("opm.pg.deadlock."))
            return "PG死锁";
        if (key.startsWith("opm.pg.conn."))
            return "PG连接";
        if (key.startsWith("opm.pg.replication."))
            return "PG复制";
        return "配置项";
    }

    public static String formatConfigSourceSuffix(String key)
    {
        if (ToolUtilities.isStringEmpty(key, true))
            return "配置";
        if (key.endsWith(".warnRate") || key.endsWith(".warnBytes") || key.endsWith(".warnRateBytesPerSec"))
            return "警告阈值";
        if (key.endsWith(".minorRate") || key.endsWith(".minorBytes") || key.endsWith(".minorRateBytesPerSec"))
            return "次要阈值";
        if (key.endsWith(".majorRate") || key.endsWith(".majorBytes") || key.endsWith(".majorRateBytesPerSec"))
            return "主要阈值";
        if (key.endsWith(".criticalRate") || key.endsWith(".criticalBytes") || key.endsWith(".criticalRateBytesPerSec"))
            return "严重阈值";
        if (key.endsWith(".warnSec") || key.endsWith(".warnDurationSec"))
            return "警告持续时间";
        if (key.endsWith(".minorSec") || key.endsWith(".minorDurationSec"))
            return "次要持续时间";
        if (key.endsWith(".majorSec") || key.endsWith(".majorDurationSec"))
            return "主要持续时间";
        if (key.endsWith(".criticalSec") || key.endsWith(".criticalDurationSec"))
            return "严重持续时间";
        if (key.endsWith(".warnCount"))
            return "警告次数阈值";
        if (key.endsWith(".minorCount"))
            return "次要次数阈值";
        if (key.endsWith(".majorCount"))
            return "主要次数阈值";
        if (key.endsWith(".criticalCount"))
            return "严重次数阈值";
        if (key.endsWith(".collectIntervalSec"))
            return "采集周期配置";
        if (key.endsWith(".sampleMillis"))
            return "采样窗口配置";
        return "配置";
    }
}
