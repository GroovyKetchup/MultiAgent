package bap.opm.registry;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.dfc.gui.LvUtil;

import tiny.service.md.TsAlarm;

/**
 * OPM配置注册表测试工具
 * 
 * <pre>
 * 设计目标：
 * 1. 自动化测试所有告警规则的配置项映射
 * 2. 验证配置项完整性
 * 3. 生成测试报告
 * 4. 可集成到CI/CD流程
 * 
 * 使用方式：
 * 1. 系统启动时自动运行：OpmConfigTestRunner.runTests()
 * 2. 手动测试：访问 /api/opm/config/test 接口
 * 3. CI/CD集成：测试失败则构建失败
 * </pre>
 */
public class OpmConfigTestRunner
{
    /**
     * 运行所有测试
     */
    public static OpmConfigTestResult runTests()
    {
        OpmConfigTestResult result = new OpmConfigTestResult();

        LvUtil.trace("=== 开始OPM配置注册表测试 ===");

        // 1. 验证注册表完整性
        List<String> validateErrors = OpmConfigRegistry.getInstance().validate();
        if (!validateErrors.isEmpty())
        {
            result.addErrors(validateErrors);
            LvUtil.trace("❌ 注册表验证失败:");
            for (String error : validateErrors)
            {
                LvUtil.trace("  " + error);
            }
        }
        else
        {
            LvUtil.trace("✅ 注册表验证通过");
        }

        // 2. 测试所有告警规则的配置项映射
        testAllAlarmRules(result);

        // 3. 测试采集周期预期规则
        testCollectExpectationRules(result);

        // 4. 测试运行时动态规则key样例
        testRuntimeRuleSamples(result);

        // 5. 输出测试结果
        LvUtil.trace("\n=== 测试结果 ===");
        LvUtil.trace("总计: " + result.getTotalCount() + " 个测试");
        LvUtil.trace("成功: " + result.getSuccessCount() + " 个");
        LvUtil.trace("失败: " + result.getFailCount() + " 个");

        if (result.getFailCount() > 0)
        {
            LvUtil.trace("\n❌ 存在失败的测试:");
            for (OpmConfigTestCase testCase : result.getFailedCases())
            {
                LvUtil.trace("  " + testCase.toString());
            }
        }
        else
        {
            LvUtil.trace("\n✅ 所有测试通过！");
        }

        return result;
    }

    /**
     * 测试所有告警规则
     */
    protected static void testAllAlarmRules(OpmConfigTestResult result)
    {
        OpmConfigRegistry registry = OpmConfigRegistry.getInstance();

        for (OpmAlarmRuleMeta ruleMeta : registry._alarmRules.values())
        {
            String ruleKey = ruleMeta.getRuleKey();
            String collectorKey = ruleMeta.getCollectorKey();

            // 测试每个告警级别
            int[] levels = new int[] {
                    TsAlarm.LEVEL_WARN,
                    TsAlarm.LEVEL_ERROR_MINOR,
                    TsAlarm.LEVEL_ERROR_MAJOR,
                    TsAlarm.LEVEL_ERROR_CRITICAL
            };

            for (int level : levels)
            {
                String configParamKey = registry.resolveConfigParamKey(collectorKey, ruleKey, level);

                OpmConfigTestCase testCase = new OpmConfigTestCase();
                testCase.collectorKey = collectorKey;
                testCase.ruleKey = ruleKey;
                testCase.alarmLevel = level;
                testCase.configParamKey = configParamKey;
                testCase.success = configParamKey != null && !configParamKey.isEmpty();

                result.addTestCase(testCase);
            }
        }
    }

    /**
     * 测试采集周期预期规则
     */
    protected static void testCollectExpectationRules(OpmConfigTestResult result)
    {
        OpmConfigRegistry registry = OpmConfigRegistry.getInstance();

        // 获取所有采集器
        for (String collectorKey : registry._collectorRules.keySet())
        {
            String ruleKey = "collectExpectation." + collectorKey;
            String configParamKey = registry.resolveConfigParamKey(collectorKey, ruleKey, null);

            OpmConfigTestCase testCase = new OpmConfigTestCase();
            testCase.collectorKey = collectorKey;
            testCase.ruleKey = ruleKey;
            testCase.alarmLevel = -1;
            testCase.configParamKey = configParamKey;
            testCase.success = configParamKey != null && !configParamKey.isEmpty();
            testCase.description = "采集周期预期规则";

            result.addTestCase(testCase);
        }
    }

    /**
     * 测试运行时真实产生的动态规则key，避免注册表声明与运行时命名脱节。
     */
    protected static void testRuntimeRuleSamples(OpmConfigTestResult result)
    {
        OpmConfigRegistry registry = OpmConfigRegistry.getInstance();

        addRuntimeRuleSample(result, registry,
                "diskPartition",
                "diskPartition.warn.root",
                TsAlarm.LEVEL_WARN,
                "磁盘分区警告动态规则样例");

        addRuntimeRuleSample(result, registry,
                "diskPartition",
                "diskPartition.critical.root",
                TsAlarm.LEVEL_ERROR_CRITICAL,
                "磁盘分区严重动态规则样例");
    }

    protected static void addRuntimeRuleSample(OpmConfigTestResult result,
            OpmConfigRegistry registry,
            String collectorKey,
            String ruleKey,
            int alarmLevel,
            String description)
    {
        String configParamKey = registry.resolveConfigParamKey(collectorKey, ruleKey, alarmLevel);

        OpmConfigTestCase testCase = new OpmConfigTestCase();
        testCase.collectorKey = collectorKey;
        testCase.ruleKey = ruleKey;
        testCase.alarmLevel = alarmLevel;
        testCase.configParamKey = configParamKey;
        testCase.success = configParamKey != null && !configParamKey.isEmpty();
        testCase.description = description;
        result.addTestCase(testCase);
    }

    /**
     * 测试用例
     */
    public static class OpmConfigTestCase
    {
        public String collectorKey;
        public String ruleKey;
        public int alarmLevel;
        public String configParamKey;
        public boolean success;
        public String description;

        @Override
        public String toString()
        {
            String levelName = getLevelName(alarmLevel);
            String status = success ? "✅" : "❌";
            return status + " " + collectorKey + " / " + ruleKey + " [" + levelName + "] -> " + configParamKey;
        }

        protected String getLevelName(int level)
        {
            if (level == TsAlarm.LEVEL_WARN)
                return "警告";
            if (level == TsAlarm.LEVEL_ERROR_MINOR)
                return "次要";
            if (level == TsAlarm.LEVEL_ERROR_MAJOR)
                return "主要";
            if (level == TsAlarm.LEVEL_ERROR_CRITICAL)
                return "严重";
            return "未知";
        }
    }

    /**
     * 测试结果
     */
    public static class OpmConfigTestResult
    {
        protected List<OpmConfigTestCase> testCases = new ArrayList<OpmConfigTestCase>();
        protected List<String> errors = new ArrayList<String>();

        public void addTestCase(OpmConfigTestCase testCase)
        {
            testCases.add(testCase);
        }

        public void addError(String error)
        {
            errors.add(error);
        }

        public void addErrors(List<String> errorList)
        {
            errors.addAll(errorList);
        }

        public int getTotalCount()
        {
            return testCases.size();
        }

        public int getSuccessCount()
        {
            int count = 0;
            for (OpmConfigTestCase testCase : testCases)
            {
                if (testCase.success)
                    count++;
            }
            return count;
        }

        public int getFailCount()
        {
            int count = 0;
            for (OpmConfigTestCase testCase : testCases)
            {
                if (!testCase.success)
                    count++;
            }
            return count;
        }

        public List<OpmConfigTestCase> getFailedCases()
        {
            List<OpmConfigTestCase> failed = new ArrayList<OpmConfigTestCase>();
            for (OpmConfigTestCase testCase : testCases)
            {
                if (!testCase.success)
                    failed.add(testCase);
            }
            return failed;
        }

        public List<String> getErrors()
        {
            return errors;
        }

        public boolean isAllPassed()
        {
            return errors.isEmpty() && getFailCount() == 0;
        }

        public Map<String, Object> toMap()
        {
            Map<String, Object> map = new LinkedHashMap<String, Object>();
            map.put("totalCount", getTotalCount());
            map.put("successCount", getSuccessCount());
            map.put("failCount", getFailCount());
            map.put("errors", errors);
            map.put("allPassed", isAllPassed());

            List<Map<String, Object>> failedCases = new ArrayList<Map<String, Object>>();
            for (OpmConfigTestCase testCase : getFailedCases())
            {
                Map<String, Object> caseMap = new LinkedHashMap<String, Object>();
                caseMap.put("collectorKey", testCase.collectorKey);
                caseMap.put("ruleKey", testCase.ruleKey);
                caseMap.put("alarmLevel", testCase.alarmLevel);
                caseMap.put("configParamKey", testCase.configParamKey);
                caseMap.put("description", testCase.description);
                failedCases.add(caseMap);
            }
            map.put("failedCases", failedCases);

            return map;
        }
    }
}
