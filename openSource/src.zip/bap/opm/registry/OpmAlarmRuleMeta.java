package bap.opm.registry;

import java.util.regex.Pattern;

/**
 * OPM告警规则元数据
 * 
 * <pre>
 * 设计目标：
 * 1. 统一管理所有告警规则的元数据
 * 2. 支持ruleKey模式匹配（如 focus.cpu.*.pid）
 * 3. 自动关联配置项
 * 4. 支持规则验证
 * </pre>
 */
public class OpmAlarmRuleMeta
{
    protected String _ruleKey;
    protected String _ruleKeyPattern;
    protected Pattern _compiledPattern;
    protected String _ruleLabel;
    protected String _collectorKey;
    protected String _configParamKey;
    protected String _configParamMetaKey;
    protected String _description;

    public OpmAlarmRuleMeta(String ruleKey, String ruleLabel)
    {
        _ruleKey = ruleKey;
        _ruleLabel = ruleLabel;
        
        if (ruleKey != null && ruleKey.contains("*"))
        {
            _ruleKeyPattern = ruleKey.replace(".", "\\.").replace("*", ".*");
            _compiledPattern = Pattern.compile("^" + _ruleKeyPattern + "$");
        }
    }

    public OpmAlarmRuleMeta setCollector(String collectorKey)
    {
        _collectorKey = collectorKey;
        return this;
    }

    /**
     * 设置关联的配置项key（固定配置项）
     */
    public OpmAlarmRuleMeta setConfigParam(String configParamKey)
    {
        _configParamKey = configParamKey;
        return this;
    }

    /**
     * 设置关联的配置项元数据key（用于多级告警）
     */
    public OpmAlarmRuleMeta setConfigParamMeta(String metaKey)
    {
        _configParamMetaKey = metaKey;
        return this;
    }

    public OpmAlarmRuleMeta setDesc(String desc)
    {
        _description = desc;
        return this;
    }

    public String getRuleKey()
    {
        return _ruleKey;
    }

    public String getRuleKeyPattern()
    {
        return _ruleKeyPattern;
    }

    public String getRuleLabel()
    {
        return _ruleLabel;
    }

    public String getCollectorKey()
    {
        return _collectorKey;
    }

    public String getConfigParamKey()
    {
        return _configParamKey;
    }

    public String getConfigParamMetaKey()
    {
        return _configParamMetaKey;
    }

    public String getDescription()
    {
        return _description;
    }

    /**
     * 判断ruleKey是否匹配
     */
    public boolean matches(String ruleKey)
    {
        if (_ruleKey == null || ruleKey == null)
            return false;
        
        if (_compiledPattern != null)
            return _compiledPattern.matcher(ruleKey).matches();
        
        return _ruleKey.equals(ruleKey);
    }

    /**
     * 是否是模式匹配规则
     */
    public boolean isPattern()
    {
        return _compiledPattern != null;
    }

    @Override
    public String toString()
    {
        return "OpmAlarmRuleMeta[ruleKey=" + _ruleKey + ", collector=" + _collectorKey + "]";
    }
}