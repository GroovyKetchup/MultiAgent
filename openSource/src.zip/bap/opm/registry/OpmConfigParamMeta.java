package bap.opm.registry;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * OPM配置项元数据
 * 
 * <pre>
 * 设计目标：
 * 1. 统一管理所有配置项的元数据
 * 2. 支持多级告警配置（warn/minor/major/critical）
 * 3. 自动生成配置项映射关系
 * 4. 支持配置项验证
 * </pre>
 */
public class OpmConfigParamMeta
{
    protected String _key;
    protected String _label;
    protected String _type;
    protected String _defaultValue;
    protected String _description;
    protected String _collectorKey;
    protected String _category;
    protected Map<Integer, String> _levelParamKeys;

    public OpmConfigParamMeta(String key, String label, String type, String defaultValue)
    {
        _key = key;
        _label = label;
        _type = type;
        _defaultValue = defaultValue;
        _levelParamKeys = new LinkedHashMap<Integer, String>();
    }

    public OpmConfigParamMeta setDesc(String desc)
    {
        _description = desc;
        return this;
    }

    public OpmConfigParamMeta setCollector(String collectorKey)
    {
        _collectorKey = collectorKey;
        return this;
    }

    public OpmConfigParamMeta setCategory(String category)
    {
        _category = category;
        return this;
    }

    /**
     * 设置多级告警配置项
     * 
     * @param warnKey 警告级别配置项
     * @param minorKey 次要级别配置项
     * @param majorKey 主要级别配置项
     * @param criticalKey 严重级别配置项
     * @return this
     */
    public OpmConfigParamMeta setLevelParams(String warnKey, String minorKey, String majorKey, String criticalKey)
    {
        _levelParamKeys.put(tiny.service.md.TsAlarm.LEVEL_WARN, warnKey);
        _levelParamKeys.put(tiny.service.md.TsAlarm.LEVEL_ERROR_MINOR, minorKey);
        _levelParamKeys.put(tiny.service.md.TsAlarm.LEVEL_ERROR_MAJOR, majorKey);
        _levelParamKeys.put(tiny.service.md.TsAlarm.LEVEL_ERROR_CRITICAL, criticalKey);
        return this;
    }

    /**
     * 设置单级配置项（用于采集周期等非告警配置）
     */
    public OpmConfigParamMeta setSingleParam(String key)
    {
        _levelParamKeys.put(-1, key);
        return this;
    }

    public String getKey()
    {
        return _key;
    }

    public String getLabel()
    {
        return _label;
    }

    public String getType()
    {
        return _type;
    }

    public String getDefaultValue()
    {
        return _defaultValue;
    }

    public String getDescription()
    {
        return _description;
    }

    public String getCollectorKey()
    {
        return _collectorKey;
    }

    public String getCategory()
    {
        return _category;
    }

    /**
     * 根据告警级别获取配置项key
     */
    public String getConfigParamKey(Integer alarmLevel)
    {
        if (_levelParamKeys.isEmpty())
            return _key;
        
        if (alarmLevel == null || !_levelParamKeys.containsKey(alarmLevel))
            return _levelParamKeys.get(tiny.service.md.TsAlarm.LEVEL_WARN);
        
        return _levelParamKeys.get(alarmLevel);
    }

    /**
     * 是否是多级告警配置
     */
    public boolean isMultiLevel()
    {
        return _levelParamKeys.size() > 1;
    }

    @Override
    public String toString()
    {
        return "OpmConfigParamMeta[key=" + _key + ", label=" + _label + ", collector=" + _collectorKey + "]";
    }
}