package bap.opm.registry;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.LvUtil;

/**
 * OPM配置注册表
 * 
 * <pre>
 * 设计目标：
 * 1. 集中管理所有配置项和告警规则
 * 2. 自动建立映射关系
 * 3. 支持配置项验证
 * 4. 支持自动化测试
 * 
 * 核心优势：
 * 1. 新增采集器只需实现registerConfigParams方法
 * 2. 配置项和规则的映射关系自动建立
 * 3. 启动时自动验证完整性
 * 4. 避免遗漏配置项映射
 * </pre>
 */
public class OpmConfigRegistry
{
    protected static volatile OpmConfigRegistry _instance = null;

    protected Map<String, OpmConfigParamMeta> _configParams = new LinkedHashMap<String, OpmConfigParamMeta>();
    protected Map<String, OpmAlarmRuleMeta> _alarmRules = new LinkedHashMap<String, OpmAlarmRuleMeta>();
    protected Map<String, List<OpmAlarmRuleMeta>> _collectorRules = new LinkedHashMap<String, List<OpmAlarmRuleMeta>>();

    protected volatile boolean _initialized = false;

    private OpmConfigRegistry()
    {
    }

    public static OpmConfigRegistry getInstance()
    {
        if (_instance == null)
        {
            synchronized (OpmConfigRegistry.class)
            {
                if (_instance == null)
                    _instance = new OpmConfigRegistry();
            }
        }
        return _instance;
    }

    /**
     * 注册配置项
     */
    public synchronized void registerConfigParam(OpmConfigParamMeta meta)
    {
        if (meta == null || ToolUtilities.isStringEmpty(meta.getKey(), true))
            return;

        _configParams.put(meta.getKey(), meta);
    }

    /**
     * 注册告警规则
     */
    public synchronized void registerAlarmRule(OpmAlarmRuleMeta meta)
    {
        if (meta == null || ToolUtilities.isStringEmpty(meta.getRuleKey(), true))
            return;

        _alarmRules.put(meta.getRuleKey(), meta);

        String collectorKey = meta.getCollectorKey();
        if (!ToolUtilities.isStringEmpty(collectorKey, true))
        {
            List<OpmAlarmRuleMeta> rules = _collectorRules.get(collectorKey);
            if (rules == null)
            {
                rules = new ArrayList<OpmAlarmRuleMeta>();
                _collectorRules.put(collectorKey, rules);
            }
            rules.add(meta);
        }
    }

    /**
     * 根据告警信息获取配置项key
     * 
     * @param collectorKey 采集器key
     * @param ruleKey 规则key
     * @param alarmLevel 告警级别
     * @return 配置项key，如果找不到返回null
     */
    public String resolveConfigParamKey(String collectorKey, String ruleKey, Integer alarmLevel)
    {
        if (ToolUtilities.isStringEmpty(ruleKey, true))
            return null;

        // 1. 先精确匹配
        OpmAlarmRuleMeta ruleMeta = _alarmRules.get(ruleKey);
        if (ruleMeta != null)
        {
            return resolveConfigParamKeyFromRule(ruleMeta, alarmLevel);
        }

        // 2. 模式匹配
        for (OpmAlarmRuleMeta meta : _alarmRules.values())
        {
            if (meta.isPattern() && meta.matches(ruleKey))
            {
                return resolveConfigParamKeyFromRule(meta, alarmLevel);
            }
        }

        // 3. 根据collectorKey查找
        if (!ToolUtilities.isStringEmpty(collectorKey, true))
        {
            List<OpmAlarmRuleMeta> rules = _collectorRules.get(collectorKey);
            if (rules != null)
            {
                for (OpmAlarmRuleMeta meta : rules)
                {
                    if (meta.matches(ruleKey))
                    {
                        return resolveConfigParamKeyFromRule(meta, alarmLevel);
                    }
                }
            }
        }

        return null;
    }

    public String normalizeConfigParamKey(String collectorKey, String ruleKey, Integer alarmLevel, String configParamKey)
    {
        String resolved = resolveConfigParamKey(collectorKey, ruleKey, alarmLevel);
        if (!ToolUtilities.isStringEmpty(resolved, true))
            return resolved;

        String key = ToolUtilities.getString(configParamKey, null);
        if (ToolUtilities.isStringEmpty(key, true))
            return null;

        key = key.trim();
        if (key.startsWith("opm.pg.lock.deadlock."))
            return "opm.pg.deadlock." + key.substring("opm.pg.lock.deadlock.".length());

        return key;
    }

    protected String resolveConfigParamKeyFromRule(OpmAlarmRuleMeta ruleMeta, Integer alarmLevel)
    {
        // 1. 如果规则直接指定了配置项key
        String configParamKey = ruleMeta.getConfigParamKey();
        if (!ToolUtilities.isStringEmpty(configParamKey, true))
            return configParamKey;

        // 2. 如果规则指定了配置项元数据key
        String metaKey = ruleMeta.getConfigParamMetaKey();
        if (!ToolUtilities.isStringEmpty(metaKey, true))
        {
            OpmConfigParamMeta paramMeta = _configParams.get(metaKey);
            if (paramMeta != null)
                return paramMeta.getConfigParamKey(alarmLevel);
        }

        return null;
    }
    /**
     * 获取配置项元数据
     */
    public OpmConfigParamMeta getConfigParamMeta(String key)
    {
        return _configParams.get(key);
    }

    /**
     * 获取告警规则元数据
     */
    public OpmAlarmRuleMeta getAlarmRuleMeta(String ruleKey)
    {
        return _alarmRules.get(ruleKey);
    }

    /**
     * 获取采集器的所有规则
     */
    public List<OpmAlarmRuleMeta> getCollectorRules(String collectorKey)
    {
        List<OpmAlarmRuleMeta> rules = _collectorRules.get(collectorKey);
        return rules == null ? new ArrayList<OpmAlarmRuleMeta>() : rules;
    }

    /**
     * 验证配置完整性
     * 
     * @return 验证结果列表，空列表表示验证通过
     */
    public List<String> validate()
    {
        List<String> errors = new ArrayList<String>();

        // 1. 验证所有规则都有配置项映射
        for (OpmAlarmRuleMeta rule : _alarmRules.values())
        {
            if (ToolUtilities.isStringEmpty(rule.getConfigParamKey(), true)
                    && ToolUtilities.isStringEmpty(rule.getConfigParamMetaKey(), true))
            {
                errors.add("规则[" + rule.getRuleKey() + "]缺少配置项映射");
            }
        }

        // 2. 验证所有配置项元数据都有效
        for (OpmConfigParamMeta param : _configParams.values())
        {
            if (ToolUtilities.isStringEmpty(param.getKey(), true))
            {
                errors.add("配置项元数据key为空");
            }
        }

        return errors;
    }

    /**
     * 打印注册表信息（用于调试）
     */
    public void printRegistryInfo()
    {
        LvUtil.trace("=== OPM配置注册表信息 ===");
        LvUtil.trace("配置项数量: " + _configParams.size());
        LvUtil.trace("告警规则数量: " + _alarmRules.size());
        LvUtil.trace("采集器数量: " + _collectorRules.size());

        LvUtil.trace("\n=== 配置项列表 ===");
        for (OpmConfigParamMeta param : _configParams.values())
        {
            LvUtil.trace("  " + param.getKey() + " -> " + param.getLabel());
        }

        LvUtil.trace("\n=== 告警规则列表 ===");
        for (OpmAlarmRuleMeta rule : _alarmRules.values())
        {
            LvUtil.trace("  " + rule.getRuleKey() + " -> " + rule.getConfigParamKey() + " / " + rule.getConfigParamMetaKey());
        }
    }

    /**
     * 清空注册表（用于测试）
     */
    public synchronized void clear()
    {
        _configParams.clear();
        _alarmRules.clear();
        _collectorRules.clear();
        _initialized = false;
    }

    public boolean isInitialized()
    {
        return _initialized;
    }

    public void setInitialized(boolean initialized)
    {
        _initialized = initialized;
    }
}
