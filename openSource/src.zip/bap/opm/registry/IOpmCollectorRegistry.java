package bap.opm.registry;

import java.util.List;

/**
 * OPM采集器注册接口
 * 
 * <pre>
 * 设计目标：
 * 1. 所有采集器实现此接口
 * 2. 采集器负责注册自己的配置项和告警规则
 * 3. 系统启动时自动调用注册方法
 * 4. 保证配置项和规则的完整性
 * 
 * 使用方式：
 * public class COpmTopCpuCollector implements IOpmCollector, IOpmCollectorRegistry
 * {
 *     public void registerConfigParams(OpmConfigRegistry registry)
 *     {
 *         // 注册配置项
 *         registry.registerConfigParam(new OpmConfigParamMeta(...)
 *             .setLevelParams(warn, minor, major, critical));
 *         
 *         // 注册告警规则
 *         registry.registerAlarmRule(new OpmAlarmRuleMeta(...)
 *             .setConfigParamMeta("cpu.usage"));
 *     }
 * }
 * </pre>
 */
public interface IOpmCollectorRegistry
{
    /**
     * 注册配置项和告警规则
     * 
     * @param registry 配置注册表
     */
    void registerConfigParams(OpmConfigRegistry registry);
}