# OPM配置注册表设计文档

## 一、设计目标

### 1.1 问题分析

当前OPM告警配置项映射存在以下问题：

| 问题 | 影响 | 根本原因 |
|------|------|---------|
| 配置项分散 | 难以维护 | 配置项常量分散在各个Const类 |
| 映射逻辑分散 | 容易遗漏 | 映射逻辑分散在OpmCenter的多个方法 |
| 手动维护 | 容易出错 | 新增采集器需要修改多个地方 |
| 缺乏验证 | 后知后觉 | 没有自动化测试，依赖人工发现 |

### 1.2 设计目标

1. **集中管理**：所有配置项和规则集中定义
2. **自动映射**：映射关系自动建立，无需手动维护
3. **自动验证**：启动时自动验证完整性
4. **易于扩展**：新增采集器只需实现注册接口

## 二、核心设计

### 2.1 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                    OpmConfigRegistry                         │
│                    (配置注册表)                               │
│                                                              │
│  ┌──────────────────┐        ┌──────────────────┐          │
│  │  ConfigParamMeta │        │  AlarmRuleMeta   │          │
│  │  (配置项元数据)   │        │  (告警规则元数据) │          │
│  └──────────────────┘        └──────────────────┘          │
│                                                              │
│  - registerConfigParam()                                     │
│  - registerAlarmRule()                                       │
│  - resolveConfigParamKey()                                   │
│  - validate()                                                │
└─────────────────────────────────────────────────────────────┘
                           ▲
                           │ 注册
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
┌───────┴──────┐   ┌───────┴──────┐   ┌───────┴──────┐
│ CpuCollector │   │MemCollector  │   │PgCollector   │
│ Registry     │   │Registry      │   │Registry      │
└──────────────┘   └──────────────┘   └──────────────┘
```

### 2.2 核心类设计

#### 2.2.1 OpmConfigParamMeta（配置项元数据）

```java
public class OpmConfigParamMeta
{
    protected String _key;              // 配置项key
    protected String _label;            // 配置项标签
    protected String _type;             // 配置项类型
    protected String _defaultValue;     // 默认值
    protected String _description;      // 描述
    protected String _collectorKey;     // 所属采集器
    protected String _category;         // 分类
    protected Map<Integer, String> _levelParamKeys; // 多级告警配置
    
    // 支持多级告警配置
    public OpmConfigParamMeta setLevelParams(
        String warnKey, 
        String minorKey, 
        String majorKey, 
        String criticalKey);
    
    // 根据告警级别获取配置项key
    public String getConfigParamKey(Integer alarmLevel);
}
```

#### 2.2.2 OpmAlarmRuleMeta（告警规则元数据）

```java
public class OpmAlarmRuleMeta
{
    protected String _ruleKey;          // 规则key（支持通配符）
    protected String _ruleKeyPattern;   // 规则模式
    protected String _ruleLabel;        // 规则标签
    protected String _collectorKey;     // 所属采集器
    protected String _configParamKey;   // 关联的配置项key
    protected String _configParamMetaKey; // 关联的配置项元数据key
    
    // 判断ruleKey是否匹配
    public boolean matches(String ruleKey);
}
```

#### 2.2.3 IOpmCollectorRegistry（采集器注册接口）

```java
public interface IOpmCollectorRegistry
{
    /**
     * 注册配置项和告警规则
     */
    void registerConfigParams(OpmConfigRegistry registry);
}
```

#### 2.2.4 OpmConfigRegistry（配置注册表）

```java
public class OpmConfigRegistry
{
    protected Map<String, OpmConfigParamMeta> _configParams;
    protected Map<String, OpmAlarmRuleMeta> _alarmRules;
    protected Map<String, List<OpmAlarmRuleMeta>> _collectorRules;
    
    // 注册配置项
    public void registerConfigParam(OpmConfigParamMeta meta);
    
    // 注册告警规则
    public void registerAlarmRule(OpmAlarmRuleMeta meta);
    
    // 根据告警信息获取配置项key
    public String resolveConfigParamKey(
        String collectorKey, 
        String ruleKey, 
        Integer alarmLevel);
    
    // 验证配置完整性
    public List<String> validate();
}
```

## 三、使用示例

### 3.1 采集器注册实现

```java
public class OpmTopCpuCollectorRegistry implements IOpmCollectorRegistry
{
    public void registerConfigParams(OpmConfigRegistry registry)
    {
        // 1. 注册配置项
        registry.registerConfigParam(
            new OpmConfigParamMeta("cpu.usage", "CPU使用率阈值", "string", "0.8")
                .setDesc("CPU使用率告警阈值")
                .setCollector("topCpu")
                .setCategory("alarm")
                .setLevelParams(
                    "opm.topCpu.warnRate",
                    "opm.topCpu.minorRate",
                    "opm.topCpu.majorRate",
                    "opm.topCpu.criticalRate"));
        
        // 2. 注册告警规则
        registry.registerAlarmRule(
            new OpmAlarmRuleMeta("cpu.usageThreshold", "CPU使用率过高")
                .setCollector("topCpu")
                .setConfigParamMeta("cpu.usage"));
        
        // 3. 注册模式匹配规则
        registry.registerAlarmRule(
            new OpmAlarmRuleMeta("focus.cpu.*.*", "重点进程CPU持续过高")
                .setCollector("topCpu")
                .setConfigParamMeta("focus.cpu"));
    }
}
```

### 3.2 系统初始化

```java
public class OpmCenter
{
    protected void initConfigRegistry()
    {
        OpmConfigRegistry registry = OpmConfigRegistry.getInstance();
        
        // 注册所有采集器
        new OpmTopCpuCollectorRegistry().registerConfigParams(registry);
        new OpmTopMemoryCollectorRegistry().registerConfigParams(registry);
        new OpmFocusCollectorRegistry().registerConfigParams(registry);
        new OpmPgCollectorRegistry().registerConfigParams(registry);
        // ... 其他采集器
        
        // 验证配置完整性
        List<String> errors = registry.validate();
        if (!errors.isEmpty())
        {
            LvUtil.error("OPM配置注册表验证失败:");
            for (String error : errors)
                LvUtil.error("  " + error);
        }
        
        // 运行自动化测试
        OpmConfigTestRunner.runTests();
    }
}
```

### 3.3 配置项映射查询

```java
public class OpmCenter
{
    protected String resolveAlarmConfigParamKey(
        OpmCollectResult collect, 
        OpmRuleResult rule)
    {
        // 直接使用注册表查询
        return OpmConfigRegistry.getInstance().resolveConfigParamKey(
            collect.collectorKey,
            rule.ruleKey,
            rule.alarmLevel);
    }
}
```

## 四、自动化测试

### 4.1 测试覆盖范围

| 测试项 | 测试内容 | 自动化 |
|--------|---------|--------|
| 配置项完整性 | 所有配置项都有元数据 | ✅ |
| 规则完整性 | 所有规则都有配置项映射 | ✅ |
| 映射正确性 | 配置项映射关系正确 | ✅ |
| 多级告警 | 每个级别都能正确映射 | ✅ |
| 模式匹配 | 通配符规则能正确匹配 | ✅ |

### 4.2 测试执行

```java
// 系统启动时自动运行
OpmConfigTestResult result = OpmConfigTestRunner.runTests();

if (!result.isAllPassed())
{
    // 测试失败，记录日志
    LvUtil.error("OPM配置测试失败:");
    for (OpmConfigTestCase failed : result.getFailedCases())
        LvUtil.error("  " + failed.toString());
}
```

### 4.3 测试报告

```json
{
  "totalCount": 68,
  "successCount": 68,
  "failCount": 0,
  "errors": [],
  "allPassed": true,
  "failedCases": []
}
```

## 五、迁移方案

### 5.1 迁移步骤

1. **创建注册类**：为每个采集器创建Registry类
2. **迁移配置项**：将配置项常量迁移到Registry类
3. **实现注册接口**：实现registerConfigParams方法
4. **修改OpmCenter**：使用注册表查询配置项
5. **删除旧代码**：删除resolveAlarmConfigParamKey中的if分支
6. **运行测试**：验证所有功能正常

### 5.2 兼容性保证

- 保留旧的配置项常量，标记为@Deprecated
- 逐步迁移，不影响现有功能
- 新增采集器必须使用注册表模式

## 六、优势总结

### 6.1 设计优势

| 优势 | 说明 |
|------|------|
| **集中管理** | 所有配置项和规则集中定义，易于维护 |
| **自动映射** | 映射关系自动建立，无需手动维护 |
| **自动验证** | 启动时自动验证，及时发现问题 |
| **易于扩展** | 新增采集器只需实现注册接口 |
| **编译检查** | 编译期就能发现大部分错误 |
| **自动化测试** | 完整的测试覆盖，保证质量 |

### 6.2 问题解决

| 问题 | 解决方案 | 效果 |
|------|---------|------|
| 配置项分散 | 集中到Registry类 | ✅ 解决 |
| 映射逻辑分散 | 统一到注册表 | ✅ 解决 |
| 手动维护 | 自动建立映射 | ✅ 解决 |
| 缺乏验证 | 自动化测试 | ✅ 解决 |
| 容易遗漏 | 编译期检查 | ✅ 解决 |

## 七、最佳实践

### 7.1 新增采集器

1. 创建Registry类实现IOpmCollectorRegistry
2. 定义配置项常量
3. 实现registerConfigParams方法
4. 在OpmCenter初始化时注册
5. 运行测试验证

### 7.2 新增告警规则

1. 在Registry类中添加配置项元数据
2. 在Registry类中添加告警规则元数据
3. 运行测试验证

### 7.3 修改配置项

1. 修改Registry类中的配置项元数据
2. 运行测试验证
3. 无需修改映射逻辑

## 八、总结

通过注册表模式，我们实现了：

1. **配置项和规则的集中管理**
2. **映射关系的自动建立**
3. **完整性的自动验证**
4. **问题的及时发现**

这个设计彻底解决了配置项映射遗漏的问题，让系统更加健壮和易于维护。