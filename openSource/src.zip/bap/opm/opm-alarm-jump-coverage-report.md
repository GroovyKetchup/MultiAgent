# OPM 告警跳配置覆盖报告

## 1. 背景

本轮围绕 OPM 的“告警 -> 跳转配置项”链路做了系统性治理，目标包括：

1. 所有会产生告警的采集器，其 `ruleKey`、`configParamKey`、配置元数据 key 统一规范
2. 动态拼接 key 的逻辑集中管理，禁止多处散落硬编码字符串
3. 主控与代理在真实页面上点击“跳转配置项”时，必须能定位到真实存在的配置项
4. 覆盖 Windows 与 Linux 两类在线代理

## 2. 本轮核心改造

### 2.1 统一 key 常量与解析入口

- 新增统一常量工具：`bap/opm/registry/OpmAlarmConfigKeys.java`
- 统一集中管理：
  - 规则 key
  - 配置元数据 key
  - expectation 规则 key
  - focus / diskPartition 动态 rule key 拼装

### 2.2 统一后端映射与归一化

- `bap/opm/registry/OpmConfigRegistry.java`
  - 新增 `normalizeConfigParamKey(...)`
- `bap/opm/OpmCenter.java`
  - 告警入库前统一走归一化
- `bap/opm/web/OpmWebServlet.java`
  - 告警列表与详情统一返回归一化后的 `configParamKey`

### 2.3 修复的关键问题

- PG deadlock 错误映射：
  - 旧：`opm.pg.lock.deadlock.warnCount`
  - 新：`opm.pg.deadlock.warnCount`
- TOP 监控 expectation / 阈值跳转修复：
  - `topCpu`
  - `topMemory`
  - `topIo`
  - `topNet`
- `focus` 聚合/单进程告警修复：
  - 直接按 `alarmLevel` 回填 `configParamKey`
  - 避免模式匹配默认回落到 warn 级别

## 3. 覆盖环境

### 3.1 代理范围

- Windows 主控：`ws://192.168.0.60:2020`
- Windows 在线代理：`ws://192.168.0.60:8001`
- Linux 在线代理：`ws://192.168.145.57:8801`

### 3.2 覆盖策略

- 能真采的优先走真采
- 通过临时压低阈值触发真实告警
- 对无法自然命中的项，通过主控已有测试/仿真入口辅助验证
- 最终统一使用真实浏览器页面做点击验证

## 4. 已验证通过的告警链路

### 4.1 Windows 主控 `ws://192.168.0.60:2020`

- `lock.deadlockCount -> opm.pg.deadlock.warnCount`
- `sql.longDuration -> opm.pg.sql.warnSec`
- `conn.usageRate -> opm.pg.conn.criticalRate`
- `space.usageRate -> opm.pg.space.criticalRate`
- `collectExpectation.sys -> opm.sys.collectIntervalSec`
- `collectExpectation.topCpu -> opm.topCpu.collectIntervalSec`
- `collectExpectation.focus -> opm.focus.collectIntervalSec`
- `disk.usageThreshold -> opm.disk.criticalRate`

### 4.2 Windows 在线代理 `ws://192.168.0.60:8001`

- `collectExpectation.sys -> opm.sys.collectIntervalSec`
- `collectExpectation.topMemory -> opm.topMemory.collectIntervalSec`
- `collectExpectation.topIo -> opm.topIo.collectIntervalSec`
- `collectExpectation.topNet -> opm.topNet.collectIntervalSec`
- `focus.cpu.java.-1 -> opm.focus.cpu.criticalRate`
- `focus.memory.java.<pid> -> opm.focus.memory.criticalBytes`
- `focus.io.java.-1 -> opm.focus.io.criticalRateBytesPerSec`

### 4.3 Linux 在线代理 `ws://192.168.145.57:8801`

- `diskPartition.critical._ -> opm.diskPartition.criticalRate`
- `focus.memory.aggregate.name_java_ -> opm.focus.memory.minorBytes`

## 5. 真实验证方式

本轮不是只看接口，而是做了两层验证：

1. **接口层**
   - 告警列表 / 告警详情返回的 `configParamKey` 是否正确
2. **页面层**
   - 真实浏览器登录 OPM
   - 在告警页点开详情
   - 点击“跳转配置项”
   - 确认 URL 中 `focusParam` 正确
   - 确认配置页存在对应 `[data-param-key]`
   - 确认未出现“未找到配置项”

## 6. 收尾

- 已恢复以下代理的测试前配置快照：
  - `ws://192.168.0.60:2020`
  - `ws://192.168.0.60:8001`
  - `ws://192.168.145.57:8801`

## 7. 结论

本轮“告警 -> 跳转配置项”主路径已完成统一治理，且已在 Windows / Linux 多代理场景下完成真实覆盖验证。

当前可以认为：

1. 关键告警链路的 `configParamKey` 生成与归一化已稳定
2. 页面点击“跳转配置项”能够定位到真实存在的配置项
3. PG deadlock、TOP 监控、focus 聚合等此前明确存在问题的场景已修复并验证通过
