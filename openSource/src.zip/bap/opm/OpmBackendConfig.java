package bap.opm;

import bap.opm.cfg.OpmRuntimeConfig;

/**
 * OPM后端运行时配置读取。
 *
 * 说明：
 * - 该类仅用于后端（OpmCenter/Collector/Service）读取运行态参数；
 * - 前端GUI不应直接依赖此类做状态判定。
 */
public class OpmBackendConfig
{
    private OpmBackendConfig()
    {
    }

    public static long getCoreCollectIntervalMs()
    {
        return 1000L * OpmRuntimeConfig.getLong(OpmConst.CONF_CORE_COLLECT_INTERVAL_SEC, OpmConst.DEFAULT_CORE_COLLECT_INTERVAL_SEC);
    }

    public static String getCollectorClassesText()
    {
        return OpmRuntimeConfig.getString(OpmConst.CONF_CORE_COLLECTOR_CLASSES, OpmConst.DEFAULT_CORE_COLLECTOR_CLASSES);
    }

    public static String getCollectorClassesTextNullable()
    {
        return OpmRuntimeConfig.getString(OpmConst.CONF_CORE_COLLECTOR_CLASSES, null);
    }

    public static boolean isPersistEnable()
    {
        return OpmRuntimeConfig.getBoolean(OpmConst.CONF_CORE_PERSIST_ENABLE, OpmConst.DEFAULT_CORE_PERSIST_ENABLE);
    }

    public static int getRetentionDay()
    {
        return OpmRuntimeConfig.getInt(OpmConst.CONF_CORE_RETENTION_DAY, OpmConst.DEFAULT_CORE_RETENTION_DAY);
    }

    public static boolean isAlarmEnable()
    {
        return OpmRuntimeConfig.getBoolean(OpmConst.CONF_ALARM_ENABLE, OpmConst.DEFAULT_ALARM_ENABLE);
    }

    public static int getDefaultAlarmCooldownSec()
    {
        return OpmRuntimeConfig.getInt(OpmConst.CONF_ALARM_DEFAULT_COOLDOWN_SEC, OpmConst.DEFAULT_ALARM_DEFAULT_COOLDOWN_SEC);
    }

    public static int getAlarmSuppressSec()
    {
        return OpmRuntimeConfig.getInt(OpmConst.CONF_ALARM_SUPPRESS_SEC, OpmConst.DEFAULT_ALARM_SUPPRESS_SEC);
    }

    public static boolean isDebugEnable()
    {
        return OpmRuntimeConfig.getBoolean(OpmConst.CONF_CORE_DEBUG_ENABLE, OpmConst.DEFAULT_CORE_DEBUG_ENABLE);
    }
}
