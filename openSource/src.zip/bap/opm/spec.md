# OPM 模块设计说明

## 1. 目标

OPM（Operation Monitor）用于在 BAP 代理（或主控）内常驻运行，按周期采集系统及后续扩展目标（DB、Redis 等）的运行指标，并在触发规则时统一上报 TsAlarm 告警。

本模块设计目标：

1. 采集器插件化：采集、规则、配置解析一体化扩展。
2. 数据模型可检索：主表存共性检索字段，附表存采集器特有结构化字段。
3. 告警统一出口：统一写 TsAlarm，同时保留 OPM 侧结构化关联信息。
4. 代理上下文一致：所有采集记录关联 agentCode，并冗余 agentName 与 myUri。

## 2. 总体架构

### 2.1 启动链路

- `bap.opm.OpmStarter`：CStarter 启动入口。
- `bap.opm.OpmCenter`：模块中心，负责模型初始化、采集器挂载、调度循环、入库与告警。

### 2.2 采集器插件模型

采集器接口采用 Cell 规范：`cell.bap.opm.collector.IOpmCollector`。

每个采集器在同一个接口实现以下能力：

1. 配置项定义（含 key、中文标签、默认值、类型）
2. 配置解析
3. 数据采集
4. 规则判定
5. 告警构建
6. 模型声明（需要初始化的静态模型）

即：采集器与规则一一对应，扩展新采集器时不需要修改中心逻辑。

### 2.3 配置与模板驱动装配（v2）

OPM 启动后不再从 `starter.xml` 读取具体监控参数，监控参数统一来自 **配置模型**。

- `starter.xml` 的 `opm` 节点仅保留：`enable`、`before/depends(dao)`。
- 采集器默认装配来源：
  1) `opm.core.collectorClasses`（运行时配置）
  2) 默认采集器列表（`sys/focus/topCpu/topMemory/topIo/topNet/disk/diskPartition/pg`）
- 后端运行态判断统一放在 `OpmBackendConfig`，`OpmConst` 只保留常量定义。
- 性能约束：启动后不执行任何自动类/插件扫描；类扫描仅在“人工打开配置界面”时被动触发。
- 每个采集器目录都提供自己的模板文件：
  - 路径：`resources/bap/opm/collector/<collectorKey>/config.xml`
  - 模板包含两个分组：`collect`（采集配置）与 `rules`（告警规则配置）
  - 后续扩展采集器时，要求在同目录归一实现：采集逻辑 + 配置模板（含规则配置）

该约束确保“采集器个性化内容收归一处”，新增采集器无需修改中心配置定义。

### 2.3.1 展示层冻结结构（本轮重构）

本轮重构后，OPM 配置展示层固定为以下结构：

```text
OPM配置
├─ 全局
├─ 系统监控
├─ 重点进程
├─ TOP监控
├─ 磁盘监控
└─ PG监控
```

展开结构固定如下：

```text
OPM配置
├─ 全局
│  └─ 保持现状
│
├─ 系统监控
│  ├─ 采集开关与周期
│  ├─ 总体CPU
│  ├─ 总体内存
│  ├─ 总体IO
│  └─ 总体网络
│
├─ 重点进程
│  └─ 保持现状
│
├─ TOP监控
│  ├─ 采集开关与周期
│  ├─ TOP进程CPU
│  ├─ TOP进程内存
│  ├─ TOP进程IO
│  └─ TOP进程网络
│
├─ 磁盘监控
│  ├─ 磁盘总体监控
│  │  ├─ 采集开关与周期
│  │  └─ 整体容量/使用率阈值
│  └─ 磁盘分区监控
│     ├─ 采集开关与周期
│     ├─ 默认分区阈值
│     └─ 指定分区阈值
│
└─ PG监控
   └─ 保持现状
```

### 2.3.2 采集器命名与职责冻结（本轮重构）

本轮重构按以下语义冻结采集器职责与命名：

| 展示组 | 采集器Key | 语义边界 |
|---|---|---|
| 全局 | `core`（非单一采集器） | OPM 全局配置 |
| 系统监控 | `sys` | 只承载整机总体 CPU / 内存 / IO / 网络 |
| 重点进程 | `focus` | 只承载人工定义的重点进程监控 |
| TOP监控 | `topCpu` / `topMemory` / `topIo` / `topNet` | 只承载普通进程 Top 排行与告警 |
| 磁盘监控 | `disk` / `diskPartition` | 分别承载磁盘总体与磁盘分区 |
| PG监控 | `pg` | 只承载 PostgreSQL 专项监控 |

本轮重构采用以下强制约束：

1. 所有属于 TOP 监控的采集器类、接口、常量类、配置 key、collectorKey、配置组 key，统一带 `top` 字样。
2. 禁止继续使用 `proc`、`process` 作为 TOP 监控语义命名。
3. `focus` 只代表重点进程，不得再混入 TOP 监控命名或规则解释。
4. `sys` 只代表系统总体，不再并入 TOP 监控展示组。
5. 本轮重构不考虑历史数据、旧配置、旧 key、旧类名兼容；允许直接按新语义调整。

### 2.4 Web端代码位置

OPM 的 Web 前端代码与后端代码分目录维护，当前前端源码位置使用相对当前 `spec.md` 的路径表示如下：

- Web 前端工程根目录：`../../../../../Bap/websrc/opm-web`
- 页面视图目录：`../../../../../Bap/websrc/opm-web/src/views`
- 接口封装目录：`../../../../../Bap/websrc/opm-web/src/api`
- 类型定义目录：`../../../../../Bap/websrc/opm-web/src/types`
- 已部署静态资源目录：`../../../../../Bap/webapps/opm`

当前已识别到的 OPM Web 关键文件包括：

- 采集列表页面：`../../../../../Bap/websrc/opm-web/src/views/OpmCollectView.vue`
- 告警页面：`../../../../../Bap/websrc/opm-web/src/views/OpmAlarmView.vue`
- 前端接口定义：`../../../../../Bap/websrc/opm-web/src/api/opm.ts`
- 前端类型定义：`../../../../../Bap/websrc/opm-web/src/types/opm.ts`

## 3. 数据建模

### 3.0 OPM 配置模型（新增）

`OpmAgentConfigDo`（`opm_agent_config`）作为按代理存储的监控配置：

- 一代理一条配置（`foreignKey` 唯一索引）
- 与 `TsAgentDo` 通过 `@Foreign` 外键关联（不使用 `@Depend`）
- 关键字段：
  - `agentCode` / `agentName` / `myUri`
  - `updateTime`
  - `configJson`（`ColType.TEXT`，可存大文本配置）

说明：用户明确要求“全新开始”，不做 starter 参数迁移；首次读取仅返回模板默认配置给界面，不自动落库，保存时才建档。
当“查询不到配置记录”时，OPM 主循环处于低频空转，不执行采集轮询；仅当人工保存后存在配置记录且至少启用一个采集器时才进入真实采集。

### 3.1 共性主表

`OpmMetricMainDo`（顶层共性模型）用于快速检索过滤：

- `collectorKey`：采集器标识
- `collectorLabel`：采集器名称
- `agentCode`：代理 code（维值引用 TsAgentDo）
- `agentName`：代理名称冗余
- `myUri`：当前进程 URI（兜底识别）
- `collectTime`：采集时间
- `status`：状态（OK/WARN/CRITICAL）
- `summary`：摘要

### 3.2 个性附表

每个采集器有自己的附表（例如系统采集器 `OpmSysMetricDo`），采用 `@Foreign` 外键扩展模式挂在主表下：

- 可关联查询
- 主表删除时联动删除附表

说明：

- 附表通过 `foreignClass/foreignKey` 引用主表（并声明 `@Foreign` 允许的父模型）

### 3.3 告警关联

告警统一写 `TsAlarm`。

OPM 额外维护 `OpmAlarmRefDo` 作为结构化告警索引：

- 存储 `alarmUuid`、`metricMainUuid`、`collectorKey`、`agentCode`、`myUri`、`ruleKey` 等
- 能关联反查采集数据
- 与采集数据不建立强依赖（满足“可查但不强依赖”）

### 3.4 告警跳配置映射逻辑（强制）

“告警 -> 跳转配置项”属于 OPM 的强制能力，必须保证每条支持跳转的告警都能定位到**真实存在**的配置项。

#### 3.4.1 统一原则

1. **优先直接回填 `configParamKey`**
   - 采集器在构造 `OpmRuleResult` 时，若已经明确知道当前告警对应的真实配置项，必须直接写入 `rs.configParamKey`
   - 典型场景：根据 `alarmLevel` 明确落到 `warn/minor/major/critical` 对应真实配置项

2. **统一后端归一化**
   - 若采集器未直接回填，则必须由统一注册表解析并归一化，禁止页面或调用方自行猜测
   - 统一入口：`bap.opm.registry.OpmConfigRegistry`
   - 统一方法：`resolveConfigParamKey(...)` / `normalizeConfigParamKey(...)`

3. **禁止多处散落拼 key**
   - `ruleKey`
   - `configParamMetaKey`
   - `configParamKey`
   - 动态聚合/分区规则 key
   - expectation 规则 key
   都必须优先收敛到统一常量/工具，不得在多个类里反复手写字符串

4. **前端只消费后端结果**
   - 前端跳转逻辑只使用后端返回的 `configParamKey`
   - 前端不得自己根据 `ruleKey` 再次拼接配置项 key

#### 3.4.2 统一真源

以下对象属于“告警跳配置”链路的唯一真源：

- 统一 key 常量：`bap.opm.registry.OpmAlarmConfigKeys`
- 配置注册表：`bap.opm.registry.OpmConfigRegistry`
- 告警索引归一化入口：`bap.opm.OpmCenter`
- 告警 Web 输出归一化入口：`bap.opm.web.OpmWebServlet`

约束如下：

1. 新增 rule key 时，必须优先在 `OpmAlarmConfigKeys` 中定义常量
2. 新增 `OpmConfigParamMeta` / `OpmAlarmRuleMeta` 时，必须优先引用常量，不得直接硬编码
3. 动态规则（如重点进程聚合、磁盘分区）必须通过统一工具方法生成 rule key
4. 告警详情与告警列表返回给前端时，必须输出归一化后的 `configParamKey`

#### 3.4.3 典型映射口径

以下映射口径作为当前系统固定规范：

- `collectExpectation.sys -> opm.sys.collectIntervalSec`
- `collectExpectation.topCpu -> opm.topCpu.collectIntervalSec`
- `collectExpectation.topMemory -> opm.topMemory.collectIntervalSec`
- `collectExpectation.topIo -> opm.topIo.collectIntervalSec`
- `collectExpectation.topNet -> opm.topNet.collectIntervalSec`
- `collectExpectation.focus -> opm.focus.collectIntervalSec`
- `disk.usageThreshold -> opm.disk.warnRate/minor/major/criticalRate`
- `diskPartition.* -> opm.diskPartition.warnRate/criticalRate`
- `lock.deadlockCount -> opm.pg.deadlock.warnCount/minorCount/majorCount/criticalCount`
- `sql.longDuration -> opm.pg.sql.warnSec/minorSec/majorSec/criticalSec`
- `conn.usageRate -> opm.pg.conn.warnRate/minorRate/majorRate/criticalRate`
- `space.usageRate -> opm.pg.space.warnRate/minorRate/majorRate/criticalRate`
- `focus.cpu.* / focus.memory.* / focus.io.* -> 依据 alarmLevel 落到对应真实配置项`

> 注意：像 `focus.memory.aggregate.name_xxx` 这类聚合告警，不能因为它是模式规则就默认回退到 warn 级别，必须按真实 `alarmLevel` 落到对应配置项。

#### 3.4.4 前端跳转要求

前端告警页跳配置逻辑固定如下：

1. 从选中告警读取 `agentCode` 与 `configParamKey`
2. 跳转到：`#/config?agentCode=<agentCode>&focusParam=<configParamKey>`
3. 配置页必须根据 `focusParam` 定位到真实存在的 `[data-param-key]`
4. 若未找到配置项，必须显式报错：`未找到配置项：<key>`

前端页面：

- 告警页：`../../../../../Bap/websrc/opm-web/src/views/OpmAlarmView.vue`
- 配置页：`../../../../../Bap/websrc/opm-web/src/views/OpmConfigView.vue`

### 3.5 告警跳配置变更后的强制自检（必须执行）

只要修改以下任一内容，必须执行“告警跳配置”自检：

- 任意 collector 的 rule key
- 任意 collector 的阈值配置 key
- `OpmConfigParamMeta` / `OpmAlarmRuleMeta`
- `configParamKey` 的归一化逻辑
- 前端告警页 / 配置页跳转逻辑
- 展示层 key、collectorKey、配置项 key 命名

#### 3.5.1 后端自检要求

至少检查：

1. 新增/修改的 `ruleKey` 是否已在统一常量中定义
2. 对应 `OpmAlarmRuleMeta` 是否绑定了 `configParamKey` 或 `configParamMetaKey`
3. 若为多级阈值告警，是否能按 `alarmLevel` 落到真实配置项
4. `OpmConfigRegistry.validate()` 是否通过
5. 编译是否通过：`ant compile`

#### 3.5.2 页面自检要求

至少验证：

1. 告警列表/详情返回的 `configParamKey` 非空且正确
2. 点击“跳转配置项”后，URL 中 `focusParam` 正确
3. 配置页存在对应 `[data-param-key="<configParamKey>"]`
4. 页面未出现“未找到配置项”

#### 3.5.3 覆盖要求

变更后至少覆盖以下类型中的相关项：

- 系统监控
- TOP监控
- 重点进程监控
- 磁盘监控
- PG监控

若现场存在 Windows / Linux 两类代理，必须尽量两边都做真实验证；能真采的优先真采，不能稳定真采的再使用仿真或压阈值造数。

## 4. 代理识别策略

模块启动时识别并缓存当前代理上下文：

1. 优先 `TsHelper.getMyUriText()`
2. 回退 `tiny.service.my.uri`
3. 通过 `TsAgentDo.code=myUri` 查询代理名称
4. 若查不到，`agentName` 回退为 `myUri`

该缓存与进程生命周期一致，供采集入库快速复用。

## 5. 配置规范（v2）

配置 key 仍采用 `opm.<域>.<语义项>`。

v2 生效链路：

1. 采集器模板（`resources/bap/opm/collector/*/config.xml`）定义参数元信息与默认值。
2. `OpmAgentConfigDo.configJson` 存储代理实例化后的实际参数值。
3. OPM 主循环按 `updateTime` 自动刷新运行时配置（热生效，无需重启）。

starter 仅用于模块启停，不再承担 OPM 具体参数配置职责。

### 5.1 展示层与命名约束

- 展示层固定为：`全局 / 系统监控 / 重点进程 / TOP监控 / 磁盘监控 / PG监控`。
- TOP 监控相关采集器统一使用以下 key：
  - `topCpu`
  - `topMemory`
  - `topIo`
  - `topNet`
- TOP 监控相关配置 key 统一使用以下前缀：
  - `opm.topCpu.*`
  - `opm.topMemory.*`
  - `opm.topIo.*`
  - `opm.topNet.*`
- 禁止继续引入以下旧语义命名：
  - `procCpu`
  - `process`
  - `processCpu`
  - `processMemory`
  - `processIo`
- `diskPartition` 只作为“磁盘分区监控”存在，不再额外复制为其他顶层语义组。

### 5.2 代理管理入口约束

- 代理管理右键菜单固定显示“编辑监控配置”。
- 若该代理未启用 `opm` starter：菜单可点，但仅提示“请先启用OPM模块后再编辑”。
- 若启用：打开动态配置界面，保存后自动触发后端配置重载。
- 客户端仅通过主控连接访问 `OpmCenterService`（`OpmClient`），所有配置读写与可编辑判定均在主控执行。
- 参数统一使用 `agentCode` 标识目标代理；后端负责识别“该 agentCode 是否指向主控自身”的特殊场景。
- 约束：前端/UI 不直接执行“仅后端可判定”的逻辑；此类判断统一由后端服务提供接口给前端调用。
- 每次打开配置界面，后端都会自动发现 `cell.bap.opm.collector.*` 下采集器与模板；若发现新增采集器，返回给前端时默认 `enable=false`。
- `opm.core.enable` 与 `opm.core.pluginScanIntervalSec` 不在动态配置界面暴露，OPM启停仅由 `starter.xml` 控制。

### 5.3 PG 长时 SQL 告警口径

- 配置项只保留各级别时长门限：`opm.pg.sql.warnSec`、`opm.pg.sql.minorSec`、`opm.pg.sql.majorSec`、`opm.pg.sql.criticalSec`。
- 不再保留 `warnDurationSec/minorDurationSec/majorDurationSec/criticalDurationSec` 这类“持续时间”配置。
- 规则判定口径为单次采集结果中的 `maxSqlDurationSec`，只要达到对应门限即立即触发告警。
- 告警重复抑制仍由 `opm.pg.rule.cooldownSec` 控制，避免同一规则在短时间内重复上报。
- 告警详情展示上，PG 长时 SQL 规则不再展示“持续时间”，仅保留级别、门限、消息等即时判定信息。

### 5.4 PG 锁监控口径

PG 锁相关监控拆分为 `死锁监控` 与 `长时锁监控` 两类。

#### 5.4.1 死锁监控

- 指标来源：`pg_stat_database.deadlocks`
- 判定口径：`deadlockDeltaCount = 本轮 deadlocks - 上轮 deadlocks`
- 只要本轮增量大于 `0` 且达到对应分级阈值，即触发死锁告警
- 规则 key：`lock.deadlockCount`
- 配置项：
  - `opm.pg.deadlock.warnCount`
  - `opm.pg.deadlock.minorCount`
  - `opm.pg.deadlock.majorCount`
  - `opm.pg.deadlock.criticalCount`
- 死锁告警触发后应立即补抓排查现场，尽量保留：
  - 死锁相关会话快照
  - 锁等待边
  - 表锁相关 SQL
  - 疑似死锁对
  - suspect SQL 列表

说明：PostgreSQL 真正判定死锁后会主动中止其中一方事务，因此现场不一定完整保留；当前设计要求在检测到死锁增量后立即补抓，以尽量保留可排查信息。

#### 5.4.2 长时锁监控

- 不要求会话必须处于互等状态
- 只要同一事务或同一会话持续持锁超过门限，即认为存在长时锁风险
- 重点覆盖：
  - `idle in transaction`
  - `idle in transaction (aborted)`
  - 活动中但长时间不释放锁的事务
  - 已形成等待链的长事务
- 只监控当前库：采集 SQL 固定限制 `a.datname = current_database()`，避免跨库噪音
- 规则 key：`lock.longDuration`
- 配置项：
  - `opm.pg.lock.enable`
  - `opm.pg.lock.warnSec`
  - `opm.pg.lock.minorSec`
  - `opm.pg.lock.majorSec`
  - `opm.pg.lock.criticalSec`

长时锁识别的核心不是“同一文本 SQL 是否重复出现”，而是“同一事务或同一会话是否连续存在”。

稳定身份 `stableKey` 由以下要素组成：

- `pid`
- `backendXid`
- `xactStartEpoch`
- `relationNames`
- 归一化后的 `query`

设计约束：

- `pid` 用于区分不同后端会话
- `backendXid` 用于尽量识别同一事务上下文
- `xactStartEpoch` 用于区分同一 PID 上不同事务轮次，避免事务切换后误判为同一长时锁
- `relationNames` 变化时视为不同持锁现场
- `query` 用于辅助区分同一事务中的不同执行语句

去噪规则：

- 没有关联表名的会话忽略
- 没有 SQL 文本的会话忽略
- 没有事务年龄、状态年龄且不在事务态的会话忽略
- 普通 `idle` 会话忽略

持续时间口径：

- 对外配置只保留 `warn/minor/major/critical` 的秒数门限，不再额外配置“持续时间”
- 系统内部通过连续采样判断“持续存在”
- 首次看到 `stableKey` 时记录 `firstSeenTime`
- 后续采样仍看到同一 `stableKey` 时继续累计
- `observedLockSec = now - firstSeenTime`
- 到达对应门限即触发告警

长时锁告警详情约束：

- `longLockPrimarySqls`：严格筛选后的主视图，只保留高度疑似长时间占锁的 SQL 或会话，便于优先排查
- `longLockContext`：完整现场附加信息，至少包含：
  - `allLongLocks`
  - `tableLockSqls`
  - `lockWaits`

筛选原则：

- `idle in transaction` 与 `idle in transaction (aborted)` 优先保留到 `longLockPrimarySqls`
- 对于 `active + wait_event_type=Lock` 且 `queryAgeSec/stateAgeSec` 很短的会话，更偏向死锁或锁等待现场，通常只保留在 `longLockContext`

结果解读：

- `deadlockDeltaCount > 0`：本轮新增了 PostgreSQL 自认定的真实死锁
- `longLockCount > 0`：本轮发现了长时持锁会话
- `maxLongLockSec > 0`：当前最长长时锁会话的连续持锁时长

采集异常详情约束：

- 当 PG 采集阶段抛异常时，详情中应保留：
  - `collectErrorMessage`
  - `collectErrorClass`
  - `collectErrorDetail`
- 其中 `collectErrorDetail` 记录完整线程堆栈，便于排查失败位置
- PG 详情子表（如长 SQL 详情、锁等待详情）应先在内存中缓存，待主扩展表成功落库并拿到外键后再统一持久化，避免外键时序问题

## 6. 调试与测试策略

支持调试开关：`opm.core.debugEnable`。

测试代码提供：

1. 立即触发采集并验证入库
2. 触发规则验证 TsAlarm 与 OPM 结构化索引
3. 验证按 agent/collector/time 过滤查询

## 6.1 仿真器机制

OPM 支持通过 Java 插件挂载仿真器，用于测试模拟采集数据。

### 6.1.1 核心组件

- `IOpmCollectorSimulator`：仿真器 Cell 接口，定义在 `cell.bap.opm.simulator` 包
- `OpmSimulator`：仿真器对象，存储采集器 Key 和 Cell 类名
- `OpmCenter.setSimulator(collectorKey, cellClassName)`：挂载仿真器（设置即替换）
- `OpmCenter.setSimulator(null, null)`：解挂仿真器

### 6.1.2 仿真器接口定义

```java
package cell.bap.opm.simulator;

import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmRuleResult;
import java.util.List;

public interface IOpmCollectorSimulator {
    
    /**
     * 获取仿真器名称
     */
    String getSimulatorName();
    
    /**
     * 获取目标采集器Key（如 "sys", "topCpu", "pg"）
     */
    String getTargetCollectorKey();
    
    /**
     * 仿真采集数据
     * @param agentCtx 代理上下文
     * @param now 当前时间戳
     * @return 仿真采集结果，返回null则跳过本次采集
     */
    OpmCollectResult simulateCollect(OpmAgentContext agentCtx, long now) throws Exception;
    
    /**
     * 仿真规则评估（可选）
     * @return 规则结果列表，返回null则使用真实采集器的规则评估
     */
    default List<OpmRuleResult> simulateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception {
        return null;
    }
}
```

### 6.1.3 仿真器实现示例

```java
package opm.simulator;

import bap.cells.BasicCell;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.md.opm.sys.OpmSysMetricDo;
import cell.bap.opm.simulator.IOpmCollectorSimulator;
import java.util.Random;

/**
 * CPU高负载仿真器（Cell插件实现）。
 * 
 * Cell开发规范：
 * 1. 接口必须放在 cell 包下（如 cell.bap.opm.simulator.IOpmCollectorSimulator）
 * 2. 接口必须继承 PluginCellIntf
 * 3. 实现类继承 BasicCell，实现接口方法
 * 4. 工程必须使用 DEPEND_PLUGIN 类型（depend_type=2）
 */
public class CpuHighLoadSimulator extends BasicCell implements IOpmCollectorSimulator {
    
    public String getSimulatorName() {
        return "CPU高负载仿真器";
    }
    
    public String getTargetCollectorKey() {
        return "sys";
    }
    
    public OpmCollectResult simulateCollect(OpmAgentContext agentCtx, long now) throws Exception {
        Random rand = new Random(now);
        double cpuBase = 0.70 + rand.nextDouble() * 0.25;
        double memBase = 0.65 + rand.nextDouble() * 0.30;
        
        OpmCollectResult result = new OpmCollectResult();
        result.collectorKey = "sys";
        result.collectorLabel = "系统监控(仿真)";
        result.collectTime = now;
        
        OpmSysMetricDo ext = new OpmSysMetricDo();
        ext.cpuUsageRate = cpuBase;
        ext.memUsageRate = memBase;
        result.metricExt = ext;
        
        if (cpuBase >= 0.95) {
            result.status = 2;
            result.summary = String.format("cpu=%.2f%% (CRITICAL)", cpuBase*100);
        } else if (cpuBase >= 0.90) {
            result.status = 2;
            result.summary = String.format("cpu=%.2f%% (MAJOR)", cpuBase*100);
        } else if (cpuBase >= 0.80) {
            result.status = 1;
            result.summary = String.format("cpu=%.2f%% (MINOR)", cpuBase*100);
        } else {
            result.status = 0;
            result.summary = String.format("cpu=%.2f%% (NORMAL)", cpuBase*100);
        }
        
        return result;
    }
}
```

### 6.1.4 使用流程

1. **创建 Java 工程**：在 BAP 中创建 Java 工程
2. **实现仿真器接口**：编写实现 `IOpmCollectorSimulator` 的类
3. **发布插件**：将工程发布为插件
4. **挂载仿真器**：通过 JavaTool 调用 `OpmCenter.setSimulator()`
5. **解挂仿真器**：测试完成后解挂

### 6.1.5 挂载/解挂命令

通过 JavaTool 执行：

```java
// 挂载仿真器
import bap.opm.OpmCenter;
OpmCenter.setSimulator("sys", "opm.simulator.CpuHighLoadSimulator");

// 解挂仿真器
OpmCenter.setSimulator(null, null);

// 查看当前仿真器状态
import bap.opm.OpmCenter;
import bap.opm.OpmSimulator;
OpmSimulator sim = OpmCenter.getSimulator();
if (sim != null) {
    System.out.println("仿真器: " + sim.getCellClassName());
    System.out.println("采集器: " + sim.getCollectorKey());
}
```

### 6.1.6 Python 脚本支持

使用 `bap_java_project.py` 脚本自动化完整流程：

```python
import sys
sys.path.insert(0, "C:/Users/chkec/.agents/skills/bap_host/scripts")
from bap_java_project import BapJavaProjectManager
from bap_executor import BapDynamicExecutor

# 1. 创建工程
manager = BapJavaProjectManager(base_url="http://localhost:8090")
project = manager.create_project("OpmSimulators", depend_type=0)

# 2. 保存仿真器代码
manager.save_code(project['uuid'], "opm.simulator", "CpuHighLoadSimulator", code)

# 3. 发布插件
manager.export_plugin(project['uuid'], "OpmSimulators")

# 4. 挂载仿真器
executor = BapDynamicExecutor(base_url="http://localhost:8090")
executor.execute('OpmCenter.setSimulator("sys", "opm.simulator.CpuHighLoadSimulator");')

# 5. 解挂仿真器
executor.execute('OpmCenter.setSimulator(null, null);')
```

**成功响应：**

```json
{
  "success": true,
  "data": {
    "result": 2,
    "resultType": "java.lang.Integer"
  }
}
```

**编译错误响应：**

```json
{
  "success": false,
  "error": {
    "type": "compile",
    "message": "unexpected token",
    "line": 1,
    "column": 5,
    "codeNear": "1 + 1"
  }
}
```

**运行时错误响应：**

```json
{
  "success": false,
  "error": {
    "type": "runtime",
    "message": "NullPointerException",
    "exceptionClass": "java.lang.NullPointerException",
    "stackTrace": "..."
  }
}
```

## 7. 实施约束

1. 模型全部为静态 Java 模型。
2. 在 Starter 的 initBeforeDao 阶段注册模型。
3. 采集器扩展必须遵循同一抽象接口。

## 8. 人工启动验证清单

以下清单用于在真实代理/主控启动后验证 OPM 全链路。

### 9.1 启动前检查

1. 确认 `starter.xml` 已启用 `opm`：
   - 文件：`F:/dev/Product/Bap/conf/starter.xml`
   - `opm`、`dao`、`cpluginService`、`tinyServiceChief/Member/Servant`（按角色）处于可用状态。
2. 确认数据库连接正常，且有 `TsAgentDo` 数据（便于 agentCode/agentName 识别）。
3. 若要执行调试告警验证，设置：
   - `opm.core.debugEnable=true`

### 9.2 采集链路验证（采集 -> 入库）

1. 启动服务后，执行 `bap.test.OpmSmokeTest`。
2. 观察输出应包含：
   - `collectNow(sys)` 的 summary
   - 最新 `OpmMetricMainDo` 记录列表
3. DB 侧验证：
   - 主表 `opm_metric_main` 有新增记录；
   - 附表 `opm_sys_metric` 有对应记录；
   - `opm_sys_metric.foreignClass/foreignKey` 指向 `opm_metric_main`。

### 9.3 告警链路验证（规则 -> TsAlarm -> 结构化索引）

1. 执行 `bap.test.OpmAlarmTest`（需 `opm.core.debugEnable=true`）。
2. 观察输出应包含：
   - 最新告警索引 `OpmAlarmRefDo` 记录；
   - `alarmRequestId`、`metricMainUuid`、`collectorKey` 等字段。
3. DB 侧验证：
   - `opm_alarm_ref` 有新增；
   - `opm_alarm_ext` / `opm_sys_alarm_ext` 有扩展记录；
   - `TsAlarm` 有对应告警（requestId 对齐 `alarmRequestId`）。

### 9.4 查询链路验证（过滤检索）

1. 执行 `bap.test.OpmQueryTest`。
2. 验证可按如下维度查询到数据：
   - `agentCode`
   - `collectorKey`
   - `collectTime / alarmTime`

### 9.5 异常场景验证

1. 暂停 tiny service 上报通道，验证 OPM 告警能自动回退本地保存 TsAlarm。
2. 清空/缺失 TsAgentDo 目标记录，验证采集仍能落库且 `myUri` 可定位来源。
3. 降低阈值（如 `opm.sys.cpu.warnRate=0.01`）验证规则触发与冷却时间生效。

## 9. 字段字典

### 10.1 `opm_metric_main`（采集主表）

| 字段 | 含义 | 用途 |
|---|---|---|
| `uuid` | 主键 | 主表唯一标识 |
| `collectorKey` | 采集器标识 | 跨采集器过滤 |
| `collectorLabel` | 采集器名称 | 展示 |
| `agentCode` | 代理编码（维值引用 TsAgentDo） | 按代理检索 |
| `agentName` | 代理名称冗余 | 快速识别 |
| `myUri` | 进程URI | 兜底来源定位 |
| `collectTime` | 采集时间 | 时间范围检索 |
| `status` | 状态（OK/WARN/CRITICAL） | 快速筛选 |
| `summary` | 采集摘要 | 列表快速查看 |
| `metricClass` | 附表模型类名 | 动态详情分流 |
| `metricUuid` | 附表记录UUID | 详情定位 |

### 10.2 `opm_sys_metric`（系统采集附表）

| 字段 | 含义 | 用途 |
|---|---|---|
| `foreignClass/foreignKey` | 外键关联主表主键 | 主附关联 + 联动删除 |
| `cpuUsageRate` | CPU使用率 | 规则判定 |
| `memUsageRate` | 内存使用率 | 规则判定 |
| `diskMaxUsageRate` | 磁盘最大使用率 | 规则判定 |
| `netRxRate`/`netTxRate`/`netTotalRate` | 网络吞吐 | 趋势分析 |
| `detailJson` | 原始结构化详情 | 深入排障 |

### 10.3 `opm_alarm_ref`（告警关联索引）

| 字段 | 含义 | 用途 |
|---|---|---|
| `alarmRequestId` | 告警请求ID | 与 TsAlarm.requestId 对齐 |
| `alarmUuid` | TsAlarm.uuid（可空） | 本地保存时关联 |
| `metricMainUuid` | 采集主表UUID（非强依赖） | 告警反查采集 |
| `collectorKey` | 采集器标识 | 按采集器查告警 |
| `ruleKey`/`ruleLabel` | 触发规则 | 告警分类 |
| `alarmLevel` | 告警级别 | 严重度筛选 |
| `agentCode`/`agentName`/`myUri` | 来源代理信息 | 来源过滤与识别 |
| `detailJson` | 规则细节JSON | 细节展示 |

### 10.4 `opm_alarm_ext` / `opm_sys_alarm_ext`（告警扩展）

| 字段 | 含义 | 用途 |
|---|---|---|
| `alarmRefUuid` | 告警索引UUID（强依赖） | 告警扩展挂接 |
| `metricMainUuid` | 采集主表UUID（非强依赖） | 反查采集 |
| `metricName` | 指标名（系统扩展） | 前端差异化展示 |
| `currentRate`/`warnRate`/`criticalRate` | 当前值与阈值 | 规则解释 |

## 10. 查询示例（SQL / Cnd）

### 11.1 SQL 示例

```sql
-- 1) 最近30分钟某代理的系统采集主记录
select *
from opm_metric_main
where collectorKey = 'sys'
  and agentCode = :agentCode
  and collectTime >= :startTime
order by collectTime desc
limit 200;

-- 2) 告警索引反查采集主表（非强依赖，左连接）
select ar.*, mm.summary, mm.collectTime
from opm_alarm_ref ar
left join opm_metric_main mm on ar.metricMainUuid = mm.uuid
where ar.collectorKey = 'sys'
order by ar.alarmTime desc
limit 200;

-- 3) 查询系统告警扩展详情
select ar.alarmTime, ar.agentCode, ar.ruleKey, sx.metricName, sx.currentRate, sx.warnRate, sx.criticalRate
from opm_alarm_ref ar
left join opm_sys_alarm_ext sx on sx.alarmRefUuid = ar.uuid
where ar.collectorKey = 'sys'
order by ar.alarmTime desc
limit 200;
```

### 11.2 Cnd 示例

```java
// 最近系统采集主记录
List<OpmMetricMainDo> latest = dao.queryDoPage(
    OpmMetricMainDo.class,
    Cnd.where(OpmMetricMainDo.CollectorKey, "=", "sys")
       .and(OpmMetricMainDo.AgentCode, "=", agentCode)
       .desc(OpmMetricMainDo.CollectTime),
    new CPager(0, 200)
).getListData();

// 最近告警索引
List<OpmAlarmRefDo> alarms = dao.queryDoPage(
    OpmAlarmRefDo.class,
    Cnd.where(OpmAlarmRefDo.CollectorKey, "=", "sys")
       .desc(OpmAlarmRefDo.AlarmTime),
    new CPager(0, 200)
).getListData();
```

## 11. 重点进程监控配置规则

### 12.1 进程匹配规则

重点进程监控支持通过 PID、进程名、进程路径三种方式匹配进程，三种条件为**或关系**（任一匹配即可）。

#### 12.1.1 通配符支持

| 符号 | 含义 | 示例 |
|------|------|------|
| `*` | 匹配任意字符（0个或多个） | `java*` 匹配 java、javaw、javaws |
| `?` | 匹配单个字符 | `java?` 匹配 javaw（不匹配 java） |
| `+` | 叠加符，结尾加+表示聚合计算 | `postgresql+` 将所有 postgresql 进程叠加监控 |

#### 12.1.2 叠加符 `+` 规则

- **位置约束**：`+` 只能出现在配置项结尾，否则保存配置时报错
- **语义**：将匹配该模式的所有进程指标叠加计算后作为整体进行告警判断
- **示例**：
  - `java*+`：匹配所有 java 开头的进程，CPU/内存/IO 叠加后判断是否超阈值
  - `postgres+,mysql+`：postgres 进程组叠加监控，mysql 进程组叠加监控，两组独立告警

### 12.2 告警分离规则

#### 12.2.1 独立进程告警

- **无 `+` 号**：每个匹配到的进程独立判断，独立告警
- **示例**：配置 `java*`，匹配到 java、javaw 两个进程
  - java 进程 CPU 超阈值 → 报一条告警，详情只含 java 进程数据
  - javaw 进程 CPU 超阈值 → 报另一条告警，详情只含 javaw 进程数据

#### 12.2.2 聚合进程组告警

- **有 `+` 号**：同组进程叠加后判断，独立告警
- **示例**：配置 `java*+,intel*+`
  - java 进程组（java 0.3 + javaw 0.5 = 0.8）超阈值 → 报一条告警，详情只含 java、javaw 进程数据
  - intel 进程组（intel1 0.1 + intel2 0.2 = 0.3）超阈值 → 报另一条告警，详情只含 intel1、intel2 进程数据

### 12.3 配置校验

保存配置时后端校验 `+` 号位置：

```java
// 校验逻辑
String validatePatternList(String text, String fieldName) {
    for (String pattern : text.split("[,;\\r\\n]")) {
        int plusIndex = pattern.indexOf('+');
        if (plusIndex >= 0 && plusIndex != pattern.length() - 1) {
            return fieldName + "配置错误: '+' 只能出现在结尾，当前配置: " + pattern;
        }
    }
    return null;
}
```

### 12.4 实现关键类

| 类 | 职责 |
|---|---|
| `OpmFocusMatcher` | 进程匹配逻辑，支持通配符和叠加符解析 |
| `OpmFocusMatcher.RuleSet` | 规则集，包含精确匹配集合、通配模式列表、聚合模式列表 |
| `OpmFocusMatcher.MatchResult` | 匹配结果，包含是否匹配、是否聚合、聚合键 |
| `COpmFocusCollector` | 采集器，实现进程过滤和聚合计算 |
| `OpmFocusAlarmEvaluator` | 告警评估器，每个进程/进程组独立判断告警 |

### 12.5 数据结构

#### 12.5.1 采集数据结构

```json
{
  "focusCpuProcesses": [
    {
      "pid": 1234,
      "processName": "java",
      "cpuRate": 0.3,
      "aggregate": false
    },
    {
      "pid": -1,
      "processName": "java,javaw(聚合2进程)",
      "cpuRate": 0.8,
      "aggregate": true,
      "aggregateCount": 2,
      "aggregateKey": "name:java.*",
      "aggregateProcesses": [
        {"pid": 1234, "processName": "java", "cpuRate": 0.3},
        {"pid": 5678, "processName": "javaw", "cpuRate": 0.5}
      ]
    }
  ]
}
```

#### 12.5.2 告警详情结构

**独立进程告警**：
```json
{
  "focusProcessName": "java",
  "focusPid": 1234,
  "focusCpuRate": 0.3,
  "aggregate": false,
  "focusProcesses": [{"pid": 1234, "processName": "java", "cpuRate": 0.3}]
}
```

**聚合进程组告警**：
```json
{
  "focusProcessName": "java,javaw(聚合2进程)",
  "focusPid": -1,
  "focusCpuRate": 0.8,
  "aggregate": true,
  "aggregateCount": 2,
  "aggregateKey": "name:java.*",
  "aggregateProcesses": [
    {"pid": 1234, "processName": "java", "cpuRate": 0.3},
    {"pid": 5678, "processName": "javaw", "cpuRate": 0.5}
  ]
}
```
