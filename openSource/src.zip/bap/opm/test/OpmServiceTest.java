package bap.opm.test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.dfc.gui.LvUtil;

import bap.opm.OpmCenterService;
import bap.opm.OpmCenterServiceImpl;
import bap.opm.OpmCollectResult;
import bap.md.opm.OpmAlarmRefDo;
import bap.md.opm.OpmMetricMainDo;
import bap.md.opm.cpu.OpmCpuMetricDo;
import bap.md.opm.disk.OpmDiskMetricDo;
import bap.md.opm.io.OpmIoMetricDo;
import bap.md.opm.net.OpmNetMetricDo;
import bap.md.opm.sys.OpmSysMetricDo;

/**
 * OPM后端服务接口测试类
 * 
 * 测试覆盖：
 * 1. 运行时元数据查询
 * 2. 代理可编辑性检查
 * 3. 配置查询与保存
 * 4. 配置Schema查询
 * 5. 采集器列表查询
 * 6. 立即采集测试
 * 7. 各类指标数据查询
 * 8. 告警数据查询
 */
public class OpmServiceTest
{
    private OpmCenterService service;
    private List<String> testResults;
    private int passCount;
    private int failCount;
    private String currentAgentCode;

    public static void main(String[] args)
    {
        OpmServiceTest test = new OpmServiceTest();
        test.runAllTests();
    }

    public void runAllTests()
    {
        LvUtil.trace("========================================");
        LvUtil.trace("OPM后端服务接口测试报告");
        LvUtil.trace("========================================");
        LvUtil.trace("");

        testResults = new ArrayList<String>();
        passCount = 0;
        failCount = 0;

        try
        {
            service = OpmCenterServiceImpl.get();
        }
        catch (Exception e)
        {
            LvUtil.trace("[ERROR] 无法获取OpmCenterService实例: " + e.getMessage());
            return;
        }

        // 1. 运行时元数据测试
        testQueryRuntimeMeta();

        // 2. 代理可编辑性测试
        testIsAgentOpmEditable();

        // 3. 配置Schema测试
        testQueryConfigSchema();

        // 4. 采集器列表测试
        testListCollectorKeys();

        // 5. 配置查询测试
        testQueryAgentConfigMap();

        // 6. 配置保存测试
        testSaveAgentConfigMap();

        // 7. 立即采集测试
        testCollectNow();

        // 8. 主表数据查询测试
        testQueryLatestMain();

        // 9. 告警数据查询测试
        testQueryLatestAlarmRef();

        // 10. 各类指标查询测试
        testQuerySysMetric();
        testQueryCpuMetric();
        testQueryDiskMetric();
        testQueryIoMetric();
        testQueryNetMetric();

        // 输出测试报告
        printReport();
    }

    /**
     * 测试1：运行时元数据查询
     */
    protected void testQueryRuntimeMeta()
    {
        String testName = "queryRuntimeMeta";
        LvUtil.trace("[TEST] " + testName + " - 查询运行时元数据");

        try
        {
            Map<String, Object> meta = service.queryRuntimeMeta();

            if (meta == null)
            {
                recordFail(testName, "返回null");
                return;
            }

            // 验证必要字段
            StringBuilder sb = new StringBuilder();
            sb.append("  agentCode: ").append(meta.get("agentCode"));
            sb.append(", agentName: ").append(meta.get("agentName"));
            sb.append(", myUri: ").append(meta.get("myUri"));
            sb.append(", runtimeCollectorEnabled: ").append(meta.get("runtimeCollectorEnabled"));
            sb.append(", runtimeHasConfigRecord: ").append(meta.get("runtimeHasConfigRecord"));

            List<?> collectors = (List<?>) meta.get("collectors");
            sb.append(", collectors: ").append(collectors != null ? collectors.size() : 0);

            LvUtil.trace(sb.toString());

            // 保存当前代理Code供后续测试使用
            currentAgentCode = (String) meta.get("agentCode");

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试2：代理可编辑性检查
     */
    protected void testIsAgentOpmEditable()
    {
        String testName = "isAgentOpmEditable";
        LvUtil.trace("[TEST] " + testName + " - 检查代理OPM可编辑性");

        try
        {
            // 测试当前代理
            boolean editable = service.isAgentOpmEditable(currentAgentCode);
            LvUtil.trace("  当前代理(" + currentAgentCode + ")可编辑: " + editable);

            // 测试空代理
            try
            {
                service.isAgentOpmEditable(null);
                LvUtil.trace("  空代理测试: 应抛异常但未抛出");
            }
            catch (Exception expected)
            {
                LvUtil.trace("  空代理测试: 正确抛出异常");
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试3：配置Schema查询
     */
    protected void testQueryConfigSchema()
    {
        String testName = "queryConfigSchema";
        LvUtil.trace("[TEST] " + testName + " - 查询配置Schema");

        try
        {
            Map<String, Object> schema = service.queryConfigSchema();

            if (schema == null)
            {
                recordFail(testName, "返回null");
                return;
            }

            List<?> groups = (List<?>) schema.get("groups");
            LvUtil.trace("  配置组数量: " + (groups != null ? groups.size() : 0));

            if (groups != null)
            {
                for (Object g : groups)
                {
                    if (g instanceof Map)
                    {
                        Map<?, ?> group = (Map<?, ?>) g;
                        LvUtil.trace("    - " + group.get("key") + ": " + group.get("label"));
                    }
                }
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试4：采集器列表查询
     */
    protected void testListCollectorKeys()
    {
        String testName = "listCollectorKeys";
        LvUtil.trace("[TEST] " + testName + " - 查询采集器列表");

        try
        {
            List<String> keys = service.listCollectorKeys();

            if (keys == null)
            {
                recordFail(testName, "返回null");
                return;
            }

            LvUtil.trace("  采集器数量: " + keys.size());
            LvUtil.trace("  采集器列表: " + keys);

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试5：配置查询
     */
    protected void testQueryAgentConfigMap()
    {
        String testName = "queryAgentConfigMap";
        LvUtil.trace("[TEST] " + testName + " - 查询代理配置");

        try
        {
            Map<String, String> config = service.queryAgentConfigMap(currentAgentCode);

            if (config == null)
            {
                recordFail(testName, "返回null");
                return;
            }

            LvUtil.trace("  配置项数量: " + config.size());

            // 显示部分配置
            int count = 0;
            for (Map.Entry<String, String> ent : config.entrySet())
            {
                if (count++ < 10)
                {
                    LvUtil.trace("    " + ent.getKey() + " = " + ent.getValue());
                }
            }
            if (config.size() > 10)
            {
                LvUtil.trace("    ... 共 " + config.size() + " 项");
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试6：配置保存
     */
    protected void testSaveAgentConfigMap()
    {
        String testName = "saveAgentConfigMap";
        LvUtil.trace("[TEST] " + testName + " - 保存代理配置");

        try
        {
            // 先查询当前配置
            Map<String, String> config = service.queryAgentConfigMap(currentAgentCode);

            // 修改一个测试配置项
            String testKey = "opm.core.debugEnable";
            String originalValue = config.get(testKey);
            String testValue = "true".equals(originalValue) ? "false" : "true";

            config.put(testKey, testValue);

            // 保存配置
            service.saveAgentConfigMap(currentAgentCode, config);
            LvUtil.trace("  已保存配置: " + testKey + " = " + testValue);

            // 重新查询验证
            Map<String, String> newConfig = service.queryAgentConfigMap(currentAgentCode);
            String savedValue = newConfig.get(testKey);

            if (testValue.equals(savedValue))
            {
                LvUtil.trace("  验证成功: 配置已正确保存");

                // 恢复原值
                config.put(testKey, originalValue);
                service.saveAgentConfigMap(currentAgentCode, config);
                LvUtil.trace("  已恢复原配置: " + testKey + " = " + originalValue);

                recordPass(testName);
            }
            else
            {
                recordFail(testName, "配置保存验证失败: 期望=" + testValue + ", 实际=" + savedValue);
            }
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试7：立即采集
     */
    protected void testCollectNow()
    {
        String testName = "collectNow";
        LvUtil.trace("[TEST] " + testName + " - 立即采集测试");

        try
        {
            List<String> keys = service.listCollectorKeys();
            if (keys == null || keys.isEmpty())
            {
                LvUtil.trace("  跳过: 无可用采集器");
                recordPass(testName);
                return;
            }

            // 测试第一个采集器
            String collectorKey = keys.get(0);
            LvUtil.trace("  测试采集器: " + collectorKey);

            OpmCollectResult result = service.collectNow(collectorKey);

            if (result == null)
            {
                LvUtil.trace("  采集结果: null (可能采集器未启用)");
            }
            else
            {
                LvUtil.trace("  采集结果: collectorKey=" + result.collectorKey
                        + ", status=" + result.status
                        + ", summary=" + result.summary);
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            // 采集器可能正在运行，不算失败
            if (e.getMessage() != null && e.getMessage().contains("running"))
            {
                LvUtil.trace("  采集器正在运行，跳过本次测试");
                recordPass(testName);
            }
            else
            {
                recordFail(testName, e.getMessage());
            }
        }
    }

    /**
     * 测试8：主表数据查询
     */
    protected void testQueryLatestMain()
    {
        String testName = "queryLatestMain";
        LvUtil.trace("[TEST] " + testName + " - 查询最新主表数据");

        try
        {
            List<OpmMetricMainDo> list = service.queryLatestMain(10);

            if (list == null)
            {
                LvUtil.trace("  结果: null");
            }
            else
            {
                LvUtil.trace("  记录数: " + list.size());
                for (OpmMetricMainDo m : list)
                {
                    LvUtil.trace("    - " + m.collectorKey + " @ " + new java.util.Date(m.collectTime));
                }
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试9：告警数据查询
     */
    protected void testQueryLatestAlarmRef()
    {
        String testName = "queryLatestAlarmRef";
        LvUtil.trace("[TEST] " + testName + " - 查询最新告警数据");

        try
        {
            List<OpmAlarmRefDo> list = service.queryLatestAlarmRef(10);

            if (list == null)
            {
                LvUtil.trace("  结果: null");
            }
            else
            {
                LvUtil.trace("  记录数: " + list.size());
                for (OpmAlarmRefDo a : list)
                {
                    LvUtil.trace("    - [" + a.alarmLevel + "] " + a.message + " @ " + new java.util.Date(a.alarmTime));
                }
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试10：系统指标查询
     */
    protected void testQuerySysMetric()
    {
        String testName = "queryLatestSysMetric";
        LvUtil.trace("[TEST] " + testName + " - 查询系统指标");

        try
        {
            List<OpmSysMetricDo> list = service.queryLatestSysMetric(5);

            if (list == null)
            {
                LvUtil.trace("  结果: null");
            }
            else
            {
                LvUtil.trace("  记录数: " + list.size());
                if (!list.isEmpty())
                {
                    OpmSysMetricDo m = list.get(0);
                    LvUtil.trace("    cpuUsageRate=" + m.cpuUsageRate
                            + ", memUsageRate=" + m.memUsageRate
                            + ", diskMaxUsageRate=" + m.diskMaxUsageRate);
                }
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试11：CPU指标查询
     */
    protected void testQueryCpuMetric()
    {
        String testName = "queryLatestCpuMetric";
        LvUtil.trace("[TEST] " + testName + " - 查询CPU指标");

        try
        {
            List<OpmCpuMetricDo> list = service.queryLatestCpuMetric(5);

            if (list == null)
            {
                LvUtil.trace("  结果: null");
            }
            else
            {
                LvUtil.trace("  记录数: " + list.size());
                if (!list.isEmpty())
                {
                    OpmCpuMetricDo m = list.get(0);
                    LvUtil.trace("    cpuUsageRate=" + m.cpuUsageRate
                            + ", topProcName=" + m.topProcName);
                }
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试12：磁盘指标查询
     */
    protected void testQueryDiskMetric()
    {
        String testName = "queryLatestDiskMetric";
        LvUtil.trace("[TEST] " + testName + " - 查询磁盘指标");

        try
        {
            List<OpmDiskMetricDo> list = service.queryLatestDiskMetric(5);

            if (list == null)
            {
                LvUtil.trace("  结果: null");
            }
            else
            {
                LvUtil.trace("  记录数: " + list.size());
                if (!list.isEmpty())
                {
                    OpmDiskMetricDo m = list.get(0);
                    LvUtil.trace("    totalUsageRate=" + m.totalUsageRate
                            + ", maxUsageRate=" + m.maxUsageRate
                            + ", maxUsageMount=" + m.maxUsageMount);
                }
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试13：IO指标查询
     */
    protected void testQueryIoMetric()
    {
        String testName = "queryLatestIoMetric";
        LvUtil.trace("[TEST] " + testName + " - 查询IO指标");

        try
        {
            List<OpmIoMetricDo> list = service.queryLatestIoMetric(5);

            if (list == null)
            {
                LvUtil.trace("  结果: null");
            }
            else
            {
                LvUtil.trace("  记录数: " + list.size());
                if (!list.isEmpty())
                {
                    OpmIoMetricDo m = list.get(0);
                    LvUtil.trace("    topProcName=" + m.topProcName
                            + ", topProcReadRate=" + m.topProcReadRate
                            + ", topProcWriteRate=" + m.topProcWriteRate);
                }
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    /**
     * 测试14：网络指标查询
     */
    protected void testQueryNetMetric()
    {
        String testName = "queryLatestNetMetric";
        LvUtil.trace("[TEST] " + testName + " - 查询网络指标");

        try
        {
            List<OpmNetMetricDo> list = service.queryLatestNetMetric(5);

            if (list == null)
            {
                LvUtil.trace("  结果: null");
            }
            else
            {
                LvUtil.trace("  记录数: " + list.size());
                if (!list.isEmpty())
                {
                    OpmNetMetricDo m = list.get(0);
                    LvUtil.trace("    rxRate=" + m.rxRate
                            + ", txRate=" + m.txRate
                            + ", totalRate=" + m.totalRate);
                }
            }

            recordPass(testName);
        }
        catch (Exception e)
        {
            recordFail(testName, e.getMessage());
        }
    }

    protected void recordPass(String testName)
    {
        passCount++;
        testResults.add("[PASS] " + testName);
        LvUtil.trace("[PASS] " + testName);
        LvUtil.trace("");
    }

    protected void recordFail(String testName, String reason)
    {
        failCount++;
        testResults.add("[FAIL] " + testName + " - " + reason);
        LvUtil.trace("[FAIL] " + testName + " - " + reason);
        LvUtil.trace("");
    }

    protected void printReport()
    {
        LvUtil.trace("========================================");
        LvUtil.trace("测试报告汇总");
        LvUtil.trace("========================================");
        LvUtil.trace("");

        for (String result : testResults)
        {
            LvUtil.trace(result);
        }

        LvUtil.trace("");
        LvUtil.trace("总计: " + (passCount + failCount) + " 个测试");
        LvUtil.trace("  通过: " + passCount);
        LvUtil.trace("  失败: " + failCount);
        LvUtil.trace("");

        if (failCount == 0)
        {
            LvUtil.trace("[SUCCESS] 所有测试通过!");
        }
        else
        {
            LvUtil.trace("[WARNING] 存在失败的测试，请检查!");
        }

        LvUtil.trace("========================================");
    }
}