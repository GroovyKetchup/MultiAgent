package bap.opm.test;

import java.util.LinkedHashMap;
import java.util.Map;

import com.leavay.common.util.cjson.CJson;
import com.leavay.dfc.gui.LvUtil;

import bap.md.opm.pg.OpmPgMetricDo;
import bap.opm.OpmRuleResult;
import bap.opm.alarm.OpmAlarmPolicy;
import cell.bap.opm.collector.pg.COpmPgCollector;

/**
 * PG长时SQL告警抑制键测试。
 *
 * <pre>
 * 功能说明：
 * 1. 验证不同结构的长时SQL生成不同的抑制键
 * 2. 验证同结构但参数不同的SQL生成相同抑制键
 * 3. 验证告警指纹优先使用detailJson中的suppressKey
 * </pre>
 */
public class OpmPgLongSqlSuppressKeyTest
{
    public static void main(String[] args)
    {
        OpmPgLongSqlSuppressKeyTest test = new OpmPgLongSqlSuppressKeyTest();
        test.runAll();
    }

    protected void runAll()
    {
        LvUtil.trace("========================================");
        LvUtil.trace("PG长时SQL抑制键测试");
        LvUtil.trace("========================================");

        testDifferentSqlShouldNotSuppressEachOther();
        testSameSqlWithDifferentLiteralShouldShareSuppressKey();

        LvUtil.trace("========================================");
        LvUtil.trace("测试完成");
        LvUtil.trace("========================================");
    }

    protected void testDifferentSqlShouldNotSuppressEachOther()
    {
        LvUtil.trace("[TEST] 不同SQL不能共用抑制键");

        TestablePgCollector collector = new TestablePgCollector();
        String key1 = collector.exposeBuildSuppressKey("opm", mapSql("app-a", "10.0.0.1", "active",
                "select * from t_order where id = 1"));
        String key2 = collector.exposeBuildSuppressKey("opm", mapSql("app-a", "10.0.0.1", "active",
                "update t_order set status = 'DONE' where id = 1"));

        if (key1 == null || key1.equals(key2))
            throw new IllegalStateException("不同SQL生成了相同抑制键: key1=" + key1 + ", key2=" + key2);

        OpmRuleResult rule1 = buildRule(key1, "SQL执行时长过长: 当前=35.0s, 级别=警告, 阈值=30.0s");
        OpmRuleResult rule2 = buildRule(key2, "SQL执行时长过长: 当前=35.0s, 级别=警告, 阈值=30.0s");
        String fp1 = OpmAlarmPolicy.buildSuppressFingerprint("agent-1", "pg", rule1);
        String fp2 = OpmAlarmPolicy.buildSuppressFingerprint("agent-1", "pg", rule2);
        if (fp1.equals(fp2))
            throw new IllegalStateException("不同SQL生成了相同告警指纹: fp1=" + fp1 + ", fp2=" + fp2);

        LvUtil.trace("[PASS] key1=" + key1);
        LvUtil.trace("[PASS] key2=" + key2);
    }

    protected void testSameSqlWithDifferentLiteralShouldShareSuppressKey()
    {
        LvUtil.trace("[TEST] 同结构SQL应共用抑制键");

        TestablePgCollector collector = new TestablePgCollector();
        String key1 = collector.exposeBuildSuppressKey("opm", mapSql("app-a", "10.0.0.1", "active",
                "select * from t_order where id = 1 and amount > 99"));
        String key2 = collector.exposeBuildSuppressKey("opm", mapSql("app-a", "10.0.0.1", "active",
                "select * from t_order where id = 2 and amount > 199"));

        if (key1 == null || !key1.equals(key2))
            throw new IllegalStateException("同结构SQL未共用抑制键: key1=" + key1 + ", key2=" + key2);

        OpmRuleResult rule1 = buildRule(key1, "SQL执行时长过长: 当前=35.0s, 级别=警告, 阈值=30.0s");
        OpmRuleResult rule2 = buildRule(key2, "SQL执行时长过长: 当前=55.0s, 级别=警告, 阈值=30.0s");
        String fp1 = OpmAlarmPolicy.buildSuppressFingerprint("agent-1", "pg", rule1);
        String fp2 = OpmAlarmPolicy.buildSuppressFingerprint("agent-1", "pg", rule2);
        if (!fp1.equals(fp2))
            throw new IllegalStateException("同结构SQL未共用告警指纹: fp1=" + fp1 + ", fp2=" + fp2);

        LvUtil.trace("[PASS] sharedKey=" + key1);
    }

    protected OpmRuleResult buildRule(String suppressKey, String message)
    {
        OpmRuleResult rule = new OpmRuleResult();
        rule.ruleKey = "sql.longDuration";
        rule.message = message;

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        detail.put("suppressKey", suppressKey);
        rule.detailJson = CJson.toJson(detail);
        return rule;
    }

    protected Map<String, Object> mapSql(String applicationName, String clientAddr, String state, String query)
    {
        LinkedHashMap<String, Object> sql = new LinkedHashMap<String, Object>();
        sql.put("applicationName", applicationName);
        sql.put("clientAddr", clientAddr);
        sql.put("state", state);
        sql.put("query", query);
        return sql;
    }

    protected static class TestablePgCollector extends COpmPgCollector
    {
        public String exposeBuildSuppressKey(String dbName, Map<String, Object> sql)
        {
            Map<String, Object> topSql = pickTopLongSql(java.util.Arrays.<Map<String, Object>>asList(sql));
            return buildLongSqlSuppressKey(dbName, topSql);
        }
    }
}
