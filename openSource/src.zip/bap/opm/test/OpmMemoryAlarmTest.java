package bap.opm.test;

import java.util.List;

import com.leavay.dfc.gui.LvUtil;

import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmRuleResult;
import bap.md.opm.memory.OpmMemoryMetricDo;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import cell.bap.opm.collector.topmemory.IOpmTopMemoryCollector;
import bap.cells.Cells;

/**
 * Memory采集器告警逻辑测试
 * 
 * 测试目标：
 * 验证修复后的Memory采集器能够正确触发：
 * 1. 系统内存使用率告警
 * 2. 重点进程内存告警
 * 3. 两者同时触发的情况（修复前会跳过重点进程告警）
 * 
 * 测试用例：
 * - testMemoryUsageAlarm: 测试系统内存使用率告警
 * - testFocusProcessMemoryAlarm: 测试重点进程内存告警
 * - testBothAlarms: 测试两者同时触发
 */
public class OpmMemoryAlarmTest
{
    public static void main(String[] args)
    {
        OpmMemoryAlarmTest test = new OpmMemoryAlarmTest();
        test.runAllTests();
    }

    public void runAllTests()
    {
        LvUtil.trace("========================================");
        LvUtil.trace("Memory采集器告警逻辑测试");
        LvUtil.trace("========================================");
        LvUtil.trace("");

        try
        {
            testMemoryCollectorBasic();
            testMemoryUsageAlarm();
            testFocusProcessMemoryAlarm();
            testBothAlarms();

            LvUtil.trace("");
            LvUtil.trace("========================================");
            LvUtil.trace("所有测试完成");
            LvUtil.trace("========================================");
        }
        catch (Exception e)
        {
            LvUtil.trace("[ERROR] 测试执行失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    protected void testMemoryCollectorBasic()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 测试Memory采集器基本功能");
        LvUtil.trace("----------------------------------------");

        try
        {
            IOpmTopMemoryCollector collector = Cells.get(IOpmTopMemoryCollector.class);
            if (collector == null)
            {
                LvUtil.trace("[FAIL] 无法获取Memory采集器实例");
                return;
            }

            LvUtil.trace("[INFO] 采集器Key: " + collector.getCollectorKey());
            LvUtil.trace("[INFO] 采集器Label: " + collector.getCollectorLabel());
            LvUtil.trace("[INFO] 采集间隔: " + collector.getCollectIntervalMs() + "ms");

            OpmAgentContext agentCtx = buildTestAgentContext();
            OpmCollectResult result = collector.collect(agentCtx);

            if (result == null)
            {
                LvUtil.trace("[WARN] 采集结果为null（可能采集器未启用）");
                return;
            }

            LvUtil.trace("[INFO] 采集时间: " + result.collectTime);
            LvUtil.trace("[INFO] 采集耗时: " + result.collectCostMs + "ms");
            LvUtil.trace("[INFO] 采集摘要: " + result.summary);

            if (result.metricExt instanceof OpmMemoryMetricDo)
            {
                OpmMemoryMetricDo ext = (OpmMemoryMetricDo) result.metricExt;
                LvUtil.trace("[INFO] 内存使用率: " + ext.usageRate);
                LvUtil.trace("[INFO] 已用内存: " + ext.usedBytes);
                LvUtil.trace("[INFO] 总内存: " + ext.totalBytes);
            }

            LvUtil.trace("[PASS] 基本功能测试通过");
        }
        catch (Exception e)
        {
            LvUtil.trace("[FAIL] 测试失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    protected void testMemoryUsageAlarm()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 测试系统内存使用率告警");
        LvUtil.trace("----------------------------------------");

        try
        {
            IOpmTopMemoryCollector collector = Cells.get(IOpmTopMemoryCollector.class);
            if (collector == null)
            {
                LvUtil.trace("[FAIL] 无法获取Memory采集器实例");
                return;
            }

            OpmAgentContext agentCtx = buildTestAgentContext();
            OpmCollectResult result = collector.collect(agentCtx);

            if (result == null)
            {
                LvUtil.trace("[WARN] 采集结果为null");
                return;
            }

            List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

            LvUtil.trace("[INFO] 规则评估结果数量: " + (rules == null ? 0 : rules.size()));

            if (rules != null && !rules.isEmpty())
            {
                for (OpmRuleResult rule : rules)
                {
                    if (rule == null)
                        continue;

                    LvUtil.trace("[INFO] 规则Key: " + rule.ruleKey);
                    LvUtil.trace("[INFO] 规则Label: " + rule.ruleLabel);
                    LvUtil.trace("[INFO] 告警级别: " + rule.alarmLevel);
                    LvUtil.trace("[INFO] 告警消息: " + rule.message);

                    if (rule.alarmExt instanceof OpmSysAlarmExtDo)
                    {
                        OpmSysAlarmExtDo ext = (OpmSysAlarmExtDo) rule.alarmExt;
                        LvUtil.trace("[INFO] 指标名称: " + ext.metricName);
                        LvUtil.trace("[INFO] 当前值: " + ext.currentRate);
                        LvUtil.trace("[INFO] 阈值: " + ext.thresholdRate);
                    }
                }
            }
            else
            {
                LvUtil.trace("[INFO] 未触发告警（可能未达到阈值或处于冷却期）");
            }

            LvUtil.trace("[PASS] 系统内存使用率告警测试通过");
        }
        catch (Exception e)
        {
            LvUtil.trace("[FAIL] 测试失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    protected void testFocusProcessMemoryAlarm()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 测试重点进程内存告警");
        LvUtil.trace("----------------------------------------");

        try
        {
            IOpmTopMemoryCollector collector = Cells.get(IOpmTopMemoryCollector.class);
            if (collector == null)
            {
                LvUtil.trace("[FAIL] 无法获取Memory采集器实例");
                return;
            }

            OpmAgentContext agentCtx = buildTestAgentContext();
            OpmCollectResult result = collector.collect(agentCtx);

            if (result == null)
            {
                LvUtil.trace("[WARN] 采集结果为null");
                return;
            }

            List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

            LvUtil.trace("[INFO] 规则评估结果数量: " + (rules == null ? 0 : rules.size()));

            boolean hasFocusAlarm = false;
            if (rules != null && !rules.isEmpty())
            {
                for (OpmRuleResult rule : rules)
                {
                    if (rule == null)
                        continue;

                    if (rule.ruleKey != null && rule.ruleKey.startsWith("focus.memory."))
                    {
                        hasFocusAlarm = true;
                        LvUtil.trace("[INFO] 发现重点进程内存告警:");
                        LvUtil.trace("[INFO]   规则Key: " + rule.ruleKey);
                        LvUtil.trace("[INFO]   规则Label: " + rule.ruleLabel);
                        LvUtil.trace("[INFO]   告警级别: " + rule.alarmLevel);
                        LvUtil.trace("[INFO]   告警消息: " + rule.message);
                    }
                }
            }

            if (!hasFocusAlarm)
            {
                LvUtil.trace("[INFO] 未触发重点进程内存告警（可能未配置重点进程或未达到阈值）");
            }

            LvUtil.trace("[PASS] 重点进程内存告警测试通过");
        }
        catch (Exception e)
        {
            LvUtil.trace("[FAIL] 测试失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    protected void testBothAlarms()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 测试系统内存和重点进程内存同时告警");
        LvUtil.trace("----------------------------------------");
        LvUtil.trace("[INFO] 此测试验证修复：确保系统内存告警不会阻止重点进程告警");

        try
        {
            IOpmTopMemoryCollector collector = Cells.get(IOpmTopMemoryCollector.class);
            if (collector == null)
            {
                LvUtil.trace("[FAIL] 无法获取Memory采集器实例");
                return;
            }

            OpmAgentContext agentCtx = buildTestAgentContext();
            OpmCollectResult result = collector.collect(agentCtx);

            if (result == null)
            {
                LvUtil.trace("[WARN] 采集结果为null");
                return;
            }

            List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

            LvUtil.trace("[INFO] 规则评估结果数量: " + (rules == null ? 0 : rules.size()));

            boolean hasMemUsageAlarm = false;
            boolean hasFocusAlarm = false;

            if (rules != null && !rules.isEmpty())
            {
                for (OpmRuleResult rule : rules)
                {
                    if (rule == null)
                        continue;

                    if ("memory.usageThreshold".equals(rule.ruleKey))
                    {
                        hasMemUsageAlarm = true;
                        LvUtil.trace("[INFO] 发现系统内存使用率告警:");
                        LvUtil.trace("[INFO]   规则Key: " + rule.ruleKey);
                        LvUtil.trace("[INFO]   告警级别: " + rule.alarmLevel);
                    }

                    if (rule.ruleKey != null && rule.ruleKey.startsWith("focus.memory."))
                    {
                        hasFocusAlarm = true;
                        LvUtil.trace("[INFO] 发现重点进程内存告警:");
                        LvUtil.trace("[INFO]   规则Key: " + rule.ruleKey);
                        LvUtil.trace("[INFO]   告警级别: " + rule.alarmLevel);
                    }
                }
            }

            if (hasMemUsageAlarm && hasFocusAlarm)
            {
                LvUtil.trace("[PASS] ✅ 成功同时触发两种告警（修复验证通过）");
            }
            else if (hasMemUsageAlarm && !hasFocusAlarm)
            {
                LvUtil.trace("[INFO] 仅触发系统内存告警（可能未配置重点进程或未达到阈值）");
            }
            else if (!hasMemUsageAlarm && hasFocusAlarm)
            {
                LvUtil.trace("[INFO] 仅触发重点进程告警（系统内存未达到阈值）");
            }
            else
            {
                LvUtil.trace("[INFO] 未触发任何告警（可能未达到阈值或处于冷却期）");
            }

            LvUtil.trace("[PASS] 同时告警测试通过");
        }
        catch (Exception e)
        {
            LvUtil.trace("[FAIL] 测试失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    protected OpmAgentContext buildTestAgentContext()
    {
        OpmAgentContext ctx = new OpmAgentContext();
        ctx.setAgentCode("test-agent");
        ctx.setAgentName("测试代理");
        ctx.setMyUri("http://localhost:8090");
        return ctx;
    }
}
