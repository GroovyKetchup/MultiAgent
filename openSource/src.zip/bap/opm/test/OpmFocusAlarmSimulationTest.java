package bap.opm.test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.cjson.CJson;
import com.leavay.dfc.gui.LvUtil;

import bap.md.opm.focus.OpmFocusMetricDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmRuleResult;
import bap.opm.collector.focus.OpmFocusMatcher;
import bap.opm.collector.focus.OpmFocusProcessGrouper;
import bap.opm.system.SystemMetrics;
import cell.bap.opm.collector.focus.OpmFocusAlarmEvaluator;

public class OpmFocusAlarmSimulationTest
{
    protected static final double CPU_WARN = 0.50D;
    protected static final double CPU_MINOR = 0.70D;
    protected static final double CPU_MAJOR = 0.85D;
    protected static final double CPU_CRITICAL = 0.95D;

    protected static final long MEM_WARN = 512L * 1024L * 1024L;
    protected static final long MEM_MINOR = 2L * 1024L * 1024L * 1024L;
    protected static final long MEM_MAJOR = 3L * 1024L * 1024L * 1024L;
    protected static final long MEM_CRITICAL = 4L * 1024L * 1024L * 1024L;

    protected static final double IO_WARN = 10D * 1024D * 1024D;
    protected static final double IO_MINOR = 30D * 1024D * 1024D;
    protected static final double IO_MAJOR = 80D * 1024D * 1024D;
    protected static final double IO_CRITICAL = 150D * 1024D * 1024D;

    public static void main(String[] args)
    {
        new OpmFocusAlarmSimulationTest().runAll();
    }

    public void runAll()
    {
        LvUtil.trace("========================================");
        LvUtil.trace("重点进程聚合/单进程仿真测试");
        LvUtil.trace("========================================");

        try
        {
            testAggregateOnlyByWildcard();
            testAggregateAndSingleTogether();
            testMixedPidAndNameRules();
            testMixedPathRules();
            testAggregateIsolation();
            testNoMatchNoAlarm();
            testThresholdBoundary();
            testNormalizeNameRules();
            testNormalizePathRules();
            testPidWildcardRules();
            testOverlappingAggregateRules();
            testBelowThresholdNoAlarm();

            LvUtil.trace("");
            LvUtil.trace("========================================");
            LvUtil.trace("全部仿真测试通过");
            LvUtil.trace("========================================");
        }
        catch (Throwable e)
        {
            LvUtil.trace("[FAIL] 仿真测试失败: " + e.getMessage());
            e.printStackTrace();
        }
    }

    protected void testAggregateOnlyByWildcard()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 纯聚合规则: java*+,Intel*+");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "java*+,Intel*+", "");

        List<SystemMetrics.ProcessMemoryUsage> memoryProcesses = new ArrayList<SystemMetrics.ProcessMemoryUsage>();
        memoryProcesses.add(createMemoryProc(1001, "java", "c:/jdk/bin/java.exe", 1024L * 1024L * 1024L));
        memoryProcesses.add(createMemoryProc(1002, "javaw", "c:/jdk/bin/javaw.exe", 2L * 1024L * 1024L * 1024L));
        memoryProcesses.add(createMemoryProc(2001, "IntelService", "c:/intel/service.exe", 500L * 1024L * 1024L));
        memoryProcesses.add(createMemoryProc(2002, "IntelHelper", "c:/intel/helper.exe", 400L * 1024L * 1024L));
        List<OpmFocusProcessGrouper.ProcessGroup> memoryGroups = OpmFocusProcessGrouper.groupMemoryProcesses(memoryProcesses, ruleSet);

        List<OpmRuleResult> rules = evalMemory(ruleSet, memoryGroups);
        dumpRules(rules);

        assertRuleCount(rules, 2, "两组纯聚合规则应各自产生1条聚合告警");
        OpmRuleResult javaRule = requireRule(rules, "focus.memory.aggregate.name_java_");
        OpmRuleResult intelRule = requireRule(rules, "focus.memory.aggregate.name_intel_");
        assertContains(javaRule.message, "重点进程组内存持续过高", "聚合规则应产生进程组告警文案");
        assertContains(intelRule.message, "重点进程组内存持续过高", "聚合规则应产生进程组告警文案");
        assertNotContains(javaRule.message, "进程=javaw, PID=1002", "聚合告警不应降级成单进程文案");
        assertAggregateDetailOnlyContains(javaRule, "java", "javaw");
        assertAggregateDetailNotContains(javaRule, "IntelService", "IntelHelper");
        assertNoRulePrefix(rules, "focus.memory.java.", "纯聚合规则不应抛出 java 单进程告警");
        assertNoRulePrefix(rules, "focus.memory.javaw.", "纯聚合规则不应抛出 javaw 单进程告警");
        assertNoRulePrefix(rules, "focus.memory.intelservice.", "纯聚合规则不应抛出 IntelService 单进程告警");
        LvUtil.trace("[PASS] 纯聚合规则验证通过");
    }

    protected void testAggregateAndSingleTogether()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 聚合与单进程并存: java*+,javaw,java");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "java*+,javaw,java", "");

        List<SystemMetrics.ProcessCpuUsage> cpuProcesses = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        cpuProcesses.add(createCpuProc(3001, "java", "c:/jdk/bin/java.exe", 0.44D));
        cpuProcesses.add(createCpuProc(3002, "javaw", "c:/jdk/bin/javaw.exe", 0.81D));
        List<OpmFocusProcessGrouper.ProcessGroup> cpuGroups = OpmFocusProcessGrouper.groupCpuProcesses(cpuProcesses, ruleSet);

        List<OpmRuleResult> rules = evalCpu(ruleSet, cpuGroups);
        dumpRules(rules);

        assertRuleCount(rules, 2, "聚合+单进程规则应同时保留两类告警");
        requireRule(rules, "focus.cpu.aggregate.name_java_");
        requireRule(rules, "focus.cpu.javaw.3002");
        assertNoRulePrefix(rules, "focus.cpu.java.3001", "未达阈值的单进程不应误报");
        LvUtil.trace("[PASS] 聚合与单进程并存验证通过");
    }

    protected void testMixedPidAndNameRules()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] PID与进程名混合规则");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("4101", "java*+", "");

        List<SystemMetrics.ProcessCpuUsage> cpuProcesses = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        cpuProcesses.add(createCpuProc(4101, "java", "c:/jdk/bin/java.exe", 0.72D));
        cpuProcesses.add(createCpuProc(4102, "javaw", "c:/jdk/bin/javaw.exe", 0.45D));
        List<OpmFocusProcessGrouper.ProcessGroup> cpuGroups = OpmFocusProcessGrouper.groupCpuProcesses(cpuProcesses, ruleSet);

        List<OpmRuleResult> rules = evalCpu(ruleSet, cpuGroups);
        dumpRules(rules);

        assertRuleCount(rules, 2, "PID+聚合规则应可同时告警");
        requireRule(rules, "focus.cpu.aggregate.name_java_");
        requireRule(rules, "focus.cpu.java.4101");
        LvUtil.trace("[PASS] PID与进程名混合验证通过");
    }

    protected void testMixedPathRules()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 路径混合规则");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "", "c:/apps/jdk/*+,c:/apps/tools/javaw.exe");

        List<SystemMetrics.ProcessIoUsage> ioProcesses = new ArrayList<SystemMetrics.ProcessIoUsage>();
        ioProcesses.add(createIoProc(5101, "java", "c:/apps/jdk/bin/java.exe", 50D * 1024D * 1024D));
        ioProcesses.add(createIoProc(5102, "javaw", "c:/apps/jdk/bin/javaw.exe", 70D * 1024D * 1024D));
        ioProcesses.add(createIoProc(5103, "javaw", "c:/apps/tools/javaw.exe", 90D * 1024D * 1024D));
        List<OpmFocusProcessGrouper.ProcessGroup> ioGroups = OpmFocusProcessGrouper.groupIoProcesses(ioProcesses, ruleSet);

        List<OpmRuleResult> rules = evalIo(ruleSet, ioGroups);
        dumpRules(rules);

        assertRuleCount(rules, 2, "路径聚合+单路径规则应同时生效");
        requireRule(rules, "focus.io.aggregate.path_c_apps_jdk_");
        requireRule(rules, "focus.io.javaw.5103");
        LvUtil.trace("[PASS] 路径混合规则验证通过");
    }

    protected void testAggregateIsolation()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 聚合详情隔离验证");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "java*+,python*+", "");

        List<SystemMetrics.ProcessIoUsage> ioProcesses = new ArrayList<SystemMetrics.ProcessIoUsage>();
        ioProcesses.add(createIoProc(6101, "java", "c:/jdk/bin/java.exe", 45D * 1024D * 1024D));
        ioProcesses.add(createIoProc(6102, "javaw", "c:/jdk/bin/javaw.exe", 50D * 1024D * 1024D));
        ioProcesses.add(createIoProc(6201, "python", "c:/python/python.exe", 4D * 1024D * 1024D));
        ioProcesses.add(createIoProc(6202, "pythonw", "c:/python/pythonw.exe", 5D * 1024D * 1024D));
        List<OpmFocusProcessGrouper.ProcessGroup> ioGroups = OpmFocusProcessGrouper.groupIoProcesses(ioProcesses, ruleSet);

        List<OpmRuleResult> rules = evalIo(ruleSet, ioGroups);
        dumpRules(rules);

        assertRuleCount(rules, 1, "仅 java 聚合组达到阈值时应只产生1条告警");
        OpmRuleResult rule = requireRule(rules, "focus.io.aggregate.name_java_");
        assertAggregateDetailOnlyContains(rule, "java", "javaw");
        assertAggregateDetailNotContains(rule, "python", "pythonw");
        LvUtil.trace("[PASS] 聚合详情隔离验证通过");
    }

    protected void testNoMatchNoAlarm()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 无命中规则不应产生告警");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "oracle*+,nginx", "");

        List<SystemMetrics.ProcessMemoryUsage> processes = new ArrayList<SystemMetrics.ProcessMemoryUsage>();
        processes.add(createMemoryProc(7001, "java", "c:/jdk/bin/java.exe", 3L * 1024L * 1024L * 1024L));
        processes.add(createMemoryProc(7002, "python", "c:/python/python.exe", 2L * 1024L * 1024L * 1024L));

        List<OpmFocusProcessGrouper.ProcessGroup> groups = OpmFocusProcessGrouper.groupMemoryProcesses(processes, ruleSet);
        List<OpmRuleResult> rules = evalMemory(ruleSet, groups);
        dumpRules(rules);

        assertGroupCount(groups, 0, "无命中规则时不应产生任何组");
        assertRuleCount(rules, 0, "无命中规则时不应产生告警");
        LvUtil.trace("[PASS] 无命中规则验证通过");
    }

    protected void testThresholdBoundary()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 阈值边界命中");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "java", "");

        List<SystemMetrics.ProcessMemoryUsage> processes = new ArrayList<SystemMetrics.ProcessMemoryUsage>();
        processes.add(createMemoryProc(7101, "java", "c:/jdk/bin/java.exe", MEM_MINOR));

        List<OpmFocusProcessGrouper.ProcessGroup> groups = OpmFocusProcessGrouper.groupMemoryProcesses(processes, ruleSet);
        List<OpmRuleResult> rules = evalMemory(ruleSet, groups);
        dumpRules(rules);

        assertRuleCount(rules, 1, "等于阈值时应触发告警");
        OpmRuleResult rule = requireRule(rules, "focus.memory.java.7101");
        assertContains(rule.message, "级别=次要", "等于次要阈值应命中次要级别");
        LvUtil.trace("[PASS] 阈值边界验证通过");
    }

    protected void testNormalizeNameRules()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 进程名标准化匹配");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "java,idea64", "");

        List<SystemMetrics.ProcessCpuUsage> processes = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        processes.add(createCpuProc(7201, "java.exe", "c:/jdk/bin/java.exe", 0.74D));
        processes.add(createCpuProc(7202, "idea64#1", "c:/jetbrains/bin/idea64.exe", 0.71D));

        List<OpmFocusProcessGrouper.ProcessGroup> groups = OpmFocusProcessGrouper.groupCpuProcesses(processes, ruleSet);
        List<OpmRuleResult> rules = evalCpu(ruleSet, groups);
        dumpRules(rules);

        assertGroupCount(groups, 2, "标准化名称应正确命中两个单进程组");
        requireRule(rules, "focus.cpu.java.7201");
        requireRule(rules, "focus.cpu.idea64.7202");
        LvUtil.trace("[PASS] 进程名标准化验证通过");
    }

    protected void testNormalizePathRules()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 路径标准化匹配");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "", "C:\\Apps\\JDK\\BIN\\JAVAW.EXE,c:/apps/jdk/bin/server/");

        List<SystemMetrics.ProcessIoUsage> processes = new ArrayList<SystemMetrics.ProcessIoUsage>();
        processes.add(createIoProc(7251, "javaw", "c:/apps/jdk/bin/javaw.exe", 95D * 1024D * 1024D));
        processes.add(createIoProc(7252, "server", "c:/apps/jdk/bin/server/", 90D * 1024D * 1024D));

        List<OpmFocusProcessGrouper.ProcessGroup> groups = OpmFocusProcessGrouper.groupIoProcesses(processes, ruleSet);
        List<OpmRuleResult> rules = evalIo(ruleSet, groups);
        dumpRules(rules);

        assertGroupCount(groups, 2, "路径标准化后应正确命中两个单进程组");
        requireRule(rules, "focus.io.javaw.7251");
        requireRule(rules, "focus.io.server.7252");
        LvUtil.trace("[PASS] 路径标准化验证通过");
    }

    protected void testPidWildcardRules()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] PID通配匹配");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("73*", "", "");

        List<SystemMetrics.ProcessCpuUsage> processes = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        processes.add(createCpuProc(7301, "workerA", "c:/app/workerA.exe", 0.73D));
        processes.add(createCpuProc(7302, "workerB", "c:/app/workerB.exe", 0.76D));
        processes.add(createCpuProc(7401, "workerC", "c:/app/workerC.exe", 0.88D));

        List<OpmFocusProcessGrouper.ProcessGroup> groups = OpmFocusProcessGrouper.groupCpuProcesses(processes, ruleSet);
        List<OpmRuleResult> rules = evalCpu(ruleSet, groups);
        dumpRules(rules);

        assertGroupCount(groups, 2, "PID通配应只命中 73xx 的进程");
        requireRule(rules, "focus.cpu.workera.7301");
        requireRule(rules, "focus.cpu.workerb.7302");
        assertNoRulePrefix(rules, "focus.cpu.workerc.7401", "不匹配 PID 通配的进程不应告警");
        LvUtil.trace("[PASS] PID通配验证通过");
    }

    protected void testOverlappingAggregateRules()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 重叠聚合规则");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "java*+,*w+", "");

        List<SystemMetrics.ProcessIoUsage> processes = new ArrayList<SystemMetrics.ProcessIoUsage>();
        processes.add(createIoProc(7401, "java", "c:/jdk/bin/java.exe", 20D * 1024D * 1024D));
        processes.add(createIoProc(7402, "javaw", "c:/jdk/bin/javaw.exe", 60D * 1024D * 1024D));
        processes.add(createIoProc(7403, "pythonw", "c:/python/pythonw.exe", 35D * 1024D * 1024D));

        List<OpmFocusProcessGrouper.ProcessGroup> groups = OpmFocusProcessGrouper.groupIoProcesses(processes, ruleSet);
        List<OpmRuleResult> rules = evalIo(ruleSet, groups);
        dumpRules(rules);

        assertGroupCount(groups, 2, "重叠聚合规则应形成两个聚合组");
        OpmRuleResult javaRule = requireRule(rules, "focus.io.aggregate.name_java_");
        OpmRuleResult wRule = requireRule(rules, "focus.io.aggregate.name_w");
        assertAggregateDetailOnlyContains(javaRule, "java", "javaw");
        assertAggregateDetailNotContains(javaRule, "pythonw");
        assertAggregateDetailOnlyContains(wRule, "javaw", "pythonw");
        assertNotContains(wRule.detailJson, "\"processName\",\"^\":\"java\"", "重叠聚合组不应混入纯 java 进程");
        LvUtil.trace("[PASS] 重叠聚合规则验证通过");
    }

    protected void testBelowThresholdNoAlarm()
    {
        LvUtil.trace("");
        LvUtil.trace("[TEST] 命中规则但低于阈值不告警");
        LvUtil.trace("----------------------------------------");

        OpmFocusMatcher.RuleSet ruleSet = OpmFocusMatcher.buildRuleSet("", "java*+,javaw", "");

        List<SystemMetrics.ProcessCpuUsage> processes = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        processes.add(createCpuProc(7501, "java", "c:/jdk/bin/java.exe", 0.19D));
        processes.add(createCpuProc(7502, "javaw", "c:/jdk/bin/javaw.exe", 0.29D));

        List<OpmFocusProcessGrouper.ProcessGroup> groups = OpmFocusProcessGrouper.groupCpuProcesses(processes, ruleSet);
        List<OpmRuleResult> rules = evalCpu(ruleSet, groups);
        dumpRules(rules);

        assertGroupCount(groups, 2, "低于阈值场景仍应正常分组");
        assertRuleCount(rules, 0, "命中规则但低于阈值时不应告警");
        LvUtil.trace("[PASS] 低于阈值不告警验证通过");
    }

    protected List<OpmRuleResult> evalCpu(OpmFocusMatcher.RuleSet ruleSet, List<OpmFocusProcessGrouper.ProcessGroup> groups)
    {
        OpmFocusMetricDo metric = new OpmFocusMetricDo();
        metric.detailJson = toDetailJson("focusCpuGroups", groups);
        return OpmFocusAlarmEvaluator.evalCpuAlarms(metric, buildAgentContext(), System.currentTimeMillis(), ruleSet,
                CPU_WARN, 60, CPU_MINOR, 30, CPU_MAJOR, 15, CPU_CRITICAL, 5);
    }

    protected List<OpmRuleResult> evalMemory(OpmFocusMatcher.RuleSet ruleSet, List<OpmFocusProcessGrouper.ProcessGroup> groups)
    {
        OpmFocusMetricDo metric = new OpmFocusMetricDo();
        metric.detailJson = toDetailJson("focusMemoryGroups", groups);
        return OpmFocusAlarmEvaluator.evalMemoryAlarms(metric, buildAgentContext(), System.currentTimeMillis(), ruleSet,
                MEM_WARN, 60, MEM_MINOR, 30, MEM_MAJOR, 15, MEM_CRITICAL, 5);
    }

    protected List<OpmRuleResult> evalIo(OpmFocusMatcher.RuleSet ruleSet, List<OpmFocusProcessGrouper.ProcessGroup> groups)
    {
        OpmFocusMetricDo metric = new OpmFocusMetricDo();
        metric.detailJson = toDetailJson("focusIoGroups", groups);
        return OpmFocusAlarmEvaluator.evalIoAlarms(metric, buildAgentContext(), System.currentTimeMillis(), ruleSet,
                IO_WARN, 60, IO_MINOR, 30, IO_MAJOR, 15, IO_CRITICAL, 5);
    }

    protected String toDetailJson(String key, List<OpmFocusProcessGrouper.ProcessGroup> groups)
    {
        LinkedHashMap<String, Object> detail = new LinkedHashMap<String, Object>();
        List<Map<String, Object>> maps = OpmFocusProcessGrouper.toGroupMapList(groups);
        detail.put(key, maps);
        detail.put(key.replace("Groups", "Processes"), maps);
        return CJson.toJson(detail);
    }

    protected SystemMetrics.ProcessCpuUsage createCpuProc(int pid, String processName, String processPath, double cpuRate)
    {
        SystemMetrics.ProcessCpuUsage proc = new SystemMetrics.ProcessCpuUsage();
        proc.pid = pid;
        proc.processName = processName;
        proc.processPath = processPath;
        proc.cpuRate = cpuRate;
        proc.memoryBytes = 0L;
        proc.source = "sim";
        return proc;
    }

    protected SystemMetrics.ProcessMemoryUsage createMemoryProc(int pid, String processName, String processPath, long memoryBytes)
    {
        SystemMetrics.ProcessMemoryUsage proc = new SystemMetrics.ProcessMemoryUsage();
        proc.pid = pid;
        proc.processName = processName;
        proc.processPath = processPath;
        proc.memoryBytes = memoryBytes;
        proc.source = "sim";
        return proc;
    }

    protected SystemMetrics.ProcessIoUsage createIoProc(int pid, String processName, String processPath, double ioRateBytesPerSec)
    {
        SystemMetrics.ProcessIoUsage proc = new SystemMetrics.ProcessIoUsage();
        proc.pid = pid;
        proc.processName = processName;
        proc.processPath = processPath;
        proc.memoryBytes = 0L;
        proc.ioRateBytesPerSec = ioRateBytesPerSec;
        proc.readRateBytesPerSec = ioRateBytesPerSec / 2D;
        proc.writeRateBytesPerSec = ioRateBytesPerSec / 2D;
        proc.source = "sim";
        return proc;
    }

    protected void dumpRules(List<OpmRuleResult> rules)
    {
        LvUtil.trace("[INFO] 告警数量: " + (rules == null ? 0 : rules.size()));
        if (rules == null)
            return;
        for (OpmRuleResult one : rules)
        {
            if (one == null)
                continue;
            LvUtil.trace("[INFO] ruleKey=" + one.ruleKey);
            LvUtil.trace("[INFO] message=" + one.message);
            LvUtil.trace("[INFO] detail=" + one.detailJson);
        }
    }

    protected OpmRuleResult requireRule(List<OpmRuleResult> rules, String prefix)
    {
        if (rules != null)
        {
            for (OpmRuleResult one : rules)
            {
                if (one != null && one.ruleKey != null && one.ruleKey.startsWith(prefix))
                    return one;
            }
        }
        throw new IllegalStateException("未找到规则: " + prefix);
    }

    protected void assertRuleCount(List<OpmRuleResult> rules, int expected, String message)
    {
        int actual = rules == null ? 0 : rules.size();
        if (actual != expected)
            throw new IllegalStateException(message + "，期望=" + expected + "，实际=" + actual);
    }

    protected void assertGroupCount(List<OpmFocusProcessGrouper.ProcessGroup> groups, int expected, String message)
    {
        int actual = groups == null ? 0 : groups.size();
        if (actual != expected)
            throw new IllegalStateException(message + "，期望=" + expected + "，实际=" + actual);
    }

    protected void assertNoRulePrefix(List<OpmRuleResult> rules, String prefix, String message)
    {
        if (rules == null)
            return;
        for (OpmRuleResult one : rules)
        {
            if (one != null && one.ruleKey != null && one.ruleKey.startsWith(prefix))
                throw new IllegalStateException(message + "，命中规则=" + one.ruleKey);
        }
    }

    protected void assertContains(String text, String expected, String message)
    {
        if (text == null || !text.contains(expected))
            throw new IllegalStateException(message + "，缺少=" + expected + "，实际=" + text);
    }

    protected void assertNotContains(String text, String forbidden, String message)
    {
        if (text != null && text.contains(forbidden))
            throw new IllegalStateException(message + "，命中=" + forbidden + "，实际=" + text);
    }

    protected void assertAggregateDetailOnlyContains(OpmRuleResult rule, String... names)
    {
        String detail = rule == null ? null : rule.detailJson;
        if (detail == null)
            throw new IllegalStateException("聚合告警缺少详情");
        for (String name : names)
            assertContains(detail, name, "聚合详情应包含组内进程");
    }

    protected void assertAggregateDetailNotContains(OpmRuleResult rule, String... names)
    {
        String detail = rule == null ? null : rule.detailJson;
        if (detail == null)
            return;
        for (String name : names)
            assertNotContains(detail, name, "聚合详情不应混入组外进程");
    }

    protected OpmAgentContext buildAgentContext()
    {
        OpmAgentContext ctx = new OpmAgentContext();
        ctx.setAgentCode("sim-agent");
        ctx.setAgentName("仿真代理");
        ctx.setMyUri("sim://opm-focus-test");
        return ctx;
    }
}
