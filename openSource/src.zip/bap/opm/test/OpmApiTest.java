package bap.opm.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * OPM Web API 测试
 */
public class OpmApiTest
{
    private static final String BASE_URL = "http://127.0.0.1:8090/api/opm";
    private static String TOKEN = null;
    
    public static void main(String[] args) throws Exception
    {
        System.out.println("========================================");
        System.out.println("OPM Web API 自动化测试");
        System.out.println("========================================");
        
        try
        {
            testLogin();
            testPing();
            testCollectList();
            testCollectSummary();
            
            System.out.println("\n========================================");
            System.out.println("[SUCCESS] 所有测试通过！");
            System.out.println("========================================");
        }
        catch (Exception e)
        {
            System.err.println("[FAIL] 测试失败: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private static void testLogin() throws Exception
    {
        System.out.println("\n[TEST] 登录测试...");
        
        String url = BASE_URL + "/auth/login";
        String json = "{\"userName\":\"root\",\"password\":\"public\"}";
        
        String response = post(url, json, null);
        
        if (!response.contains("\"success\":true"))
            throw new Exception("登录失败");
        
        int tokenStart = response.indexOf("\"token\":\"") + 9;
        int tokenEnd = response.indexOf("\"", tokenStart);
        TOKEN = response.substring(tokenStart, tokenEnd);
        
        System.out.println("[PASS] 登录成功，token已获取");
    }
    
    private static void testPing() throws Exception
    {
        System.out.println("\n[TEST] ping测试...");
        
        String response = get(BASE_URL + "/ping", TOKEN);
        
        if (!response.contains("\"success\":true"))
            throw new Exception("ping失败");
        
        System.out.println("[PASS] ping接口正常");
    }
    
    private static void testCollectList() throws Exception
    {
        System.out.println("\n[TEST] collect/list测试（核心）...");
        
        long start = System.currentTimeMillis();
        String response = get(BASE_URL + "/collect/list?limit=20", TOKEN);
        long elapsed = System.currentTimeMillis() - start;
        
        if (!response.contains("\"success\":true"))
            throw new Exception("collect/list失败");
        
        if (response.contains("\"records\":[]"))
            throw new Exception("records为空 - BUG未修复！");
        
        int recordsStart = response.indexOf("\"records\":[");
        int recordsEnd = response.indexOf("]", recordsStart);
        String recordsStr = response.substring(recordsStart, recordsEnd + 1);
        
        int recordCount = countOccurrences(recordsStr, "{");
        
        System.out.println("[PASS] 返回记录数: " + recordCount);
        System.out.println("[PASS] 查询耗时: " + elapsed + "ms");
        
        if (recordCount == 0)
            System.out.println("[WARN] 没有数据，请检查数据库");
        
        if (elapsed > 3000)
            System.out.println("[WARN] 查询耗时过长，建议优化");
    }
    
    private static void testCollectSummary() throws Exception
    {
        System.out.println("\n[TEST] collect/summary测试...");
        
        long start = System.currentTimeMillis();
        String response = get(BASE_URL + "/collect/summary", TOKEN);
        long elapsed = System.currentTimeMillis() - start;
        
        if (!response.contains("\"success\":true"))
            throw new Exception("collect/summary失败");

        if (!response.contains("\"totalRecords\""))
            throw new Exception("collect/summary缺少totalRecords");

        if (!response.contains("\"statusDistribution\""))
            throw new Exception("collect/summary缺少statusDistribution");

        System.out.println("[PASS] summary接口正常");
        System.out.println("[PASS] 查询耗时: " + elapsed + "ms");
    }
    
    private static String get(String urlStr, String token) throws Exception
    {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "Bearer " + token);
        
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null)
        {
            response.append(line);
        }
        reader.close();
        
        return response.toString();
    }
    
    private static String post(String urlStr, String json, String token) throws Exception
    {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        if (token != null)
            conn.setRequestProperty("Authorization", "Bearer " + token);
        conn.setDoOutput(true);
        
        OutputStream os = conn.getOutputStream();
        os.write(json.getBytes(StandardCharsets.UTF_8));
        os.close();
        
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null)
        {
            response.append(line);
        }
        reader.close();
        
        return response.toString();
    }
    
    private static int countOccurrences(String str, String sub)
    {
        int count = 0;
        int idx = 0;
        while ((idx = str.indexOf(sub, idx)) != -1)
        {
            count++;
            idx += sub.length();
        }
        return count;
    }
}
