package bap.opm.test;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import com.leavay.dfc.gui.LvUtil;

import cell.cdao.IDao;
import cell.cdao.IDaoService;

/**
 * PG数据库死锁和长时SQL生成器
 * 
 * 功能：
 * 1. 产生真实的数据库死锁
 * 2. 产生长时SQL
 * 3. 被强制终止时自动清理资源
 * 
 * 使用方法：
 * - 通过JavaTool远程执行: bap.opm.test.PgDeadlockGenerator.main(new String[]{"60"})
 * - 参数: 运行时长(秒)，默认60秒
 */
public class PgDeadlockGenerator
{
    private static final String TEST_TABLE1 = "opm_test_deadlock_t1";
    private static final String TEST_TABLE2 = "opm_test_deadlock_t2";

    private final AtomicBoolean running = new AtomicBoolean(true);
    private final AtomicInteger deadlockCount = new AtomicInteger(0);
    private final AtomicInteger longSqlCount = new AtomicInteger(0);

    public static void main(String[] args)
    {
        PgDeadlockGenerator generator = new PgDeadlockGenerator();
        generator.run(args);
    }

    public void run(String[] args)
    {
        int durationSec = 60;
        if (args != null && args.length > 0)
        {
            try
            {
                durationSec = Integer.parseInt(args[0]);
            }
            catch (NumberFormatException e)
            {
                LvUtil.trace("无效的参数，使用默认时长: " + durationSec + "秒");
            }
        }

        LvUtil.trace("========================================");
        LvUtil.trace("PG死锁和长时SQL生成器");
        LvUtil.trace("========================================");
        LvUtil.trace("运行时长: " + durationSec + "秒");
        LvUtil.trace("警告: 此程序会产生真实的死锁，仅用于测试!");
        LvUtil.trace("========================================");
        LvUtil.trace("");

        Runtime.getRuntime().addShutdownHook(new Thread("ShutdownHook")
        {
            @Override
            public void run()
            {
                shutdown();
            }
        });

        try
        {
            prepareTestTables();

            long startTime = System.currentTimeMillis();
            long endTime = startTime + durationSec * 1000L;

            while (running.get() && System.currentTimeMillis() < endTime)
            {
                generateDeadlock();
                generateLongSql();

                long elapsed = (System.currentTimeMillis() - startTime) / 1000;
                LvUtil.trace(String.format("[%02d秒] 死锁: %d次, 长时SQL: %d次", elapsed, deadlockCount.get(), longSqlCount.get()));

                Thread.sleep(1000);
            }

            LvUtil.trace("");
            LvUtil.trace("========================================");
            LvUtil.trace("测试完成");
            LvUtil.trace("总死锁次数: " + deadlockCount.get());
            LvUtil.trace("总长时SQL次数: " + longSqlCount.get());
            LvUtil.trace("========================================");

        }
        catch (Exception e)
        {
            LvUtil.trace("ERROR: " + e.getMessage());
            e.printStackTrace();
        }
        finally
        {
            shutdown();
        }
    }

    protected void prepareTestTables() throws Exception
    {
        LvUtil.trace("[准备] 创建测试表...");

        try (IDao dao = IDaoService.newIDao())
        {
            dao.queryFirst("DROP TABLE IF EXISTS " + TEST_TABLE1, null, null);
            dao.queryFirst("DROP TABLE IF EXISTS " + TEST_TABLE2, null, null);

            dao.queryFirst("CREATE TABLE " + TEST_TABLE1 + " (id INT PRIMARY KEY, value VARCHAR(100))", null, null);
            dao.queryFirst("CREATE TABLE " + TEST_TABLE2 + " (id INT PRIMARY KEY, value VARCHAR(100))", null, null);

            dao.queryFirst("INSERT INTO " + TEST_TABLE1 + " VALUES (1, 't1-row1'), (2, 't1-row2')", null, null);
            dao.queryFirst("INSERT INTO " + TEST_TABLE2 + " VALUES (1, 't2-row1'), (2, 't2-row2')", null, null);

            dao.commit();
            LvUtil.trace("[准备] 测试表创建完成");
        }
    }

    protected void generateDeadlock()
    {
        Thread t1 = new Thread("DeadlockT1")
        {
            @Override
            public void run()
            {
                try (IDao dao = IDaoService.newIDao())
                {
                    dao.queryFirst("UPDATE " + TEST_TABLE1 + " SET value = value || '-l1' WHERE id = 1", null, null);
                    Thread.sleep(100);
                    dao.queryFirst("UPDATE " + TEST_TABLE2 + " SET value = value || '-l1' WHERE id = 1", null, null);
                    dao.commit();
                }
                catch (Exception e)
                {
                    if (e.getMessage() != null && e.getMessage().contains("deadlock"))
                    {
                        deadlockCount.incrementAndGet();
                        LvUtil.trace("[死锁] T1检测到死锁!");
                    }
                }
            }
        };

        Thread t2 = new Thread("DeadlockT2")
        {
            @Override
            public void run()
            {
                try (IDao dao = IDaoService.newIDao())
                {
                    dao.queryFirst("UPDATE " + TEST_TABLE2 + " SET value = value || '-l2' WHERE id = 1", null, null);
                    Thread.sleep(100);
                    dao.queryFirst("UPDATE " + TEST_TABLE1 + " SET value = value || '-l2' WHERE id = 1", null, null);
                    dao.commit();
                }
                catch (Exception e)
                {
                    if (e.getMessage() != null && e.getMessage().contains("deadlock"))
                    {
                        deadlockCount.incrementAndGet();
                        LvUtil.trace("[死锁] T2检测到死锁!");
                    }
                }
            }
        };

        t1.start();
        t2.start();

        try
        {
            t1.join(2000);
            t2.join(2000);
        }
        catch (InterruptedException e)
        {
        }
    }

    protected void generateLongSql()
    {
        try (IDao dao = IDaoService.newIDao())
        {
            dao.queryFirst("SELECT pg_sleep(3)", null, null);
            dao.commit();
            longSqlCount.incrementAndGet();
            LvUtil.trace("[长时SQL] 执行完成 (pg_sleep 3秒)");
        }
        catch (Exception e)
        {
            LvUtil.trace("[错误] 长时SQL异常: " + e.getMessage());
        }
    }

    protected void shutdown()
    {
        if (!running.compareAndSet(true, false))
            return;

        LvUtil.trace("");
        LvUtil.trace("[清理] 开始清理资源...");

        try (IDao dao = IDaoService.newIDao())
        {
            dao.queryFirst("DROP TABLE IF EXISTS " + TEST_TABLE1, null, null);
            dao.queryFirst("DROP TABLE IF EXISTS " + TEST_TABLE2, null, null);
            dao.commit();
            LvUtil.trace("[清理] 测试表已删除");
        }
        catch (Exception e)
        {
            LvUtil.trace("[清理] 清理测试表失败: " + e.getMessage());
        }

        LvUtil.trace("[清理] 资源清理完成");
    }
}