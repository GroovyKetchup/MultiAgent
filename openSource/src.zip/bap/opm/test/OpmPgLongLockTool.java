package bap.opm.test;

import java.util.LinkedHashMap;

import com.leavay.common.util.GsonUtil;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dfc.gui.LvUtil;

import cell.cdao.IDao;
import cell.cdao.IDaoService;

/**
 * PG 长时锁制造工具。
 *
 * <pre>
 * 与 OpmPgDeadlockTool 的差异：
 * 1. OpmPgDeadlockTool 的目标是制造“真实死锁”，它会先分别持有两边的锁，再交叉更新，最终依赖 PG 自身死锁检测器来判定 deadlock。
 * 2. 本工具的目标不是制造死锁，而是稳定制造“长时间持锁”的单会话现场，用于验证 OPM 的长时锁监控逻辑。
 * 3. 本工具只会让一个事务长时间持有锁，不会主动制造互相等待，因此更适合验证“长时锁监控”而不是“死锁监控”。
 *
 * 使用场景：
 * - 验证 PG 长时锁监控是否能识别同一事务/同一会话持续持锁；
 * - 验证 stableKey 去噪策略是否能区分“同一会话持续占锁”和“相同 SQL 被不同会话重复执行”；
 * - 验证详情中是否能保留关联 SQL、会话、表名、事务年龄等排查信息。
 *
 * 调用样例：
 * - OpmPgLongLockTool.main(new String[]{"120", "2", "1"});
 *   含义：持锁 120 秒，锁住 2 行，每行只开 1 个长事务。
 *
 * 参数说明：
 * args[0]：持锁秒数，默认 120
 * args[1]：锁数量（行数），默认 2
 * args[2]：并发会话数，默认 1
 * </pre>
 */
public class OpmPgLongLockTool
{
    protected static final String TABLE = "opm_tool_long_lock";

    public static void main(String[] args)
    {
        OpmPgLongLockTool tool = new OpmPgLongLockTool();
        try
        {
            tool.run(args);
        }
        catch (Throwable err)
        {
            LvUtil.trace("[FATAL] " + err.getMessage());
            err.printStackTrace();
            throw new RuntimeException(err);
        }
    }

    public String run(String[] args) throws Exception
    {
        int holdSec = parseInt(args, 0, 120);
        int lockCount = parseInt(args, 1, 2);
        int sessions = parseInt(args, 2, 1);
        if (holdSec <= 0)
            holdSec = 120;
        if (lockCount <= 0)
            lockCount = 2;
        if (sessions <= 0)
            sessions = 1;

        prepareTable(lockCount);

        final int finalHoldSec = holdSec;
        final int finalLockCount = lockCount;
        Thread[] arr = new Thread[sessions];
        for (int i = 0; i < sessions; i++)
        {
            final int sessionNo = i + 1;
            arr[i] = new Thread("LongLock-" + sessionNo)
            {
                @Override
                public void run()
                {
                    holdLongLock(sessionNo, finalHoldSec, finalLockCount);
                }
            };
            arr[i].start();
            Thread.sleep(300L);
        }

        for (Thread one : arr)
            if (one != null)
                one.join(holdSec * 1000L + 5000L);

        cleanupTable();

        LinkedHashMap<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("tool", "OpmPgLongLockTool");
        out.put("holdSec", Integer.valueOf(holdSec));
        out.put("lockCount", Integer.valueOf(lockCount));
        out.put("sessions", Integer.valueOf(sessions));
        String json = GsonUtil.toJson(out);
        LvUtil.trace("[RESULT]" + json);
        return json;
    }

    protected void prepareTable(int rowCount) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            dao.queryFirst("DROP TABLE IF EXISTS " + TABLE, null, null);
            dao.queryFirst("CREATE TABLE " + TABLE + " (id INT PRIMARY KEY, value VARCHAR(128))", null, null);
            for (int i = 1; i <= rowCount; i++)
                dao.queryFirst("INSERT INTO " + TABLE + " VALUES (" + i + ", 'lock-" + i + "')", null, null);
            dao.commit();
            LvUtil.trace("[PREPARE] table ready, rows=" + rowCount);
        }
    }

    protected void cleanupTable() throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            dao.queryFirst("DROP TABLE IF EXISTS " + TABLE, null, null);
            dao.commit();
            LvUtil.trace("[CLEANUP] table dropped");
        }
    }

    protected void holdLongLock(int sessionNo, int holdSec, int lockCount)
    {
        try (IDao dao = IDaoService.newIDao())
        {
            for (int id = 1; id <= lockCount; id++)
            {
                dao.queryFirst("UPDATE " + TABLE + " SET value = value || '-s" + sessionNo + "' WHERE id = " + id, null, null);
                LvUtil.trace("[LOCK] session=" + sessionNo + ", rowId=" + id + ", table=" + TABLE);
            }

            LvUtil.trace("[HOLD] session=" + sessionNo + ", holdSec=" + holdSec + ", rowCount=" + lockCount + ", note=将持续占锁但不交叉等待");
            Thread.sleep(holdSec * 1000L);
            dao.commit();
            LvUtil.trace("[COMMIT] session=" + sessionNo + ", released");
        }
        catch (Throwable err)
        {
            LvUtil.trace("[ERROR] session=" + sessionNo + ", msg=" + err.getMessage());
        }
    }

    protected int parseInt(String[] args, int index, int defaultValue)
    {
        if (args == null || index < 0 || index >= args.length)
            return defaultValue;
        return ToolUtilities.getInteger(args[index], defaultValue);
    }
}
