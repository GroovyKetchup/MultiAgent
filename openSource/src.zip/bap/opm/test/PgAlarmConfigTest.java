package bap.opm.test;

import com.leavay.dfc.gui.LvUtil;

import bap.opm.collector.pg.OpmPgConst;

/**
 * PG告警配置测试类
 * 
 * 测试目的：确保告警阈值配置正确加载，避免AlarmLevelConfig构造函数遗漏字段赋值
 */
public class PgAlarmConfigTest
{
    private int passCount = 0;
    private int failCount = 0;

    public static void main(String[] args)
    {
        PgAlarmConfigTest test = new PgAlarmConfigTest();
        test.runAllTests();
    }

    public void runAllTests()
    {
        LvUtil.trace("========================================");
        LvUtil.trace("PG告警配置测试");
        LvUtil.trace("========================================");
        LvUtil.trace("");

        testSpaceThresholds();
        testConnThresholds();
        testLockThresholds();
        testReplicationThresholds();
        testSqlThresholds();

        LvUtil.trace("");
        LvUtil.trace("========================================");
        LvUtil.trace("测试结果: 通过 " + passCount + ", 失败 " + failCount);
        LvUtil.trace("========================================");

        if (failCount > 0)
        {
            LvUtil.trace("[FAIL] 存在失败的测试!");
        }
        else
        {
            LvUtil.trace("[PASS] 所有测试通过!");
        }
    }

    protected void testSpaceThresholds()
    {
        LvUtil.trace("[TEST] 空间使用率阈值");

        double warn = OpmPgConst.getSpaceWarnRate();
        double minor = OpmPgConst.getSpaceMinorRate();
        double major = OpmPgConst.getSpaceMajorRate();
        double critical = OpmPgConst.getSpaceCriticalRate();

        LvUtil.trace("  warn=" + warn + ", minor=" + minor + ", major=" + major + ", critical=" + critical);

        if (warn <= 0 || minor <= 0 || major <= 0 || critical <= 0)
        {
            LvUtil.trace("[FAIL] 阈值不能为0或负数");
            failCount++;
            return;
        }

        if (warn >= minor || minor >= major || major >= critical)
        {
            LvUtil.trace("[FAIL] 阈值必须递增: warn < minor < major < critical");
            failCount++;
            return;
        }

        if (critical > 1.0)
        {
            LvUtil.trace("[FAIL] critical阈值不能超过1.0 (100%)");
            failCount++;
            return;
        }

        LvUtil.trace("[PASS]");
        passCount++;
    }

    protected void testConnThresholds()
    {
        LvUtil.trace("[TEST] 连接使用率阈值");

        double warn = OpmPgConst.getConnWarnRate();
        double minor = OpmPgConst.getConnMinorRate();
        double major = OpmPgConst.getConnMajorRate();
        double critical = OpmPgConst.getConnCriticalRate();

        LvUtil.trace("  warn=" + warn + ", minor=" + minor + ", major=" + major + ", critical=" + critical);

        if (warn <= 0 || minor <= 0 || major <= 0 || critical <= 0)
        {
            LvUtil.trace("[FAIL] 阈值不能为0或负数");
            failCount++;
            return;
        }

        if (warn >= minor || minor >= major || major >= critical)
        {
            LvUtil.trace("[FAIL] 阈值必须递增: warn < minor < major < critical");
            failCount++;
            return;
        }

        if (critical > 1.0)
        {
            LvUtil.trace("[FAIL] critical阈值不能超过1.0 (100%)");
            failCount++;
            return;
        }

        LvUtil.trace("[PASS]");
        passCount++;
    }

    protected void testLockThresholds()
    {
        LvUtil.trace("[TEST] 长时锁时长阈值");

        int warn = OpmPgConst.getLockWarnSec();
        int minor = OpmPgConst.getLockMinorSec();
        int major = OpmPgConst.getLockMajorSec();
        int critical = OpmPgConst.getLockCriticalSec();

        LvUtil.trace("  warn=" + warn + "s, minor=" + minor + "s, major=" + major + "s, critical=" + critical + "s");

        if (warn <= 0 || minor <= 0 || major <= 0 || critical <= 0)
        {
            LvUtil.trace("[FAIL] 阈值不能为0或负数");
            failCount++;
            return;
        }

        if (warn >= minor || minor >= major || major >= critical)
        {
            LvUtil.trace("[FAIL] 阈值必须递增: warn < minor < major < critical");
            failCount++;
            return;
        }

        LvUtil.trace("[PASS]");
        passCount++;
    }

    protected void testReplicationThresholds()
    {
        LvUtil.trace("[TEST] 复制延迟阈值");

        int warn = OpmPgConst.getReplicationWarnSec();
        int minor = OpmPgConst.getReplicationMinorSec();
        int major = OpmPgConst.getReplicationMajorSec();
        int critical = OpmPgConst.getReplicationCriticalSec();

        LvUtil.trace("  warn=" + warn + "s, minor=" + minor + "s, major=" + major + "s, critical=" + critical + "s");

        if (warn <= 0 || minor <= 0 || major <= 0 || critical <= 0)
        {
            LvUtil.trace("[FAIL] 阈值不能为0或负数");
            failCount++;
            return;
        }

        if (warn >= minor || minor >= major || major >= critical)
        {
            LvUtil.trace("[FAIL] 阈值必须递增: warn < minor < major < critical");
            failCount++;
            return;
        }

        LvUtil.trace("[PASS]");
        passCount++;
    }

    protected void testSqlThresholds()
    {
        LvUtil.trace("[TEST] SQL时长阈值");

        int warn = OpmPgConst.getSqlWarnSec();
        int minor = OpmPgConst.getSqlMinorSec();
        int major = OpmPgConst.getSqlMajorSec();
        int critical = OpmPgConst.getSqlCriticalSec();

        LvUtil.trace("  warn=" + warn + "s, minor=" + minor + "s, major=" + major + "s, critical=" + critical + "s");

        if (warn <= 0 || minor <= 0 || major <= 0 || critical <= 0)
        {
            LvUtil.trace("[FAIL] 阈值不能为0或负数");
            failCount++;
            return;
        }

        if (warn >= minor || minor >= major || major >= critical)
        {
            LvUtil.trace("[FAIL] 阈值必须递增: warn < minor < major < critical");
            failCount++;
            return;
        }

        LvUtil.trace("[PASS]");
        passCount++;
    }
}
