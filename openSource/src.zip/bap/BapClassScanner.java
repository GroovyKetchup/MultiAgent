package bap;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import com.leavay.common.util.MppContext;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassInfoScanner;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.ClassInfoScanner.BasiceClassInfoLoaderEx;
import com.leavay.common.util.javac.ClassInfoScanner.ScanFilter;

import bap.plugin.mgr.CPluginClient;
import bap.plugin.mgr.CPluginFollower;
import cmn.util.AutoLock;
import cmn.util.Nulls;

/**
 * 系统启动时，可以自动加载jvm所带的基础类扫描器
 *
 */
public class BapClassScanner
{
    public final static String CONF_DISABLE_PRELOAD_SYS_SCANNER = "sys.class.pre.scan.disable";
    
    public final static String CONF_ENABLE_SCAN_JAVA_HOME_CLASSES = "scan.java.home.classes.enable"; // JVM扫描器默认不扫描JAVA_HOME目录下的任何jar
    
    private static volatile BapClassScanner _me;
    public synchronized static BapClassScanner get() throws IOException
    {
        if (_me == null)
        {
            _me = new BapClassScanner();
        }
        
        return _me;
    }
    
    ClassInfoScanner _jvmScanner;
    private BapClassScanner() throws IOException
    {
        ScanFilter filterNoPlugin = new ScanFilter(){
            public boolean handleLvLoader()
            {
                return false;
            }
            
            public boolean processFile(File file) throws IOException
            {
                String cnnPath = file.getCanonicalPath();
                // 手工排除插件目录（避免污染
                if (cnnPath.indexOf(CPluginClient.LIB_PLUGIN_ROOT) >= 0 
                        || cnnPath.indexOf(CPluginClient.LIB_PLUGIN_EXT_ROOT) >= 0 
                        || cnnPath.indexOf(CPluginFollower.LIB_PLUGIN_ROOT) >= 0)
                    return false;
                
                boolean scanJavaHome = MppContext.getBoolean(CONF_ENABLE_SCAN_JAVA_HOME_CLASSES, false);
                if (!scanJavaHome)
                {
                    // 如果不扫描JAVA_HOME，需要做判断进行排除
                    String jdkPath = ToolUtilities.getRelatedPath(cnnPath, ToolUtilities.getJavaHome());
                    if (Nulls.isNotEmpty(jdkPath)) // 忽略非工程启动目录中加载的jar，也就是忽略jdk自身的jar
                        return false;
                }
                
                return super.processFile(file);
            }
        };
        
        long start = System.currentTimeMillis();
        _jvmScanner = ClassInfoScanner.build(filterNoPlugin).scanUrlLoader(null, ClassFactory.getValidClassLoader());
        
        // 补充扫描class_path里的class文件
        ScanFilter filterClass = new ScanFilter() {
            public boolean acceptJarZipFile(File jarZipFile)
            {
                return false;
            }
        };
        ClassInfoScanner.build(filterClass).setLoader(_jvmScanner.getLoader()).scanJvmClassPath(null);
        
        ToolUtilities.infoAndOutput(getClass().getSimpleName(), "Finish scan system class info : " + (System.currentTimeMillis()-start)+"ms = " + _jvmScanner.getLoader().getAll().size());
    }
    
    public ClassInfoScanner getJvmScanner()
    {
        return _jvmScanner;
    }

    public BasiceClassInfoLoaderEx cloneJvmLoader()
    {
        return ToolUtilities.cloneEx(getJvmScanner().getLoader());
    }

    public static void lazyInit()
    {
        if (_me == null)
        {
            Thread thread = new Thread("Init System Class Scanner")
            {
                public void run()
                {
                    try
                    {
                        get();
                    } catch (IOException exp)
                    {
                        ToolUtilities.error(getName(), "Failed to init system class scanner", exp);
                    }
                }
            };
            thread.setPriority(Thread.MIN_PRIORITY);
            thread.start();
        }
    }
    

    public static ClassInfoScanner build(ScanFilter filter) throws IOException
    {
        return build(filter, false);
    }
    /**
     * 构建基于系统扫描结果的信息搜集器，同时对过滤器注入系统扫描历史记录，避免重复扫描
     * 
     * @param filter
     * @param clearRecords 是否要先删掉传入的过滤器中的扫描记录，如果是二次扫描的通常不需要清理
     */
    public static ClassInfoScanner build(ScanFilter filter, boolean clearRecords) throws IOException
    {
        filter.copyFileRecords(get().getJvmScanner().getFilter(), clearRecords);
        return ClassInfoScanner.build(filter, get().cloneJvmLoader());
    }
    

    static ReentrantLock _lcClassScanner = new ReentrantLock();
    static long _lastScanTag = -1;
    static ClassInfoScanner _pluginScanner;
    public static ClassInfoScanner prepareClassInfoScanner()
    {
        try (AutoLock lc = AutoLock.lock(_lcClassScanner))
        {
            if (_pluginScanner == null || ClassFactory.getCurrentPluginTag() != _lastScanTag)
            {
                try
                {
                    _lastScanTag = ClassFactory.getCurrentPluginTag();
                    _pluginScanner = BapClassScanner.build(new ScanFilter());
                    _pluginScanner.scanUrlLoader(null, ClassFactory.getValidClassLoader());
                } catch (IOException exp)
                {
                    ToolUtilities.fatal("BapClassScanner", "Failed to load class info scanner", exp);
                    _lastScanTag = -1;
                    _pluginScanner = null;
                    ToolUtilities.throwRuntimeException(exp);
                }
            }
            
            return _pluginScanner;
        }
    }

    // 在给定的classloader中扫描指定的类的子类（较慢）
    public static Map<String, ClassNameInfo> searchSubClassInfo(String superClass) throws IOException
    {
        return prepareClassInfoScanner().getLoader().searchSubClass(superClass);
        
//        ScanFilter filter = new ScanFilter().setPkgs(pkgs);
//        ClassInfoScanner scanner = SysClassScanner.build(filter).scanUrlLoader(null, classLoaders);
////        ClassInfoScanner scanner = ClassInfoScanner.build(filter).scanUrlLoader(null, classLoaders);
//        
////        //补充扫描class_path中的.class文件夹，专用于Eclipse调试加载自身临时编译路径下的class文件，例如: Eclipse_Temp/com/some/Aaaaa.class
////        ScanFilter filterClass = new ScanFilter() {
////            public boolean acceptJarZipFile(File jarZipFile)
////            {
////                return false;
////            }
////        }.setPkgs(pkgs);
////        ClassInfoScanner.build(filterClass, scanner.getLoader()).scanJvmClassPath(null); // 叠加扫描
//        return scanner.getLoader().searchSubClass(superClass);
    }

}
