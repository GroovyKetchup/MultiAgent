package bap.client;

public class BapGuiConst
{
    public static String SEARCH_TEXT_IN_CJAVA_CODE = "SEARCH_TEXT_IN_CJAVA_CODE"; // String projectUuid, String text
    
    public static String SHOW_JAVA_DECLARATION = "SHOW_JAVA_DECLARATION"; // param0 : codeUuid, param1 : CodeDeclareInfo
    public static String SELECT_CJAVA_CODE = "SELECT_CJAVA_CODE"; // param0 : javaRDN, param1 : IntRange
    public static String SHOW_CJAVA_LINE = "SHOW_CJAVA_LINE"; // param0 : javaRDN, param1 : lineNum
    
    public static String JAVA_CODE_SAVED = "JAVA_CODE_SAVED";// param0 : CJavaCode
    
    public static String SHOW_CJAVA_CODE_IN_TREE = "SHOW_CJAVA_CODE_IN_TREE"; // param0 : path(String[]，从工程UUID开始/目录UUID/包名/代码UUID) 
}
