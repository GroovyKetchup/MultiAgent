package bap.client;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.net.URI;
import java.util.concurrent.locks.ReentrantLock;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JSplitPane;
import javax.swing.event.DocumentEvent;

import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoUtil;
import com.leavay.client.util.CNClientUtil;
import com.leavay.client.util.MBox;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;

import bap.gui.BasicNioFrame;
import bap.java.CJavaCode;
import bap.java.CJavaConst;
import bap.java.CJavaEditor;
import cmn.util.AutoLock;
import tiny.service.client.TsClient;
import tiny.service.client.OpmClient;

public class BapJavaTool extends BasicNioFrame
{


    public BapJavaTool()
    {
        super();
        
        initCodePanel();
    }
    

    final static String _cacheCodeFile = "_bap_gui_cache_java_tool.java";
    public final static String DEFAULT_JAVA_TOOL_CODE = "package com.debug.tool;\n\npublic class JavaTool{\n\n    public static void main(){\n\n    }\n}";
    static ReentrantLock _lcCacheCode =new ReentrantLock();
    public static String getCacheCode()
    {
        try (AutoLock lc = AutoLock.lock(_lcCacheCode))
        {
            String code = ToolUtilities.readFileUtf8(_cacheCodeFile);
            return CmnUtil.isStringEmpty(code) ? DEFAULT_JAVA_TOOL_CODE : code;
        } catch (Throwable err)
        {
            return DEFAULT_JAVA_TOOL_CODE;
        }
    }
    
    public static void saveCacheCode(String code)
    {
        try (AutoLock lc = AutoLock.lock(_lcCacheCode))
        {
            ToolUtilities.saveFileUtf8(_cacheCodeFile, code, false);
        } catch (Throwable exp)
        {
            exp.printStackTrace();
        }
    }

    
    public void initCodePanel()
    {
        CJavaEditor editor = new CJavaEditor();
        CJavaCode code = new CJavaCode();
        code.setProjectUuid(CJavaConst.SYSTEM_PROJECT_UUID);
        code.setUuid(CDaoUtil.allocUuid());
        code.setJavaPackage("com.debug.tool");
        code.setMainClass("JavaTool");
        code.setCode(getCacheCode());
        editor.showCode(code);
       
        JButton btnDebug = new JButton("Debug To(F10)", GuiResource.getIcon("start_16.png"));
        btnDebug.addActionListener(new ActionAdapter()
        {
            @Override
            public void OnAction(ActionEvent e) throws Exception
            {
                editor.startDebug(true);
            }
        });
        JButton btnDebugOnCenter = new JButton("Center Debug(F9)", GuiResource.getIcon("next_disabled.gif"));
        btnDebug.addActionListener(new ActionAdapter()
        {
            @Override
            public void OnAction(ActionEvent e) throws Exception
            {
                editor.startDebugOnCenter();
            }
        });
        GuiUtil.addDocumentListener(editor.getCodePanel(), (DocumentEvent e)->{
            saveCacheCode(editor.getCode());
        });

        Box boxMain = MBox.createVBar(MBox.hBar(22, btnDebug, btnDebugOnCenter, MBox.HGlue()));
        boxMain.add(editor);
        JSplitPane spl = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, boxMain, (Component) openView(ACT_CMD_VIEW_CONSOLE));
        spl.setDividerLocation(650);
        
        setContentPane(spl);
    }

    public static void connectServer(URI uri) throws Exception
    {
        BapClient.getMe().init(uri, false);
        
        CDaoClient.getMe().initGuiClient(uri).init();
        CDaoClient.getMe().setCRpcCodecAsMe();
        
        try
        {
            TsClient.getMe().init(CNClientUtil.getUri());
            OpmClient.getMe().init(CNClientUtil.getUri());
            TsClient.getIntf().ping();
        } catch (Throwable err)
        {
            err.printStackTrace();
        }
    }

    protected void initMenuBar()
    {
    }
    
    public void showMainFrame()
    {
        CNClientUtil.setTopoWindow(this);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(1204, 960)); //原来的1440-968在Mac机上会很大，这里适当调小
        pack();
        GuiUtil.centerWindow(this);
        setVisible(true);
    }
    
    private static final long serialVersionUID = -3699872175982821556L;
    public static void main(String[] args) throws Exception
    {
        GuiUtil.setLookAndFeel_JTattoo();

        CmnUtil.out("Arguments:" + ToolUtilities.logString(args, false));
        CmnUtil.out(ToolUtilities.logString(System.getProperties(), true));
        

        // 参数样例 ：wss://develop.kwaidoo.com 8443 store 
        if (!CmnUtil.isObjectEmpty(args) && args.length >= 2)
        {
            String host = ToolUtilities.getString(args[0]);
            int port  = ToolUtilities.getInteger(args[1]);
            
            CNClientUtil.setBEHost(host);
            CNClientUtil.setNioPort(port);
            if (args.length >= 3)
            {
                CNClientUtil.setPath(ToolUtilities.getString(args[2]));
            }
            
            // 连接服务器，初始化各种远程连接
            connectServer(CNClientUtil.getUri());
        }else
        {
            CmnUtil.err("Invalid param format. Example : wss://develop.kwaidoo.com 8443 store ");
            System.exit(0);
            return;
        }
        
        // 由main入口的，都是独立进程
        BapJavaTool frm = new BapJavaTool();
        frm.setIconImage(GuiResource.getImage("dev/debug_remote.png"));
        frm.setTitle("Java Debug Tool : " + CNClientUtil.getUri());
        frm.showMainFrame();
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
