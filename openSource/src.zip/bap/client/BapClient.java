package bap.client;

import java.awt.Component;
import java.net.URI;
import java.util.concurrent.locks.ReentrantLock;

import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CSession;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.BasicLoaderChangeListener;
import com.leavay.common.util.javac.CodeUtil;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;

import bap.cells.CellClientFactory;
import bap.java.CJavaCenterIntf;
import bap.opm.OpmCenterService;
import bap.plugin.mgr.CPluginClient;
import bap.yun.YunStoreAgent;
import cmn.security.dto.UserPassword;
import cmn.util.AutoLock;
import cmn.util.Nulls;
import cplugin.ms.CPluginCenterService;
import gui.cmn.component.JUserInputPanel;

public class BapClient
{
    protected CRpcClientWrapper<CPluginCenterService> _intfPluginCenter = new CRpcClientWrapper<CPluginCenterService>(CPluginCenterService.class)
    {
        public CRpcAdapter getAdapter()
        {
            // 基于CDao的通讯通道，来获取远程接口
            return getRpcAdapter();
        }
    };
    
    protected CRpcClientWrapper<CJavaCenterIntf> _intfJava = new CRpcClientWrapper<CJavaCenterIntf>(CJavaCenterIntf.class)
    {
        public CRpcAdapter getAdapter()
        {
            // 基于CDao的通讯通道，来获取远程接口
            return getRpcAdapter();
        }
    };

    protected CRpcClientWrapper<OpmCenterService> _intfOpm = new CRpcClientWrapper<OpmCenterService>(OpmCenterService.class)
    {
        public CRpcAdapter getAdapter()
        {
            // 基于CDao的通讯通道，来获取远程接口
            return getRpcAdapter();
        }
    };
    
    public CRpcAdapter getRpcAdapter()
    {
        // 就用一个全局的
        return CRpcAdapter.getInstance();
        // 基于CDao的通讯通道，来获取远程接口
//        return CDaoClient.getMe().getRpcAdapter();
    }
    
    private static BapClient _me;
    public synchronized static BapClient getMe()
    {
        if (_me ==null)
            _me = new BapClient();
        
        return _me;
    }
    
    public URI getUri()
    {
        return getRpcAdapter().getClient().getUri();
    }
    
    protected BapClient()
    {
    }
    
    public void init(URI uri, boolean startAutoUpgradPlugin) throws Exception
    {
        synchronized (this)
        {
            _intfPluginCenter.init(uri);
            CPluginClient.getMe().initInClient(uri, startAutoUpgradPlugin);
            _intfJava.init(uri);

            try
            {
                _intfOpm.init(uri);
            }
            catch (Throwable err)
            {
                ToolUtilities.warning("BapClient", "Failed to init OPM rpc wrapper", err);
            }

            CellClientFactory.getMe().start(uri, false);
        }

        initYunStoreUri();
    }
    
    public static void initYunStoreUri()
    {
        try
        {
            String srvUri = getJavaIntf().getYunStoreUri();
            if (Nulls.isNotEmpty(srvUri))
                YunStoreAgent.initStoreUri(srvUri);
        }catch (Throwable err)
        {
            ToolUtilities.error(err);
        }
    }
    
    public static CPluginCenterService getPluginIntf()
    {
        return getMe()._intfPluginCenter.getIntf();
    }
    
    public static CJavaCenterIntf getJavaIntf()
    {
        return getMe()._intfJava.getIntf();
    }

    public static OpmCenterService getOpmIntf()
    {
        return getMe()._intfOpm.getIntf();
    }
    
    // 启动后在后台慢慢初始化所有类信息
    static {
        initAllMapClass();
    }
    
    protected static void initAllMapClass()
    {
        Thread initThread = new Thread("Init All Class Map")
        {
            public void run()
            {
                try
                {
                    ToolUtilities.sleep(10000);
                    CodeUtil.getInstance();
                    System.out.println("Succeed to init all class information.");
                } catch (Throwable err)
                {
                    err.printStackTrace();
                }
            }
        };

        initThread.setPriority(Thread.MIN_PRIORITY);
        initThread.start();
    }
    
    // 登录云仓库，默认只需要一次操作，后续只要不重启，都是他
    protected UserPassword _yunUser;
    protected CSession _yunSession;
    protected long _yunLoginTime;
    ReentrantLock _lcYunUser = new ReentrantLock();
    public UserPassword loginYunStore(Component parent) throws Exception
    {
        try (AutoLock lc = AutoLock.lock(_lcYunUser))
        {
            if (_yunUser == null)
            {
                UserPassword user = JUserInputPanel.showInputDialog(parent, null, BapGuiUtil.getString("Input User For Yun Store"));
                
                // 一旦登录成功，则缓存起来
                _yunSession = getJavaIntf().loginYunStore(user);
                _yunLoginTime = System.currentTimeMillis();
                _yunUser = user;
            }
        }
        
        return _yunUser;
    }

    public UserPassword getYunUser()
    {
        return _yunUser;
    }

    public CSession getYunSession()
    {
        return _yunSession;
    }

    public long getYunLoginTime()
    {
        return _yunLoginTime;
    }
    
}
