package bap.client;

import java.awt.Component;
import java.util.Locale;

import com.leavay.client.util.CNClientUtil;
import com.leavay.client.util.EventQ.GuiEvent;
import com.leavay.client.util.EventQ.GuiEventListener;
import com.leavay.common.BasicRes;
import com.leavay.dfc.SubjectView.gui.MainEditor.AbstractMoOpener;
import com.leavay.dfc.SubjectView.gui.MainEditor.EditorOpenerIntf;
import com.leavay.dfc.gui.AllGuiEvents;
import com.leavay.dfc.gui.dfcGuiUtil;
import com.project.gui.common.GuiUtil;
import com.vlsolutions.swing.docking.Dockable;

import bap.java.CJavaCode;
import bap.java.CJavaEditor;

public class BapGuiUtil
{
    // 默认编码：GBK
    private static BasicRes _res = new BasicRes("LanguageRes/bap_zh_CN.properties", "LanguageRes/bap_en_US.properties");
    
    public static String getString(String key)
    {
        return _res.getString(key);
    }
    
    public static String getString(String key, Object ... params)
    {
        return _res.getString(key, params);
    }
    
    public static void openCode(String pjUuid, String fullClassName) throws Exception
    {
        CJavaCode code = BapClient.getJavaIntf().getJavaCode(pjUuid, fullClassName);
        openCode(code);
    }

    public static void openCode(CJavaCode code)
    {
        openCode(code, false);
    }
    
    public static void openCode(CJavaCode code, boolean isNew)
    {
        AbstractMoOpener opener = new AbstractMoOpener(code.getKey())
        {
            public String getName()
            {
                return code.getMainClass();
            }

            public Dockable openNewEditor() throws Exception
            {
                CJavaEditor editorV = new CJavaEditor();
                editorV.setIsNew(isNew);
                
                if (false)
                    editorV.showCode(code);
                GuiUtil.invokeLater(editorV, "showCode", code);
                return editorV;
            }
        };

        fireOpenMainDockview(opener);
    }

    public static void fireOpenMainDockview(EditorOpenerIntf opener)
    {
        fireSyncGuiEvent(AllGuiEvents.OPEN_MAIN_EDITOR_TAB, opener);
    }
    
    public static void fireAsyncOpenMainDockview(EditorOpenerIntf opener)
    {
        fireAsyncGuiEvent(AllGuiEvents.OPEN_MAIN_EDITOR_TAB, opener);
    }

    public static void fireAsyncGuiEvent(GuiEvent evt)
    {
        dfcGuiUtil.fireAsyncGuiEvent(evt);
    }

    public static void fireAsyncGuiEvent2(String sKey1, String sKey2, Object... params)
    {
        dfcGuiUtil.fireAsyncGuiEvent2(sKey1, sKey2, params);
    }

    public static void fireAsyncGuiEvent(String sKey, Object... params)
    {
        dfcGuiUtil.fireAsyncGuiEvent(sKey, params);
    }

    public static void fireAsyncGuiEvent(String sKey)
    {
        dfcGuiUtil.fireAsyncGuiEvent(new GuiEvent(sKey));
    }

    public static void fireSyncGuiEvent(GuiEvent evt)
    {
        dfcGuiUtil.fireSyncGuiEvent(evt);
    }

    public static void fireSyncGuiEvent2(String sKey1, String sKey2, Object... params)
    {
        dfcGuiUtil.fireSyncGuiEvent2(sKey1, sKey2, params);
    }

    public static void fireSyncGuiEvent(String sKey, Object... params)
    {
        dfcGuiUtil.fireSyncGuiEvent(sKey, params);
    }

    public static void fireSyncGuiEvent(String sKey)
    {
        dfcGuiUtil.fireSyncGuiEvent(new GuiEvent(sKey));
    }

    public static void addListener(String key, GuiEventListener lsnr)
    {
        dfcGuiUtil.addListener(key, lsnr);
    }

    public static void addListener(String key, Component guiCmp, String sFunction)
    {
        dfcGuiUtil.addListener(key, guiCmp, sFunction);
    }

    public static void addListener(String key1, String key2, GuiEventListener lsnr)
    {
        dfcGuiUtil.addListener(key1, key2, lsnr);
    }

    public static void removeListener(String key, GuiEventListener lsnr)
    {
        dfcGuiUtil.removeListener(key, lsnr);
    }

    public static void removeGuiListenerOfComponent(Component cmp)
    {
        dfcGuiUtil.removeGuiListenerOfComponent(cmp);
    }

    public static void removeListener(String key1, String key2, GuiEventListener lsnr)
    {
        dfcGuiUtil.removeListener(key1, key2, lsnr);
    }
    
    public static void openDockable(EditorOpenerIntf opener)
    {
        dfcGuiUtil.fireAsyncGuiEvent(AllGuiEvents.OPEN_MAIN_EDITOR_TAB, opener);
    }
    
    public static void closeMainTabView(String dockKey, boolean isForceSilence)
    {
        dfcGuiUtil.fireAsyncGuiEvent(AllGuiEvents.CLOSE_MAIN_EDITOR_TAB, dockKey, isForceSilence);
    }
}
