package bap.client;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URI;
import java.util.concurrent.locks.ReentrantLock;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.event.DocumentEvent;

import com.cdao.dto.CPager;
import com.cdao.gui.CDaoFrame;
import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoUtil;
import com.cdao.model.type.Password;
import com.leavay.client.util.CNClientUtil;
import com.leavay.client.util.MBox;
import com.leavay.client.util.EventQ.GuiEvent;
import com.leavay.common.BasicRes;
import com.leavay.common.util.DetailErrorMsg;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dfc.gui.AllGuiEvents;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.mgr.javaDev.JPluginAgentMgr;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;
import com.project.gui.common.ActionAdapter;
import com.project.gui.common.GuiResource;
import com.project.gui.common.GuiUtil;
import com.project.gui.common.GuiUtil.JSimpleDialog;
import com.project.gui.common.LogReviewTool;
import com.vlsolutions.swing.docking.DockingConstants;

import bap.gui.BasicNioFrame;
import bap.java.CJavaClassSearchPanel;
import bap.java.CJavaCode;
import bap.java.CJavaConst;
import bap.java.CJavaEditor;
import bap.java.CJavaSyntaxRefTree;
import bap.md.yun.ArtifactWare;
import bap.opm.gui.OpmMainPanel;
import bap.plugin.gui.CDevelopPanel;
import bap.plugin.gui.yun.YunArtifactTablePanel;
import cell.bap.yun.ArtifactGraph;
import cell.bap.yun.IYunStore;
import cmn.security.dto.UserPassword;
import cmn.util.AutoLock;
import tiny.service.client.TsAgentMgrOpener;
import tiny.service.client.TsClient;
import tiny.service.client.OpmClient;
import tiny.service.client.TsRegTableOpener;
import tiny.service.track.gui.TsTrackPanel;

public class BapMainFrame extends BasicNioFrame
{

    public final static String ACT_CMD_VIEW_PLUGIN_VIEW = ACT_CMD_VIEW_PREFIX + "PLUGIN_VIEW";

    JMenuItem jMItem_DaoFrame;

    JMenuItem jMItem_PluginMgr;

    JMenuItem jMItem_JavaTool;

    JMenuItem jMItem_LogTool;
    
    JMenuItem jMItem_LocalStore;

    JMenuItem jMItem_TsRegMgr;

    JMenuItem jMItem_TsClusterMgr;

    JMenuItem jMItem_TsTrackCenter;

    JMenuItem jMItem_OpmMonitor;

    CJavaClassSearchPanel jSearchClassPanel = new CJavaClassSearchPanel();
    {
        jSearchClassPanel.setPreferredSize(new Dimension(750, 400));
    }

    JSimpleDialog jDlgSearchClass = GuiUtil.createSimpleDialog(jSearchClassPanel, this, GuiUtil.getTranslator(), true);

    public BapMainFrame()
    {
        super();

        setIconImage(GuiResource.getIcon("cdao/db.png").getImage());

    }

    protected void initMainPanel(String sLayout)
    {
        desktop.addDockable(openView(ACT_CMD_VIEW_MAIN_DEV_TAB_VIEW));

        desktop.split(openView(ACT_CMD_VIEW_MAIN_DEV_TAB_VIEW), openView(ACT_CMD_VIEW_PLUGIN_VIEW), DockingConstants.SPLIT_LEFT, (double) 0.25f);

        desktop.split(openView(ACT_CMD_VIEW_MAIN_DEV_TAB_VIEW), openView(ACT_CMD_VIEW_CONSOLE), DockingConstants.SPLIT_BOTTOM, (double) 0.75f);
    }

    protected void initViews() throws Exception
    {
        super.initViews();

        registView(ACT_CMD_VIEW_PLUGIN_VIEW, CDevelopPanel.class, "dfc/info_edit.png");
    }

    private static BasicRes _res = new BasicRes("LanguageRes/bap_zh_CN.properties", "LanguageRes/bap_en_US.properties");

    public static void main(String[] args) throws Exception
    {

        JPluginAgentMgr.setEnable(false);
        GuiUtil.setLookAndFeel_JTattoo();

        GuiUtil.setTranslator(_res);

        CmnUtil.out("Arguments:" + ToolUtilities.logString(args, false));
        CmnUtil.out(ToolUtilities.logString(System.getProperties(), true));

        CNClientUtil.setBEHost("127.0.0.1");
        CNClientUtil.setNioPort(2020);
//        CNClientUtil.setNioPort(13000);

        // 参数样例：wss://develop.kwaidoo.com 8443 store ck ck
        if (!CmnUtil.isObjectEmpty(args) && args.length >= 5)
        {
            String host = ToolUtilities.getString(args[0]);
            int port = ToolUtilities.getInteger(args[1]);
            String path = ToolUtilities.getString(args[2]);
            String user = ToolUtilities.getString(args[3]);
            String pwd = ToolUtilities.getString(args[4]);

            if (!logon(CmnUtil.buildWsUri(host, port, path), user, pwd))
            {
                System.exit(0);
                return;
            }
        } else
        {
            if (!logon())
            {
                System.exit(0);
                return;
            }
        }

        BapMainFrame frm = new BapMainFrame();
        frm.showMainFrame();
    }

    public static BapMainFrame showFrame(URI uri, String user, String pwd) throws Exception
    {
        JPluginAgentMgr.setEnable(false);
        System.out.println(ToolUtilities.logString(System.getProperties(), true));
        GuiUtil.setTranslator(_res);

        _logon(uri, user, pwd);

        BapMainFrame frm = new BapMainFrame();
        frm.showMainFrame();
        return frm;
    }

    boolean isMsCenter = true;

    public void initRemote() throws Exception
    {
        BapClient.getMe().init(CNClientUtil.getUri(), false);

        try
        {
            TsClient.getMe().init(CNClientUtil.getUri());
            OpmClient.getMe().init(CNClientUtil.getUri());
            TsClient.getIntf().ping();
            isMsCenter = true;
        } catch (Throwable err)
        {
            isMsCenter = false;
            err.printStackTrace();
        }
    }

    public void showMainFrame() throws Exception
    {
        super.showMainFrame();
    }

    public JMenu initMenu_Tools(JMenuBar bar)
    {
        JMenu jToolMenu = super.initMenu_Tools(bar);

        jMItem_DaoFrame = GuiUtil.createMenuItem("bap/db.png", "DAO Tool", this);
        jMItem_PluginMgr = GuiUtil.createMenuItem("dev/project_dsp.png", "Develop & Plugin", this);
        jMItem_JavaTool = GuiUtil.createMenuItem("dev/run_java.png", "Java Tool", this);
        jMItem_LogTool = GuiUtil.createMenuItem("log_16.png", dfcutil.getString("Log Tool"), this);
        jMItem_LocalStore = GuiUtil.createMenuItem("bap/searchStore.png", dfcutil.getString("Local Store Explorer"), this);

        jMItem_TsRegMgr = GuiUtil.createMenuItem("dfc/register.png", "Tiny Service Registry", this);
        jMItem_TsClusterMgr = GuiUtil.createMenuItem("dfc/server2.png", "Tiny Service Cluster Management", this);
        jMItem_TsTrackCenter = GuiUtil.createMenuItem("dfc/track.png", "Tiny Service Track Center", this);
        jMItem_OpmMonitor = GuiUtil.createMenuItem("dfc/track.png", "OPM 系统监控", this);
        jToolMenu.add(jMItem_DaoFrame);
        jToolMenu.add(jMItem_JavaTool);
        jToolMenu.add(jMItem_PluginMgr);
        jToolMenu.add(jMItem_LogTool);
        jToolMenu.add(jMItem_LocalStore);
        jToolMenu.addSeparator();
        jToolMenu.add(jMItem_TsRegMgr);
        jToolMenu.add(jMItem_TsClusterMgr);
        jToolMenu.add(jMItem_TsTrackCenter);
        jToolMenu.add(jMItem_OpmMonitor);

        return jToolMenu;
    }

    public boolean OnPostProcessKeyEvent(KeyEvent e)
    {
        if (super.OnPostProcessKeyEvent(e))
            return false;

        if (e.isControlDown() && e.isShiftDown() && e.getKeyCode() == KeyEvent.VK_T)
        {
            try
            {
                OnSearchJavaCode();
            } catch (Exception exp)
            {
                DetailErrorMsg.showError(this, exp);
            }
        }

        return false;
    }

    public void OnAction(ActionEvent e) throws Exception
    {
        super.OnAction(e);

        if (e.getSource() == jMItem_PluginMgr)
            OnPluginMgr();
        else if (e.getSource() == jMItem_JavaTool)
            showJavaTool();
        else if (e.getSource() == jMItem_LogTool)
            OnLogTool();
        else if (e.getSource() == jMItem_LocalStore)
            OnLocalStore();
        else if (e.getSource() == jMItem_DaoFrame)
            OnDaoFrame();
        else if (e.getSource() == jMItem_TsRegMgr)
            OnOpenTsRegTable();
        else if (e.getSource() == jMItem_TsClusterMgr)
            OnOpenTsClusterMgr();
        else if (e.getSource() == jMItem_TsTrackCenter)
            OnOpenTsTrackPanel();
        else if (e.getSource() == jMItem_OpmMonitor)
            OnOpenOpmMonitorPanel();
    }

    public void OnOpenTsClusterMgr()
    {
        if (!isMsCenter())
            return;

        BapGuiUtil.fireAsyncGuiEvent(AllGuiEvents.OPEN_MAIN_EDITOR_TAB, new TsAgentMgrOpener());
    }

    public void OnOpenTsRegTable()
    {
        if (!isMsCenter())
            return;

        BapGuiUtil.fireAsyncGuiEvent(AllGuiEvents.OPEN_MAIN_EDITOR_TAB, new TsRegTableOpener());
    }

    public void OnPluginMgr() throws Exception
    {
        desktop.split(openView(ACT_CMD_VIEW_MAIN_DEV_TAB_VIEW), openView(ACT_CMD_VIEW_PLUGIN_VIEW), DockingConstants.SPLIT_LEFT);
    }

    final static String _cacheCodeFile = "_bap_gui_cache_java_tool.java";
    public final static String DEFAULT_JAVA_TOOL_CODE = "package "+CJavaConst.SYS_DEBUG_JAVA_TOOL_PKG+";\n\npublic class "+CJavaConst.SYS_DEBUG_JAVA_TOOL_CLASS+"{\n\n    public static void main(){\n\n    }\n}";
    static ReentrantLock _lcCacheCode =new ReentrantLock();
    public static String getCacheCode(String file)
    {
        try (AutoLock lc = AutoLock.lock(_lcCacheCode))
        {
            String code = ToolUtilities.readFileUtf8(file);
            return CmnUtil.isStringEmpty(code) ? DEFAULT_JAVA_TOOL_CODE : code;
        } catch (Throwable err)
        {
            return DEFAULT_JAVA_TOOL_CODE;
        }
    }
    
    public static void saveCacheCode(String file, String code)
    {
        try (AutoLock lc = AutoLock.lock(_lcCacheCode))
        {
            ToolUtilities.saveFileUtf8(file, code, false);
        } catch (Throwable exp)
        {
            exp.printStackTrace();
        }
    }

    public static String getCacheCodePath()
    {
        String uri = BapClient.getMe().getUri().toASCIIString();
        return ToolUtilities.replaceAll(uri, ToolUtilities.array2Map(new String[][] {{"/","_"}, {":","__"}}))+".code";
    }

    public static void showJavaTool() throws Exception
    {
        String codeFile = getCacheCodePath(); 
        if (!ToolUtilities.isFileReadable(getCacheCodePath()))
            ToolUtilities.saveFileUtf8(codeFile, DEFAULT_JAVA_TOOL_CODE, false);
        
        showJavaTool(codeFile);
    }
    
    public static void showJavaTool(final String codeFile) throws Exception
    {
        CJavaEditor editor = new CJavaEditor();
        CJavaCode code = new CJavaCode();
        code.setProjectUuid(CJavaConst.SYSTEM_PROJECT_UUID);
        code.setUuid(CDaoUtil.allocUuid());
        code.setJavaPackage("com.debug.tool");
        code.setMainClass("JavaTool");
        code.setCode(getCacheCode(codeFile));
        editor.showCode(code);
        editor.setPreferredSize(new Dimension(1200, 440));
        JButton btnDebug = new JButton("Debug To(F10)", GuiResource.getIcon("start_16.png"));
        btnDebug.addActionListener(new ActionAdapter()
        {
            @Override
            public void OnAction(ActionEvent e) throws Exception
            {
                editor.startDebug(true);
            }
        });
        JButton btnDebugOnCenter = new JButton("Center Debug(F9)", GuiResource.getIcon("next_disabled.gif"));
        btnDebug.addActionListener(new ActionAdapter()
        {
            @Override
            public void OnAction(ActionEvent e) throws Exception
            {
                editor.startDebugOnCenter();
            }
        });
        GuiUtil.addDocumentListener(editor.getCodePanel(), (DocumentEvent e)->{
            saveCacheCode(codeFile, editor.getCode());
        });

        Box boxMain = MBox.createVBar(MBox.hBar(22, btnDebug, btnDebugOnCenter, MBox.HGlue()));
        boxMain.add(editor);

        JSimpleDialog dlg = GuiUtil.createSimpleDialog(boxMain);
        dlg.pack();
        dlg.showModel(false);
        dlg.setBounds(300, 100, 1200, 500);
            
    }

    public void OnDaoFrame() throws Exception
    {
        CDaoFrame frm = new CDaoFrame();
        frm.showMainFrame(false);
        frm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    protected void initGuiEvent()
    {
        super.initGuiEvent();

        BapGuiUtil.addListener(BapGuiConst.SEARCH_TEXT_IN_CJAVA_CODE, this, "OnSearchJavaCode");
    }

    public void OnSearchJavaCode(GuiEvent evt) throws Exception
    {
        CJavaSyntaxRefTree jRefPanel = new CJavaSyntaxRefTree();
        jRefPanel.OnEvtSearchTextInCode(evt);
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(jRefPanel);
        dlg.setIconImage(GuiResource.getImage("search.png"));
        dlg.setTitle("Search Text In Project");
        dlg.pack();
        dlg.showModel(false);

//        CJavaCode code = jClsPanel.getSelectCode();
//        if (code != null)
//            openCodeEditor(code);
    }

    public boolean isMsCenter()
    {
        return isMsCenter;
    }

    public void OnOpenTsTrackPanel() throws Exception
    {
        if (!isMsCenter())
            return;

        TsTrackPanel panel = new TsTrackPanel();

        JFrame frm = new JFrame(GuiUtil.getString("Micro Service Monitor"));
        GuiUtil.setGridLayout((JComponent) frm.getContentPane(), panel);
        frm.setIconImage(GuiResource.getIcon("dfc/track.png").getImage());
        frm.pack();
        GuiUtil.centerWindow(frm);
        GuiUtil.adjustWindowInsideScreen(frm);
        frm.setVisible(true);
    }

    public void OnOpenOpmMonitorPanel() throws Exception
    {
        final OpmMainPanel panel = new OpmMainPanel();

        final JFrame frm = new JFrame(GuiUtil.getString("OPM 系统监控"));
        GuiUtil.setGridLayout((JComponent) frm.getContentPane(), panel);
        frm.setIconImage(GuiResource.getIcon("dfc/track.png").getImage());
        frm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frm.pack();
        GuiUtil.centerWindow(frm);
        GuiUtil.adjustWindowInsideScreen(frm);
        frm.addWindowListener(new WindowAdapter()
        {
            @Override
            public void windowClosed(WindowEvent e)
            {
                panel.shutdown();
            }

            @Override
            public void windowClosing(WindowEvent e)
            {
                panel.shutdown();
            }
        });
        frm.setVisible(true);
    }

    public void OnSearchJavaCode() throws Exception
    {
        jSearchClassPanel.jTxt_Key.selectAll();
        jSearchClassPanel.jTxt_Key.grabFocus();
        jDlgSearchClass.pack();
        GuiUtil.centerWindow(jDlgSearchClass);
        if (!jDlgSearchClass.showModel(true))
            return;

        CJavaCode code = jSearchClassPanel.getSelectCode();
        if (code != null)
            BapGuiUtil.openCode(code);
    }

    protected void OnLogTool()
    {
        LogReviewTool frm = new LogReviewTool()
        {
            public String getString(String key)
            {
                return dfcutil.getString(key);
            }
        };

        if (!frm.blInitIP)
        {
            frm.s_LastIP = "127.0.0.1";
            try
            {
                frm.s_LastPort = "8090";
            } catch (Exception exp)
            {
                exp.printStackTrace();
            }
            frm.s_LastRmtFile = "logs/runtime.log";
            frm.blInitIP = true;
        }
        frm.setTitle(dfcutil.getString("Log Tool"));
        frm.setVisible(true);
    }
    
    public void OnLocalStore() throws Exception
    {
        YunArtifactTablePanel panel = new YunArtifactTablePanel() {
            CRpcClientWrapper<IYunStore> client;

            public CRpcClientWrapper<IYunStore> getIntfWrapper()
            {
                if (client == null)
                {
                    client = new CRpcClientWrapper<IYunStore>(IYunStore.class)
                    {
                        public CRpcAdapter getAdapter()
                        {
                            return BapClient.getMe().getRpcAdapter();
                        }
                    };
                    client.init(BapClient.getMe().getUri());
                }
                return client;
            }
            public UserPassword loginYunStore() throws Exception
            {
                return new UserPassword(CDaoUtil.getGlobalSession().getUserCode(), Password.decode(CDaoUtil.getGlobalSession().getPwd()));
            }
        };
        panel.showDataLater();
        JSimpleDialog dlg = GuiUtil.createSimpleDialog(panel, this);
        dlg.setTitle("Local Store - " + BapClient.getMe().getUri());
        dlg.showModel(false);
    }
}
