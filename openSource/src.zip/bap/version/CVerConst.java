package bap.version;

import com.cdao.model.CDoBasic;
import com.leavay.ms.tool.CmnUtil;

import bap.md.ver.VersionNode;

public class CVerConst
{

    public final static String TYPE_JAVA = "JAVA";
    public final static String TYPE_RES_FILE = "RES_FILE";

    public final static String[] FIELDS_NODE_BRIEF = CmnUtil.append(CDoBasic.FIELDS_BASIC, VersionNode.ForeignKey, VersionNode.Key, VersionNode.VersionNo, VersionNode.SeqNo, VersionNode.Comments, VersionNode.DeleteFlag,
            VersionNode.CommitTime, VersionNode.Commiter);

}
