package bap.version;

public class CVerLocal
{
    public final static String VersionDir = ".version";
}
