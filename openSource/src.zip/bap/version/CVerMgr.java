package bap.version;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.nutz.dao.Cnd;

import com.cdao.dto.CPager;
import com.cdao.impl.entity.field.GID;
import com.cdao.mgr.CDaoUtil;
import com.cdao.mgr.lock.LockFailException;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.ms.tool.CmnUtil;

import bap.java.CJavaCode;
import bap.md.java.CJavaCodeDo;
import bap.md.java.CJavaProject;
import bap.md.java.CResFileDo;
import bap.md.ver.VersionNode;
import bap.md.ver.VersionProject;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import cell.cdao.ILock;

public class CVerMgr
{
    private static CVerMgr _me;

    public synchronized static CVerMgr get()
    {
        if (_me == null)
        {
            _me = new CVerMgr();
        }
        return _me;
    }

    private CVerMgr()
    {

    }

    public void commitCode(IDao dao, CJavaProject project, String comments, List<CJavaCodeDo> lstCode, List<CJavaCode> deleteList) throws Exception
    {
        VersionProject vPj = queryProject(dao, project.getUuid());
        if (vPj == null)
        {
            vPj = createProject(dao, project.getName(), project.getUuid(), project.getUuid());
        }
        
        List<VersionNode> lstNodes = new LinkedList<VersionNode>();
        for (CJavaCodeDo code : lstCode)
        {
            VersionNode node = new VersionNode();
            
            node.setDataType(CVerConst.TYPE_JAVA);
            node.setKey(code.getFullClassName());
            node.setDataBin(code.getCode().getBytes("UTF-8"));
            lstNodes.add(node);
        }
        
        for (CJavaCode del : deleteList)
        {
            VersionNode node = new VersionNode();
            
            node.setDataType(CVerConst.TYPE_JAVA);
            node.setKey(del.getFullClassName());
            node.setDeleteFlag(true);
            lstNodes.add(node);
        }
        
        commitNode(dao, vPj.getGid(), comments, lstNodes);
    }
    
    public void commitFile(IDao dao, CJavaProject project, String comments, List<CResFileDo> lstFile, List<CResFileDo> deleteList) throws Exception
    {
        VersionProject vPj = queryProject(dao, project.getUuid());
        if (vPj == null)
        {
            vPj = createProject(dao, project.getName(), project.getUuid(), project.getUuid());
        }
        
        List<VersionNode> lstNodes = new LinkedList<VersionNode>();
        for (CResFileDo f : lstFile)
        {
            VersionNode node = new VersionNode();
            
            node.setDataType(CVerConst.TYPE_RES_FILE);
            node.setKey(f.getPhysicalPath());
            node.setDataBin(f.getFileBin());
            lstNodes.add(node);
        }
        
        for (CResFileDo del : deleteList)
        {
            VersionNode node = new VersionNode();
            
            node.setDataType(CVerConst.TYPE_RES_FILE);
            node.setKey(del.getPhysicalPath());
            node.setDeleteFlag(true);
            lstNodes.add(node);
        }
        
        commitNode(dao, vPj.getGid(), comments, lstNodes);
    }
    
    public long getLockTimeout()
    {
        return 30000;
    }
    
    protected class Lock implements AutoCloseable
    {
        String _uuid;
        public Lock(String uuid) throws LockFailException, TimeoutException
        {
            this(uuid, getLockTimeout());
        }
        
        public Lock(String uuid, long timeout) throws LockFailException, TimeoutException
        {
            lockProject(uuid, timeout);
            _uuid = uuid;
        }

        public void close() throws Exception
        {
            unlockProject(_uuid);
        }
    }
    
    public void lockProject(String pjUuid, long timeout) throws LockFailException, TimeoutException
    {
        ILock.get().lockKey(pjUuid, null, timeout);
    }
    
    public void unlockProject(String pjUuid)
    {
        ILock.get().unlock(pjUuid);
    }
    
    // owner可选，如果传值了，则设定了强依赖关系，同生同死
    public VersionProject createProject(IDao dao, String name, String extKey, String owner) throws Exception
    {
        VersionProject pj = new VersionProject();
        pj.setProjectName(name);
        pj.setExternalKey(extKey);
        pj.setCreateTime(System.currentTimeMillis());
        pj.setMaker(CDaoUtil.getRpcUserCode());
        pj.setOwner(owner);

        return dao.createDo(pj);
    }
    
    public VersionProject queryProject(IDao dao, String extKey) throws Exception
    {
        return (VersionProject) dao.queryDo(VersionProject.class.getName(), Cnd.where(VersionProject.ExternalKey, "=", extKey));
    }
    
    public IDao newDao() throws Exception
    {
        return IDaoService.newIDao();
    }
    
    // 只查简要信息，不查内容
    public List<VersionNode> queryNodeLog(String extProjectKey, String nodeKey) throws Exception
    {
        try (IDao dao = newDao())
        {
            VersionProject pj = queryProject(dao, extProjectKey);
            CmnUtil.assertNotNull(pj, "There isn't valid version history for project");

            Cnd cnd = Cnd.where(VersionNode.ForeignKey, "=", pj.getUuid());
            cnd.and(VersionNode.Key, "=", nodeKey);
            cnd.desc(VersionNode.VersionNo);

            return dao.queryDoList(VersionNode.class, cnd, CVerConst.FIELDS_NODE_BRIEF);
        }
    }
    
    public MultiPageResult<VersionNode> queryNodeLogs(String extProjectKey, Cnd cndWhere, CPager pager, String ... fields) throws Exception
    {
        try (IDao dao = newDao())
        {
            // 版本工程和外部实际工程有个映射关系
            VersionProject pj = queryProject(dao, extProjectKey);
            CmnUtil.assertNotNull(pj, "There isn't valid version history for project");

            if (cndWhere == null)
                cndWhere = Cnd.where(VersionNode.ForeignKey, "=", pj.getUuid());
            else
                cndWhere.and(VersionNode.ForeignKey, "=", pj.getUuid());
            
            return dao.queryDoPage(VersionNode.class, cndWhere, pager, fields);
        }
    }
    
    /**
     * 查工程的所有变更历史记录
     * 
     * 按照版本号规约化，一个版本号一条记录，只拿到简要信息、时间、注解、提交人等信息
     */
    public List<VersionNode> queryVersionList(String extProjectKey) throws Exception
    {
        try (IDao dao = newDao())
        {
            VersionProject pj = queryProject(dao, extProjectKey);
            CmnUtil.assertNotNull(pj, "There is no version history related to the project, perhaps the project has been deleted.");

            String sql =  "select distinct($versionNo), $comments, $commitTime, $commiter from $table where $forKey=@projectUuid order by $versionNo desc";
            Map<String, Object> vars = new HashMap();
            vars.put("versionNo", VersionNode.VersionNo);
            vars.put("comments", VersionNode.Comments);
            vars.put("commitTime", VersionNode.CommitTime);
            vars.put("commiter", VersionNode.Commiter);
            vars.put("table", VersionNode.TABLE);
            vars.put("forKey", VersionNode.ForeignKey);
            
            Map<String, Object> params = new HashMap();
            params.put("projectUuid", pj.getUuid());
            
            List<VersionNode> lstNode = new LinkedList();
            MultiPageResult rsO = dao.queryEntity(VersionNode.class.getName(), sql, null, vars, params, 0, Integer.MAX_VALUE);
            return rsO ==null?null:rsO.getListData();
        }
    }

    public List<VersionNode> queryVersionDetail(String extProjectKey, long versionNo, boolean withData) throws Exception
    {
        try (IDao dao = newDao())
        {
            VersionProject pj = queryProject(dao, extProjectKey);
            CmnUtil.assertNotNull(pj, "Project was deleted");
            
            Cnd cnd = Cnd.where(VersionNode.ForeignKey, "=", pj.getUuid()).and(VersionNode.VersionNo, "=", versionNo);
            cnd.asc(VersionNode.SeqNo);
            
            if (withData)
                return dao.queryDoList(VersionNode.class, cnd);
            else
                return dao.queryDoList(VersionNode.class, cnd, CVerConst.FIELDS_NODE_BRIEF);
        }
    }
    
    public VersionNode getNode(String uuid, boolean withContent) throws Exception
    {
        try (IDao dao = IDaoService.get().newDao())
        {
            if (withContent)
                return (VersionNode) dao.queryDo(GID.build(VersionNode.class, uuid));
            else
                return (VersionNode) dao.queryDo(GID.build(VersionNode.class, uuid), CVerConst.FIELDS_NODE_BRIEF);
        }
    }
    
    public void deleteProject(String pjUuid) throws Exception
    {
        try (Lock lc = new Lock(pjUuid))
        {
            try (IDao dao = IDaoService.get().newDao())
            {
                dao.deleteDo(GID.build(VersionProject.class, pjUuid));
                dao.commit();
            }   
        }
    }
    
    // 外部必须加锁
    protected long _allocVerNo(IDao dao, String pjUuid) throws Exception
    {
        Cnd cnd = Cnd.where(VersionNode.ForeignKey, "=", pjUuid);
        cnd.desc(VersionNode.VersionNo);

        return dao.queryLong(VersionNode.class, cnd, VersionNode.VersionNo, 0) + 1;
    }
    
    public void commitNode(IDao dao, GID pjGid, String comments, List<VersionNode> lstNodes) throws Exception
    {
        try (Lock lc = new Lock(pjGid.getUuid()))
        {
            long time = System.currentTimeMillis();
            long ver = _allocVerNo(dao, pjGid.getUuid());
            long seq = 0;
            for (VersionNode node : lstNodes)
            {
                node.setForeignGid(pjGid);
                node.setVersionNo(ver).setSeqNo(seq++);
                node.setComments(comments);
                node.setCommiter(CDaoUtil.getRpcUserCode());
                node.setCommitTime(time);

                dao.createDo(node);
            }
            dao.commit();
        }
    }
}
