package bap.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.cjson.CJson;

import bap.opm.system.SystemMetrics;
import bap.opm.system.SystemMetricsCollectSpec;
import bap.opm.system.SystemMetricsProvider;
import bap.opm.system.SystemMetricsProviderFactory;

/**
 * Windows采集性能剖析入口。
 *
 * 用法：
 * java -Dopm.collect.debug=true bap.test.OpmWindowsCollectProfileMain
 * java -Dopm.collect.debug=true bap.test.OpmWindowsCollectProfileMain 1000 1
 */
public class OpmWindowsCollectProfileMain
{
    public static void main(String[] args)
    {
        long sampleMillis = 1000L;
        int rounds = 1;
        if (args != null && args.length > 0)
            sampleMillis = safeLong(args[0], 1000L);
        if (args != null && args.length > 1)
            rounds = Math.max(1, (int) safeLong(args[1], 1L));

        System.setProperty("opm.collect.debug", "true");

        SystemMetricsProvider provider = SystemMetricsProviderFactory.resolveProvider();
        String providerName = provider == null ? "unknown" : provider.getName();

        List<RunStat> stats = new ArrayList<RunStat>();
        for (int i = 0; i < rounds; i++)
        {
            stats.add(runOne(provider, sampleMillis, "all", SystemMetricsCollectSpec.all()));
            stats.add(runOne(provider, sampleMillis, "sys", SystemMetricsCollectSpec.forSysCollector()));
            stats.add(runOne(provider, sampleMillis, "topCpu", SystemMetricsCollectSpec.forCpuCollector()));
            stats.add(runOne(provider, sampleMillis, "disk", SystemMetricsCollectSpec.forDiskCollector()));
            stats.add(runOne(provider, sampleMillis, "topIo", SystemMetricsCollectSpec.forIoCollector()));
            stats.add(runOne(provider, sampleMillis, "topNet", SystemMetricsCollectSpec.forNetCollector()));
        }

        LinkedHashMap<String, Object> report = new LinkedHashMap<String, Object>();
        report.put("os", System.getProperty("os.name"));
        report.put("provider", providerName);
        report.put("sampleMillis", sampleMillis);
        report.put("rounds", rounds);
        report.put("time", System.currentTimeMillis());

        List<Map<String, Object>> details = new ArrayList<Map<String, Object>>();
        for (RunStat one : stats)
            details.add(one.toMap());
        report.put("details", details);

        Map<String, List<RunStat>> grouped = new LinkedHashMap<String, List<RunStat>>();
        for (RunStat one : stats)
        {
            List<RunStat> lst = grouped.get(one.specName);
            if (lst == null)
            {
                lst = new ArrayList<RunStat>();
                grouped.put(one.specName, lst);
            }
            lst.add(one);
        }

        List<Map<String, Object>> summary = new ArrayList<Map<String, Object>>();
        for (Map.Entry<String, List<RunStat>> ent : grouped.entrySet())
            summary.add(buildSummary(ent.getKey(), ent.getValue()));
        report.put("summary", summary);

        List<RunStat> sorted = new ArrayList<RunStat>(stats);
        Collections.sort(sorted, new Comparator<RunStat>()
        {
            @Override
            public int compare(RunStat a, RunStat b)
            {
                return Long.compare(b.costMs, a.costMs);
            }
        });

        List<Map<String, Object>> topSlow = new ArrayList<Map<String, Object>>();
        for (int i = 0; i < sorted.size() && i < 10; i++)
            topSlow.add(sorted.get(i).toMap());
        report.put("topSlow", topSlow);

        System.out.println(CJson.toJson(report));
    }

    protected static RunStat runOne(SystemMetricsProvider provider, long sampleMillis, String name, SystemMetricsCollectSpec spec)
    {
        long st = System.currentTimeMillis();
        Throwable err = null;
        SystemMetrics metrics = null;
        try
        {
            metrics = provider.collect(sampleMillis, spec);
        }
        catch (Throwable e)
        {
            err = e;
        }

        RunStat rs = new RunStat();
        rs.specName = name;
        rs.costMs = System.currentTimeMillis() - st;
        rs.error = err == null ? null : err.getMessage();
        rs.detail = summarize(metrics);
        return rs;
    }

    protected static Map<String, Object> summarize(SystemMetrics metrics)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        if (metrics == null)
        {
            map.put("nullMetrics", true);
            return map;
        }

        map.put("provider", metrics.provider);
        map.put("host", metrics.hostName);
        map.put("topCpu", metrics.cpu == null ? null : metrics.cpu.available);
        map.put("topMemory", metrics.memory == null ? null : metrics.memory.available);
        map.put("diskCount", metrics.disks == null ? 0 : metrics.disks.size());
        map.put("cpuProcCount", metrics.cpuProcesses == null ? 0 : metrics.cpuProcesses.size());
        map.put("ioProcCount", metrics.io == null || metrics.io.processes == null ? 0 : metrics.io.processes.size());
        map.put("netIfCount", metrics.network == null || metrics.network.interfaces == null ? 0 : metrics.network.interfaces.size());
        return map;
    }

    protected static Map<String, Object> buildSummary(String key, List<RunStat> list)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("spec", key);
        map.put("count", list == null ? 0 : list.size());
        if (list == null || list.isEmpty())
            return map;

        long min = Long.MAX_VALUE;
        long max = Long.MIN_VALUE;
        long sum = 0L;
        int errCnt = 0;
        for (RunStat one : list)
        {
            if (one == null)
                continue;
            if (one.costMs < min)
                min = one.costMs;
            if (one.costMs > max)
                max = one.costMs;
            sum += one.costMs;
            if (one.error != null)
                errCnt++;
        }
        map.put("minMs", min == Long.MAX_VALUE ? -1 : min);
        map.put("maxMs", max == Long.MIN_VALUE ? -1 : max);
        map.put("avgMs", sum / Math.max(1, list.size()));
        map.put("errorCount", errCnt);
        return map;
    }

    protected static long safeLong(String txt, long dv)
    {
        if (txt == null)
            return dv;
        try
        {
            return Long.parseLong(txt.trim());
        }
        catch (Throwable ignore)
        {
            return dv;
        }
    }

    protected static class RunStat
    {
        String specName;
        long costMs;
        String error;
        Map<String, Object> detail;

        Map<String, Object> toMap()
        {
            LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
            map.put("spec", specName);
            map.put("costMs", costMs);
            map.put("error", error);
            map.put("detail", detail);
            return map;
        }
    }
}
