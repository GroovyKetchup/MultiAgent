package bap.test;

import java.util.List;

import com.leavay.common.util.DetailErrorMsg;

import bap.md.opm.OpmMetricMainDo;
import bap.opm.OpmCenter;
import bap.opm.OpmCollectResult;

public class OpmSmokeTest
{
    public static void main(String[] args)
    {
        try
        {
            OpmCenter center = OpmCenter.get();
            center.start();

            OpmCollectResult one = center.collectNow("sys");
            System.out.println("[OPM] collectNow(sys) => " + (one == null ? "null" : one.summary));

            List<OpmMetricMainDo> latest = center.queryLatestMain(5);
            System.out.println("[OPM] latest metric rows=" + (latest == null ? 0 : latest.size()));
            if (latest != null)
            {
                for (OpmMetricMainDo row : latest)
                {
                    if (row == null)
                        continue;
                    System.out.println("  - t=" + row.collectTime + ", collector=" + row.collectorKey + ", agent=" + row.agentCode
                            + ", status=" + row.status + ", summary=" + row.summary);
                }
            }
        }
        catch (Throwable exp)
        {
            DetailErrorMsg.showError(exp);
            System.exit(1);
        }
    }
}
