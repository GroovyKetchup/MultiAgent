package bap.test;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.ms.tool.CmnUtil;

import bap.debug.BapDebugger;
import cell.bap.test.DemoCell3;
import cell.bap.test.DemoCell3Impl;

// 接管cell2的实现为本地实现DemoCell2OnDebugger2
public class BapDebugger3
{
    public static void main(String[] args)
    {
        try
        {
            BapDebugger.get().registLocalTempCells(DemoCell3.class, DemoCell3Impl.class);
            BapDebugger.get().startGui(false, CmnUtil.buildWsUri("localhost", 2020), false);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
            System.exit(0);
        }
    }
}
