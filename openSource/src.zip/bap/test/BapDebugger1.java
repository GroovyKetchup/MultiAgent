package bap.test;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.ms.tool.CmnUtil;

import bap.debug.BapDebugger;
import cell.bap.test.DemoCell1;

// 接管Cell1的实现为本地实现：DemoDebugCell1
public class BapDebugger1
{
    public static void main(String[] args)
    {
        try
        {
            BapDebugger.get().registLocalTempCells(DemoCell1.class, DemoDebugCell1.class);
            BapDebugger.get().startGui(false, CmnUtil.buildWsUri("localhost", 2020), false);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
            System.exit(0);
        }
    }
}
