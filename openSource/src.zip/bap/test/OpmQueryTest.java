package bap.test;

import java.util.List;

import com.leavay.common.util.DetailErrorMsg;

import bap.md.opm.OpmAlarmRefDo;
import bap.md.opm.OpmMetricMainDo;
import bap.opm.OpmCenter;

public class OpmQueryTest
{
    public static void main(String[] args)
    {
        try
        {
            OpmCenter center = OpmCenter.get();
            center.start();

            System.out.println("[OPM] collectors=" + center.listCollectorKeys());

            List<OpmMetricMainDo> latestMetric = center.queryLatestMain(20);
            List<OpmAlarmRefDo> latestAlarm = center.queryLatestAlarmRef(20);

            System.out.println("[OPM] metric count=" + (latestMetric == null ? 0 : latestMetric.size()));
            System.out.println("[OPM] alarm count=" + (latestAlarm == null ? 0 : latestAlarm.size()));
        }
        catch (Throwable exp)
        {
            DetailErrorMsg.showError(exp);
            System.exit(1);
        }
    }
}
