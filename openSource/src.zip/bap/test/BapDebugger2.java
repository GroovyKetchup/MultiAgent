package bap.test;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.CellManual;
import bap.debug.BapDebugger;
import cell.bap.test.DemoCell2;
import cell.bap.test.DemoCell2Impl;
import cell.bap.test.DemoDao;

// 接管cell2的实现为本地实现DemoCell2OnDebugger2
public class BapDebugger2
{
    @CellManual
    public static class DemoCell2OnDebugger2InEclipse extends DemoCell2Impl
    {
        private static final long serialVersionUID = 4729458712058249229L;

        public void testShareDao(DemoDao tran)
        {
            tran.update("Update in cell2(Debugger)");
            
            System.out.println("Invoke testShareDao in DEBUGGER2");
            tran.commit("I'm DEBUGGER CELL2");
        }
        
        public void test()
        {
            System.out.println("I'm DEBUGGER CELL2 : " + this.getClass().getName() + "::test()");
        }
    }
    
    public static void main(String[] args)
    {
        BapDebugger2 dbg = new BapDebugger2();
        
        try
        {
            BapDebugger.get().registLocalTempCells(DemoCell2.class, DemoCell2OnDebugger2InEclipse.class);
            BapDebugger.get().startGui(false, CmnUtil.buildWsUri("localhost", 2020), false);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
            System.exit(0);
        }
    }
}
