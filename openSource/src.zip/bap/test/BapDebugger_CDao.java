package bap.test;

import com.leavay.common.util.DetailErrorMsg;
import com.leavay.ms.tool.CmnUtil;

import bap.debug.BapDebugger;
import cell.bap.test.TestDaoCell;
import cell.bap.test.TestDaoImpl;

public class BapDebugger_CDao
{
    public static void main(String[] args)
    {
        try
        {
            BapDebugger.get().registLocalTempCells(TestDaoCell.class, TestDaoImpl.class);
//            BapDebugger.get().registLocalTempCells(CDaoServiceCell.class, CDaoServiceImpl.class);
            
            BapDebugger.get().startGui(false, CmnUtil.buildWsUri("localhost", 2020), false);
        } catch (Exception exp)
        {
            DetailErrorMsg.showError(exp);
            System.exit(0);
        }
    }
}
