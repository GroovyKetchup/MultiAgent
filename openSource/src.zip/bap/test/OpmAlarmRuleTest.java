package bap.test;

import java.util.List;

import org.nutz.dao.Cnd;

import com.leavay.common.util.DetailErrorMsg;

import bap.md.opm.OpmMetricMainDo;
import bap.md.opm.sys.OpmSysMetricDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCenter;
import bap.opm.OpmCollectResult;
import bap.opm.OpmRuleResult;
import cell.bap.opm.collector.system.COpmSysCollector;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.md.TsAlarm;

/**
 * CPU/内存四级告警规则测试用例
 * 
 * 测试场景：
 * 1. 当前值低于所有阈值 - 不触发告警
 * 2. 当前值满足警告级别，但历史数据不满足持续时间 - 不触发
 * 3. 当前值满足警告级别，历史数据满足持续时间 - 触发警告
 * 4. 当前值满足次要级别，历史数据满足持续时间 - 触发次要
 * 5. 当前值满足主要级别，历史数据满足持续时间 - 触发主要
 * 6. 当前值满足严重级别，历史数据满足持续时间 - 触发严重
 * 7. 当前值满足多个级别，只触发最高级别
 * 8. 冷却期内不重复告警
 */
public class OpmAlarmRuleTest
{
    private static final String TEST_AGENT_CODE = "test-alarm-agent";
    private static final String TEST_AGENT_NAME = "测试告警代理";

    public static void main(String[] args)
    {
        try
        {
            System.out.println("========================================");
            System.out.println("CPU/内存四级告警规则测试");
            System.out.println("========================================\n");

            OpmCenter center = OpmCenter.get();
            center.start();

            // 清理测试数据
            cleanTestData();

            // 直接创建采集器实例进行测试
            COpmSysCollector collector = new COpmSysCollector();
            collector.loadConfig();

            // 创建测试上下文
            OpmAgentContext agentCtx = createTestAgentContext();

            // 运行测试用例
            runAllTests(collector, agentCtx);

            // 清理测试数据
            cleanTestData();

            System.out.println("\n========================================");
            System.out.println("测试完成");
            System.out.println("========================================");
        }
        catch (Throwable exp)
        {
            DetailErrorMsg.showError(exp);
            System.exit(1);
        }
    }

    protected static void runAllTests(COpmSysCollector collector, OpmAgentContext agentCtx) throws Exception
    {
        // 测试1: 当前值低于所有阈值 - 不触发告警
        testCase1_BelowAllThresholds(collector, agentCtx);

        // 测试2: 当前值满足警告级别，但历史数据不满足持续时间 - 不触发
        testCase2_WarnButNoDuration(collector, agentCtx);

        // 测试3: 当前值满足警告级别，历史数据满足持续时间 - 触发警告
        testCase3_WarnTriggered(collector, agentCtx);

        // 测试4: 当前值满足次要级别，历史数据满足持续时间 - 触发次要
        testCase4_MinorTriggered(collector, agentCtx);

        // 测试5: 当前值满足主要级别，历史数据满足持续时间 - 触发主要
        testCase5_MajorTriggered(collector, agentCtx);

        // 测试6: 当前值满足严重级别，历史数据满足持续时间 - 触发严重
        testCase6_CriticalTriggered(collector, agentCtx);

        // 测试7: 当前值满足多个级别，只触发最高级别
        testCase7_OnlyHighestLevel(collector, agentCtx);
    }

    /**
     * 测试1: 当前值低于所有阈值 - 不触发告警
     * CPU=50%, 低于警告阈值70%
     */
    protected static void testCase1_BelowAllThresholds(COpmSysCollector collector, OpmAgentContext agentCtx) throws Exception
    {
        System.out.println("\n--- 测试1: 当前值低于所有阈值 - 不触发告警 ---");
        cleanTestData();

        // 当前值 50%，低于所有阈值
        OpmCollectResult result = createCollectResult(0.50, 0.50);
        List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

        printResult("CPU=50%, 低于警告阈值70%", rules);
        assertNoAlarm(rules, "测试1");
    }

    /**
     * 测试2: 当前值满足警告级别，但历史数据不满足持续时间 - 不触发
     * CPU=75%, 满足警告阈值70%，但历史数据不足
     */
    protected static void testCase2_WarnButNoDuration(COpmSysCollector collector, OpmAgentContext agentCtx) throws Exception
    {
        System.out.println("\n--- 测试2: 当前值满足警告级别，但历史数据不满足持续时间 ---");
        cleanTestData();

        // 插入少量历史数据（不满足持续时间要求）
        insertHistoryData(0.72, 3); // 只插入3条，不满足60秒持续时间

        // 当前值 75%
        OpmCollectResult result = createCollectResult(0.75, 0.50);
        List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

        printResult("CPU=75%, 历史数据不足60秒", rules);
        assertNoAlarm(rules, "测试2");
    }

    /**
     * 测试3: 当前值满足警告级别，历史数据满足持续时间 - 触发警告
     * CPU=75%, 满足警告阈值70%，历史数据都>=70%，持续60秒
     */
    protected static void testCase3_WarnTriggered(COpmSysCollector collector, OpmAgentContext agentCtx) throws Exception
    {
        System.out.println("\n--- 测试3: 当前值满足警告级别，历史数据满足持续时间 - 触发警告 ---");
        cleanTestData();

        // 插入满足持续时间的历史数据（60秒，采集间隔5秒，需要12条以上）
        insertHistoryData(0.72, 15); // 15条数据，满足60秒

        // 当前值 75%
        OpmCollectResult result = createCollectResult(0.75, 0.50);
        List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

        printResult("CPU=75%, 历史数据满足60秒", rules);
        assertAlarmLevel(rules, TsAlarm.LEVEL_WARN, "测试3");
    }

    /**
     * 测试4: 当前值满足次要级别，历史数据满足持续时间 - 触发次要
     * CPU=85%, 满足次要阈值80%，历史数据都>=80%，持续30秒
     */
    protected static void testCase4_MinorTriggered(COpmSysCollector collector, OpmAgentContext agentCtx) throws Exception
    {
        System.out.println("\n--- 测试4: 当前值满足次要级别，历史数据满足持续时间 - 触发次要 ---");
        cleanTestData();

        // 插入满足次要级别持续时间的历史数据（30秒，需要6条以上）
        insertHistoryData(0.82, 8); // 8条数据，满足30秒

        // 当前值 85%
        OpmCollectResult result = createCollectResult(0.85, 0.50);
        List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

        printResult("CPU=85%, 历史数据满足30秒", rules);
        assertAlarmLevel(rules, TsAlarm.LEVEL_ERROR_MINOR, "测试4");
    }

    /**
     * 测试5: 当前值满足主要级别，历史数据满足持续时间 - 触发主要
     * CPU=92%, 满足主要阈值90%，历史数据都>=90%，持续15秒
     */
    protected static void testCase5_MajorTriggered(COpmSysCollector collector, OpmAgentContext agentCtx) throws Exception
    {
        System.out.println("\n--- 测试5: 当前值满足主要级别，历史数据满足持续时间 - 触发主要 ---");
        cleanTestData();

        // 插入满足主要级别持续时间的历史数据（15秒，需要3条以上）
        insertHistoryData(0.91, 5); // 5条数据，满足15秒

        // 当前值 92%
        OpmCollectResult result = createCollectResult(0.92, 0.50);
        List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

        printResult("CPU=92%, 历史数据满足15秒", rules);
        assertAlarmLevel(rules, TsAlarm.LEVEL_ERROR_MAJOR, "测试5");
    }

    /**
     * 测试6: 当前值满足严重级别，历史数据满足持续时间 - 触发严重
     * CPU=97%, 满足严重阈值95%，历史数据都>=95%，持续5秒
     */
    protected static void testCase6_CriticalTriggered(COpmSysCollector collector, OpmAgentContext agentCtx) throws Exception
    {
        System.out.println("\n--- 测试6: 当前值满足严重级别，历史数据满足持续时间 - 触发严重 ---");
        cleanTestData();

        // 插入满足严重级别持续时间的历史数据（5秒，需要1条以上）
        insertHistoryData(0.96, 3); // 3条数据，满足5秒

        // 当前值 97%
        OpmCollectResult result = createCollectResult(0.97, 0.50);
        List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

        printResult("CPU=97%, 历史数据满足5秒", rules);
        assertAlarmLevel(rules, TsAlarm.LEVEL_ERROR_CRITICAL, "测试6");
    }

    /**
     * 测试7: 当前值满足多个级别，只触发最高级别
     * CPU=97%, 满足所有级别，但只触发严重
     */
    protected static void testCase7_OnlyHighestLevel(COpmSysCollector collector, OpmAgentContext agentCtx) throws Exception
    {
        System.out.println("\n--- 测试7: 当前值满足多个级别，只触发最高级别 ---");
        cleanTestData();

        // 插入满足所有级别持续时间的历史数据
        insertHistoryData(0.96, 15); // 满足所有级别的持续时间

        // 当前值 97%
        OpmCollectResult result = createCollectResult(0.97, 0.50);
        List<OpmRuleResult> rules = collector.evaluateRules(result, agentCtx);

        printResult("CPU=97%, 满足所有级别", rules);
        assertAlarmLevel(rules, TsAlarm.LEVEL_ERROR_CRITICAL, "测试7");
        assertAlarmCount(rules, 1, "测试7"); // 只触发1个告警
    }

    // ==================== 辅助方法 ====================

    protected static OpmAgentContext createTestAgentContext()
    {
        return new OpmAgentContext() {
            @Override
            public String getAgentCode()
            {
                return TEST_AGENT_CODE;
            }

            @Override
            public String getAgentName()
            {
                return TEST_AGENT_NAME;
            }

            @Override
            public String getMyUri()
            {
                return "test://alarm-test";
            }
        };
    }

    protected static OpmCollectResult createCollectResult(double cpuRate, double memRate)
    {
        OpmCollectResult result = new OpmCollectResult();
        result.collectorKey = "sys";
        result.collectorLabel = "系统基础监控";
        result.collectTime = System.currentTimeMillis();

        OpmSysMetricDo ext = new OpmSysMetricDo();
        ext.collectorKey = "sys";
        ext.collectorLabel = "系统基础监控";
        ext.agentCode = TEST_AGENT_CODE;
        ext.agentName = TEST_AGENT_NAME;
        ext.collectTime = result.collectTime;
        ext.cpuUsageRate = Double.valueOf(cpuRate);
        ext.memUsageRate = Double.valueOf(memRate);
        ext.diskMaxUsageRate = Double.valueOf(0.50);
        ext.summary = "cpu=" + formatRate(cpuRate) + ", mem=" + formatRate(memRate);

        result.metricExt = ext;
        result.summary = ext.summary;
        result.status = 0;
        return result;
    }

    protected static void insertHistoryData(double cpuRate, int count) throws Exception
    {
        long now = System.currentTimeMillis();
        long interval = 5000L; // 5秒采集间隔

        try (IDao dao = IDaoService.newIDao())
        {
            for (int i = 0; i < count; i++)
            {
                long collectTime = now - (count - i) * interval;

                OpmMetricMainDo main = new OpmMetricMainDo();
                main.collectorKey = "sys";
                main.collectorLabel = "系统基础监控";
                main.agentCode = TEST_AGENT_CODE;
                main.agentName = TEST_AGENT_NAME;
                main.myUri = "test://alarm-test";
                main.collectTime = Long.valueOf(collectTime);
                main.status = Integer.valueOf(0);
                main.summary = "cpu=" + formatRate(cpuRate);

                main = (OpmMetricMainDo) dao.createDo(main);

                OpmSysMetricDo ext = new OpmSysMetricDo();
                ext.bindMain(main);
                ext.collectorKey = "sys";
                ext.collectorLabel = "系统基础监控";
                ext.agentCode = TEST_AGENT_CODE;
                ext.agentName = TEST_AGENT_NAME;
                ext.collectTime = Long.valueOf(collectTime);
                ext.cpuUsageRate = Double.valueOf(cpuRate);
                ext.memUsageRate = Double.valueOf(0.50);
                ext.diskMaxUsageRate = Double.valueOf(0.50);
                ext.summary = main.summary;

                dao.createDo(ext);
            }
            dao.commit();
        }

        System.out.println("  [准备] 插入历史数据: " + count + "条, CPU=" + formatRate(cpuRate));
    }

    protected static void cleanTestData() throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = Cnd.where(OpmSysMetricDo.AgentCode, "=", TEST_AGENT_CODE);
            dao.deleteDos(OpmSysMetricDo.class.getName(), cnd);

            Cnd mainCnd = Cnd.where(OpmMetricMainDo.AgentCode, "=", TEST_AGENT_CODE);
            dao.deleteDos(OpmMetricMainDo.class.getName(), mainCnd);

            dao.commit();
        }
    }

    protected static void printResult(String desc, List<OpmRuleResult> rules)
    {
        System.out.println("  [场景] " + desc);
        if (rules == null || rules.isEmpty())
        {
            System.out.println("  [结果] 未触发告警");
        }
        else
        {
            System.out.println("  [结果] 触发 " + rules.size() + " 个告警:");
            for (OpmRuleResult r : rules)
            {
                System.out.println("    - 级别=" + getLevelName(r.alarmLevel)
                        + ", 规则=" + r.ruleKey
                        + ", 消息=" + r.message);
            }
        }
    }

    protected static void assertNoAlarm(List<OpmRuleResult> rules, String testName)
    {
        if (rules != null && !rules.isEmpty())
        {
            throw new AssertionError(testName + " 失败: 预期不触发告警，但触发了 " + rules.size() + " 个");
        }
        System.out.println("  [验证] ✓ 通过");
    }

    protected static void assertAlarmLevel(List<OpmRuleResult> rules, int expectedLevel, String testName)
    {
        if (rules == null || rules.isEmpty())
        {
            throw new AssertionError(testName + " 失败: 预期触发告警，但未触发");
        }
        for (OpmRuleResult r : rules)
        {
            if (r.alarmLevel == expectedLevel)
            {
                System.out.println("  [验证] ✓ 通过 (级别=" + getLevelName(expectedLevel) + ")");
                return;
            }
        }
        throw new AssertionError(testName + " 失败: 预期级别=" + getLevelName(expectedLevel)
                + ", 实际级别=" + getLevelName(rules.get(0).alarmLevel));
    }

    protected static void assertAlarmCount(List<OpmRuleResult> rules, int expectedCount, String testName)
    {
        int actualCount = rules == null ? 0 : rules.size();
        if (actualCount != expectedCount)
        {
            throw new AssertionError(testName + " 失败: 预期告警数=" + expectedCount + ", 实际=" + actualCount);
        }
        System.out.println("  [验证] ✓ 通过 (告警数=" + expectedCount + ")");
    }

    protected static String getLevelName(int level)
    {
        if (level == TsAlarm.LEVEL_ERROR_CRITICAL)
            return "严重";
        if (level == TsAlarm.LEVEL_ERROR_MAJOR)
            return "主要";
        if (level == TsAlarm.LEVEL_ERROR_MINOR)
            return "次要";
        if (level == TsAlarm.LEVEL_WARN)
            return "警告";
        if (level == TsAlarm.LEVEL_INFO)
            return "信息";
        return "未知(" + level + ")";
    }

    protected static String formatRate(double rate)
    {
        return String.format(java.util.Locale.US, "%.2f%%", Double.valueOf(rate * 100D));
    }
}