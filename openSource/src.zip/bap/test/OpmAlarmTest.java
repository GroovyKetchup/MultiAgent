package bap.test;

import java.util.List;

import com.leavay.common.util.DetailErrorMsg;

import bap.md.opm.OpmAlarmRefDo;
import bap.opm.OpmCenter;

public class OpmAlarmTest
{
    public static void main(String[] args)
    {
        try
        {
            OpmCenter center = OpmCenter.get();
            center.start();

            center.collectNow("sys");
            System.out.println("[OPM] collectNow(sys) done, query latest alarms");

            List<OpmAlarmRefDo> latest = center.queryLatestAlarmRef(10);
            System.out.println("[OPM] latest alarm ref rows=" + (latest == null ? 0 : latest.size()));
            if (latest != null)
            {
                for (OpmAlarmRefDo row : latest)
                {
                    if (row == null)
                        continue;
                    System.out.println("  - t=" + row.alarmTime + ", collector=" + row.collectorKey + ", rule=" + row.ruleKey
                            + ", agent=" + row.agentCode + ", metricMainUuid=" + row.metricMainUuid + ", req=" + row.alarmRequestId);
                }
            }
        }
        catch (Throwable exp)
        {
            DetailErrorMsg.showError(exp);
            System.exit(1);
        }
    }
}
