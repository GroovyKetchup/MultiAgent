package bap.test;

import com.leavay.dfc.microService.MsHelper;

public class TestMs
{
    public Object test(Object o)
    {
        System.out.println("" + o);
        return "Return from tester from [" + MsHelper.getMyMachineID()+"] : "+ o;
    }
}
