package bap.test;

import bap.cells.CellManual;
import bap.cells.Cells;
import cell.bap.test.DemoCell1Impl;
import cell.bap.test.DemoCell2;
import cell.bap.test.DemoCell3;
import cell.bap.test.DemoDao;
import cell.bap.test.DemoDaoImpl;

/**
 * 这是调试Cell1时接管的实现，用于模拟本地调试Cell1
 *
 */
@CellManual
public class DemoDebugCell1 extends DemoCell1Impl
{

    private static final long serialVersionUID = 6650982457679860734L;

    public Object test(Object o)
    {
        try (DemoCell2 c2 = Cells.get(DemoCell2.class))
        {
            c2.test();

            // 模拟调用另外的cell，而且要传入一个服务器资源Dao进去
            // 用完后，哪里发起哪里销毁
            try (DemoDao dao = new DemoDaoImpl())
            {
                dao.insert("In cell1(DEBUGGER)");

                c2.testShareDao(dao);

                try (DemoCell3 c3 = Cells.get(DemoCell3.class))
                {
                    c3.testShareDao(dao);
                }
            }

            return "This is DEBUGGER CELL1 : " + o;
        }
    }
}
