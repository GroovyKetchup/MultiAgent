package bap.test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.md.opm.OpmAlarmRefDo;
import bap.md.opm.cpu.OpmCpuMetricDo;
import bap.md.opm.disk.OpmDiskMetricDo;
import bap.md.opm.io.OpmIoMetricDo;
import bap.md.opm.net.OpmNetMetricDo;
import bap.md.opm.sys.OpmSysMetricDo;
import bap.opm.OpmCenter;
import bap.opm.OpmCollectResult;
import bap.opm.system.SystemMetricsUtil;

/**
 * OPM本地测试入口（仅主控内手工运行）。
 *
 * 用法：
 * java bap.test.OpmCollectorLocalCheck
 * java bap.test.OpmCollectorLocalCheck 10
 */
public class OpmCollectorLocalCheck
{
    public static void main(String[] args)
    {
        try
        {
            int size = 5;
            if (args != null && args.length > 0)
                size = Math.max(1, ToolUtilities.getInteger(args[0], 5));

            OpmCenter center = OpmCenter.get();
            center.start();

            String[] keys = new String[] { "sys", "topCpu", "disk", "topIo", "topNet" };
            LinkedHashMap<String, Object> collectMap = new LinkedHashMap<String, Object>();
            for (String key : keys)
            {
                LinkedHashMap<String, Object> one = new LinkedHashMap<String, Object>();
                try
                {
                    OpmCollectResult rs = center.collectNow(key);
                    one.put("ok", true);
                    one.put("summary", rs == null ? null : rs.summary);
                    one.put("status", rs == null ? null : rs.status);
                    one.put("collectTime", rs == null ? null : rs.collectTime);
                }
                catch (Throwable err)
                {
                    one.put("ok", false);
                    one.put("error", err.getMessage());
                }
                collectMap.put(key, one);
            }

            List<OpmSysMetricDo> sys = center.queryLatestSysMetric(size);
            List<OpmCpuMetricDo> cpu = center.queryLatestCpuMetric(size);
            List<OpmDiskMetricDo> disk = center.queryLatestDiskMetric(size);
            List<OpmIoMetricDo> io = center.queryLatestIoMetric(size);
            List<OpmNetMetricDo> net = center.queryLatestNetMetric(size);
            List<OpmAlarmRefDo> alarms = center.queryLatestAlarmRef(size);

            LinkedHashMap<String, Object> report = new LinkedHashMap<String, Object>();
            report.put("time", System.currentTimeMillis());
            report.put("collectorKeys", center.listCollectorKeys());
            report.put("collectNow", collectMap);

            LinkedHashMap<String, Object> counts = new LinkedHashMap<String, Object>();
            counts.put("sys", sys == null ? 0 : sys.size());
            counts.put("topCpu", cpu == null ? 0 : cpu.size());
            counts.put("disk", disk == null ? 0 : disk.size());
            counts.put("topIo", io == null ? 0 : io.size());
            counts.put("topNet", net == null ? 0 : net.size());
            counts.put("alarm", alarms == null ? 0 : alarms.size());
            report.put("counts", counts);

            LinkedHashMap<String, Object> latest = new LinkedHashMap<String, Object>();
            latest.put("sys", sys == null || sys.isEmpty() ? null : sys.get(0));
            latest.put("topCpu", cpu == null || cpu.isEmpty() ? null : cpu.get(0));
            latest.put("disk", disk == null || disk.isEmpty() ? null : disk.get(0));
            latest.put("topIo", io == null || io.isEmpty() ? null : io.get(0));
            latest.put("topNet", net == null || net.isEmpty() ? null : net.get(0));
            latest.put("alarm", alarms == null || alarms.isEmpty() ? null : alarms.get(0));
            report.put("latest", latest);

            if (disk != null && !disk.isEmpty())
            {
                OpmDiskMetricDo d = disk.get(0);
                LinkedHashMap<String, Object> diskSummary = new LinkedHashMap<String, Object>();
                diskSummary.put("diskCount", d == null ? null : d.diskCount);
                diskSummary.put("totalBytes", d == null ? null : d.totalBytes);
                diskSummary.put("totalUsedBytes", d == null ? null : d.totalUsedBytes);
                diskSummary.put("totalFreeBytes", d == null ? null : d.totalFreeBytes);
                diskSummary.put("totalUsageRate", d == null ? null : d.totalUsageRate);
                diskSummary.put("totalUsage", d == null || d.totalUsageRate == null ? null : SystemMetricsUtil.formatPercent(d.totalUsageRate.doubleValue()));
                diskSummary.put("maxUsageMount", d == null ? null : d.maxUsageMount);
                diskSummary.put("maxUsageRate", d == null ? null : d.maxUsageRate);
                diskSummary.put("maxUsage", d == null || d.maxUsageRate == null ? null : SystemMetricsUtil.formatPercent(d.maxUsageRate.doubleValue()));
                report.put("diskSummary", diskSummary);
            }

            boolean pass = (sys != null && !sys.isEmpty())
                    && (cpu != null && !cpu.isEmpty())
                    && (disk != null && !disk.isEmpty())
                    && (io != null && !io.isEmpty())
                    && (net != null && !net.isEmpty());
            report.put("pass", pass);

            System.out.println(CJson.toJson(report));
        }
        catch (Throwable err)
        {
            err.printStackTrace();
        }
    }
}
