package bap.udf;

import cell.CellIntf;

/**
 * 当调试代码时，真正attach到服务端的构建器是UDfInvokerCellBuilder 而构建出来并传递给服务端进行调用的则是该类
 */
public interface IUdfInvoker extends CellIntf
{
    public UdfMeta getMeta();
    
    public Object invoke(Object... params) throws Exception;
}
