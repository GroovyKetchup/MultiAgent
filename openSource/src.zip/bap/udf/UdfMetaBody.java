package bap.udf;

import java.io.Serializable;
import java.util.List;

import com.leavay.common.util.cjson.CJson;
import com.leavay.ms.tool.CmnUtil;

import cmn.util.NullUtil;


public class UdfMetaBody implements Serializable
{
    String desc;
    
    String returnType;
    
    List<UdfMetaArg> lstArgs;
    
    List<String> lstExceptions;

    public String toJson()
    {
        return CJson.toJson(this);
    }
    
    public static UdfMetaBody fromJson(String s) throws Exception
    {
        return (UdfMetaBody) CJson.fromJson(s);
    }

    public String getDesc()
    {
        return desc;
    }

    public void setDesc(String desc)
    {
        this.desc = desc;
    }

    public List<String> getLstExceptions()
    {
        return lstExceptions;
    }

    public void setLstExceptions(List<String> lstExceptions)
    {
        this.lstExceptions = lstExceptions;
    }

    public String getReturnType()
    {
        return returnType;
    }

    public void setReturnType(String returnType)
    {
        this.returnType = returnType;
    }

    public List<UdfMetaArg> getLstArgs()
    {
        return lstArgs;
    }

    public void setLstArgs(List<UdfMetaArg> lstArgs)
    {
        this.lstArgs = lstArgs;
    }
    
    public UdfMetaArg getArgument(String name)
    {
        for (UdfMetaArg arg : NullUtil.get(lstArgs))
        {
            if (CmnUtil.isStringEqual(name, arg.getName()))
                return arg;
        }
        
        return null;
    }
    
    public String toString()
    {
        return getDesc()+" - ("+NullUtil.get(getLstArgs())+")";
    }
}
