package bap.udf;

import bap.cells.CellBuilderIntf;
import cell.CellIntf;

public class UdfInvokerCellBuilder implements CellBuilderIntf
{
    private transient Class udfClass;
    
    private transient CUdfInoker invoker;
    
    public UdfInvokerCellBuilder(Class udfClass, UdfMeta meta) throws Exception
    {
        this.udfClass = udfClass;
        invoker = new CUdfInoker(udfClass, meta);
    }

    public String getInterfaceClass()
    {
        return udfClass.getName();
    }

    public String getImplementClass()
    {
        return udfClass.getName();
    }

    public CellIntf buildCell(Object... params) throws ClassNotFoundException, Exception
    {
        return invoker;
    }

}
