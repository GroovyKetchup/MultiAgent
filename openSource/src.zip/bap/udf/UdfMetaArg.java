package bap.udf;

import java.io.Serializable;

import com.leavay.ms.tool.CmnUtil;

public class UdfMetaArg implements Serializable
{
    private static final long serialVersionUID = -7850820236154261890L;
    
    public String name;
    public String fullClass;
    public String desc;
    
    public String getName()
    {
        return name;
    }
    public UdfMetaArg setName(String name)
    {
        this.name = name;
        return this;
    }
    
    public String getFullClass()
    {
        return fullClass;
    }
    public UdfMetaArg setFullClass(String fullClass)
    {
        this.fullClass = fullClass;
        return this;
    }
    
    public String getDesc()
    {
        return desc;
    }
    public UdfMetaArg setDesc(String desc)
    {
        this.desc = desc;
        return this;
    }
    
    public String toString()
    {
        return CmnUtil.getNameAndLabel(getName(), getDesc())+" - " +CmnUtil.getSimpleClassName(getFullClass());
    }
}
