package bap.udf;

import bap.java.CodeMeta;

/**
 * UDF 的Meta比较特殊，每次要根据UDF实际编译解析得来的compileMeta + 库中存的ResFile里的Meta，合并得来
 * 
 * 而在Eclipse开发端，则要用反射解析出来的CompileMeta + Eclipse下载过去的资源文件，合并得来
 *
 *到了界面上看到的整合好以后，保存也是一体保存，但读取时每次又要合并
 */
public class UdfMeta extends CodeMeta
{
    private static final long serialVersionUID = 2282061473179330782L;

    public UdfMeta()
    {
        super();
    }
    
    public UdfMeta(UdfMetaBody body)
    {
        this();
        setMetaBody(body);
    }
    
    public void setMetaBody(UdfMetaBody meta)
    {
        setMeta(meta==null?null:meta.toJson());
    }
    
    public UdfMetaBody getMetaBody() throws Exception
    {
        return UdfMetaBody.fromJson(getMeta());
    }
}
