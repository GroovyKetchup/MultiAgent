package bap.udf;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.jdt.internal.compiler.ClassFile;
import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
import org.eclipse.jdt.internal.compiler.ast.Argument;
import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
import org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
import org.eclipse.jdt.internal.compiler.ast.TypeReference;
import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
import org.eclipse.jdt.internal.compiler.lookup.VoidTypeBinding;

import com.leavay.common.util.SrvRes;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.common.util.javac.CodeUtil;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.LvCompileUnit;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.common.util.javac.LvJavac.LvCompileResult;
import com.leavay.ms.tool.CmnUtil;

import bap.java.CJavaCode;
import bap.java.CodeMeta;
import bap.md.java.CJavaCodeDo;
import cell.UdfIntf;
import cmn.util.NullUtil;

public class CUdfUtil
{
    //UDF库里所有类（包括测试类），都没有临时编译文件，只能每次临时编译
    public static UdfMeta compileAndLoadCode(LvClassLoader loader, CJavaCode code) throws Exception
    {
        return compileAndLoadCode(loader, code.getCode(), code.getFilePath(), code.getFileEncoding());
    }

    public static UdfMeta compileAndLoadCode(LvClassLoader loader, CJavaCodeDo code) throws Exception
    {
        return compileAndLoadCode(loader, code.getCode(), code.getFilePath(), code.getFileEncoding());
    }

    public static UdfMeta compileAndLoadCode(LvClassLoader loader, String codeText, String codePath, String encoding) throws Exception
    {
        LvJavac tmpCompiler = new LvJavac();
        tmpCompiler.setClassLoader(loader);
        tmpCompiler.optIsGenerateClass = false;

        List<ICompilationUnit> lst = new ArrayList<ICompilationUnit>();
        ICompilationUnit unit = new LvCompileUnit(codeText.toCharArray(), codePath, CmnUtil.isStringEmpty(encoding) ? "UTF-8" : encoding);
        lst.add(unit);

        
        LvCompileResult result = tmpCompiler.compile(false, lst);
        for (ClassFile clsF : result.getOneResult().getClassFiles())
        {
            String name = LvJavac.getCompoundName(clsF.getCompoundName());
            byte[] byteCode = LvJavac.saveClassFile(clsF, name);
            loader.addClassByte(name, byteCode);//loader.loadClass("udf.my.NewUdf").getMethods()
        }
        
        return loadUdfMeta(result.getLvJavac().getOneCompilationUnit());
    }
    
    public static UdfMeta loadUdfMeta(CompilationUnitDeclaration mainUnit) throws Exception
    {
        TypeDeclaration typeDec = mainUnit.types[0];
        AbstractMethodDeclaration[] mths = typeDec.methods;
        
        MethodDeclaration exeMethod = null;
        for (AbstractMethodDeclaration mth : mths)
        {
            if (mth instanceof MethodDeclaration)
            {
                MethodDeclaration method = (MethodDeclaration)mth;
                String name = new String(method.selector);
                if (ToolUtilities.isStringEqual(name, UdfIntf.MAIN_METHOD))
                {
                    if (exeMethod != null)
                        throw new Exception(SrvRes.getString("Found more than one method named")+" : " + UdfIntf.MAIN_METHOD);
                    exeMethod = method;
                }
            }
        }
        
        if (exeMethod == null)
            throw new Exception(SrvRes.getString("Please define main function entry")+" : " +UdfIntf.MAIN_METHOD);
        
        CodeDeclareInfo methodInfo = CodeDeclareInfo.convert(typeDec, exeMethod);
        if (!methodInfo.isPublic())
            throw new Exception(SrvRes.getString("Main function entry must be public") + " : " + UdfIntf.MAIN_METHOD);
        if (methodInfo.isStatic())
            throw new Exception(SrvRes.getString("Main function entry shouldn't be static") + " : " + UdfIntf.MAIN_METHOD);
        
        UdfMetaBody meta = new UdfMetaBody();
        if (exeMethod.returnType == null && exeMethod.returnType.resolvedType != null)
            meta.setReturnType(null);
        else
        {
            TypeBinding retType = exeMethod.returnType.resolvedType;
            if (retType instanceof VoidTypeBinding)
                meta.setReturnType(null);
            else
            {
                // 校验是否可序列化
                if (!retType.isBaseType())
                {
                    // 数组则取其元素的类型来判断
                    if (retType.isArrayType())
                        retType = retType.leafComponentType();

                    if (!retType.isBaseType())
                    {
                        String className = new String(retType.readableName());
                        try
                        {
                            Class clazz = ClassFactory.loadClass(className);
                            if (!clazz.equals(Object.class) && !Serializable.class.isAssignableFrom(clazz))
                                throw new Exception(SrvRes.getString("Return type must be serializable") + " : " + className);
                        }catch (Throwable err)
                        {
                            ToolUtilities.warnAndOutput("UDF Util", "Unknown type if its serializable : " + className);
                        }
                    }
                }
                
                CodeDeclareInfo returnType = CodeDeclareInfo.convert(exeMethod.returnType);
                meta.setReturnType(returnType.getMyType());
            }
        }
        
        // 解析参数及类型
        List<UdfMetaArg> args = new ArrayList();
        if (exeMethod.arguments != null)
        {
            for (Argument arg : exeMethod.arguments)
            {
                String argName = new String(arg.name);
                TypeReference type = arg.type;
                TypeBinding typeBind = arg.type.resolvedType;
                String argClass = new String(typeBind.qualifiedPackageName())+"."+new String(typeBind.qualifiedSourceName());

                CodeDeclareInfo decInfo = CodeDeclareInfo.convert(arg);
                args.add(new UdfMetaArg().setName(decInfo.getName()).setFullClass(decInfo.getMyType()));
            }
            meta.setLstArgs(args);
        }
        
        return new UdfMeta(meta);
    }
    
    /**
     * 尝试通过反射的方式获取参数名以及meta，这个只用于Eclipse端未提交的UDF
     * 
     * 如果失败或者找不到，则随便取个名字：p1, p2 ....
     */
    public static UdfMeta tryLoadUdfMeta(Class udfClass)
    {
        for (Method mth : udfClass.getMethods())
        {
            if (!UdfIntf.MAIN_METHOD.equals(mth.getName()))
                continue;

            UdfMetaBody meta = new UdfMetaBody();
            if (mth.getReturnType() != null)
                meta.setReturnType(mth.getReturnType().getName());

            if (mth.getParameterCount() > 0)
            {
                String[] names = null;
                try
                {
                    names = CodeUtil.getMethodParamNames(mth);
                } catch (Throwable err)
                {
                }
                
                if (names == null)
                {
                    names = new String[mth.getParameterCount()];
                    for (int i = 0; i < names.length; i++)
                    {
                        names[i] = "p" + i;
                    }
                }

                List<UdfMetaArg> lstArgs = new LinkedList<UdfMetaArg>();
                for (int i = 0; i < mth.getParameterCount(); i++)
                {
                    UdfMetaArg arg = new UdfMetaArg();
                    arg.setName(names[i]);
                    arg.setFullClass(mth.getParameterTypes()[i].getName());
                    lstArgs.add(arg);
                }
                meta.setLstArgs(lstArgs);
            }
            return new UdfMeta(meta);
        }

        return null;
    }

    // UDF的扩展Meta暂时就以最简单的SJsonMap存储了参数的附加描述，由外部来实现更复杂的
    /**
     * 将编译得来的meta和库存meta合并
     * 
     * @param compileMeta : 来自于代码编译解析的基础meta
     * @param extMeta ：扩展的meta信息，来自于.meta的资源文件（主控端来自ResFileDo，Eclipse端来自.meta文件）
     * @return
     */
    public static UdfMeta mergeMeta(UdfMeta compileMeta, CodeMeta extMeta) throws Exception
    {
        if (compileMeta == null)
            compileMeta = new UdfMeta();
        
        if (extMeta == null)
            return compileMeta;
        
        // 附加Meta从数据库来，merge到对象中
        UdfMetaBody doBody = UdfMetaBody.fromJson(extMeta.getMeta());
        UdfMetaBody cmpBody = compileMeta.getMetaBody();
        if (doBody != null)
        {
            cmpBody.setDesc(doBody.getDesc());
            for (UdfMetaArg arg : NullUtil.get(cmpBody.getLstArgs()))
            {
                UdfMetaArg doArg = doBody.getArgument(arg.getName());
                if (doArg != null)
                    arg.setDesc(doArg.getDesc());
            }
        }
        compileMeta.setMetaBody(cmpBody);
        return compileMeta;
    }
}
