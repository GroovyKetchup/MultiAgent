package bap.udf;

import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.BasicCell;
import bap.cells.BasicUdf;
import cell.UdfIntf;

public class CUdfInoker extends BasicCell implements IUdfInvoker
{
    BasicUdf udfInstance;
    UdfMeta meta;
    
    public CUdfInoker(Class udfClass, UdfMeta meta) throws Exception
    {
        CmnUtil.assertNotNull(udfClass, "UDF class is null");
        CmnUtil.assertTrue(CmnUtil.isInheritFrom(udfClass, BasicUdf.class), "UDF class should be inherited from "+BasicUdf.class);

        udfInstance = (BasicUdf) ToolUtilities.newObject(udfClass);
        this.meta = meta;
    }

    public UdfMeta getMeta()
    {
        return meta;
    }
    
    public Object invoke(Object... params) throws Exception
    {
        return ToolUtilities.callFunction(udfInstance, UdfIntf.MAIN_METHOD, params);
    }

    public BasicUdf getUdfInstance()
    {
        return udfInstance;
    }

    public void setUdfInstance(BasicUdf udfInstance)
    {
        this.udfInstance = udfInstance;
    }
    
    public String toString()
    {
        return super.toString()+" - {" + getUdfInstance()+ "}";
    }

}
