package bap.cells;

public class NullCellBuilderException extends Exception
{
    private static final long serialVersionUID = 2423096810707660544L;

    public NullCellBuilderException(String msg)
    {
        super(msg);
    }
}
