package bap.cells.exception;

// 这个异常通常是外部调用代码本身已经老了，例如一些脚本或调试代码，编译时的loader较老，当插件发布后返回的新对象的类冲突了
// 一般发生这种情况，只要重新执行调试，使脚本或调试代码得到最新的编译，即可排除
public class ClassLoaderConflictException extends RuntimeException
{
    private static final long serialVersionUID = -9124840693687915665L;

    public ClassLoaderConflictException(ClassLoader expectedLoader, Object objectRet)
    {
        super("Found conflict cell class error! Expected Loader = "+expectedLoader+"\nCurrent Cell = " + objectRet+" [Cell Loader = "+objectRet.getClass().getClassLoader()+"]");
    }
    
    public ClassLoaderConflictException(String msg, Throwable err)
    {
        super(msg, err);
    }
}
