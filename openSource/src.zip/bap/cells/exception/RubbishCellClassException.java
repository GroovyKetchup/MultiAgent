package bap.cells.exception;

/**
 * 出现这种异常比较正常，就是在插件发布，全局类工厂已经得到了更新，而CELL体系中的各种缓存的的singleton还没来得及清理（会有一些延迟，后台清理）
 * 这个间隙中如果访问这些脏的cell，则会校验出类不兼容，并抛出此异常
 * 
 * 通常等待一会儿，等所有缓存的CELL（插件体系中的）都得到了清理之后再去访问，此异常就会消失
 *
 */
public class RubbishCellClassException extends RuntimeException
{
    private static final long serialVersionUID = -9124840693687915665L;

    public RubbishCellClassException(ClassLoader factoryLoader, Object cell)
    {
        super("Cell class is incompatible with global class factory. Try again after a while or try to republish plugin again!\nFactory Loader = "+factoryLoader+"\nRubbish Cell = " + cell+" [Cell Loader = "+cell.getClass().getClassLoader()+"]");
    }
    
    public RubbishCellClassException(String msg, Throwable err)
    {
        super(msg, err);
    }
}
