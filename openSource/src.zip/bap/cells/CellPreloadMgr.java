package bap.cells;

import com.leavay.client.util.CmnEvent.CmnRunnable;
import com.leavay.client.util.CmnEvent.EThreadPool;
import com.leavay.common.util.ToolUtilities;

import cell.CellPreloadIntf;

public class CellPreloadMgr
{
    public static synchronized CellPreloadMgr getMe()
    {
        if (_me == null)
        {
            _me  = new CellPreloadMgr();
        }
        return _me;
    }
    
    private static CellPreloadMgr _me;
    
    protected EThreadPool _pool = new EThreadPool("Preload Cell", 0, 2, false);
    private CellPreloadMgr()
    {
    }
    
    public void preloadCell(final Class<? extends CellPreloadIntf> cellClass)
    {
        _pool.run(new CmnRunnable()
        {
            public void run()
            {
                try
                {
                    CellPreloadIntf cell = Cells.get(cellClass);
                }catch (Throwable err)
                {
                    ToolUtilities.error("CellPreloadMgr", "Failed to preload Cell : " +cellClass.getName());
                }
            }
        });
    }
}
