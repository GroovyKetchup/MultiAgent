package bap.cells;

import java.net.URI;
import java.util.Map;

import com.leavay.nio.crpc.Pingable;

/**
 * 给调试端提供服务的，在主控或任何bap代理启动时都会启动
 */
public interface ServerCellService extends Pingable
{
    /**
     * 远端（调试器）启动，远程注册拦截目标Cell以及过滤器，并将远端Cell注册进来
     * 
     * @param cls ：监听的目标Cell接口类名
     * @param rmtCell ：远端Cell构造器（Callback对象）
     */
    public void attachRemoteBuilder(RmtCellBuilderIntf rmtBuilder) throws Exception;
    

    /**
     * 查询服务端已经注册了的远程调试器（CELL Builder）
     * @return key:service, Value:RmtCellBuilderInfo 或者Exception
     */
    public Map<String, Object> queryRemoteBuilder() throws Exception;
    

    /**
     * 强行踢掉其它人占用的远程调试
     * 
     * 如果对方拒绝被踢，那么会抛出DenyApplyKickout异常
     * 
     * forceKick 如果为true，则强行剔除，不询问不等待（适用于僵尸连接）
     */
    public void kickoutRemoteBuilder(String otherUser, String intf, boolean forceKick) throws DenyApplyKickout;
    

    /**
     * 获取默认的服务端CELL
     * @param cls
     * @param params
     * @return
     */
    public Object getCell(String cls, Object ... params) throws Exception;
    
    /**
     * 接口类名，拿服务端Cell（Callback）对象
     * 
     * @param cls
     * @return
     */
    public Object getCell(boolean verifyClassCompatible, String cls, Object ... params) throws Exception;
    

    /**
     * 判断一个类名是否注册在案的细胞接口类
     */
    public boolean isValieCell(String cls);
    
    
    /**
     * Cell的server可能是代理也可能是主控，可能是dao的主控也可能是dao的follower，所以要找到真正插件的来源地址
     */
    public URI getPluginServer();
    
}
