package bap.cells;

// 简单服务CELL，无启停特定动作
public class SimpleServiceCell extends BasicServiceCell
{

    @Override
    protected void doStartService() throws Exception
    {

    }

    @Override
    protected void doStopService()
    {

    }

}
