package bap.cells;

import java.io.Serializable;

public class RmtCellBuilderInfo implements Serializable
{
    private static final long serialVersionUID = -3764437919432697221L;

    String host;

    String user;

    // 从服务端侦测到远端的地址
    String clientAddress;

    public String getHost()
    {
        return host;
    }

    public RmtCellBuilderInfo setHost(String host)
    {
        this.host = host;
        return this;
    }

    public String getUser()
    {
        return user;
    }

    public RmtCellBuilderInfo setUser(String user)
    {
        this.user = user;
        return this;
    }

    public String getClientAddress()
    {
        return clientAddress;
    }

    public void setClientAddress(String clientAddress)
    {
        this.clientAddress = clientAddress;
    }

    public String toString()
    {
        return user + " (" + host + "=" + clientAddress + ")";
    }
}
