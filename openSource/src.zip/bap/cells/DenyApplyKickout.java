package bap.cells;

public class DenyApplyKickout extends Exception
{

    private static final long serialVersionUID = -479051951803793487L;

    public DenyApplyKickout(String msg)
    {
        super(msg);
    }
}
