package bap.cells;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.dom4j.Element;

import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

/**
 * 这是默认的细胞配置适配器，完成加载保存等动作
 * 默认是从本地conf/cell.config中加载细胞配置信息
 */
public class CellConfigAdapter
{

    public final static String FILE_CONFIG = "conf/cell.config";
    
    
    // key=Class Name
    public final static String XML_CONF_CLASS="config_class";
    public final static String XML_ITEM_VALUE="value";
    public static Element toXml(String cellClass, CellConfig cfg)
    {
        if (cfg == null)
        return null;

        Element ele = ToolUtilities.newDom4jRoot(cellClass);
        ele.setAttributeValue(XML_CONF_CLASS, cfg.getClass().getName());
        List<Field> lstF = ToolUtilities.getAllField(cfg.getClass(), false);
        if (lstF != null)
            for (Field f : lstF)
            {
                if (!ConfigFactory.isConfigField(f))
                    continue;
                
                String value = ToolUtilities.getString(ToolBasic.getFieldValue(cfg, f), null);
                if (!CmnUtil.isStringEmpty(value))
                {
                    Element eleItem = ToolUtilities.newDom4jRoot( f.getName());
                    eleItem.setAttributeValue(XML_ITEM_VALUE, value);
                    ele.add(eleItem);
                }
            }
        
        return ele.nodeCount()<=0?null:ele;
    }

    public static String saveConfigXml(Map<String, CellConfig> configs) throws Exception
    {
        Element eleRoot = ToolUtilities.newDom4jRoot("cells");
        if (configs != null)
            for (Entry<String, CellConfig> ent : configs.entrySet())
            {
                Element eleCfg = toXml(ent.getKey(), ent.getValue());
                if (eleCfg != null)
                    eleRoot.add(eleCfg);
            }
        
        String sFile = ToolUtilities.XML_UTF8_HEADER;
        sFile+="\n"+ToolUtilities.xmlDom4j2String(eleRoot);
        
        return sFile;
        
    }
    
    public void saveConfigFile(Map<String, CellConfig> configs) throws Exception
    {
        ToolUtilities.saveFile(FILE_CONFIG, saveConfigXml(configs), "UTF-8", false);
    }
    

    public static HashMap<String, String> fromXml(Element eleOneCell)
    {
        HashMap<String, String> mapConf = new HashMap<String, String>();
        
        String cfgClass = eleOneCell.attributeValue(XML_CONF_CLASS);
        if (eleOneCell.nodeCount() >= 0)
            for (Element eleItem : (List<Element>)eleOneCell.elements())
                {
                    String f = eleItem.getName();
                    String v = eleItem.attributeValue(XML_ITEM_VALUE, null);
                    if (!CmnUtil.isStringEmpty(v))
                        mapConf.put(ConfigFactory.getConfigKey(cfgClass, f), v);
                }
        
        return mapConf;
    }
    
    // 加载本地配置文件，合并成property返回
    public HashMap<String, String> loadConfigProps() throws Exception
    {
        HashMap<String, String> mapConf = new HashMap<String, String>();
        if (!new File(FILE_CONFIG).canRead())
            return mapConf;

        String sxml = ToolUtilities.readFile(FILE_CONFIG, "UTF-8");
        if (!CmnUtil.isStringEmpty(sxml))
        {
            Element eleRoot = ToolUtilities.xmlString2Element(sxml);
            for (Element ele : (List<Element>) eleRoot.elements())
            {
                HashMap<String, String> mapOne = fromXml(ele);
                if (!mapOne.isEmpty())
                    mapConf.putAll(mapOne);
            }
        }
        return mapConf;
    }
}
