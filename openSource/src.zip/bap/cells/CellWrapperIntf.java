package bap.cells;

import cell.CellIntf;

// 用于包裹Cell，实现Hook的包装器
public interface CellWrapperIntf
{
    public CellIntf getRealCell();
}
