package bap.cells;

import crpc.CRpcCallbackForeverIntf;
import crpc.CRpcCallbackIntf;

public interface RmtCellBuilderIntf extends CRpcCallbackIntf, CRpcCallbackForeverIntf, CellBuilderIntf
{
    // 服务端通过此方法回调，获取注册请求方的一些信息（如用户、主机名等）
    public RmtCellBuilderInfo getRemoteInfo();
    
    // 其他用户请你申请踢出你的连接，他想要接管相关接口的调试
    public boolean applyKickout(String serviceInterface, RmtCellBuilderInfo otherClient);
    
    // 带条件的远程builder才有意义
    public default boolean isMatch(Object... params)
    {
        return true;
    };
}
