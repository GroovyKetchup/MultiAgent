package bap.cells;

import java.io.Serializable;

/**
 * 使用Cell的配置框架，需要定义配置类POJO，派生于此类
 * 在Cell的接口头部用@Config注解指向对应的配置类，例如在CRedis中，头部申明@Config(IRedisConfig.class)
 * 
 * Config定义类本身不需要继承任何类，申明的配置项都必须是静态即可
 * 
 * 
 *  要求配置项字段必须只能是基础类型：数字、String、boolean等
 *  配置项字段最好都有默认值
 *  配置项字段必须是public的
 *
 */
public class CellConfig implements Serializable
{
    private static final long serialVersionUID = 2510281499822151179L;
    
    public String toString()
    {
        return getClass().getName();
    }
}
