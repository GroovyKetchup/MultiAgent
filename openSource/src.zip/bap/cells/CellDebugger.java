package bap.cells;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 将某个Cell设置调试专用，通常只用于细胞核，申明在头部
 * 
 * 可以在启动调试器时自动扫描到并注册到本地，从而接管某些特定操作在本地模拟
 * 
 * 例如分布式锁，为了降低调试对服务环境的破坏，就实现了调试专用细胞核
 * 
 * 主要用于测试、调试等l
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface CellDebugger{
   boolean value() default true;
}
