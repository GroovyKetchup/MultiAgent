package bap.cells;

import cell.UdfIntf;

/**
 * 所有UDF必须派生于此类，以此作为基类，再申明一个名为execute的方法作为主入口即可
 * 所有UDF的包名必须是以"udf"开头，以便能被扫描到并自动注册到系统中
 * 
 * UDF 对外接口必须是唯一的以“execute”命名的方法，传递的参数以及返回结果都必须是可序列化的
 * UdfIntf.MAIN_METHOD = "execute";
 * 
 * 如果需要传递回调对象，那么与CELL的接口规范一样，可以传递CELL或其它回调对象（BasicCallback的子类）
 * 若参数内还需要通过字段以及子孙字段传递回调对象，则需@CRpcContainer注解的类对象
 *
 */
public class BasicUdf extends BasicCell implements UdfIntf
{

}
