package bap.cells;

import java.util.concurrent.locks.ReentrantLock;

import cell.ServiceCellIntf;
import cmn.util.AutoLock;

public abstract class BasicServiceCell extends BasicCell implements ServiceCellIntf
{
    protected transient volatile boolean _started = false;
    transient ReentrantLock _lockStart = new ReentrantLock();
    
    public boolean isStarted()
    {
        return _started;
    }

    public synchronized void startService() throws Exception
    {
        try (AutoLock lc = AutoLock.lock(_lockStart))
        {
            if (isStarted())
                return;
            
            // 启动默认就会重新加载缓存
            resetConfig();
            
            doStartService();
            
            _started = true;
        }
    }

    public synchronized void stopService()
    {
        try (AutoLock lc = AutoLock.lock(_lockStart))
        {
            if (!isStarted())
                return;

            // 关停动作内部如果有异常，自行记录日志并设法保证关停动作一次性成功结束，反复关停失败可能会导致残留
            doStopService();
            
            // 关停默认会清空缓存
            resetConfig();
            
            _started = false;
        }
    }
    
    // 子类重载此函数实现真正的启动动作
    abstract protected void doStartService() throws Exception;
    
    // 子类重载此函数实现真正的关停动作
    // 自行记录日志并设法保证关停动作一次性成功结束
    // 反复关停失败可能会导致残留
    abstract protected  void doStopService();

}
