package bap.cells.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 申明Cell的默认配置类, 需派生于 CellConfig
 * 配置类以POJO的形式，细胞工厂中会有配置工厂负责装配配置类的值，包名+类名+字段名对应配置文件中的key
 * 
 * 可参考CUdfConfig
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface Config {

    Class value();

}
