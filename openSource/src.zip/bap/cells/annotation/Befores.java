package bap.cells.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 在Cell的实现类中，可以申明某个方法[成功]执行后的Hook
 * 指向一个类，派生于CellHookIntf接口的类，例如：CellHookPrinter
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
@Documented
public @interface Befores {
    Before[] value();
}
