package bap.cells.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 在Cell的实现类（加在接口上无效）中，可以申明某个方法执行前的Hook
 * 指向一个类，派生于CellHookIntf接口的类，例如：CellHookPrinter
 * 
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
@Repeatable(Befores.class)
@Documented
public @interface Before {

    Class<?> value();
}
