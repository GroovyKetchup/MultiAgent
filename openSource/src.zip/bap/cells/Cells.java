package bap.cells;

import java.util.List;
import java.util.Set;

import com.leavay.ms.tool.CmnUtil;

import bap.cells.exception.ClassLoaderConflictException;

public class Cells
{
    /**
     * 所有Cell必须在cell包之下，才会被自动扫描注册
     * 而且整个派生路径上的类（接口）都必须在cell包下，否则找不全
     */
    public final static String CELL_PACKAGE = "cell";
    
    // 所有Cell接口，打头字母
    public final static String CELL_PREFIX = "I";
    
    public static class CellFactoryUninitException extends RuntimeException
    {
        private static final long serialVersionUID = 1L;
        public CellFactoryUninitException()
        {
            super("Please initialize cell factory first. For Example : Start cell server, start BAP Debugger or extend BAP Tester");
        }
    }
    
    /**
     * 包名是否符合CELL自动注册的要求，要么是cell，要么是cell.开头的包名
     */
    public static boolean isCellPackage(String pkg)
    {
        return pkg != null && (pkg.equals(CELL_PACKAGE) || pkg.startsWith(CELL_PACKAGE + '.'));
    }
    
    public final static CellFactory NULL_FACTORY = new CellFactory()
    {
        public boolean isValieCell(String cls)
        {
            return false;
        }

        public Object getCell(String clsName, Object... params) throws Exception
        {
            throw new CellFactoryUninitException();
        }
        
        public Object getCell(boolean verifyClassCompatible, String clsName, Object... params) throws Exception
        {
            throw new CellFactoryUninitException();
        }

        public ConfigFactoryIntf getConfigFactory()
        {
            throw new CellFactoryUninitException();
        }

        public List<String> getGlobalBefore()
        {
            throw new CellFactoryUninitException();
        }

        public void setGlobalBefore(List<String> _globalBefore)
        {
            throw new CellFactoryUninitException();
        }

        public List<String> addGlobalBefore(String hookClass)
        {
            throw new CellFactoryUninitException();
        }

        public List<String> getGlobalAfter()
        {
            throw new CellFactoryUninitException();
        }

        public void setGlobalAfter(List<String> globalAfter)
        {
            throw new CellFactoryUninitException();
        }

        public List<String> addGlobalAfter(String hookClass)
        {
            throw new CellFactoryUninitException();
        }

        public Set<String> getAllCells()
        {
            throw new CellFactoryUninitException();
        }
    };


    // 默认空厂（当功能无效，没有初始化Server工厂或client工厂时使用）
    private static CellFactory _factory = NULL_FACTORY;
    
    public static synchronized CellFactory getFactory()
    {
        return CmnUtil.assertNotNull(_factory, "Should init cell factory when start");
    }

    public static synchronized  void setFactory(CellFactory factory)
    {
        Cells._factory = factory;
    }

    public static boolean isValidFactory()
    {
        return _factory != NULL_FACTORY && _factory != null;
    }
    
    public static boolean isValidCell(String intfClass)
    {
        return getFactory().isValieCell(intfClass);
    }

    public static Object get(String clsName, Object ... params)
    {
        try
        {
            return getFactory().getCell(clsName, params);
        } catch (Exception exp)
        {
            CmnUtil.throwRuntimeException(exp);
            return null;
        }
    }
    
    public static <T> T get(Class<T> cls, Object ... params)
    {
        Object obj = get(cls.getName(), params);

        if (obj != null && !cls.isInstance(obj))
            throw new ClassLoaderConflictException(cls.getClassLoader(), obj);
            
        return (T)obj;
    }
    

    // 不校验版本兼容性
    public static <T> T unsafeGet(Class<T> cls, Object ... params)
    {
        Object obj = unsafeGet(cls.getName(), params);

        return (T)obj;
    }
    
    // 不校验版本兼容性
    public static Object unsafeGet(String clsName, Object ... params)
    {
        try
        {
            return getFactory().getCell(false, clsName, params);
        } catch (Exception exp)
        {
            CmnUtil.throwRuntimeException(exp);
            return null;
        }
    }
    
    public static CellConfig getConfig(Class cellClass)
    {
        return getFactory().getConfig(cellClass);
    }
    
    public static Object tryGet(String clsName, Object ... params)
    {
        try
        {
            return getFactory().getCell(clsName, params);
        } catch (Exception err)
        {
            return null;
        }
    }
}
