package bap.cells;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 设置CELL实现类的级别（高级别可以覆盖低级别），在同一个接口有多个实现类时，可根据注解级别进行相互覆盖
 * 
 * 只适用于实现类注解，主要是用于系统内置CELL间的覆盖优先级，不注解默认为NORMAL
 * 这个级别只在同级CELL之间有效，系统CELL之间、插件CELL之间。而插件CELL整体优先于系统CELL的特性是固定的，不受此控制
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface CellLevel{
   int value() default LEVEL_NORMAL;
   
   final static int LEVEL_BASIC = 0;

   final static int LEVEL_NORMAL = 50;
   final static int LEVEL_HIGH = 100;
}
