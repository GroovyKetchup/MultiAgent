package bap.cells;

import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.tools.ant.taskdefs.Classloader;
import org.reflections.Reflections;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import org.reflections.util.FilterBuilder;

import com.leavay.common.Exception.MultipleException;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassGraphUtil;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CallbackUtil;

import cell.CellIntf;
import cmn.util.Nulls;

public class CellFinder
{
    /**
     * @param ignoreDisable
     *            是否略过打了Disable标签的CELL（包括接口、实现）
     * @param ignoreConflict
     *            是否忽略冲突的实现，对于同一个接口如果出现多个实现，将随机覆盖
     */
    public static Set<Class> getAllCellClasses(ClassLoader loader)
    {
        Set<URL> setUrl = ClasspathHelper.forPackage(Cells.CELL_PACKAGE, loader);
        if (loader instanceof URLClassLoader)
        {
            URL[] urls = ((URLClassLoader) loader).getURLs();
            if (urls != null)
                for (URL url : urls)
                    setUrl.add(url);
        }
        FilterBuilder fb = new FilterBuilder();
        fb.includePackage(Cells.CELL_PACKAGE);

        long time = System.currentTimeMillis();
        Reflections newRef = new Reflections(new ConfigurationBuilder().addClassLoader(loader).addUrls(setUrl).filterInputsBy(fb));

        Set<Class> lstCls = (Set) newRef.getSubTypesOf(CellIntf.class);
        CmnUtil.out("Finish load all cells : " + (System.currentTimeMillis() - time) + "(ms) = " + ToolBasic.logString(lstCls, false));

        if (loader instanceof LvClassLoader)
        {
            Set<String> setNames = ((LvClassLoader) loader).getCachedClassData().keySet();
            for (String s : setNames)
            {
                if (!Cells.isCellPackage(s))
                    continue;

                try
                {
                    lstCls.add(loader.loadClass(s));
                } catch (ClassNotFoundException exp)
                {
                    // ignore
                }
            }
        }

        return lstCls;
    }
    

    /**
     * 新的类扫描方式，但是这种方式对于一些实现类中的匿名类会遗漏，如：
     * Missed class : class cell.function.CConsumer$1
        Missed class : class cell.function.CSupplier$1
        Missed class : class cell.function.CFunction$1
        Missed class : class cell.function.CBiConsumer$1
        Missed class : class cell.function.CBiFunction$1
     *
     *
     * 
     * @param ignoreDisable
     *            是否略过打了Disable标签的CELL（包括接口、实现）
     * @param ignoreConflict
     *            是否忽略冲突的实现，对于同一个接口如果出现多个实现，将随机覆盖
     */
    public static Set<Class> getAllCellClasses_Disable(ClassLoader loader) // ClassGraphUtil好像有不是放文件的问题
    {
        long time = System.currentTimeMillis();
        Map<String, ClassNameInfo> map = ClassGraphUtil.searchSubClass(CellIntf.class, Cells.CELL_PACKAGE, loader);
        CmnUtil.out("Finish load all cells : " + (System.currentTimeMillis() - time) + "(ms) = " + ToolBasic.logString(map.values(), false));
        

        Set<Class> setRet = new HashSet<Class>();
        for (ClassNameInfo info : Nulls.get(map).values())
        {
            try
            {
                setRet.add(ClassFactory.loadClass(info.getClassFullName()));
            }catch (Throwable err)
            {
                ToolUtilities.error("Cell Finder", "Failed to load cell class : " + info.getClassFullName()+" -> " + err.getMessage(), err);
            }
        }
        
        try
        {
            ClassFactory.searchDynamicSubClass(setRet, loader, CellIntf.class);
        } catch (ClassNotFoundException exp)
        {
            ToolUtilities.error("Cell Finder", "Failed to load dynamic class from loader", exp);
        }

        // 是否调试打印：比对新老扫描结果集，看新的扫描方式有无遗漏
        if (MppContext.getBoolean("com.bap.cellfinder.debug.compare.reflections.enable", false))
            compareWithOrg(loader, setRet);
        
        return setRet;
    }
    
    public static void compareWithOrg(ClassLoader loader, Set<Class> setNew)
    {
        Set<Class> setOrg = getAllCellClasses(loader);
        for (Class cls : setOrg)
        {
            if (setNew.contains(cls))
                continue;
            
            System.err.println("Missed class : " + cls);
        }
        
    }

    /**
     * 从类加载器中分析Cell接口、实现
     * 
     * @param loader
     *            目标类加载器
     * @param ignoreManul
     *            是否忽略掉打了Manul标签的
     * @param ignoreDebugger
     *            是否忽略掉打了Debug标签的
     * @param ignoreConflict
     *            遇到同级CELL冲突（FALSE=重复注册会报错）
     */
    public static Map<Class, CellBuilderIntf> loadCellsMap(ClassLoader loader, boolean ignoreManul, boolean ignoreDebugger, boolean ignoreConflict) throws Exception
    {

        Set<Class> lstCls = getAllCellClasses(loader);

        return loadCellsMap(lstCls, ignoreManul, ignoreDebugger, ignoreConflict);
    }

    /**
     * 在Cell类集合中，加载实现与接口的map
     * 
     * @param ignoreManul
     *            是否忽略掉打了Manul标签的
     * @param ignoreDebugger
     *            是否忽略掉打了Debug标签的
     * @param ignoreConflict
     *            遇到同级CELL冲突（FALSE=重复注册会报错）
     */
    public static Map<Class, CellBuilderIntf> loadCellsMap(Collection<Class> lstCls, boolean ignoreManul, boolean ignoreDebugger, boolean ignoreConflict) throws Exception
    {
        Map<Class, CellBuilderIntf> map = new HashMap();

        // 先默认把所有接口都已自身注册为实现（大不了没有找到实现的话则报错）
        for (Class cellIntf : lstCls)
        {
            if (cellIntf.isInterface() && CmnUtil.isInheritFrom(cellIntf, CellIntf.class))
            {
                if (ignoreManul)
                {
                    CellManual disable = (CellManual) cellIntf.getAnnotation(CellManual.class);
                    if (disable != null && disable.value())
                        continue;
                }

                map.put(cellIntf, new EmptyCellBuilder(cellIntf));
            }
        }

        // 再搜索实现类
        MultipleException mExp = new MultipleException("Failed to load some of Cells builder");
        for (Class cellImpl : lstCls)
        {
            try
            {
                if (cellImpl.isInterface())
                    continue;

                if (ignoreManul)
                {
                    CellManual disable = (CellManual) cellImpl.getAnnotation(CellManual.class);
                    if (disable != null && disable.value())
                        continue;
                }

                if (ignoreDebugger)
                {
                    CellDebugger dbg = (CellDebugger) cellImpl.getAnnotation(CellDebugger.class);
                    if (dbg != null && dbg.value())
                        continue;
                }

                Class intf = CallbackUtil.getCallbackInterface(cellImpl);
                if (intf == null)
                    continue;

                // 根据其主接口来判断该细胞核是否需要
                if (ignoreManul)
                {
                    // 打了禁用标签的接口，连同其实现一起忽略
                    CellManual disable = (CellManual) intf.getAnnotation(CellManual.class);
                    if (disable != null && disable.value())
                        continue;
                }

                if (ignoreDebugger)
                {
                    // 打了调试器的接口，连同实现一起忽略
                    CellDebugger dbg = (CellDebugger) intf.getAnnotation(CellDebugger.class);
                    if (dbg != null && dbg.value())
                        continue;
                }
                
                if (Modifier.isAbstract(cellImpl.getModifiers()))
                {
                    // 抽象的实现类，不加载CellBuilder，靠外部自行解决构建问题
                    ToolUtilities.info("Cells", "Ignore abstract cell : " + cellImpl);
                    continue;
                }

                if (!map.containsKey(intf))
                {
                    map.put(intf, new SimpleCellBuilder(intf, cellImpl));
                } else
                {
                    CellBuilderIntf exist = map.get(intf);
                    if (exist instanceof EmptyCellBuilder)
                        map.put(intf, new SimpleCellBuilder(intf, cellImpl));
                    else
                    {
                        int newLevel = CellLevel.LEVEL_NORMAL;
                        CellLevel lv = (CellLevel) cellImpl.getAnnotation(CellLevel.class);
                        if (lv != null)
                            newLevel = lv.value();

                        if (exist.getLevel() < newLevel)
                        {
                            // 高级别CELL实现可以覆盖低级别
                            map.put(intf, new SimpleCellBuilder(intf, cellImpl));
                            ToolUtilities.info("Cells", "Found higher level Cell to overwrite lower one : " + cellImpl + " -> " + exist);
                        } else if (exist.getLevel() == newLevel)
                        {
                            // 同级冲突，则按照是按条件忽略或报错
                            if (ignoreConflict)
                                ToolUtilities.error("Cells", "Some conflict builder try to overwrite original one : NEW=" + cellImpl + ", OLD=" + exist);
                            else
                                throw new Exception("Found conflict cell implement : " + intf + "[" + exist + " <> " + cellImpl + "]");
                        } else
                        {
                            // 低级别直接忽略
                            ToolUtilities.info("Cells", "Ignore lower cell : " + cellImpl + ", Keep Old= " + exist);
                        }
                    }
                }

            } catch (Throwable err)
            {
                mExp.addException(new Exception("Failed to load cell builder for (" + cellImpl + ") : " + err.getMessage(), err));
            }
        }

        mExp.tryThrowException();

        return map;
    }

    public static Map<Class, Class> loadCellDebuggers(boolean ignoreConflict) throws Exception
    {
        Map<Class, Class> map = new HashMap<Class, Class>();

        Set<Class> lstCls = getAllCellClasses(CmnUtil.getSystemLoader());
        for (Class cellImpl : lstCls)
        {
            if (cellImpl.isInterface())
                continue;

            // 如果不是debugger则忽略
            CellDebugger dbg = (CellDebugger) cellImpl.getAnnotation(CellDebugger.class);
            if (dbg == null || !dbg.value())
                continue;

            // 如果是手动，则不自动加载
            CellManual disable = (CellManual) cellImpl.getAnnotation(CellManual.class);
            if (disable != null && disable.value())
                continue;

            Class intf = CallbackUtil.getCallbackInterface(cellImpl);
            if (intf == null)
                continue;

            // 如果其接口被禁用，则也不加载
            CellManual disableIntf = (CellManual) intf.getAnnotation(CellManual.class);
            if (disableIntf != null && disableIntf.value())
                continue;

            if (!ignoreConflict && map.containsKey(intf))
                throw new Exception("Found conflict cell implement : " + intf + "[" + map.get(intf) + " <> " + cellImpl + "]");

            map.put(intf, cellImpl);
        }

        return map;
    }

    public static void main(String[] args) throws Exception
    {
        Map<Class, CellBuilderIntf> map = loadCellsMap(CmnUtil.getSystemLoader(), true, true, false);

        System.out.println(ToolUtilities.logString(map, true));

//        System.out.println(ClassFactory.searchSubClass(WfeActionIntf.class));
//        System.out.println(ClassFactory.searchSubClass(CellIntf.class));
    }
}
