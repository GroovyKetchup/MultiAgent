package bap.cells;

public interface ConfigFactoryIntf
{
    public CellConfig getConfig(Class cellClass) throws Exception;
}
