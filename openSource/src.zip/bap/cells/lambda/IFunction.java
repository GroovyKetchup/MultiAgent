package bap.cells.lambda;

import java.util.function.Function;

import crpc.CRpcCallbackIntf;

public interface  IFunction<T, R> extends CRpcCallbackIntf, Function<T, R>
{
}
