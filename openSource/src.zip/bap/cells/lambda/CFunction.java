package bap.cells.lambda;

import java.util.function.Function;

import com.leavay.ms.tool.CmnUtil;

import crpc.BasicCallback;

public class CFunction<T, R> extends BasicCallback implements IFunction<T, R>
{
    Function<T, R> _local;
    public CFunction(Function<T, R> func)
    {
        _local = CmnUtil.assertNotNull(func, "Invalid function object");
    }
    
    public static <T, R> CFunction<T, R> NEW(Function<T, R> func)
    {
        return new CFunction<>(func);
    }
    
    public R apply(T t)
    {
        return _local.apply(t);
    }
}
