package bap.cells;

import com.leavay.common.util.ToolUtilities;
import com.project.gui.common.GuiUtil;

import cell.CellIntf;
import crpc.BasicCallback;
import crpc.CallbackLocalMethod;

/**
 * 
 * 注册到服务端接管cell builder
 * 
 * 比较特殊，不允许转发桥接了
 *
 */
public class RmtCellBuilder extends BasicCallback implements RmtCellBuilderIntf
{
    String localUser;
    
    transient CellBuilderIntf _local;

    @CallbackLocalMethod
    public boolean isSupportBridge()
    {
        return false;
    }
    
    public RmtCellBuilder(Class intfCls, Class implCls)
    {
        _local = new SimpleCellBuilder(intfCls, implCls);
    }
    
    public RmtCellBuilder(CellBuilderIntf bd)
    {
        _local = bd;
    }
    
    public CellIntf buildCell(Object... params) throws ClassNotFoundException, Exception
    {
        return _local.buildCell(params);
    }

    public String getInterfaceClass()
    {
        return _local.getInterfaceClass();
    }

    public String getImplementClass()
    {
        return _local.getImplementClass();
    }

    public String getLocalUser()
    {
        return localUser;
    }

    public void setLocalUser(String localUser)
    {
        this.localUser = localUser;
    }

    @Override
    public RmtCellBuilderInfo getRemoteInfo()
    {
        return new RmtCellBuilderInfo().setHost(ToolUtilities.getCurrentHostName()).setUser(getLocalUser());
    }

    @Override
    public boolean applyKickout(String serviceInterface, RmtCellBuilderInfo otherClient)
    {
        return GuiUtil.showConfirmWarn(null, "Other people want to attach cell : " + serviceInterface+"\nFrom : " +otherClient+"\n\nDo you approve?" , "Apply Warning!");
    }
    
}
