package bap.cells;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.jdt.internal.compiler.ClassFile;
import org.eclipse.jdt.internal.compiler.batch.CompilationUnit;

import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.common.util.javac.LvJavac.LvCompileResult;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcCodeUtil;

import bap.cells.CellHookIntf.ENTRY;
import bap.cells.annotation.After;
import bap.cells.annotation.Before;
import cell.CellIntf;
import cmn.util.Nulls;

/**
 * 提供Cell的Class（内含HOOK的包装），每次会根据原始Class 结合 是否需要加探针等包装器，动态编译构建出Cell的Class
 * 
 * 目前的实现在重建cell map时（发布插件的瞬间），可能有旧的类加载器残留问题，暂时先观察
 */
public class CellHookProvider
{
    public final static String REAL_ME_FIELD = "_realMe"; // 类中成员：用于记录真实包裹目标

    public final static String MTH_GET_REALME = "getRealCell()"; // 获取包裹目标的方法，必须实现接口CellWrapperIntf的方法，因为外部还有可能需要获取这个对象

    public final static String HOOK_CALL_ID = "_____id"; // 函数内用于分配调用id的变量名

    String _className;

    private volatile Class _orgClass;

    private Class _wrapClass;

    public CellHookProvider(String className)
    {
        _className = className;
    }

    // key=Cell Class, value=Wrapper Class（有可能为空）
    // forceReload是否强制重新生成包装类（false则优先使用缓存）
    public Pair<Class, Class> loadCellClass(List<String> globalBefore, List<String> globalAfter, boolean forceReload) throws Exception
    {
        Class newCls = ClassFactory.loadClass(_className);
        if (!forceReload && _orgClass == newCls) // 如果ClassFactory发生了变化，那么此缓存也会失效
        {
            return new Pair<Class, Class>(_orgClass, _wrapClass);
        }

        synchronized (this)
        {
            _orgClass = newCls;
            _wrapClass = buildWrapperClass(newCls, globalBefore, globalAfter);
            return new Pair<Class, Class>(_orgClass, _wrapClass);
        }
    }

    public Class buildWrapperClass(Class orgClass, List<String> globalBefore, List<String> globalAfter) throws Exception
    {
        String code = generateWrapperCode(orgClass, globalBefore, globalAfter);
        if (code == null) // 没有方法需要包装，则返回空
            return null;

        LvJavac c = new LvJavac();
        c.setClassLoader(new LvClassLoader(orgClass.getClassLoader()));
        try (LvClassLoader clsLoader = c.getClassLoader())
        {
            String fullClassName = getWrapperName(orgClass.getName());
            LvCompileResult rs = c.compile(new CompilationUnit(code.toCharArray(), LvJavac.getSimpleName(fullClassName), "UTF-8"));
            if (rs.getOneResult().hasErrors())
                throw new Exception("Failed to compile proxy code : \n" + ToolUtilities.logString(rs.getOneResult().getErrors(), true) + "\n\n---------- CODE -----------\n" + code);

            ClassFile[] clsFile = rs.getOneResult().getClassFiles();
            clsLoader.addClassByte(fullClassName, clsFile[0].getBytes());
            return clsLoader.loadClass(fullClassName);
        }
    }

    public static String getWrapperName(String className)
    {
        return className + "_Wrapper";
    }

    public static Object executeRealFunction(CellIntf wrapperObj, String func, Object... params) throws Throwable
    {
        try
        {
            return ToolUtilities.callFunction(wrapperObj, func, params);
        } catch (InvocationTargetException exp)
        {
            throw ((InvocationTargetException) exp).getTargetException();
        }
//        catch (SecurityException exp)
//        {
//            ToolUtilities.throwRuntimeException(exp);
//        } catch (NoSuchMethodException exp)
//        {
//            ToolUtilities.throwRuntimeException(exp);
//        } catch (IllegalArgumentException exp)
//        {
//            ToolUtilities.throwRuntimeException(exp);
//        } catch (IllegalAccessException exp)
//        {
//            ToolUtilities.throwRuntimeException(exp);
//        } catch (ClassNotFoundException exp)
//        {
//            ToolUtilities.throwRuntimeException(exp);
//        }
//        return null;
    }

    public static String generateWrapperCode(Class clazz, List<String> globalBefore, List<String> globalAfter)
    {
        // 记录是否存在重载的方法，不是所有cell都一定需要包装的
        boolean hasMethods = false;

        // 不能包装纯虚接口
        CmnUtil.assertFalse(clazz.isInterface(), "Can not wrap cell interface as implement");

        String clsBody = "package " + clazz.getPackage().getName() + ";";

        clsBody += "\nimport cell.*;";
        clsBody += "\nimport java.util.HashMap;";
        clsBody += "\nimport com.leavay.common.util.*;";
        clsBody += "\nimport com.leavay.common.util.javac.ClassFactory;";
        clsBody += "\nimport bap.cells.*;";

        clsBody += "\npublic class " + getWrapperName(clazz.getSimpleName()) + " extends " + clazz.getCanonicalName() + " implements " + CellWrapperIntf.class.getName();
        clsBody += "{";

        // ----- 专有字段 -----//
        // 真实对象，必须是不能传递到远端的，如果包裹器被发送给远端，那么应该被转换成远程调用回来本地，在转调realMe的方法
        clsBody += "\n    protected transient CellIntf " + REAL_ME_FIELD + ";";
        clsBody += "\n    public CellIntf " + MTH_GET_REALME + "{return " + REAL_ME_FIELD + ";}";

        // 构造函数
        clsBody += "\n    public " + getWrapperName(clazz.getSimpleName()) + "(Object realMe){this." + REAL_ME_FIELD + "=(CellIntf)realMe;}";

        // 先生成Proxy的桥接函数
        List<Method> allMethods = getHookMethods(clazz);
        List<String> lstMethodBody = new ArrayList();
        for (Method m : allMethods)
        {
            int modi = m.getModifiers();
            if (Modifier.isInterface(modi) || Modifier.isNative(modi))
                continue;

            // Final方法不可以重载， 故而无法包装
            if (Modifier.isFinal(modi))
                continue;

            // 有Hook的才会生成派生方法
            Before[] bfAnnts = getAnnotations(m, Before.class);
            After[] aftAnnts = getAnnotations(m, After.class);
            if (!CmnUtil.isObjectEmpty(globalBefore) || !CmnUtil.isObjectEmpty(globalAfter) || !CmnUtil.isObjectEmpty(bfAnnts) || !CmnUtil.isObjectEmpty(aftAnnts))
            {
                String mBody = generateMethodBody(m, globalBefore, globalAfter, bfAnnts, aftAnnts);
                if (!lstMethodBody.contains(mBody))
                    lstMethodBody.add(mBody);
                hasMethods = true;
            }
        }

        for (String sMth : lstMethodBody)
            clsBody += "\n" + sMth + "\n";

        clsBody += "\n}";

        return hasMethods ? clsBody : null;
    }

    // 所有函数都找一遍
    public static List<Method> getHookMethods(Class implClass)
    {
        return CRpcCodeUtil.getMethod(implClass);
    }

    public static <T extends Annotation> T[] getAnnotations(Method m, Class<T> anntClass)
    {
        T[] bm = m.getAnnotationsByType(anntClass);
        T[] bc = m.getDeclaringClass().getAnnotationsByType(anntClass);
        int size = ToolUtilities.getObjectSize(bm) + ToolUtilities.getObjectSize(bc);
        if (size <= 0)
            return null;

        List<T> lst = new ArrayList<T>();
        if (bm != null)
            for (T t : bm)
                lst.add(t);

        if (bc != null)
            for (T t : bc)
                lst.add(t);

        return ToolUtilities.list2Array(lst, anntClass);
    }

    /**
     * 生成包装函数，可以传入全局HOOK类名，或者局部HOOK注解
     * 
     * @param globalBefore
     *            ： 全局HOOK类名（Before）
     * @param globalAfter
     *            ：全局HOOK类名（After）
     * @param lstBefore
     *            ：代码中申明的HOOK注解（Before）
     * @param lstAfter
     *            ：代码中申明的HOOK注解（After）
     * @return
     */
    public static String generateMethodBody(Method method, List<String> globalBefore, List<String> globalAfter, Before[] lstBefore, After[] lstAfter)
    {
        StringBuilder sBody = new StringBuilder("");

        // 函数头
        sBody.append(CRpcCodeUtil.generateMethodHead(method));

        sBody.append(method.getName() + "(");

        // 参数
        sBody.append(CRpcCodeUtil.generateParamDeclare(method));
        sBody.append(")");

        // 抛出异常
        sBody.append(CRpcCodeUtil.generateMethodThrow(method));
        sBody.append("{");

        // HOOK调用序号 No，这一组的hook都将接收到同一个调用序号（以便外部统计执行时间）
        sBody.append("\n    long " + HOOK_CALL_ID + " = ToolBasic.allocRandomID();");

        // Before Hooks
        List<String> allBefore = ToolUtilities.combineLists(new LinkedList<String>(), globalBefore);
        if (lstBefore != null)
            for (Before annBefore : lstBefore)
                allBefore.add(annBefore.value().getName());

        for (String gBefore : allBefore)
            sBody.append("\n   " + CellHookProvider.class.getName() + ".executeHook(CellHookIntf.ENTRY.BEFORE, " + HOOK_CALL_ID + ", \"" + gBefore + "\", " + MTH_GET_REALME + ", \"" + method.getName() + "\""
                    + CRpcCodeUtil.generateParamCode(method) + ");");

        sBody.append("\n    ");

        // 真正执行的代码
        String exeCode = CellHookProvider.class.getName() + ".executeRealFunction(" + MTH_GET_REALME + ", \"" + method.getName() + "\"" + CRpcCodeUtil.generateParamCode(method) + ");";

        // After Hooks
        List<String> allAfter = ToolUtilities.combineLists(new LinkedList<String>(), globalAfter);
        if (lstAfter != null)
            for (After annAfter : lstAfter)
                allAfter.add(annAfter.value().getName());

        String sAfter = "";
        for (String gAfter : allAfter)
            sAfter += "\n       " + CellHookProvider.class.getName() + ".executeHook(CellHookIntf.ENTRY.AFTER, " + HOOK_CALL_ID + ", \"" + gAfter + "\", " + MTH_GET_REALME + ", \"" + method.getName() + "\""
                    + CRpcCodeUtil.generateParamCode(method) + ");";

        sBody.append("\n    try{");
        if (!CRpcCodeUtil.isVoidReturn(method))
        {
            Class clzReturn = method.getReturnType();
            String retrunConvert = CRpcCodeUtil.getClassCodeText(ToolUtilities.getCompatibleClass(clzReturn));
            sBody.append("\n\tObject __returnObject=").append(exeCode);

            for (String gAfter : allAfter)
                sBody.append("\n\t").append(CellHookProvider.class.getName() + ".onReturnHook(__returnObject, " + HOOK_CALL_ID + ", \"" + gAfter + "\", " + MTH_GET_REALME + ", \"" + method.getName() + "\""
                        + CRpcCodeUtil.generateParamCode(method) + ");");

            sBody.append("\n\treturn " + "(" + retrunConvert + ")__returnObject;");
        } else
        {
            sBody.append("\n    " + exeCode);
        }

        sBody.append("\n    }");

        // Catch Block
        String catchBlk = generateCatchBlock(method, allAfter);

        sBody.append(catchBlk);
        sBody.append("\nfinally{");
        sBody.append(sAfter);
        sBody.append("\n    }");

        sBody.append("\n}");

        return sBody.toString();
    }

    public static String generateCatchBlock(Method method, List<String> allAfter)
    {
        Class<?>[] types = method.getExceptionTypes();

        String s = "\ncatch(Throwable __throwable){";
//        s+="\n\tToolBasic.err(__throwable);";
        for (String gAfter : allAfter)
            s += "\n\t" + CellHookProvider.class.getName() + ".onExceptionHook(__throwable, " + HOOK_CALL_ID + ", \"" + gAfter + "\", " + MTH_GET_REALME + ", \"" + method.getName() + "\""
                    + CRpcCodeUtil.generateParamCode(method) + ");";

        if (!Nulls.isEmpty(types))
        {
            for (Class expClass : types)
            {
                s += "\nif (__throwable instanceof " + expClass.getName() + ")";
                s += "\n\tthrow (" + expClass.getName() + ")__throwable;";
            }
        }
        s += "\nthrow " + CellHookProvider.class.getName() + ".wrapRuntimeException(__throwable);";
        s += "}";
        return s;
    }

    public static RuntimeException wrapRuntimeException(Throwable err)
    {
        if (err instanceof RuntimeException)
            return (RuntimeException) err;
        else
            return new RuntimeException(err);
    }

    public static void executeHook(ENTRY entry, long id, String hookClass, CellIntf cell, String func, Object... params)
    {
        try
        {
            ((CellHookIntf) ClassFactory.newInstance(hookClass)).onAction(entry, id, cell, func, params);
        } catch (Exception exp)
        {
            CmnUtil.throwRuntimeException(exp);
        }
    }

    public static void onReturnHook(Object objReturn, long id, String hookClass, CellIntf cell, String func, Object... params)
    {
        try
        {
            ((CellHookIntf) ClassFactory.newInstance(hookClass)).onRetrun(objReturn, id, cell, func, params);
        } catch (Exception exp)
        {
            CmnUtil.throwRuntimeException(exp);
        }
    }

    public static void onExceptionHook(Throwable throwable, long id, String hookClass, CellIntf cell, String func, Object... params)
    {
        try
        {
            ((CellHookIntf) ClassFactory.newInstance(hookClass)).onException(throwable, id, cell, func, params);
        } catch (Exception exp)
        {
            CmnUtil.throwRuntimeException(exp);
        }
    }

}
