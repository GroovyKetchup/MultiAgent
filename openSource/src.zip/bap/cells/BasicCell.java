package bap.cells;

import java.util.concurrent.locks.ReentrantLock;

import cell.CellIntf;
import cmn.util.AutoLock;
import crpc.BasicCallback;

/**
 * 推荐一般的Cell实现都派生于此类
 * 
 * 所有Cell都必须申明在cell.xxx这样的包名下，否则Cells工厂无法识别 所有Cell都不得申明构造函数
 * ，统一在initCell方法中实现带参数的构造
 * 
 */
public class BasicCell extends BasicCallback implements CellIntf
{
    // Cell作为Callback被调用的默认超时时长，CELL用于Callback大多用于云开发场景，可以长一点时间
    protected long __callbackTimout = 24 * 60 * 60 * 1000; // 24消失

    public long getTimeout()
    {
        return __callbackTimout;
    }

    public void setTimeout(long timeout)
    {
        __callbackTimout = timeout;
    }

    /**
     * 所有Cell都不得申明构造函数 ，统一在initCell方法中实现带参数的构造
     */
    protected BasicCell()
    {

    }

    // 这个conf必须和Cell实现类一起，来自一个classLoader，这样在更换classLoader后，新的CELL自然会加载新的配置
    private transient ReentrantLock _lcConf = new ReentrantLock();

    private transient CellConfig _conf = null;

    public CellConfig getConfig()
    {
        try (AutoLock lc = AutoLock.lock(_lcConf))
        {
            if (_conf == null)
                _conf = Cells.getConfig(getClass());
        }

        return _conf;
    }

    // 服务启停的时候，默认都会自动调用此动作，以确保重启时能加载最新的配置
    public void resetConfig()
    {
        try (AutoLock lc = AutoLock.lock(_lcConf))
        {
            _conf = null;
        }
    }
}
