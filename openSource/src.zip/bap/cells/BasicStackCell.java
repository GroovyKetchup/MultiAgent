package bap.cells;

/**
 * 栈空间Cell基类，其生命存续期与堆栈内存相同，即随着对象被gc而自动close
 * 无需手动close，常用于远程lambda表达式，以及远程临时回调对象的自动释放。
 * 默认会设置一个较长的超时（10分钟），也可以自行设置，因为正常会随着gc释放无需用户手动释放。
 * 2025年5月26日
 * 
 * 实测确实能随gc得到回收，但时机非常不确定，只能作为兜底措施。
 * 主要还是被超时回收了。属于双保险，如果影响到内存可能被gc触发释放，内存不吃紧的话可能被超时释放
 *  
 */
public class BasicStackCell extends BasicCell
{
    public BasicStackCell()
    {
        super();
        
        setStackScope();
    }

    public BasicStackCell setStackScope()
    {
        return (BasicStackCell) super.setStackScope();
    }
    
    public BasicStackCell setStackScope(long expireTime)
    {
        return (BasicStackCell) super.setStackScope(expireTime);
    }
}
