package bap.cells;

import java.util.List;
import java.util.Set;

import com.leavay.ms.tool.CmnUtil;

public interface CellFactory
{
    public boolean isValieCell(String cls);

    public ConfigFactoryIntf getConfigFactory();

    // 获取细胞配置
    public default CellConfig getConfig(Class cellClass)
    {
        ConfigFactoryIntf factory = getConfigFactory();
        try
        {
            return factory==null?null:factory.getConfig(cellClass);
        } catch (Exception exp)
        {
            CmnUtil.throwRuntimeException(exp);
            return null;
        }
    }
    
    // 全局HOOK设置、获取
    public List<String> getGlobalBefore();

    public void setGlobalBefore(List<String> _globalBefore);
    
    public List<String> addGlobalBefore(String hookClass);

    public List<String> getGlobalAfter();

    public void setGlobalAfter(List<String> globalAfter);
    
    public List<String> addGlobalAfter(String hookClass);
    
    public Set<String> getAllCells();

    // 获取细胞
    public default <T> T getCell(Class<T> cls, Object... params) throws Exception
    {
        return (T) getCell(cls.getName(), params);
    }
    
    // 获取细胞    
    // 改成默认不校验版本兼容性，影响性能
    public Object getCell(String clsName, Object... params) throws Exception;

    // 最底层真正的getCell，可以指定是否需要校验兼容性
    public Object getCell(boolean verifyClassCompatible, String clsName, Object... params) throws Exception;
}
