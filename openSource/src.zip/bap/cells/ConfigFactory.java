package bap.cells;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.starter.GlobalReflect;

import bap.cells.annotation.Config;
import bap.plugin.mgr.CellConfigDaoAdapter;

/**
 * 细胞配置工厂，负责为细胞提供配置信息（通常用于服务类Cell的启动，或者一些资源Cell的默认配置等）
 * 配置对象必须派生于CellConfig，且其字段只支持基本数据类型
 * 
 * 1、在服务端，该工厂默认从conf/cell.config中获取并装配在一起
 * 2、在CPluginClient启动时，则会进一步被DAO适配器接管，从而累加DAO中存储的配置（主要用于动态插件中的CELL配置）
 * 3、在远程开发端(Eclispe)，这个工厂会被接管，从而支持调试端专用配置
 *
 *
    XML 的每个元素名字是Cell的类名，而参数中config_class=配置类的名字
    默认的配置文件存储位置：FILE_CONFIG
    
 */
public class ConfigFactory implements ConfigFactoryIntf
{

    static CellConfigAdapter _adapter = new CellConfigAdapter();
    
    // 根据细胞类获取其配置类（如果没有定义则返回NULL）
    public CellConfig getConfig(Class cellClass) throws Exception
    {
        CellConfig cfg = buildDefaultConfig(cellClass);
        
        // 结合本地配置文件或者基于DAO的配置，组装出配置
        assembleConfig(cfg);
        return cfg;
    }
    
    public static CellConfig buildDefaultConfig(Class cellClass) throws Exception
    {
        Class cfgClass = getConfigClass(cellClass);
        if (cfgClass == null)
            return null;
        
        return (CellConfig) ClassFactory.newInstance(cfgClass);
    }
    
    public static Class getConfigClass(Class cellClass) throws ClassNotFoundException
    {
        if (cellClass == null)
            return null;
        
        // 搜索指定了Config目标类的注解（支持搜索父类、接口等）
        Config cfgAnt =(Config) cellClass.getAnnotation(Config.class);
        if (cfgAnt == null)
        {
            List<Class> lstSuper = CmnUtil.getAllSuper(cellClass, true);
            for (Class sCls : lstSuper)
            {
                cfgAnt =(Config) sCls.getAnnotation(Config.class);
                if (cfgAnt != null)
                    break;
            }
        }
        
        // 全都搜过，依然没有则说明没有申明对应的配置类
        if (cfgAnt == null)
            return null;
        else
            return ClassFactory.loadClass(cfgAnt.value().getName());
    }
    
    // 装配配置项，加载配置值，设置到配置对象的字段里
    public boolean assembleConfig(CellConfig dftCfg) throws Exception
    {
        return assembleConfig(dftCfg, loadConfigProps());
    }
    
    // 返回TRUE，表示有修改默认配置，FALSE则表名完全没有修改传入的默认配置
    public static boolean assembleConfig(CellConfig dftCfg, Map<String, String> props) throws Exception
    {
        if (dftCfg == null)
            return false;

        boolean touched = false;
        if (props != null)
        {
            List<Field> lstF = ToolUtilities.getAllField(dftCfg.getClass(), false);
            for (Field f : lstF)
            {
                if (!isConfigField(f))
                    continue;
                
                String p = ToolUtilities.getString(props.get(getConfigKey(dftCfg.getClass(), f.getName())), null);
                if (p == null)
                    continue;
                
                setValue(dftCfg, f, p);
                touched = true;
            }
        }
        
        return touched;
    }
    
    public static boolean isConfigField(Field f)
    {
        int mod = f.getModifiers();
        return !Modifier.isStatic(mod) && Modifier.isPublic(mod) && !Modifier.isTransient(mod);
    }
    
    public static void setValue(CellConfig cfg, Field f, String prop) throws Exception
    {
        if (CmnUtil.isStringEmpty(prop))
            return;
        
        if (f.getType().equals(String.class))
            ToolUtilities.setFieldValue(cfg, f, prop);
        else if (f.getType().equals(byte.class) || f.getType().equals(Byte.class))
            ToolUtilities.setFieldValue(cfg, f, prop==null?null:prop.getBytes());
        else if (f.getType().equals(long.class) || f.getType().equals(Long.class))
            ToolUtilities.setFieldValue(cfg, f, ToolUtilities.getLong(prop));
        else if (f.getType().equals(short.class) || f.getType().equals(Short.class))
            ToolUtilities.setFieldValue(cfg, f, ToolUtilities.getShort(prop));
        else if (f.getType().equals(int.class) || f.getType().equals(Integer.class))
            ToolUtilities.setFieldValue(cfg, f, ToolUtilities.getInteger(prop));
        else if (f.getType().equals(float.class) || f.getType().equals(Float.class))
            ToolUtilities.setFieldValue(cfg, f, ToolUtilities.getFloat(prop));
        else if (f.getType().equals(double.class) || f.getType().equals(Double.class))
            ToolUtilities.setFieldValue(cfg, f, ToolUtilities.getDouble(prop));
        else if (f.getType().equals(boolean.class) || f.getType().equals(Boolean.class))
            ToolUtilities.setFieldValue(cfg, f, ToolUtilities.getBoolean(prop));
        else
            throw new Exception("Data type of config is illegal : " + cfg.getClass()+"::"+f.getName()+"="+f.getType());
    }
    
    public static String getConfigKey(Class clsConfig, String fieldName)
    {
        return getConfigKey(clsConfig.getName(), fieldName);
    }
    
    public static String getConfigKey(String configClassName, String fieldName)
    {
        return configClassName+"."+fieldName;
    }
    
    public static CellConfigAdapter getAdapter()
    {
        return _adapter;
    }

    public static void resetAdapter(CellConfigAdapter adapter)
    {
        ConfigFactory._adapter = adapter;
    }
    
    // GlobalReflect
    public static void reflectResetDaoAdapter() throws Exception
    {
        if (false) GlobalReflect.registDaoConfigAdapter(); // 由这里反向调用，以隔绝编译依赖
        resetAdapter(CellConfigDaoAdapter.getMe());
    }
    
    public static void saveConfigFile(Map<String, CellConfig> configs) throws Exception
    {
        getAdapter().saveConfigFile(configs);
    }
    
    public static HashMap<String, String> loadConfigProps() throws Exception
    {
        return getAdapter().loadConfigProps();
    }
    
}
