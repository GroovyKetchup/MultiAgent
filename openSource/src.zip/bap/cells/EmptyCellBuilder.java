package bap.cells;

import org.eclipse.jdt.internal.compiler.ClassFile;
import org.eclipse.jdt.internal.compiler.batch.CompilationUnit;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.common.util.javac.LvJavac.LvCompileResult;
import com.leavay.ms.tool.CmnUtil;

import cell.CellIntf;
import cell.ServiceCellIntf;

// 用于默认还没有实现的Cell的构建
public class EmptyCellBuilder implements CellBuilderIntf, CellHolderIntf
{
    boolean isSingleton = false;
    CellIntf _singleton = null;
    
    Class intfCls;
    Class implCls;
    
    public EmptyCellBuilder(Class intfCls)
    {
        setIntfClass(intfCls);
    }
    
    public Class<? extends CellIntf> getIntfCls()
    {
        return intfCls;
    }

    public void setIntfClass(Class intfClass)
    {
        this.intfCls = intfClass;
    }

    public synchronized CellIntf tryGetSingletone()
    {
        if (isSingleton)
            return _singleton;
        return null;
    }

    protected synchronized CellIntf clearSingletone()
    {
        CellIntf org = _singleton;
        _singleton = null;

        return org;
    }
    
    protected synchronized void _trySetAndStartSingletone(CellIntf newInstance) throws Exception
    {
        // 服务类需要触发启动
        if (newInstance instanceof ServiceCellIntf)
        {
            // 确保重新加载配置
            ((ServiceCellIntf) newInstance).resetConfig();

            // 启动，只启动一次
            ((ServiceCellIntf) newInstance).startService();
        }

        isSingleton = true;
        _singleton = newInstance;
    }
    
    public synchronized Class loadImplementClass() throws ClassNotFoundException
    {
        if (implCls == null)
        {
            try
            {
                // 服务CELL的空壳不推荐直接写在接口里
                String superClass = BasicCell.class.getName();
                
                String mainClass = getInterfaceClass() + "EmptyImplement";
                String pkg = LvJavac.getPackageFromFullClass(mainClass);
                String code = "package " + pkg + ";\n";
                code += "public class " + LvJavac.getSimpleName(mainClass) + " extends " +superClass+ " implements " + getInterfaceClass() + "{\n";
                code += "\n}";

                LvJavac c = new LvJavac();
                LvClassLoader loader = LvClassLoader.wrap(getIntfCls().getClassLoader()); //ClassFactory.newValidClassLoader(); 这个在重建时，有可能刚好拿到老的
                c.setClassLoader(loader);
                CompilationUnit u = new CompilationUnit(code.toCharArray(), LvJavac.getClassFilePath(mainClass), "UTF-8");
                LvCompileResult rs = c.compile(u);
                for (ClassFile clsFile : rs.getOneResult().getClassFiles())
                {
                    loader.addClassByte(mainClass, LvJavac.saveClassFile(clsFile, mainClass));
                }

                implCls = loader.loadClass(mainClass);

            } catch (Exception exp)
            {
                throw new RuntimeException("Failed to generate empty implement for cell interface : " + getInterfaceClass(), exp);
            }
        }
        return implCls;
    }

    public CellIntf buildCell(Object... params) throws ClassNotFoundException
    {
        CellIntf existSingleton = tryGetSingletone();
        if (existSingleton != null)
            return existSingleton;
        
        Class cls = loadImplementClass();
        CmnUtil.assertNotNull(cls, "Invalid cell implement class : " + getImplementClass());
        
        try
        {
            CellIntf intf = (CellIntf) cls.newInstance();

            // 初始化（之所以要用反射，是为了兼容各Cell派生的initCell入参被固定了类型）
            if (false) intf.initCell(params);
            ToolUtilities.callFunction(intf, "initCell", params);
            
            // 如果是singleton，则缓存起来不再新建
            if (intf != null && intf.isSingleton())
                _trySetAndStartSingletone(intf);
            
            return intf;
        } catch (Exception exp)
        {
            CmnUtil.throwRuntimeException(exp);
            return null;
        }
    }

    public String getInterfaceClass()
    {
        return intfCls.getName();
    }

    public String getImplementClass()
    {
        return implCls==null?null:implCls.getName();
    }
    
    public String toString()
    {
        return "Empty Cell : " + CmnUtil.getNameAndLabel(getInterfaceClass()+"", getImplementClass());
    }
    
    public  void clearAndStopInstance()
    {
        CellIntf org = null;
        synchronized (this)
        {
            implCls = null;
            org = clearSingletone();
        }

        if (org != null && org instanceof ServiceCellIntf)
        {
            try
            {
                ((ServiceCellIntf) org).stopService();
            }catch (Throwable err)
            {
                ToolUtilities.fatal("Cell Builder", "Failed to clear rubbish singleton : " +org, err);
            }
        }
    }
}
