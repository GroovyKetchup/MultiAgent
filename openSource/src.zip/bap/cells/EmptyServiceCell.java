package bap.cells;

public class EmptyServiceCell extends BasicServiceCell
{

    @Override
    protected void doStartService() throws Exception
    {
        
    }

    @Override
    protected void doStopService()
    {
        
    }

}
