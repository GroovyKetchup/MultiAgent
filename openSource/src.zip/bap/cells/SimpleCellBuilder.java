package bap.cells;

import java.lang.reflect.Constructor;
import java.util.LinkedList;
import java.util.List;

import com.leavay.common.util.Pair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import cell.CellIntf;
import cell.ServiceCellIntf;

public class SimpleCellBuilder implements CellBuilderIntf, CellHolderIntf
{
    private String intfClass;

    private String implClass;

    private int implLevel = CellLevel.LEVEL_NORMAL;

    private volatile boolean isSingleton = false;

    private volatile CellIntf _singleton = null;

    // 用来对细胞制作包装类的工具
    private transient CellHookProvider _classProvider;

    public SimpleCellBuilder(Class intfCls, Class implCls)
    {
        intfClass = intfCls.getName();
        implClass = implCls.getName();
        CellLevel level = (CellLevel) implCls.getAnnotation(CellLevel.class);
        if (level != null)
            implLevel = level.value();

        _classProvider = new CellHookProvider(implClass);
    }

    public int getLevel()
    {
        return implLevel;
    }

    public synchronized CellIntf tryGetAndStartSingletone() throws Exception
    {
        if (isSingleton)
        {
            if (_singleton instanceof ServiceCellIntf && !((ServiceCellIntf) _singleton).isStarted())
            {
                // 确保重新加载配置
                ((ServiceCellIntf) _singleton).resetConfig();
                ((ServiceCellIntf) _singleton).startService();
            }

            return _singleton;
        }
        return null;
    }

    // 直接返回singleton对象，不自动启动
    public synchronized CellIntf tryGetSingletone()
    {
        if (isSingleton)
        {
            return _singleton;
        }
        return null;
    }

    public boolean isSingletone()
    {
        return isSingleton;
    }

    protected synchronized CellIntf clearSingletone()
    {
        CellIntf org = _singleton;
        _singleton = null;

        return org;
    }

    // 设置单例，如果是服务还需启动服务
    // 外部要校验好确实非空单例，才能传入此方法
    protected synchronized void _trySetAndStartSingletone(CellIntf newInstance) throws Exception
    {
        // 服务类需要触发启动
        if (newInstance instanceof ServiceCellIntf)
        {
            // 确保重新加载配置
            ((ServiceCellIntf) newInstance).resetConfig();

            // 启动，只启动一次
            ((ServiceCellIntf) newInstance).startService();
        }

        isSingleton = true;
        _singleton = newInstance;
    }

    // 主要用于Singleton的情况下，需要热特换Cell的包装类
    // 包装器是用于拦截调入调出监听的，例如做调用次数统计等
    public synchronized void rebuildWrapper() throws Exception
    {
        // 尚未缓存，则略过
        if (!isSingleton || _singleton == null)
            return;

        Pair<Class, Class> p = loadCellClass(true);
        if (p.getValue() == _singleton.getClass())
            return;

        // 重新包装，并替换缓存（如果本来就是包装器，则需要取出内核重新包装）
        if (p.getValue() == null)
            _singleton = null;
        else
            _singleton = constructCellWrapper(p.getValue(), _singleton instanceof CellWrapperIntf ? ((CellWrapperIntf) _singleton).getRealCell() : _singleton);
    }


    // 全局CELL HOOK（类名）
    List<String> _localBefore;

    List<String> _localAfter;
    
    public List<String> getLocalBefore()
    {
        return _localBefore;
    }

    public SimpleCellBuilder setLocalBefore(List<String> _localBefore)
    {
        this._localBefore = _localBefore;
        return this;
    }

    public List<String> getLocalAfter()
    {
        return _localAfter;
    }

    public SimpleCellBuilder setLocalAfter(List<String> _localAfter)
    {
        this._localAfter = _localAfter;
        return this;
    }

    // 如果forceReload=False，则优先使用内部缓存的已加载好的类，否则就强制重新制作包装类
    public Pair<Class, Class> loadCellClass(boolean forceReload) throws ClassNotFoundException, Exception
    {
        return _classProvider.loadCellClass(ToolUtilities.combineLists(Cells.getFactory().getGlobalBefore(), getLocalBefore()), ToolUtilities.combineLists(Cells.getFactory().getGlobalAfter(), getLocalAfter()),
                forceReload);
    }
    
    public CellIntf buildCell(Object... params) throws ClassNotFoundException, Exception
    {
        // singleton的直接尝试获取（如果是服务，尝试启动）
        CellIntf existSingleton = tryGetAndStartSingletone();
        if (existSingleton != null)
            return existSingleton;

        Pair<Class, Class> pairCls = loadCellClass(false);
        CmnUtil.assertNotNull(pairCls, "Invalid cell implement class : " + implClass);
        CmnUtil.assertNotNull(pairCls.getKey(), "Invalid cell implement class : " + implClass);

        try
        {
            CellIntf intf = (CellIntf) pairCls.getKey().newInstance();

            // 初始化（之所以要用反射，是为了兼容各Cell派生的initCell入参被固定了类型）
            if (false)
                intf.initCell(params);
            ToolUtilities.callFunction(intf, "initCell", params);

            // 送入包装对象（如果有包装器）
            if (pairCls.getValue() != null)
                intf = constructCellWrapper(pairCls.getValue(), intf);

            // 如果是singleton，则缓存起来不再新建
            // 如果是服务，还会启动服务
            // 【注】虽然并发访问时，以上构造过程可能被多次运行，但这个效率损失极低，却可以最大限度保证普通cell的build过程不被加锁
            if (intf != null && intf.isSingleton())
                _trySetAndStartSingletone(intf);

            return intf;
        } catch (Exception exp)
        {
            CmnUtil.throwRuntimeException(exp);
            return null;
        }
    }

    // 构造包装对象
    public static CellIntf constructCellWrapper(Class wrapperClass, CellIntf realCell) throws Exception
    {
        Constructor cstr = ToolUtilities.getBestConstructor(wrapperClass, Object.class);
        return (CellIntf) cstr.newInstance(realCell);
    }

    public String getInterfaceClass()
    {
        return intfClass;
    }

    public String getImplementClass()
    {
        return implClass;
    }

    public String toString()
    {
        String s = CmnUtil.getNameAndLabel(getInterfaceClass(), getImplementClass());
        if (isSingletone())
            s += "{Singletone=" + tryGetSingletone() + "}";
        return s;
    }

    public void clearAndStopInstance()
    {
        CellIntf org = null;
        synchronized (this)
        {
            org = clearSingletone();
        }

        if (org != null && org instanceof ServiceCellIntf)
        {
            try
            {
                ((ServiceCellIntf) org).stopService();
            } catch (Throwable err)
            {
                ToolUtilities.fatal("Cell Builder", "Failed to clear rubbish singleton : " + org, err);
            }
        }
    }
}
