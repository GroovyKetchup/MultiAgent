package bap.cells;

import java.util.Set;

public class CellFilter
{
    Set<String> funcFilter;

    public Set<String> getFuncFilter()
    {
        return funcFilter;
    }

    public void setFuncFilter(Set<String> funcFilter)
    {
        this.funcFilter = funcFilter;
    }
    
    // 是否转发到远端
    // 如果没有设置具体的函数列表，则全都转发远端
    public boolean isRemoteHandle(String func, Object ... params)
    {
        return funcFilter==null?true:funcFilter.contains(func);
    }
    
}
