package bap.cells;

import java.net.URI;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

import com.cdao.CDaoConst;
import com.cdao.mgr.CDaoUtil;
import com.leavay.client.util.lazy.LazyPool;
import com.leavay.common.nio.ws.CWsUtil;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.Pair;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.CodeUtil.BasiceClassInfoLoader;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.common.util.javac.PluginAgentIntf;
import com.leavay.dfc.mgr.javaDev.ClassSearchEngine;
import com.leavay.dfc.mgr.javaDev.PluginAgentListener;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcServer;
import com.leavay.nio.crpc.CRpcTimeoutException;
import com.leavay.nio.crpc.CRpcUtil;
import com.leavay.nio.crpc.CallbackUtil;
import com.leavay.starter.GlobalReflect;
import com.leavay.starter.ServerNotStartedException;
import com.leavay.starter.StarterMain;

import bap.cells.exception.RubbishCellClassException;
import bap.cells.hook.CellLocalHook;
import cell.CellIntf;
import cell.CellPreloadIntf;
import cell.ServiceCellIntf;
import cmn.util.AutoLock;
import cmn.util.Nulls;

/**
 * 运行在服务端（非IDE端），主控以及所有代理上均会启动，伴随CRPC服务端启动
 */
public class CellServerFactory implements CellFactory, ServerCellService, PluginAgentListener
{
    private static final long serialVersionUID = -6525323926143229929L;

    public final static String LOG = "Cell Server Factory";

    // 全局CELL HOOK（类名）
    volatile List<String> _globalBefore;

    volatile List<String> _globalAfter;

    // 存本地系统Loader中的Cell
    ConcurrentHashMap<String, CellBuilderIntf> mapLocalBuilder = new ConcurrentHashMap<String, CellBuilderIntf>();

    // 存插件中的Cell
    ConcurrentHashMap<String, CellBuilderIntf> mapPluginBuilder = new ConcurrentHashMap<String, CellBuilderIntf>();

    // 存远端attach上来的Cell
    ReentrantLock _lockRmt = new ReentrantLock();

    ConcurrentHashMap<String, RmtCellBuilderWrapper> mapRmtBuilder = new ConcurrentHashMap<String, RmtCellBuilderWrapper>();

    ConfigFactory _cfgFactory = new ConfigFactory();

    private static CellServerFactory _me;

    public synchronized static CellServerFactory getMe()
    {
        if (_me == null)
        {
            _me = new CellServerFactory();
        }
        return _me;
    }

    protected CellServerFactory()
    {
        // 启动就注册自己作为Plugin的监听器
        ClassFactory.addPluginListner(this);
    }

    public void registLocalCell(Class intfCls, Class implCls)
    {
        CmnUtil.assertTrue(intfCls.isInterface(), "Only interface could be registed as cell");
        CmnUtil.assertTrue(CmnUtil.isInheritFrom(intfCls, CellIntf.class), "Cell interface should be child of " + CellIntf.class.getName());
        CmnUtil.assertTrue(CmnUtil.isInheritFrom(implCls, intfCls), "Cell implement should be child of " + intfCls.getName());

        // 接口可以build，实现类同样可以关联到builder
        registLocalBuilder(new SimpleCellBuilder(intfCls, implCls));
    }

    protected void registLocalBuilder(CellBuilderIntf builder)
    {
        CellBuilderIntf exist = mapLocalBuilder.get(builder.getInterfaceClass());
        if (exist != null)
            ToolUtilities.warning(LOG, "Some conflict local builder try to overwrite original one : NEW=" + builder + ", OLD=" + exist);

        mapLocalBuilder.put(builder.getInterfaceClass(), builder);
        
    }

    // 为全局类搜索建立索引
    public final static String CLASS_LOADER_KEY = "Cell-Server-Class-Loader";
    
    // 整体替换
    public void registPluginCell(Map<Class, CellBuilderIntf> cellMap)
    {
        ConcurrentHashMap<String, CellBuilderIntf> mapNew = new ConcurrentHashMap<String, CellBuilderIntf>();

        List<Class<? extends CellPreloadIntf>> lstPreload = new LinkedList<Class<? extends CellPreloadIntf>>();
        
        ClassSearchEngine.removeOuterLoader(CLASS_LOADER_KEY);
        if (cellMap != null)
        {
            BasiceClassInfoLoader infoLoader = new BasiceClassInfoLoader();
            for (Entry<Class, CellBuilderIntf> pair : cellMap.entrySet())
            {
                CmnUtil.assertTrue(pair.getKey().isInterface(), "Only interface could be registed as cell");
                CmnUtil.assertTrue(CmnUtil.isInheritFrom(pair.getKey(), CellIntf.class), "Cell interface should be child of CellIntf : " + pair.getKey());
                mapNew.put(pair.getKey().getName(), pair.getValue());
                
                infoLoader.addClass(pair.getKey().getSimpleName(), pair.getKey().getName(), "Cell Factory");
                if (CmnUtil.isStringNotEmpty(pair.getValue().getImplementClass()))
                    infoLoader.addClass(LvJavac.getSimpleName(pair.getValue().getImplementClass()), pair.getValue().getImplementClass(), "Cell Factory");
                
                if (CmnUtil.isInheritFrom(pair.getKey(), CellPreloadIntf.class))
                    lstPreload.add(pair.getKey());
            }
            ClassSearchEngine.putOuterLoader(CLASS_LOADER_KEY, infoLoader);
        }

        synchronized (mapPluginBuilder)
        {
            if (mapPluginBuilder != null)
            {
                // 插件中的服务类Cell需要触发关闭动作
                lazyShutdownCells(mapPluginBuilder.values());

                mapPluginBuilder.clear();
            }
            mapPluginBuilder = mapNew;
        }
        
        for (Class<? extends CellPreloadIntf> cls : Nulls.get(lstPreload))
        {
            CellPreloadMgr.getMe().preloadCell(cls);
        }
    }

    public ConcurrentHashMap<String, CellBuilderIntf> getPluginCellMap()
    {
        return mapPluginBuilder;
    }

    public ConcurrentHashMap<String, CellBuilderIntf> getLocalCellMap()
    {
        return mapLocalBuilder;
    }

    protected void lazyShutdownCell(CellBuilderIntf rubbish)
    {
        _lazyShutdownCell.add(rubbish);
    }

    protected void lazyShutdownCells(Collection<CellBuilderIntf> lstRubbish)
    {
        _lazyShutdownCell.add(lstRubbish);
    }

    // 这里是在插件更新后，批量关闭缓存的脏cell服务，这里只会关闭服务
    LazyPool<CellBuilderIntf> _lazyShutdownCell = new LazyPool<CellBuilderIntf>(1000)
    {
        public void handle(List<CellBuilderIntf> objects)
        {
            for (CellBuilderIntf builder : objects)
            {
                try
                {
                    if (builder instanceof SimpleCellBuilder || builder instanceof EmptyCellBuilder)
                    {
                        CellIntf singleton = builder.tryGetSingletone();
                        if (singleton != null && singleton instanceof ServiceCellIntf)
                        {
                            // 停止服务类cell
                            terminateServiceCell(builder, (ServiceCellIntf)singleton);
                        }
                    }
                } catch (Throwable err)
                {
                    ToolUtilities.error(LOG, "Failed to shutdown cell : " + builder, err);
                }
            }
        }
    };
    
    public static void terminateServiceCell(CellBuilderIntf builder, ServiceCellIntf cell)
    {
        // 强停服务
        try
        {
            ToolUtilities.infoAndOutput(LOG, "Try to shutdown cell : " + cell + " ... ");
            cell.stopService();
        }catch (Throwable err)
        {
            ToolUtilities.fatal(LOG, "Failed to kill service cell : " + cell);
        }

        // 确保清除残留配置
        try
        {
            cell.resetConfig();
            ToolUtilities.infoAndOutput(LOG, "Succed to shutdown cell : " + cell);
        }catch (Throwable err)
        {
            ToolUtilities.fatal(LOG, "Failed to kill service cell : " + cell);
        }
    }

    public CellBuilderIntf prepareBuilder(String intfClass, Object... params) throws NullCellBuilderException
    {
        RmtCellBuilderIntf rmtBd = getRemoteBuilder(intfClass);
        if (rmtBd != null && rmtBd.isMatch(params))
            return rmtBd;

        CellBuilderIntf pluginBd = mapPluginBuilder.get(intfClass);
        if (pluginBd != null)
            return pluginBd;

        CellBuilderIntf lcBd = mapLocalBuilder.get(intfClass);
        if (lcBd == null)
            throw new NullCellBuilderException(String.format("Do not support cell interface (%s), please register cell builder first.", intfClass));

        return lcBd;
    }

    public RmtCellBuilderIntf getRemoteBuilder(String cls)
    {
        _lockRmt.lock();
        try
        {
            RmtCellBuilderWrapper rmt = mapRmtBuilder.get(cls);
            if (rmt != null)
            {
                if (rmt.getRmt() != null)
                {
                    // 如果rmt不是一个远程proxy（本地类），或者远程proxy是开启态， 则直接返回可以使用
                    if (!rmt.getRmt().isProxy() || CallbackUtil.isProxyOpen(rmt.getRmt()))
                        return rmt.getRmt();
                }

                mapRmtBuilder.remove(cls);
                return null;
            }

            return null;
        } finally
        {
            _lockRmt.unlock();
        }
    }

    LazyPool<Pair<String, RmtCellBuilderIntf>> _lazyCheckRmt = new LazyPool<Pair<String, RmtCellBuilderIntf>>(500)
    {
        public void handle(List<Pair<String, RmtCellBuilderIntf>> objects)
        {
            for (Pair<String, RmtCellBuilderIntf> p : objects)
            {
                try
                {
                    if (!CallbackUtil.isProxyOpen(p.getValue()))
                    {
                        removeInvalidRemote(p.getKey(), p.getValue());
                    }
                } catch (Throwable err)
                {
                    ToolUtilities.error(LOG, err);
                }
            }
        }
    };

    public void lazyCheckAndRemoveRemote(String intfCls, RmtCellBuilderIntf rmt)
    {
        _lazyCheckRmt.add(new Pair(intfCls, rmt));
    }

    public void removeInvalidRemote(String cls, RmtCellBuilderIntf rmt)
    {
        _lockRmt.lock();
        try
        {
            RmtCellBuilderWrapper real = mapRmtBuilder.get(cls);
            if (real == null || real.getRmt() == rmt)
            {
                mapRmtBuilder.remove(cls);
            }
        } finally
        {
            _lockRmt.unlock();
        }
    }
    
    public static final String CONF_DEFAULT_GET_SAFE_CELL=  "bap.default.get.safe.cell";
    
    // 获取细胞    
    // 改成默认不校验版本兼容性，影响性能
    public Object getCell(String cls, Object ... params) throws Exception
    {
        return getCell(MppContext.getBoolean(CONF_DEFAULT_GET_SAFE_CELL, false), cls, params);
    }
    
    public Object getCell(boolean verifyClassCompatible, String cls, Object... params) throws RubbishCellClassException, Exception
    {
        // 如果正在重载cell map，阻塞等待其完成
        blockPluginReloading();
        
        try
        {
            CellBuilderIntf builder = prepareBuilder(cls, params);

            if (builder instanceof RmtCellBuilderIntf)
            {
                try
                {
                    return builder.buildCell(params); // 远程构建，截获连接异常触发自动清理
                } catch (Throwable err)
                {
                    // err.printStackTrace();
                    // 断链或者超时无响应的，自动切换到本地 err.printStackTrace()
                    if (CRpcUtil.isDisconnectedException(err) || ToolBasic.isCausedBy(err, CRpcTimeoutException.class))
                    {
                        lazyCheckAndRemoveRemote(cls, (RmtCellBuilderIntf) builder);
                        return builder.buildCell(params); // 本地构建
                    }

                    return ToolUtilities.throwException(err);
                }
            } else
            {
                Object cell = builder.buildCell(params); // 本地构建

                if (verifyClassCompatible)
                    return verifyCellClassCompatible(cls, cell, builder); // 校验类兼容
                else
                    return cell;
            }
        } catch (Throwable error)
        {
            // 如果系统还没启动完成，发生的错误需提示等系统启动完成
            if (StarterMain.isStarting())
                throw new ServerNotStartedException(error);

            throw error;
        }
    }

    // 校验获取到的cell是否和当前全局Loader兼容，如果发现冲突类，则抛出异常
    public Object verifyCellClassCompatible(String targetClass, Object cell, CellBuilderIntf builder) throws RubbishCellClassException, ClassNotFoundException
    {
        if (cell == null)
            return null;
        
        // 系统加载器出来的， 没有兼容性问题
        if (ToolUtilities.isSystemLoader(cell.getClass().getClassLoader()) && cell.getClass().getName().equals(targetClass))
            return cell;

        // 全局类加载中的类和当前缓存的instance是否匹配
        // 如果类加载器变了（比如发布了新的），那么老的cell实例就是脏的了，需要清理
        Class factoryCls = ClassFactory.loadClass(targetClass);
        if (!factoryCls.isInstance(cell))
        {
            // 在插件发布还没触发cell重载时，访问老的服务都会报此错（一般遇到这种异常，等一会儿延迟清理脏cell即可解决，或者重新发布一次插件）
            RubbishCellClassException exp = new RubbishCellClassException(factoryCls.getClassLoader(), cell);
            ToolUtilities.fatal(LOG, "Found some rubbish incompatible cell with current classloader : " + cell.getClass().getClassLoader(), exp);
            throw exp;
        }

        return cell;
    }

    // 判断是否注册在案的细胞
    public boolean isValieCell(String cls)
    {
        return getRemoteBuilder(cls) != null || mapLocalBuilder.containsKey(cls) || mapPluginBuilder.containsKey(cls);
    }
    
    /**
     * 在服务端本地attach用于调优性能或临时监控的HOOK
     * 利用远程attach的入口，接管到本地hook wrapper里
     * 【注】 : 必须是通过cells工厂生成的cell才有效果， 自己new出来的野cell，没人管
     * 
     * 用法可参考测试类：TestCellHook
     * @param cellImpl - CELL的实现类（主控本地类）
     * @param beforeHooks - 前置钩子类名（需派生于CellHookIntf）
     * @param afterHooks - 后置钩子类名（需派生于CellHookIntf）
     * @param forceKick - 是否强制踢掉其它挂接（包括云开发接管）
     * @throws Exception
     */
    public CellLocalHook attachLocalHookBuilder(Class cellImpl, List<String> beforeHooks, List<String> afterHooks, boolean forceKick) throws Exception
    {
        Class intf = CallbackUtil.getCallbackInterface(cellImpl);
        if (!CmnUtil.isInheritFrom(intf, CellIntf.class))
            throw new Exception("Invalid class is not a cell");

        String user = CDaoUtil.getRpcUserCode();

        if (forceKick)
            kickoutRemoteBuilder(user, intf.getName(), forceKick);

        SimpleCellBuilder localBuilder = new SimpleCellBuilder(intf, cellImpl);
        localBuilder.setLocalBefore(beforeHooks);
        localBuilder.setLocalAfter(afterHooks);

        RmtCellBuilderIntf builder = new RmtCellBuilder(localBuilder);
        attachRemoteBuilder(builder);
        return new CellLocalHook(user, builder);
    }

    public void attachRemoteBuilder(RmtCellBuilderIntf rmtBuilder) throws Exception
    {
        _lockRmt.lock();
        try
        {
            // 马上回调获取远端信息
            RmtCellBuilderInfo newRmtInfo = null;
            try
            {
                newRmtInfo = rmtBuilder.getRemoteInfo();
                newRmtInfo.setClientAddress(CRpcServer.getCurrentRemoteAddress() + "");
            } catch (Throwable err)
            {
                // 有可能老接口不支持，忽略
            }

            String intf = rmtBuilder.getInterfaceClass();

            RmtCellBuilderIntf rmt = getRemoteBuilder(intf);
            if (rmt != null)
            {
                RmtCellBuilderInfo info = null;
                RmtCellBuilderWrapper wrapper = mapRmtBuilder.get(intf);
                if (wrapper != null)
                    info = wrapper.getInfo();
                // 这里有问题，容易导致卡死，需要改掉
                throw new Exception("Attached by other user : " + info + " [" + intf + " -> " + rmt + "]");
            }

            mapRmtBuilder.put(rmtBuilder.getInterfaceClass(), new RmtCellBuilderWrapper(rmtBuilder, newRmtInfo));
        } finally
        {
            _lockRmt.unlock();
        }
    }

    // forceKick将不询问直接踢
    public void kickoutRemoteBuilder(String otherUser, String intf, boolean forceKick) throws DenyApplyKickout
    {
        RmtCellBuilderIntf rmt = getRemoteBuilder(intf);
        if (rmt == null)
            return;

        // 向远端申请
        try
        {
            RmtCellBuilderInfo otherInfo = new RmtCellBuilderInfo();
            otherInfo.user = otherUser;
            otherInfo.clientAddress = "" + CRpcServer.getCurrentRemoteAddress();

            // 自然超时的，忽略（说明对方不在位或断联了）
            if (!forceKick)
            {
                if (CallbackUtil.isProxyOpen(rmt))
                {
                    if (!rmt.applyKickout(intf, otherInfo))
                        throw new DenyApplyKickout("Application was dennied! Please contact someone concerned.");
                }
            }
        } catch (DenyApplyKickout denied)
        {
            throw denied;
        } catch (Throwable err)
        {
            // 远端异常，就当他同意了
            err.printStackTrace();
        }

        removeInvalidRemote(intf, rmt);
    }

    // key:service, Value:RmtCellBuilderInfo 或者Exception
    public Map<String, Object> queryRemoteBuilder() throws Exception
    {
        Map<String, Object> mapRet = new HashMap<String, Object>();

        HashMap<String, RmtCellBuilderWrapper> map = new HashMap(mapRmtBuilder);
        for (Entry<String, RmtCellBuilderWrapper> ent : map.entrySet())
        {
            try
            {
                RmtCellBuilderInfo info = ent.getValue().getInfo();
                mapRet.put(ent.getKey(), info);

                lazyCheckAndRemoveRemote(ent.getKey(), ent.getValue().getRmt());
            } catch (Throwable err)
            {
                mapRet.put(ent.getKey(), err);
            }
        }

        return mapRet;
    }

    public static void reflectStartService() throws Exception
    {
        if (false)
            GlobalReflect.startCellServer(); // 由这里反向调用，以隔绝编译依赖
        getMe().startService();
    }

    public void startService() throws Exception
    {
        CRpcServer.registService(ServerCellService.class, CellServerFactory.getMe());

        Cells.setFactory(getMe());

        // 自动加载所有类，分析派生继承类
        CmnUtil.out("Start loading all cell implements ... ");
        loadLocalCells();
    }

    public void loadLocalCells() throws Exception
    {
        Map<Class, CellBuilderIntf> mapCells = CellFinder.loadCellsMap(CmnUtil.getSystemLoader(), true, true, false);
        ToolUtilities.infoAndOutput(LOG,  "Load and regist local cells builder : " + ToolUtilities.logString(mapCells.keySet(), false));
        
        for (Entry<Class, CellBuilderIntf> ent : mapCells.entrySet())
        {
            registLocalBuilder(ent.getValue());
        }
        
    }

    public void ping() throws RemoteException
    {
    }

    public URI getPluginServer()
    {
        if (CDaoUtil.isConfDaoSlave())
        {
            try
            {
                return CWsUtil.buildURI(MppContext.getString(CDaoConst.CONF_CLUSTER_MASTER_URI));
            } catch (Throwable err)
            {
                throw new RuntimeException("Please check DAO slave config of master URI", err);
            }
        } else
        {
            return CWsUtil.buildURI(ToolUtilities.getInetAddress(CRpcServer.getCurrentLocalAddress()), ToolUtilities.getInetPort(CRpcServer.getCurrentLocalAddress()));
        }
    }

    public ConfigFactoryIntf getConfigFactory()
    {
        return _cfgFactory;
    }

    public List<String> getGlobalBefore()
    {
        return _globalBefore;
    }

    public void setGlobalBefore(List<String> globalBefore)
    {
        this._globalBefore = globalBefore;
        rebuildWrapper();
    }

    public List<String> addGlobalBefore(String hookClass)
    {
        List<String> lst = _globalBefore;
        if (lst == null)
            lst = new LinkedList<String>();
        lst.add(hookClass);

        setGlobalBefore(lst);
        return lst;
    }

    public List<String> getGlobalAfter()
    {
        return _globalAfter;
    }

    public void setGlobalAfter(List<String> globalAfter)
    {
        this._globalAfter = globalAfter;
        rebuildWrapper();
    }

    public List<String> addGlobalAfter(String hookClass)
    {
        List<String> lst = _globalAfter;
        if (lst == null)
            lst = new LinkedList<String>();
        lst.add(hookClass);

        setGlobalAfter(lst);
        return lst;
    }

    ReentrantLock _lockRebuild = new ReentrantLock();

    public void rebuildWrapper()
    {
        _lockRebuild.lock();
        try
        {
            for (CellBuilderIntf builder : mapLocalBuilder.values())
            {
                try
                {
                    if (builder instanceof SimpleCellBuilder)
                        ((SimpleCellBuilder) builder).rebuildWrapper();
                } catch (Exception exp)
                {
                    ToolUtilities.error(LOG, exp);
                }
            }

            for (CellBuilderIntf builder : mapPluginBuilder.values())
            {
                try
                {
                    if (builder instanceof SimpleCellBuilder)
                        ((SimpleCellBuilder) builder).rebuildWrapper();
                } catch (Exception exp)
                {
                    ToolUtilities.error(LOG, exp);
                }
            }
        } finally
        {
            _lockRebuild.unlock();
        }
    }

    public Set<String> getAllCells()
    {
        HashSet<String> setAll = new HashSet<String>();
        setAll.addAll(mapLocalBuilder.keySet());
        setAll.addAll(mapRmtBuilder.keySet());
        setAll.addAll(mapPluginBuilder.keySet());

        return setAll;
    }

    /**
     * 在插件重新发布替换加载后触发，扫描插件中的类，哪些是cell的，自动重新注册 并会触发释放老的cell
     */
    public void replaceCellMap(BasiceClassInfoLoader infoLoader, LvClassLoader newLoader) throws Exception
    {
        ToolUtilities.warnAndOutput(LOG, "Begin replace CELL after plugin loader upgraded : " + newLoader);

        List<Class> lstCls = new LinkedList();
        if (infoLoader != null && infoLoader.getClassMap() != null)
            for (List<ClassNameInfo> lstInfo : infoLoader.getClassMap().values())
            {
                if (lstInfo != null)
                    for (ClassNameInfo i : lstInfo)
                    {
                        String pkg = LvJavac.getPackageFromFullClass(i.getClassFullName());
                        if (!Cells.isCellPackage(pkg))
                            continue;

                        try
                        {
                            Class cellClass = newLoader.loadClass(i.getClassFullName());
                            lstCls.add(cellClass);
                        } catch (NoClassDefFoundError noClass)
                        {

                        } catch (IllegalAccessError accErr)
                        {

                        } catch (Throwable err)
                        {
                            // ignore
                            ToolUtilities.error(LOG, "Failed to analyse plugin class : " + i + " - " + ToolUtilities.getExceptionStatck(err, true));
                        }
                    }
            }

        Map<Class, CellBuilderIntf> mapCells = CellFinder.loadCellsMap(lstCls, true, true, true);
        registPluginCell(mapCells);
        ToolUtilities.warnAndOutput(LOG, "Finish replace plugin cell after replace : " + ToolUtilities.logString(mapCells, false));
    }

    // 灰度发布才会调用此方法（已废弃）
    @Deprecated
    public void replaceCellMap(Collection<Class> infoLoader, LvClassLoader newLoader) throws Exception
    {
        ToolUtilities.warnAndOutput(LOG, "Begin replace CELL after plugin loader upgraded : " + newLoader);

        List<Class> lstCls = new LinkedList();
        if (infoLoader != null)
            for (Class cellCls : infoLoader)
            {
                String name = cellCls.getCanonicalName();
                String pkg = LvJavac.getPackageFromFullClass(name);
                if (!Cells.isCellPackage(pkg))
                    continue;

                try
                {
                    lstCls.add(newLoader.loadClass(name));
                } catch (NoClassDefFoundError noClass)
                {

                } catch (IllegalAccessError accErr)
                {

                } catch (Throwable err)
                {
                    // ignore
                    ToolUtilities.error(LOG, "Failed to analyse plugin class : " + name, err);
                }
            }

        Map<Class, CellBuilderIntf> mapCells = CellFinder.loadCellsMap(lstCls, true, true, true);
        registPluginCell(mapCells);
        ToolUtilities.warnAndOutput(LOG, "Finish replace plugin cell after replace : " + ToolUtilities.logString(mapCells, false));
    }

    // plugin发布或者启动，都需要从插件类中搜索出所有的cells进行reload（如果有服务cell还会主动停止老服务，释放老cell）
    ReentrantLock _lockReloadPluginCells = new ReentrantLock();
    

    public void afterPluginLoaded(long newTagID)
    {
        _lazyHandlePluginLoaded.addUnexist(newTagID);
    }
    
    LazyPool<Long>  _lazyHandlePluginLoaded = new LazyPool<Long>(500)
    {
        public void handle(List<Long> lstData)
        {
            long maxTag = -1;
            for (long tag : lstData)
                maxTag = Math.max(maxTag, tag);
            
            if (StarterMain.isStarting())
            {
                ToolUtilities.infoAndOutput(LOG, "Ignore and retry later to reload plugin CELLS when still starting!");
                ToolUtilities.sleep(2000);
                afterPluginLoaded(maxTag);
                return;
            }else
            {
                _handleAfterPluginLoaded(maxTag);
            }
        }
    };

    public final static long TIMEOUT_BLOCK_PLUGIN_RELOAD = 5*60*1000;
    volatile boolean _reloadingPluginClasses = false;
    public boolean isPluginClassReloading()
    {
        return _reloadingPluginClasses;
    }
    public void blockPluginReloading() throws TimeoutException
    {
        long start = -1;
        while (isPluginClassReloading())
        {
            if (start > 0)
            {
                if (System.currentTimeMillis() - start > TIMEOUT_BLOCK_PLUGIN_RELOAD)
                    throw new TimeoutException("Timed out to block waiting plugin reloading. Please try again later.");
            }
            else
                start = System.currentTimeMillis();
            
            ToolUtilities.sleep(10);
        }
    }
    
    public void _handleAfterPluginLoaded(long newTagID)
    {
        if (StarterMain.isStarting())
        {
            // 有了lazypool缓冲，按道理会一直等到启动完毕才会执行
            ToolUtilities.warnAndOutput(LOG, "[WARN]Reject reload plugin CELLS when still starting");
            return;
        }

        try (AutoLock lc = AutoLock.lock(_lockReloadPluginCells))
        {
            _reloadingPluginClasses = true;
            
            PluginAgentIntf pluginAgent = ClassFactory.getPluginAgent();
            ToolUtilities.infoAndOutput(LOG, "Load CELL info from plugin agent : " + pluginAgent + ", ClassFactory=" + ClassFactory.getFactory());

            BasiceClassInfoLoader infoLoader = pluginAgent.getClassInfoLoader();
            ToolUtilities.debug(LOG, "All Plugin Classes=" + ToolBasic.logString(infoLoader == null ? null : infoLoader.getAllClass(), false));

            if (!CmnUtil.isObjectEmpty(infoLoader))
            {
                ToolUtilities.infoAndOutput(LOG, "Truely replace CELL map from classes loader =" + pluginAgent);
                replaceCellMap(infoLoader, ClassFactory.getValidClassLoader());
            }
        } catch (Throwable exp)
        {
            ToolUtilities.fatal(LOG, "Failed to reload CELL service after plugin published", exp);
        } finally
        {
            _reloadingPluginClasses = false;
        }
    }

    public String printLog()
    {
        String s = "Plugin Cells : " + ToolBasic.logString(getPluginCellMap(), Integer.MAX_VALUE, false);
        s += "\nLocal Cells : " + ToolBasic.logString(getLocalCellMap(), Integer.MAX_VALUE, false);
        s += "\nRemote Cells : " + ToolUtilities.logString(mapRmtBuilder, Integer.MAX_VALUE, false);
        return s;
    }

    public String printRemoteBuilder()
    {
        return ToolUtilities.logString(mapRmtBuilder, true);
    }
}
