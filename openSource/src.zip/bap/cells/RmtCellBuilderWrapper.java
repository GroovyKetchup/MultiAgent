package bap.cells;

public class RmtCellBuilderWrapper
{
    RmtCellBuilderInfo info;
    RmtCellBuilderIntf _realRmt;
    
    public RmtCellBuilderWrapper(RmtCellBuilderIntf intf, RmtCellBuilderInfo info)
    {
        this._realRmt = intf;
        this.info = info;
    }

    public RmtCellBuilderInfo getInfo()
    {
        return info;
    }

    public void setInfo(RmtCellBuilderInfo info)
    {
        this.info = info;
    }

    public RmtCellBuilderIntf getRmt()
    {
        return _realRmt;
    }
}
