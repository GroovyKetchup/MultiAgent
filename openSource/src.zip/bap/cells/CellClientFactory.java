package bap.cells;

import java.net.URI;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;
import com.leavay.nio.crpc.CRpcAdapter;
import com.leavay.nio.crpc.CRpcClientWrapper;
import bap.debug.BapDebugUtil;
import bap.debug.gui.DevConf;
import cell.CellIntf;

/**
 * 这个通常是启动在调试端进程，正常的服务、代理上都是启动CellServerFactory
 *
 */
public class CellClientFactory implements CellFactory, ServerCellService
{
    public final static String LOG = "Cell Client Factory";

    // 全局CELL HOOK（类名）
    volatile List<String> _globalBefore;

    volatile List<String> _globalAfter;

    protected CRpcClientWrapper<ServerCellService> _cellIntf = new CRpcClientWrapper<ServerCellService>(ServerCellService.class)
    {
        public CRpcAdapter getAdapter()
        {
            return CRpcAdapter.getInstance();
        }
    };

    // 细胞配置工厂，每个细胞都可以有自己的配置，参考@Config
    ConfigFactory _cfgFactory = new ConfigFactory();

    private static CellClientFactory _me;

    public synchronized static CellClientFactory getMe()
    {
        if (_me == null)
        {
            _me = new CellClientFactory();
        }
        return _me;
    }

    protected CellClientFactory()
    {
    }

    // 默认用于Eclipse开发端、云Tester中，需要加载本地调试Cell
    public void start(URI uri) throws Exception
    {
        start(uri, true);
    }

    /**
     * 启动Cell客户端工厂，从而在客户端代码中可以直接使用Cells使用远程Cell
     * 
     * 
     * @param host
     * @param port
     * @param loadDebugger
     *            是否加载本地调试类Cell（@CellDebugger标识的调试专用本地Cell），通常Eclipse启动都要传入true，纯客户端则传入false
     */
    public void start(URI uri, boolean loadDebugger) throws Exception
    {
        _cellIntf.init(uri);

        // 加载并注册本地调试器
        if (loadDebugger)
        {
            CmnUtil.out("Start loading local debugger cell ... ");
            loadAllDebugger();
        }

        Cells.setFactory(this);
    }

    public ServerCellService getIntf()
    {
        return _cellIntf.getIntf(true);
    }

    ConcurrentHashMap<String, CellBuilderIntf> _mapLocal = new ConcurrentHashMap<String, CellBuilderIntf>();

    public void attachCellToServer(Class intfCls, Class implCls) throws Exception
    {
        attachBuilderToServer(new SimpleCellBuilder(intfCls, implCls));
    }

    /**
     * 启动调试时，用本地cell去接管远端cell的实现，从而得以本地调试运行
     */
    public void attachBuilderToServer(CellBuilderIntf localBuilder) throws Exception
    {
        // 本地桥接到服务端
        RmtCellBuilder rmtBuilder = new RmtCellBuilder(localBuilder);
        DevConf conf = BapDebugUtil.loadConfigIfexist(ToolUtilities.getCurrentDirectory());
        if (conf != null)
        {
            rmtBuilder.setLocalUser(conf.getUser());
        }

        getIntf().attachRemoteBuilder(rmtBuilder);
        
        // 给远端的也需要覆盖注册到本地，本地调用时也要确保走入同一个builder（否则Service类的CELL会出现多个实例）
        registLocalBuilder(rmtBuilder);
    }

    public void kickoutRemoteBuilder(String intf, boolean forceKick) throws Exception
    {
        String currUser = null;
        DevConf conf = BapDebugUtil.loadConfigIfexist(ToolUtilities.getCurrentDirectory());
        if (conf != null)
            currUser = conf.getUser();

        getIntf().kickoutRemoteBuilder(currUser, intf, forceKick);
    }

    public Map<String, Object> queryRemoteBuilder() throws Exception
    {
        return getIntf().queryRemoteBuilder();
    }

    /**
     * 注册本地Cell（可用于调试专用的细胞核，例如分布式锁就有调试专用细胞核）
     */
    public void registLocalCell(Class intfCls, Class implCls)
    {
        CmnUtil.assertTrue(intfCls.isInterface(), "Only interface could be registed as cell");
        CmnUtil.assertTrue(CmnUtil.isInheritFrom(intfCls, CellIntf.class), "Cell interface should be child of " + CellIntf.class.getName());
        CmnUtil.assertTrue(CmnUtil.isInheritFrom(implCls, intfCls), "Cell implement should be child of " + intfCls.getName());

        // 接口可以build，实现类同样可以关联到builder
        registLocalBuilder(new SimpleCellBuilder(intfCls, implCls));
    }

    /**
     * 注册本地Cell（可用于调试专用的细胞核，例如分布式锁就有调试专用细胞核）
     */
    public void registLocalBuilder(CellBuilderIntf builder)
    {
        _mapLocal.put(builder.getInterfaceClass(), builder);

        if (!CmnUtil.isStringEmpty(builder.getImplementClass()))
            _mapLocal.put(builder.getImplementClass(), builder);
    }
    
    public Object getCell(String clsName, Object... params) throws Exception
    {
        CellBuilderIntf bd = _mapLocal.get(clsName);
        if (bd != null)
            return bd.buildCell(params);

        return getIntf().getCell(clsName, params);
    }

    public Object getCell(boolean verifyClassCompatible, String clsName, Object... params) throws Exception
    {
        CellBuilderIntf bd = _mapLocal.get(clsName);
        if (bd != null)
            return bd.buildCell(params);

        return getIntf().getCell(verifyClassCompatible, clsName, params);
    }

    public boolean isValieCell(String cls)
    {
        return _mapLocal.containsKey(cls) || getIntf().isValieCell(cls);
    }

    /**
     * 装载本地调试专用的Cell，打了标记：@CellDebugger
     * 只是极为特殊的情况，不适合远程联调的Cell，例如和本机线程相关的分布式锁（线程重入无法在远程模式下模拟）
     */
    public void loadAllDebugger() throws Exception
    {
        Map<Class, Class> mapCells = CellFinder.loadCellDebuggers(false);
        for (Entry<Class, Class> ent : mapCells.entrySet())
        {
            registLocalCell(ent.getKey(), ent.getValue());
            CmnUtil.out("Regist local debugger : " + ent.getKey() + " -> " + ent.getValue());
        }
    }

    public ConfigFactoryIntf getConfigFactory()
    {
        return _cfgFactory;
    }

    public List<String> getGlobalBefore()
    {
        return _globalBefore;
    }

    public void setGlobalBefore(List<String> _globalBefore)
    {
        this._globalBefore = _globalBefore;
        rebuildWrapper();
    }

    public List<String> addGlobalBefore(String hookClass)
    {
        List<String> lst = _globalBefore;
        if (lst == null)
            lst = new LinkedList<String>();
        lst.add(hookClass);

        setGlobalBefore(lst);
        return lst;
    }

    public List<String> getGlobalAfter()
    {
        return _globalAfter;
    }

    public void setGlobalAfter(List<String> globalAfter)
    {
        this._globalAfter = globalAfter;
        rebuildWrapper();
    }

    public List<String> addGlobalAfter(String hookClass)
    {
        List<String> lst = _globalAfter;
        if (lst == null)
            lst = new LinkedList<String>();
        lst.add(hookClass);

        setGlobalAfter(lst);
        return lst;
    }

    ReentrantLock _lockRebuild = new ReentrantLock();

    public void rebuildWrapper()
    {
        _lockRebuild.lock();
        try
        {
            for (CellBuilderIntf builder : _mapLocal.values())
            {
                try
                {
                    if (builder instanceof SimpleCellBuilder)
                        ((SimpleCellBuilder) builder).rebuildWrapper();
                } catch (Exception exp)
                {
                    ToolUtilities.error(LOG, exp);
                }
            }
        } finally
        {
            _lockRebuild.unlock();
        }
    }

    public Set<String> getAllCells()
    {
        return _mapLocal.keySet();
    }


    // 存远端attach上来的Cell
    ReentrantLock _lockRmt = new ReentrantLock();
    
    /**
     * 虽然是CELL的Client端, 也同时扮演服务端支持级联挂接
     */
    @Override
    public void attachRemoteBuilder(RmtCellBuilderIntf rmtBuilder) throws Exception
    {
        ToolUtilities.warnAndOutput(LOG, "Regist cascade cell to local : " + rmtBuilder.getInterfaceClass() + "="+rmtBuilder);
        
        // 直接桥接到本地cell
        registLocalBuilder(rmtBuilder);
    }

    /**
     * 虽然是CELL的Client端, 也同时扮演服务端支持级联挂接
     */
    @Override
    public void kickoutRemoteBuilder(String otherUser, String intf, boolean forceKick) throws DenyApplyKickout
    {
        throw new RuntimeException("Do not support kickout remote CELLs in cascade mode");
    }

    /**
     * 虽然是CELL的Client端, 也同时扮演服务端支持级联挂接
     */
    @Override
    public URI getPluginServer()
    {
        return null;
    }

}
