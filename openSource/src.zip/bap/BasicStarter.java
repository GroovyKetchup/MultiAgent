package bap;

import java.io.IOException;
import java.net.URL;

import com.cdao.web.servlet.CDaoModelServlet;
import com.leavay.common.util.MppContext;
import com.leavay.common.util.appState.StackAutoSaver;
import com.leavay.jmxfw.Main;import com.leavay.ms.tool.CmnUtil;
import com.leavay.starter.CStarter;

import bap.cells.CellServerFactory;

public class BasicStarter implements CStarter
{
    
    public void init() throws Exception{
        
        // 全局禁用URLConnection的缓存（默认禁止）
        // JDK默认URLConnection都会启用缓存，但这对于我们的架构非常危险，会导致插件资源残留，从而导致严重的类加载器残留问题
        // 而类加载器无法释放，其内部加载的所有类也就无法释放，会导致元空间不断膨胀的严重问题
        // 所以必须全局禁用默认缓存，特殊地方自行开启
        disableURLConnectionCache();
        
        try
        {
            Main.initLogConfig();
        }catch(Exception exp)
        {
            exp.printStackTrace();
        }
        
        // Cells管理，是整个框架的底层基础中的基础，很多初始化都要用到cell了（提供cell服务，同时也提供远程调试支持）
        CellServerFactory.getMe().startService();
        
        // 延迟启动系统类扫描器，初始化JVM类信息扫描
        if (!MppContext.getBoolean(BapClassScanner.CONF_DISABLE_PRELOAD_SYS_SCANNER , false))
            BapClassScanner.lazyInit();
    }
    
    public static void disableURLConnectionCache() throws IOException
    {
        URL url = ClassLoader.getSystemClassLoader().getResource("LanguageRes/bap_en_US.properties");
        url.openConnection().setDefaultUseCaches(false);
    }
    
    public void before(CStarter other) throws Exception
    {
    }

    public void start() throws Exception
    {
        StackAutoSaver.getMe().start();
    }

}
