package bap.dev;

public class FolderDto extends FileDto
{
    private static final long serialVersionUID = 4853479142717036737L;

    public FolderDto(String path, String rootPath)
    {
        super(path, rootPath);
    }
}
