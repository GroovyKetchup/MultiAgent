package bap.dev;

import com.leavay.ms.cmn.DtoIntf;
import com.leavay.ms.tool.CmnUtil;

public class FileDto implements DtoIntf
{

    private static final long serialVersionUID = 4853479142717036737L;
    
    String path;
    
    String rootPath;
    
    String md5;
    
    public String lastWriter;
    
    public final static int FLAG_NEW=1; // 远端不存在，本地存在
    public final static int FLAG_DIFFERENT=2; // 不一致：本地和远端不一样
    public final static int FLAG_DELETED=3; // 本地修改，远端存在
    
    public final static int FLAG_CONFLICT=4; // 冲突：修改了，且是不同用户之间

    public final static int FLAG_DELETED_BY_OTHER=10; // 和FLAG_NEW表象一致，但是远端有删除痕迹
    
    public int flag=-1;

    public long size = 0;
    
    public long lastModify = -1;
    public long createTime = -1;
    
    // 附加信息，例如被谁删除了等
    public String extInfo;
    
    public FileDto(String path, String rootPath)
    {
        this.path = path;
        this.rootPath = rootPath;
    }
    
    public String getKey()
    {
        return path;
    }

    public void setPath(String path)
    {
        this.path = path;
    }

    public void setRootPath(String rootPath)
    {
        this.rootPath = rootPath;
    }

    public String getPath()
    {
        return path;
    }
    
    public String getRootPath()
    {
        return rootPath;
    }
    
    public String getRelatedPath()
    {
        if (rootPath != null)
            return CmnUtil.getRelatedPath(getPath(), getRootPath());
        else
            return getPath();
    }

    public String getMd5()
    {
        return md5;
    }

    public void setMd5(String md5)
    {
        this.md5 = md5;
    }

    public int getFlag()
    {
        return flag;
    }

    public void setFlag(int flag)
    {
        this.flag = flag;
    }

    public boolean isNew()
    {
        return flag == FLAG_NEW;
    }
    
    public boolean isDifferent()
    {
        return flag == FLAG_DIFFERENT;
    }
    
    public boolean isDeleted()
    {
        return flag == FLAG_DELETED;
    }
    
    public boolean isConflict()
    {
        return flag == FLAG_CONFLICT;
    }
    
    public boolean isDeletedByOther()
    {
        return flag == FLAG_DELETED_BY_OTHER;
    }
    
    public long getSize()
    {
        return size;
    }

    public void setSize(long size)
    {
        this.size = size;
    }

    public long getLastModify()
    {
        return lastModify;
    }

    public void setLastModify(long lastModify)
    {
        this.lastModify = lastModify;
    }

    public long getCreateTime()
    {
        return createTime;
    }

    public void setCreateTime(long createTime)
    {
        this.createTime = createTime;
    }
    
    public String getLastWriter()
    {
        return lastWriter;
    }

    public void setLastWriter(String lastWriter)
    {
        this.lastWriter = lastWriter;
    }

    public String getExtInfo()
    {
        return extInfo;
    }

    public void setExtInfo(String extInfo)
    {
        this.extInfo = extInfo;
    }

    /**
     * 创建时间如果有效值的时候，可以用来判断文件在初次创建之后有没有被修改过
     */
    public boolean isLocalModified()
    {
        return getLastModify() > getCreateTime() && getCreateTime() > 0;
    }
    
    public String toString()
    {
        return getRelatedPath();
    }
}
