package bap.dev;

public class JavaDto extends FileDto
{
    private static final long serialVersionUID = -1486214348492908643L;
    
    public String fullClass;
    
    public JavaDto(String path, String rootPath)
    {
        super(path, rootPath);
    }
    
    public String getFullClass()
    {
        return fullClass;
    }

    public void setFullClass(String fullClass)
    {
        this.fullClass = fullClass;
    }
}
