package bap.dev;

public class JarDto extends FileDto
{

    public JarDto(String path, String rootPath)
    {
        super(path, rootPath);
    }
    private static final long serialVersionUID = -7129648795494837779L;

}
