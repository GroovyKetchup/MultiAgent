

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 将某个Cell设置为手动加载，申明在Cell的implement或者interface头部
 * 
 * 手动的cell接口或实现都不会自动被注册到系统，一定要通过api调用进行注册才会生效
 * 主要用于测试、调试等非官方cell
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface CellManual{
   boolean value() default true;
}
