package art.mvn;

import java.io.Serializable;
import java.util.List;

import com.leavay.ms.tool.CmnUtil;

import bap.md.yun.ArtifactDefine;
import cplugin.ms.dto.CJarFileDto;

public class MvnArt implements Serializable
{
    
    private static final long serialVersionUID = 6418540098629015L;
    
    public String groupId;
    public String artifactId;
    public String version;
    
    public String classifier;
    public String scope;
    public String packaging="jar";
    
    public List<CJarFileDto> lstFiles;
    
    public String getGroupId()
    {
        return groupId;
    }
    public MvnArt setGroupId(String groupId)
    {
        this.groupId = groupId;
        return this;
    }
    public String getArtifactId()
    {
        return artifactId;
    }
    public MvnArt setArtifactId(String artifactId)
    {
        this.artifactId = artifactId;
        return this;
    }
    public String getVersion()
    {
        return version;
    }
    public MvnArt setVersion(String version)
    {
        this.version = version;
        return this;
    }
    public String getScope()
    {
        return scope;
    }
    public MvnArt setScope(String scope)
    {
        this.scope = scope;
        return this;
    }
    public String getClassifier()
    {
        return classifier;
    }
    public MvnArt setClassifier(String classifier)
    {
        this.classifier = classifier;
        return this;
    }
    public String getPackaging()
    {
        return packaging;
    }
    public MvnArt setPackaging(String packaging)
    {
        this.packaging = packaging;
        return this;
    }
    

    //送往云中心时，注册的artifactId是要合并classifier的
    public String getYunArtifactId()
    {
        return getArtifactId()+ (classifier==null?"":"-"+classifier);
    }
    
    
    /**
     * 普通格式：artId+Version = audience-annotations-0.5.0.jar
     * 带classifier的格式：artId+Version+classifier = avro-mapred-1.8.2-hadoop2.jar
     */
    public String getJarFileName(boolean withExt)
    {
        String name = getArtifactId()+"-"+getVersion();
        if (!CmnUtil.isStringEmpty(getClassifier()))
            name = getArtifactId()+"-"+getVersion()+"-"+getClassifier();
        
        if (withExt)
            name += "."+getPackaging();
        
        return name;
    }
    
    public void setupYunArt(ArtifactDefine yunArt)
    {
        yunArt.setGroupId(getGroupId());
        yunArt.setArtifactId(getYunArtifactId());
        yunArt.setVersion(getVersion());
    }
    
    
    public List<CJarFileDto> getLstFiles()
    {
        return lstFiles;
    }
    public void setLstFiles(List<CJarFileDto> lstFiles)
    {
        this.lstFiles = lstFiles;
    }
    
    public void addJarFile(CJarFileDto file)
    {
        lstFiles = CmnUtil.addToList(lstFiles, file);
    }
    
    public String toString()
    {
        String basic = getGroupId()+":"+getArtifactId()+":"+getVersion()+":"+getScope()+":"+getClassifier();

        if (!CmnUtil.isObjectEmpty(lstFiles))
            for (CJarFileDto fl : lstFiles)
                basic += " ["+fl+"]";
        return basic;
    }
    
    // 生成POM文件中依赖项的XML
    public String toDependXml(String indent)
    {
        String xml = indent+"<dependency>";
        xml += "\n"+indent+ "    <groupId>" + getGroupId()+"</groupId>";
        xml += "\n"+indent+ "    <artifactId>" + getArtifactId()+"</artifactId>";
        xml += "\n"+indent+ "    <version>" + getVersion()+"</version>";
        
        if (!CmnUtil.isStringEmpty(getScope()))
            xml += "\n"+indent+ "    <scope>" + getScope()+"</scope>";
        
        if (!CmnUtil.isStringEmpty(getClassifier()))
            xml += "\n"+indent+ "    <classifier>" + getClassifier()+"</classifier>";
            

        xml += "\n"+indent+ "</dependency>";
        return xml;
    }
}
