package art.mvn;

import java.util.List;

import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import cmn.util.NullUtil;

// 双向链表
public class MvnArtTreeNode
{
    MvnArtTreeNode parent;
    
    MvnArt thisArt;
    
    List<MvnArtTreeNode> dependList;

    public MvnArtTreeNode getParent()
    {
        return parent;
    }

    public void setParent(MvnArtTreeNode parent)
    {
        this.parent = parent;
    }

    public MvnArt getThisArt()
    {
        return thisArt;
    }

    public void setThisArt(MvnArt thisArt)
    {
        this.thisArt = thisArt;
    }

    public List<MvnArtTreeNode> getDependList()
    {
        return dependList;
    }

    public void setDependList(List<MvnArtTreeNode> dependList)
    {
        this.dependList = dependList;
    }

    public void addDepend(MvnArtTreeNode child)
    {
        child.setParent(this);
        dependList = CmnUtil.addToList(dependList, child);
    }
    
    public String toString()
    {
        return thisArt+"[CHILD:"+CmnUtil.getObjectSize(dependList)+"]";
    }

    public String toLog()
    {
        return toLog(0);
    }
    
    public String toLog(int indentLevel)
    {
        String s = "";
        if (indentLevel > 0)
            s = ToolUtilities.duplicateString("|   ", indentLevel);
        s += "+- "+toString();
        
        for (MvnArtTreeNode child : NullUtil.get(dependList))
        {
            s += "\n"+child.toLog(indentLevel+1);
        }
        return s;
    }
}
