package cell.concurrent;

import java.io.Serializable;

import cell.CellIntf;
import cell.function.IConsumer;

/**
 * 异步执行控制器
 * 通常作为返回对象，由服务接口返回。用于将长时阻塞调用变为异步通知模式。
 * 但是这里要特别注意，调用这种模式的接口，必须设置then和error消费者，
 * 否则服务端会反复等待尝试，直到保护超时，默认保护超时时长为10s。
 * 
 *
 */
public interface IPromise<T extends Serializable> extends CellIntf
{
    // 设置then的消费者
    IPromise<T> then(IConsumer<T> consumer);
    
    // 设置出错的消费者
    IPromise<T> error(IConsumer<Throwable> consumer);
    
}
