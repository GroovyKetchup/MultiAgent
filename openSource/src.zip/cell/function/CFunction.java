package cell.function;

import java.io.Serializable;
import java.util.function.Function;

import bap.cells.BasicStackCell;

public abstract class CFunction<T extends Serializable, R extends Serializable> extends BasicStackCell implements IFunction<T, R>
{
    public static <T extends Serializable, R extends Serializable> CFunction<T, R> NEW(Function<T, R> func)
    {
        return new CFunction<T , R>()
        {
            @Override
            public Function<T, R> getRealFunction()
            {
                return func;
            }
        };
    }

    public String toString()
    {
        return super.toString()+"["+getRealFunction()+"]";
    }
}
