package cell.function;

import java.io.Serializable;
import java.util.function.Consumer;

import bap.cells.BasicStackCell;

public abstract class CConsumer<T extends Serializable> extends BasicStackCell implements IConsumer<T>
{
    public static <T extends Serializable> CConsumer<T> NEW(Consumer<T> consumer)
    {
        return new CConsumer<T>()
        {
            @Override
            public Consumer<T> getRealConsumer()
            {
                return consumer;
            }
        };
    }

    public String toString()
    {
        return super.toString()+"["+getRealConsumer()+"]";
    }
}
