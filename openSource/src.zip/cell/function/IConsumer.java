package cell.function;

import java.io.Serializable;
import java.util.function.Consumer;

import cell.CellIntf;

public interface IConsumer<T extends Serializable> extends CellIntf
{
    public Consumer<T> getRealConsumer();
    
    public default void accept(T t)
    {
        getRealConsumer().accept(t);
    }
}
