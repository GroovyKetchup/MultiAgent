package cell.function;

import java.io.Serializable;
import java.util.function.Function;

import cell.CellIntf;

public interface IFunction<T extends Serializable, R extends Serializable> extends CellIntf 
{
    public Function<T, R> getRealFunction();
    
    public default R apply(T t)
    {
        return getRealFunction().apply(t);
    }
}
