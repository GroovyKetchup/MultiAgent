package cell.function;

import java.io.Serializable;
import java.util.function.BiConsumer;

import bap.cells.BasicStackCell;

public abstract class CBiConsumer<T extends Serializable,U extends Serializable> extends BasicStackCell implements IBiConsumer<T, U>
{
    public static <T extends Serializable,U extends Serializable> CBiConsumer<T, U> NEW(BiConsumer<T, U> consumer)
    {
        return new CBiConsumer<T ,U>()
        {
            @Override
            public BiConsumer<T, U> getRealConsumer()
            {
                return consumer;
            }
        };
    }
    
    public String toString()
    {
        return super.toString()+"["+getRealConsumer()+"]";
    }
    
}
