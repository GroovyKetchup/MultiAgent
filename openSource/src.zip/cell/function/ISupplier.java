package cell.function;

import java.io.Serializable;
import java.util.function.Supplier;

import cell.CellIntf;

public interface ISupplier<R extends Serializable> extends CellIntf
{
    public Supplier<R> getRealSupplier();
    
    public default R get() 
    {
        return getRealSupplier().get();    
    }
}
