package cell.function;

import java.io.Serializable;
import java.util.function.BiFunction;

import bap.cells.BasicStackCell;

public abstract class CBiFunction<T extends Serializable, U extends Serializable, R extends Serializable> extends BasicStackCell implements IBiFunction<T, U, R>
{
    public static <T extends Serializable, U extends Serializable, R extends Serializable> CBiFunction<T, U, R> NEW(BiFunction<T, U, R> func)
    {
        return new CBiFunction<T ,U, R>()
        {
            @Override
            public BiFunction<T, U, R> getRealFunction()
            {
                return func;
            }
        };
    }

    public String toString()
    {
        return super.toString()+"["+getRealFunction()+"]";
    }
}
