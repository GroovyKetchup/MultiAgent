package cell.function;

import java.io.Serializable;
import java.util.function.BiConsumer;

import cell.CellIntf;

public interface IBiConsumer<T extends Serializable,U extends Serializable> extends CellIntf
{
    public BiConsumer<T, U> getRealConsumer();
    
    public default void accept(T t, U u)
    {
        getRealConsumer().accept(t, u);
    }
}
