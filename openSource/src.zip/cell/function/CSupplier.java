package cell.function;

import java.io.Serializable;
import java.util.function.Supplier;

import bap.cells.BasicStackCell;

public abstract class  CSupplier<R extends Serializable> extends BasicStackCell implements ISupplier<R>
{
    public static <R extends Serializable> CSupplier<R> NEW(Supplier<R> spl)
    {
        return new CSupplier<R>()
        {
            @Override
            public Supplier<R> getRealSupplier()
            {
                return spl;
            }
        };
    }
    
    public String toString()
    {
        return super.toString()+"["+getRealSupplier()+"]";
    }
}
