package cell.function;

import java.io.Serializable;
import java.util.function.BiFunction;

import cell.CellIntf;

public interface IBiFunction<T extends Serializable, U extends Serializable, R extends Serializable> extends CellIntf
{
    public BiFunction<T, U, R> getRealFunction();

    public default R apply(T t, U u)
    {
        return getRealFunction().apply(t, u);
    }
}
