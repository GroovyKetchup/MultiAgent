package cell;

import crpc.CRpcCallbackForeverIntf;
import crpc.CallbackLocalMethod;

/**
 * 代表资源操作的cell，可以被转发传递，但是关闭逻辑需要触发close 
 *
 *服务类Cell在动态被替换时（例如插件中动态服务每次发布新的，都会把老的shutdown掉），会执行stopService动作
 *新的服务会先上线接替，之后才会异步慢慢的逐步shutdown老的服务并释放，如果shutdown失败或异常只会记录日志并抛弃
 *
 *服务CELL的实现类建议派生于BasicServiceCell，并按要求实现启停动作
 *如果无实际启停需求，可以派生于EmptyServiceCell
 *
 *
 * 实现类样例：
 * public class CServiceDemo extends BasicServiceCell implements IServiceDemo
 * {
 *      public void test(){
 *          //Do Something Customized
 *      };
 * }
 */
public interface ServiceCellIntf extends CellIntf, CRpcCallbackForeverIntf
{
    /**
     * 服务类Cell，必须是单例
     */
    @CallbackLocalMethod
    public default boolean isSingleton() {
        return true;
    };
    
    /**
     * 服务类Cell，永不释放Callback对外的服务缓存
     */
    @CallbackLocalMethod
    public default void releaseLocalCache()
    {
        // 服务类细胞，常驻内存，且Singlton，永不释放
        
    }
    
    @CallbackLocalMethod
    public default void close()
    {
        // 不要实现该函数
        // 服务类细胞默认没有close一说，既不能简单的关闭服务（不可以随意释放本地资源）
        // 服务的停止，必须显式操作，确定要调用停止动作方可（stopService）
    }

    // 返回服务当前是否正常启动了（默认不启动任何东西，如果有真实启动需求，那么一定要实现该函数如实返回服务状态）
    public default boolean isStarted()
    {
        return true;
    }
    
    // 服务启动，完成一些服务启动初始化等动作（例如一些连接池、线程池等的初始化）
    // 启动动作允许出错异常，启动失败
    public default void startService() throws Exception
    {
        
    }
    
    // 服务有热重启（热替换）的需要，本地的一些资源需要释放，例如连接、线程池等
    // 关停动作不允许抛出异常，自行消化关停失败的日志处理，且最好静默结束
    public default void stopService()
    {
        
    }
    
}
