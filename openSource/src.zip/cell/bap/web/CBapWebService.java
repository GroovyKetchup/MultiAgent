package cell.bap.web;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cdao.mgr.CDaoUtil;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.common.util.javac.LvProblem;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.BasicServiceCell;
import bap.java.CJavaCode;
import bap.java.CJavaFolderDto;
import bap.java.CJavaProjectDto;
import bap.java.project.CJavaCenter;
import bap.java.project.CJavaHint;
import cplugin.ms.dto.CResFileDto;

public class CBapWebService extends BasicServiceCell implements IBapWebService
{

    protected void doStartService() throws Exception
    {
        
    }

    protected void doStopService()
    {
        
    }

    public CJavaCode getCode(String codeUuid) throws Exception
    {
//        ToolUtilities.sleep(10);
        return CJavaCenter.getMe().getJavaCode(codeUuid);
    }
    
    public CJavaCode saveJavaCode(CJavaCode newCode, boolean autoCompile) throws Exception
    {
        return CJavaCenter.getMe().saveJavaCode(newCode, autoCompile);
    }

    public List<CJavaProjectDto> getAllProjects() throws Exception
    {
        return CDaoUtil.convertDtos((List)CJavaCenter.getMe().getAllProjects(), CJavaProjectDto.class);
    }
    
    public List<CJavaFolderDto> getFolders(String pjUuid) throws Exception
    {
        return CDaoUtil.convertDtos((List)CJavaCenter.getMe().getFolders(pjUuid), CJavaFolderDto.class);
    }

    public List<String> getAllPackages(String projectUuid, String folderUuid) throws Exception
    {
        return new LinkedList<String>(CJavaCenter.getMe().queryPackage(projectUuid, folderUuid));
    }
    
    public List<CJavaCode> getChildCodeBrief(String projectUuid, String folderUuid, String sPackage)
    {
        return CJavaCenter.getMe().getBuilder_Force(projectUuid).getChildCodeBrief(folderUuid, ToolUtilities.getString(sPackage, ""));
    }
    
    public List<CResFileDto> queryResFiles(String projectUuid, String filterFolderUuid, String pkg, boolean onlyBrief) throws Exception
    {
        return CDaoUtil.convertDtos((List)CJavaCenter.getMe().queryResFiles(projectUuid, filterFolderUuid, pkg, onlyBrief), CResFileDto.class);
    }

    public Map<String, ClassNameInfo> searchClass(CJavaCode code, String sPreFix, int iCurrentPos) throws Exception
    {
        Map<String,Object> map =  CJavaCenter.getMe().searchClass(code, sPreFix, iCurrentPos);
        Map<String, ClassNameInfo> mapRet = new HashMap();
        for (Entry<String, Object> ent : map.entrySet()) {
            if (ent.getValue() instanceof ClassNameInfo)
                mapRet.put(ent.getKey(), (ClassNameInfo) ent.getValue());
            else {
                String v = "";
                if (ent.getValue() instanceof String)
                    v = (String)ent.getValue();
                else
                    v = ToolUtilities.logString(ent.getValue(), false);
                
                mapRet.put(ent.getKey(), new ClassNameInfo(CmnUtil.getSimpleClassName(v), v, null));
            }
        }
        
        return mapRet;
    }

    public Map<String, CodeDeclareInfo> searchMethodField(CJavaCode code, String sTotalPreword, int iCurrentPos) throws Exception
    {
        Map<String, CodeDeclareInfo> mapRet =new  HashMap();
        
        String lastWord = "";
        String preWord = sTotalPreword;
        int lastPoint = sTotalPreword.lastIndexOf('.');
        if (lastPoint >= 0) {
            preWord = sTotalPreword.substring(0, lastPoint);
            lastWord = sTotalPreword.substring(lastPoint+1);
        }
        
        Map<String, Object> map = CJavaCenter.getMe().searchMethodField(code, preWord, iCurrentPos);
        for (Entry<String, Object> ent : map.entrySet()) {
            if (lastWord.isEmpty() || ent.getKey().toLowerCase().startsWith(lastWord.toLowerCase()))
                if (ent.getValue() instanceof CodeDeclareInfo)
                    mapRet.put(ent.getKey(), (CodeDeclareInfo) ent.getValue());
        }
        System.err.println(mapRet.size());
        return mapRet;
    }

    public List<CJavaHint> searchHint(CJavaCode code, int pos) throws Exception
    {
        return CJavaCenter.getMe().searchHint(code, pos);
    }

    public int checkAutoImport(CJavaCode code, String fullClass) throws Exception
    {
        return CJavaCenter.getMe().checkAutoImport(code, fullClass);
    }

    public List<LvProblem> compileSingleCode(CJavaCode code, boolean useCache) throws Exception
    {
        return CJavaCenter.getMe().compileSingleCode(code, useCache);
    }
}
