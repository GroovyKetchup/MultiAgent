package cell.bap.web;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.nutz.dao.Cnd;

import com.cdao.mgr.CDaoUtil;
import com.cdao.model.CDoIcon;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.SimpleServiceCell;
import bap.image.CIconDto;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import ms.cmn.util.MD5Util;

public class CBapIconService extends SimpleServiceCell implements IBapIconService
{
//    private final PluginAgentListener _lsnr = new PluginAgentListener() {
//
//        public void afterPluginLoaded(long newTagID)
//        {
//            
//        }
//    };
//    
//    protected void doStartService() throws Exception
//    {
//        ClassFactory.addPluginListner(_lsnr);
//    }
//
//    protected void doStopService()
//    {
//        ClassFactory.removePluginListner(_lsnr);
//    }

    public CIconDto saveImage(CIconDto img) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            CDoIcon iconDo = dao.queryDo(CDoIcon.class, Cnd.where(CDoIcon.Code, "=", img.getCode()), CDoIcon.UUID);
            if (iconDo == null)
            {
                iconDo = new CDoIcon();
                iconDo.setImage(img.getImage());
                iconDo.setMd5(MD5Util.encode(img.getImage()));
                iconDo.setUpdateTime(System.currentTimeMillis());
                dao.createDo(iconDo);
            } else
            {
                iconDo.setImage(img.getImage());
                iconDo.setMd5(MD5Util.encode(img.getImage()));
                iconDo.setUpdateTime(System.currentTimeMillis());
                dao.updateDo(iconDo);
            }
            dao.commit();
            return CDaoUtil.convertDto(iconDo, CIconDto.class);
        }
    }

    public byte[] getResImage(String path) throws IOException
    {
        URL url = ClassFactory.getResourceURL(path);
        if (url == null)
            return null;
        
        return ToolBasic.readAndCloseInputStream(url.openStream());
    }
    
    public CIconDto getImage(String name) throws Exception
    {
        if (CmnUtil.isStringEmpty(name))
            return null;

        // 优先判断是否有图标资源
        if (name.toLowerCase().startsWith(CIconDto.RES_PREFIX))
        {
            String path = name.substring(CIconDto.RES_PREFIX.length());
            byte[] bytes = getResImage(path);
            if (bytes == null)
                return null;

            CIconDto dto = new CIconDto();
            dto.setCode(name);
            dto.setImage(bytes);
            dto.setMd5(MD5Util.encode(bytes));
            dto.setUpdateTime(getResTag(bytes)); // 资源文件用MD5的hashCode代替
            dto.setResource(true);
            return dto;
        }

        // 其次才从库中取
        try (IDao dao = IDaoService.newIDao())
        {
            CDoIcon iconDo = dao.queryDo(CDoIcon.class, Cnd.where(CDoIcon.Code, "=", name));
            if (iconDo == null)
                return null;

            CIconDto dto = CDaoUtil.convertDto(iconDo, CIconDto.class);
            dto.setMd5(MD5Util.encode(dto.getImage()));
            return dto;
        }
    }
    
    // 就用字节长度作为判断吧，字节数没变化而图标变了的概率太小太小
    public static long getResTag(byte[] bytes) throws Exception
    {
        return ToolUtilities.getObjectSize(bytes);
    }
    
    long _lastPluginTag = -1;
    ConcurrentHashMap<String, Long> _cacheTag = new ConcurrentHashMap();
    public Long getCachedTag(String name)
    {
        if (ClassFactory.getCurrentPluginTag() != _lastPluginTag)
        {
            _lastPluginTag = ClassFactory.getCurrentPluginTag();
            _cacheTag.clear();
        }
        
        return _cacheTag.get(name);
    }
    
    protected void putCachedTag(String name, long tag)
    {
        _cacheTag.put(name, tag);
    }
    
    public boolean isImageDirty(String name, long imageTag) throws Exception
    {
        if (name.toLowerCase().startsWith(CIconDto.RES_PREFIX))
        {
            Long tag = getCachedTag(name);
            if (tag != null)
                return tag != imageTag;
            
            // 资源文件用MD5的hashCode代替
            String path = name.substring(CIconDto.RES_PREFIX.length());
            
            byte[] bytes = getResImage(path);
            if (bytes == null)
            {
                // 不存在的，以-1代表
                putCachedTag(name, -1L);
                return true;
            }
            
            tag = getResTag(bytes);
            putCachedTag(name, tag);
            
            return tag != imageTag;
        }else
        {
            try (IDao dao = IDaoService.newIDao())
            {
                CDoIcon iconDo = dao.queryDo(CDoIcon.class, Cnd.where(CDoIcon.Code, "=", name), CDoIcon.UpdateTime);
                if (iconDo == null)
                    return true;

                // 没设置时间的，一律认为不会变，省得重复加载
                return iconDo.getUpdateTime() != null && iconDo.getUpdateTime() > 0 && iconDo.getUpdateTime() != imageTag;
            }
        }
    }

}
