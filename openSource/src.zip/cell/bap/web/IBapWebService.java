package cell.bap.web;

import java.util.List;
import java.util.Map;

import com.leavay.common.util.javac.ClassNameInfo;
import com.leavay.common.util.javac.CodeDeclareInfo;
import com.leavay.common.util.javac.LvProblem;

import bap.java.CJavaCode;
import bap.java.CJavaFolderDto;
import bap.java.CJavaProjectDto;
import bap.java.project.CJavaHint;
import cell.ServiceCellIntf;
import cplugin.ms.dto.CResFileDto;
import flutter.coder.FlutterBuilder;

public interface IBapWebService extends ServiceCellIntf
{
    public CJavaCode getCode(String codeUuid) throws Exception;
    
    public CJavaCode saveJavaCode(CJavaCode newCode, boolean autoCompile) throws Exception;

    public List<CJavaProjectDto> getAllProjects() throws Exception;

    public List<CJavaFolderDto> getFolders(String pjUuid) throws Exception;

    public List<String> getAllPackages(String projectUuid, String folderUuid) throws Exception;

    public List<CJavaCode> getChildCodeBrief(String projectUuid, String folderUuid, String sPackage);

    public List<CResFileDto> queryResFiles(String projectUuid, String filterFolderUuid, String pkg, boolean onlyBrief) throws Exception;

    // 总的代码辅助
    public List<CJavaHint> searchHint(CJavaCode code, int pos) throws Exception;

    // 检查是否需要自动导入，并返回导入插入点
    public int checkAutoImport(CJavaCode code, String fullClass) throws Exception;
    
    // Alt+Slash 代码辅助
    public Map<String, ClassNameInfo> searchClass(CJavaCode code, String sPreFix, int iCurrentPos) throws Exception;

    public Map<String, CodeDeclareInfo> searchMethodField(CJavaCode code, String sTotalPreword, int iCurrentPos) throws Exception;
    
    public List<LvProblem> compileSingleCode(CJavaCode code, boolean useCache) throws Exception;

    public static void main(String[] args) throws Exception
    {
        FlutterBuilder bd = new FlutterBuilder().setTargetFile("F:\\flutter\\bap_code_web\\lib/java/IBapWebService.dart");
        bd.buildInterface(IBapWebService.class);

    }
}
