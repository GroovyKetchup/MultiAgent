package cell.bap.web;

import bap.cells.Cells;
import bap.image.CIconDto;
import cell.ServiceCellIntf;
import flutter.coder.FlutterBuilder;
import flutter.coder.annt.NullReturn;
public interface IBapIconService extends ServiceCellIntf
{
    public static IBapIconService get(){ return Cells.get(IBapIconService.class);}

    // 保存图片资源
    public CIconDto saveImage(CIconDto img) throws Exception;
    
    // 获取图片资源
    @NullReturn
    public CIconDto getImage(String name) throws Exception;
    
    // 图片是否过期（如果图片不存在，返回true），imageTag不一致也返回true
    public boolean isImageDirty(String name, long imageTag) throws Exception;
    
    public static void main(String[] args) throws Exception{
        FlutterBuilder bd = new FlutterBuilder().setTargetFile("F:\\flutter_dev\\core\\lib\\java\\icon_service.dart");
        bd.buildInterface(IBapIconService.class);
    }
}