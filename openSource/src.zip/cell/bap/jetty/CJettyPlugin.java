package cell.bap.jetty;

import java.io.File;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.Servlet;

import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.server.handler.gzip.GzipHandler;
import org.eclipse.jetty.servlet.DefaultServlet;
import org.eclipse.jetty.servlet.FilterHolder;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlets.DoSFilter;
import org.eclipse.jetty.servlets.HeaderFilter;
import org.eclipse.jetty.util.resource.Resource;

import com.kwaidoo.ms.tool.CmnUtil;
import com.leavay.common.util.MppContext;

import bap.cells.BasicCell;
import web.config.Configuration;
import web.config.FilterMapping;
import web.config.ServletMapping;

public class CJettyPlugin extends BasicCell implements IJettyPlugin{

	@Override
	public void initServletContext(ServletContextHandler servletContext) throws Exception {
		servletContext.setInitParameter("dirAllowed", ""+Configuration.getInstance().isDirAllowed());
//		org.eclipse.jetty.servlet.Default.dirAllowed
		servletContext.setInitParameter(DefaultServlet.CONTEXT_INIT+"dirAllowed", ""+Configuration.getInstance().isDirAllowed());
		Class cls = null;
		for(ServletMapping servletMapping : Configuration.getInstance().getServletMapping()) {
			String servletClassName = servletMapping.getServlet();
			if(!CmnUtil.isStringEmpty(servletClassName)) {
				cls = (Class<? extends Servlet>) Class.forName(servletClassName);
				List<String> urlPatterns = servletMapping.getUrlPatternList();
				for(String urlPattern : urlPatterns) {
					if(!CmnUtil.isStringEmpty(urlPattern)) {
						servletContext.addServlet(cls, urlPattern);
					}
				}
			}
		}
	}
	
	@Override
	public void appendStaticHandler(HandlerCollection handlers) throws Exception {
		Map<String,String> dirs = Configuration.getInstance().getResourceDirs();
		if(CmnUtil.isMapEmpty(dirs)) {
			return;
		}
		for(String dir:dirs.keySet()) {
			String path = dirs.get(dir);
			File logDir = new File(MppContext.getRootDir(),path);
			ServletContextHandler servletContext2 = new ServletContextHandler();
			servletContext2.setContextPath("/"+dir);
			servletContext2.setBaseResource(Resource.newResource(logDir));
			// 预压缩
			servletContext2.setInitParameter("precompressed", "br=.br,gzip=.gz,bzip2=.bz");
			servletContext2.setInitParameter("gzip", "true");
			servletContext2.setInitParameter(DefaultServlet.CONTEXT_INIT+"cacheControl", "max-age=0,public");
//			servletContext2.setInitParameter(DefaultServlet.CONTEXT_INIT+"dirAllowed", "true");
			
	//		servletContext2.setInitParameter("dirAllowed", ""+Configuration.getInstance().isDirAllowed());
			servletContext2.addServlet(DefaultServlet.class, "/");
			GzipHandler gzipHandler2 = new GzipHandler();
			gzipHandler2.setHandler(servletContext2);	
			handlers.addHandler(gzipHandler2);
		}
	}
	
	@Override
	public void initCrossOriginFilter(FilterHolder holder) throws Exception {
		if(CmnUtil.isMapEmpty(Configuration.getInstance().getCrossOriginFilter()))
			return;
		for(Entry<String,String> setting : Configuration.getInstance().getCrossOriginFilter().entrySet()) {
			String key = setting.getKey();
			String value = setting.getValue();
			holder.setInitParameter(key, value);
		}
	}
	
	@Override
	public void initHeaderFilter(ServletContextHandler servletContext) throws Exception {
		if(Configuration.getInstance().getHeaderFilter() == null)
			return;
		//补充额外的请求头设置
		FilterHolder holder = new FilterHolder(HeaderFilter.class);
		for(Entry<String,String> setting : Configuration.getInstance().getHeaderFilter().entrySet()) {
			String key = setting.getKey();
			String value = setting.getValue();
			holder.setInitParameter(key, value);
		}
		servletContext.addFilter(holder, "/*", null);
	}
	
	@Override
	public void initDosFilter(ServletContextHandler servletContext) throws Exception {
		if(Configuration.getInstance().getDosFilter() == null)
			return;
		FilterHolder holder = new FilterHolder(DoSFilter.class);
		for(Entry<String,String> setting : Configuration.getInstance().getDosFilter().entrySet()) {
			String key = setting.getKey();
			String value = setting.getValue();
			holder.setInitParameter(key, value);
		}
		servletContext.addFilter(holder, "/*", null);
	}

	@Override
	public void initCustomFilters(ServletContextHandler servletContext) throws Exception {
		Class<? extends Filter> cls = null;
		for(FilterMapping filterMapping : Configuration.getInstance().getFilterMapping()) {
			String filterClassName = filterMapping.getFilterClass();
			if(!CmnUtil.isStringEmpty(filterClassName)) {
				cls = (Class<? extends Filter>) Class.forName(filterClassName);
				List<String> urlPatterns = filterMapping.getUrlPatternList();
				for(String urlPattern : urlPatterns) {
					if(!CmnUtil.isStringEmpty(urlPattern)) {
						List<DispatcherType> dispatcherTypes = filterMapping.getDispatchesList();
						EnumSet<DispatcherType> dispatches = null;
						if(!dispatcherTypes.isEmpty()) {
							dispatches = EnumSet.copyOf(dispatcherTypes);
						}
						servletContext.addFilter(cls, urlPattern, dispatches);
					}
				}
			}
		}
	}
	
}
