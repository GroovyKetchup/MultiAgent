package cell.bap.jetty;

import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.servlet.FilterHolder;
import org.eclipse.jetty.servlet.ServletContextHandler;

import bap.cells.Cells;
import cell.PluginCellIntf;

public interface IJettyPlugin extends PluginCellIntf{

	public static IJettyPlugin get() {
		return Cells.get(IJettyPlugin.class);
	}
	
	public default void initServletContext(ServletContextHandler servletContext) throws Exception{
		
	}
	
	public default void appendStaticHandler(HandlerCollection handlers) throws Exception{
		
	}
	
	public default void initCrossOriginFilter(FilterHolder holder) throws Exception{
		
	}
	
	public default void initHeaderFilter(ServletContextHandler servletContext) throws Exception{
		
	}
	
	public default void initDosFilter(ServletContextHandler servletContext) throws Exception{
		
	}
	
	public default void initCustomFilters(ServletContextHandler servletContext) throws Exception{
		
	}
}
