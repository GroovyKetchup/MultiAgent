package cell.bap.dev.store;

import java.util.List;

import com.leavay.common.util.ToolUtilities;

import bap.cells.Cells;
import cell.ServiceCellIntf;
public interface IBapStore extends ServiceCellIntf
{
    public static IBapStore get(){ return Cells.get(IBapStore.class);}
    
    public default List queryWares()
    {
        return ToolUtilities.newArrayList("Developing ... ");
    }
}