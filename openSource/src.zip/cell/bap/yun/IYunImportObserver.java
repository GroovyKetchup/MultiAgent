package cell.bap.yun;

import com.leavay.common.util.ProgressCtrl.crpc.IProgress;

import bap.cells.Cells;
import bap.md.java.CJavaProject;
import bap.md.yun.ArtifactWare;
import cell.CellIntf;
import cell.cdao.IDao;
import cmn.security.dto.UserPassword;
public interface IYunImportObserver extends CellIntf
{

    public static IYunImportObserver get(){ return Cells.get(IYunImportObserver.class);}
    
    public default void verifyArtifactWare(IProgress prog, ArtifactWare art, UserPassword yunUser)
    {
        //TODO : 实现你自己的导入前校验
    }
    
    public default void beforeCommit(IProgress prog, IDao dao, CJavaProject newProject)
    {
        //TODO : 最后提交之前的HOOK
    }
    

    public default void afterAll(IProgress prog, CJavaProject newProject)
    {
        //TODO : 最后提交之前的HOOK
    }
}