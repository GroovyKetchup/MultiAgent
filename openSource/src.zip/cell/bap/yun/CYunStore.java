package cell.bap.yun;

import static bap.md.yun.ArtifactDefine.ArtifactId;
import static bap.md.yun.ArtifactDefine.ExclusiveModel;
import static bap.md.yun.ArtifactDefine.GroupId;
import static bap.md.yun.ArtifactDefine.MainPage;
import static bap.md.yun.ArtifactDefine.Version;
import static bap.md.yun.ArtifactDefine.VersionSeq;
import static bap.md.yun.ArtifactWare.PublishTime;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.Cnd;
import org.nutz.dao.util.cri.Exps;
import org.nutz.dao.util.cri.SqlExpressionGroup;

import com.cdao.dto.CPager;
import com.cdao.dto.DataRow;
import com.cdao.impl.entity.field.SlaveTable;
import com.cdao.mgr.CSession;
import com.cdao.model.CDoAttach;
import com.cdao.model.CDoBasic;
import com.cdao.model.CDoLink;
import com.cdao.model.CDoModel;
import com.leavay.common.util.RelationMap;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.cjson.CJson;
import com.leavay.dfc.gui.LvUtil;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.BasicServiceCell;
import bap.md.yun.ArtifactDefine;
import bap.md.yun.ArtifactWare;
import bap.yun.ArtifactConst;
import bap.yun.ArtifactPackage;
import bap.yun.YunVersion;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import cmn.security.dto.UserPassword;
import cmn.util.Nulls;

public class CYunStore extends BasicServiceCell implements IYunStore
{
    protected void doStartService() throws Exception
    {
        
    }

    protected void doStopService()
    {
        
    }

    public void importArtifact(ArtifactPackage pkg, UserPassword user) throws Exception
    {
        publishArtifact(pkg, user, false);
    }
    
    public void publishArtifact(ArtifactPackage pkg, UserPassword user) throws Exception
    {
        publishArtifact(pkg, user, true);
    }
    
    public void publishArtifact(ArtifactPackage pkg, UserPassword user, boolean verify) throws Exception
    {
        if (verify)
        {
            try
            {
                YunVersion.verify(pkg.getArtifactDefine().getVersion());
            }catch (Throwable err)
            {
                throw new Exception("Invalid version : "+pkg.getArtifactDefine(), err);
            }
        }
        
        // 先登录校验
        CSession session = IDaoService.get().loginWithSession(user.getUser(), user.getPassword());
        IYunStoreAuth.get().canPublishArtifact(session);
        
        try (IDao dao = IDaoService.newIDao())
        {
            ArtifactDefine def = pkg.getArtifactDefine();

            // 发布包，一定owner为空（否则就是挂在工程下的)
            ArtifactWare art = (ArtifactWare) dao.queryDo(ArtifactWare.class.getName(),
                    Cnd.where(GroupId, "=", def.getGroupId()).and(ArtifactId, "=", def.getArtifactId()).and(Version, "=", def.getVersion()));
            if (art == null)
            {
                art = new ArtifactWare();
                art.setDefine(def);
                art.setPublishTime(System.currentTimeMillis());
                art.setCommiter(user.getUser());
                art = dao.createDo(art);
            }else
            {
                // 只有原提交人可以修改同版本的提交物，同版本的提交物不允许被别人覆盖
                if (!CmnUtil.isStringEqual(art.getCommiter(), user.getUser()))
                    throw new Exception("Only original commiter could modify existed artifact : " + art);
                
                art.setDefine(def);
                art.setPublishTime(System.currentTimeMillis());
                dao.updateDo(art, ArtifactWare.Description, MainPage, ExclusiveModel, ArtifactDefine.IconImg, ArtifactDefine.VersionSeq, PublishTime);
            }

            if (pkg.getProjectPkg() != null)
                dao.saveAttach(art.getGid(), art.ProjectPkg, ToolUtilities.newArrayList(pkg.getProjectPkg()), true);

            if (pkg.getReleasePkg() != null)
                dao.saveAttach(art.getGid(), art.ReleasePkg, pkg.getReleasePkg(), true);
            
            if (pkg.getModelPkg() != null)
                dao.saveAttach(art.getGid(), art.ModelPkg, pkg.getModelPkg(), true);
            
            // 创建依赖链路（全删全建），依赖路径从原来的slaveTable转化为link
            dao.deleteLink(Cnd.where(CDoLink.SrcKey, "=", art.getUuid()).and(CDoLink.Flag, "=", ArtifactConst.LINK_FLAG_DEPEND));
            SlaveTable<ArtifactDefine> lstDep = def.getDependTo();
            if (lstDep != null)
                for (ArtifactDefine dep : lstDep)
                {
                    ArtifactWare toArt = queryArtifact(dep.getGroupId(), dep.getArtifactId(), dep.getVersion());
                    CmnUtil.assertNotNull(toArt, "Depend on invalid target artifact : " + dep);
                    dao.createLink(art.getGid(), toArt.getGid(), ArtifactConst.LINK_FLAG_DEPEND);
                }

            dao.commit();
        }
    }
    
    public int deleteArtifact(UserPassword user, String groupId, String artifactId, String version) throws Exception
    {
        // 先登录校验
        CSession session = IDaoService.get().loginWithSession(user.getUser(), user.getPassword());
        
        StringBuffer sb = new StringBuffer();
        try (IDao dao = IDaoService.newIDao())
        {
            List<String> lstDel = new LinkedList<String>();
            ArtifactWare art = (ArtifactWare)dao.queryDo(ArtifactWare.class.getName(),
                    Cnd.where(GroupId, "=", groupId).and(ArtifactId, "=", artifactId).and(Version, "=", version), ArtifactWare.FIELDS_BRIEF); // 需查出commiter,以便鉴权
            if (art == null)
                return 0;

            // 鉴权
            IYunStoreAuth.get().canDeleteArtifact(session, art);
            
            lstDel.add(art.getUuid());
            sb.append(art.toString()).append(',');
            
            ArtifactGraph graph = queryDependByGraph(ToolUtilities.newHashSet(art.getUuid()), true);
            for (String depBy : Nulls.get(graph.getRelations().getAllSource(art.getUuid())))
            {
                ArtifactWare artDep = graph.getArtifacts().get(depBy);
                // 鉴权被依赖项
                IYunStoreAuth.get().canDeleteArtifact(session, artDep);
                lstDel.add(depBy);// 所有依赖我的(直接+间接), 统统删除
                

                sb.append(artDep.toString()).append(',');
            }
            
            // 删除所有相关组件
            int rows = dao.deleteDos(ArtifactWare.class.getName(),
                    Cnd.where(Exps.inStr(CDoBasic.UUID, lstDel)));
            
            dao.commit();
            ToolUtilities.warnAndOutput("CYunStore", "Deleted artifact("+art.getArtifactKey()+") with dependencies by '"+session.getUserCode()+"' : " + sb.toString());
            return rows;
        }
    }

    // version可以不指定，则按版本排序取最大的（排序规则是字符串比较规则）
    public ArtifactWare queryArtifact(String groupId, String artifactId, String version) throws Exception
    {
        return queryArtifact(groupId, artifactId, version, false, ArtifactWare.FIELDS_BRIEF);
    }
    
    // version可以不指定，版本序号最大的（版本序号由版本号生成），如果版本序号相同（无值）以发布时间靠后为准
    public ArtifactWare queryArtifact(String groupId, String artifactId, String version, boolean includeDepend, String ... fields) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = Cnd.where(GroupId, "=", groupId).and(ArtifactId, "=", artifactId);
            if (!CmnUtil.isStringEmpty(version))
                cnd = cnd.and(Version, "=", version);
            cnd.desc(ArtifactWare.VersionSeq);
            cnd.desc(ArtifactWare.PublishTime);
                
            ArtifactWare art = (ArtifactWare) dao.queryDo(ArtifactWare.class.getName(), cnd, fields);
            if (art != null && includeDepend)
            {
                Map<String, String> mapTarget = dao.queryLinkTarget(ToolBasic.newHashSet(art.getUuid()), ArtifactConst.LINK_FLAG_DEPEND);
                if (!CmnUtil.isObjectEmpty(mapTarget))
                {
                    List<ArtifactWare> lstDep = dao.queryDoList(ArtifactWare.class, Cnd.where(Exps.inStr(CDoBasic.UUID, mapTarget.keySet())), fields);
                    if (!CmnUtil.isObjectEmpty(lstDep))
                    {
                        // 将ware对象转换为define对象传出（模拟定义端的dependTo数据）
                        SlaveTable<ArtifactDefine> slvDef = new SlaveTable<ArtifactDefine>(); 
                        for (ArtifactWare ware : lstDep)
                            slvDef.add(new ArtifactDefine().setDefine(ware));
                        art.setDependTo(slvDef);
                    }
                }
            }
            
            return art;
        }
    }
    
    public List<CDoAttach> queryReleasePackage(String artUuid) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryAttach(artUuid, ArtifactWare.ReleasePkg);
        }
    }
    
    public List<CDoModel> queryModelPackage(String artUuid) throws Exception
    {
        List<CDoModel> lstModel = new LinkedList<CDoModel>();
        try (IDao dao = IDaoService.newIDao())
        {
            List<CDoAttach> lstModelFile = dao.queryAttach(artUuid, ArtifactWare.ModelPkg);
            if (!CmnUtil.isObjectEmpty(lstModelFile))
            {
                for (CDoAttach att : lstModelFile)
                {
                    if (!att.isBinary() && !CmnUtil.isStringEmpty(att.getContentText()))
                    {
                        CDoModel md = (CDoModel) CJson.fromJson(att.getContentText());
                        lstModel.add(md);
                    }
                }
            }
        }
        
        
        return lstModel;
    }
    
    // zip
    public CDoAttach queryProjectPackage(String artUuid) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            List<CDoAttach> lstAtt = dao.queryAttach(artUuid, ArtifactWare.ProjectPkg);
            if (CmnUtil.getObjectSize(lstAtt) >= 1)
                return lstAtt.get(0);
            
            return null;
        }
    }

    public MultiPageResult<ArtifactWare> queryArtifact(Cnd cnd, CPager pager, String ... fields) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryDoPage(ArtifactWare.class.getName(), cnd, pager, fields);
        }
    }
    
    public MultiPageResult<DataRow> queryRows(String sqlText, Map<String, Object> vars, Map<String, Object> params, int startPos, int pageSize) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            return dao.queryRows(sqlText, vars, params, startPos, pageSize);
        }
    }
    
    public MultiPageResult<ArtifactWare> queryNewestArtifact(String whereExp, int pos, int pageSize, String ... fields) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            String sql1 = "select " + GroupId + ", " + ArtifactId + ", max(" + VersionSeq + ") max_ver from " + ArtifactWare.TABLE + " group by " + GroupId + ", "
                    + ArtifactId;

            String filterWhere = "";
            if (!CmnUtil.isStringEmpty(whereExp))
                filterWhere = " where " + whereExp;
            
            String afterFrom = "from (select * from " + ArtifactWare.TABLE + filterWhere+ ") a, (" + sql1 + ") b where (a."+GroupId+"=b."+GroupId+" and a."+ArtifactId+"=b."+ArtifactId+" and a."+VersionSeq+"=b.max_ver)";
            
            String sql = "select * "+afterFrom;

            if (!CmnUtil.isObjectEmpty(fields))
            {
                String fs = "";
                for (String f : fields)
                {
                    if (!fs.isEmpty())
                        fs += ", ";
                    fs += "a."+f;
                }
                sql = "select " + fs+" "+ afterFrom;
            }

            return dao.queryEntity(ArtifactWare.class.getName(), sql, null, null, null, pos, pageSize);
        }
    }

    /**
     * 查询组件的依赖目标图谱, 即我依赖了哪些
     * 
     * @param leafArts : 要查询的源头组件
     * @param querySourceArtifact : 是否将源头组件的对象一并查出
     * 返回依赖图谱(内含组件基本信息), 即我依赖哪些组件
     */
    public ArtifactGraph queryDependGraph(Set<String> srcArts, boolean querySourceArtifactDo) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            ArtifactGraph graph = new ArtifactGraph();
            queryDependRelation(dao, graph.getRelations(), srcArts);
            
            LinkedList<String> lstUuids = new LinkedList();
            if (querySourceArtifactDo)
            {
                lstUuids.addAll(srcArts);
            }
            
            if (graph.getRelations().size() > 0)
            {
                lstUuids.addAll(graph.getRelations().getTargetKeys());
            }
            
            if (!CmnUtil.isObjectEmpty(lstUuids))
            {
                SqlExpressionGroup exp = new SqlExpressionGroup();
                exp.andInStrList(ArtifactWare.UUID, lstUuids);
                
                List<ArtifactWare> lstArts = dao.queryDoList(ArtifactWare.class, Cnd.where(exp), ArtifactWare.FIELDS_BRIEF);
                for (ArtifactWare art : lstArts)
                    graph.getArtifacts().put(art.getUuid(), art);
            }

            return graph;
        }
    }

    public void queryDependRelation(IDao dao, RelationMap relations, Set<String> srcArts)
    {
        for (String src : srcArts)
            queryDependRelation(dao, relations, src);
    }
    
    public void queryDependRelation(IDao dao, RelationMap relations, String srcArt)
    {
        Map<String, String> mapTarget = dao.queryLinkTarget(ToolBasic.newHashSet(srcArt), ArtifactConst.LINK_FLAG_DEPEND);
        if (CmnUtil.isObjectEmpty(mapTarget))
            return;
        
        for (String dst : mapTarget.keySet())
        {
            relations.addRelation(srcArt, dst);
        }
        
        // 递归查下一层
        for (String exist : relations.getSourceKeys())
            mapTarget.remove(exist);
        if (!CmnUtil.isObjectEmpty(mapTarget))
                queryDependRelation(dao, relations, mapTarget.keySet());
    }
    

    /**
     * 查询组件被哪些组件依赖的图谱, 即我被谁依赖了
     * 
     * @param dstArts : 要查询的目标组件
     * @param querySourceArtifact : 是否将目标组件对象一并查出
     * 返回被依赖图谱(内含组件基本信息), 即我被哪些组件依赖
     */
    public ArtifactGraph queryDependByGraph(Set<String> dstArts, boolean queryDstArtifactDo) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            ArtifactGraph graph = new ArtifactGraph();
            queryDependByRelation(dao, graph.getRelations(), dstArts);
            
            LinkedList<String> lstUuids = new LinkedList();
            if (queryDstArtifactDo)
            {
                lstUuids.addAll(dstArts);
            }
            
            if (graph.getRelations().size() > 0)
            {
                lstUuids.addAll(graph.getRelations().getSourceKeys());
            }
            
            if (!CmnUtil.isObjectEmpty(lstUuids))
            {
                SqlExpressionGroup exp = new SqlExpressionGroup();
                exp.andInStrList(ArtifactWare.UUID, lstUuids);
                
                List<ArtifactWare> lstArts = dao.queryDoList(ArtifactWare.class, Cnd.where(exp), ArtifactWare.FIELDS_BRIEF);
                for (ArtifactWare art : lstArts)
                    graph.getArtifacts().put(art.getUuid(), art);
            }

            return graph;
        }
    }
    
    // 查询被依赖图谱, 有哪些其它组件依赖目标(dstArts)
    public void queryDependByRelation(IDao dao, RelationMap relations, Set<String> dstArts)
    {
        for (String dst : dstArts)
            queryDependByRelation(dao, relations, dst);
    }
    
    public void queryDependByRelation(IDao dao, RelationMap relations, String dstArt)
    {
        Map<String, String> mapSource = dao.queryLinkSource(ToolBasic.newHashSet(dstArt), ArtifactConst.LINK_FLAG_DEPEND);
        if (CmnUtil.isObjectEmpty(mapSource))
            return;
        
        for (String src : mapSource.keySet())
        {
            relations.addRelation(src, dstArt);
        }
        
        // 递归查下一层
        for (String exist : relations.getTargetKeys())
            mapSource.remove(exist);
        if (!CmnUtil.isObjectEmpty(mapSource))
            queryDependByRelation(dao, relations, mapSource.keySet());
    }

    public CSession login(UserPassword user) throws Exception
    {
        return IDaoService.get().loginWithSession(user.getUser(), user.getPassword());
    }

    // 手工全量更新所有组件的版本序号（升级旧数据），可用于升级旧数据、修复脏版本（一般正常发布是不会出现这个问题的，但是手工修改DO可能导致数据脏）
    public static void updateAllVersionSeq() throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            List<ArtifactWare> lstArts = dao.queryDoList(ArtifactWare.class, null, ArtifactWare.UUID, ArtifactWare.Version);
            for (ArtifactWare art : lstArts)
            {
                String ver = ArtifactDefine.version2Seq(art.getVersion());
                LvUtil.trace(art.getVersion() + " => "+ ver);
                dao.updateDoField(art, ArtifactWare.VersionSeq, ver);
            }
            dao.commit();
            LvUtil.trace("Update Artifact Ware : "+lstArts.size());
            
            List<ArtifactDefine> lstDefs = dao.queryDoList(ArtifactDefine.class, null, ArtifactDefine.UUID, ArtifactDefine.Version);
            for (ArtifactDefine def : lstDefs)
            {
                String ver = ArtifactDefine.version2Seq(def.getVersion());
                LvUtil.trace(def.getVersion() + " => "+ ver);
                dao.updateDoField(def, ArtifactDefine.VersionSeq, ver);
            }
            dao.commit();
            LvUtil.trace("Update Artifact Define : "+lstDefs.size());
        }
    }
}
