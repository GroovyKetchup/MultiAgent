package cell.bap.yun;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.leavay.common.util.RelationMap;
import com.leavay.common.util.ToolUtilities;
import com.leavay.ms.tool.CmnUtil;

import bap.md.yun.ArtifactWare;
import cmn.util.Nulls;

public class ArtifactGraph implements Serializable
{
    private static final long serialVersionUID = -8726325892017286397L;
    
    public HashMap<String, ArtifactWare> artifacts = new HashMap<String, ArtifactWare>();
    public RelationMap relations = new RelationMap();
    
    public HashMap<String, ArtifactWare> getArtifacts()
    {
        return artifacts;
    }
    public void setArtifacts(HashMap<String, ArtifactWare> artifacts)
    {
        this.artifacts = artifacts;
    }
    public RelationMap getRelations()
    {
        return relations;
    }
    public void setRelations(RelationMap relations)
    {
        this.relations = relations;
    }
    
    // 分析哪些Artifact重复冲突的
    // 返回key = ArtifactID， Value=冲突的Artifact列表
    public Map<String, List<ArtifactWare>> analyseConflict()
    {
        Map<String, List<ArtifactWare>> mapRet = new HashMap();
        for (ArtifactWare art : artifacts.values())
        {
            CmnUtil.putMapList(mapRet, art.getArtifactId(), art, false);
        }
        
        for (Iterator<Entry<String, List<ArtifactWare>>> it = mapRet.entrySet().iterator(); it.hasNext();)
        {
            Entry<String, List<ArtifactWare>> ent = it.next();
            if (CmnUtil.getObjectSize(ent.getValue()) <= 1)
                it.remove();
        }
        
        return mapRet;
    }
    
    public String getDependText()
    {
        String s="";
        for (String start : Nulls.get(getRelations().searchStartNodes()))
        {
            if (!s.equals(""))
                s+="\n";
            s+=getDependText(start, 0);
        }
        return s;
    }
    
    public String getDependText(String uuid, int layer)
    {
        ArtifactWare art = getArtifacts().get(uuid);
        
        String s = ToolUtilities.duplicateString("  ", layer)+"- "+art.toString();
        for (String target : Nulls.get(getRelations().getTarget(uuid)))
        {
            s += "\n"+getDependText(target, layer+1);
        }
        return s;
    }
    
}
