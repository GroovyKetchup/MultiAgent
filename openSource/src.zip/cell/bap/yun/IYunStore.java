package cell.bap.yun;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.Cnd;

import com.cdao.dto.CPager;
import com.cdao.dto.DataRow;
import com.cdao.mgr.CSession;
import com.cdao.model.CDoAttach;
import com.cdao.model.CDoModel;
import com.leavay.common.util.MultiPage.MultiPageResult;

import bap.cells.Cells;
import bap.md.yun.ArtifactWare;
import bap.yun.ArtifactPackage;
import cell.ServiceCellIntf;
import cmn.security.dto.UserPassword;

/**
 * 仓库端管理功能
 * 
 * 仓库固化地址配置文件在资源文件中：bap/yun/YunStoreConfig.prop (Bap Resource)
 */
public interface IYunStore extends ServiceCellIntf
{
    public static IYunStore get() {return Cells.get(IYunStore.class);}

    public CSession login(UserPassword user) throws Exception;
    
    /**
     * 
     * version可以不指定，则按版本排序取最大的（排序规则是字符串比较规则）
     * 
     * @param includeDepend : 是否连带查出依赖关系（第一层），并转换为define 列表放在DependTo字段
     */
    public ArtifactWare queryArtifact(String groupId, String artifactId, String version, boolean includeDepend, String ... fields) throws Exception;
    
    /**
     * [危险] : 删除指定组件及所有依赖它的组件(直接或间接依赖它的都将被删除)
     * 默认组件的提交人或者root才能删组件
     * 
     * @param groupId
     * @param artifactId
     * @param version
     * @return 删除的组件数(包含依赖它的)
     */
    public int deleteArtifact(UserPassword user, String groupId, String artifactId, String version) throws Exception;

    public MultiPageResult<ArtifactWare> queryArtifact(Cnd cnd, CPager pager, String ... fields) throws Exception; 
    
    public List<CDoAttach> queryReleasePackage(String artUuid) throws Exception;

    public List<CDoModel> queryModelPackage(String artUuid) throws Exception;

    /**
     * 按版本最新去重，只取最新版本的组件库
     */
    public MultiPageResult<ArtifactWare> queryNewestArtifact(String whereExp, int pos, int pageSize, String ... fields) throws Exception;
    
    // return one zip
    public CDoAttach queryProjectPackage(String artUuid) throws Exception;
    
    public void publishArtifact(ArtifactPackage pkg, UserPassword yunUser) throws Exception;
    
    // 不校验版本号, 直接导入(用于导入maven库或外部第三方包)
    public void importArtifact(ArtifactPackage pkg, UserPassword user) throws Exception;

    /**
     *  查询整颗依赖树，关系中src -> dst代表 A 依赖于 B
     *  例如：TestRedis -> IRedis
     *  
     *  @param querySourceArtifactDo : 是否顺带把源端对象也查出来，默认建议一同查出
     */
    public ArtifactGraph queryDependGraph(Set<String> srcArts, boolean querySourceArtifactDo) throws Exception;
    
    /**
     * 自定义SQL查询，复杂查询 （具体可参考IDao.queryRows）
     */
    public MultiPageResult<DataRow> queryRows(String sqlText, Map<String, Object> vars, Map<String, Object> params, int startPos, int pageSize) throws Exception;
    
    /**
     * 查询组件被哪些组件依赖的图谱, 即我被谁依赖了
     * 
     * @param dstArts : 要查询的目标组件
     * @param querySourceArtifact : 是否将目标组件对象一并查出
     * 返回被依赖图谱(内含组件基本信息), 即我被哪些组件依赖
     */
    public ArtifactGraph queryDependByGraph(Set<String> dstArts, boolean queryDstArtifactDo) throws Exception;
    
}
