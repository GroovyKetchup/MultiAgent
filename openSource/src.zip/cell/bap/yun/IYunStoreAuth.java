package cell.bap.yun;

import com.cdao.mgr.AuthorizeException;
import com.cdao.mgr.CSession;

import bap.cells.Cells;
import bap.md.yun.ArtifactWare;
import cell.CellIntf;

public interface IYunStoreAuth extends CellIntf
{
    public static IYunStoreAuth get() {
        return Cells.get(IYunStoreAuth.class);
    }
    
    public default void canPublishArtifact(CSession session)
    {
        // 默认只要能登录的都可以发布
    }
    
    // 默认组件的提交人或者root才能删组件
    public default void canDeleteArtifact(CSession session, ArtifactWare deleteArt)
    {
        if (session.getUserCode().equals("root"))
            return;
        if(session.getUserCode().equals(deleteArt.getCommiter()))
            return;
        
            throw new AuthorizeException("Only root user or commiter can delete artifact : " + deleteArt.toString());
    }
    
}
