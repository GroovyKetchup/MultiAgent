package cell.bap.servlet;

import cell.ResourceCellIntf;
public interface IHttpServlet extends ResourceCellIntf
{
	public IHttpServletRequest getRequest();
	public IHttpServletResponse getResponse();
	public IRequestDispatcher getRequestDispatcher(String path);
}