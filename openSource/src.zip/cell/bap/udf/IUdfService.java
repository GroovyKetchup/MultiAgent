package cell.bap.udf;

import bap.cells.Cells;
import bap.udf.UdfMeta;
import cell.ServiceCellIntf;

public interface IUdfService extends ServiceCellIntf
{
    public static IUdfService get(){ return Cells.get(IUdfService.class);}

    public static Object execute(String className, Object ... params) throws Exception{
        return get().executeUdf(className, params);
    }
    
    // 正常情况是拿不到UDF类对象的，只有Eclipse开发环境里的测试代码可以使用此方法
    public static Object execute(Class cls, Object ... params) throws Exception{
        return execute(cls.getName(), params);
    }

    public Object executeUdf(String className, Object ... params) throws Exception;
    
    /**
     * 获取UDF的meta信息
     * 
     * 如果是已经提交到主控的，则可以返回主控上（定制过）的UDF
     * 如果是在Eclipse端，尚未提交到主控的，则返回空
     */
    public UdfMeta getUdfMeta(String className) throws Exception;
}