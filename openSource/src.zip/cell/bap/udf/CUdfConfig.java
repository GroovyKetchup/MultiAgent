package cell.bap.udf;

import bap.cells.CellConfig;

public class CUdfConfig extends CellConfig
{
    private static final long serialVersionUID = -1060956685032078958L;
    
    //UDF缓存库大小（LRU）
    public int cacheSize = 200;
    
    //"主线程轮询检查更新的时间间隔（秒)"
    public int loopIntervalS = 5;
    
    //"主线程全量兜底检查脏缓存以及清理删除对象的时间间隔（秒)"
    public int fullCheckIntervalS = 30 * 60;
}
