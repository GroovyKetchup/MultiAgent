package cell.bap.udf;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.locks.ReentrantLock;

import org.nutz.dao.Cnd;
import org.nutz.dao.util.cri.Exps;
import org.nutz.dao.util.cri.SqlExpressionGroup;

import com.cdao.dto.DataRow;
import com.leavay.common.util.LRUCache;
import com.leavay.common.util.StringLock;
import com.leavay.common.util.StringLock.LockObject;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.common.util.javac.LvClassLoader;
import com.leavay.common.util.javac.LvJavac;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.BasicServiceCell;
import bap.cells.BasicUdf;
import bap.cells.Cells;
import bap.cells.annotation.Config;
import bap.java.CJavaConst;
import bap.java.CJavaUtil;
import bap.java.CUdfBean;
import bap.java.CUdfErrorBean;
import bap.java.CodeMeta;
import bap.md.java.CJavaCodeDo;
import bap.md.java.CJavaProject;
import bap.udf.CUdfUtil;
import bap.udf.IUdfInvoker;
import bap.udf.UdfMeta;
import cell.UdfIntf;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import cmn.util.AutoLock;

/**
 * 该CELL负责提供UDF的调用服务，并缓存编译对象
 *
 */

@Config(CUdfConfig.class)
public class CUdfService extends BasicServiceCell implements IUdfService
{
    public final static String LOG = "UDF Service";
    
    private transient Thread _mainThread = null;

    
    protected void doStartService()
    {
        _mainThread = new Thread("UDF Service Main Thread") {
            public void run()
            {
                try
                {
                    mainLoop();
                } catch (InterruptedException inter)
                {
                    ToolUtilities.warning(LOG, "Quit UDF service thread");
                }
            }
        };
        _mainThread.start();
    }

    protected void doStopService()
    {
        clearCache();
        
        while (_mainThread.isAlive())
        {
            ToolUtilities.killThread(_mainThread, 10000);
        }
    }
    
    public CUdfConfig getConf()
    {
        return getConfig(CUdfConfig.class);
    }
    
    protected void mainLoop() throws InterruptedException
    {
        long interval = getConf().loopIntervalS * 1000;
        long fullCheckInterval = getConf().fullCheckIntervalS * 1000;
        long lastFullCheck = System.currentTimeMillis();
        
        long lastCheckSaved = -1000; // 确保第一次会触发同步Create/Update数据
        for (;;)
        {
            try
            {
                // 增量检查最新的修改动作
                // 检查修改较为复杂，这个通知时间戳只用于触发检查，实际的增量检查动作依靠内部记录每次同步的最大修改时间为基准，递进更新
                long savedTag = ToolUtilities.getLong(IDaoService.get().getCenterCache(CJavaConst.DAO_NOTIFY_SAVED_UDF_TIME), -1);
                if (savedTag != lastCheckSaved)
                {
                    checkAndUpdateCache();
                    lastCheckSaved = savedTag;
                }
                
                // 检查删除代码的动作
                checkDeletedCode();
                
                // 全量兜底检查（间隔较长时间）
                if (System.currentTimeMillis() - lastFullCheck > fullCheckInterval)
                {
                    fullyCheckCache();
                    lastFullCheck = System.currentTimeMillis();
                }
            }catch (Throwable err)
            {
                if (ToolBasic.isCausedBy(err, InterruptedException.class))
                    throw ToolBasic.getCauseExcpetion(err, InterruptedException.class);
                
                ToolUtilities.error(LOG, err);
            }            
            ToolUtilities.sleep(interval);
        }
    }
    
    transient StringLock _lcKey = new StringLock(); // 锁单个UDF的获取、编译动作，防止重复加载编译某一个UDF

    transient ReentrantLock _lcCache = new ReentrantLock(); // 锁缓存的操作，将缓存的操作独立于update之外，不受update动作的阻塞
    transient LRUCache<String, CUdfBean> _cache = new LRUCache<String, CUdfBean>(getConf().cacheSize); // key = class full name
    
    transient volatile long _localMaxTag = -1; // 记录同步过的代码最大修改时间戳（来自DB里真实的save time的最大值）
    transient ReentrantLock _lcUpdate = new ReentrantLock(); // 锁_localMaxTag，锁检查、更新缓存的动作（主要是防同时更新缓存）
    protected void checkAndUpdateCache() throws Exception
    {
        try (AutoLock lc = AutoLock.lock(_lcUpdate))
        {
            // 以是否存在缓存决定查询方式
            if (isCacheEmpty())
            {
                // 无缓存，则单查一个最大时间戳即可
                _localMaxTag = queryMaxTime();
                return;
            } else
            {
                // 有缓存，则需查出脏列表，从缓存中移除
                Map<String, Long> mapDirty = queryChangeList(_localMaxTag);
                if (mapDirty != null)
                    for (Entry<String, Long> ent : mapDirty.entrySet())
                    {
                        removeFromCache(ent.getKey());
                        _localMaxTag = Math.max(_localMaxTag, ent.getValue());
                    }
            }
        }
    }
    
    transient volatile long _localDeleteNotifyTag = -1; // 记录同步过的删除代码时间戳
    transient ReentrantLock _lcDelete = new ReentrantLock(); // 锁_loclCheckDeleteTime，锁检查Delete动作通知
    protected void checkDeletedCode() throws Exception
    {
        try (AutoLock lc = AutoLock.lock(_lcDelete))
        {
            long delTag = ToolUtilities.getLong(IDaoService.get().getCenterCache(CJavaConst.DAO_NOTIFY_DELETED_UDF_TIME), -1);
            if (_localDeleteNotifyTag != delTag)
            {
                // delete的代码只能通过全量检查来剔除
                fullyCheckCache();
                _localDeleteNotifyTag = delTag;
            }
        }
    }
    
    // 全量检查所有缓存有哪些脏了的，这个动作是用来除掉已删除的部分，以及兜底脏缓存的
    // 该动作无需加锁，清理脏缓存宁错杀不放过
    protected void fullyCheckCache() throws Exception
    {
        List<CUdfBean> lst = peekCache();
        if (CmnUtil.isObjectEmpty(lst))
            return;
        
        try (IDao dao = IDaoService.newIDao())
        {
            int cnt = 0;
            Map<String, CUdfBean> buffer = new HashMap();
            for (CUdfBean bean : lst)
            {
                if (cnt ++ > 100) //100 分页
                {
                    clearDirtyCache(dao, buffer);
                    buffer.clear();
                    cnt = 0;
                }else
                    buffer.put(bean.getUuid(), bean);
            }
            
            if (!buffer.isEmpty())
                clearDirtyCache(dao, buffer);
        }
    }
    
    // 该动作无需加锁，清理脏缓存宁错杀不放过
    protected void clearDirtyCache(IDao dao, Map<String, CUdfBean> mapCache)
    {
        if (CmnUtil.isObjectEmpty(mapCache))
            return;
        
        List<CJavaCodeDo> lstDb = dao.queryDoList(CJavaCodeDo.class, Cnd.where(new SqlExpressionGroup().andInStrList(CJavaCodeDo.UUID, new LinkedList(mapCache.keySet()))), CJavaCodeDo.JavaPackage, CJavaCodeDo.MainClass, CJavaCodeDo.SaveTime);
        if (lstDb != null)
            for (CJavaCodeDo code : lstDb)
            {
                CUdfBean bean = mapCache.get(code.getUuid());
                if (bean == null)
                    continue;

                // 时间吻合的，干净，从map中移除，留下的就是脏的
                if (bean.getSaveTime() == code.getSaveTime())
                    mapCache.remove(code.getUuid());
            }
        
        // 剩下的要么是DB中不存在，要么是过期了的，都从缓存中删掉
        for (CUdfBean bean : mapCache.values())
            removeFromCache(bean.getFullClassName());
    }
    
    
    protected boolean isCacheEmpty()
    {
        try (AutoLock lc = AutoLock.lock(_lcCache))
        {
            return _cache.isEmpty();
        }
    }
    
    protected void removeFromCache(String key)
    {
        try (AutoLock lc = AutoLock.lock(_lcCache))
        {
            _cache.remove(key);
        }
    }
    
    public List<CUdfBean> peekCache()
    {
        try (AutoLock lc = AutoLock.lock(_lcCache))
        {
            return _cache.peekValues();
        }
    }
    
    public CUdfBean getBean(String clsName)
    {
        try (AutoLock lc = AutoLock.lock(_lcCache))
        {
            return _cache.get(clsName);
        }
    }
    
    public CUdfBean putBean(String clsName, CUdfBean bean)
    {
        try (AutoLock lc = AutoLock.lock(_lcCache))
        {
            _cache.put(clsName, bean);
            return bean;
        }
    }
    
    protected void clearCache()
    {
        try (AutoLock lc = AutoLock.lock(_lcCache))
        {
            _cache.clear();
        }
    }
    
    // 查询UDF工程下，所有java代码中最大的修改时间
    public long queryMaxTime() throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            String sql = "select max(a.$C_SaveTime) as \"max_time\" from $T_JAVACODE a, $T_PROJECT b where a.masterKey=b.uuid and b.$C_DEPEND_TYPE=" + CJavaConst.UDF_LIB;
            HashMap<String, Object> vars = ToolUtilities.newHashMap("T_PROJECT", CJavaProject.TABLE);
            vars.put("T_JAVACODE", CJavaCodeDo.TABLE);
            vars.put("C_SaveTime", CJavaCodeDo.SaveTime);
            vars.put("C_DEPEND_TYPE", CJavaProject.DependType);

            MultiPageResult<DataRow> rows = dao.queryRows(sql, vars, null, 0, 1);
            if (rows != null && rows.hasData())
            {
                DataRow row = rows.getListData().get(0);
                return ToolUtilities.getLong(row.get("max_time"), -1);
            }

            return -1;
        }
    }
    
    // 查出>from时间的所有变更类，不含等于的
    public Map<String, Long> queryChangeList(long from) throws Exception
    {
        try (IDao dao = IDaoService.newIDao())
        {
            String sql = "select a.$C_Pkg as pkg, a.$C_Name as name, a.$C_SaveTime as max_time from $T_JAVACODE a, $T_PROJECT b where a.masterKey=b.uuid and b.$C_DEPEND_TYPE=" + CJavaConst.UDF_LIB+" and a.$C_SaveTime >"+from;
            HashMap<String, Object> vars = ToolUtilities.newHashMap("T_PROJECT", CJavaProject.TABLE);
            vars.put("T_JAVACODE", CJavaCodeDo.TABLE);
            vars.put("C_Pkg", CJavaCodeDo.JavaPackage);
            vars.put("C_Name", CJavaCodeDo.MainClass);
            vars.put("C_DEPEND_TYPE", CJavaProject.DependType);
             vars.put("C_SaveTime", CJavaCodeDo.SaveTime);

            MultiPageResult<DataRow> rows = dao.queryRows(sql, vars, null, 0, Integer.MAX_VALUE);
            if (rows != null && rows.hasData())
            {
                Map<String, Long> mapRet = new HashMap<String, Long>();
                for (DataRow row : rows.getListData())
                {
                    String pkg = ToolUtilities.getString(row.get("pkg"), null);
                    String cls = ToolUtilities.getString(row.get("name"), null);
                    long time = ToolUtilities.getLong(row.get("max_time"), -1);
                    mapRet.put(CmnUtil.getFullClassName(pkg, cls), time);
                }

                return mapRet;
            }

            return null;
        }
    }

    public CUdfBean getUdf(String className) throws TimeoutException, Exception
    {
        try (LockObject lc = _lcKey.lockDN(className))
        {
            CUdfBean bean = getBean(className);
            if (bean != null)
                return bean;
            
            try (IDao dao = IDaoService.newIDao())
            {
                String pkg = LvJavac.getPackageFromFullClass(className);
                String simpleCls = LvJavac.getSimpleName(className);
                Cnd cnd = Cnd.where(CJavaCodeDo.MainClass, "=", simpleCls);
                if (CmnUtil.isStringEmpty(pkg))
                {
                    cnd.and(Exps.isStringBlank(CJavaCodeDo.JavaPackage));
                }else
                    cnd.and(CJavaCodeDo.JavaPackage, "=", pkg);
                
                // 从数据库查询
                CJavaCodeDo code = (CJavaCodeDo) dao.queryDo(CJavaCodeDo.class.getName(), cnd);
                if (code == null)
                    return putBean(className, CUdfBean.UNEXIST_UDF);
                    
                // 编译对象
                try (LvClassLoader tmpLoader = ClassFactory.newValidClassLoader())
                {
                    // 编译UDF,并加载到类加载器中
                    UdfMeta cmpMeta = CUdfUtil.compileAndLoadCode(tmpLoader, code);

                    // 构建实例对象
                    Class cls = CmnUtil.assertNotNull(tmpLoader.loadClass(className), "Failed to compile and load class");
                    BasicUdf ins = (BasicUdf) ToolUtilities.newObject(cls);
                    
                    bean = new CUdfBean();
                    ToolUtilities.copyFields(code, bean, false);
                    bean.setCompileMeta(cmpMeta);
                    bean.setUdfInstance(ins);
                    return putBean(className, bean);
                }catch (Throwable err)
                {
                    // 出现加载异常，也缓存起来，避免重复尝试加载
                    return putBean(className, new CUdfErrorBean(err));
                }
            }
        }
    }
    
    public Object executeUdf(String className, Object ... params) throws Exception
    {
        CmnUtil.assertTrue(UdfIntf.isUdfPackage(CmnUtil.getPackageFromFullClass(className)), "Package of UDF should start with : " + UdfIntf.PACKAGE_PREFIX);
        
        // 首先从细胞工厂获取（这里只有可能获取到远程开发端注册上来的）
        // 如果有，则直接调用
        Object remoteCell = Cells.tryGet(className);
        if (remoteCell != null)
        {
            CmnUtil.assertTrue(remoteCell instanceof IUdfInvoker, "UDF remote cell should be child of IUdfInvoker");
            
            IUdfInvoker rmtInvoker = (IUdfInvoker)remoteCell;
            return rmtInvoker.invoke(params);
        }
        
        // 正常（无联调）的UDF，从本地缓存获取（通过数据库查询、编译的方式得到）
        CUdfBean bean = getUdf(className);
        CmnUtil.assertNotNull(bean, "Failed to get or compile UDF : " + className);
        if (bean instanceof CUdfErrorBean)
            ToolUtilities.throwException(((CUdfErrorBean)bean).getError());
        
        if (bean.isUnexistBean())
            throw new Exception("This UDF is undefined : " + className);
        
        return ToolUtilities.callFunction(bean.getUdfInstance(), UdfIntf.MAIN_METHOD, params);
    }
    
    public UdfMeta getUdfMeta(String className) throws Exception
    {
        CmnUtil.assertTrue(UdfIntf.isUdfPackage(CmnUtil.getPackageFromFullClass(className)), "Package of UDF should start with : " + UdfIntf.PACKAGE_PREFIX);

        // 首先从细胞工厂获取（这里只有可能获取到远程开发端注册上来的）
        // 如果有，则直接调用
        Object remoteCell = Cells.tryGet(className);
        if (remoteCell != null)
        {
            CmnUtil.assertTrue(remoteCell instanceof IUdfInvoker, "UDF remote cell should be child of IUdfInvoker");
            
            IUdfInvoker rmtInvoker = (IUdfInvoker)remoteCell;
            return rmtInvoker.getMeta();
        }else
        {
            // 正常（无联调）的UDF，从本地缓存获取（通过数据库查询、编译的方式得到）
            CUdfBean bean = getUdf(className);
            CmnUtil.assertNotNull(bean, "Failed to get or compile UDF : " + className);
            if (bean instanceof CUdfErrorBean)
                ToolUtilities.throwException(((CUdfErrorBean)bean).getError());
            
            if (bean.isUnexistBean())
                throw new Exception("This UDF is undefined : " + className);
            
            UdfMeta cmpMeta = bean.getCompileMeta();
            try (IDao dao = IDaoService.newIDao())
            {
                CodeMeta doMeta = CJavaUtil.queryCodeMeta(dao, className);
                if (doMeta != null)
                    cmpMeta = CUdfUtil.mergeMeta(cmpMeta, doMeta);
            }
            
            return cmpMeta;
        }
    }
}
