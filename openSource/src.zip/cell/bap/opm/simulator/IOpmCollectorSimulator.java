package cell.bap.opm.simulator;

import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmRuleResult;
import cell.PluginCellIntf;

/**
 * OPM采集器仿真器Cell接口。
 * 实现此接口并通过插件发布后，可通过OpmCenter.setSimulator(collectorKey, cellClassName)挂载仿真器。
 * 
 * Cell接口规范：
 * 1. 接口必须放在 cell 包下（如 cell.xxx.IXxx）
 * 2. 接口必须继承 PluginCellIntf
 * 3. 实现类必须继承 BasicCell 或其子类
 * 4. 实现类命名规范：C + 接口名去掉I（如 COpmCollectorSimulator）
 * 5. 接口方法所有入参/返回类型必须可序列化（实现Serializable）
 * 6. 发布插件后，通过 Cells.get(IOpmCollectorSimulator.class) 获取实例
 * 
 * ⚠️ 重要说明：
 * 1. 仿真器必须制作为Cell并提交到BAP某个内部工程中
 * 2. 只有这样才能发布为插件，从而才能通过Cells.get被反射调用
 * 3. 不能用临时Java代码或脚本执行的方式挂载
 * 4. 临时Java代码执行完，其scope就消失了，无法被Cells.get找到
 * 
 * 使用方式：
 * 1. 创建Java工程（dependType=DEPEND_PLUGIN），实现此接口
 * 2. 发布为插件
 * 3. 调用 OpmCenter.setSimulator("sys", "cell.opm.simulator.COpmSysSimulator") 挂载
 * 4. 调用 OpmCenter.setSimulator(null, null) 解挂
 * 
 * 示例实现：
 * <pre>
 * package opm.simulator;
 * 
 * import bap.opm.OpmAgentContext;
 * import bap.opm.OpmCollectResult;
 * import bap.md.opm.sys.OpmSysMetricDo;
 * import cell.bap.opm.simulator.IOpmCollectorSimulator;
 * import java.util.Random;
 * 
 * public class CpuHighLoadSimulator implements IOpmCollectorSimulator {
 *     
 *     public String getSimulatorName() {
 *         return "CPU高负载仿真器";
 *     }
 *     
 *     public String getTargetCollectorKey() {
 *         return "sys";
 *     }
 *     
 *     public OpmCollectResult simulateCollect(OpmAgentContext agentCtx, long now) {
 *         Random rand = new Random(now);
 *         double cpuBase = 0.70 + rand.nextDouble() * 0.25;
 *         double memBase = 0.65 + rand.nextDouble() * 0.30;
 *         
 *         OpmCollectResult result = new OpmCollectResult();
 *         result.collectorKey = "sys";
 *         result.collectorLabel = "系统监控(仿真)";
 *         result.collectTime = now;
 *         
 *         OpmSysMetricDo ext = new OpmSysMetricDo();
 *         ext.cpuUsageRate = cpuBase;
 *         ext.memUsageRate = memBase;
 *         result.metricExt = ext;
 *         
 *         if (cpuBase >= 0.95) {
 *             result.status = 2;
 *             result.summary = String.format("cpu=%.2f%% (CRITICAL)", cpuBase*100);
 *         } else if (cpuBase >= 0.90) {
 *             result.status = 2;
 *             result.summary = String.format("cpu=%.2f%% (MAJOR)", cpuBase*100);
 *         } else if (cpuBase >= 0.80) {
 *             result.status = 1;
 *             result.summary = String.format("cpu=%.2f%% (MINOR)", cpuBase*100);
 *         } else {
 *             result.status = 0;
 *             result.summary = String.format("cpu=%.2f%% (NORMAL)", cpuBase*100);
 *         }
 *         
 *         return result;
 *     }
 * }
 * </pre>
 */
public interface IOpmCollectorSimulator extends PluginCellIntf
{
    /**
     * 获取仿真器名称
     */
    String getSimulatorName();
    
    /**
     * 获取目标采集器Key（如 "sys", "topCpu", "mem"）
     */
    String getTargetCollectorKey();
    
    /**
     * 仿真采集数据
     * @param agentCtx 代理上下文
     * @param now 当前时间戳
     * @return 仿真采集结果，返回null则跳过本次采集
     */
    OpmCollectResult simulateCollect(OpmAgentContext agentCtx, long now) throws Exception;
    
    /**
     * 仿真规则评估（可选）
     * @param collectResult 采集结果
     * @param agentCtx 代理上下文
     * @return 规则结果列表，返回null则使用真实采集器的规则评估
     */
    default java.util.List<OpmRuleResult> simulateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception {
        return null;
    }
}