package cell.bap.opm.collector.topnet;

import bap.cells.Cells;
import cell.bap.opm.collector.IOpmCollector;

public interface IOpmTopNetCollector extends IOpmCollector
{
    public static IOpmTopNetCollector get()
    {
        return Cells.get(IOpmTopNetCollector.class);
    }
}
