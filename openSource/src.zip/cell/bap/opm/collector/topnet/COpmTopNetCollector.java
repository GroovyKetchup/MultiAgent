package cell.bap.opm.collector.topnet;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.cells.BasicCell;
import bap.md.opm.net.OpmNetMetricDo;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmConst;
import bap.opm.OpmParamDef;
import bap.opm.cfg.OpmConfigGroup;
import bap.opm.cfg.OpmConfigXmlBuilder;
import bap.opm.OpmRuleResult;
import bap.opm.collector.topnet.OpmTopNetConst;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.system.SystemMetrics;
import bap.opm.system.SystemMetricsCollectSpec;
import bap.opm.system.SystemMetricsUtil;

/**
 * 网络采集器（吞吐、读写速率、总字节）。
 */
public class COpmTopNetCollector extends BasicCell implements IOpmTopNetCollector
{
    protected volatile boolean _enable = OpmTopNetConst.DEFAULT_ENABLE;
    protected volatile long _collectIntervalMs = OpmTopNetConst.getCollectIntervalMs();
    protected volatile int _sampleMillis = OpmTopNetConst.DEFAULT_SAMPLE_MILLIS;
    protected volatile int _topProcSize = OpmTopNetConst.DEFAULT_TOP_PROC_SIZE;
    protected volatile double _warnRateBytesPerSec = OpmTopNetConst.DEFAULT_WARN_RATE;
    protected volatile int _warnDurationSec = OpmTopNetConst.DEFAULT_WARN_DURATION_SEC;
    protected volatile double _minorRateBytesPerSec = OpmTopNetConst.DEFAULT_MINOR_RATE;
    protected volatile int _minorDurationSec = OpmTopNetConst.DEFAULT_MINOR_DURATION_SEC;
    protected volatile double _majorRateBytesPerSec = OpmTopNetConst.DEFAULT_MAJOR_RATE;
    protected volatile int _majorDurationSec = OpmTopNetConst.DEFAULT_MAJOR_DURATION_SEC;
    protected volatile double _criticalRateBytesPerSec = OpmTopNetConst.DEFAULT_CRITICAL_RATE;
    protected volatile int _criticalDurationSec = OpmTopNetConst.DEFAULT_CRITICAL_DURATION_SEC;

    @Override
    public String getCollectorKey()
    {
        return OpmTopNetConst.COLLECTOR_KEY;
    }

    @Override
    public String getCollectorLabel()
    {
        return OpmTopNetConst.COLLECTOR_LABEL;
    }

    @Override
    public List<OpmParamDef> getParamDefs()
    {
        ArrayList<OpmParamDef> list = new ArrayList<OpmParamDef>();
        list.add(new OpmParamDef(OpmTopNetConst.CONF_ENABLE, OpmTopNetConst.LABEL_ENABLE, "boolean", String.valueOf(OpmTopNetConst.DEFAULT_ENABLE)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_COLLECT_INTERVAL_SEC, OpmTopNetConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmTopNetConst.DEFAULT_COLLECT_INTERVAL_SEC)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_SAMPLE_MILLIS, OpmTopNetConst.LABEL_SAMPLE_MILLIS, "int", String.valueOf(OpmTopNetConst.DEFAULT_SAMPLE_MILLIS)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_TOP_PROC_SIZE, OpmTopNetConst.LABEL_TOP_PROC_SIZE, "int", String.valueOf(OpmTopNetConst.DEFAULT_TOP_PROC_SIZE)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_WARN_RATE, OpmTopNetConst.LABEL_WARN_RATE, "string", String.valueOf(OpmTopNetConst.DEFAULT_WARN_RATE)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_WARN_DURATION_SEC, OpmTopNetConst.LABEL_WARN_DURATION_SEC, "int", String.valueOf(OpmTopNetConst.DEFAULT_WARN_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_MINOR_RATE, OpmTopNetConst.LABEL_MINOR_RATE, "string", String.valueOf(OpmTopNetConst.DEFAULT_MINOR_RATE)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_MINOR_DURATION_SEC, OpmTopNetConst.LABEL_MINOR_DURATION_SEC, "int", String.valueOf(OpmTopNetConst.DEFAULT_MINOR_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_MAJOR_RATE, OpmTopNetConst.LABEL_MAJOR_RATE, "string", String.valueOf(OpmTopNetConst.DEFAULT_MAJOR_RATE)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_MAJOR_DURATION_SEC, OpmTopNetConst.LABEL_MAJOR_DURATION_SEC, "int", String.valueOf(OpmTopNetConst.DEFAULT_MAJOR_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_CRITICAL_RATE, OpmTopNetConst.LABEL_CRITICAL_RATE, "string", String.valueOf(OpmTopNetConst.DEFAULT_CRITICAL_RATE)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_CRITICAL_DURATION_SEC, OpmTopNetConst.LABEL_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmTopNetConst.DEFAULT_CRITICAL_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopNetConst.CONF_RULE_COOLDOWN_SEC, OpmTopNetConst.LABEL_RULE_COOLDOWN_SEC, "int", String.valueOf(OpmTopNetConst.DEFAULT_RULE_COOLDOWN_SEC)));
        return list;
    }

    @Override
    public String getSampleConfigComment()
    {
        return OpmConfigXmlBuilder.buildModuleSample("topNet", "TOP进程网络监控", "cell.bap.opm.collector.topnet.IOpmTopNetCollector", getConfigGroup());
    }

    @Override
    public long getCollectIntervalMs()
    {
        return _collectIntervalMs;
    }

    @Override
    public List<Class> getModelClasses()
    {
        List<Class> list = new ArrayList<Class>();
        list.add(OpmNetMetricDo.class);
        list.add(OpmSysAlarmExtDo.class);
        return list;
    }

    @Override
    public void loadConfig()
    {
        _enable = OpmTopNetConst.isEnable();
        _collectIntervalMs = OpmTopNetConst.getCollectIntervalMs();
        _sampleMillis = OpmTopNetConst.getSampleMillis();
        _topProcSize = OpmTopNetConst.getTopProcSize();
        _warnRateBytesPerSec = OpmTopNetConst.getWarnRate();
        _warnDurationSec = OpmTopNetConst.getWarnDurationSec();
        _minorRateBytesPerSec = OpmTopNetConst.getMinorRate();
        _minorDurationSec = OpmTopNetConst.getMinorDurationSec();
        _majorRateBytesPerSec = OpmTopNetConst.getMajorRate();
        _majorDurationSec = OpmTopNetConst.getMajorDurationSec();
        _criticalRateBytesPerSec = OpmTopNetConst.getCriticalRate();
        _criticalDurationSec = OpmTopNetConst.getCriticalDurationSec();

        if (_collectIntervalMs <= 0L)
            _collectIntervalMs = OpmTopNetConst.DEFAULT_COLLECT_INTERVAL_SEC * 1000L;
        if (_sampleMillis <= 0)
            _sampleMillis = OpmTopNetConst.DEFAULT_SAMPLE_MILLIS;
        if (_topProcSize <= 0)
            _topProcSize = OpmTopNetConst.DEFAULT_TOP_PROC_SIZE;
    }

    @Override
    public OpmCollectResult collect(OpmAgentContext agentCtx) throws Exception
    {
        long begin = System.nanoTime();
        if (!_enable)
            return null;

        long now = System.currentTimeMillis();
        SystemMetrics metrics = SystemMetricsUtil.collect(_sampleMillis, SystemMetricsCollectSpec.forNetCollector());
        SystemMetrics.NetworkUsage net = metrics == null ? null : metrics.network;

        OpmNetMetricDo ext = new OpmNetMetricDo();
        ext.collectorKey = getCollectorKey();
        ext.collectorLabel = getCollectorLabel();
        ext.agentCode = agentCtx == null ? null : agentCtx.getAgentCode();
        ext.agentName = agentCtx == null ? null : agentCtx.getAgentName();
        ext.myUri = agentCtx == null ? null : agentCtx.getMyUri();
        ext.collectTime = now;
        ext.hostName = metrics == null ? null : metrics.hostName;
        ext.osName = metrics == null ? null : metrics.osName;
        ext.provider = metrics == null ? null : metrics.provider;
        ext.sampleMillis = Long.valueOf(_sampleMillis);

        if (net != null)
        {
            ext.totalRxBytes = net.totalRxBytes;
            ext.totalTxBytes = net.totalTxBytes;
            ext.rxRate = net.totalRxRateBytesPerSec;
            ext.txRate = net.totalTxRateBytesPerSec;
            ext.totalRate = net.totalThroughputBytesPerSec;
        }

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        Map<String, Object> netMap = new LinkedHashMap<String, Object>();
        netMap.put("available", net == null ? false : net.available);
        netMap.put("source", net == null ? null : net.source);
        netMap.put("sampleMillis", net == null ? null : net.sampleMillis);
        netMap.put("totalRxBytes", net == null ? null : net.totalRxBytes);
        netMap.put("totalTxBytes", net == null ? null : net.totalTxBytes);
        netMap.put("totalRxRateBytesPerSec", net == null ? null : net.totalRxRateBytesPerSec);
        netMap.put("totalTxRateBytesPerSec", net == null ? null : net.totalTxRateBytesPerSec);
        netMap.put("totalThroughputBytesPerSec", net == null ? null : net.totalThroughputBytesPerSec);

        List<Map<String, Object>> interfaces = new ArrayList<Map<String, Object>>();
        if (net != null && net.interfaces != null)
            for (SystemMetrics.NetworkInterfaceUsage itf : net.interfaces)
            {
                if (itf == null)
                    continue;
                Map<String, Object> one = new LinkedHashMap<String, Object>();
                one.put("name", itf.name);
                one.put("displayName", itf.displayName);
                one.put("rxBytes", itf.rxBytes);
                one.put("txBytes", itf.txBytes);
                one.put("rxRateBytesPerSec", itf.rxRateBytesPerSec);
                one.put("txRateBytesPerSec", itf.txRateBytesPerSec);
                one.put("throughputBytesPerSec", itf.throughputBytesPerSec);
                interfaces.add(one);
            }
        netMap.put("interfaces", interfaces);
        detail.put("network", netMap);

        List<SystemMetrics.ProcessNetworkUsage> topRaw = cutTopProc(net == null ? null : net.processes, _topProcSize);
        List<Map<String, Object>> top = new ArrayList<Map<String, Object>>();
        for (SystemMetrics.ProcessNetworkUsage p : topRaw)
        {
            if (p == null)
                continue;
            Map<String, Object> one = new LinkedHashMap<String, Object>();
            one.put("pid", p.pid);
            one.put("processName", p.processName);
            one.put("rxRateBytesPerSec", p.rxRateBytesPerSec);
            one.put("txRateBytesPerSec", p.txRateBytesPerSec);
            one.put("throughputBytesPerSec", p.throughputBytesPerSec);
            one.put("source", p.source);
            top.add(one);
        }
        detail.put("topProcesses", top);
        ext.detailJson = CJson.toJson(detail);

        OpmCollectResult ret = new OpmCollectResult();
        ret.collectorKey = getCollectorKey();
        ret.collectorLabel = getCollectorLabel();
        ret.collectTime = now;
        ret.collectCostMs = (System.nanoTime() - begin) / 1000000L;
        ret.metricExt = ext;
        ret.summary = "Rx=" + SystemMetricsUtil.formatRate(ToolUtilities.getDouble(ext.rxRate, -1D))
                + ", Tx=" + SystemMetricsUtil.formatRate(ToolUtilities.getDouble(ext.txRate, -1D))
                + ", Total=" + SystemMetricsUtil.formatRate(ToolUtilities.getDouble(ext.totalRate, -1D));
        if (net == null || !net.available)
            ret.status = OpmConst.STATUS_ERROR;
        return ret;
    }

    @Override
    public List<OpmRuleResult> evaluateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception
    {
        ArrayList<OpmRuleResult> list = new ArrayList<OpmRuleResult>();
        if (collectResult == null || !(collectResult.metricExt instanceof OpmNetMetricDo))
            return list;

        OpmNetMetricDo ext = (OpmNetMetricDo) collectResult.metricExt;
        long now = System.currentTimeMillis();
        OpmRuleResult netRule = evalTopNetRule(ext, agentCtx, now);
        if (netRule != null)
            list.add(netRule);
        return list;
    }

    protected OpmRuleResult evalTopNetRule(OpmNetMetricDo ext, OpmAgentContext agentCtx, long now)
    {
        double totalRate = ToolUtilities.getDouble(ext.totalRate, -1D);
        if (totalRate < 0D)
            return null;

        AlarmLevelConfig[] levels = new AlarmLevelConfig[] {
                new AlarmLevelConfig(tiny.service.md.TsAlarm.LEVEL_ERROR_CRITICAL, "严重", _criticalRateBytesPerSec, _criticalDurationSec),
                new AlarmLevelConfig(tiny.service.md.TsAlarm.LEVEL_ERROR_MAJOR, "主要", _majorRateBytesPerSec, _majorDurationSec),
                new AlarmLevelConfig(tiny.service.md.TsAlarm.LEVEL_ERROR_MINOR, "次要", _minorRateBytesPerSec, _minorDurationSec),
                new AlarmLevelConfig(tiny.service.md.TsAlarm.LEVEL_WARN, "警告", _warnRateBytesPerSec, _warnDurationSec)
        };

        for (AlarmLevelConfig level : levels)
        {
            if (totalRate < level.threshold)
                continue;

            List<OpmNetMetricDo> history = queryHistoryMetrics(agentCtx == null ? null : agentCtx.getAgentCode(), now - level.durationSec * 1000L);
            if (!allNetOver(history, level.threshold))
                continue;

            OpmRuleResult rs = new OpmRuleResult();
            rs.triggered = true;
            rs.alarmLevel = level.level;
            rs.ruleKey = OpmAlarmConfigKeys.RULE_TOP_NET;
            rs.configParamKey = resolveConfigParamKey(level.level);
            rs.ruleLabel = "TOP进程网络门限";
            rs.message = "TOP进程网络持续过高: 当前=" + SystemMetricsUtil.formatRate(totalRate)
                    + ", 级别=" + level.levelName
                    + ", 阈值=" + SystemMetricsUtil.formatRate(level.threshold)
                    + ", 持续" + level.durationSec + "秒";
            rs.detailJson = ext.detailJson;

            OpmSysAlarmExtDo alarmExt = new OpmSysAlarmExtDo();
            alarmExt.metricName = "topProcNetRate";
            alarmExt.currentRate = Double.valueOf(totalRate);
            alarmExt.triggerLevel = level.levelName;
            alarmExt.thresholdRate = Double.valueOf(level.threshold);
            alarmExt.durationSec = Integer.valueOf(level.durationSec);
            alarmExt.warnRate = Double.valueOf(_warnRateBytesPerSec);
            alarmExt.criticalRate = Double.valueOf(_criticalRateBytesPerSec);
            rs.alarmExt = alarmExt;
            return rs;
        }

        return null;
    }

    protected String resolveConfigParamKey(int alarmLevel)
    {
        if (alarmLevel == tiny.service.md.TsAlarm.LEVEL_ERROR_CRITICAL)
            return OpmTopNetConst.CONF_CRITICAL_RATE;
        if (alarmLevel == tiny.service.md.TsAlarm.LEVEL_ERROR_MAJOR)
            return OpmTopNetConst.CONF_MAJOR_RATE;
        if (alarmLevel == tiny.service.md.TsAlarm.LEVEL_ERROR_MINOR)
            return OpmTopNetConst.CONF_MINOR_RATE;
        return OpmTopNetConst.CONF_WARN_RATE;
    }

    protected boolean allNetOver(List<OpmNetMetricDo> history, double threshold)
    {
        if (history == null || history.isEmpty())
            return false;
        for (OpmNetMetricDo one : history)
        {
            if (one == null || one.totalRate == null || one.totalRate.doubleValue() < threshold)
                return false;
        }
        return true;
    }

    protected List<OpmNetMetricDo> queryHistoryMetrics(String agentCode, long sinceTime)
    {
        List<OpmNetMetricDo> list = new ArrayList<OpmNetMetricDo>();
        if (ToolUtilities.isStringEmpty(agentCode, true))
            return list;
        try (cell.cdao.IDao dao = cell.cdao.IDaoService.newIDao())
        {
            org.nutz.dao.Cnd cnd = org.nutz.dao.Cnd.where(OpmNetMetricDo.AgentCode, "=", agentCode)
                    .and(OpmNetMetricDo.CollectTime, ">=", Long.valueOf(sinceTime))
                    .asc(OpmNetMetricDo.CollectTime);
            list = dao.queryDoList(OpmNetMetricDo.class, cnd);
        }
        catch (Throwable ignore)
        {
        }
        return list;
    }

    protected List<SystemMetrics.ProcessNetworkUsage> cutTopProc(List<SystemMetrics.ProcessNetworkUsage> src, int max)
    {
        ArrayList<SystemMetrics.ProcessNetworkUsage> ret = new ArrayList<SystemMetrics.ProcessNetworkUsage>();
        if (src == null)
            return ret;

        for (SystemMetrics.ProcessNetworkUsage one : src)
        {
            if (one == null)
                continue;
            ret.add(one);
            if (ret.size() >= max)
                break;
        }
        return ret;
    }

    @Override
    public OpmConfigGroup getConfigGroup()
    {
        OpmConfigGroup root = new OpmConfigGroup(getCollectorKey(), getCollectorLabel())
                .setDesc("采集主机网络吞吐和网络活跃进程，用于定位异常流量或网络 IO 压力。主要参数控制采样窗口和保留的 Top 进程数量。 ");
        List<OpmParamDef> defs = getParamDefs();
        if (defs != null)
        {
            for (OpmParamDef p : defs)
            {
                if (p != null)
                    root.addParam(p);
            }
        }
        return root;
    }

    protected static class AlarmLevelConfig
    {
        int level;
        String levelName;
        double threshold;
        int durationSec;

        AlarmLevelConfig(int level, String levelName, double threshold, int durationSec)
        {
            this.level = level;
            this.levelName = levelName;
            this.threshold = threshold;
            this.durationSec = durationSec;
        }
    }
}
