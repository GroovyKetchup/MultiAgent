package cell.bap.opm.collector.topio;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.cells.BasicCell;
import bap.md.opm.io.OpmIoMetricDo;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmConst;
import bap.opm.OpmParamDef;
import bap.opm.OpmRuleResult;
import bap.opm.cfg.OpmConfigGroup;
import bap.opm.cfg.OpmConfigXmlBuilder;
import bap.opm.collector.topio.OpmTopIoConst;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.system.SystemMetrics;
import bap.opm.system.SystemMetricsCollectSpec;
import bap.opm.system.SystemMetricsUtil;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import org.nutz.dao.Cnd;
import tiny.service.md.TsAlarm;

/**
 * IO采集器（进程级）。
 */
public class COpmTopIoCollector extends BasicCell implements IOpmTopIoCollector
{
    protected volatile boolean _enable = OpmTopIoConst.DEFAULT_ENABLE;
    protected volatile long _collectIntervalMs = OpmTopIoConst.getCollectIntervalMs();
    protected volatile int _sampleMillis = OpmTopIoConst.DEFAULT_SAMPLE_MILLIS;
    protected volatile int _topProcSize = OpmTopIoConst.DEFAULT_TOP_PROC_SIZE;
    protected volatile double _warnRateBytesPerSec = OpmTopIoConst.DEFAULT_WARN_RATE;
    protected volatile int _warnDurationSec = OpmTopIoConst.DEFAULT_WARN_DURATION_SEC;
    protected volatile double _minorRateBytesPerSec = OpmTopIoConst.DEFAULT_MINOR_RATE;
    protected volatile int _minorDurationSec = OpmTopIoConst.DEFAULT_MINOR_DURATION_SEC;
    protected volatile double _majorRateBytesPerSec = OpmTopIoConst.DEFAULT_MAJOR_RATE;
    protected volatile int _majorDurationSec = OpmTopIoConst.DEFAULT_MAJOR_DURATION_SEC;
    protected volatile double _criticalRateBytesPerSec = OpmTopIoConst.DEFAULT_CRITICAL_RATE;
    protected volatile int _criticalDurationSec = OpmTopIoConst.DEFAULT_CRITICAL_DURATION_SEC;
    @Override
    public String getCollectorKey()
    {
        return OpmTopIoConst.COLLECTOR_KEY;
    }

    @Override
    public String getCollectorLabel()
    {
        return OpmTopIoConst.COLLECTOR_LABEL;
    }

    @Override
    public List<OpmParamDef> getParamDefs()
    {
        ArrayList<OpmParamDef> list = new ArrayList<OpmParamDef>();
        list.add(new OpmParamDef(OpmTopIoConst.CONF_ENABLE, OpmTopIoConst.LABEL_ENABLE, "boolean", String.valueOf(OpmTopIoConst.DEFAULT_ENABLE)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_COLLECT_INTERVAL_SEC, OpmTopIoConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmTopIoConst.DEFAULT_COLLECT_INTERVAL_SEC)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_SAMPLE_MILLIS, OpmTopIoConst.LABEL_SAMPLE_MILLIS, "int", String.valueOf(OpmTopIoConst.DEFAULT_SAMPLE_MILLIS)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_TOP_PROC_SIZE, OpmTopIoConst.LABEL_TOP_PROC_SIZE, "int", String.valueOf(OpmTopIoConst.DEFAULT_TOP_PROC_SIZE)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_WARN_RATE, OpmTopIoConst.LABEL_WARN_RATE, "string", String.valueOf(OpmTopIoConst.DEFAULT_WARN_RATE)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_WARN_DURATION_SEC, OpmTopIoConst.LABEL_WARN_DURATION_SEC, "int", String.valueOf(OpmTopIoConst.DEFAULT_WARN_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_MINOR_RATE, OpmTopIoConst.LABEL_MINOR_RATE, "string", String.valueOf(OpmTopIoConst.DEFAULT_MINOR_RATE)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_MINOR_DURATION_SEC, OpmTopIoConst.LABEL_MINOR_DURATION_SEC, "int", String.valueOf(OpmTopIoConst.DEFAULT_MINOR_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_MAJOR_RATE, OpmTopIoConst.LABEL_MAJOR_RATE, "string", String.valueOf(OpmTopIoConst.DEFAULT_MAJOR_RATE)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_MAJOR_DURATION_SEC, OpmTopIoConst.LABEL_MAJOR_DURATION_SEC, "int", String.valueOf(OpmTopIoConst.DEFAULT_MAJOR_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_CRITICAL_RATE, OpmTopIoConst.LABEL_CRITICAL_RATE, "string", String.valueOf(OpmTopIoConst.DEFAULT_CRITICAL_RATE)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_CRITICAL_DURATION_SEC, OpmTopIoConst.LABEL_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmTopIoConst.DEFAULT_CRITICAL_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopIoConst.CONF_RULE_COOLDOWN_SEC, OpmTopIoConst.LABEL_RULE_COOLDOWN_SEC, "int", String.valueOf(OpmTopIoConst.DEFAULT_RULE_COOLDOWN_SEC)));
        return list;
    }

    @Override
    public String getSampleConfigComment()
    {
        return OpmConfigXmlBuilder.buildModuleSample("topIo", "TOP进程IO监控", "cell.bap.opm.collector.topio.IOpmTopIoCollector", getConfigGroup());
    }

    @Override
    public long getCollectIntervalMs()
    {
        return _collectIntervalMs;
    }

    @Override
    public List<Class> getModelClasses()
    {
        List<Class> list = new ArrayList<Class>();
        list.add(OpmIoMetricDo.class);
        list.add(OpmSysAlarmExtDo.class);
        return list;
    }

    @Override
    public void loadConfig()
    {
        _enable = OpmTopIoConst.isEnable();
        _collectIntervalMs = OpmTopIoConst.getCollectIntervalMs();
        _sampleMillis = OpmTopIoConst.getSampleMillis();
        _topProcSize = OpmTopIoConst.getTopProcSize();
        _warnRateBytesPerSec = OpmTopIoConst.getWarnRate();
        _warnDurationSec = OpmTopIoConst.getWarnDurationSec();
        _minorRateBytesPerSec = OpmTopIoConst.getMinorRate();
        _minorDurationSec = OpmTopIoConst.getMinorDurationSec();
        _majorRateBytesPerSec = OpmTopIoConst.getMajorRate();
        _majorDurationSec = OpmTopIoConst.getMajorDurationSec();
        _criticalRateBytesPerSec = OpmTopIoConst.getCriticalRate();
        _criticalDurationSec = OpmTopIoConst.getCriticalDurationSec();
        if (_collectIntervalMs <= 0L)
            _collectIntervalMs = OpmTopIoConst.DEFAULT_COLLECT_INTERVAL_SEC * 1000L;
        if (_sampleMillis <= 0)
            _sampleMillis = OpmTopIoConst.DEFAULT_SAMPLE_MILLIS;
        if (_topProcSize <= 0)
            _topProcSize = OpmTopIoConst.DEFAULT_TOP_PROC_SIZE;
    }

    @Override
    public OpmCollectResult collect(OpmAgentContext agentCtx) throws Exception
    {
        long begin = System.nanoTime();
        if (!_enable)
            return null;

        long now = System.currentTimeMillis();
        SystemMetrics metrics = SystemMetricsUtil.collect(_sampleMillis, SystemMetricsCollectSpec.forIoCollector());

        OpmIoMetricDo ext = new OpmIoMetricDo();
        ext.collectorKey = getCollectorKey();
        ext.collectorLabel = getCollectorLabel();
        ext.agentCode = agentCtx == null ? null : agentCtx.getAgentCode();
        ext.agentName = agentCtx == null ? null : agentCtx.getAgentName();
        ext.myUri = agentCtx == null ? null : agentCtx.getMyUri();
        ext.collectTime = now;
        ext.hostName = metrics == null ? null : metrics.hostName;
        ext.osName = metrics == null ? null : metrics.osName;
        ext.provider = metrics == null ? null : metrics.provider;

        SystemMetrics.IoUsage io = metrics == null ? null : metrics.io;
        ext.sampleMillis = Long.valueOf(_sampleMillis);
        List<SystemMetrics.ProcessIoUsage> top = cutTopIo(io == null ? null : io.processes, _topProcSize);
        ext.topProcCount = top.size();
        if (!top.isEmpty())
        {
            ext.topProcName = top.get(0).processName;
            ext.topProcReadRate = top.get(0).readRateBytesPerSec;
            ext.topProcWriteRate = top.get(0).writeRateBytesPerSec;
        }

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        Map<String, Object> ioMap = new LinkedHashMap<String, Object>();
        ioMap.put("available", io == null ? false : io.available);
        ioMap.put("source", io == null ? null : io.source);
        ioMap.put("error", io == null ? null : io.error);
        ioMap.put("sampleMillis", io == null ? null : io.sampleMillis);
        detail.put("topIo", ioMap);

        List<Map<String, Object>> arr = new ArrayList<Map<String, Object>>();
        for (SystemMetrics.ProcessIoUsage one : top)
        {
            if (one == null)
                continue;
            Map<String, Object> p = new LinkedHashMap<String, Object>();
            p.put("pid", one.pid);
            p.put("processName", one.processName);
            p.put("processPath", one.processPath);
            p.put("memoryBytes", Long.valueOf(one.memoryBytes));
            p.put("readBytes", one.readBytes);
            p.put("writeBytes", one.writeBytes);
            p.put("readRateBytesPerSec", one.readRateBytesPerSec);
            p.put("writeRateBytesPerSec", one.writeRateBytesPerSec);
            p.put("ioRateBytesPerSec", one.ioRateBytesPerSec);
            p.put("source", one.source);
            arr.add(p);
        }
        detail.put("topProcesses", arr);
        ext.detailJson = CJson.toJson(detail);

        OpmCollectResult ret = new OpmCollectResult();
        ret.collectorKey = getCollectorKey();
        ret.collectorLabel = getCollectorLabel();
        ret.collectTime = now;
        ret.collectCostMs = (System.nanoTime() - begin) / 1000000L;
        ret.metricExt = ext;
        ret.summary = "TopProc=" + ToolUtilities.getString(ext.topProcName, "N/A")
                + ", ReadRate=" + SystemMetricsUtil.formatRate(ToolUtilities.getDouble(ext.topProcReadRate, -1D))
                + ", WriteRate=" + SystemMetricsUtil.formatRate(ToolUtilities.getDouble(ext.topProcWriteRate, -1D));
        if (io == null || !io.available)
            ret.status = OpmConst.STATUS_ERROR;
        return ret;
    }

    @Override
    public List<OpmRuleResult> evaluateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception
    {
        ArrayList<OpmRuleResult> list = new ArrayList<OpmRuleResult>();
        if (collectResult == null || !(collectResult.metricExt instanceof OpmIoMetricDo))
            return list;

        OpmIoMetricDo ext = (OpmIoMetricDo) collectResult.metricExt;
        long now = System.currentTimeMillis();
        OpmRuleResult ioRule = evalTopIoRule(ext, agentCtx, now);
        if (ioRule != null)
            list.add(ioRule);
        return list;
    }

    protected OpmRuleResult evalTopIoRule(OpmIoMetricDo ext, OpmAgentContext agentCtx, long now)
    {
        double ioRate = ToolUtilities.getDouble(ext.topProcReadRate, 0D) + ToolUtilities.getDouble(ext.topProcWriteRate, 0D);
        if (ioRate <= 0D || ToolUtilities.isStringEmpty(ext.topProcName, true))
            return null;

        AlarmLevelConfig[] levels = new AlarmLevelConfig[] {
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", _criticalRateBytesPerSec, _criticalDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MAJOR, "主要", _majorRateBytesPerSec, _majorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MINOR, "次要", _minorRateBytesPerSec, _minorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_WARN, "警告", _warnRateBytesPerSec, _warnDurationSec)
        };

        for (AlarmLevelConfig level : levels)
        {
            if (ioRate < level.threshold)
                continue;

            List<OpmIoMetricDo> history = queryHistoryMetrics(agentCtx == null ? null : agentCtx.getAgentCode(), now - level.durationSec * 1000L);
            if (!allIoOver(history, ext.topProcName, level.threshold))
                continue;

            OpmRuleResult rs = new OpmRuleResult();
            rs.triggered = true;
            rs.alarmLevel = level.level;
            rs.ruleKey = OpmAlarmConfigKeys.RULE_TOP_IO;
            rs.configParamKey = resolveConfigParamKey(level.level);
            rs.ruleLabel = "TOP进程IO门限";
            rs.message = "TOP进程IO持续过高: 进程=" + ext.topProcName
                    + ", 当前=" + SystemMetricsUtil.formatRate(ioRate)
                    + ", 级别=" + level.levelName
                    + ", 阈值=" + SystemMetricsUtil.formatRate(level.threshold)
                    + ", 持续" + level.durationSec + "秒";
            rs.detailJson = ext.detailJson;

            OpmSysAlarmExtDo alarmExt = new OpmSysAlarmExtDo();
            alarmExt.metricName = "topProcIoRate";
            alarmExt.currentRate = Double.valueOf(ioRate);
            alarmExt.triggerLevel = level.levelName;
            alarmExt.thresholdRate = Double.valueOf(level.threshold);
            alarmExt.durationSec = Integer.valueOf(level.durationSec);
            alarmExt.warnRate = Double.valueOf(_warnRateBytesPerSec);
            alarmExt.criticalRate = Double.valueOf(_criticalRateBytesPerSec);
            rs.alarmExt = alarmExt;
            return rs;
        }

        return null;
    }

    protected String resolveConfigParamKey(int alarmLevel)
    {
        if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
            return OpmTopIoConst.CONF_CRITICAL_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
            return OpmTopIoConst.CONF_MAJOR_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
            return OpmTopIoConst.CONF_MINOR_RATE;
        return OpmTopIoConst.CONF_WARN_RATE;
    }

    protected boolean allIoOver(List<OpmIoMetricDo> history, String procName, double threshold)
    {
        if (history == null || history.isEmpty() || ToolUtilities.isStringEmpty(procName, true))
            return false;
        for (OpmIoMetricDo one : history)
        {
            if (one == null || !ToolUtilities.isStringEqual(procName, one.topProcName, true))
                return false;
            double oneRate = ToolUtilities.getDouble(one.topProcReadRate, 0D) + ToolUtilities.getDouble(one.topProcWriteRate, 0D);
            if (oneRate < threshold)
                return false;
        }
        return true;
    }

    protected List<SystemMetrics.ProcessIoUsage> cutTopIo(List<SystemMetrics.ProcessIoUsage> src, int max)
    {
        ArrayList<SystemMetrics.ProcessIoUsage> ret = new ArrayList<SystemMetrics.ProcessIoUsage>();
        if (src == null)
            return ret;

        for (SystemMetrics.ProcessIoUsage one : src)
        {
            if (one == null)
                continue;
            ret.add(one);
            if (ret.size() >= max)
                break;
        }
        return ret;
    }

    @Override
    public OpmConfigGroup getConfigGroup()
    {
        OpmConfigGroup root = new OpmConfigGroup(getCollectorKey(), getCollectorLabel())
                .setDesc("采集主机进程级 IO 活跃情况，用于发现磁盘读写压力较高的进程。主要参数控制采样窗口和保留的 Top 进程数量。 ");
        List<OpmParamDef> defs = getParamDefs();
        if (defs != null)
        {
            for (OpmParamDef p : defs)
            {
                if (p != null)
                    root.addParam(p);
            }
        }
        return root;
    }

    @SuppressWarnings("unchecked")
    protected List<Map<String, Object>> parseListFromDetail(String detailJson, String key)
    {
        if (ToolUtilities.isStringEmpty(detailJson))
            return null;
        try
        {
            Object obj = CJson.fromJson(detailJson);
            if (!(obj instanceof Map))
                return null;
            Object value = ((Map<String, Object>) obj).get(key);
            if (value instanceof List)
                return (List<Map<String, Object>>) value;
        }
        catch (Throwable ignore)
        {
        }
        return null;
    }

    protected List<OpmIoMetricDo> queryHistoryMetrics(String agentCode, long sinceTime)
    {
        List<OpmIoMetricDo> list = new ArrayList<OpmIoMetricDo>();
        if (ToolUtilities.isStringEmpty(agentCode, true))
            return list;
        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = Cnd.where(OpmIoMetricDo.AgentCode, "=", agentCode)
                    .and(OpmIoMetricDo.CollectTime, ">=", Long.valueOf(sinceTime))
                    .asc(OpmIoMetricDo.CollectTime);
            list = dao.queryDoList(OpmIoMetricDo.class, cnd);
        }
        catch (Throwable ignore)
        {
        }
        return list;
    }


    protected static class AlarmLevelConfig
    {
        int level;
        String levelName;
        double threshold;
        int durationSec;

        AlarmLevelConfig(int level, String levelName, double threshold, int durationSec)
        {
            this.level = level;
            this.levelName = levelName;
            this.threshold = threshold;
            this.durationSec = durationSec;
        }
    }

}
