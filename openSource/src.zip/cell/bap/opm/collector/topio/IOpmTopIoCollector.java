package cell.bap.opm.collector.topio;

import bap.cells.Cells;
import cell.bap.opm.collector.IOpmCollector;

public interface IOpmTopIoCollector extends IOpmCollector
{
    public static IOpmTopIoCollector get()
    {
        return Cells.get(IOpmTopIoCollector.class);
    }
}
