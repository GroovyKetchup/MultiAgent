package cell.bap.opm.collector.system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.nutz.dao.Cnd;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.cells.BasicCell;
import bap.md.opm.OpmAlarmExtDo;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import bap.md.opm.sys.OpmSysMetricDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmConst;
import bap.opm.OpmParamDef;
import bap.opm.OpmRuleResult;
import bap.opm.cfg.OpmConfigGroup;
import bap.opm.cfg.OpmConfigXmlBuilder;
import bap.opm.collector.system.OpmSysConst;
import bap.opm.system.SystemMetrics;
import bap.opm.system.SystemMetricsCollectSpec;
import bap.opm.system.SystemMetricsUtil;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.md.TsAlarm;

/**
 * OPM系统采集器。
 *
 * starter.xml 参数样板（可直接复制）：
 *
 * <module name="sys" label="系统采集器" enable="true" class_name="cell.bap.opm.collector.system.IOpmSysCollector">
 *     <param key="opm.sys.enable" label="启用系统采集器" type="boolean" value="true"/>
 *     <param key="opm.sys.collectIntervalSec" label="系统采集周期秒" type="int" value="5"/>
 *     <param key="opm.sys.cpu.sampleMillis" label="CPU采样毫秒" type="int" value="1000"/>
 *     
 *     <param key="opm.sys.cpu.warnRate" label="CPU警告阈值" type="string" value="0.70"/>
 *     <param key="opm.sys.cpu.warnDurationSec" label="CPU警告持续时间秒" type="int" value="60"/>
 *     <param key="opm.sys.cpu.minorRate" label="CPU次要阈值" type="string" value="0.80"/>
 *     <param key="opm.sys.cpu.minorDurationSec" label="CPU次要持续时间秒" type="int" value="30"/>
 *     <param key="opm.sys.cpu.majorRate" label="CPU主要阈值" type="string" value="0.90"/>
 *     <param key="opm.sys.cpu.majorDurationSec" label="CPU主要持续时间秒" type="int" value="15"/>
 *     <param key="opm.sys.cpu.criticalRate" label="CPU严重阈值" type="string" value="0.95"/>
 *     <param key="opm.sys.cpu.criticalDurationSec" label="CPU严重持续时间秒" type="int" value="5"/>
 *     
 *     <param key="opm.sys.mem.warnRate" label="内存警告阈值" type="string" value="0.70"/>
 *     <param key="opm.sys.mem.warnDurationSec" label="内存警告持续时间秒" type="int" value="60"/>
 *     <param key="opm.sys.mem.minorRate" label="内存次要阈值" type="string" value="0.80"/>
 *     <param key="opm.sys.mem.minorDurationSec" label="内存次要持续时间秒" type="int" value="30"/>
 *     <param key="opm.sys.mem.majorRate" label="内存主要阈值" type="string" value="0.90"/>
 *     <param key="opm.sys.mem.majorDurationSec" label="内存主要持续时间秒" type="int" value="15"/>
 *     <param key="opm.sys.mem.criticalRate" label="内存严重阈值" type="string" value="0.95"/>
 *     <param key="opm.sys.mem.criticalDurationSec" label="内存严重持续时间秒" type="int" value="5"/>
 *     
 *     <param key="opm.sys.rule.cooldownSec" label="系统规则冷却秒" type="int" value="300"/>
 * </module>
 */
public class COpmSysCollector extends BasicCell implements IOpmSysCollector
{
    protected volatile boolean _enable = OpmSysConst.DEFAULT_ENABLE;
    protected volatile long _collectIntervalMs = OpmSysConst.getCollectIntervalMs();
    protected volatile int _cpuSampleMillis = OpmSysConst.DEFAULT_CPU_SAMPLE_MILLIS;

    protected volatile double _cpuWarnRate = OpmSysConst.DEFAULT_CPU_WARN_RATE;
    protected volatile int _cpuWarnDurationSec = OpmSysConst.DEFAULT_CPU_WARN_DURATION_SEC;
    protected volatile double _cpuMinorRate = OpmSysConst.DEFAULT_CPU_MINOR_RATE;
    protected volatile int _cpuMinorDurationSec = OpmSysConst.DEFAULT_CPU_MINOR_DURATION_SEC;
    protected volatile double _cpuMajorRate = OpmSysConst.DEFAULT_CPU_MAJOR_RATE;
    protected volatile int _cpuMajorDurationSec = OpmSysConst.DEFAULT_CPU_MAJOR_DURATION_SEC;
    protected volatile double _cpuCriticalRate = OpmSysConst.DEFAULT_CPU_CRITICAL_RATE;
    protected volatile int _cpuCriticalDurationSec = OpmSysConst.DEFAULT_CPU_CRITICAL_DURATION_SEC;

    protected volatile double _memWarnRate = OpmSysConst.DEFAULT_MEM_WARN_RATE;
    protected volatile int _memWarnDurationSec = OpmSysConst.DEFAULT_MEM_WARN_DURATION_SEC;
    protected volatile double _memMinorRate = OpmSysConst.DEFAULT_MEM_MINOR_RATE;
    protected volatile int _memMinorDurationSec = OpmSysConst.DEFAULT_MEM_MINOR_DURATION_SEC;
    protected volatile double _memMajorRate = OpmSysConst.DEFAULT_MEM_MAJOR_RATE;
    protected volatile int _memMajorDurationSec = OpmSysConst.DEFAULT_MEM_MAJOR_DURATION_SEC;
    protected volatile double _memCriticalRate = OpmSysConst.DEFAULT_MEM_CRITICAL_RATE;
    protected volatile int _memCriticalDurationSec = OpmSysConst.DEFAULT_MEM_CRITICAL_DURATION_SEC;

    protected volatile long _diskCollectIntervalMs = OpmSysConst.getDiskCollectIntervalMs();
    protected volatile long _lastDiskCollectTime = 0L;
    protected volatile Double _lastDiskMaxUsageRate = Double.valueOf(-1D);
    protected volatile Integer _lastDiskCount = Integer.valueOf(0);

    protected volatile long _ioCollectIntervalMs = OpmSysConst.getIoCollectIntervalMs();
    protected volatile int _ioSampleMillis = OpmSysConst.DEFAULT_IO_SAMPLE_MILLIS;
    protected volatile long _lastIoCollectTime = 0L;
    protected volatile double _ioWarnRate = OpmSysConst.DEFAULT_IO_WARN_RATE;
    protected volatile int _ioWarnDurationSec = OpmSysConst.DEFAULT_IO_WARN_DURATION_SEC;
    protected volatile double _ioMinorRate = OpmSysConst.DEFAULT_IO_MINOR_RATE;
    protected volatile int _ioMinorDurationSec = OpmSysConst.DEFAULT_IO_MINOR_DURATION_SEC;
    protected volatile double _ioMajorRate = OpmSysConst.DEFAULT_IO_MAJOR_RATE;
    protected volatile int _ioMajorDurationSec = OpmSysConst.DEFAULT_IO_MAJOR_DURATION_SEC;
    protected volatile double _ioCriticalRate = OpmSysConst.DEFAULT_IO_CRITICAL_RATE;
    protected volatile int _ioCriticalDurationSec = OpmSysConst.DEFAULT_IO_CRITICAL_DURATION_SEC;
    protected volatile Double _lastIoTotalRate = Double.valueOf(-1D);

    protected volatile long _netCollectIntervalMs = OpmSysConst.getNetCollectIntervalMs();
    protected volatile int _netSampleMillis = OpmSysConst.DEFAULT_NET_SAMPLE_MILLIS;
    protected volatile long _lastNetCollectTime = 0L;
    protected volatile double _netWarnRate = OpmSysConst.DEFAULT_NET_WARN_RATE;
    protected volatile int _netWarnDurationSec = OpmSysConst.DEFAULT_NET_WARN_DURATION_SEC;
    protected volatile double _netMinorRate = OpmSysConst.DEFAULT_NET_MINOR_RATE;
    protected volatile int _netMinorDurationSec = OpmSysConst.DEFAULT_NET_MINOR_DURATION_SEC;
    protected volatile double _netMajorRate = OpmSysConst.DEFAULT_NET_MAJOR_RATE;
    protected volatile int _netMajorDurationSec = OpmSysConst.DEFAULT_NET_MAJOR_DURATION_SEC;
    protected volatile double _netCriticalRate = OpmSysConst.DEFAULT_NET_CRITICAL_RATE;
    protected volatile int _netCriticalDurationSec = OpmSysConst.DEFAULT_NET_CRITICAL_DURATION_SEC;
    protected volatile Double _lastNetTotalRate = Double.valueOf(-1D);

    @Override
    public String getCollectorKey()
    {
        return OpmSysConst.COLLECTOR_KEY;
    }

    @Override
    public String getCollectorLabel()
    {
        return OpmSysConst.COLLECTOR_LABEL;
    }

    @Override
    public List<OpmParamDef> getParamDefs()
    {
        List<OpmParamDef> defs = new LinkedList<OpmParamDef>();
        defs.add(new OpmParamDef(OpmSysConst.CONF_ENABLE, OpmSysConst.LABEL_ENABLE, "boolean", String.valueOf(OpmSysConst.DEFAULT_ENABLE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_COLLECT_INTERVAL_SEC, OpmSysConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_COLLECT_INTERVAL_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_CPU_SAMPLE_MILLIS, OpmSysConst.LABEL_CPU_SAMPLE_MILLIS, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_SAMPLE_MILLIS)));

        defs.add(new OpmParamDef(OpmSysConst.CONF_CPU_WARN_RATE, OpmSysConst.LABEL_CPU_WARN_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_CPU_WARN_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_CPU_WARN_DURATION_SEC, OpmSysConst.LABEL_CPU_WARN_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_CPU_MINOR_RATE, OpmSysConst.LABEL_CPU_MINOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_CPU_MINOR_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_CPU_MINOR_DURATION_SEC, OpmSysConst.LABEL_CPU_MINOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_CPU_MAJOR_RATE, OpmSysConst.LABEL_CPU_MAJOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_CPU_MAJOR_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_CPU_MAJOR_DURATION_SEC, OpmSysConst.LABEL_CPU_MAJOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_CPU_CRITICAL_RATE, OpmSysConst.LABEL_CPU_CRITICAL_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_CPU_CRITICAL_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_CPU_CRITICAL_DURATION_SEC, OpmSysConst.LABEL_CPU_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmSysConst.CONF_MEM_WARN_RATE, OpmSysConst.LABEL_MEM_WARN_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_MEM_WARN_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_MEM_WARN_DURATION_SEC, OpmSysConst.LABEL_MEM_WARN_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_MEM_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_MEM_MINOR_RATE, OpmSysConst.LABEL_MEM_MINOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_MEM_MINOR_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_MEM_MINOR_DURATION_SEC, OpmSysConst.LABEL_MEM_MINOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_MEM_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_MEM_MAJOR_RATE, OpmSysConst.LABEL_MEM_MAJOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_MEM_MAJOR_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_MEM_MAJOR_DURATION_SEC, OpmSysConst.LABEL_MEM_MAJOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_MEM_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_MEM_CRITICAL_RATE, OpmSysConst.LABEL_MEM_CRITICAL_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_MEM_CRITICAL_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_MEM_CRITICAL_DURATION_SEC, OpmSysConst.LABEL_MEM_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_MEM_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_COLLECT_INTERVAL_SEC, OpmSysConst.LABEL_IO_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_IO_COLLECT_INTERVAL_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_SAMPLE_MILLIS, OpmSysConst.LABEL_IO_SAMPLE_MILLIS, "int", String.valueOf(OpmSysConst.DEFAULT_IO_SAMPLE_MILLIS)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_WARN_RATE, OpmSysConst.LABEL_IO_WARN_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_IO_WARN_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_WARN_DURATION_SEC, OpmSysConst.LABEL_IO_WARN_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_IO_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_MINOR_RATE, OpmSysConst.LABEL_IO_MINOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_IO_MINOR_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_MINOR_DURATION_SEC, OpmSysConst.LABEL_IO_MINOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_IO_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_MAJOR_RATE, OpmSysConst.LABEL_IO_MAJOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_IO_MAJOR_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_MAJOR_DURATION_SEC, OpmSysConst.LABEL_IO_MAJOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_IO_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_CRITICAL_RATE, OpmSysConst.LABEL_IO_CRITICAL_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_IO_CRITICAL_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_IO_CRITICAL_DURATION_SEC, OpmSysConst.LABEL_IO_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_IO_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_COLLECT_INTERVAL_SEC, OpmSysConst.LABEL_NET_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_NET_COLLECT_INTERVAL_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_SAMPLE_MILLIS, OpmSysConst.LABEL_NET_SAMPLE_MILLIS, "int", String.valueOf(OpmSysConst.DEFAULT_NET_SAMPLE_MILLIS)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_WARN_RATE, OpmSysConst.LABEL_NET_WARN_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_NET_WARN_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_WARN_DURATION_SEC, OpmSysConst.LABEL_NET_WARN_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_NET_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_MINOR_RATE, OpmSysConst.LABEL_NET_MINOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_NET_MINOR_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_MINOR_DURATION_SEC, OpmSysConst.LABEL_NET_MINOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_NET_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_MAJOR_RATE, OpmSysConst.LABEL_NET_MAJOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_NET_MAJOR_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_MAJOR_DURATION_SEC, OpmSysConst.LABEL_NET_MAJOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_NET_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_CRITICAL_RATE, OpmSysConst.LABEL_NET_CRITICAL_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_NET_CRITICAL_RATE)));
        defs.add(new OpmParamDef(OpmSysConst.CONF_NET_CRITICAL_DURATION_SEC, OpmSysConst.LABEL_NET_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_NET_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmSysConst.CONF_RULE_COOLDOWN_SEC, OpmSysConst.LABEL_RULE_COOLDOWN_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_RULE_COOLDOWN_SEC)));
        return defs;
    }

    @Override
    public String getSampleConfigComment()
    {
        return OpmConfigXmlBuilder.buildModuleSample("sys", "系统采集器", "cell.bap.opm.collector.system.IOpmSysCollector", getConfigGroup());
    }

    @Override
    public long getCollectIntervalMs()
    {
        return _collectIntervalMs;
    }

    @Override
    public List<Class> getModelClasses()
    {
        List<Class> classes = new ArrayList<Class>();
        classes.add(OpmSysMetricDo.class);
        classes.add(OpmSysAlarmExtDo.class);
        return classes;
    }

    @Override
    public void loadConfig()
    {
        _enable = OpmSysConst.isEnable();
        _collectIntervalMs = OpmSysConst.getCollectIntervalMs();
        _cpuSampleMillis = OpmSysConst.getCpuSampleMillis();

        _cpuWarnRate = OpmSysConst.getCpuWarnRate();
        _cpuWarnDurationSec = OpmSysConst.getCpuWarnDurationSec();
        _cpuMinorRate = OpmSysConst.getCpuMinorRate();
        _cpuMinorDurationSec = OpmSysConst.getCpuMinorDurationSec();
        _cpuMajorRate = OpmSysConst.getCpuMajorRate();
        _cpuMajorDurationSec = OpmSysConst.getCpuMajorDurationSec();
        _cpuCriticalRate = OpmSysConst.getCpuCriticalRate();
        _cpuCriticalDurationSec = OpmSysConst.getCpuCriticalDurationSec();

        _memWarnRate = OpmSysConst.getMemWarnRate();
        _memWarnDurationSec = OpmSysConst.getMemWarnDurationSec();
        _memMinorRate = OpmSysConst.getMemMinorRate();
        _memMinorDurationSec = OpmSysConst.getMemMinorDurationSec();
        _memMajorRate = OpmSysConst.getMemMajorRate();
        _memMajorDurationSec = OpmSysConst.getMemMajorDurationSec();
        _memCriticalRate = OpmSysConst.getMemCriticalRate();
        _memCriticalDurationSec = OpmSysConst.getMemCriticalDurationSec();

        _ioCollectIntervalMs = OpmSysConst.getIoCollectIntervalMs();
        _ioSampleMillis = OpmSysConst.getIoSampleMillis();
        _ioWarnRate = OpmSysConst.getIoWarnRate();
        _ioWarnDurationSec = OpmSysConst.getIoWarnDurationSec();
        _ioMinorRate = OpmSysConst.getIoMinorRate();
        _ioMinorDurationSec = OpmSysConst.getIoMinorDurationSec();
        _ioMajorRate = OpmSysConst.getIoMajorRate();
        _ioMajorDurationSec = OpmSysConst.getIoMajorDurationSec();
        _ioCriticalRate = OpmSysConst.getIoCriticalRate();
        _ioCriticalDurationSec = OpmSysConst.getIoCriticalDurationSec();

        _netCollectIntervalMs = OpmSysConst.getNetCollectIntervalMs();
        _netSampleMillis = OpmSysConst.getNetSampleMillis();
        _netWarnRate = OpmSysConst.getNetWarnRate();
        _netWarnDurationSec = OpmSysConst.getNetWarnDurationSec();
        _netMinorRate = OpmSysConst.getNetMinorRate();
        _netMinorDurationSec = OpmSysConst.getNetMinorDurationSec();
        _netMajorRate = OpmSysConst.getNetMajorRate();
        _netMajorDurationSec = OpmSysConst.getNetMajorDurationSec();
        _netCriticalRate = OpmSysConst.getNetCriticalRate();
        _netCriticalDurationSec = OpmSysConst.getNetCriticalDurationSec();
    }

    @Override
    public OpmCollectResult collect(OpmAgentContext agentCtx) throws Exception
    {
        long begin = System.nanoTime();
        loadConfig();
        if (!_enable)
            return null;

        SystemMetrics metrics = SystemMetricsUtil.collect(_cpuSampleMillis, SystemMetricsCollectSpec.forSysCollector());

        OpmSysMetricDo ext = new OpmSysMetricDo();
        ext.collectorKey = getCollectorKey();
        ext.collectorLabel = getCollectorLabel();
        ext.agentCode = agentCtx.getAgentCode();
        ext.agentName = agentCtx.getAgentName();
        ext.myUri = agentCtx.getMyUri();
        ext.collectTime = metrics == null ? System.currentTimeMillis() : metrics.timestamp;

        if (metrics != null)
        {
            ext.hostName = metrics.hostName;
            ext.osName = metrics.osName;
            ext.provider = metrics.provider;
            ext.cpuUsageRate = getValidRate(metrics.cpu == null ? -1D : metrics.cpu.usageRate);
            ext.memUsageRate = getValidRate(metrics.memory == null ? -1D : metrics.memory.usageRate);
            fillDiskMetrics(ext, metrics);
            fillIoMetrics(ext, metrics);
            fillNetMetrics(ext, metrics);
            ext.detailJson = CJson.toJson(metrics);
        }
        ext.summary = buildSummary(ext);

        OpmCollectResult result = new OpmCollectResult();
        result.collectorKey = getCollectorKey();
        result.collectorLabel = getCollectorLabel();
        result.collectTime = ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue();
        result.collectCostMs = (System.nanoTime() - begin) / 1000000L;
        result.metricExt = ext;
        result.summary = ext.summary;
        result.status = isCollectError(metrics) ? OpmConst.STATUS_ERROR : OpmConst.STATUS_NORMAL;
        return result;
    }

    @Override
    public List<OpmRuleResult> evaluateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception
    {
        List<OpmRuleResult> list = new LinkedList<OpmRuleResult>();
        if (collectResult == null || collectResult.metricExt == null || !(collectResult.metricExt instanceof OpmSysMetricDo))
            return list;

        return list;
    }

    protected OpmRuleResult evalCpuMemRule(String metricName, String metricLabel, Double rateValue,
            double criticalRate, int criticalDurationSec,
            double majorRate, int majorDurationSec,
            double minorRate, int minorDurationSec,
            double warnRate, int warnDurationSec,
            long now, OpmSysMetricDo sysMetric, OpmAgentContext agentCtx)
    {
        if (rateValue == null || rateValue.doubleValue() < 0D)
            return null;

        AlarmLevelConfig[] levels = new AlarmLevelConfig[] {
            new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", criticalRate, criticalDurationSec),
            new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MAJOR, "主要", majorRate, majorDurationSec),
            new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MINOR, "次要", minorRate, minorDurationSec),
            new AlarmLevelConfig(TsAlarm.LEVEL_WARN, "警告", warnRate, warnDurationSec)
        };

        for (AlarmLevelConfig level : levels)
        {
            if (rateValue.doubleValue() < level.threshold)
                continue;

            long sinceTime = now - level.durationSec * 1000L;
            List<OpmSysMetricDo> history = queryHistoryMetrics(agentCtx.getAgentCode(), metricName, sinceTime);

            if (history == null || history.isEmpty())
                continue;

            boolean allOverThreshold = true;
            for (OpmSysMetricDo m : history)
            {
                Double histValue = getMetricValue(m, metricName);
                if (histValue == null || histValue.doubleValue() < 0D || histValue.doubleValue() < level.threshold)
                {
                    allOverThreshold = false;
                    break;
                }
            }

            if (allOverThreshold)
            {
                String ruleKey = metricName + "Threshold";

                return buildAlarmResult(metricName, metricLabel, level, rateValue, history.size(), sysMetric, agentCtx);
            }
        }

        return null;
    }

    protected OpmRuleResult evalDiskRule(String metricName, String metricLabel, Double rateValue,
            double warnRate, double criticalRate, long now, OpmSysMetricDo sysMetric, OpmAgentContext agentCtx)
    {
        if (rateValue == null || rateValue.doubleValue() < 0D)
            return null;

        int level = -1;
        double threshold = 0D;
        String levelName = "";

        if (rateValue.doubleValue() >= criticalRate)
        {
            level = TsAlarm.LEVEL_ERROR_CRITICAL;
            threshold = criticalRate;
            levelName = "严重";
        }
        else if (rateValue.doubleValue() >= warnRate)
        {
            level = TsAlarm.LEVEL_WARN;
            threshold = warnRate;
            levelName = "警告";
        }

        if (level < 0)
            return null;

        String ruleKey = metricName + "Threshold";

        OpmRuleResult rs = new OpmRuleResult();
        rs.triggered = true;
        rs.alarmLevel = level;
        rs.ruleKey = ruleKey;
        rs.ruleLabel = metricLabel + "门限";
        rs.message = metricLabel + "超过阈值: 当前=" + formatRate(rateValue.doubleValue())
                + ", 级别=" + levelName
                + ", 阈值=" + formatRate(threshold);

        Map<String, Object> detail = new HashMap<String, Object>();
        detail.put("collectorKey", getCollectorKey());
        detail.put("metricName", metricName);
        detail.put("metricLabel", metricLabel);
        detail.put("currentRate", rateValue);
        detail.put("thresholdRate", Double.valueOf(threshold));
        detail.put("triggerLevel", levelName);
        detail.put("agentCode", agentCtx.getAgentCode());
        detail.put("agentName", agentCtx.getAgentName());
        detail.put("myUri", agentCtx.getMyUri());
        detail.put("collectTime", sysMetric.collectTime);
        rs.detailJson = CJson.toJson(detail);

        OpmSysAlarmExtDo ext = new OpmSysAlarmExtDo();
        ext.metricName = metricName;
        ext.currentRate = rateValue;
        ext.triggerLevel = levelName;
        ext.thresholdRate = Double.valueOf(threshold);
        ext.warnRate = Double.valueOf(warnRate);
        ext.criticalRate = Double.valueOf(criticalRate);
        ext.message = rs.message;
        ext.detailJson = rs.detailJson;
        rs.alarmExt = ext;

        return rs;
    }

    protected OpmRuleResult buildAlarmResult(String metricName, String metricLabel, AlarmLevelConfig level,
            Double currentValue, int historyCount, OpmSysMetricDo sysMetric, OpmAgentContext agentCtx)
    {
        OpmRuleResult rs = new OpmRuleResult();
        rs.triggered = true;
        rs.alarmLevel = level.level;
        rs.ruleKey = metricName + "Threshold";
        rs.ruleLabel = metricLabel + "门限";
        rs.message = metricLabel + "超过阈值: 当前=" + formatRate(currentValue.doubleValue())
                + ", 级别=" + level.levelName
                + ", 阈值=" + formatRate(level.threshold)
                + ", 持续" + level.durationSec + "秒";

        Map<String, Object> detail = new HashMap<String, Object>();
        detail.put("collectorKey", getCollectorKey());
        detail.put("metricName", metricName);
        detail.put("metricLabel", metricLabel);
        detail.put("currentRate", currentValue);
        detail.put("thresholdRate", Double.valueOf(level.threshold));
        detail.put("triggerLevel", level.levelName);
        detail.put("durationSec", Integer.valueOf(level.durationSec));
        detail.put("historyCount", Integer.valueOf(historyCount));
        detail.put("agentCode", agentCtx.getAgentCode());
        detail.put("agentName", agentCtx.getAgentName());
        detail.put("myUri", agentCtx.getMyUri());
        detail.put("collectTime", sysMetric.collectTime);
        rs.detailJson = CJson.toJson(detail);

        OpmSysAlarmExtDo ext = new OpmSysAlarmExtDo();
        ext.metricName = metricName;
        ext.currentRate = currentValue;
        ext.triggerLevel = level.levelName;
        ext.thresholdRate = Double.valueOf(level.threshold);
        ext.durationSec = Integer.valueOf(level.durationSec);
        ext.message = rs.message;
        ext.detailJson = rs.detailJson;
        rs.alarmExt = ext;

        return rs;
    }

    protected List<OpmSysMetricDo> queryHistoryMetrics(String agentCode, String metricName, long sinceTime)
    {
        List<OpmSysMetricDo> list = new ArrayList<OpmSysMetricDo>();
        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = Cnd.where(OpmSysMetricDo.AgentCode, "=", agentCode)
                    .and(OpmSysMetricDo.CollectTime, ">=", Long.valueOf(sinceTime))
                    .asc(OpmSysMetricDo.CollectTime);
            list = dao.queryDoList(OpmSysMetricDo.class, cnd);
        }
        catch (Exception e)
        {
            ToolUtilities.warning(OpmConst.LOG, "Failed to query history metrics: " + e.getMessage(), e);
        }
        return list;
    }

    protected Double getMetricValue(OpmSysMetricDo metric, String metricName)
    {
        if (metric == null)
            return null;
        if ("cpuUsage".equals(metricName))
            return metric.cpuUsageRate;
        if ("memUsage".equals(metricName))
            return metric.memUsageRate;
        return null;
    }

    protected boolean isCollectError(SystemMetrics metrics)
    {
        if (metrics == null)
            return true;
        if (metrics.cpu == null || !metrics.cpu.available)
            return true;
        if (metrics.memory == null || !metrics.memory.available)
            return true;
        return false;
    }

    protected boolean over(Double value, double threshold)
    {
        return value != null && value.doubleValue() >= 0D && value.doubleValue() >= threshold;
    }

    protected String buildSummary(OpmSysMetricDo ext)
    {
        return "cpu=" + formatRate(ext.cpuUsageRate) + ", mem=" + formatRate(ext.memUsageRate)
                + ", diskMax=" + formatRate(ext.diskMaxUsageRate)
                + ", io=" + SystemMetricsUtil.formatRate(ToolUtilities.getDouble(ext.ioTotalRate, 0D))
                + ", net=" + SystemMetricsUtil.formatRate(ToolUtilities.getDouble(ext.netTotalRate, 0D));
    }

    protected Double getValidRate(double value)
    {
        if (Double.isNaN(value) || Double.isInfinite(value) || value < 0D)
            return Double.valueOf(-1D);
        if (value > 1D)
            return Double.valueOf(1D);
        return Double.valueOf(value);
    }

    protected Double getMaxDiskUsage(SystemMetrics metrics)
    {
        if (metrics == null || metrics.disks == null || metrics.disks.isEmpty())
            return Double.valueOf(-1D);

        double max = -1D;
        for (SystemMetrics.DiskUsage d : metrics.disks)
        {
            if (d == null || !d.available)
                continue;
            if (d.usageRate > max)
                max = d.usageRate;
        }
        return getValidRate(max);
    }

    protected void fillDiskMetrics(OpmSysMetricDo ext, SystemMetrics metrics)
    {
        long now = ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue();
        boolean needRefresh = _lastDiskCollectTime <= 0L || now - _lastDiskCollectTime >= _diskCollectIntervalMs;

        if (needRefresh)
        {
            _lastDiskMaxUsageRate = getMaxDiskUsage(metrics);
            _lastDiskCount = Integer.valueOf(metrics == null || metrics.disks == null ? 0 : metrics.disks.size());
            _lastDiskCollectTime = now;
        }

        ext.diskMaxUsageRate = _lastDiskMaxUsageRate;
        ext.diskCount = _lastDiskCount;
    }

    protected void fillIoMetrics(OpmSysMetricDo ext, SystemMetrics metrics)
    {
        long now = ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue();
        boolean needRefresh = _lastIoCollectTime <= 0L || now - _lastIoCollectTime >= _ioCollectIntervalMs;

        if (needRefresh)
        {
            if (metrics != null && metrics.io != null && metrics.io.processes != null)
            {
                double totalReadRate = 0D;
                double totalWriteRate = 0D;
                for (SystemMetrics.ProcessIoUsage proc : metrics.io.processes)
                {
                    if (proc != null)
                    {
                        totalReadRate += proc.readRateBytesPerSec;
                        totalWriteRate += proc.writeRateBytesPerSec;
                    }
                }
                ext.ioReadRate = totalReadRate;
                ext.ioWriteRate = totalWriteRate;
                ext.ioTotalRate = totalReadRate + totalWriteRate;
                _lastIoTotalRate = ext.ioTotalRate;
            }
            else
            {
                ext.ioReadRate = 0D;
                ext.ioWriteRate = 0D;
                ext.ioTotalRate = 0D;
                _lastIoTotalRate = 0D;
            }
            _lastIoCollectTime = now;
        }
        else
        {
            ext.ioReadRate = _lastIoTotalRate;
            ext.ioWriteRate = _lastIoTotalRate;
            ext.ioTotalRate = _lastIoTotalRate;
        }
    }

    protected void fillNetMetrics(OpmSysMetricDo ext, SystemMetrics metrics)
    {
        long now = ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue();
        boolean needRefresh = _lastNetCollectTime <= 0L || now - _lastNetCollectTime >= _netCollectIntervalMs;

        if (needRefresh)
        {
            if (metrics != null && metrics.network != null)
            {
                ext.netRxRate = metrics.network.totalRxRateBytesPerSec;
                ext.netTxRate = metrics.network.totalTxRateBytesPerSec;
                ext.netTotalRate = metrics.network.totalThroughputBytesPerSec;
                _lastNetTotalRate = ext.netTotalRate;
            }
            else
            {
                ext.netRxRate = 0D;
                ext.netTxRate = 0D;
                ext.netTotalRate = 0D;
                _lastNetTotalRate = 0D;
            }
            _lastNetCollectTime = now;
        }
        else
        {
            ext.netRxRate = _lastNetTotalRate;
            ext.netTxRate = _lastNetTotalRate;
            ext.netTotalRate = _lastNetTotalRate;
        }
    }

    protected String formatRate(double v)
    {
        if (v < 0D)
            return "N/A";
        return String.format(java.util.Locale.US, "%.2f%%", Double.valueOf(v * 100D));
    }

    protected static class AlarmLevelConfig
    {
        public int level;
        public String levelName;
        public double threshold;
        public int durationSec;

        public AlarmLevelConfig(int level, String levelName, double threshold, int durationSec)
        {
            this.level = level;
            this.levelName = levelName;
            this.threshold = threshold;
            this.durationSec = durationSec;
        }
    }

    @Override
    public OpmConfigGroup getConfigGroup()
    {
        OpmConfigGroup root = new OpmConfigGroup(getCollectorKey(), getCollectorLabel())
                .setDesc("采集主机 CPU、内存、磁盘与网络等基础系统指标，并按内置规则生成系统级告警，是 OPM 的基础监控模组。")
                ;

        root.addParam(new OpmParamDef(OpmSysConst.CONF_ENABLE, OpmSysConst.LABEL_ENABLE, "boolean", String.valueOf(OpmSysConst.DEFAULT_ENABLE)));
        root.addParam(new OpmParamDef(OpmSysConst.CONF_COLLECT_INTERVAL_SEC, OpmSysConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_COLLECT_INTERVAL_SEC)));
        root.addParam(new OpmParamDef(OpmSysConst.CONF_CPU_SAMPLE_MILLIS, OpmSysConst.LABEL_CPU_SAMPLE_MILLIS, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_SAMPLE_MILLIS)));
        root.addParam(new OpmParamDef(OpmSysConst.CONF_DISK_COLLECT_INTERVAL_SEC, OpmSysConst.LABEL_DISK_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_DISK_COLLECT_INTERVAL_SEC)));
        OpmConfigGroup cpuGroup = new OpmConfigGroup("cpu", "CPU告警")
                .setDesc("根据 CPU 使用率及持续时间进行分级告警，下方参数只用于配置不同等级的 CPU 阈值和持续时间。 ");
        cpuGroup.addParam(new OpmParamDef(OpmSysConst.CONF_CPU_WARN_RATE, OpmSysConst.LABEL_CPU_WARN_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_CPU_WARN_RATE)));
        cpuGroup.addParam(new OpmParamDef(OpmSysConst.CONF_CPU_WARN_DURATION_SEC, OpmSysConst.LABEL_CPU_WARN_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_WARN_DURATION_SEC)));
        cpuGroup.addParam(new OpmParamDef(OpmSysConst.CONF_CPU_MINOR_RATE, OpmSysConst.LABEL_CPU_MINOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_CPU_MINOR_RATE)));
        cpuGroup.addParam(new OpmParamDef(OpmSysConst.CONF_CPU_MINOR_DURATION_SEC, OpmSysConst.LABEL_CPU_MINOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_MINOR_DURATION_SEC)));
        cpuGroup.addParam(new OpmParamDef(OpmSysConst.CONF_CPU_MAJOR_RATE, OpmSysConst.LABEL_CPU_MAJOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_CPU_MAJOR_RATE)));
        cpuGroup.addParam(new OpmParamDef(OpmSysConst.CONF_CPU_MAJOR_DURATION_SEC, OpmSysConst.LABEL_CPU_MAJOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_MAJOR_DURATION_SEC)));
        cpuGroup.addParam(new OpmParamDef(OpmSysConst.CONF_CPU_CRITICAL_RATE, OpmSysConst.LABEL_CPU_CRITICAL_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_CPU_CRITICAL_RATE)));
        cpuGroup.addParam(new OpmParamDef(OpmSysConst.CONF_CPU_CRITICAL_DURATION_SEC, OpmSysConst.LABEL_CPU_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_CPU_CRITICAL_DURATION_SEC)));
        root.addGroup(cpuGroup);

        OpmConfigGroup memGroup = new OpmConfigGroup("mem", "内存告警")
                .setDesc("根据内存使用率及持续时间进行分级告警，下方参数只用于配置不同等级的内存阈值和持续时间。 ");
        memGroup.addParam(new OpmParamDef(OpmSysConst.CONF_MEM_WARN_RATE, OpmSysConst.LABEL_MEM_WARN_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_MEM_WARN_RATE)));
        memGroup.addParam(new OpmParamDef(OpmSysConst.CONF_MEM_WARN_DURATION_SEC, OpmSysConst.LABEL_MEM_WARN_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_MEM_WARN_DURATION_SEC)));
        memGroup.addParam(new OpmParamDef(OpmSysConst.CONF_MEM_MINOR_RATE, OpmSysConst.LABEL_MEM_MINOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_MEM_MINOR_RATE)));
        memGroup.addParam(new OpmParamDef(OpmSysConst.CONF_MEM_MINOR_DURATION_SEC, OpmSysConst.LABEL_MEM_MINOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_MEM_MINOR_DURATION_SEC)));
        memGroup.addParam(new OpmParamDef(OpmSysConst.CONF_MEM_MAJOR_RATE, OpmSysConst.LABEL_MEM_MAJOR_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_MEM_MAJOR_RATE)));
        memGroup.addParam(new OpmParamDef(OpmSysConst.CONF_MEM_MAJOR_DURATION_SEC, OpmSysConst.LABEL_MEM_MAJOR_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_MEM_MAJOR_DURATION_SEC)));
        memGroup.addParam(new OpmParamDef(OpmSysConst.CONF_MEM_CRITICAL_RATE, OpmSysConst.LABEL_MEM_CRITICAL_RATE, "string", String.valueOf(OpmSysConst.DEFAULT_MEM_CRITICAL_RATE)));
        memGroup.addParam(new OpmParamDef(OpmSysConst.CONF_MEM_CRITICAL_DURATION_SEC, OpmSysConst.LABEL_MEM_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_MEM_CRITICAL_DURATION_SEC)));
        root.addGroup(memGroup);

        root.addParam(new OpmParamDef(OpmSysConst.CONF_RULE_COOLDOWN_SEC, OpmSysConst.LABEL_RULE_COOLDOWN_SEC, "int", String.valueOf(OpmSysConst.DEFAULT_RULE_COOLDOWN_SEC)));

        return root;
    }
}
