package cell.bap.opm.collector.system;

import bap.cells.Cells;
import cell.bap.opm.collector.IOpmCollector;

public interface IOpmSysCollector extends IOpmCollector
{
    public static IOpmSysCollector get()
    {
        return Cells.get(IOpmSysCollector.class);
    }
}
