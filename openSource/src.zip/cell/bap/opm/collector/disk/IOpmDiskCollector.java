package cell.bap.opm.collector.disk;

import bap.cells.Cells;
import cell.bap.opm.collector.IOpmCollector;

public interface IOpmDiskCollector extends IOpmCollector
{
    public static IOpmDiskCollector get()
    {
        return Cells.get(IOpmDiskCollector.class);
    }
}
