package cell.bap.opm.collector.disk;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.cells.BasicCell;
import bap.md.opm.disk.OpmDiskMetricDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmConst;
import bap.opm.OpmParamDef;
import bap.opm.cfg.OpmConfigGroup;
import bap.opm.cfg.OpmConfigXmlBuilder;
import bap.opm.OpmRuleResult;
import bap.opm.collector.disk.OpmDiskConst;
import bap.opm.system.SystemMetrics;
import bap.opm.system.SystemMetricsCollectSpec;
import bap.opm.system.SystemMetricsUtil;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import tiny.service.md.TsAlarm;

/**
 * 磁盘采集器（分区级）。
 */
public class COpmDiskCollector extends BasicCell implements IOpmDiskCollector
{
    protected volatile boolean _enable = OpmDiskConst.DEFAULT_ENABLE;
    protected volatile long _collectIntervalMs = OpmDiskConst.getCollectIntervalMs();
    protected volatile double _warnRate = OpmDiskConst.DEFAULT_WARN_RATE;
    protected volatile double _criticalRate = OpmDiskConst.DEFAULT_CRITICAL_RATE;

    @Override
    public String getCollectorKey()
    {
        return OpmDiskConst.COLLECTOR_KEY;
    }

    @Override
    public String getCollectorLabel()
    {
        return OpmDiskConst.COLLECTOR_LABEL;
    }

    @Override
    public List<OpmParamDef> getParamDefs()
    {
        ArrayList<OpmParamDef> list = new ArrayList<OpmParamDef>();
        list.add(new OpmParamDef(OpmDiskConst.CONF_ENABLE, OpmDiskConst.LABEL_ENABLE, "boolean", String.valueOf(OpmDiskConst.DEFAULT_ENABLE)));
        list.add(new OpmParamDef(OpmDiskConst.CONF_COLLECT_INTERVAL_SEC, OpmDiskConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmDiskConst.DEFAULT_COLLECT_INTERVAL_SEC)));
        list.add(new OpmParamDef(OpmDiskConst.CONF_WARN_RATE, OpmDiskConst.LABEL_WARN_RATE, "string", String.valueOf(OpmDiskConst.DEFAULT_WARN_RATE)));
        list.add(new OpmParamDef(OpmDiskConst.CONF_CRITICAL_RATE, OpmDiskConst.LABEL_CRITICAL_RATE, "string", String.valueOf(OpmDiskConst.DEFAULT_CRITICAL_RATE)));
        return list;
    }

    @Override
    public String getSampleConfigComment()
    {
        return OpmConfigXmlBuilder.buildModuleSample("disk", "磁盘监控", "cell.bap.opm.collector.disk.IOpmDiskCollector", getConfigGroup());
    }

    @Override
    public long getCollectIntervalMs()
    {
        return _collectIntervalMs;
    }

    @Override
    public List<Class> getModelClasses()
    {
        List<Class> list = new ArrayList<Class>();
        list.add(OpmDiskMetricDo.class);
        return list;
    }

    @Override
    public void loadConfig()
    {
        _enable = OpmDiskConst.isEnable();
        _collectIntervalMs = OpmDiskConst.getCollectIntervalMs();
        _warnRate = OpmDiskConst.getWarnRate();
        _criticalRate = OpmDiskConst.getCriticalRate();
        if (_collectIntervalMs <= 0L)
            _collectIntervalMs = OpmDiskConst.DEFAULT_COLLECT_INTERVAL_SEC * 1000L;
    }

    @Override
    public OpmCollectResult collect(OpmAgentContext agentCtx) throws Exception
    {
        long begin = System.nanoTime();
        if (!_enable)
            return null;

        long now = System.currentTimeMillis();
        SystemMetrics metrics = SystemMetricsUtil.collect(1000L, SystemMetricsCollectSpec.forDiskCollector());

        OpmDiskMetricDo ext = new OpmDiskMetricDo();
        ext.collectorKey = getCollectorKey();
        ext.collectorLabel = getCollectorLabel();
        ext.agentCode = agentCtx == null ? null : agentCtx.getAgentCode();
        ext.agentName = agentCtx == null ? null : agentCtx.getAgentName();
        ext.myUri = agentCtx == null ? null : agentCtx.getMyUri();
        ext.collectTime = now;
        ext.hostName = metrics == null ? null : metrics.hostName;
        ext.osName = metrics == null ? null : metrics.osName;
        ext.provider = metrics == null ? null : metrics.provider;

        List<SystemMetrics.DiskUsage> disks = metrics == null ? null : metrics.disks;
        ext.diskCount = disks == null ? 0 : disks.size();

        long totalBytes = 0L;
        long totalUsedBytes = 0L;
        long totalFreeBytes = 0L;
        double maxUsage = -1D;
        String maxMount = null;
        if (disks != null)
            for (SystemMetrics.DiskUsage one : disks)
            {
                if (one == null)
                    continue;

                long oneTotal = normalizeBytes(one.totalBytes);
                long oneUsed = normalizeBytes(one.usedBytes);
                long oneFree = normalizeBytes(one.freeBytes);

                if (oneTotal > 0L)
                {
                    if (oneUsed > oneTotal)
                        oneUsed = oneTotal;
                    if (oneFree > oneTotal)
                        oneFree = oneTotal;
                    if (oneUsed + oneFree > oneTotal)
                    {
                        long overflow = oneUsed + oneFree - oneTotal;
                        if (oneFree >= overflow)
                            oneFree -= overflow;
                        else
                            oneUsed = Math.max(0L, oneTotal - oneFree);
                    }

                    totalBytes += oneTotal;
                    totalUsedBytes += oneUsed;
                    totalFreeBytes += oneFree;
                }

                if (one.available && one.usageRate >= 0D && one.usageRate > maxUsage)
                {
                    maxUsage = one.usageRate;
                    maxMount = one.mountPath;
                }
            }

        if (totalBytes > 0L)
        {
            ext.totalBytes = Long.valueOf(totalBytes);
            ext.totalUsedBytes = Long.valueOf(totalUsedBytes);
            ext.totalFreeBytes = Long.valueOf(totalFreeBytes);
            ext.totalUsageRate = Double.valueOf((double) totalUsedBytes / (double) totalBytes);
        }
        else
        {
            ext.totalBytes = null;
            ext.totalUsedBytes = null;
            ext.totalFreeBytes = null;
            ext.totalUsageRate = null;
        }

        ext.maxUsageRate = maxUsage < 0D ? null : Double.valueOf(maxUsage);
        ext.maxUsageMount = maxMount;

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        detail.put("diskCount", ext.diskCount);
        detail.put("totalBytes", ext.totalBytes);
        detail.put("totalUsedBytes", ext.totalUsedBytes);
        detail.put("totalFreeBytes", ext.totalFreeBytes);
        detail.put("totalUsageRate", ext.totalUsageRate);

        List<Map<String, Object>> arr = new ArrayList<Map<String, Object>>();
        if (disks != null)
            for (SystemMetrics.DiskUsage one : disks)
            {
                if (one == null)
                    continue;
                Map<String, Object> d = new LinkedHashMap<String, Object>();
                d.put("available", one.available);
                d.put("mountPath", one.mountPath);
                d.put("fileSystem", one.fileSystem);
                d.put("usageRate", one.usageRate);
                d.put("totalBytes", one.totalBytes);
                d.put("usedBytes", one.usedBytes);
                d.put("freeBytes", one.freeBytes);
                d.put("type", one.type);
                d.put("source", one.source);
                arr.add(d);
            }
        detail.put("disks", arr);
        ext.detailJson = CJson.toJson(detail);

        OpmCollectResult ret = new OpmCollectResult();
        ret.collectorKey = getCollectorKey();
        ret.collectorLabel = getCollectorLabel();
        ret.collectTime = now;
        ret.collectCostMs = (System.nanoTime() - begin) / 1000000L;
        ret.metricExt = ext;
        ret.summary = "Partitions=" + ToolUtilities.getInteger(ext.diskCount, 0)
                + ", TotalUsage=" + SystemMetricsUtil.formatPercent(ToolUtilities.getDouble(ext.totalUsageRate, -1D))
                + ", MaxUsage=" + SystemMetricsUtil.formatPercent(ToolUtilities.getDouble(ext.maxUsageRate, -1D))
                + ", MaxMount=" + ToolUtilities.getString(ext.maxUsageMount, "N/A");
        if (disks == null || disks.isEmpty())
            ret.status = OpmConst.STATUS_ERROR;
        return ret;
    }

    @Override
    public List<OpmRuleResult> evaluateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception
    {
        ArrayList<OpmRuleResult> list = new ArrayList<OpmRuleResult>();
        if (collectResult == null || !(collectResult.metricExt instanceof OpmDiskMetricDo))
            return list;

        OpmDiskMetricDo ext = (OpmDiskMetricDo) collectResult.metricExt;
        double usage = ToolUtilities.getDouble(ext.totalUsageRate, -1D);
        if (usage < 0D)
            return list;

        if (usage >= _criticalRate)
            list.add(buildTotalUsageAlarm(ext, usage, _criticalRate, true));
        else if (usage >= _warnRate)
            list.add(buildTotalUsageAlarm(ext, usage, _warnRate, false));
        return list;
    }

    protected OpmRuleResult buildTotalUsageAlarm(OpmDiskMetricDo ext, double usage, double threshold, boolean criticalLevel)
    {
        OpmRuleResult rs = new OpmRuleResult();
        rs.triggered = true;
        rs.alarmLevel = criticalLevel ? TsAlarm.LEVEL_ERROR_CRITICAL : TsAlarm.LEVEL_WARN;
        rs.ruleKey = "disk.usageThreshold";
        rs.ruleLabel = "磁盘总体使用率门限";
        rs.message = (criticalLevel ? "磁盘总体使用率过高" : "磁盘总体使用率升高")
                + ": 当前=" + SystemMetricsUtil.formatPercent(usage)
                + ", 阈值=" + SystemMetricsUtil.formatPercent(threshold)
                + ", 已用=" + SystemMetricsUtil.formatBytes(ToolUtilities.getLong(ext.totalUsedBytes, 0L))
                + ", 可用=" + SystemMetricsUtil.formatBytes(ToolUtilities.getLong(ext.totalFreeBytes, 0L))
                + ", 总量=" + SystemMetricsUtil.formatBytes(ToolUtilities.getLong(ext.totalBytes, 0L))
                + "，建议=优先清理大体量无用数据，必要时扩容磁盘或迁移存储。";

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        detail.put("usageRate", Double.valueOf(usage));
        detail.put("thresholdRate", Double.valueOf(threshold));
        detail.put("totalBytes", ext.totalBytes);
        detail.put("totalUsedBytes", ext.totalUsedBytes);
        detail.put("totalFreeBytes", ext.totalFreeBytes);
        detail.put("maxUsageRate", ext.maxUsageRate);
        detail.put("maxUsageMount", ext.maxUsageMount);
        detail.put("collectorKey", getCollectorKey());
        detail.put("collectorLabel", getCollectorLabel());
        detail.put("agentCode", ext.agentCode);
        detail.put("agentName", ext.agentName);
        detail.put("myUri", ext.myUri);
        detail.put("collectTime", ext.collectTime);
        detail.put("collectDetail", ext.detailJson);
        rs.detailJson = CJson.toJson(detail);

        OpmSysAlarmExtDo alarmExt = new OpmSysAlarmExtDo();
        alarmExt.metricName = "diskTotalUsageRate";
        alarmExt.currentRate = Double.valueOf(usage);
        alarmExt.triggerLevel = criticalLevel ? "严重" : "警告";
        alarmExt.thresholdRate = Double.valueOf(threshold);
        alarmExt.warnRate = Double.valueOf(_warnRate);
        alarmExt.criticalRate = Double.valueOf(_criticalRate);
        rs.alarmExt = alarmExt;
        return rs;
    }

    protected long normalizeBytes(long v)
    {
        return v < 0L ? 0L : v;
    }

    @SuppressWarnings("unchecked")
    protected List<Map<String, Object>> parseDiskList(String detailJson)
    {
        if (ToolUtilities.isStringEmpty(detailJson))
            return null;
        try
        {
            Object obj = CJson.fromJson(detailJson);
            Object normalized = normalizeCJsonObject(obj);
            if (!(normalized instanceof Map))
                return null;

            Object disks = ((Map<String, Object>) normalized).get("disks");
            if (!(disks instanceof List))
                return null;

            ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
            for (Object one : (List<Object>) disks)
            {
                if (!(one instanceof Map))
                    continue;
                ret.add((Map<String, Object>) one);
            }
            return ret;
        }
        catch (Throwable err)
        {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    protected Object normalizeCJsonObject(Object obj)
    {
        if (obj == null)
            return null;

        if (obj instanceof Map)
        {
            Map<Object, Object> map = (Map<Object, Object>) obj;

            if (map.containsKey("#O"))
                return normalizeCJsonObject(map.get("#O"));

            if (map.containsKey("#M"))
            {
                Object items = map.get("#M");
                if (items instanceof List)
                {
                    LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
                    for (Object one : (List<Object>) items)
                    {
                        if (!(one instanceof Map))
                            continue;

                        Map<Object, Object> ent = (Map<Object, Object>) one;
                        String k = ToolUtilities.getString(ent.get("$"), null);
                        if (ToolUtilities.isStringEmpty(k))
                            continue;
                        ret.put(k, normalizeCJsonObject(ent.get("^")));
                    }
                    return ret;
                }
            }

            if (map.containsKey("#L"))
            {
                Object arr = map.get("#L");
                if (arr instanceof List)
                {
                    ArrayList<Object> ret = new ArrayList<Object>();
                    for (Object one : (List<Object>) arr)
                        ret.add(normalizeCJsonObject(one));
                    return ret;
                }
            }

            if (map.containsKey("@") || map.containsKey("@A"))
                return null;

            LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
            for (Map.Entry<Object, Object> ent : map.entrySet())
            {
                String k = String.valueOf(ent.getKey());
                if (k.startsWith("#"))
                    continue;
                ret.put(k, normalizeCJsonObject(ent.getValue()));
            }
            return ret;
        }

        if (obj instanceof List)
        {
            ArrayList<Object> ret = new ArrayList<Object>();
            for (Object one : (List<Object>) obj)
                ret.add(normalizeCJsonObject(one));
            return ret;
        }

        return obj;
    }

    @Override
    public OpmConfigGroup getConfigGroup()
    {
        OpmConfigGroup root = new OpmConfigGroup(getCollectorKey(), getCollectorLabel())
                .setDesc("采集主机磁盘分区的容量占用情况，用于观察各分区空间是否逼近上限。主要参数控制是否启用和采集频率。 ");
        List<OpmParamDef> defs = getParamDefs();
        if (defs != null)
        {
            for (OpmParamDef p : defs)
            {
                if (p != null)
                    root.addParam(p);
            }
        }
        return root;
    }
}
