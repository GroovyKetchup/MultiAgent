package cell.bap.opm.collector.focus;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.cells.BasicCell;
import bap.md.opm.focus.OpmFocusMetricDo;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmConst;
import bap.opm.OpmParamDef;
import bap.opm.OpmRuleResult;
import bap.opm.cfg.OpmConfigGroup;
import bap.opm.cfg.OpmConfigXmlBuilder;
import bap.opm.collector.focus.OpmFocusConst;
import bap.opm.collector.focus.OpmFocusMatcher;
import bap.opm.collector.focus.OpmFocusProcessGrouper;
import bap.opm.system.SystemMetrics;
import bap.opm.system.SystemMetricsCollectSpec;
import bap.opm.system.SystemMetricsUtil;
import tiny.service.md.TsAlarm;

public class COpmFocusCollector extends BasicCell implements IOpmFocusCollector
{
    protected volatile boolean _enable = OpmFocusConst.DEFAULT_ENABLE;
    protected volatile long _collectIntervalMs = OpmFocusConst.getCollectIntervalMs();
    protected volatile int _sampleMillis = 1000;
    protected volatile OpmFocusMatcher.RuleSet _focusRuleSet = new OpmFocusMatcher.RuleSet();

    protected volatile double _cpuWarnRate = OpmFocusConst.DEFAULT_CPU_WARN_RATE;
    protected volatile int _cpuWarnDurationSec = OpmFocusConst.DEFAULT_CPU_WARN_DURATION_SEC;
    protected volatile double _cpuMinorRate = OpmFocusConst.DEFAULT_CPU_MINOR_RATE;
    protected volatile int _cpuMinorDurationSec = OpmFocusConst.DEFAULT_CPU_MINOR_DURATION_SEC;
    protected volatile double _cpuMajorRate = OpmFocusConst.DEFAULT_CPU_MAJOR_RATE;
    protected volatile int _cpuMajorDurationSec = OpmFocusConst.DEFAULT_CPU_MAJOR_DURATION_SEC;
    protected volatile double _cpuCriticalRate = OpmFocusConst.DEFAULT_CPU_CRITICAL_RATE;
    protected volatile int _cpuCriticalDurationSec = OpmFocusConst.DEFAULT_CPU_CRITICAL_DURATION_SEC;

    protected volatile long _memoryWarnBytes = OpmFocusConst.DEFAULT_MEMORY_WARN_BYTES;
    protected volatile int _memoryWarnDurationSec = OpmFocusConst.DEFAULT_MEMORY_WARN_DURATION_SEC;
    protected volatile long _memoryMinorBytes = OpmFocusConst.DEFAULT_MEMORY_MINOR_BYTES;
    protected volatile int _memoryMinorDurationSec = OpmFocusConst.DEFAULT_MEMORY_MINOR_DURATION_SEC;
    protected volatile long _memoryMajorBytes = OpmFocusConst.DEFAULT_MEMORY_MAJOR_BYTES;
    protected volatile int _memoryMajorDurationSec = OpmFocusConst.DEFAULT_MEMORY_MAJOR_DURATION_SEC;
    protected volatile long _memoryCriticalBytes = OpmFocusConst.DEFAULT_MEMORY_CRITICAL_BYTES;
    protected volatile int _memoryCriticalDurationSec = OpmFocusConst.DEFAULT_MEMORY_CRITICAL_DURATION_SEC;

    protected volatile double _ioWarnRate = OpmFocusConst.DEFAULT_IO_WARN_RATE;
    protected volatile int _ioWarnDurationSec = OpmFocusConst.DEFAULT_IO_WARN_DURATION_SEC;
    protected volatile double _ioMinorRate = OpmFocusConst.DEFAULT_IO_MINOR_RATE;
    protected volatile int _ioMinorDurationSec = OpmFocusConst.DEFAULT_IO_MINOR_DURATION_SEC;
    protected volatile double _ioMajorRate = OpmFocusConst.DEFAULT_IO_MAJOR_RATE;
    protected volatile int _ioMajorDurationSec = OpmFocusConst.DEFAULT_IO_MAJOR_DURATION_SEC;
    protected volatile double _ioCriticalRate = OpmFocusConst.DEFAULT_IO_CRITICAL_RATE;
    protected volatile int _ioCriticalDurationSec = OpmFocusConst.DEFAULT_IO_CRITICAL_DURATION_SEC;

    @Override
    public String getCollectorKey()
    {
        return OpmFocusConst.COLLECTOR_KEY;
    }

    @Override
    public String getCollectorLabel()
    {
        return OpmFocusConst.COLLECTOR_LABEL;
    }

    @Override
    public List<OpmParamDef> getParamDefs()
    {
        List<OpmParamDef> defs = new LinkedList<OpmParamDef>();
        defs.add(new OpmParamDef(OpmFocusConst.CONF_ENABLE, OpmFocusConst.LABEL_ENABLE, "boolean", String.valueOf(OpmFocusConst.DEFAULT_ENABLE)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_COLLECT_INTERVAL_SEC, OpmFocusConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_COLLECT_INTERVAL_SEC)));

        defs.add(new OpmParamDef(OpmFocusConst.CONF_MATCH_PIDS, OpmFocusConst.LABEL_MATCH_PIDS, "string", OpmFocusConst.DEFAULT_MATCH_PIDS));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_MATCH_PROCESS_NAMES, OpmFocusConst.LABEL_MATCH_PROCESS_NAMES, "string", OpmFocusConst.DEFAULT_MATCH_PROCESS_NAMES));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_MATCH_PROCESS_PATHS, OpmFocusConst.LABEL_MATCH_PROCESS_PATHS, "string", OpmFocusConst.DEFAULT_MATCH_PROCESS_PATHS));

        defs.add(new OpmParamDef(OpmFocusConst.CONF_CPU_WARN_RATE, OpmFocusConst.LABEL_CPU_WARN_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_CPU_WARN_RATE)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_CPU_WARN_DURATION_SEC, OpmFocusConst.LABEL_CPU_WARN_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_CPU_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_CPU_MINOR_RATE, OpmFocusConst.LABEL_CPU_MINOR_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_CPU_MINOR_RATE)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_CPU_MINOR_DURATION_SEC, OpmFocusConst.LABEL_CPU_MINOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_CPU_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_CPU_MAJOR_RATE, OpmFocusConst.LABEL_CPU_MAJOR_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_CPU_MAJOR_RATE)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_CPU_MAJOR_DURATION_SEC, OpmFocusConst.LABEL_CPU_MAJOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_CPU_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_CPU_CRITICAL_RATE, OpmFocusConst.LABEL_CPU_CRITICAL_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_CPU_CRITICAL_RATE)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_CPU_CRITICAL_DURATION_SEC, OpmFocusConst.LABEL_CPU_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_CPU_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmFocusConst.CONF_MEMORY_WARN_BYTES, OpmFocusConst.LABEL_MEMORY_WARN_BYTES, "string", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_WARN_BYTES)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_MEMORY_WARN_DURATION_SEC, OpmFocusConst.LABEL_MEMORY_WARN_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_MEMORY_MINOR_BYTES, OpmFocusConst.LABEL_MEMORY_MINOR_BYTES, "string", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_MINOR_BYTES)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_MEMORY_MINOR_DURATION_SEC, OpmFocusConst.LABEL_MEMORY_MINOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_MEMORY_MAJOR_BYTES, OpmFocusConst.LABEL_MEMORY_MAJOR_BYTES, "string", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_MAJOR_BYTES)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_MEMORY_MAJOR_DURATION_SEC, OpmFocusConst.LABEL_MEMORY_MAJOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_MEMORY_CRITICAL_BYTES, OpmFocusConst.LABEL_MEMORY_CRITICAL_BYTES, "string", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_CRITICAL_BYTES)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_MEMORY_CRITICAL_DURATION_SEC, OpmFocusConst.LABEL_MEMORY_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_MEMORY_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmFocusConst.CONF_IO_WARN_RATE, OpmFocusConst.LABEL_IO_WARN_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_IO_WARN_RATE)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_IO_WARN_DURATION_SEC, OpmFocusConst.LABEL_IO_WARN_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_IO_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_IO_MINOR_RATE, OpmFocusConst.LABEL_IO_MINOR_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_IO_MINOR_RATE)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_IO_MINOR_DURATION_SEC, OpmFocusConst.LABEL_IO_MINOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_IO_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_IO_MAJOR_RATE, OpmFocusConst.LABEL_IO_MAJOR_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_IO_MAJOR_RATE)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_IO_MAJOR_DURATION_SEC, OpmFocusConst.LABEL_IO_MAJOR_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_IO_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_IO_CRITICAL_RATE, OpmFocusConst.LABEL_IO_CRITICAL_RATE, "string", String.valueOf(OpmFocusConst.DEFAULT_IO_CRITICAL_RATE)));
        defs.add(new OpmParamDef(OpmFocusConst.CONF_IO_CRITICAL_DURATION_SEC, OpmFocusConst.LABEL_IO_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_IO_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmFocusConst.CONF_RULE_COOLDOWN_SEC, OpmFocusConst.LABEL_RULE_COOLDOWN_SEC, "int", String.valueOf(OpmFocusConst.DEFAULT_RULE_COOLDOWN_SEC)));
        return defs;
    }

    @Override
    public String getSampleConfigComment()
    {
        return OpmConfigXmlBuilder.buildModuleSample("focus", "重点进程监控", "cell.bap.opm.collector.focus.IOpmFocusCollector", getConfigGroup());
    }

    @Override
    public long getCollectIntervalMs()
    {
        return _collectIntervalMs;
    }

    @Override
    public List<Class> getModelClasses()
    {
        List<Class> list = new ArrayList<Class>();
        list.add(OpmFocusMetricDo.class);
        return list;
    }

    @Override
    public void loadConfig()
    {
        _enable = OpmFocusConst.isEnable();
        _collectIntervalMs = OpmFocusConst.getCollectIntervalMs();
        _focusRuleSet = OpmFocusMatcher.loadRuleSet();

        _cpuWarnRate = OpmFocusConst.getCpuWarnRate();
        _cpuWarnDurationSec = OpmFocusConst.getCpuWarnDurationSec();
        _cpuMinorRate = OpmFocusConst.getCpuMinorRate();
        _cpuMinorDurationSec = OpmFocusConst.getCpuMinorDurationSec();
        _cpuMajorRate = OpmFocusConst.getCpuMajorRate();
        _cpuMajorDurationSec = OpmFocusConst.getCpuMajorDurationSec();
        _cpuCriticalRate = OpmFocusConst.getCpuCriticalRate();
        _cpuCriticalDurationSec = OpmFocusConst.getCpuCriticalDurationSec();

        _memoryWarnBytes = OpmFocusConst.getMemoryWarnBytes();
        _memoryWarnDurationSec = OpmFocusConst.getMemoryWarnDurationSec();
        _memoryMinorBytes = OpmFocusConst.getMemoryMinorBytes();
        _memoryMinorDurationSec = OpmFocusConst.getMemoryMinorDurationSec();
        _memoryMajorBytes = OpmFocusConst.getMemoryMajorBytes();
        _memoryMajorDurationSec = OpmFocusConst.getMemoryMajorDurationSec();
        _memoryCriticalBytes = OpmFocusConst.getMemoryCriticalBytes();
        _memoryCriticalDurationSec = OpmFocusConst.getMemoryCriticalDurationSec();

        _ioWarnRate = OpmFocusConst.getIoWarnRateBytesPerSec();
        _ioWarnDurationSec = OpmFocusConst.getIoWarnDurationSec();
        _ioMinorRate = OpmFocusConst.getIoMinorRateBytesPerSec();
        _ioMinorDurationSec = OpmFocusConst.getIoMinorDurationSec();
        _ioMajorRate = OpmFocusConst.getIoMajorRateBytesPerSec();
        _ioMajorDurationSec = OpmFocusConst.getIoMajorDurationSec();
        _ioCriticalRate = OpmFocusConst.getIoCriticalRateBytesPerSec();
        _ioCriticalDurationSec = OpmFocusConst.getIoCriticalDurationSec();
    }

    @Override
    public OpmCollectResult collect(OpmAgentContext agentCtx) throws Exception
    {
        long begin = System.nanoTime();
        if (!_enable)
            return null;

        long now = System.currentTimeMillis();
        SystemMetrics metrics = SystemMetricsUtil.collect(_sampleMillis, SystemMetricsCollectSpec.all());

        OpmFocusMetricDo ext = new OpmFocusMetricDo();
        ext.collectorKey = getCollectorKey();
        ext.collectorLabel = getCollectorLabel();
        ext.agentCode = agentCtx == null ? null : agentCtx.getAgentCode();
        ext.agentName = agentCtx == null ? null : agentCtx.getAgentName();
        ext.myUri = agentCtx == null ? null : agentCtx.getMyUri();
        ext.collectTime = now;
        ext.hostName = metrics == null ? null : metrics.hostName;
        ext.osName = metrics == null ? null : metrics.osName;
        ext.provider = metrics == null ? null : metrics.provider;

        List<OpmFocusProcessGrouper.ProcessGroup> focusCpuGroups = OpmFocusProcessGrouper.groupCpuProcesses(
                metrics == null ? null : metrics.cpuProcesses, _focusRuleSet);
        List<OpmFocusProcessGrouper.ProcessGroup> focusMemoryGroups = OpmFocusProcessGrouper.groupMemoryProcesses(
                metrics == null ? null : metrics.memoryProcesses, _focusRuleSet);
        List<OpmFocusProcessGrouper.ProcessGroup> focusIoGroups = OpmFocusProcessGrouper.groupIoProcesses(
                metrics == null || metrics.io == null ? null : metrics.io.processes, _focusRuleSet);

        List<Map<String, Object>> focusCpu = OpmFocusProcessGrouper.toGroupMapList(focusCpuGroups);
        List<Map<String, Object>> focusMemory = OpmFocusProcessGrouper.toGroupMapList(focusMemoryGroups);
        List<Map<String, Object>> focusIo = OpmFocusProcessGrouper.toGroupMapList(focusIoGroups);

        ext.focusProcessCount = Integer.valueOf(focusCpuGroups.size());

        OpmFocusProcessGrouper.ProcessGroup topCpuGroup = OpmFocusProcessGrouper.findTopCpuGroup(focusCpuGroups);
        if (topCpuGroup != null)
        {
            ext.topCpuProcessName = topCpuGroup.groupName;
            ext.topCpuProcessRate = topCpuGroup.cpuRate;
        }

        OpmFocusProcessGrouper.ProcessGroup topMemoryGroup = OpmFocusProcessGrouper.findTopMemoryGroup(focusMemoryGroups);
        if (topMemoryGroup != null)
        {
            ext.topMemoryProcessName = topMemoryGroup.groupName;
            ext.topMemoryProcessBytes = topMemoryGroup.memoryBytes;
        }

        OpmFocusProcessGrouper.ProcessGroup topIoGroup = OpmFocusProcessGrouper.findTopIoGroup(focusIoGroups);
        if (topIoGroup != null)
        {
            ext.topIoProcessName = topIoGroup.groupName;
            ext.topIoProcessRate = topIoGroup.ioRateBytesPerSec;
        }

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        detail.put("focusCpuGroups", focusCpu);
        detail.put("focusMemoryGroups", focusMemory);
        detail.put("focusIoGroups", focusIo);
        detail.put("focusCpuProcesses", focusCpu);
        detail.put("focusMemoryProcesses", focusMemory);
        detail.put("focusIoProcesses", focusIo);
        detail.put("focusPidFilter", OpmFocusMatcher.toPidStringList(_focusRuleSet.pidSet));
        detail.put("focusProcessNameFilter", new ArrayList<String>(_focusRuleSet.nameSet));
        detail.put("focusProcessPathFilter", new ArrayList<String>(_focusRuleSet.pathSet));
        ext.detailJson = CJson.toJson(detail);

        OpmCollectResult ret = new OpmCollectResult();
        ret.collectorKey = getCollectorKey();
        ret.collectorLabel = getCollectorLabel();
        ret.collectTime = now;
        ret.collectCostMs = (System.nanoTime() - begin) / 1000000L;
        ret.metricExt = ext;
        ret.summary = buildSummary(ext);
        ret.status = OpmConst.STATUS_NORMAL;
        return ret;
    }

    protected String buildSummary(OpmFocusMetricDo ext)
    {
        return "FocusCount=" + ext.focusProcessCount
                + ", TopCpu=" + ToolUtilities.getString(ext.topCpuProcessName, "N/A")
                + ", TopMem=" + ToolUtilities.getString(ext.topMemoryProcessName, "N/A")
                + ", TopIO=" + ToolUtilities.getString(ext.topIoProcessName, "N/A");
    }

    @Override
    public List<OpmRuleResult> evaluateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception
    {
        List<OpmRuleResult> list = new LinkedList<OpmRuleResult>();
        if (collectResult == null || !(collectResult.metricExt instanceof OpmFocusMetricDo))
            return list;

        OpmFocusMetricDo ext = (OpmFocusMetricDo) collectResult.metricExt;
        long now = System.currentTimeMillis();

        list.addAll(OpmFocusAlarmEvaluator.evalCpuAlarms(ext, agentCtx, now, _focusRuleSet,
                _cpuWarnRate, _cpuWarnDurationSec,
                _cpuMinorRate, _cpuMinorDurationSec,
                _cpuMajorRate, _cpuMajorDurationSec,
                _cpuCriticalRate, _cpuCriticalDurationSec));

        list.addAll(OpmFocusAlarmEvaluator.evalMemoryAlarms(ext, agentCtx, now, _focusRuleSet,
                _memoryWarnBytes, _memoryWarnDurationSec,
                _memoryMinorBytes, _memoryMinorDurationSec,
                _memoryMajorBytes, _memoryMajorDurationSec,
                _memoryCriticalBytes, _memoryCriticalDurationSec));

        list.addAll(OpmFocusAlarmEvaluator.evalIoAlarms(ext, agentCtx, now, _focusRuleSet,
                _ioWarnRate, _ioWarnDurationSec,
                _ioMinorRate, _ioMinorDurationSec,
                _ioMajorRate, _ioMajorDurationSec,
                _ioCriticalRate, _ioCriticalDurationSec));

        return list;
    }

    @Override
    public OpmConfigGroup getConfigGroup()
    {
        OpmConfigGroup root = new OpmConfigGroup(getCollectorKey(), getCollectorLabel())
                .setDesc("监控重点进程的CPU、内存、IO使用情况，统一周期采集，支持四级告警门限。");
        List<OpmParamDef> defs = getParamDefs();
        if (defs != null)
        {
            for (OpmParamDef p : defs)
            {
                if (p != null)
                    root.addParam(p);
            }
        }
        return root;
    }
}
