package cell.bap.opm.collector.focus;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.nutz.dao.Cnd;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.md.opm.focus.OpmFocusMetricDo;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmRuleResult;
import bap.opm.collector.focus.OpmFocusMatcher;
import bap.opm.collector.focus.OpmFocusProcessGrouper;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.system.SystemMetricsUtil;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.md.TsAlarm;

public class OpmFocusAlarmEvaluator
{
    public static List<OpmRuleResult> evalCpuAlarms(OpmFocusMetricDo ext, OpmAgentContext agentCtx, long now,
            OpmFocusMatcher.RuleSet ruleSet,
            double warnRate, int warnDurationSec,
            double minorRate, int minorDurationSec,
            double majorRate, int majorDurationSec,
            double criticalRate, int criticalDurationSec)
    {
        List<OpmRuleResult> results = new LinkedList<OpmRuleResult>();
        if (ruleSet == null || ruleSet.isEmpty())
            return results;

        List<Map<String, Object>> focus = parseListFromDetail(ext.detailJson, "focusCpuGroups", "focusCpuProcesses");
        if (focus == null || focus.isEmpty())
            return results;

        AlarmLevel[] levels = new AlarmLevel[] {
                new AlarmLevel(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", criticalRate, criticalDurationSec),
                new AlarmLevel(TsAlarm.LEVEL_ERROR_MAJOR, "主要", majorRate, majorDurationSec),
                new AlarmLevel(TsAlarm.LEVEL_ERROR_MINOR, "次要", minorRate, minorDurationSec),
                new AlarmLevel(TsAlarm.LEVEL_WARN, "警告", warnRate, warnDurationSec)
        };

        for (Map<String, Object> proc : focus)
        {
            double cpuRate = ToolUtilities.getDouble(proc.get("cpuRate"), -1D);
            if (cpuRate < 0D)
                continue;

            for (AlarmLevel level : levels)
            {
                if (cpuRate < level.threshold)
                    continue;

                String processName = ToolUtilities.getString(proc.get("groupName"), ToolUtilities.getString(proc.get("processName"), "unknown"));
                int pid = ToolUtilities.getInteger(proc.get("pid"), -1);
                boolean isAggregate = ToolUtilities.getBoolean(proc.get("aggregate"), false);
                String aggregateKey = ToolUtilities.getString(proc.get("aggregateKey"), null);

                String ruleKey = OpmAlarmConfigKeys.buildFocusCpuRuleKey(isAggregate,
                        normalizeRuleKey(isAggregate && aggregateKey != null ? aggregateKey : processName), pid);

                OpmRuleResult rs = new OpmRuleResult();
                rs.triggered = true;
                rs.alarmLevel = level.level;
                rs.ruleKey = ruleKey;
                rs.configParamKey = resolveFocusCpuConfigParamKey(level.level);
                rs.ruleLabel = isAggregate ? "重点进程组CPU持续过高" : "重点进程CPU持续过高";
                rs.message = (isAggregate ? "重点进程组CPU持续过高" : "重点进程CPU持续过高") + ": 进程=" + processName
                        + ", PID=" + pid
                        + ", 当前=" + SystemMetricsUtil.formatPercent(cpuRate)
                        + ", 级别=" + level.levelName
                        + ", 阈值=" + SystemMetricsUtil.formatPercent(level.threshold)
                        + ", 持续" + level.durationSec + "秒"
                        + "，建议=检查该进程线程栈、热点调用与任务堆积。";

                LinkedHashMap<String, Object> detail = new LinkedHashMap<String, Object>();
                detail.put("focusProcessName", processName);
                detail.put("focusPid", Integer.valueOf(pid));
                detail.put("focusCpuRate", Double.valueOf(cpuRate));
                detail.put("triggerLevel", level.levelName);
                detail.put("thresholdRate", Double.valueOf(level.threshold));
                detail.put("durationSec", Integer.valueOf(level.durationSec));
                detail.put("aggregate", Boolean.valueOf(isAggregate));
                if (isAggregate)
                {
                    detail.put("aggregateCount", proc.get("aggregateCount"));
                    detail.put("aggregateKey", aggregateKey);
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> aggProcs = (List<Map<String, Object>>) pickFirst(proc, "aggregateProcesses", "groupProcesses");
                    if (aggProcs != null)
                        detail.put("aggregateProcesses", aggProcs);
                }
                else
                {
                    List<Map<String, Object>> singleProc = new ArrayList<Map<String, Object>>();
                    Object groupProcesses = proc.get("groupProcesses");
                    if (groupProcesses instanceof List)
                        singleProc.addAll(castMapList(groupProcesses));
                    else
                        singleProc.add(proc);
                    detail.put("focusProcesses", singleProc);
                }
                rs.detailJson = CJson.toJson(detail);

                OpmSysAlarmExtDo alarmExt = new OpmSysAlarmExtDo();
                alarmExt.metricName = "focusProcCpuRate";
                alarmExt.currentRate = Double.valueOf(cpuRate);
                alarmExt.triggerLevel = level.levelName;
                alarmExt.thresholdRate = Double.valueOf(level.threshold);
                alarmExt.durationSec = Integer.valueOf(level.durationSec);
                rs.alarmExt = alarmExt;
                results.add(rs);
                break;
            }
        }

        return results;
    }

    public static List<OpmRuleResult> evalMemoryAlarms(OpmFocusMetricDo ext, OpmAgentContext agentCtx, long now,
            OpmFocusMatcher.RuleSet ruleSet,
            long warnBytes, int warnDurationSec,
            long minorBytes, int minorDurationSec,
            long majorBytes, int majorDurationSec,
            long criticalBytes, int criticalDurationSec)
    {
        List<OpmRuleResult> results = new LinkedList<OpmRuleResult>();
        if (ruleSet == null || ruleSet.isEmpty())
            return results;

        List<Map<String, Object>> focus = parseListFromDetail(ext.detailJson, "focusMemoryGroups", "focusMemoryProcesses");
        if (focus == null || focus.isEmpty())
            return results;

        AlarmLevel[] levels = new AlarmLevel[] {
                new AlarmLevel(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", criticalBytes, criticalDurationSec),
                new AlarmLevel(TsAlarm.LEVEL_ERROR_MAJOR, "主要", majorBytes, majorDurationSec),
                new AlarmLevel(TsAlarm.LEVEL_ERROR_MINOR, "次要", minorBytes, minorDurationSec),
                new AlarmLevel(TsAlarm.LEVEL_WARN, "警告", warnBytes, warnDurationSec)
        };

        for (Map<String, Object> proc : focus)
        {
            long memoryBytes = ToolUtilities.getLong(proc.get("memoryBytes"), 0L);
            if (memoryBytes <= 0L)
                continue;

            for (AlarmLevel level : levels)
            {
                if (memoryBytes < level.thresholdBytes)
                    continue;

                String processName = ToolUtilities.getString(proc.get("groupName"), ToolUtilities.getString(proc.get("processName"), "unknown"));
                int pid = ToolUtilities.getInteger(proc.get("pid"), -1);
                boolean isAggregate = ToolUtilities.getBoolean(proc.get("aggregate"), false);
                String aggregateKey = ToolUtilities.getString(proc.get("aggregateKey"), null);

                String ruleKey = OpmAlarmConfigKeys.buildFocusMemoryRuleKey(isAggregate,
                        normalizeRuleKey(isAggregate && aggregateKey != null ? aggregateKey : processName), pid);

                OpmRuleResult rs = new OpmRuleResult();
                rs.triggered = true;
                rs.alarmLevel = level.level;
                rs.ruleKey = ruleKey;
                rs.configParamKey = resolveFocusMemoryConfigParamKey(level.level);
                rs.ruleLabel = isAggregate ? "重点进程组内存持续过高" : "重点进程内存持续过高";
                rs.message = (isAggregate ? "重点进程组内存持续过高" : "重点进程内存持续过高") + ": 进程=" + processName
                        + ", PID=" + pid
                        + ", 当前=" + SystemMetricsUtil.formatBytes(memoryBytes)
                        + ", 级别=" + level.levelName
                        + ", 阈值=" + SystemMetricsUtil.formatBytes(level.thresholdBytes)
                        + ", 持续" + level.durationSec + "秒"
                        + "，建议=检查该进程堆外/堆内占用、缓存膨胀、对象泄漏或进程参数配置。";

                LinkedHashMap<String, Object> detail = new LinkedHashMap<String, Object>();
                detail.put("focusProcessName", processName);
                detail.put("focusPid", Integer.valueOf(pid));
                detail.put("focusMemoryBytes", Long.valueOf(memoryBytes));
                detail.put("triggerLevel", level.levelName);
                detail.put("thresholdBytes", Long.valueOf(level.thresholdBytes));
                detail.put("durationSec", Integer.valueOf(level.durationSec));
                detail.put("aggregate", Boolean.valueOf(isAggregate));
                if (isAggregate)
                {
                    detail.put("aggregateCount", proc.get("aggregateCount"));
                    detail.put("aggregateKey", aggregateKey);
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> aggProcs = (List<Map<String, Object>>) pickFirst(proc, "aggregateProcesses", "groupProcesses");
                    if (aggProcs != null)
                        detail.put("aggregateProcesses", aggProcs);
                }
                else
                {
                    List<Map<String, Object>> singleProc = new ArrayList<Map<String, Object>>();
                    Object groupProcesses = proc.get("groupProcesses");
                    if (groupProcesses instanceof List)
                        singleProc.addAll(castMapList(groupProcesses));
                    else
                        singleProc.add(proc);
                    detail.put("focusProcesses", singleProc);
                }
                rs.detailJson = CJson.toJson(detail);

                OpmSysAlarmExtDo alarmExt = new OpmSysAlarmExtDo();
                alarmExt.metricName = "focusProcMemoryBytes";
                alarmExt.currentRate = Double.valueOf(memoryBytes);
                alarmExt.triggerLevel = level.levelName;
                alarmExt.thresholdRate = Double.valueOf(level.thresholdBytes);
                alarmExt.durationSec = Integer.valueOf(level.durationSec);
                rs.alarmExt = alarmExt;
                results.add(rs);
                break;
            }
        }

        return results;
    }

    public static List<OpmRuleResult> evalIoAlarms(OpmFocusMetricDo ext, OpmAgentContext agentCtx, long now,
            OpmFocusMatcher.RuleSet ruleSet,
            double warnRate, int warnDurationSec,
            double minorRate, int minorDurationSec,
            double majorRate, int majorDurationSec,
            double criticalRate, int criticalDurationSec)
    {
        List<OpmRuleResult> results = new LinkedList<OpmRuleResult>();
        if (ruleSet == null || ruleSet.isEmpty())
            return results;

        List<Map<String, Object>> focus = parseListFromDetail(ext.detailJson, "focusIoGroups", "focusIoProcesses");
        if (focus == null || focus.isEmpty())
            return results;

        AlarmLevel[] levels = new AlarmLevel[] {
                new AlarmLevel(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", criticalRate, criticalDurationSec),
                new AlarmLevel(TsAlarm.LEVEL_ERROR_MAJOR, "主要", majorRate, majorDurationSec),
                new AlarmLevel(TsAlarm.LEVEL_ERROR_MINOR, "次要", minorRate, minorDurationSec),
                new AlarmLevel(TsAlarm.LEVEL_WARN, "警告", warnRate, warnDurationSec)
        };

        for (Map<String, Object> proc : focus)
        {
            double ioRate = ToolUtilities.getDouble(proc.get("ioRateBytesPerSec"), -1D);
            if (ioRate < 0D)
                continue;

            for (AlarmLevel level : levels)
            {
                if (ioRate < level.threshold)
                    continue;

                String processName = ToolUtilities.getString(proc.get("groupName"), ToolUtilities.getString(proc.get("processName"), "unknown"));
                int pid = ToolUtilities.getInteger(proc.get("pid"), -1);
                boolean isAggregate = ToolUtilities.getBoolean(proc.get("aggregate"), false);
                String aggregateKey = ToolUtilities.getString(proc.get("aggregateKey"), null);

                String ruleKey = OpmAlarmConfigKeys.buildFocusIoRuleKey(isAggregate,
                        normalizeRuleKey(isAggregate && aggregateKey != null ? aggregateKey : processName), pid);

                OpmRuleResult rs = new OpmRuleResult();
                rs.triggered = true;
                rs.alarmLevel = level.level;
                rs.ruleKey = ruleKey;
                rs.configParamKey = resolveFocusIoConfigParamKey(level.level);
                rs.ruleLabel = isAggregate ? "重点进程组IO持续过高" : "重点进程IO持续过高";
                rs.message = (isAggregate ? "重点进程组IO持续过高" : "重点进程IO持续过高") + ": 进程=" + processName
                        + ", PID=" + pid
                        + ", 当前=" + SystemMetricsUtil.formatRate(ioRate)
                        + ", 级别=" + level.levelName
                        + ", 阈值=" + SystemMetricsUtil.formatRate(level.threshold)
                        + ", 持续" + level.durationSec + "秒"
                        + "，建议=检查该进程磁盘读写热点、批处理任务、日志输出或数据库文件访问。";

                LinkedHashMap<String, Object> detail = new LinkedHashMap<String, Object>();
                detail.put("focusProcessName", processName);
                detail.put("focusPid", Integer.valueOf(pid));
                detail.put("focusIoRateBytesPerSec", Double.valueOf(ioRate));
                detail.put("triggerLevel", level.levelName);
                detail.put("thresholdRate", Double.valueOf(level.threshold));
                detail.put("durationSec", Integer.valueOf(level.durationSec));
                detail.put("aggregate", Boolean.valueOf(isAggregate));
                if (isAggregate)
                {
                    detail.put("aggregateCount", proc.get("aggregateCount"));
                    detail.put("aggregateKey", aggregateKey);
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> aggProcs = (List<Map<String, Object>>) pickFirst(proc, "aggregateProcesses", "groupProcesses");
                    if (aggProcs != null)
                        detail.put("aggregateProcesses", aggProcs);
                }
                else
                {
                    List<Map<String, Object>> singleProc = new ArrayList<Map<String, Object>>();
                    Object groupProcesses = proc.get("groupProcesses");
                    if (groupProcesses instanceof List)
                        singleProc.addAll(castMapList(groupProcesses));
                    else
                        singleProc.add(proc);
                    detail.put("focusProcesses", singleProc);
                }
                rs.detailJson = CJson.toJson(detail);

                OpmSysAlarmExtDo alarmExt = new OpmSysAlarmExtDo();
                alarmExt.metricName = "focusProcIoRateBytesPerSec";
                alarmExt.currentRate = Double.valueOf(ioRate);
                alarmExt.triggerLevel = level.levelName;
                alarmExt.thresholdRate = Double.valueOf(level.threshold);
                alarmExt.durationSec = Integer.valueOf(level.durationSec);
                rs.alarmExt = alarmExt;
                results.add(rs);
                break;
            }
        }

        return results;
    }

    @SuppressWarnings("unchecked")
    protected static List<Map<String, Object>> parseListFromDetail(String detailJson, String primaryKey, String fallbackKey)
    {
        List<Map<String, Object>> list = OpmFocusProcessGrouper.parseGroupMapList(detailJson, primaryKey);
        if (list != null)
            return list;
        return OpmFocusProcessGrouper.parseGroupMapList(detailJson, fallbackKey);
    }

    @SuppressWarnings("unchecked")
    protected static List<Map<String, Object>> castMapList(Object value)
    {
        if (value instanceof List)
            return (List<Map<String, Object>>) value;
        return null;
    }

    protected static Object pickFirst(Map<String, Object> map, String... keys)
    {
        if (map == null || keys == null)
            return null;
        for (String key : keys)
        {
            if (map.containsKey(key))
                return map.get(key);
        }
        return null;
    }

    protected static Map<String, Object> findTopCpuProcess(List<Map<String, Object>> focus)
    {
        if (focus == null || focus.isEmpty())
            return null;
        Map<String, Object> best = null;
        double bestRate = -1D;
        for (Map<String, Object> one : focus)
        {
            double rate = ToolUtilities.getDouble(one.get("cpuRate"), -1D);
            if (rate > bestRate)
            {
                bestRate = rate;
                best = one;
            }
        }
        return best;
    }

    protected static Map<String, Object> findTopMemoryProcess(List<Map<String, Object>> focus)
    {
        if (focus == null || focus.isEmpty())
            return null;
        Map<String, Object> best = null;
        long bestBytes = 0L;
        for (Map<String, Object> one : focus)
        {
            long bytes = ToolUtilities.getLong(one.get("memoryBytes"), 0L);
            if (bytes > bestBytes)
            {
                bestBytes = bytes;
                best = one;
            }
        }
        return best;
    }

    protected static Map<String, Object> findTopIoProcess(List<Map<String, Object>> focus)
    {
        if (focus == null || focus.isEmpty())
            return null;
        Map<String, Object> best = null;
        double bestRate = -1D;
        for (Map<String, Object> one : focus)
        {
            double rate = ToolUtilities.getDouble(one.get("ioRateBytesPerSec"), -1D);
            if (rate > bestRate)
            {
                bestRate = rate;
                best = one;
            }
        }
        return best;
    }

    protected static String normalizeRuleKey(String text)
    {
        String name = OpmFocusMatcher.normalizeName(text);
        if (ToolUtilities.isStringEmpty(name, true))
            return "unknown";
        return name.replaceAll("[^a-z0-9_-]+", "_");
    }

    protected static String resolveFocusCpuConfigParamKey(int alarmLevel)
    {
        if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
            return bap.opm.collector.focus.OpmFocusConst.CONF_CPU_CRITICAL_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
            return bap.opm.collector.focus.OpmFocusConst.CONF_CPU_MAJOR_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
            return bap.opm.collector.focus.OpmFocusConst.CONF_CPU_MINOR_RATE;
        return bap.opm.collector.focus.OpmFocusConst.CONF_CPU_WARN_RATE;
    }

    protected static String resolveFocusMemoryConfigParamKey(int alarmLevel)
    {
        if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
            return bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_CRITICAL_BYTES;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
            return bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_MAJOR_BYTES;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
            return bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_MINOR_BYTES;
        return bap.opm.collector.focus.OpmFocusConst.CONF_MEMORY_WARN_BYTES;
    }

    protected static String resolveFocusIoConfigParamKey(int alarmLevel)
    {
        if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
            return bap.opm.collector.focus.OpmFocusConst.CONF_IO_CRITICAL_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
            return bap.opm.collector.focus.OpmFocusConst.CONF_IO_MAJOR_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
            return bap.opm.collector.focus.OpmFocusConst.CONF_IO_MINOR_RATE;
        return bap.opm.collector.focus.OpmFocusConst.CONF_IO_WARN_RATE;
    }

    protected static class AlarmLevel
    {
        int level;
        String levelName;
        double threshold;
        long thresholdBytes;
        int durationSec;

        AlarmLevel(int level, String levelName, double threshold, int durationSec)
        {
            this.level = level;
            this.levelName = levelName;
            this.threshold = threshold;
            this.thresholdBytes = (long) threshold;
            this.durationSec = durationSec;
        }

        AlarmLevel(int level, String levelName, long thresholdBytes, int durationSec)
        {
            this.level = level;
            this.levelName = levelName;
            this.threshold = thresholdBytes;
            this.thresholdBytes = thresholdBytes;
            this.durationSec = durationSec;
        }
    }

    private OpmFocusAlarmEvaluator()
    {
    }
}
