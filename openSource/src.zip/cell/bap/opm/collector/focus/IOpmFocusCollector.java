package cell.bap.opm.collector.focus;

import cell.bap.opm.collector.IOpmCollector;

public interface IOpmFocusCollector extends IOpmCollector
{
}