package cell.bap.opm.collector.topcpu;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.nutz.dao.Cnd;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.cells.BasicCell;
import bap.md.opm.cpu.OpmCpuMetricDo;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmConst;
import bap.opm.OpmParamDef;
import bap.opm.OpmRuleResult;
import bap.opm.cfg.OpmConfigGroup;
import bap.opm.cfg.OpmConfigXmlBuilder;
import bap.opm.collector.topcpu.OpmTopCpuConst;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.system.SystemMetrics;
import bap.opm.system.SystemMetricsCollectSpec;
import bap.opm.system.SystemMetricsUtil;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.md.TsAlarm;

/**
 * TOP 进程 CPU 采集器。
 */
public class COpmTopCpuCollector extends BasicCell implements IOpmTopCpuCollector
{
    protected volatile boolean _enable = OpmTopCpuConst.DEFAULT_ENABLE;
    protected volatile long _collectIntervalMs = OpmTopCpuConst.getCollectIntervalMs();
    protected volatile int _sampleMillis = OpmTopCpuConst.DEFAULT_CPU_SAMPLE_MILLIS;
    protected volatile int _topProcSize = OpmTopCpuConst.DEFAULT_TOP_PROC_SIZE;

    protected volatile double _warnRate = OpmTopCpuConst.DEFAULT_WARN_RATE;
    protected volatile int _warnDurationSec = OpmTopCpuConst.DEFAULT_WARN_DURATION_SEC;
    protected volatile double _minorRate = OpmTopCpuConst.DEFAULT_MINOR_RATE;
    protected volatile int _minorDurationSec = OpmTopCpuConst.DEFAULT_MINOR_DURATION_SEC;
    protected volatile double _majorRate = OpmTopCpuConst.DEFAULT_MAJOR_RATE;
    protected volatile int _majorDurationSec = OpmTopCpuConst.DEFAULT_MAJOR_DURATION_SEC;
    protected volatile double _criticalRate = OpmTopCpuConst.DEFAULT_CRITICAL_RATE;
    protected volatile int _criticalDurationSec = OpmTopCpuConst.DEFAULT_CRITICAL_DURATION_SEC;

    protected volatile List<SystemMetrics.ProcessCpuUsage> _lastTopProc = new ArrayList<SystemMetrics.ProcessCpuUsage>();

    @Override
    public String getCollectorKey()
    {
        return OpmTopCpuConst.COLLECTOR_KEY;
    }

    @Override
    public String getCollectorLabel()
    {
        return OpmTopCpuConst.COLLECTOR_LABEL;
    }

    @Override
    public List<OpmParamDef> getParamDefs()
    {
        ArrayList<OpmParamDef> list = new ArrayList<OpmParamDef>();
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_ENABLE, OpmTopCpuConst.LABEL_ENABLE, "boolean", String.valueOf(OpmTopCpuConst.DEFAULT_ENABLE)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_COLLECT_INTERVAL_SEC, OpmTopCpuConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmTopCpuConst.DEFAULT_COLLECT_INTERVAL_SEC)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_CPU_SAMPLE_MILLIS, OpmTopCpuConst.LABEL_CPU_SAMPLE_MILLIS, "int", String.valueOf(OpmTopCpuConst.DEFAULT_CPU_SAMPLE_MILLIS)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_TOP_PROC_SIZE, OpmTopCpuConst.LABEL_TOP_PROC_SIZE, "int", String.valueOf(OpmTopCpuConst.DEFAULT_TOP_PROC_SIZE)));

        list.add(new OpmParamDef(OpmTopCpuConst.CONF_WARN_RATE, OpmTopCpuConst.LABEL_WARN_RATE, "string", String.valueOf(OpmTopCpuConst.DEFAULT_WARN_RATE)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_WARN_DURATION_SEC, OpmTopCpuConst.LABEL_WARN_DURATION_SEC, "int", String.valueOf(OpmTopCpuConst.DEFAULT_WARN_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_MINOR_RATE, OpmTopCpuConst.LABEL_MINOR_RATE, "string", String.valueOf(OpmTopCpuConst.DEFAULT_MINOR_RATE)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_MINOR_DURATION_SEC, OpmTopCpuConst.LABEL_MINOR_DURATION_SEC, "int", String.valueOf(OpmTopCpuConst.DEFAULT_MINOR_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_MAJOR_RATE, OpmTopCpuConst.LABEL_MAJOR_RATE, "string", String.valueOf(OpmTopCpuConst.DEFAULT_MAJOR_RATE)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_MAJOR_DURATION_SEC, OpmTopCpuConst.LABEL_MAJOR_DURATION_SEC, "int", String.valueOf(OpmTopCpuConst.DEFAULT_MAJOR_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_CRITICAL_RATE, OpmTopCpuConst.LABEL_CRITICAL_RATE, "string", String.valueOf(OpmTopCpuConst.DEFAULT_CRITICAL_RATE)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_CRITICAL_DURATION_SEC, OpmTopCpuConst.LABEL_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmTopCpuConst.DEFAULT_CRITICAL_DURATION_SEC)));
        list.add(new OpmParamDef(OpmTopCpuConst.CONF_RULE_COOLDOWN_SEC, OpmTopCpuConst.LABEL_RULE_COOLDOWN_SEC, "int", String.valueOf(OpmTopCpuConst.DEFAULT_RULE_COOLDOWN_SEC)));

        return list;
    }

    @Override
    public String getSampleConfigComment()
    {
        return OpmConfigXmlBuilder.buildModuleSample("topCpu", "CPU监控", "cell.bap.opm.collector.topcpu.IOpmTopCpuCollector", getConfigGroup());
    }

    @Override
    public long getCollectIntervalMs()
    {
        return _collectIntervalMs;
    }

    @Override
    public List<Class> getModelClasses()
    {
        List<Class> list = new ArrayList<Class>();
        list.add(OpmCpuMetricDo.class);
        list.add(OpmSysAlarmExtDo.class);
        return list;
    }

    @Override
    public void loadConfig()
    {
        _enable = OpmTopCpuConst.isEnable();
        _collectIntervalMs = OpmTopCpuConst.getCollectIntervalMs();
        _sampleMillis = OpmTopCpuConst.getCpuSampleMillis();
        _topProcSize = OpmTopCpuConst.getTopProcSize();

        _warnRate = OpmTopCpuConst.getWarnRate();
        _warnDurationSec = OpmTopCpuConst.getWarnDurationSec();
        _minorRate = OpmTopCpuConst.getMinorRate();
        _minorDurationSec = OpmTopCpuConst.getMinorDurationSec();
        _majorRate = OpmTopCpuConst.getMajorRate();
        _majorDurationSec = OpmTopCpuConst.getMajorDurationSec();
        _criticalRate = OpmTopCpuConst.getCriticalRate();
        _criticalDurationSec = OpmTopCpuConst.getCriticalDurationSec();

        if (_collectIntervalMs <= 0L)
            _collectIntervalMs = OpmTopCpuConst.DEFAULT_COLLECT_INTERVAL_SEC * 1000L;
        if (_sampleMillis <= 0)
            _sampleMillis = OpmTopCpuConst.DEFAULT_CPU_SAMPLE_MILLIS;
        if (_topProcSize <= 0)
            _topProcSize = OpmTopCpuConst.DEFAULT_TOP_PROC_SIZE;
    }

    @Override
    public OpmCollectResult collect(OpmAgentContext agentCtx) throws Exception
    {
        long begin = System.nanoTime();
        loadConfig();
        if (!_enable)
            return null;

        long now = System.currentTimeMillis();
        SystemMetrics metrics = SystemMetricsUtil.collect(_sampleMillis, SystemMetricsCollectSpec.forCpuCollector());

        OpmCpuMetricDo ext = new OpmCpuMetricDo();
        ext.collectorKey = getCollectorKey();
        ext.collectorLabel = getCollectorLabel();
        ext.agentCode = agentCtx == null ? null : agentCtx.getAgentCode();
        ext.agentName = agentCtx == null ? null : agentCtx.getAgentName();
        ext.myUri = agentCtx == null ? null : agentCtx.getMyUri();
        ext.collectTime = now;
        ext.hostName = metrics == null ? null : metrics.hostName;
        ext.osName = metrics == null ? null : metrics.osName;
        ext.provider = metrics == null ? null : metrics.provider;

        if (metrics != null && metrics.cpu != null)
        {
            ext.cpuUsageRate = metrics.cpu.usageRate;
            ext.userRate = metrics.cpu.userRate;
            ext.systemRate = metrics.cpu.systemRate;
            ext.idleRate = metrics.cpu.idleRate;
        }

        List<SystemMetrics.ProcessCpuUsage> top = cutTopCpu(metrics == null ? null : metrics.cpuProcesses, _topProcSize);
        if (top.isEmpty() && _lastTopProc != null && !_lastTopProc.isEmpty())
            top = cloneCpuProcList(_lastTopProc);
        else if (!top.isEmpty())
            _lastTopProc = cloneCpuProcList(top);

        OpmCpuMetricDo fallbackTop = null;
        if (top.isEmpty())
            fallbackTop = queryLastTopProcess(ext.agentCode);

        ext.topProcCount = top.size();
        if (!top.isEmpty())
        {
            ext.topProcName = top.get(0).processName;
            ext.topProcCpuRate = top.get(0).cpuRate;
        }
        else if (fallbackTop != null && ToolUtilities.getInteger(fallbackTop.topProcCount, 0) > 0)
        {
            ext.topProcCount = fallbackTop.topProcCount;
            ext.topProcName = fallbackTop.topProcName;
            ext.topProcCpuRate = fallbackTop.topProcCpuRate;
        }

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        Map<String, Object> cpuMap = new LinkedHashMap<String, Object>();
        if (metrics != null && metrics.cpu != null)
        {
            cpuMap.put("usageRate", metrics.cpu.usageRate);
            cpuMap.put("userRate", metrics.cpu.userRate);
            cpuMap.put("systemRate", metrics.cpu.systemRate);
            cpuMap.put("idleRate", metrics.cpu.idleRate);
            cpuMap.put("source", metrics.cpu.source);
        }
        detail.put("topCpu", cpuMap);

        List<Map<String, Object>> topProc = toProcList(top);
        if (topProc.isEmpty() && fallbackTop != null && !ToolUtilities.isStringEmpty(fallbackTop.topProcName))
        {
            Map<String, Object> p = new LinkedHashMap<String, Object>();
            p.put("pid", -1);
            p.put("processName", fallbackTop.topProcName);
            p.put("cpuRate", fallbackTop.topProcCpuRate);
            p.put("source", "fallback_latest_metric");
            topProc.add(p);
        }
        detail.put("topProcesses", topProc);

        ext.detailJson = CJson.toJson(detail);

        OpmCollectResult ret = new OpmCollectResult();
        ret.collectorKey = getCollectorKey();
        ret.collectorLabel = getCollectorLabel();
        ret.collectTime = now;
        ret.collectCostMs = (System.nanoTime() - begin) / 1000000L;
        ret.metricExt = ext;
        ret.summary = "TopProc=" + ToolUtilities.getString(ext.topProcName, "N/A")
                + ", TopProcCPU=" + SystemMetricsUtil.formatPercent(ToolUtilities.getDouble(ext.topProcCpuRate, -1D))
                + ", CpuSnapshot=" + SystemMetricsUtil.formatPercent(ToolUtilities.getDouble(ext.cpuUsageRate, -1D));

        if (metrics == null || metrics.cpu == null || !metrics.cpu.available)
            ret.status = OpmConst.STATUS_ERROR;
        return ret;
    }

    @Override
    public List<OpmRuleResult> evaluateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception
    {
        ArrayList<OpmRuleResult> list = new ArrayList<OpmRuleResult>();
        if (collectResult == null || !(collectResult.metricExt instanceof OpmCpuMetricDo))
            return list;

        OpmCpuMetricDo ext = (OpmCpuMetricDo) collectResult.metricExt;
        long now = System.currentTimeMillis();

        OpmRuleResult cpuRule = evalCpuUsageRule(ext, agentCtx, now);
        if (cpuRule != null)
            list.add(cpuRule);

        return list;
    }

    protected OpmRuleResult evalCpuUsageRule(OpmCpuMetricDo ext, OpmAgentContext agentCtx, long now)
    {
        double usage = ToolUtilities.getDouble(ext.cpuUsageRate, -1D);
        if (usage < 0D)
            return null;

        AlarmLevelConfig[] levels = new AlarmLevelConfig[] {
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", _criticalRate, _criticalDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MAJOR, "主要", _majorRate, _majorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MINOR, "次要", _minorRate, _minorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_WARN, "警告", _warnRate, _warnDurationSec)
        };

        for (AlarmLevelConfig level : levels)
        {
            if (usage < level.threshold)
                continue;

            List<OpmCpuMetricDo> history = queryHistoryMetrics(agentCtx == null ? null : agentCtx.getAgentCode(), now - level.durationSec * 1000L);
            if (!allCpuOver(history, level.threshold))
                continue;

            String ruleKey = OpmAlarmConfigKeys.RULE_TOP_CPU;

            OpmRuleResult rs = new OpmRuleResult();
            rs.triggered = true;
            rs.alarmLevel = level.level;
            rs.ruleKey = ruleKey;
            rs.configParamKey = resolveConfigParamKey(level.level);
            rs.ruleLabel = "TOP进程CPU门限";
            rs.message = "TOP进程CPU持续过高: 当前=" + SystemMetricsUtil.formatPercent(usage)
                    + ", 级别=" + level.levelName
                    + ", 阈值=" + SystemMetricsUtil.formatPercent(level.threshold)
                    + ", 持续" + level.durationSec + "秒"
                    + "，原因=普通进程 Top CPU 持续偏高"
                    + "，建议=检查对应高 CPU 进程、线程热点与采样窗口，必要时优化业务或限流。";
            rs.detailJson = ext.detailJson;

            OpmSysAlarmExtDo alarmExt = new OpmSysAlarmExtDo();
            alarmExt.metricName = "topProcCpuRate";
            alarmExt.currentRate = Double.valueOf(usage);
            alarmExt.triggerLevel = level.levelName;
            alarmExt.thresholdRate = Double.valueOf(level.threshold);
            alarmExt.durationSec = Integer.valueOf(level.durationSec);
            alarmExt.warnRate = Double.valueOf(_warnRate);
            alarmExt.criticalRate = Double.valueOf(_criticalRate);
            rs.alarmExt = alarmExt;
            return rs;
        }

        return null;
    }

    protected String resolveConfigParamKey(int alarmLevel)
    {
        if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
            return OpmTopCpuConst.CONF_CRITICAL_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
            return OpmTopCpuConst.CONF_MAJOR_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
            return OpmTopCpuConst.CONF_MINOR_RATE;
        return OpmTopCpuConst.CONF_WARN_RATE;
    }

    protected boolean allCpuOver(List<OpmCpuMetricDo> history, double threshold)
    {
        if (history == null || history.isEmpty())
            return false;
        for (OpmCpuMetricDo one : history)
        {
            if (one == null || one.cpuUsageRate == null || one.cpuUsageRate.doubleValue() < threshold)
                return false;
        }
        return true;
    }

    protected List<OpmCpuMetricDo> queryHistoryMetrics(String agentCode, long sinceTime)
    {
        List<OpmCpuMetricDo> list = new ArrayList<OpmCpuMetricDo>();
        if (ToolUtilities.isStringEmpty(agentCode, true))
            return list;
        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = Cnd.where(OpmCpuMetricDo.AgentCode, "=", agentCode)
                    .and(OpmCpuMetricDo.CollectTime, ">=", Long.valueOf(sinceTime))
                    .asc(OpmCpuMetricDo.CollectTime);
            list = dao.queryDoList(OpmCpuMetricDo.class, cnd);
        }
        catch (Throwable ignore)
        {
        }
        return list;
    }

    protected List<Map<String, Object>> toProcList(List<SystemMetrics.ProcessCpuUsage> list)
    {
        ArrayList<Map<String, Object>> out = new ArrayList<Map<String, Object>>();
        if (list == null)
            return out;
        for (SystemMetrics.ProcessCpuUsage one : list)
        {
            if (one == null)
                continue;
            Map<String, Object> p = new LinkedHashMap<String, Object>();
            p.put("pid", Integer.valueOf(one.pid));
            p.put("processName", one.processName);
            p.put("processPath", one.processPath);
            p.put("memoryBytes", Long.valueOf(one.memoryBytes));
            p.put("cpuRate", Double.valueOf(one.cpuRate));
            p.put("source", one.source);
            out.add(p);
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    protected List<Map<String, Object>> parseListFromDetail(String detailJson, String key)
    {
        if (ToolUtilities.isStringEmpty(detailJson))
            return null;
        try
        {
            Object obj = normalizeCJsonObject(CJson.fromJson(detailJson));
            if (!(obj instanceof Map))
                return null;
            Object value = ((Map<String, Object>) obj).get(key);
            if (value instanceof List)
                return (List<Map<String, Object>>) value;
        }
        catch (Throwable ignore)
        {
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    protected Object normalizeCJsonObject(Object obj)
    {
        if (obj == null)
            return null;
        if (obj instanceof Map)
        {
            Map<Object, Object> map = (Map<Object, Object>) obj;
            if (map.containsKey("#O"))
                return normalizeCJsonObject(map.get("#O"));

            if (map.containsKey("#M"))
            {
                Object items = map.get("#M");
                if (items instanceof List)
                {
                    LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
                    for (Object one : (List<Object>) items)
                    {
                        if (!(one instanceof Map))
                            continue;
                        Map<Object, Object> entry = (Map<Object, Object>) one;
                        String k = ToolUtilities.getString(entry.get("$"), null);
                        if (ToolUtilities.isStringEmpty(k))
                            continue;
                        ret.put(k, normalizeCJsonObject(entry.get("^")));
                    }
                    return ret;
                }
            }

            if (map.containsKey("#L"))
            {
                Object arr = map.get("#L");
                if (arr instanceof List)
                {
                    ArrayList<Object> ret = new ArrayList<Object>();
                    for (Object one : (List<Object>) arr)
                        ret.add(normalizeCJsonObject(one));
                    return ret;
                }
            }
        }
        return obj;
    }

    protected List<SystemMetrics.ProcessCpuUsage> cutTopCpu(List<SystemMetrics.ProcessCpuUsage> src, int max)
    {
        ArrayList<SystemMetrics.ProcessCpuUsage> ret = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        if (src == null)
            return ret;
        for (SystemMetrics.ProcessCpuUsage one : src)
        {
            if (one == null)
                continue;
            ret.add(one);
            if (ret.size() >= max)
                break;
        }
        return ret;
    }

    protected List<SystemMetrics.ProcessCpuUsage> cloneCpuProcList(List<SystemMetrics.ProcessCpuUsage> src)
    {
        ArrayList<SystemMetrics.ProcessCpuUsage> ret = new ArrayList<SystemMetrics.ProcessCpuUsage>();
        if (src == null)
            return ret;
        for (SystemMetrics.ProcessCpuUsage one : src)
        {
            if (one == null)
                continue;
            SystemMetrics.ProcessCpuUsage cp = new SystemMetrics.ProcessCpuUsage();
            cp.available = one.available;
            cp.pid = one.pid;
            cp.processName = one.processName;
            cp.source = one.source;
            cp.cpuRate = one.cpuRate;
            ret.add(cp);
        }
        return ret;
    }

    protected OpmCpuMetricDo queryLastTopProcess(String agentCode)
    {
        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = Cnd.where(OpmCpuMetricDo.TopProcCount, ">", 0);
            if (!ToolUtilities.isStringEmpty(agentCode))
                cnd.and(OpmCpuMetricDo.AgentCode, "=", agentCode);
            cnd.desc(OpmCpuMetricDo.CollectTime);

            OpmCpuMetricDo one = dao.queryDo(OpmCpuMetricDo.class, cnd);
            if (one != null)
                return one;

            cnd = Cnd.where(OpmCpuMetricDo.TopProcCount, ">", 0).desc(OpmCpuMetricDo.CollectTime);
            return dao.queryDo(OpmCpuMetricDo.class, cnd);
        }
        catch (Throwable err)
        {
            return null;
        }
    }

    @Override
    public OpmConfigGroup getConfigGroup()
    {
        OpmConfigGroup root = new OpmConfigGroup(getCollectorKey(), getCollectorLabel())
                .setDesc("采集普通进程 TOP CPU 排行，并对 TOP 进程 CPU 持续超阈值情况进行告警。 ");
        List<OpmParamDef> defs = getParamDefs();
        if (defs != null)
        {
            for (OpmParamDef p : defs)
            {
                if (p != null)
                    root.addParam(p);
            }
        }
        return root;
    }

    protected static class AlarmLevelConfig
    {
        int level;
        String levelName;
        double threshold;
        int durationSec;

        AlarmLevelConfig(int level, String levelName, double threshold, int durationSec)
        {
            this.level = level;
            this.levelName = levelName;
            this.threshold = threshold;
            this.durationSec = durationSec;
        }
    }

}
