package cell.bap.opm.collector.topcpu;

import bap.cells.Cells;
import cell.bap.opm.collector.IOpmCollector;

public interface IOpmTopCpuCollector extends IOpmCollector
{
    public static IOpmTopCpuCollector get()
    {
        return Cells.get(IOpmTopCpuCollector.class);
    }
}
