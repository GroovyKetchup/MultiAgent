package cell.bap.opm.collector.topmemory;

import bap.cells.Cells;
import cell.bap.opm.collector.IOpmCollector;

public interface IOpmTopMemoryCollector extends IOpmCollector
{
    public static IOpmTopMemoryCollector get()
    {
        return Cells.get(IOpmTopMemoryCollector.class);
    }
}
