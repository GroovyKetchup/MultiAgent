package cell.bap.opm.collector.topmemory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.nutz.dao.Cnd;

import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;

import bap.cells.BasicCell;
import bap.md.opm.memory.OpmMemoryMetricDo;
import bap.md.opm.sys.OpmSysAlarmExtDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmConst;
import bap.opm.OpmParamDef;
import bap.opm.OpmRuleResult;
import bap.opm.cfg.OpmConfigGroup;
import bap.opm.cfg.OpmConfigXmlBuilder;
import bap.opm.collector.topmemory.OpmTopMemoryConst;
import bap.opm.registry.OpmAlarmConfigKeys;
import bap.opm.system.SystemMetrics;
import bap.opm.system.SystemMetricsCollectSpec;
import bap.opm.system.SystemMetricsUtil;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.md.TsAlarm;

public class COpmTopMemoryCollector extends BasicCell implements IOpmTopMemoryCollector
{
    protected volatile boolean _enable = OpmTopMemoryConst.DEFAULT_ENABLE;
    protected volatile long _collectIntervalMs = OpmTopMemoryConst.getCollectIntervalMs();
    protected volatile double _warnRate = OpmTopMemoryConst.DEFAULT_WARN_RATE;
    protected volatile int _warnDurationSec = OpmTopMemoryConst.DEFAULT_WARN_DURATION_SEC;
    protected volatile double _minorRate = OpmTopMemoryConst.DEFAULT_MINOR_RATE;
    protected volatile int _minorDurationSec = OpmTopMemoryConst.DEFAULT_MINOR_DURATION_SEC;
    protected volatile double _majorRate = OpmTopMemoryConst.DEFAULT_MAJOR_RATE;
    protected volatile int _majorDurationSec = OpmTopMemoryConst.DEFAULT_MAJOR_DURATION_SEC;
    protected volatile double _criticalRate = OpmTopMemoryConst.DEFAULT_CRITICAL_RATE;
    protected volatile int _criticalDurationSec = OpmTopMemoryConst.DEFAULT_CRITICAL_DURATION_SEC;
    @Override
    public String getCollectorKey()
    {
        return OpmTopMemoryConst.COLLECTOR_KEY;
    }

    @Override
    public String getCollectorLabel()
    {
        return OpmTopMemoryConst.COLLECTOR_LABEL;
    }

    @Override
    public List<OpmParamDef> getParamDefs()
    {
        List<OpmParamDef> defs = new LinkedList<OpmParamDef>();
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_ENABLE, OpmTopMemoryConst.LABEL_ENABLE, "boolean", String.valueOf(OpmTopMemoryConst.DEFAULT_ENABLE)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_COLLECT_INTERVAL_SEC, OpmTopMemoryConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmTopMemoryConst.DEFAULT_COLLECT_INTERVAL_SEC)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_WARN_RATE, OpmTopMemoryConst.LABEL_WARN_RATE, "string", String.valueOf(OpmTopMemoryConst.DEFAULT_WARN_RATE)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_WARN_DURATION_SEC, OpmTopMemoryConst.LABEL_WARN_DURATION_SEC, "int", String.valueOf(OpmTopMemoryConst.DEFAULT_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_MINOR_RATE, OpmTopMemoryConst.LABEL_MINOR_RATE, "string", String.valueOf(OpmTopMemoryConst.DEFAULT_MINOR_RATE)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_MINOR_DURATION_SEC, OpmTopMemoryConst.LABEL_MINOR_DURATION_SEC, "int", String.valueOf(OpmTopMemoryConst.DEFAULT_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_MAJOR_RATE, OpmTopMemoryConst.LABEL_MAJOR_RATE, "string", String.valueOf(OpmTopMemoryConst.DEFAULT_MAJOR_RATE)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_MAJOR_DURATION_SEC, OpmTopMemoryConst.LABEL_MAJOR_DURATION_SEC, "int", String.valueOf(OpmTopMemoryConst.DEFAULT_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_CRITICAL_RATE, OpmTopMemoryConst.LABEL_CRITICAL_RATE, "string", String.valueOf(OpmTopMemoryConst.DEFAULT_CRITICAL_RATE)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_CRITICAL_DURATION_SEC, OpmTopMemoryConst.LABEL_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmTopMemoryConst.DEFAULT_CRITICAL_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmTopMemoryConst.CONF_RULE_COOLDOWN_SEC, OpmTopMemoryConst.LABEL_RULE_COOLDOWN_SEC, "int", String.valueOf(OpmTopMemoryConst.DEFAULT_RULE_COOLDOWN_SEC)));
        return defs;
    }

    @Override
    public String getSampleConfigComment()
    {
        return OpmConfigXmlBuilder.buildModuleSample("topMemory", "TOP进程内存监控", "cell.bap.opm.collector.topmemory.IOpmTopMemoryCollector", getConfigGroup());
    }

    @Override
    public long getCollectIntervalMs()
    {
        return _collectIntervalMs;
    }

    @Override
    public List<Class> getModelClasses()
    {
        List<Class> list = new ArrayList<Class>();
        list.add(OpmMemoryMetricDo.class);
        list.add(OpmSysAlarmExtDo.class);
        return list;
    }

    @Override
    public void loadConfig()
    {
        _enable = OpmTopMemoryConst.isEnable();
        _collectIntervalMs = OpmTopMemoryConst.getCollectIntervalMs();
        _warnRate = OpmTopMemoryConst.getWarnRate();
        _warnDurationSec = OpmTopMemoryConst.getWarnDurationSec();
        _minorRate = OpmTopMemoryConst.getMinorRate();
        _minorDurationSec = OpmTopMemoryConst.getMinorDurationSec();
        _majorRate = OpmTopMemoryConst.getMajorRate();
        _majorDurationSec = OpmTopMemoryConst.getMajorDurationSec();
        _criticalRate = OpmTopMemoryConst.getCriticalRate();
        _criticalDurationSec = OpmTopMemoryConst.getCriticalDurationSec();
    }

    @Override
    public OpmCollectResult collect(OpmAgentContext agentCtx) throws Exception
    {
        long begin = System.nanoTime();
        loadConfig();
        if (!_enable)
            return null;

        long now = System.currentTimeMillis();
        SystemMetrics metrics = SystemMetricsUtil.collect(0L, SystemMetricsCollectSpec.forMemoryCollector());

        OpmMemoryMetricDo ext = new OpmMemoryMetricDo();
        ext.collectorKey = getCollectorKey();
        ext.collectorLabel = getCollectorLabel();
        ext.agentCode = agentCtx == null ? null : agentCtx.getAgentCode();
        ext.agentName = agentCtx == null ? null : agentCtx.getAgentName();
        ext.myUri = agentCtx == null ? null : agentCtx.getMyUri();
        ext.collectTime = now;
        ext.hostName = metrics == null ? null : metrics.hostName;
        ext.osName = metrics == null ? null : metrics.osName;
        ext.provider = metrics == null ? null : metrics.provider;

        if (metrics != null && metrics.memory != null)
        {
            ext.totalBytes = Long.valueOf(metrics.memory.totalBytes);
            ext.usedBytes = Long.valueOf(metrics.memory.usedBytes);
            ext.freeBytes = Long.valueOf(metrics.memory.freeBytes);
            ext.usageRate = Double.valueOf(metrics.memory.usageRate);
            ext.swapTotalBytes = Long.valueOf(metrics.memory.swapTotalBytes);
            ext.swapUsedBytes = Long.valueOf(metrics.memory.swapUsedBytes);
            ext.swapFreeBytes = Long.valueOf(metrics.memory.swapFreeBytes);
            ext.swapUsageRate = Double.valueOf(metrics.memory.swapUsageRate);
        }

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        Map<String, Object> mem = new LinkedHashMap<String, Object>();
        if (metrics != null && metrics.memory != null)
        {
            mem.put("available", Boolean.valueOf(metrics.memory.available));
            mem.put("source", metrics.memory.source);
            mem.put("error", metrics.memory.error);
            mem.put("totalBytes", Long.valueOf(metrics.memory.totalBytes));
            mem.put("usedBytes", Long.valueOf(metrics.memory.usedBytes));
            mem.put("freeBytes", Long.valueOf(metrics.memory.freeBytes));
            mem.put("usageRate", Double.valueOf(metrics.memory.usageRate));
            mem.put("swapTotalBytes", Long.valueOf(metrics.memory.swapTotalBytes));
            mem.put("swapUsedBytes", Long.valueOf(metrics.memory.swapUsedBytes));
            mem.put("swapFreeBytes", Long.valueOf(metrics.memory.swapFreeBytes));
            mem.put("swapUsageRate", Double.valueOf(metrics.memory.swapUsageRate));
        }
        detail.put("topMemory", mem);
        ext.detailJson = CJson.toJson(detail);

        OpmCollectResult ret = new OpmCollectResult();
        ret.collectorKey = getCollectorKey();
        ret.collectorLabel = getCollectorLabel();
        ret.collectTime = now;
        ret.collectCostMs = (System.nanoTime() - begin) / 1000000L;
        ret.metricExt = ext;
        ret.summary = "Memory=" + SystemMetricsUtil.formatPercent(ToolUtilities.getDouble(ext.usageRate, -1D))
                + ", Used=" + SystemMetricsUtil.formatBytes(ToolUtilities.getLong(ext.usedBytes, -1L))
                + ", Free=" + SystemMetricsUtil.formatBytes(ToolUtilities.getLong(ext.freeBytes, -1L));
        if (metrics == null || metrics.memory == null || !metrics.memory.available)
            ret.status = OpmConst.STATUS_ERROR;
        return ret;
    }

    @Override
    public List<OpmRuleResult> evaluateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception
    {
        List<OpmRuleResult> list = new LinkedList<OpmRuleResult>();
        if (collectResult == null || !(collectResult.metricExt instanceof OpmMemoryMetricDo))
            return list;

        OpmMemoryMetricDo ext = (OpmMemoryMetricDo) collectResult.metricExt;
        long now = System.currentTimeMillis();

        OpmRuleResult memRule = evalMemoryUsageRule(ext, agentCtx, now);
        if (memRule != null)
            list.add(memRule);

        return list;
    }

    protected OpmRuleResult evalMemoryUsageRule(OpmMemoryMetricDo ext, OpmAgentContext agentCtx, long now)
    {
        Double usage = ext.usageRate;
        if (usage == null || usage.doubleValue() < 0D)
            return null;

        MemoryRateAlarmLevelConfig[] levels = new MemoryRateAlarmLevelConfig[] {
                new MemoryRateAlarmLevelConfig(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", _criticalRate, _criticalDurationSec),
                new MemoryRateAlarmLevelConfig(TsAlarm.LEVEL_ERROR_MAJOR, "主要", _majorRate, _majorDurationSec),
                new MemoryRateAlarmLevelConfig(TsAlarm.LEVEL_ERROR_MINOR, "次要", _minorRate, _minorDurationSec),
                new MemoryRateAlarmLevelConfig(TsAlarm.LEVEL_WARN, "警告", _warnRate, _warnDurationSec)
        };

        for (MemoryRateAlarmLevelConfig level : levels)
        {
            if (usage.doubleValue() < level.threshold)
                continue;

            List<OpmMemoryMetricDo> history = queryHistoryMetrics(agentCtx == null ? null : agentCtx.getAgentCode(), now - level.durationSec * 1000L);
            if (history == null || history.isEmpty())
                continue;

            boolean allOver = true;
            for (OpmMemoryMetricDo one : history)
            {
                if (one == null || one.usageRate == null || one.usageRate.doubleValue() < level.threshold)
                {
                    allOver = false;
                    break;
                }
            }
            if (!allOver)
                continue;

            String ruleKey = OpmAlarmConfigKeys.RULE_TOP_MEMORY;

            OpmRuleResult rs = new OpmRuleResult();
            rs.triggered = true;
            rs.alarmLevel = level.level;
            rs.ruleKey = ruleKey;
            rs.configParamKey = resolveConfigParamKey(level.level);
            rs.ruleLabel = "TOP进程内存门限";
            rs.message = "TOP进程内存持续过高: 当前=" + SystemMetricsUtil.formatPercent(usage.doubleValue())
                    + ", 级别=" + level.levelName
                    + ", 阈值=" + SystemMetricsUtil.formatPercent(level.threshold)
                    + ", 持续" + level.durationSec + "秒"
                    + "，原因=普通进程 Top 内存占用持续偏高"
                    + "，建议=检查对应大内存进程、堆内存配置、缓存占用与交换区使用情况。";
            rs.detailJson = ext.detailJson;

            OpmSysAlarmExtDo extAlarm = new OpmSysAlarmExtDo();
            extAlarm.metricName = "topProcMemoryRate";
            extAlarm.currentRate = usage;
            extAlarm.triggerLevel = level.levelName;
            extAlarm.thresholdRate = Double.valueOf(level.threshold);
            extAlarm.durationSec = Integer.valueOf(level.durationSec);
            extAlarm.warnRate = Double.valueOf(_warnRate);
            extAlarm.criticalRate = Double.valueOf(_criticalRate);
            rs.alarmExt = extAlarm;
            return rs;
        }

        return null;
    }

    protected String resolveConfigParamKey(int alarmLevel)
    {
        if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
            return OpmTopMemoryConst.CONF_CRITICAL_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
            return OpmTopMemoryConst.CONF_MAJOR_RATE;
        if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
            return OpmTopMemoryConst.CONF_MINOR_RATE;
        return OpmTopMemoryConst.CONF_WARN_RATE;
    }

    protected List<OpmMemoryMetricDo> queryHistoryMetrics(String agentCode, long sinceTime)
    {
        List<OpmMemoryMetricDo> list = new ArrayList<OpmMemoryMetricDo>();
        if (ToolUtilities.isStringEmpty(agentCode, true))
            return list;
        try (IDao dao = IDaoService.newIDao())
        {
            Cnd cnd = Cnd.where(OpmMemoryMetricDo.AgentCode, "=", agentCode)
                    .and(OpmMemoryMetricDo.CollectTime, ">=", Long.valueOf(sinceTime))
                    .asc(OpmMemoryMetricDo.CollectTime);
            list = dao.queryDoList(OpmMemoryMetricDo.class, cnd);
        }
        catch (Throwable ignore)
        {
        }
        return list;
    }

    @Override
    public OpmConfigGroup getConfigGroup()
    {
        OpmConfigGroup root = new OpmConfigGroup(getCollectorKey(), getCollectorLabel())
                .setDesc("采集普通进程 TOP 内存排行，并对 TOP 进程内存持续超阈值情况进行告警。 ");
        List<OpmParamDef> defs = getParamDefs();
        if (defs != null)
            for (OpmParamDef p : defs)
                if (p != null)
                    root.addParam(p);
        return root;
    }

    @SuppressWarnings("unchecked")
    protected List<Map<String, Object>> parseListFromDetail(String detailJson, String key)
    {
        if (ToolUtilities.isStringEmpty(detailJson))
            return null;
        try
        {
            Object obj = CJson.fromJson(detailJson);
            if (!(obj instanceof Map))
                return null;
            Object value = ((Map<String, Object>) obj).get(key);
            if (value instanceof List)
                return (List<Map<String, Object>>) value;
        }
        catch (Throwable ignore)
        {
        }
        return null;
    }


    protected static class MemoryRateAlarmLevelConfig
    {
        int level;
        String levelName;
        double threshold;
        int durationSec;

        MemoryRateAlarmLevelConfig(int level, String levelName, double threshold, int durationSec)
        {
            this.level = level;
            this.levelName = levelName;
            this.threshold = threshold;
            this.durationSec = durationSec;
        }
    }

}
