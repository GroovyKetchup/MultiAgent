package cell.bap.opm.collector;

import java.util.List;

import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmParamDef;
import bap.opm.OpmRuleResult;
import bap.opm.cfg.OpmConfigGroup;
import cell.PluginCellIntf;

/**
 * OPM采集器接口。
 *
 * 采集器装配采用配置驱动：
 * 1) 优先在 starter.xml 的 opm starter 下，用 module.class_name 配置接口或实现类；
 * 2) 兼容读取 opm.core.collectorClasses；
 * 3) 采集器自身负责参数定义、配置解析、采集和规则判定。
 *
 * 约定：
 * - 新采集器需在实现类头部提供可复制的参数样板注释；
 * - 并通过 getSampleConfigComment() 返回同样内容，便于界面或日志提示。
 * - 必须实现 getConfigGroup() 方法返回配置分组，支持无限嵌套。
 */
public interface IOpmCollector extends PluginCellIntf
{
    public String getCollectorKey();

    public String getCollectorLabel();

    public List<OpmParamDef> getParamDefs();

    public String getSampleConfigComment();

    public long getCollectIntervalMs();

    public List<Class> getModelClasses();

    public void loadConfig();

    public OpmCollectResult collect(OpmAgentContext agentCtx) throws Exception;

    public List<OpmRuleResult> evaluateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception;

    public OpmConfigGroup getConfigGroup();
}
