package cell.bap.opm.collector.diskpartition;

import cell.bap.opm.collector.IOpmCollector;

public interface IOpmDiskPartitionCollector extends IOpmCollector
{
}