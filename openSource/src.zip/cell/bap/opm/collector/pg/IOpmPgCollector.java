package cell.bap.opm.collector.pg;

import cell.bap.opm.collector.IOpmCollector;

public interface IOpmPgCollector extends IOpmCollector
{
}