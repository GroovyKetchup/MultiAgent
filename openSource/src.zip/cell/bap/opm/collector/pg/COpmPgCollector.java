package cell.bap.opm.collector.pg;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.nutz.dao.Cnd;

import com.cdao.dto.DataRow;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.cjson.CJson;
import com.leavay.common.util.ToolBasic;

import bap.cells.BasicCell;
import bap.md.opm.pg.OpmPgAlarmExtDo;
import bap.md.opm.pg.OpmPgLockDetailDo;
import bap.md.opm.pg.OpmPgMetricDo;
import bap.md.opm.pg.OpmPgSqlDetailDo;
import bap.opm.OpmAgentContext;
import bap.opm.OpmCollectResult;
import bap.opm.OpmConst;
import bap.opm.OpmParamDef;
import bap.opm.OpmRuleResult;
import bap.opm.cfg.OpmConfigGroup;
import bap.opm.cfg.OpmConfigXmlBuilder;
import bap.opm.collector.pg.OpmPgConst;
import bap.opm.collector.pg.PgSqlQueries;
import bap.opm.cfg.OpmCollectorTemplate;
import bap.opm.registry.OpmAlarmConfigKeys;
import cell.cdao.IDao;
import cell.cdao.IDaoService;
import tiny.service.md.TsAlarm;

/**
 * PG数据库监控采集器。
 *
 * <pre>
 * 功能说明：
 * 1. 采集长时SQL、锁等待、连接、空间、复制等PG指标
 * 2. 对PG关键指标执行规则评估并生成告警
 * 3. 输出可区分的长时SQL摘要与抑制键，避免不同SQL互相抑制
 *
 * 测试用例：
 * - bap.opm.test.PgAlarmConfigTest
 * - bap.opm.test.OpmPgLongSqlSuppressKeyTest
 * </pre>
 */
public class COpmPgCollector extends BasicCell implements IOpmPgCollector
{
    protected static final String DETAIL_KEY_TOP_LONG_SQL = "topLongSql";
    protected static final String DETAIL_KEY_LONG_SQL_SUPPRESS_KEY = "suppressKey";

    protected volatile boolean _enable = OpmPgConst.DEFAULT_ENABLE;
    protected volatile long _collectIntervalMs = OpmPgConst.getCollectIntervalMs();
    protected volatile String _dbName = OpmPgConst.DEFAULT_DB_NAME;
    protected volatile boolean _sqlEnable = OpmPgConst.DEFAULT_SQL_ENABLE;
    protected volatile boolean _spaceEnable = OpmPgConst.DEFAULT_SPACE_ENABLE;
    protected volatile boolean _lockEnable = OpmPgConst.DEFAULT_LOCK_ENABLE;
    protected volatile boolean _connEnable = OpmPgConst.DEFAULT_CONN_ENABLE;
    protected volatile Boolean _pgStatActivityHasBackendType = null;
    protected volatile boolean _storeSqlDetail = OpmPgConst.DEFAULT_STORE_SQL_DETAIL;
    protected volatile int _sqlDetailMaxRows = OpmPgConst.DEFAULT_SQL_DETAIL_MAX_ROWS;

    protected volatile int _sqlWarnSec = OpmPgConst.DEFAULT_SQL_WARN_SEC;
    protected volatile int _sqlMinorSec = OpmPgConst.DEFAULT_SQL_MINOR_SEC;
    protected volatile int _sqlMajorSec = OpmPgConst.DEFAULT_SQL_MAJOR_SEC;
    protected volatile int _sqlCriticalSec = OpmPgConst.DEFAULT_SQL_CRITICAL_SEC;

    protected volatile double _spaceWarnRate = OpmPgConst.DEFAULT_SPACE_WARN_RATE;
    protected volatile int _spaceWarnDurationSec = OpmPgConst.DEFAULT_SPACE_WARN_DURATION_SEC;
    protected volatile double _spaceMinorRate = OpmPgConst.DEFAULT_SPACE_MINOR_RATE;
    protected volatile int _spaceMinorDurationSec = OpmPgConst.DEFAULT_SPACE_MINOR_DURATION_SEC;
    protected volatile double _spaceMajorRate = OpmPgConst.DEFAULT_SPACE_MAJOR_RATE;
    protected volatile int _spaceMajorDurationSec = OpmPgConst.DEFAULT_SPACE_MAJOR_DURATION_SEC;
    protected volatile double _spaceCriticalRate = OpmPgConst.DEFAULT_SPACE_CRITICAL_RATE;
    protected volatile int _spaceCriticalDurationSec = OpmPgConst.DEFAULT_SPACE_CRITICAL_DURATION_SEC;

    protected volatile double _connWarnRate = OpmPgConst.DEFAULT_CONN_WARN_RATE;
    protected volatile int _connWarnDurationSec = OpmPgConst.DEFAULT_CONN_WARN_DURATION_SEC;
    protected volatile double _connMinorRate = OpmPgConst.DEFAULT_CONN_MINOR_RATE;
    protected volatile int _connMinorDurationSec = OpmPgConst.DEFAULT_CONN_MINOR_DURATION_SEC;
    protected volatile double _connMajorRate = OpmPgConst.DEFAULT_CONN_MAJOR_RATE;
    protected volatile int _connMajorDurationSec = OpmPgConst.DEFAULT_CONN_MAJOR_DURATION_SEC;
    protected volatile double _connCriticalRate = OpmPgConst.DEFAULT_CONN_CRITICAL_RATE;
    protected volatile int _connCriticalDurationSec = OpmPgConst.DEFAULT_CONN_CRITICAL_DURATION_SEC;

    protected volatile int _replicationWarnSec = OpmPgConst.DEFAULT_REPLICATION_WARN_SEC;
    protected volatile int _replicationWarnDurationSec = OpmPgConst.DEFAULT_REPLICATION_WARN_DURATION_SEC;
    protected volatile int _replicationMinorSec = OpmPgConst.DEFAULT_REPLICATION_MINOR_SEC;
    protected volatile int _replicationMinorDurationSec = OpmPgConst.DEFAULT_REPLICATION_MINOR_DURATION_SEC;
    protected volatile int _replicationMajorSec = OpmPgConst.DEFAULT_REPLICATION_MAJOR_SEC;
    protected volatile int _replicationMajorDurationSec = OpmPgConst.DEFAULT_REPLICATION_MAJOR_DURATION_SEC;
    protected volatile int _replicationCriticalSec = OpmPgConst.DEFAULT_REPLICATION_CRITICAL_SEC;
    protected volatile int _replicationCriticalDurationSec = OpmPgConst.DEFAULT_REPLICATION_CRITICAL_DURATION_SEC;
    protected volatile boolean _replicationEnable = OpmPgConst.DEFAULT_REPLICATION_ENABLE;
    protected volatile long _lowFreqCollectIntervalMs = OpmPgConst.getLowFreqCollectIntervalMs();
    protected volatile long _lastLowFreqCollectTime = 0L;
    protected volatile long _lastDbSizeBytes = 0L;
    protected volatile double _lastTablespaceUsageRate = 0D;
    protected volatile int _deadlockWarnCount = OpmPgConst.DEFAULT_DEADLOCK_WARN_COUNT;
    protected volatile int _deadlockMinorCount = OpmPgConst.DEFAULT_DEADLOCK_MINOR_COUNT;
    protected volatile int _deadlockMajorCount = OpmPgConst.DEFAULT_DEADLOCK_MAJOR_COUNT;
    protected volatile int _deadlockCriticalCount = OpmPgConst.DEFAULT_DEADLOCK_CRITICAL_COUNT;
    protected volatile int _lastDeadlockCount = -1;

    protected final Object _recentLockWaitLock = new Object();
    protected final LinkedList<RecentLockWaitSnapshot> _recentLockWaitHistory = new LinkedList<RecentLockWaitSnapshot>();
    protected final Object _recentTableLockSqlLock = new Object();
    protected final LinkedList<RecentSqlSnapshot> _recentTableLockSqlHistory = new LinkedList<RecentSqlSnapshot>();

    protected static final class RecentLockWaitSnapshot
    {
        long captureTime;
        List<Map<String, Object>> lockWaits;
    }

    protected static final class RecentSqlSnapshot
    {
        long captureTime;
        List<Map<String, Object>> sqls;
    }

    @Override
    public String getCollectorKey()
    {
        return OpmPgConst.COLLECTOR_KEY;
    }

    @Override
    public String getCollectorLabel()
    {
        return OpmPgConst.COLLECTOR_LABEL;
    }

    @Override
    public List<OpmParamDef> getParamDefs()
    {
        List<OpmParamDef> defs = new LinkedList<OpmParamDef>();
        defs.add(new OpmParamDef(OpmPgConst.CONF_ENABLE, OpmPgConst.LABEL_ENABLE, "boolean", String.valueOf(OpmPgConst.DEFAULT_ENABLE)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_COLLECT_INTERVAL_SEC, OpmPgConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_COLLECT_INTERVAL_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_LOW_FREQ_COLLECT_INTERVAL_SEC, OpmPgConst.LABEL_LOW_FREQ_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_LOW_FREQ_COLLECT_INTERVAL_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_STORE_SQL_DETAIL, OpmPgConst.LABEL_STORE_SQL_DETAIL, "boolean", String.valueOf(OpmPgConst.DEFAULT_STORE_SQL_DETAIL)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SQL_DETAIL_MAX_ROWS, OpmPgConst.LABEL_SQL_DETAIL_MAX_ROWS, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_DETAIL_MAX_ROWS)));

        defs.add(new OpmParamDef(OpmPgConst.CONF_SQL_WARN_SEC, OpmPgConst.LABEL_SQL_WARN_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_WARN_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SQL_MINOR_SEC, OpmPgConst.LABEL_SQL_MINOR_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_MINOR_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SQL_MAJOR_SEC, OpmPgConst.LABEL_SQL_MAJOR_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_MAJOR_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SQL_CRITICAL_SEC, OpmPgConst.LABEL_SQL_CRITICAL_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_CRITICAL_SEC)));

        defs.add(new OpmParamDef(OpmPgConst.CONF_SPACE_WARN_RATE, OpmPgConst.LABEL_SPACE_WARN_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_SPACE_WARN_RATE)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SPACE_WARN_DURATION_SEC, OpmPgConst.LABEL_SPACE_WARN_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SPACE_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SPACE_MINOR_RATE, OpmPgConst.LABEL_SPACE_MINOR_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_SPACE_MINOR_RATE)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SPACE_MINOR_DURATION_SEC, OpmPgConst.LABEL_SPACE_MINOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SPACE_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SPACE_MAJOR_RATE, OpmPgConst.LABEL_SPACE_MAJOR_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_SPACE_MAJOR_RATE)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SPACE_MAJOR_DURATION_SEC, OpmPgConst.LABEL_SPACE_MAJOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SPACE_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SPACE_CRITICAL_RATE, OpmPgConst.LABEL_SPACE_CRITICAL_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_SPACE_CRITICAL_RATE)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_SPACE_CRITICAL_DURATION_SEC, OpmPgConst.LABEL_SPACE_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SPACE_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmPgConst.CONF_DEADLOCK_WARN_COUNT, OpmPgConst.LABEL_DEADLOCK_WARN_COUNT, "int", String.valueOf(OpmPgConst.DEFAULT_DEADLOCK_WARN_COUNT)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_DEADLOCK_MINOR_COUNT, OpmPgConst.LABEL_DEADLOCK_MINOR_COUNT, "int", String.valueOf(OpmPgConst.DEFAULT_DEADLOCK_MINOR_COUNT)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_DEADLOCK_MAJOR_COUNT, OpmPgConst.LABEL_DEADLOCK_MAJOR_COUNT, "int", String.valueOf(OpmPgConst.DEFAULT_DEADLOCK_MAJOR_COUNT)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_DEADLOCK_CRITICAL_COUNT, OpmPgConst.LABEL_DEADLOCK_CRITICAL_COUNT, "int", String.valueOf(OpmPgConst.DEFAULT_DEADLOCK_CRITICAL_COUNT)));

        defs.add(new OpmParamDef(OpmPgConst.CONF_CONN_WARN_RATE, OpmPgConst.LABEL_CONN_WARN_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_CONN_WARN_RATE)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_CONN_WARN_DURATION_SEC, OpmPgConst.LABEL_CONN_WARN_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_CONN_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_CONN_MINOR_RATE, OpmPgConst.LABEL_CONN_MINOR_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_CONN_MINOR_RATE)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_CONN_MINOR_DURATION_SEC, OpmPgConst.LABEL_CONN_MINOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_CONN_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_CONN_MAJOR_RATE, OpmPgConst.LABEL_CONN_MAJOR_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_CONN_MAJOR_RATE)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_CONN_MAJOR_DURATION_SEC, OpmPgConst.LABEL_CONN_MAJOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_CONN_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_CONN_CRITICAL_RATE, OpmPgConst.LABEL_CONN_CRITICAL_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_CONN_CRITICAL_RATE)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_CONN_CRITICAL_DURATION_SEC, OpmPgConst.LABEL_CONN_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_CONN_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmPgConst.CONF_REPLICATION_WARN_SEC, OpmPgConst.LABEL_REPLICATION_WARN_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_WARN_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_REPLICATION_WARN_DURATION_SEC, OpmPgConst.LABEL_REPLICATION_WARN_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_WARN_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_REPLICATION_MINOR_SEC, OpmPgConst.LABEL_REPLICATION_MINOR_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_MINOR_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_REPLICATION_MINOR_DURATION_SEC, OpmPgConst.LABEL_REPLICATION_MINOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_MINOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_REPLICATION_MAJOR_SEC, OpmPgConst.LABEL_REPLICATION_MAJOR_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_MAJOR_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_REPLICATION_MAJOR_DURATION_SEC, OpmPgConst.LABEL_REPLICATION_MAJOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_MAJOR_DURATION_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_REPLICATION_CRITICAL_SEC, OpmPgConst.LABEL_REPLICATION_CRITICAL_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_CRITICAL_SEC)));
        defs.add(new OpmParamDef(OpmPgConst.CONF_REPLICATION_CRITICAL_DURATION_SEC, OpmPgConst.LABEL_REPLICATION_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_CRITICAL_DURATION_SEC)));

        defs.add(new OpmParamDef(OpmPgConst.CONF_RULE_COOLDOWN_SEC, OpmPgConst.LABEL_RULE_COOLDOWN_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_RULE_COOLDOWN_SEC)));
        return defs;
    }

    @Override
    public String getSampleConfigComment()
    {
        return OpmConfigXmlBuilder.buildModuleSample("pg", "PG数据库监控", "cell.bap.opm.collector.pg.IOpmPgCollector", getConfigGroup());
    }

    @Override
    public OpmConfigGroup getConfigGroup()
    {
        OpmConfigGroup root = new OpmConfigGroup(getCollectorKey(), getCollectorLabel())
                .setDesc("采集 PostgreSQL 的运行状态、长 SQL、锁等待、连接占用、空间使用和复制延迟等指标，并基于阈值输出数据库监控结果与告警。适合数据库巡检与性能排障。")
                .setExtraText("当前连接库：" + resolveDefaultDbName());

        root.addParam(new OpmParamDef(OpmPgConst.CONF_ENABLE, OpmPgConst.LABEL_ENABLE, "boolean", String.valueOf(OpmPgConst.DEFAULT_ENABLE)));
        OpmConfigGroup highFreqGroup = new OpmConfigGroup("highFreq", "高频监控")
                .setDesc("用于需要较高实时性的采集与告警项，例如长 SQL、锁等待、死锁、连接占用、复制延迟等。该组沿用主采集周期。 ");
        highFreqGroup.addParam(new OpmParamDef(OpmPgConst.CONF_COLLECT_INTERVAL_SEC, OpmPgConst.LABEL_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_COLLECT_INTERVAL_SEC)));

        OpmConfigGroup lowFreqGroup = new OpmConfigGroup("lowFreq", "低频监控")
                .setDesc("用于变化较慢、无需每轮采集的指标，例如数据库大小、表空间占用等。该组使用低频采集周期，减少不必要损耗。 ");
        lowFreqGroup.addParam(new OpmParamDef(OpmPgConst.CONF_LOW_FREQ_COLLECT_INTERVAL_SEC, OpmPgConst.LABEL_LOW_FREQ_COLLECT_INTERVAL_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_LOW_FREQ_COLLECT_INTERVAL_SEC)));

        OpmConfigGroup sqlGroup = new OpmConfigGroup("sql", "长时SQL告警")
                .setDesc("高频采集的实时监控组。基于数据库中最长 SQL 执行时长进行分级告警，用于发现慢 SQL、阻塞前兆和执行异常。下方参数仅用于配置各告警级别的时长门限，达到门限即立即告警。 ");
        sqlGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SQL_ENABLE, OpmPgConst.LABEL_SQL_ENABLE, "boolean", String.valueOf(OpmPgConst.DEFAULT_SQL_ENABLE)));
        sqlGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SQL_WARN_SEC, OpmPgConst.LABEL_SQL_WARN_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_WARN_SEC)));
        sqlGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SQL_MINOR_SEC, OpmPgConst.LABEL_SQL_MINOR_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_MINOR_SEC)));
        sqlGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SQL_MAJOR_SEC, OpmPgConst.LABEL_SQL_MAJOR_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_MAJOR_SEC)));
        sqlGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SQL_CRITICAL_SEC, OpmPgConst.LABEL_SQL_CRITICAL_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_CRITICAL_SEC)));
        sqlGroup.addParam(new OpmParamDef(OpmPgConst.CONF_STORE_SQL_DETAIL, OpmPgConst.LABEL_STORE_SQL_DETAIL, "boolean", String.valueOf(OpmPgConst.DEFAULT_STORE_SQL_DETAIL)));
        sqlGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SQL_DETAIL_MAX_ROWS, OpmPgConst.LABEL_SQL_DETAIL_MAX_ROWS, "int", String.valueOf(OpmPgConst.DEFAULT_SQL_DETAIL_MAX_ROWS)));
        highFreqGroup.addGroup(sqlGroup);

        OpmConfigGroup spaceGroup = new OpmConfigGroup("space", "空间与低频健康告警")
                .setDesc("监控数据库大小、表空间占用等低频变化指标。这类信息变化较慢，建议按低频采集周期执行，用于容量规划与提前预警。 ");
        spaceGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SPACE_ENABLE, OpmPgConst.LABEL_SPACE_ENABLE, "boolean", String.valueOf(OpmPgConst.DEFAULT_SPACE_ENABLE)));
        spaceGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SPACE_WARN_RATE, OpmPgConst.LABEL_SPACE_WARN_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_SPACE_WARN_RATE)));
        spaceGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SPACE_WARN_DURATION_SEC, OpmPgConst.LABEL_SPACE_WARN_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SPACE_WARN_DURATION_SEC)));
        spaceGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SPACE_MINOR_RATE, OpmPgConst.LABEL_SPACE_MINOR_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_SPACE_MINOR_RATE)));
        spaceGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SPACE_MINOR_DURATION_SEC, OpmPgConst.LABEL_SPACE_MINOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SPACE_MINOR_DURATION_SEC)));
        spaceGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SPACE_MAJOR_RATE, OpmPgConst.LABEL_SPACE_MAJOR_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_SPACE_MAJOR_RATE)));
        spaceGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SPACE_MAJOR_DURATION_SEC, OpmPgConst.LABEL_SPACE_MAJOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SPACE_MAJOR_DURATION_SEC)));
        spaceGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SPACE_CRITICAL_RATE, OpmPgConst.LABEL_SPACE_CRITICAL_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_SPACE_CRITICAL_RATE)));
        spaceGroup.addParam(new OpmParamDef(OpmPgConst.CONF_SPACE_CRITICAL_DURATION_SEC, OpmPgConst.LABEL_SPACE_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_SPACE_CRITICAL_DURATION_SEC)));
        lowFreqGroup.addGroup(spaceGroup);

        OpmConfigGroup deadlockGroup = new OpmConfigGroup("deadlock", "死锁监控")
                .setDesc("严格依据 PostgreSQL 自身的死锁统计增量判定是否发生新死锁，并在发现新增死锁后尽可能回溯最近采集到的持锁语句、锁等待边和相关 SQL，记录可能导致死锁的 SQL 供排查。 ");
        deadlockGroup.addParam(new OpmParamDef(OpmPgConst.CONF_DEADLOCK_WARN_COUNT, OpmPgConst.LABEL_DEADLOCK_WARN_COUNT, "int", String.valueOf(OpmPgConst.DEFAULT_DEADLOCK_WARN_COUNT)));
        deadlockGroup.addParam(new OpmParamDef(OpmPgConst.CONF_DEADLOCK_MINOR_COUNT, OpmPgConst.LABEL_DEADLOCK_MINOR_COUNT, "int", String.valueOf(OpmPgConst.DEFAULT_DEADLOCK_MINOR_COUNT)));
        deadlockGroup.addParam(new OpmParamDef(OpmPgConst.CONF_DEADLOCK_MAJOR_COUNT, OpmPgConst.LABEL_DEADLOCK_MAJOR_COUNT, "int", String.valueOf(OpmPgConst.DEFAULT_DEADLOCK_MAJOR_COUNT)));
        deadlockGroup.addParam(new OpmParamDef(OpmPgConst.CONF_DEADLOCK_CRITICAL_COUNT, OpmPgConst.LABEL_DEADLOCK_CRITICAL_COUNT, "int", String.valueOf(OpmPgConst.DEFAULT_DEADLOCK_CRITICAL_COUNT)));
        highFreqGroup.addGroup(deadlockGroup);

        OpmConfigGroup connGroup = new OpmConfigGroup("conn", "高频监控-连接告警")
                .setDesc("监控数据库连接数占用率，避免连接池或数据库最大连接数被打满，影响业务建立新连接。下方参数用于配置不同等级的连接占用率门限。 ");
        connGroup.addParam(new OpmParamDef(OpmPgConst.CONF_CONN_ENABLE, OpmPgConst.LABEL_CONN_ENABLE, "boolean", String.valueOf(OpmPgConst.DEFAULT_CONN_ENABLE)));
        connGroup.addParam(new OpmParamDef(OpmPgConst.CONF_CONN_WARN_RATE, OpmPgConst.LABEL_CONN_WARN_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_CONN_WARN_RATE)));
        connGroup.addParam(new OpmParamDef(OpmPgConst.CONF_CONN_WARN_DURATION_SEC, OpmPgConst.LABEL_CONN_WARN_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_CONN_WARN_DURATION_SEC)));
        connGroup.addParam(new OpmParamDef(OpmPgConst.CONF_CONN_MINOR_RATE, OpmPgConst.LABEL_CONN_MINOR_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_CONN_MINOR_RATE)));
        connGroup.addParam(new OpmParamDef(OpmPgConst.CONF_CONN_MINOR_DURATION_SEC, OpmPgConst.LABEL_CONN_MINOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_CONN_MINOR_DURATION_SEC)));
        connGroup.addParam(new OpmParamDef(OpmPgConst.CONF_CONN_MAJOR_RATE, OpmPgConst.LABEL_CONN_MAJOR_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_CONN_MAJOR_RATE)));
        connGroup.addParam(new OpmParamDef(OpmPgConst.CONF_CONN_MAJOR_DURATION_SEC, OpmPgConst.LABEL_CONN_MAJOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_CONN_MAJOR_DURATION_SEC)));
        connGroup.addParam(new OpmParamDef(OpmPgConst.CONF_CONN_CRITICAL_RATE, OpmPgConst.LABEL_CONN_CRITICAL_RATE, "string", String.valueOf(OpmPgConst.DEFAULT_CONN_CRITICAL_RATE)));
        connGroup.addParam(new OpmParamDef(OpmPgConst.CONF_CONN_CRITICAL_DURATION_SEC, OpmPgConst.LABEL_CONN_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_CONN_CRITICAL_DURATION_SEC)));
        highFreqGroup.addGroup(connGroup);

        OpmConfigGroup replGroup = new OpmConfigGroup("replication", "高频监控-复制延迟告警")
                .setDesc("监控主从复制延迟，适用于有只读副本、容灾链路或一致性要求较高的场景。默认关闭，启用后才会采集复制延迟并参与状态计算和告警判断。 ");
        replGroup.addParam(new OpmParamDef(OpmPgConst.CONF_REPLICATION_ENABLE, OpmPgConst.LABEL_REPLICATION_ENABLE, "boolean", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_ENABLE)));
        replGroup.addParam(new OpmParamDef(OpmPgConst.CONF_REPLICATION_WARN_SEC, OpmPgConst.LABEL_REPLICATION_WARN_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_WARN_SEC)));
        replGroup.addParam(new OpmParamDef(OpmPgConst.CONF_REPLICATION_WARN_DURATION_SEC, OpmPgConst.LABEL_REPLICATION_WARN_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_WARN_DURATION_SEC)));
        replGroup.addParam(new OpmParamDef(OpmPgConst.CONF_REPLICATION_MINOR_SEC, OpmPgConst.LABEL_REPLICATION_MINOR_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_MINOR_SEC)));
        replGroup.addParam(new OpmParamDef(OpmPgConst.CONF_REPLICATION_MINOR_DURATION_SEC, OpmPgConst.LABEL_REPLICATION_MINOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_MINOR_DURATION_SEC)));
        replGroup.addParam(new OpmParamDef(OpmPgConst.CONF_REPLICATION_MAJOR_SEC, OpmPgConst.LABEL_REPLICATION_MAJOR_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_MAJOR_SEC)));
        replGroup.addParam(new OpmParamDef(OpmPgConst.CONF_REPLICATION_MAJOR_DURATION_SEC, OpmPgConst.LABEL_REPLICATION_MAJOR_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_MAJOR_DURATION_SEC)));
        replGroup.addParam(new OpmParamDef(OpmPgConst.CONF_REPLICATION_CRITICAL_SEC, OpmPgConst.LABEL_REPLICATION_CRITICAL_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_CRITICAL_SEC)));
        replGroup.addParam(new OpmParamDef(OpmPgConst.CONF_REPLICATION_CRITICAL_DURATION_SEC, OpmPgConst.LABEL_REPLICATION_CRITICAL_DURATION_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_REPLICATION_CRITICAL_DURATION_SEC)));
        highFreqGroup.addGroup(replGroup);

        root.addGroup(highFreqGroup);
        root.addGroup(lowFreqGroup);

        root.addParam(new OpmParamDef(OpmPgConst.CONF_RULE_COOLDOWN_SEC, OpmPgConst.LABEL_RULE_COOLDOWN_SEC, "int", String.valueOf(OpmPgConst.DEFAULT_RULE_COOLDOWN_SEC)));

        return root;
    }

    @Override
    public List<Class> getModelClasses()
    {
        List<Class> classes = new ArrayList<Class>();
        classes.add(OpmPgMetricDo.class);
        classes.add(OpmPgSqlDetailDo.class);
        classes.add(OpmPgLockDetailDo.class);
        classes.add(OpmPgAlarmExtDo.class);
        return classes;
    }

    @Override
    public void loadConfig()
    {
        _enable = OpmPgConst.isEnable();
        _collectIntervalMs = OpmPgConst.getCollectIntervalMs();
        _dbName = resolveDefaultDbName();
        _lowFreqCollectIntervalMs = OpmPgConst.getLowFreqCollectIntervalMs();
        _storeSqlDetail = OpmPgConst.isStoreSqlDetail();
        _sqlDetailMaxRows = OpmPgConst.getSqlDetailMaxRows();

        _sqlWarnSec = OpmPgConst.getSqlWarnSec();
        _sqlMinorSec = OpmPgConst.getSqlMinorSec();
        _sqlMajorSec = OpmPgConst.getSqlMajorSec();
        _sqlCriticalSec = OpmPgConst.getSqlCriticalSec();

        _spaceWarnRate = OpmPgConst.getSpaceWarnRate();
        _spaceWarnDurationSec = OpmPgConst.getSpaceWarnDurationSec();
        _spaceMinorRate = OpmPgConst.getSpaceMinorRate();
        _spaceMinorDurationSec = OpmPgConst.getSpaceMinorDurationSec();
        _spaceMajorRate = OpmPgConst.getSpaceMajorRate();
        _spaceMajorDurationSec = OpmPgConst.getSpaceMajorDurationSec();
        _spaceCriticalRate = OpmPgConst.getSpaceCriticalRate();
        _spaceCriticalDurationSec = OpmPgConst.getSpaceCriticalDurationSec();

        _deadlockWarnCount = OpmPgConst.getDeadlockWarnCount();
        _deadlockMinorCount = OpmPgConst.getDeadlockMinorCount();
        _deadlockMajorCount = OpmPgConst.getDeadlockMajorCount();
        _deadlockCriticalCount = OpmPgConst.getDeadlockCriticalCount();

        _connWarnRate = OpmPgConst.getConnWarnRate();
        _connWarnDurationSec = OpmPgConst.getConnWarnDurationSec();
        _connMinorRate = OpmPgConst.getConnMinorRate();
        _connMinorDurationSec = OpmPgConst.getConnMinorDurationSec();
        _connMajorRate = OpmPgConst.getConnMajorRate();
        _connMajorDurationSec = OpmPgConst.getConnMajorDurationSec();
        _connCriticalRate = OpmPgConst.getConnCriticalRate();
        _connCriticalDurationSec = OpmPgConst.getConnCriticalDurationSec();

        _replicationWarnSec = OpmPgConst.getReplicationWarnSec();
        _replicationWarnDurationSec = OpmPgConst.getReplicationWarnDurationSec();
        _replicationMinorSec = OpmPgConst.getReplicationMinorSec();
        _replicationMinorDurationSec = OpmPgConst.getReplicationMinorDurationSec();
        _replicationMajorSec = OpmPgConst.getReplicationMajorSec();
        _replicationMajorDurationSec = OpmPgConst.getReplicationMajorDurationSec();
        _replicationCriticalSec = OpmPgConst.getReplicationCriticalSec();
        _replicationCriticalDurationSec = OpmPgConst.getReplicationCriticalDurationSec();
        _replicationEnable = OpmPgConst.isReplicationEnable();
    }

    @Override
    public OpmCollectResult collect(OpmAgentContext agentCtx) throws Exception
    {
        long begin = System.nanoTime();
        loadConfig();
        if (!_enable)
        {
            return null;
        }

        long now = System.currentTimeMillis();
        OpmPgMetricDo ext = new OpmPgMetricDo();
        ext.collectorKey = getCollectorKey();
        ext.collectorLabel = getCollectorLabel();
        ext.agentCode = agentCtx == null ? null : agentCtx.getAgentCode();
        ext.agentName = agentCtx == null ? null : agentCtx.getAgentName();
        ext.myUri = agentCtx == null ? null : agentCtx.getMyUri();
        ext.collectTime = now;
        ext.dbName = _dbName;

        Map<String, Object> detail = new LinkedHashMap<String, Object>();
        boolean collectError = false;

        try (IDao dao = IDaoService.newIDao())
        {
            collectLongSql(dao, ext, detail);
            collectLock(dao, ext, detail);
            collectConnection(dao, ext, detail);
            collectTransaction(dao, ext, detail);
            collectReplication(dao, ext, detail);
            collectLowFrequencyMetrics(dao, ext, detail, now);

            dao.commit();
        }
        catch (Exception e)
        {
            ToolUtilities.warning("OPM", "PG collect error: " + e.getMessage(), e);
            collectError = true;
            detail.put("collectError", Boolean.TRUE);
            detail.put("collectErrorMessage", e.getMessage());
            detail.put("collectErrorClass", e.getClass().getName());
            detail.put("collectErrorDetail", ToolBasic.getExceptionStatck(e, true));
        }

        ext.detailJson = CJson.toJson(detail);
        ext.summary = buildSummary(ext);

        OpmCollectResult result = new OpmCollectResult();
        result.collectorKey = getCollectorKey();
        result.collectorLabel = getCollectorLabel();
        result.collectTime = now;
        result.collectCostMs = (System.nanoTime() - begin) / 1000000L;
        result.metricExt = ext;
        result.summary = ext.summary;
        result.status = collectError ? OpmConst.STATUS_ERROR : OpmConst.STATUS_NORMAL;
        return result;
    }

    protected String resolveConfiguredDbName()
    {
        String dbName = OpmPgConst.getDbName();
        if (!ToolUtilities.isStringEmpty(dbName, true) && !OpmPgConst.DEFAULT_DB_NAME.equalsIgnoreCase(dbName.trim()))
            return dbName.trim();
        return resolveDefaultDbName();
    }

    protected String resolveDefaultDbName()
    {
        try (IDao dao = IDaoService.newIDao())
        {
            String currentDb = dao.queryString("SELECT current_database()", null, null, null);
            if (!ToolUtilities.isStringEmpty(currentDb, true))
                return currentDb.trim();
        }
        catch (Throwable err)
        {
            ToolUtilities.warning("OPM", "Resolve PostgreSQL current_database failed: " + err.getMessage(), err);
        }
        return OpmPgConst.DEFAULT_DB_NAME;
    }

    protected void collectLongSql(IDao dao, OpmPgMetricDo ext, Map<String, Object> detail) throws Exception
    {
        String sql = PgSqlQueries.queryLongSql(_sqlWarnSec, _sqlDetailMaxRows);
        MultiPageResult<DataRow> rs = dao.queryRows(sql, null, null, 0, _sqlDetailMaxRows);

        List<Map<String, Object>> sqlList = new ArrayList<Map<String, Object>>();
        double maxDuration = 0D;
        int count = 0;

        if (rs != null && rs.getListData() != null)
        {
            for (DataRow row : rs.getListData())
            {
                Map<String, Object> item = new LinkedHashMap<String, Object>();
                item.put("pid", row.get("pid"));
                item.put("query", row.get("query"));
                item.put("state", row.get("state"));
                item.put("durationSec", row.get("duration_sec"));
                item.put("waitEventType", row.get("wait_event_type"));
                item.put("waitEvent", row.get("wait_event"));
                item.put("applicationName", row.get("application_name"));
                item.put("clientAddr", row.get("client_addr"));
                sqlList.add(item);

                Double dur = ToolUtilities.getDouble(row.get("duration_sec"), 0D);
                if (dur > maxDuration)
                {
                    maxDuration = dur;
                }
                count++;
            }
        }

        ext.longSqlCount = count;
        ext.maxSqlDurationSec = maxDuration;
        detail.put("longSqls", sqlList);
        Map<String, Object> topSql = pickTopLongSql(sqlList);
        if (topSql != null)
        {
            detail.put(DETAIL_KEY_TOP_LONG_SQL, topSql);
            detail.put(DETAIL_KEY_LONG_SQL_SUPPRESS_KEY, buildLongSqlSuppressKey(ext.dbName, topSql));
        }

        if (_storeSqlDetail && count > 0)
            detail.put("_pendingSqlDetails", sqlList);

        String blockedSql = PgSqlQueries.queryBlockedSql();
        Object blockedCount = dao.queryFirst(blockedSql, null, null);
        ext.blockedSqlCount = ToolUtilities.getInteger(blockedCount, 0);
        detail.put("blockedSqlCount", ext.blockedSqlCount);
    }

    protected void collectSpace(IDao dao, OpmPgMetricDo ext, Map<String, Object> detail) throws Exception
    {
        String dbSizeSql = PgSqlQueries.queryDbSize();
        MultiPageResult<DataRow> rs = dao.queryRows(dbSizeSql, null, null, 0, 100);

        long totalSize = 0L;
        List<Map<String, Object>> dbList = new ArrayList<Map<String, Object>>();
        if (rs != null && rs.getListData() != null)
        {
            for (DataRow row : rs.getListData())
            {
                Map<String, Object> item = new LinkedHashMap<String, Object>();
                item.put("datname", row.get("datname"));
                item.put("sizeBytes", row.get("size_bytes"));
                dbList.add(item);

                Long size = ToolUtilities.getLong(row.get("size_bytes"), 0L);
                totalSize += size;
            }
        }
        ext.dbSizeBytes = totalSize;
        detail.put("databases", dbList);

        String tablespaceSql = PgSqlQueries.queryTablespaceSize();
        rs = dao.queryRows(tablespaceSql, null, null, 0, 100);
        double maxTsUsage = 0D;
        if (rs != null && rs.getListData() != null)
        {
            for (DataRow row : rs.getListData())
            {
                Long size = ToolUtilities.getLong(row.get("size_bytes"), 0L);
                double usageRate = size > 0L ? (double) size / (100L * 1024 * 1024 * 1024) : 0D;
                if (usageRate > maxTsUsage)
                {
                    maxTsUsage = usageRate;
                }
            }
        }
        ext.tablespaceUsageRate = maxTsUsage;
    }

    protected void collectLowFrequencyMetrics(IDao dao, OpmPgMetricDo ext, Map<String, Object> detail, long now) throws Exception
    {
        boolean needRefresh = _lastLowFreqCollectTime <= 0L || now - _lastLowFreqCollectTime >= _lowFreqCollectIntervalMs;
        if (needRefresh)
        {
            collectSpace(dao, ext, detail);

            _lastDbSizeBytes = ToolUtilities.getLong(ext.dbSizeBytes, 0L);
            _lastTablespaceUsageRate = ToolUtilities.getDouble(ext.tablespaceUsageRate, 0D);
            _lastLowFreqCollectTime = now;
        }
        else
        {
            ext.dbSizeBytes = Long.valueOf(_lastDbSizeBytes);
            ext.tablespaceUsageRate = Double.valueOf(_lastTablespaceUsageRate);
            detail.put("lowFreqCached", Boolean.TRUE);
        }
    }

    protected void collectLock(IDao dao, OpmPgMetricDo ext, Map<String, Object> detail) throws Exception
    {
        int detailLimit = resolveDeadlockSnapshotLimit();
        String lockSql = PgSqlQueries.queryLockWait(detailLimit);
        MultiPageResult<DataRow> rs = dao.queryRows(lockSql, null, null, 0, detailLimit);

        List<Map<String, Object>> lockList = new ArrayList<Map<String, Object>>();
        double maxWait = 0D;
        int count = 0;

        if (rs != null && rs.getListData() != null)
        {
            for (DataRow row : rs.getListData())
            {
                Map<String, Object> item = new LinkedHashMap<String, Object>();
                item.put("blockedPid", row.get("blocked_pid"));
                item.put("blockedUserName", row.get("blocked_user_name"));
                item.put("blockedApplicationName", row.get("blocked_application_name"));
                item.put("blockedClientAddr", row.get("blocked_client_addr"));
                item.put("blockedState", row.get("blocked_state"));
                item.put("blockedWaitEventType", row.get("blocked_wait_event_type"));
                item.put("blockedWaitEvent", row.get("blocked_wait_event"));
                item.put("blockedBackendXid", row.get("blocked_backend_xid"));
                item.put("blockedBackendXmin", row.get("blocked_backend_xmin"));
                item.put("blockedQuery", row.get("blocked_query"));
                item.put("blockingPid", row.get("blocking_pid"));
                item.put("blockingUserName", row.get("blocking_user_name"));
                item.put("blockingApplicationName", row.get("blocking_application_name"));
                item.put("blockingClientAddr", row.get("blocking_client_addr"));
                item.put("blockingState", row.get("blocking_state"));
                item.put("blockingWaitEventType", row.get("blocking_wait_event_type"));
                item.put("blockingWaitEvent", row.get("blocking_wait_event"));
                item.put("blockingBackendXid", row.get("blocking_backend_xid"));
                item.put("blockingBackendXmin", row.get("blocking_backend_xmin"));
                item.put("blockingQuery", row.get("blocking_query"));
                item.put("waitSec", row.get("wait_sec"));
                item.put("lockType", row.get("lock_type"));
                item.put("lockMode", row.get("lock_mode"));
                item.put("relationName", row.get("relation_name"));
                item.put("page", row.get("page"));
                item.put("tuple", row.get("tuple"));
                item.put("virtualXid", row.get("virtual_xid"));
                item.put("transactionId", row.get("transaction_id"));
                lockList.add(item);

                Double wait = ToolUtilities.getDouble(row.get("wait_sec"), 0D);
                if (wait > maxWait)
                {
                    maxWait = wait;
                }
                count++;
            }
        }

        ext.lockWaitCount = count;
        ext.maxLockWaitSec = maxWait;
        detail.put("lockWaits", lockList);
        cacheRecentLockWaits(ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue(), lockList);

        List<Map<String, Object>> tableLockSqls = queryTableLockRelatedSqls(dao, detailLimit);
        detail.put("tableLockSqls", tableLockSqls);
        cacheRecentTableLockSqls(ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue(), tableLockSqls);

        if (count > 0)
            detail.put("_pendingLockDetails", lockList);

        String deadlockSql = PgSqlQueries.queryDeadlockStats();
        rs = dao.queryRows(deadlockSql, null, null, 0, 1);
        if (rs != null && rs.getListData() != null && !rs.getListData().isEmpty())
        {
            DataRow row = rs.getListData().get(0);
            ext.deadlockCount = ToolUtilities.getInteger(row.get("deadlocks"), 0);
        }
        int currentDeadlockCount = ToolUtilities.getInteger(ext.deadlockCount, 0);
        if (_lastDeadlockCount < 0)
            ext.deadlockDeltaCount = Integer.valueOf(0);
        else
            ext.deadlockDeltaCount = Integer.valueOf(Math.max(0, currentDeadlockCount - _lastDeadlockCount));
        _lastDeadlockCount = currentDeadlockCount;
        detail.put("deadlockCount", ext.deadlockCount);
        detail.put("deadlockDeltaCount", ext.deadlockDeltaCount);

        if (ToolUtilities.getInteger(ext.deadlockDeltaCount, 0) > 0)
            collectDeadlockSnapshot(dao, ext, detail);
    }

    protected void collectDeadlockSnapshot(IDao dao, OpmPgMetricDo ext, Map<String, Object> detail) throws Exception
    {
        int limit = resolveDeadlockSnapshotLimit();
        int sampleRounds = 6;
        long waitMillis = 80L;

        LinkedHashMap<String, Map<String, Object>> sessionMap = new LinkedHashMap<String, Map<String, Object>>();
        LinkedHashMap<String, Map<String, Object>> lockMap = new LinkedHashMap<String, Map<String, Object>>();
        LinkedHashMap<String, Map<String, Object>> edgeMap = new LinkedHashMap<String, Map<String, Object>>();

        for (int round = 1; round <= sampleRounds; round++)
        {
            mergeDeadlockRows(sessionMap, queryDeadlockSessionSnapshot(dao, limit), true, round, limit);
            List<Map<String, Object>> edgeList = queryDeadlockLockSnapshot(dao, limit);
            mergeDeadlockRows(lockMap, edgeList, false, round, limit);
            mergeDeadlockEdges(edgeMap, edgeList, round, limit);

            if (round >= sampleRounds)
                continue;
            if (edgeMap.size() >= limit && sessionMap.size() >= limit)
                break;

            try
            {
                Thread.sleep(waitMillis);
            }
            catch (InterruptedException err)
            {
                Thread.currentThread().interrupt();
                break;
            }
        }

        if (edgeMap.isEmpty())
        {
            List<Map<String, Object>> fallbackEdges = pickRecentLockWaits(ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue(), limit);
            mergeDeadlockRows(lockMap, fallbackEdges, false, 0, limit);
            mergeDeadlockEdges(edgeMap, fallbackEdges, 0, limit);
        }

        List<Map<String, Object>> relatedSqls = queryRelatedRunningSqls(dao, edgeMap, limit);
        List<Map<String, Object>> tableLockSqls = queryTableLockRelatedSqls(dao, limit);
        List<Map<String, Object>> idleTxnHints = queryIdleInTransactionHints(dao, limit);
        if (tableLockSqls.isEmpty())
            tableLockSqls = pickRecentTableLockSqls(ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue(), limit);
        List<Map<String, Object>> suspectSqls = buildSuspectedSqlCandidates(tableLockSqls, relatedSqls, idleTxnHints, edgeMap);
        String suspectSql = pickTopSuspectedSql(suspectSqls, edgeMap);
        detail.put("deadlockPairs", buildDeadlockPairs(edgeMap));
        detail.put("deadlockEdges", trimMapList(new ArrayList<Map<String, Object>>(edgeMap.values()), limit));
        detail.put("deadlockRelatedSqls", trimMapList(relatedSqls, limit));
        detail.put("deadlockTableLockSqls", trimMapList(tableLockSqls, limit));
        detail.put("deadlockIdleTxnHints", trimMapList(idleTxnHints, limit));
        detail.put("deadlockRecentLockWaits", pickRecentLockWaits(ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue(), limit));
        detail.put("deadlockRecentTableLockSqls", pickRecentTableLockSqls(ext.collectTime == null ? System.currentTimeMillis() : ext.collectTime.longValue(), limit));
        detail.put("deadlockSuspectSqls", trimMapList(suspectSqls, limit));
        detail.put("deadlockSuspectSql", truncateString(suspectSql, 4000));
    }

    protected int resolveDeadlockSnapshotLimit()
    {
        return 200;
    }

    protected List<Map<String, Object>> buildSuspectedSqlCandidates(List<Map<String, Object>> tableLockSqls,
            List<Map<String, Object>> relatedSqls,
            List<Map<String, Object>> idleTxnHints,
            LinkedHashMap<String, Map<String, Object>> edgeMap)
    {
        LinkedHashMap<String, Map<String, Object>> merged = new LinkedHashMap<String, Map<String, Object>>();
        mergeSuspectedSqlSource(merged, tableLockSqls, edgeMap, true, null);
        mergeSuspectedSqlSource(merged, relatedSqls, edgeMap, false, null);
        mergeSuspectedSqlSource(merged, idleTxnHints, edgeMap, false, null, true);

        ArrayList<Map<String, Object>> list = new ArrayList<Map<String, Object>>(merged.values());
        java.util.Collections.sort(list, (a, b) -> ToolUtilities.getInteger(b.get("suspectScore"), 0)
                - ToolUtilities.getInteger(a.get("suspectScore"), 0));
        return list;
    }

    protected String pickTopSuspectedSql(List<Map<String, Object>> suspectSqls,
            LinkedHashMap<String, Map<String, Object>> edgeMap)
    {
        if (suspectSqls != null)
        {
            for (Map<String, Object> one : suspectSqls)
            {
                String query = ToolUtilities.getString(one == null ? null : one.get("query"), null);
                if (!ToolUtilities.isStringEmpty(query, true))
                    return query;
            }
        }
        return pickDeadlockQueryFromEdges(edgeMap);
    }

    protected String pickDeadlockQueryFromEdges(LinkedHashMap<String, Map<String, Object>> edgeMap)
    {
        if (edgeMap == null || edgeMap.isEmpty())
            return null;
        for (Map<String, Object> edge : edgeMap.values())
        {
            if (edge == null)
                continue;
            String blockedQuery = ToolUtilities.getString(edge.get("blockedQuery"), null);
            if (!ToolUtilities.isStringEmpty(blockedQuery, true))
                return blockedQuery;
            String blockingQuery = ToolUtilities.getString(edge.get("blockingQuery"), null);
            if (!ToolUtilities.isStringEmpty(blockingQuery, true))
                return blockingQuery;
        }
        return null;
    }

    protected List<Map<String, Object>> queryDeadlockSessionSnapshot(IDao dao, int limit) throws Exception
    {
        String sql = PgSqlQueries.queryDeadlockSessionSnapshot(limit);
        MultiPageResult<DataRow> rs = dao.queryRows(sql, null, null, 0, limit);
        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        if (rs == null || rs.getListData() == null)
            return ret;

        for (DataRow row : rs.getListData())
        {
            LinkedHashMap<String, Object> item = new LinkedHashMap<String, Object>();
            item.put("pid", row.get("pid"));
            item.put("userName", row.get("user_name"));
            item.put("applicationName", row.get("application_name"));
            item.put("clientAddr", row.get("client_addr"));
            item.put("state", row.get("state"));
            item.put("waitEventType", row.get("wait_event_type"));
            item.put("waitEvent", row.get("wait_event"));
            item.put("backendXid", row.get("backend_xid"));
            item.put("backendXmin", row.get("backend_xmin"));
            item.put("xactAgeSec", row.get("xact_age_sec"));
            item.put("queryAgeSec", row.get("query_age_sec"));
            item.put("stateAgeSec", row.get("state_age_sec"));
            item.put("blockingPids", parsePidList(row.get("blocking_pids")));
            item.put("query", row.get("query"));
            ret.add(item);
        }
        return ret;
    }

    protected List<Map<String, Object>> queryDeadlockLockSnapshot(IDao dao, int limit) throws Exception
    {
        String sql = PgSqlQueries.queryDeadlockLockSnapshot(limit);
        MultiPageResult<DataRow> rs = dao.queryRows(sql, null, null, 0, limit);
        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        if (rs == null || rs.getListData() == null)
            return ret;

        for (DataRow row : rs.getListData())
        {
            LinkedHashMap<String, Object> item = new LinkedHashMap<String, Object>();
            item.put("blockedPid", row.get("blocked_pid"));
            item.put("blockedUserName", row.get("blocked_user_name"));
            item.put("blockedApplicationName", row.get("blocked_application_name"));
            item.put("blockedClientAddr", row.get("blocked_client_addr"));
            item.put("blockedState", row.get("blocked_state"));
            item.put("blockedWaitEventType", row.get("blocked_wait_event_type"));
            item.put("blockedWaitEvent", row.get("blocked_wait_event"));
            item.put("blockedBackendXid", row.get("blocked_backend_xid"));
            item.put("blockedBackendXmin", row.get("blocked_backend_xmin"));
            item.put("blockedQuery", row.get("blocked_query"));
            item.put("blockingPid", row.get("blocking_pid"));
            item.put("blockingUserName", row.get("blocking_user_name"));
            item.put("blockingApplicationName", row.get("blocking_application_name"));
            item.put("blockingClientAddr", row.get("blocking_client_addr"));
            item.put("blockingState", row.get("blocking_state"));
            item.put("blockingWaitEventType", row.get("blocking_wait_event_type"));
            item.put("blockingWaitEvent", row.get("blocking_wait_event"));
            item.put("blockingBackendXid", row.get("blocking_backend_xid"));
            item.put("blockingBackendXmin", row.get("blocking_backend_xmin"));
            item.put("blockingQuery", row.get("blocking_query"));
            item.put("waitSec", row.get("wait_sec"));
            item.put("lockType", row.get("lock_type"));
            item.put("lockMode", row.get("lock_mode"));
            item.put("relationName", row.get("relation_name"));
            item.put("page", row.get("page"));
            item.put("tuple", row.get("tuple"));
            item.put("virtualXid", row.get("virtual_xid"));
            item.put("transactionId", row.get("transaction_id"));
            ret.add(item);
        }
        return ret;
    }

    protected void mergeDeadlockRows(LinkedHashMap<String, Map<String, Object>> target,
            List<Map<String, Object>> src, boolean sessionRow, int sampleRound, int maxRows)
    {
        if (target == null || src == null || src.isEmpty())
            return;

        for (Map<String, Object> item : src)
        {
            if (item == null)
                continue;

            String key = sessionRow ? buildDeadlockSessionKey(item) : buildDeadlockLockKey(item);
            if (ToolUtilities.isStringEmpty(key, true) || target.containsKey(key))
                continue;

            item.put("sampleRound", Integer.valueOf(sampleRound));
            target.put(key, item);
            if (target.size() >= maxRows)
                return;
        }
    }

    protected String buildDeadlockSessionKey(Map<String, Object> item)
    {
        StringBuilder sb = new StringBuilder();
        sb.append(ToolUtilities.getString(item.get("pid"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("state"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("backendXid"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("query"), ""));
        return sb.toString();
    }

    protected String buildDeadlockLockKey(Map<String, Object> item)
    {
        StringBuilder sb = new StringBuilder();
        sb.append(ToolUtilities.getString(item.get("blockedPid"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("blockingPid"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("lockType"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("lockMode"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("relationName"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("page"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("tuple"), ""));
        sb.append('|').append(ToolUtilities.getString(item.get("transactionId"), ""));
        return sb.toString();
    }

    protected void mergeDeadlockEdges(LinkedHashMap<String, Map<String, Object>> target, List<Map<String, Object>> src,
            int sampleRound, int maxRows)
    {
        if (target == null || src == null || src.isEmpty())
            return;

        for (Map<String, Object> item : src)
        {
            if (item == null)
                continue;
            String key = ToolUtilities.getString(item.get("blockedPid"), "") + "->"
                    + ToolUtilities.getString(item.get("blockingPid"), "") + "|"
                    + ToolUtilities.getString(item.get("relationName"), "") + "|"
                    + ToolUtilities.getString(item.get("transactionId"), "");
            if (ToolUtilities.isStringEmpty(key, true) || target.containsKey(key))
                continue;

            LinkedHashMap<String, Object> edge = new LinkedHashMap<String, Object>();
            edge.put("sampleRound", Integer.valueOf(sampleRound));
            edge.put("blockedPid", item.get("blockedPid"));
            edge.put("blockedUserName", item.get("blockedUserName"));
            edge.put("blockedApplicationName", item.get("blockedApplicationName"));
            edge.put("blockedClientAddr", item.get("blockedClientAddr"));
            edge.put("blockedState", item.get("blockedState"));
            edge.put("blockedBackendXid", item.get("blockedBackendXid"));
            edge.put("blockedQuery", item.get("blockedQuery"));
            edge.put("blockingPid", item.get("blockingPid"));
            edge.put("blockingUserName", item.get("blockingUserName"));
            edge.put("blockingApplicationName", item.get("blockingApplicationName"));
            edge.put("blockingClientAddr", item.get("blockingClientAddr"));
            edge.put("blockingState", item.get("blockingState"));
            edge.put("blockingBackendXid", item.get("blockingBackendXid"));
            edge.put("blockingQuery", item.get("blockingQuery"));
            edge.put("waitSec", item.get("waitSec"));
            edge.put("lockType", item.get("lockType"));
            edge.put("lockMode", item.get("lockMode"));
            edge.put("relationName", item.get("relationName"));
            edge.put("page", item.get("page"));
            edge.put("tuple", item.get("tuple"));
            edge.put("virtualXid", item.get("virtualXid"));
            edge.put("transactionId", item.get("transactionId"));
            target.put(key, edge);
            if (target.size() >= maxRows)
                return;
        }
    }

    protected List<Map<String, Object>> buildDeadlockPairs(LinkedHashMap<String, Map<String, Object>> edgeMap)
    {
        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        if (edgeMap == null || edgeMap.isEmpty())
            return ret;

        LinkedHashMap<String, Map<String, Object>> used = new LinkedHashMap<String, Map<String, Object>>();
        for (Map<String, Object> edge : edgeMap.values())
        {
            if (edge == null)
                continue;
            String blockedPid = ToolUtilities.getString(edge.get("blockedPid"), null);
            String blockingPid = ToolUtilities.getString(edge.get("blockingPid"), null);
            if (ToolUtilities.isStringEmpty(blockedPid, true) || ToolUtilities.isStringEmpty(blockingPid, true))
                continue;

            String key = blockedPid + "->" + blockingPid;
            if (used.containsKey(key))
                continue;

            String reverseKey = blockingPid + "->" + blockedPid;
            Map<String, Object> reverse = null;
            for (Map<String, Object> one : edgeMap.values())
            {
                if (one == null)
                    continue;
                String oneKey = ToolUtilities.getString(one.get("blockedPid"), "") + "->"
                        + ToolUtilities.getString(one.get("blockingPid"), "");
                if (reverseKey.equals(oneKey))
                {
                    reverse = one;
                    break;
                }
            }
            if (reverse == null)
                continue;

            LinkedHashMap<String, Object> pair = new LinkedHashMap<String, Object>();
            pair.put("sessionA", buildDeadlockParticipant(edge, true));
            pair.put("sessionB", buildDeadlockParticipant(edge, false));
            pair.put("edgeAToB", edge);
            pair.put("edgeBToA", reverse);
            ret.add(pair);
            used.put(key, edge);
            used.put(reverseKey, reverse);
        }
        return ret;
    }

    protected Map<String, Object> buildDeadlockParticipant(Map<String, Object> edge, boolean blockedSide)
    {
        LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
        String prefix = blockedSide ? "blocked" : "blocking";
        map.put("pid", edge.get(prefix + "Pid"));
        map.put("userName", edge.get(prefix + "UserName"));
        map.put("applicationName", edge.get(prefix + "ApplicationName"));
        map.put("clientAddr", edge.get(prefix + "ClientAddr"));
        map.put("state", edge.get(prefix + "State"));
        map.put("backendXid", edge.get(prefix + "BackendXid"));
        map.put("query", edge.get(prefix + "Query"));
        return map;
    }

    protected void cacheRecentLockWaits(long captureTime, List<Map<String, Object>> lockWaits)
    {
        if (lockWaits == null || lockWaits.isEmpty())
            return;

        RecentLockWaitSnapshot one = new RecentLockWaitSnapshot();
        one.captureTime = captureTime;
        one.lockWaits = cloneMapList(lockWaits);

        synchronized (_recentLockWaitLock)
        {
            _recentLockWaitHistory.addFirst(one);
            while (_recentLockWaitHistory.size() > 8)
                _recentLockWaitHistory.removeLast();
        }
    }

    protected List<Map<String, Object>> pickRecentLockWaits(long collectTime, int limit)
    {
        long maxGapMs = Math.max(10000L, _collectIntervalMs * 2L);
        synchronized (_recentLockWaitLock)
        {
            if (_recentLockWaitHistory.isEmpty())
                return new ArrayList<Map<String, Object>>();

            for (RecentLockWaitSnapshot one : _recentLockWaitHistory)
            {
                if (one == null || one.lockWaits == null || one.lockWaits.isEmpty())
                    continue;
                if (Math.abs(collectTime - one.captureTime) > maxGapMs)
                    continue;
                return trimMapList(one.lockWaits, limit);
            }
        }
        return new ArrayList<Map<String, Object>>();
    }

    protected List<Map<String, Object>> queryRelatedRunningSqls(IDao dao, LinkedHashMap<String, Map<String, Object>> edgeMap, int limit) throws Exception
    {
        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        if (dao == null || edgeMap == null || edgeMap.isEmpty())
            return ret;

        LinkedHashSet<Integer> pidSet = new LinkedHashSet<Integer>();
        LinkedHashSet<String> xidSet = new LinkedHashSet<String>();
        LinkedHashSet<String> txIdSet = new LinkedHashSet<String>();
        for (Map<String, Object> edge : edgeMap.values())
        {
            if (edge == null)
                continue;
            addPositiveInt(pidSet, edge.get("blockedPid"));
            addPositiveInt(pidSet, edge.get("blockingPid"));
            addNonEmptyString(xidSet, edge.get("blockedBackendXid"));
            addNonEmptyString(xidSet, edge.get("blockingBackendXid"));
            addNonEmptyString(txIdSet, edge.get("transactionId"));
        }

        String sql = PgSqlQueries.querySessionByPidOrXid(buildPgIntArray(pidSet), buildPgTextArray(xidSet), buildPgTextArray(txIdSet), limit);
        if (ToolUtilities.isStringEmpty(sql, true))
            return ret;

        MultiPageResult<DataRow> rs = dao.queryRows(sql, null, null, 0, limit);
        if (rs == null || rs.getListData() == null)
            return ret;

        for (DataRow row : rs.getListData())
        {
            LinkedHashMap<String, Object> item = new LinkedHashMap<String, Object>();
            item.put("pid", row.get("pid"));
            item.put("userName", row.get("user_name"));
            item.put("applicationName", row.get("application_name"));
            item.put("clientAddr", row.get("client_addr"));
            item.put("state", row.get("state"));
            item.put("waitEventType", row.get("wait_event_type"));
            item.put("waitEvent", row.get("wait_event"));
            item.put("backendXid", row.get("backend_xid"));
            item.put("backendXmin", row.get("backend_xmin"));
            item.put("queryStartAgeSec", row.get("query_age_sec"));
            item.put("xactAgeSec", row.get("xact_age_sec"));
            item.put("blockingPids", parsePidList(row.get("blocking_pids")));
            item.put("query", row.get("query"));
            ret.add(item);
        }
        return ret;
    }

    protected List<Map<String, Object>> queryTableLockRelatedSqls(IDao dao, int limit) throws Exception
    {
        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        if (dao == null)
            return ret;

        String sql = PgSqlQueries.queryTableLockRelatedSql(limit);
        MultiPageResult<DataRow> rs = dao.queryRows(sql, null, null, 0, limit);
        if (rs == null || rs.getListData() == null)
            return ret;

        for (DataRow row : rs.getListData())
        {
            LinkedHashMap<String, Object> item = new LinkedHashMap<String, Object>();
            item.put("pid", row.get("pid"));
            item.put("state", row.get("state"));
            item.put("userName", row.get("user_name"));
            item.put("applicationName", row.get("application_name"));
            item.put("clientAddr", row.get("client_addr"));
            item.put("waitEventType", row.get("wait_event_type"));
            item.put("waitEvent", row.get("wait_event"));
            item.put("backendXid", row.get("backend_xid"));
            item.put("backendXmin", row.get("backend_xmin"));
            item.put("queryAgeSec", row.get("query_age_sec"));
            item.put("xactAgeSec", row.get("xact_age_sec"));
            item.put("blockingPids", parsePidList(row.get("blocking_pids")));
            item.put("relationNames", row.get("relation_names"));
            item.put("query", row.get("query"));
            ret.add(item);
        }
        return ret;
    }

    protected List<Map<String, Object>> queryIdleInTransactionHints(IDao dao, int limit) throws Exception
    {
        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        if (dao == null)
            return ret;

        String sql = PgSqlQueries.queryIdleInTransactionSql(limit);
        MultiPageResult<DataRow> rs = dao.queryRows(sql, null, null, 0, limit);
        if (rs == null || rs.getListData() == null)
            return ret;

        for (DataRow row : rs.getListData())
        {
            LinkedHashMap<String, Object> item = new LinkedHashMap<String, Object>();
            item.put("pid", row.get("pid"));
            item.put("state", row.get("state"));
            item.put("userName", row.get("user_name"));
            item.put("applicationName", row.get("application_name"));
            item.put("clientAddr", row.get("client_addr"));
            item.put("waitEventType", row.get("wait_event_type"));
            item.put("waitEvent", row.get("wait_event"));
            item.put("backendXid", row.get("backend_xid"));
            item.put("backendXmin", row.get("backend_xmin"));
            item.put("queryAgeSec", row.get("query_age_sec"));
            item.put("xactAgeSec", row.get("xact_age_sec"));
            item.put("blockingPids", parsePidList(row.get("blocking_pids")));
            item.put("relationNames", row.get("relation_names"));
            item.put("query", row.get("query"));
            item.put("hintOnly", Boolean.TRUE);
            ret.add(item);
        }
        return ret;
    }

    protected void addPositiveInt(Set<Integer> set, Object value)
    {
        int one = ToolUtilities.getInteger(value, 0);
        if (one > 0)
            set.add(Integer.valueOf(one));
    }

    protected void addNonEmptyString(Set<String> set, Object value)
    {
        String one = ToolUtilities.getString(value, null);
        if (!ToolUtilities.isStringEmpty(one, true))
            set.add(one.trim());
    }

    protected String buildPgIntArray(Set<Integer> set)
    {
        if (set == null || set.isEmpty())
            return "ARRAY[]::int[]";
        StringBuilder sb = new StringBuilder();
        sb.append("ARRAY[");
        boolean first = true;
        for (Integer one : set)
        {
            if (one == null || one.intValue() <= 0)
                continue;
            if (!first)
                sb.append(',');
            sb.append(one.intValue());
            first = false;
        }
        if (first)
            return "ARRAY[]::int[]";
        sb.append("]::int[]");
        return sb.toString();
    }

    protected String buildPgTextArray(Set<String> set)
    {
        if (set == null || set.isEmpty())
            return "ARRAY[]::text[]";
        StringBuilder sb = new StringBuilder();
        sb.append("ARRAY[");
        boolean first = true;
        for (String one : set)
        {
            if (ToolUtilities.isStringEmpty(one, true))
                continue;
            if (!first)
                sb.append(',');
            sb.append('\'').append(one.replace("'", "''")).append('\'');
            first = false;
        }
        if (first)
            return "ARRAY[]::text[]";
        sb.append("]::text[]");
        return sb.toString();
    }

    protected List<Map<String, Object>> cloneMapList(List<Map<String, Object>> list)
    {
        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        if (list == null)
            return ret;
        for (Map<String, Object> one : list)
        {
            if (one == null)
                continue;
            ret.add(new LinkedHashMap<String, Object>(one));
        }
        return ret;
    }

    protected List<Map<String, Object>> trimMapList(List<Map<String, Object>> list, int limit)
    {
        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        if (list == null || list.isEmpty())
            return ret;
        for (Map<String, Object> one : list)
        {
            if (one == null)
                continue;
            ret.add(new LinkedHashMap<String, Object>(one));
            if (ret.size() >= limit)
                break;
        }
        return ret;
    }

    protected void cacheRecentTableLockSqls(long captureTime, List<Map<String, Object>> sqls)
    {
        if (sqls == null || sqls.isEmpty())
            return;

        RecentSqlSnapshot one = new RecentSqlSnapshot();
        one.captureTime = captureTime;
        one.sqls = cloneMapList(sqls);

        synchronized (_recentTableLockSqlLock)
        {
            _recentTableLockSqlHistory.addFirst(one);
            while (_recentTableLockSqlHistory.size() > 8)
                _recentTableLockSqlHistory.removeLast();
        }
    }

    protected List<Map<String, Object>> pickRecentTableLockSqls(long collectTime, int limit)
    {
        long maxGapMs = Math.max(10000L, _collectIntervalMs * 2L);
        synchronized (_recentTableLockSqlLock)
        {
            if (_recentTableLockSqlHistory.isEmpty())
                return new ArrayList<Map<String, Object>>();

            for (RecentSqlSnapshot one : _recentTableLockSqlHistory)
            {
                if (one == null || one.sqls == null || one.sqls.isEmpty())
                    continue;
                if (Math.abs(collectTime - one.captureTime) > maxGapMs)
                    continue;
                return trimMapList(one.sqls, limit);
            }
        }
        return new ArrayList<Map<String, Object>>();
    }

    protected List<Map<String, Object>> buildSuspectedSqlDelta(List<Map<String, Object>> tableLockSqls,
            List<Map<String, Object>> relatedSqls, LinkedHashMap<String, Map<String, Object>> edgeMap, int limit)
    {
        LinkedHashMap<String, Map<String, Object>> baseMap = new LinkedHashMap<String, Map<String, Object>>();
        if (tableLockSqls != null)
        {
            for (Map<String, Object> one : tableLockSqls)
            {
                if (one == null)
                    continue;
                String key = buildSqlIdentityKey(one);
                if (!ToolUtilities.isStringEmpty(key, true))
                    baseMap.put(key, one);
            }
        }

        LinkedHashMap<String, Map<String, Object>> merged = new LinkedHashMap<String, Map<String, Object>>();
        mergeSuspectedSqlSource(merged, relatedSqls, edgeMap, false, baseMap);

        ArrayList<Map<String, Object>> list = new ArrayList<Map<String, Object>>(merged.values());
        java.util.Collections.sort(list, (a, b) -> ToolUtilities.getInteger(b.get("suspectScore"), 0)
                - ToolUtilities.getInteger(a.get("suspectScore"), 0));

        ArrayList<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();
        for (Map<String, Object> one : list)
        {
            if (one == null)
                continue;
            ret.add(one);
            if (ret.size() >= limit)
                break;
        }
        return ret;
    }

    protected void mergeSuspectedSqlSource(LinkedHashMap<String, Map<String, Object>> merged, List<Map<String, Object>> src,
            LinkedHashMap<String, Map<String, Object>> edgeMap, boolean tableLockSource,
            Map<String, Map<String, Object>> baseMap)
    {
        mergeSuspectedSqlSource(merged, src, edgeMap, tableLockSource, baseMap, false);
    }

    protected void mergeSuspectedSqlSource(LinkedHashMap<String, Map<String, Object>> merged, List<Map<String, Object>> src,
            LinkedHashMap<String, Map<String, Object>> edgeMap, boolean tableLockSource,
            Map<String, Map<String, Object>> baseMap, boolean hintOnly)
    {
        if (merged == null || src == null || src.isEmpty())
            return;

        for (Map<String, Object> one : src)
        {
            if (one == null)
                continue;

            String pid = ToolUtilities.getString(one.get("pid"), null);
            String query = ToolUtilities.getString(one.get("query"), null);
            if (ToolUtilities.isStringEmpty(pid, true) || ToolUtilities.isStringEmpty(query, true))
                continue;

            String key = buildSqlIdentityKey(one);
            if (ToolUtilities.isStringEmpty(key, true))
                continue;
            if (baseMap != null && baseMap.containsKey(key))
                continue;
            int score = calcSuspectScore(one, edgeMap, tableLockSource, hintOnly);

            Map<String, Object> exist = merged.get(key);
            if (exist != null)
            {
                int oldScore = ToolUtilities.getInteger(exist.get("suspectScore"), 0);
                if (score > oldScore)
                    exist.put("suspectScore", Integer.valueOf(score));
                String oldSource = ToolUtilities.getString(exist.get("suspectSource"), "");
                String newSource = hintOnly ? "idleInTransactionHints" : (tableLockSource ? "tableLockRelatedSqls" : "relatedRunningSqls");
                if (oldSource.indexOf(newSource) < 0)
                    exist.put("suspectSource", ToolUtilities.isStringEmpty(oldSource, true) ? newSource : oldSource + "," + newSource);
                continue;
            }

            LinkedHashMap<String, Object> item = new LinkedHashMap<String, Object>(one);
            item.put("suspectScore", Integer.valueOf(score));
            item.put("suspectSource", hintOnly ? "idleInTransactionHints" : (tableLockSource ? "tableLockRelatedSqls" : "relatedRunningSqls"));
            item.put("suspectReason", buildSuspectReason(one, edgeMap, tableLockSource, hintOnly));
            merged.put(key, item);
        }
    }

    protected String buildSuspectReason(Map<String, Object> sqlItem, LinkedHashMap<String, Map<String, Object>> edgeMap,
            boolean tableLockSource, boolean hintOnly)
    {
        ArrayList<String> reasons = new ArrayList<String>();
        reasons.add(hintOnly ? "来自idle in transaction线索采样(弱相关)"
                : (tableLockSource ? "来自最近持锁语句采样" : "来自死锁相关运行中会话"));

        String query = ToolUtilities.getString(sqlItem == null ? null : sqlItem.get("query"), "").toLowerCase();
        String waitEventType = ToolUtilities.getString(sqlItem == null ? null : sqlItem.get("waitEventType"), "").toLowerCase();
        String state = ToolUtilities.getString(sqlItem == null ? null : sqlItem.get("state"), "").toLowerCase();
        String backendXid = ToolUtilities.getString(sqlItem == null ? null : sqlItem.get("backendXid"), "");
        int pid = ToolUtilities.getInteger(sqlItem == null ? null : sqlItem.get("pid"), 0);

        if (query.contains("update ") || query.contains("delete ") || query.contains("insert ") || query.contains(" for update"))
            reasons.add("包含高风险写锁SQL");
        if ("lock".equals(waitEventType))
            reasons.add("当前处于锁等待");
        if (state.indexOf("idle in transaction") >= 0)
            reasons.add("处于事务未提交状态");

        if (edgeMap != null && !edgeMap.isEmpty())
        {
            for (Map<String, Object> edge : edgeMap.values())
            {
                if (edge == null)
                    continue;
                if (pid > 0 && (pid == ToolUtilities.getInteger(edge.get("blockedPid"), 0)
                        || pid == ToolUtilities.getInteger(edge.get("blockingPid"), 0)))
                {
                    reasons.add("PID直接出现在死锁边中");
                    break;
                }
                String blockedXid = ToolUtilities.getString(edge.get("blockedBackendXid"), "");
                String blockingXid = ToolUtilities.getString(edge.get("blockingBackendXid"), "");
                if (!ToolUtilities.isStringEmpty(backendXid, true)
                        && (backendXid.equals(blockedXid) || backendXid.equals(blockingXid)))
                {
                    reasons.add("事务XID与死锁边匹配");
                    break;
                }
            }
        }
        return String.join(";", reasons);
    }

    protected String buildSqlIdentityKey(Map<String, Object> sqlItem)
    {
        if (sqlItem == null)
            return null;
        String pid = ToolUtilities.getString(sqlItem.get("pid"), null);
        String query = ToolUtilities.getString(sqlItem.get("query"), null);
        String relationNames = ToolUtilities.getString(sqlItem.get("relationNames"), null);
        String backendXid = ToolUtilities.getString(sqlItem.get("backendXid"), null);
        if (ToolUtilities.isStringEmpty(pid, true) || ToolUtilities.isStringEmpty(query, true))
            return null;
        return pid + "|" + ToolUtilities.getString(backendXid, "") + "|" + ToolUtilities.getString(relationNames, "") + "|" + query;
    }

    protected int calcSuspectScore(Map<String, Object> sqlItem, LinkedHashMap<String, Map<String, Object>> edgeMap,
            boolean tableLockSource, boolean hintOnly)
    {
        int score = hintOnly ? 5 : (tableLockSource ? 30 : 10);
        String query = ToolUtilities.getString(sqlItem.get("query"), "").toLowerCase();
        String state = ToolUtilities.getString(sqlItem.get("state"), "").toLowerCase();
        String waitEventType = ToolUtilities.getString(sqlItem.get("waitEventType"), "").toLowerCase();
        String relationNames = ToolUtilities.getString(sqlItem.get("relationNames"), "").toLowerCase();
        String backendXid = ToolUtilities.getString(sqlItem.get("backendXid"), "");
        int pid = ToolUtilities.getInteger(sqlItem.get("pid"), 0);

        if (query.contains("update ") || query.contains("delete ") || query.contains("insert ") || query.contains(" for update"))
            score += 40;
        if (query.contains("opm_tool_deadlock_"))
            score += 100;
        if (relationNames.indexOf("opm_tool_deadlock_") >= 0)
            score += 80;
        if ("lock".equals(waitEventType))
            score += 30;
        if (state.indexOf("idle in transaction") >= 0)
            score += 20;
        if (hintOnly)
            score -= 15;

        if (edgeMap != null && !edgeMap.isEmpty())
        {
            for (Map<String, Object> edge : edgeMap.values())
            {
                if (edge == null)
                    continue;
                if (pid > 0 && (pid == ToolUtilities.getInteger(edge.get("blockedPid"), 0)
                        || pid == ToolUtilities.getInteger(edge.get("blockingPid"), 0)))
                    score += 60;

                String blockedXid = ToolUtilities.getString(edge.get("blockedBackendXid"), "");
                String blockingXid = ToolUtilities.getString(edge.get("blockingBackendXid"), "");
                if (!ToolUtilities.isStringEmpty(backendXid, true)
                        && (backendXid.equals(blockedXid) || backendXid.equals(blockingXid)))
                    score += 50;
            }
        }
        return score;
    }

    protected List<Integer> parsePidList(Object value)
    {
        ArrayList<Integer> ret = new ArrayList<Integer>();
        String text = ToolUtilities.getString(value, null);
        if (ToolUtilities.isStringEmpty(text, true))
            return ret;

        String[] arr = text.split(",");
        for (String one : arr)
        {
            int pid = ToolUtilities.getInteger(one, 0);
            if (pid > 0)
                ret.add(Integer.valueOf(pid));
        }
        return ret;
    }

    protected void collectConnection(IDao dao, OpmPgMetricDo ext, Map<String, Object> detail) throws Exception
    {
        boolean hasBackendType = hasPgStatActivityBackendType(dao);
        String connSql = hasBackendType ? PgSqlQueries.queryConnectionStats() : PgSqlQueries.queryConnectionStatsLegacy();
        MultiPageResult<DataRow> rs = dao.queryRows(connSql, null, null, 0, 1);
        if (rs != null && rs.getListData() != null && !rs.getListData().isEmpty())
        {
            DataRow row = rs.getListData().get(0);
            ext.totalConnCount = ToolUtilities.getInteger(row.get("total_conn"), 0);
            ext.activeConnCount = ToolUtilities.getInteger(row.get("active_conn"), 0);
            ext.idleConnCount = ToolUtilities.getInteger(row.get("idle_conn"), 0);
            ext.idleInTxnConnCount = ToolUtilities.getInteger(row.get("idle_in_txn_conn"), 0);
        }

        String maxConnSql = PgSqlQueries.queryMaxConnections();
        Object maxConn = dao.queryFirst(maxConnSql, null, null);
        ext.maxConnLimit = ToolUtilities.getInteger(maxConn, 100);

        if (ext.maxConnLimit > 0 && ext.totalConnCount != null)
        {
            ext.connUsageRate = (double) ext.totalConnCount / ext.maxConnLimit;
        }

        detail.put("connections", buildConnDetail(ext));
        if (!hasBackendType)
            detail.put("connectionStatsMode", "legacy_pg_stat_activity_without_backend_type");
    }

    protected boolean hasPgStatActivityBackendType(IDao dao) throws Exception
    {
        if (_pgStatActivityHasBackendType != null)
            return _pgStatActivityHasBackendType.booleanValue();

        String sql = "SELECT count(*) FROM information_schema.columns "
                + "WHERE table_schema='pg_catalog' "
                + "AND table_name='pg_stat_activity' "
                + "AND column_name='backend_type'";
        long count = dao.queryLong(sql, null, null, 0L);
        _pgStatActivityHasBackendType = Boolean.valueOf(count > 0L);
        return _pgStatActivityHasBackendType.booleanValue();
    }

    protected void collectTransaction(IDao dao, OpmPgMetricDo ext, Map<String, Object> detail) throws Exception
    {
        String txnSql = PgSqlQueries.queryTransactionStats();
        MultiPageResult<DataRow> rs = dao.queryRows(txnSql, null, null, 0, 1);
        if (rs != null && rs.getListData() != null && !rs.getListData().isEmpty())
        {
            DataRow row = rs.getListData().get(0);
            ext.txnCommitCount = ToolUtilities.getLong(row.get("xact_commit"), 0L);
            ext.txnRollbackCount = ToolUtilities.getLong(row.get("xact_rollback"), 0L);
        }
        detail.put("transactions", buildTxnDetail(ext));
    }

    protected void collectReplication(IDao dao, OpmPgMetricDo ext, Map<String, Object> detail) throws Exception
    {
        if (!_replicationEnable)
        {
            ext.replicationRole = "disabled";
            ext.replicationLagSec = Double.valueOf(0D);
            ext.replicationConnCount = Integer.valueOf(0);
            detail.put("replication", buildReplicationDetail(ext));
            return;
        }

        try
        {
            String isInRecoverySql = PgSqlQueries.queryIsInRecovery();
            Object inRecovery = dao.queryFirst(isInRecoverySql, null, null);
            boolean isStandby = ToolUtilities.getBoolean(inRecovery, false);

            if (isStandby)
            {
                ext.replicationRole = "standby";
                String standbySql = PgSqlQueries.queryReplicationStandby();
                MultiPageResult<DataRow> rs = dao.queryRows(standbySql, null, null, 0, 1);
                if (rs != null && rs.getListData() != null && !rs.getListData().isEmpty())
                {
                    DataRow row = rs.getListData().get(0);
                    ext.replicationLagSec = ToolUtilities.getDouble(row.get("lag_sec"), 0D);
                }
            }
            else
            {
                ext.replicationRole = "primary";
                String primarySql = PgSqlQueries.queryReplicationPrimary();
                MultiPageResult<DataRow> rs = dao.queryRows(primarySql, null, null, 0, 10);
                if (rs != null && rs.getListData() != null && !rs.getListData().isEmpty())
                {
                    ext.replicationConnCount = rs.getListData().size();
                    double maxLag = 0D;
                    for (DataRow row : rs.getListData())
                    {
                        Double lag = ToolUtilities.getDouble(row.get("lag_sec"), 0D);
                        if (lag > maxLag)
                        {
                            maxLag = lag;
                        }
                        ext.replicationState = (String) row.get("state");
                    }
                    ext.replicationLagSec = maxLag;
                }
            }
        }
        catch (Exception e)
        {
            ext.replicationRole = "unknown";
        }

        detail.put("replication", buildReplicationDetail(ext));
    }

    @Override
    public List<OpmRuleResult> evaluateRules(OpmCollectResult collectResult, OpmAgentContext agentCtx) throws Exception
    {
        List<OpmRuleResult> list = new LinkedList<OpmRuleResult>();
        if (collectResult == null || collectResult.metricExt == null || !(collectResult.metricExt instanceof OpmPgMetricDo))
        {
            return list;
        }

        OpmPgMetricDo ext = (OpmPgMetricDo) collectResult.metricExt;
        long now = System.currentTimeMillis();

        OpmRuleResult sqlRule = evalSqlRule(ext, now, agentCtx);
        if (sqlRule != null)
        {
            list.add(sqlRule);
        }

        OpmRuleResult spaceRule = evalSpaceRule(ext, now, agentCtx);
        if (spaceRule != null)
        {
            list.add(spaceRule);
        }

        OpmRuleResult deadlockRule = evalDeadlockRule(ext, now, agentCtx);
        if (deadlockRule != null)
        {
            list.add(deadlockRule);
        }

        OpmRuleResult connRule = evalConnRule(ext, now, agentCtx);
        if (connRule != null)
        {
            list.add(connRule);
        }

        OpmRuleResult replicationRule = evalReplicationRule(ext, now, agentCtx);
        if (replicationRule != null)
        {
            list.add(replicationRule);
        }

        return list;
    }

    protected OpmRuleResult evalSqlRule(OpmPgMetricDo ext, long now, OpmAgentContext agentCtx)
    {
        if (!_sqlEnable)
            return null;

        if (ext.maxSqlDurationSec == null || ext.maxSqlDurationSec <= 0D)
        {
            return null;
        }

        double duration = ext.maxSqlDurationSec;
        AlarmLevelConfig[] levels = new AlarmLevelConfig[] {
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", _sqlCriticalSec, 0),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MAJOR, "主要", _sqlMajorSec, 0),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MINOR, "次要", _sqlMinorSec, 0),
                new AlarmLevelConfig(TsAlarm.LEVEL_WARN, "警告", _sqlWarnSec, 0)
        };

        for (AlarmLevelConfig level : levels)
        {
            if (duration >= level.threshold)
            {
                String ruleKey = OpmAlarmConfigKeys.RULE_PG_SQL;

                OpmRuleResult rs = new OpmRuleResult();
                rs.triggered = true;
                rs.alarmLevel = level.level;
                rs.ruleKey = ruleKey;
                rs.configParamKey = resolvePgConfigParamKey(ruleKey, level.level);
                rs.ruleLabel = "SQL执行时长超阈值";
                rs.message = buildSqlAlarmMessage(ext, duration, level);
                rs.detailJson = buildSqlAlarmDetailJson(ext, duration, level);

                OpmPgAlarmExtDo alarmExt = new OpmPgAlarmExtDo();
                alarmExt.alarmType = "sqlLong";
                alarmExt.metricName = "maxSqlDurationSec";
                alarmExt.currentValue = duration;
                alarmExt.thresholdValue = Double.valueOf(level.threshold);
                alarmExt.triggerLevel = level.levelName;
                alarmExt.dbName = ext.dbName;
                fillLongSqlAlarmExt(alarmExt, ext);
                rs.alarmExt = alarmExt;

                return rs;
            }
        }

        return null;
    }

    protected OpmRuleResult evalSpaceRule(OpmPgMetricDo ext, long now, OpmAgentContext agentCtx)
    {
        if (!_spaceEnable)
            return null;

        Double usageRate = ext.tablespaceUsageRate;
        if (usageRate == null || usageRate <= 0D)
        {
            return null;
        }

        AlarmLevelConfig[] levels = new AlarmLevelConfig[] {
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", _spaceCriticalRate, _spaceCriticalDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MAJOR, "主要", _spaceMajorRate, _spaceMajorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MINOR, "次要", _spaceMinorRate, _spaceMinorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_WARN, "警告", _spaceWarnRate, _spaceWarnDurationSec)
        };

        for (AlarmLevelConfig level : levels)
        {
            if (usageRate >= level.threshold)
            {
                String ruleKey = OpmAlarmConfigKeys.RULE_PG_SPACE;

                OpmRuleResult rs = new OpmRuleResult();
                rs.triggered = true;
                rs.alarmLevel = level.level;
                rs.ruleKey = ruleKey;
                rs.configParamKey = resolvePgConfigParamKey(ruleKey, level.level);
                rs.ruleLabel = "空间使用率超阈值";
                rs.message = "空间使用率过高: 当前=" + formatRate(usageRate) + ", 级别=" + level.levelName + ", 阈值=" + formatRate(level.threshold);
                rs.detailJson = ext.detailJson;

                OpmPgAlarmExtDo alarmExt = new OpmPgAlarmExtDo();
                alarmExt.alarmType = "dbSpace";
                alarmExt.metricName = "usageRate";
                alarmExt.currentValue = usageRate;
                alarmExt.thresholdValue = Double.valueOf(level.threshold);
                alarmExt.durationSec = Integer.valueOf(level.durationSec);
                alarmExt.triggerLevel = level.levelName;
                alarmExt.dbName = ext.dbName;
                rs.alarmExt = alarmExt;

                return rs;
            }
        }

        return null;
    }

    protected OpmRuleResult evalDeadlockRule(OpmPgMetricDo ext, long now, OpmAgentContext agentCtx)
    {
        int deadlockCount = ToolUtilities.getInteger(ext.deadlockDeltaCount, 0);
        if (deadlockCount <= 0)
            return null;

        AlarmLevelConfig[] levels = new AlarmLevelConfig[] {
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", _deadlockCriticalCount, 0),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MAJOR, "主要", _deadlockMajorCount, 0),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MINOR, "次要", _deadlockMinorCount, 0),
                new AlarmLevelConfig(TsAlarm.LEVEL_WARN, "警告", _deadlockWarnCount, 0)
        };

        for (AlarmLevelConfig level : levels)
        {
            if (deadlockCount < level.threshold)
                continue;

            String ruleKey = OpmAlarmConfigKeys.RULE_PG_DEADLOCK;

            String suspectSql = truncateString(extractDeadlockSuspectSql(ext.detailJson), 4000);

            OpmRuleResult rs = new OpmRuleResult();
            rs.triggered = true;
            rs.alarmLevel = level.level;
            rs.ruleKey = ruleKey;
            rs.configParamKey = resolvePgConfigParamKey(ruleKey, level.level);
            rs.ruleLabel = "死锁次数超阈值";
            rs.message = "死锁次数过高: 本轮新增=" + deadlockCount + ", 级别=" + level.levelName + ", 阈值=" + (int) level.threshold;
            rs.detailJson = ext.detailJson;

            OpmPgAlarmExtDo alarmExt = new OpmPgAlarmExtDo();
            alarmExt.alarmType = "deadlock";
            alarmExt.metricName = "deadlockDeltaCount";
            alarmExt.currentValue = Double.valueOf(deadlockCount);
            alarmExt.thresholdValue = Double.valueOf(level.threshold);
            alarmExt.triggerLevel = level.levelName;
            alarmExt.dbName = ext.dbName;
            alarmExt.sqlText = suspectSql;
            rs.alarmExt = alarmExt;
            return rs;
        }

        return null;
    }

    protected OpmRuleResult evalConnRule(OpmPgMetricDo ext, long now, OpmAgentContext agentCtx)
    {
        if (!_connEnable)
            return null;

        if (ext.connUsageRate == null || ext.connUsageRate <= 0D)
        {
            return null;
        }

        double usageRate = ext.connUsageRate;
        AlarmLevelConfig[] levels = new AlarmLevelConfig[] {
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", _connCriticalRate, _connCriticalDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MAJOR, "主要", _connMajorRate, _connMajorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MINOR, "次要", _connMinorRate, _connMinorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_WARN, "警告", _connWarnRate, _connWarnDurationSec)
        };

        for (AlarmLevelConfig level : levels)
        {
            if (usageRate >= level.threshold)
            {
                String ruleKey = OpmAlarmConfigKeys.RULE_PG_CONN;

                OpmRuleResult rs = new OpmRuleResult();
                rs.triggered = true;
                rs.alarmLevel = level.level;
                rs.ruleKey = ruleKey;
                rs.configParamKey = resolvePgConfigParamKey(ruleKey, level.level);
                rs.ruleLabel = "连接使用率超阈值";
                rs.message = "连接使用率过高: 当前=" + formatRate(usageRate) + ", 级别=" + level.levelName + ", 阈值=" + formatRate(level.threshold);
                rs.detailJson = ext.detailJson;

                OpmPgAlarmExtDo alarmExt = new OpmPgAlarmExtDo();
                alarmExt.alarmType = "connUsage";
                alarmExt.metricName = "connUsageRate";
                alarmExt.currentValue = usageRate;
                alarmExt.thresholdValue = Double.valueOf(level.threshold);
                alarmExt.durationSec = Integer.valueOf(level.durationSec);
                alarmExt.triggerLevel = level.levelName;
                alarmExt.dbName = ext.dbName;
                rs.alarmExt = alarmExt;

                return rs;
            }
        }

        return null;
    }

    @SuppressWarnings("unchecked")
    protected String extractDeadlockSuspectSql(String detailJson)
    {
        if (ToolUtilities.isStringEmpty(detailJson, true))
            return null;
        try
        {
            Object obj = CJson.fromJson(detailJson);
            if (!(obj instanceof Map))
                return null;
            Map<String, Object> map = (Map<String, Object>) obj;

            String suspectSql = ToolUtilities.getString(map.get("deadlockSuspectSql"), null);
            if (!ToolUtilities.isStringEmpty(suspectSql, true))
                return suspectSql;

            suspectSql = extractFirstQuery(map.get("deadlockSuspectSqls"));
            if (!ToolUtilities.isStringEmpty(suspectSql, true))
                return suspectSql;

            suspectSql = extractFirstQuery(map.get("deadlockIdleTxnHints"));
            if (!ToolUtilities.isStringEmpty(suspectSql, true))
                return suspectSql;

            Object deadlockDetail = map.get("deadlockDetail");
            if (deadlockDetail instanceof Map)
            {
                suspectSql = extractLegacyDeadlockSuspectSql((Map<String, Object>) deadlockDetail);
                if (!ToolUtilities.isStringEmpty(suspectSql, true))
                    return suspectSql;
            }
        }
        catch (Throwable ignore)
        {
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    protected String extractLegacyDeadlockSuspectSql(Map<String, Object> detail)
    {
        if (detail == null)
            return null;

        String suspectSql = extractFirstQuery(detail.get("suspectSqlDelta"));
        if (!ToolUtilities.isStringEmpty(suspectSql, true))
            return suspectSql;

        suspectSql = extractFirstQuery(detail.get("tableLockRelatedSqls"));
        if (!ToolUtilities.isStringEmpty(suspectSql, true))
            return suspectSql;

        Object blockingEdges = detail.get("blockingEdges");
        if (blockingEdges instanceof List)
        {
            for (Object one : (List<?>) blockingEdges)
            {
                if (!(one instanceof Map))
                    continue;
                Map<String, Object> edge = (Map<String, Object>) one;
                suspectSql = ToolUtilities.getString(edge.get("blockedQuery"), null);
                if (!ToolUtilities.isStringEmpty(suspectSql, true))
                    return suspectSql;
                suspectSql = ToolUtilities.getString(edge.get("blockingQuery"), null);
                if (!ToolUtilities.isStringEmpty(suspectSql, true))
                    return suspectSql;
            }
        }

        return extractFirstQuery(detail.get("sessions"));
    }

    @SuppressWarnings("unchecked")
    protected String extractFirstQuery(Object listObj)
    {
        if (!(listObj instanceof List))
            return null;
        for (Object one : (List<?>) listObj)
        {
            if (!(one instanceof Map))
                continue;
            String query = ToolUtilities.getString(((Map<String, Object>) one).get("query"), null);
            if (!ToolUtilities.isStringEmpty(query, true))
                return query;
        }
        return null;
    }

    protected OpmRuleResult evalReplicationRule(OpmPgMetricDo ext, long now, OpmAgentContext agentCtx)
    {
        if (!_replicationEnable)
            return null;

        if (ext.replicationLagSec == null || ext.replicationLagSec <= 0D)
        {
            return null;
        }

        double lagSec = ext.replicationLagSec;
        AlarmLevelConfig[] levels = new AlarmLevelConfig[] {
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_CRITICAL, "严重", _replicationCriticalSec, _replicationCriticalDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MAJOR, "主要", _replicationMajorSec, _replicationMajorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_ERROR_MINOR, "次要", _replicationMinorSec, _replicationMinorDurationSec),
                new AlarmLevelConfig(TsAlarm.LEVEL_WARN, "警告", _replicationWarnSec, _replicationWarnDurationSec)
        };

        for (AlarmLevelConfig level : levels)
        {
            if (lagSec >= level.threshold)
            {
                String ruleKey = OpmAlarmConfigKeys.RULE_PG_REPLICATION;

                OpmRuleResult rs = new OpmRuleResult();
                rs.triggered = true;
                rs.alarmLevel = level.level;
                rs.ruleKey = ruleKey;
                rs.configParamKey = resolvePgConfigParamKey(ruleKey, level.level);
                rs.ruleLabel = "复制延迟超阈值";
                rs.message = "复制延迟过长: 当前=" + formatDuration(lagSec) + ", 级别=" + level.levelName + ", 阈值=" + formatDuration(level.threshold);
                rs.detailJson = ext.detailJson;

                OpmPgAlarmExtDo alarmExt = new OpmPgAlarmExtDo();
                alarmExt.alarmType = "replicationLag";
                alarmExt.metricName = "replicationLagSec";
                alarmExt.currentValue = lagSec;
                alarmExt.thresholdValue = Double.valueOf(level.threshold);
                alarmExt.durationSec = Integer.valueOf(level.durationSec);
                alarmExt.triggerLevel = level.levelName;
                alarmExt.dbName = ext.dbName;
                rs.alarmExt = alarmExt;

                return rs;
            }
        }

        return null;
    }

    protected String buildSummary(OpmPgMetricDo ext)
    {
        StringBuilder sb = new StringBuilder();
        sb.append("db=").append(ext.dbName);
        sb.append(", longSql=").append(ext.longSqlCount != null ? ext.longSqlCount : 0);
        if (ext.maxSqlDurationSec != null && ext.maxSqlDurationSec > 0D)
        {
            sb.append(", maxSql=").append(formatDuration(ext.maxSqlDurationSec));
            String topSqlSummary = extractTopLongSqlSummary(ext.detailJson);
            if (!ToolUtilities.isStringEmpty(topSqlSummary, true))
                sb.append(", sqlTop=").append(topSqlSummary);
        }
        sb.append(", conn=").append(formatRate(ext.connUsageRate));
        int deadlockCount = ToolUtilities.getInteger(ext.deadlockCount, 0);
        int deadlockDeltaCount = ToolUtilities.getInteger(ext.deadlockDeltaCount, 0);
        if (deadlockCount > 0)
        {
            sb.append(", deadlock=").append(deadlockCount);
            if (deadlockDeltaCount > 0)
                sb.append("(+").append(deadlockDeltaCount).append(')');
        }
        if (ext.replicationLagSec != null && ext.replicationLagSec > 0)
        {
            sb.append(", replLag=").append(formatDuration(ext.replicationLagSec));
        }
        return sb.toString();
    }

    protected String resolvePgConfigParamKey(String ruleKey, int alarmLevel)
    {
        if (OpmAlarmConfigKeys.RULE_PG_SQL.equals(ruleKey))
        {
            if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
                return OpmPgConst.CONF_SQL_CRITICAL_SEC;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
                return OpmPgConst.CONF_SQL_MAJOR_SEC;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
                return OpmPgConst.CONF_SQL_MINOR_SEC;
            return OpmPgConst.CONF_SQL_WARN_SEC;
        }
        if (OpmAlarmConfigKeys.RULE_PG_SPACE.equals(ruleKey))
        {
            if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
                return OpmPgConst.CONF_SPACE_CRITICAL_RATE;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
                return OpmPgConst.CONF_SPACE_MAJOR_RATE;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
                return OpmPgConst.CONF_SPACE_MINOR_RATE;
            return OpmPgConst.CONF_SPACE_WARN_RATE;
        }
        if (OpmAlarmConfigKeys.RULE_PG_DEADLOCK.equals(ruleKey))
        {
            if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
                return OpmPgConst.CONF_DEADLOCK_CRITICAL_COUNT;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
                return OpmPgConst.CONF_DEADLOCK_MAJOR_COUNT;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
                return OpmPgConst.CONF_DEADLOCK_MINOR_COUNT;
            return OpmPgConst.CONF_DEADLOCK_WARN_COUNT;
        }
        if (OpmAlarmConfigKeys.RULE_PG_CONN.equals(ruleKey))
        {
            if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
                return OpmPgConst.CONF_CONN_CRITICAL_RATE;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
                return OpmPgConst.CONF_CONN_MAJOR_RATE;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
                return OpmPgConst.CONF_CONN_MINOR_RATE;
            return OpmPgConst.CONF_CONN_WARN_RATE;
        }
        if (OpmAlarmConfigKeys.RULE_PG_REPLICATION.equals(ruleKey))
        {
            if (alarmLevel == TsAlarm.LEVEL_ERROR_CRITICAL)
                return OpmPgConst.CONF_REPLICATION_CRITICAL_SEC;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MAJOR)
                return OpmPgConst.CONF_REPLICATION_MAJOR_SEC;
            if (alarmLevel == TsAlarm.LEVEL_ERROR_MINOR)
                return OpmPgConst.CONF_REPLICATION_MINOR_SEC;
            return OpmPgConst.CONF_REPLICATION_WARN_SEC;
        }
        return null;
    }

    protected Map<String, Object> buildConnDetail(OpmPgMetricDo ext)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("total", ext.totalConnCount);
        map.put("active", ext.activeConnCount);
        map.put("idle", ext.idleConnCount);
        map.put("idleInTxn", ext.idleInTxnConnCount);
        map.put("maxLimit", ext.maxConnLimit);
        map.put("usageRate", ext.connUsageRate);
        return map;
    }

    protected Map<String, Object> buildTxnDetail(OpmPgMetricDo ext)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("commit", ext.txnCommitCount);
        map.put("rollback", ext.txnRollbackCount);
        return map;
    }

    protected Map<String, Object> buildReplicationDetail(OpmPgMetricDo ext)
    {
        Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("role", ext.replicationRole);
        map.put("lagSec", ext.replicationLagSec);
        map.put("state", ext.replicationState);
        map.put("connCount", ext.replicationConnCount);
        return map;
    }

    protected boolean over(Double value, double threshold)
    {
        return value != null && value.doubleValue() > 0D && value.doubleValue() >= threshold;
    }

    protected boolean over(Integer value, int threshold)
    {
        return value != null && value.intValue() > 0 && value.intValue() >= threshold;
    }

    protected String formatRate(Double v)
    {
        if (v == null || v < 0D)
        {
            return "N/A";
        }
        return String.format(java.util.Locale.US, "%.2f%%", Double.valueOf(v * 100D));
    }

    protected String formatDuration(double v)
    {
        if (v < 0D)
        {
            return "N/A";
        }
        if (v < 60D)
        {
            return String.format(java.util.Locale.US, "%.1fs", Double.valueOf(v));
        }
        else if (v < 3600D)
        {
            return String.format(java.util.Locale.US, "%.1fm", Double.valueOf(v / 60D));
        }
        else
        {
            return String.format(java.util.Locale.US, "%.1fh", Double.valueOf(v / 3600D));
        }
    }

    protected String truncateString(String s, int maxLen)
    {
        if (s == null)
        {
            return null;
        }
        if (s.length() <= maxLen)
        {
            return s;
        }
        return s.substring(0, maxLen);
    }

    @SuppressWarnings("unchecked")
    protected Map<String, Object> pickTopLongSql(List<Map<String, Object>> sqlList)
    {
        if (sqlList == null || sqlList.isEmpty())
            return null;
        Map<String, Object> best = null;
        double bestDuration = -1D;
        for (Map<String, Object> one : sqlList)
        {
            if (one == null)
                continue;
            double oneDuration = ToolUtilities.getDouble(one.get("durationSec"), 0D);
            if (best == null || oneDuration > bestDuration)
            {
                best = one;
                bestDuration = oneDuration;
            }
        }
        if (best == null)
            return null;

        LinkedHashMap<String, Object> ret = new LinkedHashMap<String, Object>();
        ret.put("pid", best.get("pid"));
        ret.put("durationSec", best.get("durationSec"));
        ret.put("state", best.get("state"));
        ret.put("waitEventType", best.get("waitEventType"));
        ret.put("waitEvent", best.get("waitEvent"));
        ret.put("applicationName", best.get("applicationName"));
        ret.put("clientAddr", best.get("clientAddr"));

        String query = ToolUtilities.getString(best.get("query"), null);
        ret.put("query", truncateString(query, 4000));
        ret.put("queryBrief", buildSqlBrief(query));
        ret.put("queryDigest", buildSqlDigest(query));
        return ret;
    }

    protected String buildSqlAlarmMessage(OpmPgMetricDo ext, double duration, AlarmLevelConfig level)
    {
        StringBuilder sb = new StringBuilder();
        sb.append("SQL执行时长过长: 当前=").append(formatDuration(duration));
        sb.append(", 级别=").append(level.levelName);
        sb.append(", 阈值=").append(formatDuration(level.threshold));
        String topSqlSummary = extractTopLongSqlSummary(ext == null ? null : ext.detailJson);
        if (!ToolUtilities.isStringEmpty(topSqlSummary, true))
            sb.append(", SQL=").append(topSqlSummary);
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    protected String buildSqlAlarmDetailJson(OpmPgMetricDo ext, double duration, AlarmLevelConfig level)
    {
        Map<String, Object> detail = null;
        try
        {
            Object obj = CJson.fromJson(ext == null ? null : ext.detailJson);
            if (obj instanceof Map)
                detail = new LinkedHashMap<String, Object>((Map<String, Object>) obj);
        }
        catch (Throwable ignore)
        {
        }
        if (detail == null)
            detail = new LinkedHashMap<String, Object>();

        Map<String, Object> topSql = extractTopLongSql(detail);
        if (topSql != null)
            detail.put(DETAIL_KEY_TOP_LONG_SQL, topSql);
        String suppressKey = buildLongSqlSuppressKey(ext == null ? null : ext.dbName, topSql);
        if (!ToolUtilities.isStringEmpty(suppressKey, true))
            detail.put(DETAIL_KEY_LONG_SQL_SUPPRESS_KEY, suppressKey);
        detail.put("currentValue", Double.valueOf(duration));
        detail.put("thresholdValue", Double.valueOf(level.threshold));
        detail.put("triggerLevel", level.levelName);
        detail.put("dbName", ext == null ? null : ext.dbName);
        return CJson.toJson(detail);
    }

    protected void fillLongSqlAlarmExt(OpmPgAlarmExtDo alarmExt, OpmPgMetricDo ext)
    {
        if (alarmExt == null)
            return;
        Map<String, Object> topSql = extractTopLongSql(ext == null ? null : ext.detailJson);
        if (topSql == null)
            return;
        alarmExt.pid = Integer.valueOf(ToolUtilities.getInteger(topSql.get("pid"), 0));
        alarmExt.sqlText = truncateString(ToolUtilities.getString(topSql.get("query"), null), 4000);
    }

    @SuppressWarnings("unchecked")
    protected Map<String, Object> extractTopLongSql(String detailJson)
    {
        if (ToolUtilities.isStringEmpty(detailJson, true))
            return null;
        try
        {
            Object obj = CJson.fromJson(detailJson);
            if (obj instanceof Map)
                return extractTopLongSql((Map<String, Object>) obj);
        }
        catch (Throwable ignore)
        {
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    protected Map<String, Object> extractTopLongSql(Map<String, Object> detail)
    {
        if (detail == null)
            return null;
        Object obj = detail.get(DETAIL_KEY_TOP_LONG_SQL);
        if (obj instanceof Map)
            return (Map<String, Object>) obj;
        return pickTopLongSql((List<Map<String, Object>>) detail.get("longSqls"));
    }

    protected String extractTopLongSqlSummary(String detailJson)
    {
        Map<String, Object> topSql = extractTopLongSql(detailJson);
        if (topSql == null)
            return null;
        return buildTopLongSqlSummary(topSql);
    }

    protected String buildTopLongSqlSummary(Map<String, Object> topSql)
    {
        if (topSql == null)
            return null;
        StringBuilder sb = new StringBuilder();
        String applicationName = ToolUtilities.getString(topSql.get("applicationName"), null);
        String state = ToolUtilities.getString(topSql.get("state"), null);
        String digest = ToolUtilities.getString(topSql.get("queryDigest"), null);
        String queryBrief = ToolUtilities.getString(topSql.get("queryBrief"), null);
        if (!ToolUtilities.isStringEmpty(applicationName, true))
            sb.append("app=").append(applicationName.trim());
        if (!ToolUtilities.isStringEmpty(state, true))
        {
            if (sb.length() > 0)
                sb.append('/');
            sb.append("state=").append(state.trim());
        }
        if (!ToolUtilities.isStringEmpty(digest, true))
        {
            if (sb.length() > 0)
                sb.append('/');
            sb.append("sig=").append(digest);
        }
        if (!ToolUtilities.isStringEmpty(queryBrief, true))
        {
            if (sb.length() > 0)
                sb.append('/');
            sb.append(queryBrief);
        }
        return sb.length() <= 0 ? null : truncateString(sb.toString(), 240);
    }

    protected String buildLongSqlSuppressKey(String dbName, Map<String, Object> topSql)
    {
        if (topSql == null)
            return null;
        StringBuilder sb = new StringBuilder();
        sb.append("sql.longDuration|");
        sb.append("db=").append(normalizeSqlKeyPart(dbName)).append('|');
        String digest = ToolUtilities.getString(topSql.get("queryDigest"), null);
        String brief = ToolUtilities.getString(topSql.get("queryBrief"), null);
        sb.append("digest=").append(normalizeSqlKeyPart(digest)).append('|');
        sb.append("brief=").append(normalizeSqlKeyPart(brief));
        return sb.toString();
    }

    protected String buildSqlBrief(String sql)
    {
        String normalized = normalizeSqlText(sql);
        if (ToolUtilities.isStringEmpty(normalized, true))
            return null;
        String upper = normalized.toUpperCase(java.util.Locale.US);
        int fromIndex = upper.indexOf(" FROM ");
        if (fromIndex > 0)
            return truncateString(normalized.substring(0, fromIndex).trim(), 80);
        int whereIndex = upper.indexOf(" WHERE ");
        if (whereIndex > 0)
            return truncateString(normalized.substring(0, whereIndex).trim(), 80);
        return truncateString(normalized, 80);
    }

    protected String buildSqlDigest(String sql)
    {
        String normalized = normalizeSqlText(sql);
        if (ToolUtilities.isStringEmpty(normalized, true))
            return null;
        try
        {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest(normalized.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.length && i < 6; i++)
                sb.append(String.format(java.util.Locale.US, "%02x", Byte.valueOf(bytes[i])));
            return sb.toString();
        }
        catch (Throwable err)
        {
            return String.valueOf(normalized.hashCode());
        }
    }

    protected String normalizeSqlText(String sql)
    {
        if (ToolUtilities.isStringEmpty(sql, true))
            return null;
        String text = sql.trim();
        text = text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
        text = text.replaceAll("'[^']*'", "?");
        text = text.replaceAll("\\b\\d+(?:\\.\\d+)?\\b", "?");
        text = text.replaceAll("\\s+", " ").trim();
        return ToolUtilities.isStringEmpty(text, true) ? null : text;
    }

    protected String normalizeSqlKeyPart(String text)
    {
        String val = ToolUtilities.getString(text, "").trim().toLowerCase(java.util.Locale.US);
        if (val.length() <= 0)
            return "-";
        return val.replace('|', '_');
    }

    protected static class AlarmLevelConfig
    {
        public int level;
        public String levelName;
        public double threshold;
        public int durationSec;

public AlarmLevelConfig(int level, String levelName, double threshold, int durationSec)
        {
            this.level = level;
            this.levelName = levelName;
            this.threshold = threshold;
            this.durationSec = durationSec;
        }
}

    @Override
    public long getCollectIntervalMs()
    {
        return _collectIntervalMs;
    }
}
