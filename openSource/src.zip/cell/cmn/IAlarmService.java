package cell.cmn;

import bap.cells.Cells;
import cell.ServiceCellIntf;

public interface IAlarmService extends ServiceCellIntf{
	
	public static IAlarmService get() {
		return Cells.get(IAlarmService.class);
	}
	
	public String getAppName()throws Exception;
	
	public int getState(Throwable err)throws Exception;
	
	public String getErrorCode(Throwable err)throws Exception;
	
//	/**
//	 * 获取定义的错误码
//	 * @return
//	 */
//	public String getErrorCode(String productCode,String moduleCode,String errorForm,String innerErrCode) ;
	
	public String getErrorBrief(Throwable err)throws Exception;
	
	public String getErrorMsg(Throwable err)throws Exception;
}
