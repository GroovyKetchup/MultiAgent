package cell.cmn;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import com.leavay.common.util.MppContext;
import com.leavay.common.util.Utils;
import com.leavay.dfc.gui.dfcutil;

import bap.cells.EmptyServiceCell;
import cmn.exception.DefaultExceptionHandler;
import cmn.exception.ExceptionHandler;
import etl.ETLUtil;

public class CAlarmService extends EmptyServiceCell implements IAlarmService{
	
	public final static String EXCEPTION_HANDLER_CONF = "ExceptionHandler.json";
	
	public Map<String,Class<ExceptionHandler>> errHandler = new HashMap<>();
	
	@Override
	public synchronized void startService() throws Exception {
		super.startService();
		initExceptionHandle();
	}
	
	public void initExceptionHandle() throws Exception {
		String filePath = MppContext.getConfDirFile(EXCEPTION_HANDLER_CONF);
		File file = new File(filePath);
		Map<String,Class<ExceptionHandler>> map = new HashMap<>();
		if(file.exists()) {
			String content = Utils.getFileContent(file, "UTF-8");
			try (IJson json = IJsonService.get().getJson()){
				Map<String,String> configMap = json.fromJson(content, Map.class);
				for(String key : configMap.keySet()) {
					String handlerClass = configMap.get(key);
					Class handlerClazz = ETLUtil.loadClass(handlerClass);
					map.put(key, handlerClazz);
				}
			}
		}
		errHandler = map;
	}
	
	
	
	@SuppressWarnings("rawtypes")
	public ExceptionHandler getExceptionHandler(Throwable err) throws InstantiationException, IllegalAccessException {
		ExceptionHandler handler = IAlarmPlugin.get().getExceptionHandler(err);
		if(handler != null)
			return handler;
		Class<? extends ExceptionHandler> handlerClazz = errHandler.get(err.getClass().getName());
		if(handlerClazz != null) {
			return handlerClazz.newInstance();
		}
		return new DefaultExceptionHandler();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public int getState(Throwable err) throws Exception {
		ExceptionHandler handler = getExceptionHandler(err);
		return handler.getState(err);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public String getErrorCode(Throwable err) throws Exception {
		ExceptionHandler handler = getExceptionHandler(err);
		return handler.getErrorCode(err);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public String getErrorBrief(Throwable err) throws Exception{
		ExceptionHandler handler = getExceptionHandler(err);
		return handler.getErrorBrief(err);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public String getErrorMsg(Throwable err) throws Exception{
		ExceptionHandler handler = getExceptionHandler(err);
		return handler.getErrorMsg(err);
	}

	@Override
	public String getAppName() throws Exception {
		return dfcutil.getDfcIntf().getProductName();
	}

}
