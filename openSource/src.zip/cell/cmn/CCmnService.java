package cell.cmn;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import com.kwaidoo.entity.annotation.Label;
import com.kwaidoo.verify.DataValidatorIntf;
import com.kwaidoo.verify.FieldValidatorIntf;
import com.kwaidoo.verify.ValidateException;
import com.kwaidoo.verify.ValidateTriggerType;
import com.kwaidoo.verify.annotation.NotEmpty;
import com.kwaidoo.verify.annotation.NotNull;
import com.kwaidoo.verify.annotation.Validator;
import com.leavay.common.util.LRUCache;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.ProgressCtrl.ProgressCtrlUtil.UserCancelOperation;
import com.leavay.common.util.ProgressCtrl.crpc.CProgressProxy;
import com.leavay.common.util.ProgressCtrl.crpc.CSrvOutputProgress;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.EmptyServiceCell;
import cmn.constant.WordI18nConst;
import web.constant.WebI18nConst;
import web.dto.Pair;
import web.dto.ProgressDetail;
import web.mgr.WebUtil;

public class CCmnService extends EmptyServiceCell implements ICmnService{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2917710079335930122L;
	
	private static ThreadLocal<Map<String,SimpleDateFormat>> threadLocal = new ThreadLocal<Map<String,SimpleDateFormat>>();
	
	LRUCache<String, CSrvOutputProgress<?>> progressCache = new LRUCache<>(500);
	
	public static SimpleDateFormat getDateFormat(String format) {
		Map<String,SimpleDateFormat> map = threadLocal.get();
		if (map == null) {
			map = new HashMap<>();
			threadLocal.set(map);
		}
		if(!map.containsKey(format)) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			map.put(format, sdf);
			return sdf;
		}else
			return map.get(format);
	}
	
	@Override
	public String getLabelOrName(Class<?> clazz) throws Exception {
		Label label = clazz.getAnnotation(Label.class);
		if(label != null && !CmnUtil.isStringEmpty(label.value()))
			return String.format("%s(%s)",WordI18nConst.getString(label.value()),clazz.getName());
		return clazz.getName();
	}
	
	@Override
	public String getLabelOrName(Field field) throws Exception {
		Label label = field.getAnnotation(Label.class);
		if(label != null && !CmnUtil.isStringEmpty(label.value()))
			return String.format("%s(%s)",WordI18nConst.getString(label.value()),field.getName());
		return field.getName();
	}
	
	private boolean fireValidate(ValidateTriggerType annoValue,ValidateTriggerType triggerType) {
		return annoValue ==ValidateTriggerType.All || annoValue == triggerType;
	}

	@Override
	public void verify(Class<?> clazz,Object obj,ValidateTriggerType triggerType) throws Exception {
		NotNull objNotNull = clazz.getAnnotation(NotNull.class);
		if(objNotNull != null && fireValidate(objNotNull.triggerType(), triggerType) && obj == null)
			throw new ValidateException(WebUtil.getString(WebI18nConst.DATA_CAN_NOT_BE_NULL));
		if(obj == null)
			return;
		//对象校验
		Validator objValidator = obj.getClass().getAnnotation(Validator.class);
		if(objValidator != null && fireValidate(objValidator.triggerType(), triggerType)) {
			Class<? extends DataValidatorIntf> objValidateClz = (Class<? extends DataValidatorIntf>) objValidator.value();
			DataValidatorIntf objVerifyInst = ClassFactory.newInstance(objValidateClz);
			try {
				objVerifyInst.verify(clazz,obj);
			}catch (Exception e) {
				e.printStackTrace();
//				throw new ValidateException(WebUtil.getString(WebI18nConst.FIELD_VALUE_INVALID,getLabelOrName(clazz))+":"+e.getMessage());
				throw new ValidateException(e.getMessage());
			}
		}
		
		List<Field> fields = ToolUtilities.getAllField(obj.getClass(), false);
		for(Field field : fields) {
			Object fieldValue = ToolUtilities.getFieldValue(obj, field);
			NotNull fieldNotNull = field.getAnnotation(NotNull.class);
			if(fieldNotNull != null && fireValidate(fieldNotNull.triggerType(), triggerType)) {
				if(fieldValue == null) {
					throw new ValidateException(WebUtil.getString(WebI18nConst.FIELD_CAN_NOT_BE_NULL,getLabelOrName(field)));
				}
			}
			if(fieldValue == null)
				continue;
			Validator validator = field.getAnnotation(Validator.class);
			if(validator != null && fireValidate(validator.triggerType(), triggerType)) {
				Class<? extends FieldValidatorIntf> fieldVerify = (Class<? extends FieldValidatorIntf>) validator.value();
				FieldValidatorIntf verifyInst = ClassFactory.newInstance(fieldVerify);
				try {
					verifyInst.verify(obj, field.getName(), fieldValue);
				}catch (Exception e) {
					throw new ValidateException(WebUtil.getString(WebI18nConst.FIELD_VALUE_INVALID,fieldValue)+":"+e.getMessage());
				}
			}
			if(fieldValue != null) {
				NotEmpty fieldNotEmpty = field.getAnnotation(NotEmpty.class);
				if(fieldNotEmpty != null && fireValidate(fieldNotEmpty.triggerType(), triggerType)) {
					if(CmnUtil.isObjectEmpty(fieldValue)) {
						throw new ValidateException(WebUtil.getString(WebI18nConst.FIELD_CAN_NOT_BE_EMPTY,getLabelOrName(field)));
					}
				}
				if (obj.getClass().isArray()) {
					Object[] objArr = (Object[])fieldValue;
					for(Object fieldV : objArr) {
						if(fieldV != null)
							verify(fieldV.getClass(), fieldV,triggerType);
					}
				}else if (obj instanceof Map) {
					Map map = (Map)fieldValue;
					for(Object key : map.keySet()) {
						Object fieldV = map.get(key);
						verify(fieldV.getClass(), fieldV,triggerType);
					}
				}else if (obj instanceof Collection) {
					Collection list = (Collection)fieldValue;
					for(Object fieldV : list) {
						if(fieldV != null)
							verify(fieldV.getClass(), fieldV,triggerType);
					}
				}
			}
		}
	}

	@Override
	public boolean isBaseType(Object object) {
		Class className = object.getClass();
		if(className.isPrimitive())
			return true;
		if (className.equals(java.lang.Integer.class) || className.equals(java.lang.Byte.class)
				|| className.equals(java.lang.Long.class) || className.equals(java.lang.Double.class)
				|| className.equals(java.lang.Float.class) || className.equals(java.lang.Character.class)
				|| className.equals(java.lang.Short.class) || className.equals(java.lang.Boolean.class)
				|| className.equals(java.lang.String.class)) {
			return true;
		}
		return false;
	
	}
	
	@Override
	public boolean isNumber(Object object) {
		Class className = object.getClass();
		if (className.equals(java.lang.Integer.class) 
				|| className.equals(int.class)
				|| className.equals(java.lang.Long.class) 
				|| className.equals(long.class)
				|| className.equals(java.lang.Double.class)
				|| className.equals(double.class)
				|| className.equals(java.lang.Float.class) 
				|| className.equals(float.class)
				|| className.equals(java.lang.Short.class) 
				|| className.equals(short.class)) {
			return true;
		}
		return false;
	}
	
	@Override
	public Date parseString(String timeStr, String format) throws Exception {
		return getDateFormat(format).parse(timeStr);
	}
	
	@Override
	public String formatDate(long timeMills, String format) throws Exception {
		return getDateFormat(format).format(new Date(timeMills));
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public Pair<String, IProgress> newProgress(String title, String stasticMsg, boolean showStaticMsg,Map<String, Object> extendCfg) throws Exception {
		CSrvOutputProgress prog = new CSrvOutputProgress(true);
		prog.setTitle(title);
		prog.setStasticMsg(stasticMsg);
		prog.setShowStasticMsg(showStaticMsg);
		prog.setExtendCfg(extendCfg);
		CProgressProxy proxy = CProgressProxy.build(prog);
//		CRpcAdapter.setTempTimeout(24*60*60*1000);
		String uuid = ToolUtilities.allockUUIDWithUnderline();
		progressCache.put(uuid, prog);
		return new Pair<>(uuid,proxy);
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public <T> Pair<String, IProgress> newProgress(String title,Consumer<T> consumer) throws Exception {
		CSrvOutputProgress prog = new CSrvOutputProgress(true);
		prog.setTitle(title);
		CProgressProxy proxy = CProgressProxy.build(prog,consumer);
		String uuid = ToolUtilities.allockUUIDWithUnderline();
		progressCache.put(uuid, prog);
		return new Pair<>(uuid,proxy);
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public ProgressDetail getProgressDetail(String uuid) throws Exception {
		CSrvOutputProgress srvPro = progressCache.get(uuid);
		if(srvPro != null) {
			ProgressDetail result = new ProgressDetail();
			String title = srvPro.getTitle();
			String status = ProgressDetail.STATUS_NONE;
			int percent = 0;
			String msg = srvPro.getStasticMsg();
			String error = "";
			if(srvPro.isAlive()){
				status = ProgressDetail.STATUS_RUNNING;
				if(!srvPro.isShowStasticMsg())
					msg = srvPro.getKeepMessage();
				percent = srvPro.getPercent();
			}else if(!srvPro.isResultOK()){
				if(srvPro.getException() instanceof UserCancelOperation){
					status = ProgressDetail.STATUS_ERROR;
				}else{
					status = ProgressDetail.STATUS_ERROR;
					msg = IAlarmService.get().getErrorBrief(srvPro.getException());
					error = IAlarmService.get().getErrorMsg(srvPro.getException());
				}
				percent = srvPro.getPercent();
			}else{
				status = ProgressDetail.STATUS_OK;
				msg = srvPro.getKeepMessage();
				percent = srvPro.getPercent();
			}
			if(status == ProgressDetail.STATUS_ERROR) {
				result.setStatus(status);
				result.setMsg(msg);
				result.setError(error);
			}else if(status == ProgressDetail.STATUS_RUNNING) {
				result.setStatus(status);
				result.setMsg(msg);
			}else if(status == ProgressDetail.STATUS_OK) {
//				if(result.getStatus() == ProgressDetail.STATUS_OK || result.getStatus() == ProgressDetail.STATUS_NONE) {
					result.setStatus(status);
//				}
			}
			result.setName(title);
			result.setShowStaticMsg(srvPro.isShowStasticMsg());
			Map<String, Object> extendCfg = srvPro.getExtendCfg();
			if(!CmnUtil.isMapEmpty(extendCfg)) {
				Object showProgressBar = extendCfg.get(ProgressDetail.ShowProgressBar);
				Object isProgressUnchoke = extendCfg.get(ProgressDetail.IsProgressUnchoke);
				if (!CmnUtil.isObjectEmpty(showProgressBar)) {
					result.setShowProgressBar((boolean)showProgressBar);
				}
				if (!CmnUtil.isObjectEmpty(isProgressUnchoke)) {
					result.setProgressUnchoke((boolean)isProgressUnchoke);
				}
			}
			result.setPercent(percent > 100 ? 100 : percent);
			return result;
		}
		return null;
	}
	
	@Override
	public int getProgressPercent(String uuid) throws Exception {
		CSrvOutputProgress<?> srvPro = progressCache.get(uuid);
		if(srvPro != null) {
			return srvPro.getPercent();
		}
		return 0;
	}
	
	@Override
	public void cancelProgress(String uuid) throws Exception {
		CSrvOutputProgress<?> srvPro = progressCache.get(uuid);
		if(srvPro != null) {
			srvPro.setCancel(true);
		}
	}
	
	@Override
	public boolean isProgressAlive(String uuid) throws Exception {
		CSrvOutputProgress<?> srvPro = progressCache.get(uuid);
		if(srvPro != null) {
			return srvPro.isAlive();
		}
		return false;
	}
	
	@Override
	public Object getProgressResult(String uuid)throws Exception{
		CSrvOutputProgress<?> srvPro = progressCache.get(uuid);
		if(srvPro != null) {
			return srvPro.getResult();
		}
		return null;
	}
	@Override
	public void setException(String uuid,Exception e)throws Exception{
		CSrvOutputProgress<?> srvPro = progressCache.get(uuid);
		if(srvPro != null) {
			srvPro.setException(e);
		}
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void setProgressResult(String uuid, Object result) throws Exception {
		CSrvOutputProgress srvPro = progressCache.get(uuid);
		if(srvPro != null) {
			srvPro.setResult(result);
		}
	}
	
	@Override
	public <T> List<T> sortDataByOrderSeq(List<T> data, String orderFieldName,List<String> orderSeqs) throws Exception {
		Map<String,T> map = new HashMap<>();
		for(T t : data) {
			String value = (String) ToolUtilities.getFieldValue(t, orderFieldName);
			map.put(value, t);
		}
		List<T> orderDatas = new ArrayList<>();	
		for(String orderSeq : orderSeqs) {
			T t = map.get(orderSeq);
			if(t != null) {
				orderDatas.add(t);
			}
		}
		return orderDatas;
	}

	@Override
	public void setProgressExtendCfg(String uuid, Map<String, Object> extendCfg) throws Exception {
		CSrvOutputProgress srvPro = progressCache.get(uuid);
		if(srvPro != null) {
			srvPro.setExtendCfg(extendCfg);
		}
	}

	@Override
	public Map<String, Object> getProgressExtendCfg(String uuid) throws Exception {
		CSrvOutputProgress srvPro = progressCache.get(uuid);
		if(srvPro != null) {
			return srvPro.getExtendCfg();
		}
		return null;
	}
}
