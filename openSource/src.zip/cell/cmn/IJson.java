package cell.cmn;

import java.io.Reader;
import java.lang.reflect.Type;

import cell.ResourceCellIntf;

public interface IJson extends ResourceCellIntf {

	public String toJson(Object obj);

	public <T> T fromJsonByType(String json, Type typeOfT);

	public <T> T fromJson(String json, Class<T> clazz);

	public <T> T fromJson(Reader reader, Class<T> classOfT);

	public <T> T forceCast(Class<T> type, Object obj);

	public <T> T forceCastByType(Type type, Object obj);

	public <T> T cloneObject(Object obj);
}
