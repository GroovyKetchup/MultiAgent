package cell.cmn;

import java.lang.reflect.Field;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import com.kwaidoo.verify.ValidateTriggerType;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.leavay.nio.crpc.Pingable;

import bap.cells.Cells;
import cell.ServiceCellIntf;
import web.dto.Pair;
import web.dto.ProgressDetail;

public interface ICmnService extends ServiceCellIntf,Pingable{
	
	public static ICmnService get() {
		return Cells.get(ICmnService.class);
	}
	
	public String getLabelOrName(Class<?> clazz) throws Exception;
	
	public String getLabelOrName(Field field) throws Exception;
	
	public void verify(Class<?> clazz,Object obj,ValidateTriggerType triggerType)throws Exception;
	
	public boolean isBaseType(Object object);
	
	public boolean isNumber(Object object) ;
	
	public Date parseString(String timeStr,String format)throws Exception;
	
	public String formatDate(long timeMills,String format)throws Exception;
	
	@SuppressWarnings("rawtypes")
	public Pair<String,IProgress> newProgress(String title, String stasticMsg, boolean showStaticMsg, Map<String, Object> extendCfg)throws Exception;
	
	@SuppressWarnings("rawtypes")
	public <T> Pair<String, IProgress> newProgress(String title,Consumer<T> consumer) throws Exception;
	
	public ProgressDetail getProgressDetail(String uuid)throws Exception;
	
	public boolean isProgressAlive(String uuid)throws Exception;
	
	public void cancelProgress(String uuid)throws Exception;
	
	public int getProgressPercent(String uuid)throws Exception;
	
	public Object getProgressResult(String uuid)throws Exception;
	
	public void setException(String uuid,Exception e)throws Exception;
	
	public void setProgressResult(String uuid,Object result)throws Exception;
	
	public void setProgressExtendCfg(String uuid,Map<String, Object> extendCfg)throws Exception;
	
	public Map<String, Object> getProgressExtendCfg(String uuid)throws Exception;
	/**
	 * 根据排序属性的顺序值对结果进行排序
	 * @param <T>
	 * @param data
	 * @param orderFieldName
	 * @param orderSeqs
	 * @return
	 * @throws Exception
	 */
	public <T> List<T> sortDataByOrderSeq(List<T> data, String orderFieldName,List<String> orderSeqs)throws Exception; 
	
}
