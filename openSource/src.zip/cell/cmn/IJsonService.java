package cell.cmn;

import com.leavay.nio.crpc.Pingable;

import bap.cells.Cells;
import cell.ServiceCellIntf;
import cmn.util.IJsonBuilder;

public interface IJsonService extends ServiceCellIntf,Pingable{
	
	public static IJsonService get() {
		return Cells.get(IJsonService.class);
	}

	public IJson getJson();
	
	public IJson getJsonWithNull();
	
	public IJson getPrettyJson();
	
	public IJson getReferenceJson();
	
	public IJson newIJson(IJsonBuilder builder);
}
