package cell.cmn;

import com.cdao.model.type.KeyFormField;
import com.cdao.model.type.KeyValue;
import com.cdao.model.type.Password;
import com.leavay.common.gson.Gson;
import com.leavay.common.gson.GsonBuilder;
import com.leavay.common.gson.TypeAdapter;
import com.leavay.common.gson.TypeAdapterFactory;
import com.leavay.common.reflect.TypeToken;
import com.leavay.common.util.javac.ClassFactory;

import bap.cells.EmptyServiceCell;
import cmn.util.IJsonBuilder;
import web.util.KeyFormFieldTypeAdapter;
import web.util.KeyValueTypeAdapter;
import web.util.PasswordTypeAdapter;

public class CJsonService extends EmptyServiceCell implements IJsonService{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2917710079335930122L;
	
	public final static TypeAdapterFactory TypeAdapterFactory = new TypeAdapterFactory() {
		@SuppressWarnings("unchecked")
		@Override
		public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
			if (type.getRawType() == KeyValue.class) {
				return (TypeAdapter<T>) new KeyValueTypeAdapter();
			}else if (type.getRawType() == KeyFormField.class) {
				return (TypeAdapter<T>) new KeyFormFieldTypeAdapter();
			} else if (type.getRawType() == Password.class) {
				return (TypeAdapter<T>) new PasswordTypeAdapter();
			}
			return null;
		}
	};

	private static Gson gson = null;
	private static GsonBuilder builder = new GsonBuilder();
	static {
		builder.registerTypeAdapterFactory(TypeAdapterFactory);
	}

	public static synchronized Gson getGson() {
		if (gson == null) {
			GsonBuilder builder = new GsonBuilder();
			builder.registerTypeAdapterFactory(TypeAdapterFactory);
			gson = builder.create();
		}
		gson.resetRead();
		gson.reseWrite();
		// TODO 设置插件类的ClassLoader
		gson.setClassLoader(ClassFactory.getValidClassLoader());
		return gson;
	}
	
	private static Gson gsonWithNull = null;
	private static GsonBuilder builderWithNull = new GsonBuilder();
	static {
		builderWithNull.registerTypeAdapterFactory(TypeAdapterFactory);
		builderWithNull.serializeNulls();
	}

	public static synchronized Gson getGsonWithNull() {
		if (gsonWithNull == null) {
			GsonBuilder builder = new GsonBuilder();
			builder.registerTypeAdapterFactory(TypeAdapterFactory);
			builder.serializeNulls();
			gsonWithNull = builder.create();
		}
		gsonWithNull.resetRead();
		gsonWithNull.reseWrite();
		// TODO 设置插件类的ClassLoader
		gsonWithNull.setClassLoader(ClassFactory.getValidClassLoader());
		return gsonWithNull;
	}

	private static Gson prettyGson = null;

	public static synchronized Gson getPrettyGson() {
		if (prettyGson == null) {
			GsonBuilder builder = new GsonBuilder();
			builder.registerTypeAdapterFactory(TypeAdapterFactory);
			prettyGson = builder.setPrettyPrinting().create();
		}
		prettyGson.resetRead();
		prettyGson.reseWrite();
		// TODO 设置插件类的ClassLoader
		prettyGson.setClassLoader(ClassFactory.getValidClassLoader());
		return prettyGson;
	}

	private static Gson referenceGson = null;

	public static synchronized Gson getReferenceGson() {
		if (referenceGson == null) {
			GsonBuilder builder = new GsonBuilder();
			builder.registerTypeAdapterFactory(TypeAdapterFactory);
			builder.setTypeCheckForOutClassName((clazz) -> {
				return clazz.getName().startsWith("web.") || clazz == Object.class;
			});
			builder.serializeNulls();
			builder.withReference();
			referenceGson = builder.setPrettyPrinting().create();
		}
		referenceGson.resetRead();
		referenceGson.reseWrite();
		// TODO 设置插件类的ClassLoader
		referenceGson.setClassLoader(ClassFactory.getValidClassLoader());
		return referenceGson;
	}
	
	public IJson getJson() {
//		gson = builder.create();
//		gson.resetRead();
//		gson.reseWrite();
//		// TODO 设置插件类的ClassLoader
//		gson.setClassLoader(JPluginAgentMgr.getInstance().getValidClassLoader());
//		return new CJson(gson);
		return new CJson(getGson());
	}
	
	public IJson getJsonWithNull() {
//		Gson gsonWithNull = builderWithNull.create();
//		gsonWithNull.resetRead();
//		gsonWithNull.reseWrite();
//		// TODO 设置插件类的ClassLoader
//		gsonWithNull.setClassLoader(JPluginAgentMgr.getInstance().getValidClassLoader());
//		return new CJson(gsonWithNull);
		return new CJson(getGsonWithNull());
	}
	
	public IJson getPrettyJson() {
		return new CJson(getPrettyGson());
	}
	
	public IJson getReferenceJson() {
		return new CJson(getReferenceGson());
	}
	
	@Override
	public IJson newIJson(IJsonBuilder builder) {
		GsonBuilder gsonBuilder = new GsonBuilder();
		if(builder.isSerializeNulls()) {
			gsonBuilder.serializeNulls();
		}
		if(builder.isPrettyPrinting()) {
			gsonBuilder.setPrettyPrinting();
		}
		if(!builder.isEscapeHtmlChars()) {
			gsonBuilder.disableHtmlEscaping();
		}
		if(builder.isWithReference()) {
			gsonBuilder.withReference();
		}
		if(builder.getTypeCheckForOutClassName() != null) {
			gsonBuilder.setTypeCheckForOutClassName(builder.getTypeCheckForOutClassName());
		}
		Gson gson = gsonBuilder.create();
		gson.setClassLoader(ClassFactory.getValidClassLoader());
		return new CJson(gson);
	}

}
