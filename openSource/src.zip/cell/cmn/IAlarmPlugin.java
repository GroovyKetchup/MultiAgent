package cell.cmn;

import java.lang.reflect.InvocationTargetException;

import com.kwaidoo.ms.tool.ToolUtilities;

import bap.cells.Cells;
import cell.PluginCellIntf;
import cmn.exception.ExceptionHandler;

public interface IAlarmPlugin extends PluginCellIntf{

	public static IAlarmPlugin get() {
		return Cells.get(IAlarmPlugin.class);
	}
	
	public default ExceptionHandler getExceptionHandler(Throwable err){
		return null;
	}
	
	public default String getErrorCode(Throwable err) {
		return null;
	}
	
	public default String getErrBrief(Throwable err) {
		return null;
	}
	
	public default String getErrorMsg(Throwable err) {
		if(err instanceof InvocationTargetException) {
			return ToolUtilities.getExceptionStatck(((InvocationTargetException) err).getTargetException());
		}
		return ToolUtilities.getExceptionStatck(err);
	}
}
