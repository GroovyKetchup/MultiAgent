package cell.cmn.cache;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.leavay.ms.tool.CmnUtil;

import bap.cells.BasicCell;

public class CMapCell<K, V> extends BasicCell implements IMapCell<K, V>
{
    private static final long serialVersionUID = -5873426427143765985L;
    
    transient ConcurrentHashMap<K, V> _map = new ConcurrentHashMap();

    @Override
    public void onClose()
    {
        clear();
    }

    @Override
    public void putValue(K key, V value)
    {
        _map.put(key, value);
    }

    @Override
    public Object getValue(K key)
    {
        return _map.get(key);
    }

    @Override
    public Object remove(K key)
    {
        return _map.remove(key);
    }

    @Override
    public Map<K, V> peekAll()
    {
        return new HashMap(_map);
    }
    
    public int size()
    {
        return _map.size();
    }
    
    public boolean isEmpty()
    {
        return _map.isEmpty();
    }
    
    public boolean contain(K key)
    {
        return _map.containsKey(key);
    }
    
    public boolean contains(V value)
    {
        return _map.contains(value);
    }
    
    public void putAll(Map<K, V> m)
    {
        _map.putAll(m);
    }
    
    public Set<K> keySet()
    {
        return new HashSet(_map.keySet());
    }

    @Override
    public void clear()
    {
        if (_map != null)
            _map.clear();
    }
    
    public String toString()
    {
        return getClass().getSimpleName()+"(size="+CmnUtil.getObjectSize(_map)+", hash="+hashCode()+", last access="+getLastAccess()+", expire="+getExpireTime()+")";
    }
}
