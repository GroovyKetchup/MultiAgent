package cell.cmn.cache;

import java.util.Map;
import java.util.Set;

import cell.*;

/**
 * 该CELL是对MAP的远程包装, 支持远程访问/云联调等
 * 主要用于一些场景下不便于把整个map传来传去的时候 , 可将其以资源CELL的方式提供远程访问
 *
 */
public interface IMapCell<K, V> extends ResourceCellIntf
{
    public void putValue(K key, V value);

    public Object getValue(K key);

    public Object remove(K key);

    public Map<K, V> peekAll();
    
    public void clear();

    public int size();

    public Set<K> keySet();
    
    public boolean isEmpty();
    
    public boolean contain(K key);
    
    public boolean contains(V value);
    
    public void putAll(Map<K, V> m);
}