package cell.cmn;

import java.io.Reader;
import java.lang.reflect.Type;

import com.leavay.common.gson.Gson;

import bap.cells.BasicCell;

public class CJson extends BasicCell implements IJson, AutoCloseable {

	private Gson gson;
	
	public CJson(Gson gson) {
		this.gson = gson;
	}
	
	public Gson getGson() {
		return gson;
	}

	@Override
	public void onClose() {
		//释放gson的时候将GsonContext置空,避免内存泄漏
		gson.reset();
	}

	@Override
	public String toJson(Object obj) {
		return gson.toJson(obj);
	}

	@Override
	public <T> T fromJsonByType(String json, Type typeOfT) {
		return gson.fromJson(json, typeOfT);
	}

	@Override
	public <T> T fromJson(String json, Class<T> clazz) {
		return gson.fromJson(json, clazz);
	}

	@Override
	public <T> T fromJson(Reader reader, Class<T> classOfT) {
		return getGson().fromJson(reader, classOfT);
	}

	@Override
	public <T> T forceCast(Class<T> type, Object obj) {
		String json = toJson(obj);
		return fromJson(json, type);
	}

	@Override
	public <T> T forceCastByType(Type type, Object obj) {
		String json = toJson(obj);
		return fromJsonByType(json, type);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public <T> T cloneObject(Object obj) {
		String json = toJson(obj);
		return (T) fromJson(json, obj.getClass());
	}

}
