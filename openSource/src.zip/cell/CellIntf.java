package cell;

import bap.cells.CellConfig;
import bap.cells.Cells;
import crpc.CRpcCallbackIntf;
import crpc.CallbackLocalMethod;

/**
 * 所有Cell的接口必须继承该接口
 * 
 * 普通CELL或资源型CELL的实现，建议派生于BasicCell
 * 
 * 
 * 实现类样例：
 * public class CDemo extends BasicCell implements IDemo
 * {
 *      public void test(){
 *          //Do Something Customized
 *      };
 * }
 */
public interface CellIntf extends CRpcCallbackIntf
{
    @CallbackLocalMethod
    public default boolean isSingleton() {
        return false;
    };
    
    /**
     * 有些callback是不支持桥接的（但经过反复斟酌，单例服务类也应该允许转发，否则异地开发单例服务就无法联调了）
     * 所以应该是都允许桥接转发，可能极个别特例才不允许桥接转发（也就意味着不允许远程联调）
     */
    @CallbackLocalMethod
    public default boolean isSupportBridge()
    {
        return true;
    }
    
    /**
     * 初始化Cell（如果是Singleton的，则在初次创建时调用）
     * 
     * 子类可以申明近似函数（带强类型参数的），例如initCell(String name, Date date)等，因为平台不是直接调用，而是通过反射找到最匹配的函数进行调用（以此方便开发以及强类型校验）
     * @param params
     */
    public default void initCell(Object ... params) {};
    
    /**
     * 当服务启动时，会先触发reset，以便重启服务时能重新加载配置
     */
    public void resetConfig();
    
    /**
     * 获取当前CELL（主要是服务类）对应的配置对象
     */
    public default CellConfig getConfig()
    {
        return Cells.getConfig(getClass());
    }

    /**
     * 获取当前CELL（主要是服务类）对应的配置对象
     */
    public default <T> T getConfig(Class<T> cls)
    {
        return (T)getConfig();
    }
}
