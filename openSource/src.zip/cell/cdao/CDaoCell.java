package cell.cdao;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import org.nutz.dao.Cnd;
import org.nutz.dao.FieldMatcher;
import org.nutz.dao.SimpleFieldMatcher;
import org.nutz.dao.entity.Entity;
import org.nutz.dao.impl.entity.field.NutMappingField;
import org.nutz.dao.pager.Pager;

import com.cdao.dto.CPager;
import com.cdao.dto.DataRow;
import com.cdao.exception.CDaoCasExcpetion;
import com.cdao.impl.entity.field.GID;
import com.cdao.mgr.CDao;
import com.cdao.mgr.CDaoEntity;
import com.cdao.mgr.CSession;
import com.cdao.mgr.CommitListener;
import com.cdao.mgr.lock.LockFailException;
import com.cdao.mgr.lock.NoLockException;
import com.cdao.model.CDimension;
import com.cdao.model.CDo;
import com.cdao.model.CDoAttach;
import com.cdao.model.CDoBasic;
import com.cdao.model.CDoGlobalNotice;
import com.cdao.model.CDoLink;
import com.cdao.model.CDoModel;
import com.leavay.common.util.Pair;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.leavay.common.util.clone.CloneWithReference;
import com.leavay.common.util.javac.ClassFactory;
import com.leavay.ms.tool.CmnUtil;

import bap.cells.BasicCell;
import cmn.util.AutoLock;

public class CDaoCell extends BasicCell implements IDao
{
    private static final long serialVersionUID = -8936322053924872651L;

    @CloneWithReference
    transient CDao _dao;

    /**
     * 中央缓存：在核心提供全局通用缓存，当需要和Transaction一起传递、分享的缓存数据可以放在这里 此缓存只存在于主控，暴露远程访问接口而已
     */
    private transient ReentrantLock _lc = new ReentrantLock();

    private transient ConcurrentHashMap<String, Object> _centerCache;

    public CDaoCell(CDao dao)
    {
        CmnUtil.assertNotNull(dao, "NULL DAO object");

        _dao = dao;
    };

    public CDao getDao()
    {
        return _dao;
    }

    public void onClose()
    {
        // 有可能被反复触发释放
        if (_dao != null)
        {
            _dao.close();
            _dao = null;
        }
    }

    public <T extends CDoBasic> T createDo(T o) throws Exception
    {
        return getDao().createDo(o);
    }

    public void commit()
    {
        getDao().commit();
    }

    public CSession getSession()
    {
        return getDao().getSession();
    }

    public void setSession(CSession session)
    {
        getDao().setSession(session);
    }

    public CDoBasic createDo(CDoBasic o, boolean lockTarget) throws Exception
    {
        return getDao().createDo(o, lockTarget);
    }
    
    public <T extends CDoBasic> T createDo(T o, boolean lockTarget, boolean givebackSlaveTable) throws Exception
    {
        return getDao().createDo(o, lockTarget, givebackSlaveTable);
    }

    public void createLink(GID src, GID dst, String flag) throws Exception
    {
        getDao().createLink(src, dst, flag);
    }

    public void createLink(CDoLink link) throws Exception
    {
        getDao().createLink(link);
    }

    public boolean updateLink(String src, String dst, String flag, Map<String, Object> mapValue)
    {
        return getDao().updateLink(src, dst, flag, mapValue);
    }

    public int updateLinks(Cnd cnd, Map<String, Object> mapValue)
    {
        return getDao().updateLinks(cnd, mapValue);
    }

    public List<CDoAttach> queryAttachBrief(String uuid, String field)
    {
        return getDao().queryAttachBrief(uuid, field);
    }

    public List<CDoAttach> queryAttach(String uuid, String field)
    {
        return getDao().queryAttach(uuid, field);
    }

    public CDoAttach queryAttach(String uuid, String field, String attachName)
    {
        return getDao().queryAttach(uuid, field, attachName);
    }

    public void saveAttach(GID pGid, String field, List<CDoAttach> lstAttach, boolean deleteOthers) throws Exception
    {
        getDao().saveAttach(pGid, field, lstAttach, deleteOthers);
    }

    public void saveAttach(GID pGid, Map<String, List<CDoAttach>> mapAttach, boolean deleteOthers) throws Exception
    {
        getDao().saveAttach(pGid, mapAttach, deleteOthers);
    }

    public void updateDo(CDoBasic o) throws Exception
    {
        getDao().updateDo(o);
    }

    public void updateDos(String clsName, Set<String> setUuids, Map<String, Object> mapValue, int commitBatchCount) throws Exception
    {
        getDao().updateDos(clsName, setUuids, mapValue, commitBatchCount);
    }

    public int updateDos(String clsName, Cnd cnd, Map<String, Object> mapValue, int commitBatchCount) throws Exception
    {
        return getDao().updateDos(clsName, cnd, mapValue, commitBatchCount);
    }

    public int updateDos(IProgress prog, String clsName, Cnd cnd, Map<String, Object> mapValue, int commitBatchCount) throws Exception
    {
        return getDao().updateDos(prog, clsName, cnd, mapValue, commitBatchCount);
    }

    public int updateDos(String clsName, Cnd cnd, Map<String, Object> mapValue) throws Exception
    {
        return getDao().updateDos(clsName, cnd, mapValue);
    }

    public void dblockDimShare(Class<CDoBasic> cls, Map<String, Object> mapValue) throws Exception
    {
        getDao().dblockDimShare(cls, mapValue);
    }

    public void updateDoField(CDoBasic o, String field, Object value) throws Exception
    {
        getDao().updateDoField(o, field, value);
    }

    public void updateDo(GID gid, Map<String, Object> mapValue) throws Exception
    {
        getDao().updateDo(gid, mapValue);
    }

    public void updateDo(CDoBasic o, String... updateFields) throws Exception
    {
        getDao().updateDo(o, updateFields);
    }

    public void updateDo(CDoBasic o, Map<String, Object> mapValue) throws Exception
    {
        getDao().updateDo(o, mapValue);
    }

    public void deleteDo(GID gid) throws Exception
    {
        getDao().deleteDo(gid);
    }

    public void deleteDo(CDoBasic o) throws Exception
    {
        getDao().deleteDo(o);
    }

    public int deleteDos(IProgress prog, String clsName, Cnd cnd, int commitBatchCount) throws Exception
    {
        return getDao().deleteDos(prog, clsName, cnd, commitBatchCount);
    }

    public int deleteDos(String clsName, Cnd cnd) throws Exception
    {
        return getDao().deleteDos(clsName, cnd);
    }

    public boolean isClassDependable(String className) throws Exception
    {
        return getDao().isClassDependable(className);
    }

    public void setSavepoint(String spId)
    {
        getDao().setSavepoint(spId);
    }

    public void rollback()
    {
        getDao().rollback();
    }

    public void rollback(String sp)
    {
        getDao().rollback(sp);
    }

    public void rollbackAndThrow(String sp, Throwable err) throws Exception
    {
        getDao().rollback(sp);

        CmnUtil.throwException(err);
    }

    public <T> Entity<T> prepareEntity(Class<T> classOfT)
    {
        return getDao().prepareEntity(classOfT);
    }

    public void verifyFieldValue(Class doClass, Map<String, Object> mapValue) throws Exception
    {
        getDao().verifyFieldValue(doClass, mapValue);
    }

    public void verifyFieldValue(Object dataObject, NutMappingField f) throws Exception
    {
        getDao().verifyFieldValue(dataObject, f);
    }

    public void verifyFieldValue(Object dataObject, String fieldName, boolean nullable, String checker) throws Exception
    {
        getDao().verifyFieldValue(dataObject, fieldName, nullable, checker);
    }

    public void verifyFieldValue(Class mdClass, String fieldName, Object fieldValue, boolean nullable, String checker) throws Exception
    {
        getDao().verifyFieldValue(mdClass, fieldName, fieldValue, nullable, checker);
    }

    public void checkCreateAuth(CDoBasic o)
    {
        getDao().checkCreateAuth(o);
    }

    public void readlockDependTarget(String dstClass, String dstUuid, boolean includeAncestor) throws Exception
    {
        getDao().readlockDependTarget(dstClass, dstUuid, includeAncestor);
    }

    public void createDepend(GID src, GID dst) throws Exception
    {
        getDao().createDepend(src, dst);
    }

    public int deleteDepend(String srcUuid, String dstUuid)
    {
        return getDao().deleteDepend(srcUuid, dstUuid);
    }

    public <T extends CDoBasic> List<T> createDos(List<T> lstDo) throws Exception
    {
        return getDao().createDos(lstDo);
    }

    public <T extends CDoBasic> List<T> createDos(List<T> lstDo, boolean lockDependTarget) throws Exception
    {
        return getDao().createDos(lstDo, lockDependTarget);
    }

    public <T extends CDoBasic> List<T> createDos(List<T> lstDo, boolean lockDependTarget, boolean givebackSlaveTable) throws Exception
    {
        return getDao().createDos(lstDo, lockDependTarget, givebackSlaveTable);
    }

    public boolean isPrintDebug()
    {
        return getDao().isPrintDebug();
    }

    public void setPrintDebug(boolean debug)
    {
        getDao().setPrintDebug(debug);
    }

    public void debug(String log)
    {
        getDao().debug(log);
    }

    public void setDblockTimeoutMs(int dblockTimeoutMs)
    {
        getDao().setDblockTimeoutMs(dblockTimeoutMs);
    }
    
    public long getDbLockTimeout()
    {
        return getDao().getDbLockTimeout();
    }

    public int getDbLockTimeoutS()
    {
        return getDao().getDbLockTimeoutS();
    }

    public int getUpdateTimeoutS()
    {
        return getDao().getUpdateTimeoutS();
    }

    public int getCreateTimeoutS()
    {
        return getDao().getCreateTimeoutS();
    }

    public int getBatchUpdateTimeoutS()
    {
        return getDao().getBatchDeleteTimeoutS();
    }

    public int getRebuildOneFollowerCodeTimeout()
    {
        return getDao().getRebuildOneFollowerCodeTimeout();
    }

    public int getDeleteTimeoutS()
    {
        return getDao().getDeleteTimeoutS();
    }

    public int getBatchDeleteTimeoutS()
    {
        return getDao().getBatchDeleteTimeoutS();
    }

    public int getBatchDeleteTimeoutS(int rows)
    {
        return getDao().getBatchDeleteTimeoutS(rows);
    }

    public boolean dblockShare(GID gid) throws Exception
    {
        return getDao().dblockShare(gid);
    }

    public boolean dblockShare(String uuid, String className) throws Exception
    {
        return getDao().dblockShare(uuid, className);
    }

    public boolean dblockShare(CDoBasic o) throws Exception
    {
        return getDao().dblockShare(o);
    }

    public boolean dblockShare(Class cls, String uuid) throws Exception
    {
        return getDao().dblockShare(cls, uuid);
    }

    public void dblockShare(Map<String, String> mapUuidClass) throws Exception
    {
        getDao().dblockShare(mapUuidClass);
    }

    public boolean dblockWrite(GID gid) throws Exception
    {
        return getDao().dblockWrite(gid);
    }

    public void dblockWrite(Map<String, String> mapUuidClass) throws Exception
    {
        getDao().dblockWrite(mapUuidClass);
    }

    public int clearProjectionByModel(Class projectionClass, Set<String> fields) throws Exception
    {
        return getDao().clearProjectionByModel(projectionClass, fields);
    }

    public int clearProjectionByUuid(Class projectionClass, String field, String srcUuid) throws Exception
    {
        return getDao().clearProjectionByUuid(projectionClass, field, srcUuid);
    }

    public int clearRelatedProjectionFields(CDoBasic o) throws Exception
    {
        return getDao().clearRelatedProjectionFields(o);
    }

    public List<Pair<String, String>> searchDimensionRef(String dimClass, boolean includeChild) throws ClassNotFoundException
    {
        return getDao().searchDimensionRef(dimClass, includeChild);
    }

    public int deleteSlave(CDoBasic o) throws Exception
    {
        return getDao().deleteSlave(o);
    }

    public int deleteSlave(CDoBasic o, String field) throws Exception
    {
        return getDao().deleteSlave(o, field);
    }

    public int deleteSlave(String slaveClass, String masterUuid, String masterField) throws Exception
    {
        return getDao().deleteSlave(slaveClass, masterUuid, masterField);
    }

    public int deleteSlave(String slaveClass, String masterUuid) throws Exception
    {
        return getDao().deleteSlave(slaveClass, masterUuid);
    }

    public int deleteSlaveByModel(String slaveClass, String masterClass) throws Exception
    {
        return getDao().deleteSlaveByModel(slaveClass, masterClass);
    }

    public int deleteSlaveByModel(String slaveClass, String masterClass, String masterField) throws Exception
    {
        return getDao().deleteSlaveByModel(slaveClass, masterClass, masterField);
    }

    public int deleteForeignChild(CDoBasic parent) throws Exception
    {
        return getDao().deleteForeignChild(parent);
    }

    public int deleteForeignChild(String childClass, String parentKey) throws Exception
    {
        return getDao().deleteForeignChild(childClass, parentKey);
    }

    public void deleteAttachOf(String uuid) throws Exception
    {
        getDao().deleteAttachOf(uuid);
    }

    public void deleteAttachOf(String uuid, String field) throws Exception
    {
        getDao().deleteAttachOf(uuid, field);
    }

    public void deleteLinkOf(String uuid)
    {
        getDao().deleteLinkOf(uuid);
    }

    public void deleteLink(String srcUuid, String dstUuid)
    {
        getDao().deleteLink(srcUuid, dstUuid);
    }

    public void deleteLink(Cnd cnd)
    {
        getDao().deleteLink(cnd);
    }

    public void deleteLink(String srcUuid, String dstUuid, String flag)
    {
        getDao().deleteLink(srcUuid, dstUuid, flag);
    }

    public void deleteDependBoth(String uuid)
    {
        getDao().deleteDependBoth(uuid);
    }

    public Map<String, String> queryDependSourceOfModel(String className)
    {
        return getDao().queryDependSourceOfModel(className);
    }

    public String queryDependTargetClass(String srcClass, String dstUuid)
    {
        return getDao().queryDependTargetClass(srcClass, dstUuid);
    }

    public CDoBasic queryDependTarget(String srcClass, String dstUuid, String... fields) throws Exception
    {
        return getDao().queryDependTarget(srcClass, dstUuid, fields);
    }

    public Map<String, List<String>> queryDependTarget(String dstUuid, List<String> srcClass, String srcField)
    {
        return getDao().queryDependTarget(dstUuid, srcClass, srcField);
    }

    public List<String> queryDependTarget(String dstUuid, String srcClass, String srcField)
    {
        return getDao().queryDependTarget(dstUuid, srcClass, srcField);
    }

    public Map<String, List<String>> queryDependTarget(String dstUuid, List<String> srcClass, String srcField, CPager pager)
    {
        return getDao().queryDependTarget(dstUuid, srcClass, srcField, pager);
    }

    public Class prepareModelClass(String className) throws Exception
    {
        return getDao().prepareModelClass(className);
    }

    public CDaoEntity buildEntity(String className) throws Exception
    {
        return new CDaoEntity(getDao().buildEntity(ClassFactory.loadClass(className)));
    }

    public CDaoEntity getEntity(String className) throws Exception
    {
        return new CDaoEntity(getDao().getEntity(ClassFactory.loadClass(className)));
    }
    
    @Override
    public CDaoEntity getCachedEntity(String className) throws Exception
    {
        return new CDaoEntity(getDao().getCachedEntity(ClassFactory.loadClass(className)));
    }
    
    public CDaoEntity getCDaoEntity(String className) throws Exception
    {
        return getDao().getCDaoEntity(className);
    }

    public Object newObject(String className) throws Exception
    {
        return getDao().newObject(className);
    }

    public CDoBasic newObject(String className, String uuid) throws Exception
    {
        return getDao().newObject(className, uuid);
    }

    public CDoBasic newObject(GID gid) throws Exception
    {
        return getDao().newObject(gid);
    }

    public Map<String, String> queryAllDependSource(String depTarget)
    {
        return getDao().queryAllDependSource(depTarget);
    }

    public Map<String, String> queryAllDependTarget(String depSource)
    {
        return getDao().queryAllDependTarget(depSource);
    }

    // Key=UUID, Value=ClassName
    public Map<String, String> queryAllLinkSource(String lnkTarget, String flag)
    {
        return getDao().queryAllLinkSource(lnkTarget, flag);
    }

    // Key=UUID, Value=ClassName
    public Map<String, String> queryLinkSource(Set<String> lstTarget, String flag)
    {
        return getDao().queryLinkSource(lstTarget, flag);
    }

    // 查询所有“被”自己（linkSource）连接的对象，无限层
    // Key=UUID, Value=ClassName
    public Map<String, String> queryAllLinkTarget(String depSource, String flag)
    {
        return getDao().queryAllLinkTarget(depSource, flag);
    }

    // Key=UUID, Value=ClassName
    public Map<String, String> queryLinkTarget(Set<String> lstSource, String flag)
    {
        return getDao().queryLinkTarget(lstSource, flag);
    }

    public List querySlaveTable(GID masterGid, String field) throws Exception
    {
        return getDao().querySlaveTable(masterGid, field);
    }

    public void casUpdateDo(CDoBasic o, String name, Object value) throws CDaoCasExcpetion, Exception
    {
        getDao().casUpdateDo(o, name, value);
    }

    public void casUpdateDo(CDoBasic o, Map<String, Object> mapValue) throws CDaoCasExcpetion, Exception
    {
        getDao().casUpdateDo(o, mapValue);
    }

    public void dblockDimShare(String dimClass, boolean isMulti, String dimCode) throws Exception
    {
        getDao().dblockDimShare(dimClass, isMulti, dimCode);
    }

    public void dblockOneDimShare(String dimClass, String dimCode) throws Exception
    {
        getDao().dblockOneDimShare(dimClass, dimCode);
    }

    public MultiPageResult queryDoPage(String className, Cnd cnd, CPager pager) throws Exception
    {
        return getDao().queryDoPage(className, cnd, pager);
    }

    public MultiPageResult queryDoPage(String className, Cnd cnd, CPager pager, String... fields) throws Exception
    {
        return getDao().queryDoPage(className, cnd, pager, fields);
    }

    public <T> MultiPageResult<T> queryDoPage(Class<T> cls, Cnd cnd, CPager pager, String... fields)
    {
        return getDao().queryDoPage(cls, cnd, pager, fields);
    }

    public CDoModel queryModel(String className)
    {
        return getDao().queryModel(className);
    }

    public CDoModel prepareModel(String className)
    {
        return getDao().prepareModel(className);
    }

    public String queryDoClass(String uuid) throws Exception
    {
        return getDao().queryDoClass(uuid, null);
    }

    public CDoBasic queryDoByUuid(String uuid, List<String> lstClasses, String... fields) throws Exception
    {
        return getDao().queryDoByUuid(uuid, lstClasses, fields);
    }

    public boolean exists(GID gid) throws Exception
    {
        return getDao().exists(gid);
    }

    public boolean exists(Class clz, Cnd cnd) throws Exception
    {
        return getDao().exists(clz, cnd);
    }

    public CDoBasic queryDo(GID gid, String... fields) throws Exception
    {
        return getDao().queryDo(gid, fields);
    }

    // op=CDaoConst.AUTH_READ
    public int countDo(Class<?> classOfT, Cnd cnd, int op)
    {
        return getDao().countDo(classOfT, cnd, op);
    }

    public CDo queryDo(String className, Cnd cnd) throws Exception
    {
        return getDao().queryDo(className, cnd);
    }

    public CDo queryDo(String className, Cnd cnd, String... fields) throws Exception
    {
        return getDao().queryDo(className, cnd, fields);
    }

    public List<String> queryUuid(Class cls, Cnd cnd)
    {
        return getDao().queryUuid(cls, cnd);
    }

    public List queryField(Class cls, Cnd cnd, String field)
    {
        return getDao().queryField(cls, cnd, field);
    }

    public Object queryFieldValue(GID gid, String field) throws Exception
    {
        return getDao().queryFieldValue(gid, field);
    }

    public Object queryFieldValue(Class cls, Cnd cnd, String field)
    {
        return getDao().queryFieldValue(cls, cnd, field);
    }

    public String queryString(Class cls, Cnd cnd, String field, String defaultValue)
    {
        return getDao().queryString(cls, cnd, field, defaultValue);
    }

    public long queryLong(Class cls, Cnd cnd, String field, long defaultValue)
    {
        return getDao().queryLong(cls, cnd, field, defaultValue);
    }

    public int queryInt(Class cls, Cnd cnd, String field, int defaultValue)
    {
        return getDao().queryInt(cls, cnd, field, defaultValue);
    }

    public MultiPageResult<String> queryUuid(Class cls, Cnd cnd, CPager pager)
    {
        return getDao().queryUuid(cls, cnd, pager);
    }

    public <T> T queryDo(Class<T> cls, String fieldName, Object value, String... fields)
    {
        return getDao().queryDo(cls, fieldName, value, fields);
    }

    public <T> T queryDo(Class<T> cls, Cnd cnd, String... fields)
    {
        return getDao().queryDo(cls, cnd, fields);
    }

    public <T> List<T> queryDoList(Class<T> cls, Cnd cnd, String... fields)
    {
        return getDao().queryDoList(cls, cnd, fields);
    }
    
    public <T extends CDo> List<T> queryDoList(String clsName, Cnd cnd, String... fields) throws Exception
    {
        return getDao().queryDoList(clsName, cnd, fields);
    }

    public List<GID> queryChild(String pUuid, List<String> srcClass, CPager pager)
    {
        return getDao().queryChild(pUuid, srcClass, pager);
    }

    public List<CDimension> queryChildDimension(Class parentClass, String parentCode, Class childClass)
    {
        return getDao().queryChildDimension(parentClass, parentCode, childClass);
    }

    public void deleteDos(List<? extends CDoBasic> lstDos) throws Exception
    {
        getDao().deleteDos(lstDos);
    }

    public GID prepareGidByUuid(Object uuidOrGid) throws Exception
    {
        return getDao().prepareGidByUuid(uuidOrGid);
    }
    
    public void putTranCachedUuidClass(String uuid, String modelClass)
    {
        getDao().putTranCachedUuidClass(uuid, modelClass);
    }
    
    public void putCachedUuidClass(String uuid, String modelClass)
    {
        getDao().putCachedUuidClass(uuid, modelClass);
    }

    public MultiPageResult<CDoLink> queryLinks(Cnd cnd, CPager pager, String... fields) throws Exception
    {
        return getDao().queryLinks(cnd, pager, fields);
    }

    public CDoLink queryLink(Cnd cnd, String... fields)
    {
        return getDao().queryLink(cnd, fields);
    }

    public boolean isDisableCache()
    {
        return getDao().isDisableCache();
    }

    public void setDisableCache(boolean disableCache)
    {
        getDao().setDisableCache(disableCache);
    }

    public boolean isCacheWork()
    {
        return getDao().isCacheWork();
    }

    public <T> List<T> queryDo(Class<T> classOfT, Cnd cnd, Pager pager, FieldMatcher matcher)
    {
        return getDao().queryDo(classOfT, cnd, pager, matcher);
    }

    public LinkedHashMap<String, CDoBasic> queryDo(Class cls, List<String> lstUuids, String... fields)
    {
        return getDao().queryDo(cls, lstUuids, fields);
    }

    public <T> List<T> cqueryDo(Class<T> classOfT, Cnd cnd, Pager pager, SimpleFieldMatcher matcher)
    {
        return getDao().cqueryDo(classOfT, cnd, pager, matcher);
    }

    public Cnd wrapAuthCondition(Class cls, Cnd cnd, int op)
    {
        return getDao().wrapAuthCondition(cls, cnd, op);
    }

    public boolean isClassCacheable(String clsName)
    {
        return getDao().isClassCacheable(clsName);
    }

    public LinkedHashMap<String, CDoBasic> cqueryByUuid(Class classOfT, Collection<CDoBasic> lstData, SimpleFieldMatcher matcher)
    {
        return getDao().cqueryByUuid(classOfT, lstData, matcher);
    }

    public <T> List<T> cqueryDoList(Class<T> cls, Cnd cnd, String... fields)
    {
        return getDao().cqueryDoList(cls, cnd, fields);
    }

    public LinkedHashMap<String, CDoBasic> cqueryDo(String clsName, List<String> lstUuids, String... fields) throws Exception
    {
        return getDao().cqueryDo(clsName, lstUuids, fields);
    }

    public CDoBasic cqueryDo(GID gid, String... fields) throws Exception
    {
        return getDao().cqueryDo(gid, fields);
    }

    public <T> T cqueryDo(Class<T> cls, Cnd cnd, String... fields)
    {
        return getDao().cqueryDo(cls, cnd, fields);
    }

    public MultiPageResult cqueryDoPage(String className, Cnd cnd, CPager pager) throws Exception
    {
        return getDao().cqueryDoPage(className, cnd, pager);
    }

    public MultiPageResult cqueryDoPage(String className, Cnd cnd, CPager pager, String... fields) throws Exception
    {
        return getDao().cqueryDoPage(className, cnd, pager, fields);
    }

    public <T> MultiPageResult<T> cqueryDoPage(Class<T> cls, Cnd cnd, CPager pager, String... fields)
    {
        return getDao().cqueryDoPage(cls, cnd, pager, fields);
    }

    public List<CDoAttach> cqueryAttach(String uuid, String field)
    {
        return getDao().cqueryAttach(uuid, field);
    }

    public CDoAttach cqueryAttach(String uuid, String field, String attachName)
    {
        return getDao().cqueryAttach(uuid, field, attachName);
    }

    public Set<String> convertDimCascade(Class cls, Map<String, Object> mapValue) throws Exception
    {
        return getDao().convertDimCascade(cls, mapValue);
    }

    public void convertDimCascadeForUpdate(Class cls, Map<String, Object> mapValue) throws Exception
    {
        getDao().convertDimCascadeForUpdate(cls, mapValue);
    }

    public void queryFollowerValue(Class cls, Field leaderFd, String leaderCode, Map<String, Object> mapValue)
    {
        getDao().queryFollowerValue(cls, leaderFd, leaderCode, mapValue);
    }

    public <T> T getOrCreateSingleton(Class<T> cls) throws Exception
    {
        return getDao().getOrCreateSingleton(cls);
    }

    public void convertProjectionValue(Class cls, Map<String, Object> mapValue) throws Exception
    {
        getDao().convertProjectionValue(cls, mapValue);
    }

    public String queryAndLockProjectionRefValue(Object currValue, Class refClazz, String field) throws Exception
    {
        return getDao().queryAndLockProjectionRefValue(currValue, refClazz, field);
    }

    public void addCommitListener(CommitListener lsnr)
    {
        getDao().addCommitListener(lsnr);
    }

    public MultiPageResult queryEntity(String className, String sqlText, Set<String> extFields, Map<String, Object> vars, Map<String, Object> params, int startPos, int pageSize) throws Exception
    {
        return getDao().queryEntity(className, sqlText, extFields, vars, params, startPos, pageSize);
    }

    public MultiPageResult<DataRow> queryRows(String sqlText, Map<String, Object> vars, Map<String, Object> params, int startPos, int pageSize) throws Exception
    {
        return getDao().queryRows(sqlText, vars, params, startPos, pageSize);
    }

    public long queryLong(String sqlText, Map<String, Object> vars, Map<String, Object> params, long dftValue)
    {
        return getDao().queryLong(sqlText, vars, params, dftValue);
    }

    public double queryDouble(String sqlText, Map<String, Object> vars, Map<String, Object> params, double dftValue)
    {
        return getDao().queryDouble(sqlText, vars, params, dftValue);
    }

    public boolean queryBoolean(String sqlText, Map<String, Object> vars, Map<String, Object> params, boolean dftValue)
    {
        return getDao().queryBoolean(sqlText, vars, params, dftValue);
    }

    public String queryString(String sqlText, Map<String, Object> vars, Map<String, Object> params, String dftValue)
    {
        return getDao().queryString(sqlText, vars, params, dftValue);
    }

    public Object queryFirst(String sqlText, Map<String, Object> vars, Map<String, Object> params)
    {
        return getDao().queryFirst(sqlText, vars, params);
    }

    public String saveGlobalNotice(CDoGlobalNotice notice) throws Exception
    {
        return getDao().saveGlobalNotice(notice);
    }

    public int deleteGlobalNotice(String key) throws Exception
    {
        return getDao().deleteGlobalNotice(key);
    }

    public CDoGlobalNotice queryGlobalNotice(String key, String... fields)
    {
        return getDao().queryGlobalNotice(key, fields);
    }

    @Override
    public Map<String, List<String>> searchMasterOfSlave(String slaveClass, boolean includeChild) throws ClassNotFoundException
    {
        return getDao().searchMasterOfSlave(slaveClass, includeChild);
    }

    @Override
    public void setUpdateTimeoutS(int updateTimeoutS)
    {
        getDao().setUpdateTimeoutS(updateTimeoutS);
    }

    @Override
    public void setCreateTimeoutS(int createTimeoutS)
    {
        getDao().setCreateTimeoutS(createTimeoutS);
    }

    @Override
    public void setQueryTimeoutS(int queryTimeoutS)
    {
        getDao().setQueryTimeoutS(queryTimeoutS);
    }

    @Override
    public void setBatchUpdateTimeoutS(int batchUpdateTimeoutS)
    {
        getDao().setBatchUpdateTimeoutS(batchUpdateTimeoutS);
    }

    @Override
    public void setDeleteTimeoutS(int deleteTimeoutS)
    {
        getDao().setDeleteTimeoutS(deleteTimeoutS);
    }

    public ConcurrentHashMap<String, Object> prepareCenterCache()
    {
        try (AutoLock lc = AutoLock.lock(_lc))
        {
            if (_centerCache == null)
                _centerCache = new ConcurrentHashMap<String, Object>();
            return _centerCache;
        }
    }

    public Object getCenterCache(String key)
    {
        try (AutoLock lc = AutoLock.lock(_lc))
        {
            return _centerCache == null ? null : _centerCache.get(key);
        }
    }

    public void putCenterCache(String key, Object data)
    {
        try (AutoLock lc = AutoLock.lock(_lc))
        {
            if (_centerCache == null)
                _centerCache = new ConcurrentHashMap<String, Object>();
            _centerCache.put(key, data);
        }
    }

    public Object removeCenterCache(String key)
    {
        try (AutoLock lc = AutoLock.lock(_lc))
        {
            if (_centerCache == null)
                return null;

            return _centerCache.remove(key);
        }
    }

    public Set<String> getCenterCacheKeys()
    {
        ConcurrentHashMap<String, Object> cache = _centerCache;
        if (cache == null)
            return null;
        return new HashSet(cache.keySet());
    }

    public void clearCenterCache()
    {
        try (AutoLock lc = AutoLock.lock(_lc))
        {
            if (_centerCache != null)
            {
                _centerCache.clear();
                _centerCache = null;
            }
        }
    }
    
    public List<Object> getCenterCacheValues()
    {
        ConcurrentHashMap<String, Object> cache = _centerCache;
        if (cache == null)
            return null;
        return new LinkedList(cache.values());
    }

    @Override
    public int getQueryDependTimeoutS()
    {
        return getDao().getQueryDependTimeoutS();
    }

    @Override
    public void setQueryDependTimeoutS(int queryDependTimeoutS)
    {
        getDao().setQueryDependTimeoutS(queryDependTimeoutS);
    }

    @Override
    public boolean isIgnoreMaxDependDepthError()
    {
        return getDao().isIgnoreMaxDependDepthError();
    }

    @Override
    public void setIgnoreMaxDependDepthError(boolean ignoreMaxDependDepthError)
    {
        getDao().setIgnoreMaxDependDepthError(ignoreMaxDependDepthError);
    }

    @Override
    public int getMaxQueryDependDepth()
    {
        return getDao().getMaxQueryDependDepth();
    }

    @Override
    public void setMaxQueryDependDepth(int maxQueryDependDepth)
    {
        getDao().setMaxQueryDependDepth(maxQueryDependDepth);        
    }

    //  全网分布式锁(立即返回是否加锁成功)
    public boolean tryLock(String key, String info)
    {
        return getDao().tryLock(key, info);
    }
    
    //  全网分布式锁
    public void lockKey(String key, String info, long timeout) throws LockFailException, TimeoutException
    {
        getDao().lockKey(key, info, timeout);
    }
    
    // 全网分布式锁
    public void unlockKey(String key)
    {
        getDao().unlockKey(key);
    }

    // 全网分布式锁
    public void unlockKey(String key, boolean force)
    {
        getDao().unlockKey(key, force);
    }
    
    public String getLockInfo(String key) throws NoLockException, Exception
    {
        return getDao().getLockInfo(key);
    }

    public long getTimeTag()
    {
        return getDao().getTimeTag();
    }

    @Override
    public String getDbType()
    {
        return getDao().getDbType();
    }

}
