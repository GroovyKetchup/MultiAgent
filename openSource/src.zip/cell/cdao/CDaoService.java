package cell.cdao;

import java.net.URI;
import java.rmi.RemoteException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.Cnd;
import org.nutz.dao.Condition;

import com.cdao.dto.AuthLinkDto;
import com.cdao.dto.CDaoIndex;
import com.cdao.dto.CPager;
import com.cdao.dto.FieldExemptDto;
import com.cdao.impl.entity.field.GID;
import com.cdao.mgr.BroadcastBoard;
import com.cdao.mgr.CDaoCacheMap;
import com.cdao.mgr.CDaoCenter;
import com.cdao.mgr.CDaoCenterPackage;
import com.cdao.mgr.CDaoCenterPackageBrief;
import com.cdao.mgr.CDaoCenterPackageDelta;
import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.CDaoConfig;
import com.cdao.mgr.CDaoEntity;
import com.cdao.mgr.CSession;
import com.cdao.mgr.ClassInheritNode;
import com.cdao.mgr.ModelObserver;
import com.cdao.mgr.action.UpdateAction;
import com.cdao.model.CDimension;
import com.cdao.model.CDo;
import com.cdao.model.CDoAttach;
import com.cdao.model.CDoBasic;
import com.cdao.model.CDoEnum;
import com.cdao.model.CDoLink;
import com.cdao.model.CDoModel;
import com.cdao.model.CDoRole;
import com.cdao.model.CDoUser;
import com.leavay.common.util.Pair;
import com.leavay.common.util.SrvRes;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;
import com.project.gui.common.DBDatasource;

import bap.cells.EmptyServiceCell;
import cell.function.ISupplier;

public class CDaoService extends EmptyServiceCell implements IDaoService
{
    /**
     * 此方法比较特殊，仅在DAO主控服务上有效，在Follower上执行不报错但无效
     */
    public void addInitModel(Class ... clsArray)
    {
        CDaoCenter.addInitModel(clsArray);
    }

    public IDao newDao() throws Exception
    {
        return new CDaoCell(CDaoClient.newDao());
    }

    public IDao newDao(CSession session) throws Exception
    {
        return new CDaoCell(CDaoClient.newDao(session));
    }

    public URI getServerUri()
    {
        return CDaoClient.getMe().getUri();
    }

    public CDoBasic newDo(String className) throws Exception
    {
        return CDaoClient.getMe().newDo(className);
    }

    public long getClassTimeTag()
    {
        return CDaoClient.getMe().getClassTimeTag();
    }

    public List<String> getInheritTree(String parentClass, boolean includeSelf)
    {
        return CDaoClient.getMe().getInheritTree(parentClass, includeSelf);
    }

    public BroadcastBoard getBroadcast()
    {
        return CDaoClient.getMe().getBroadcast();
    }

    public Object getBroadcast(String key)
    {
        return CDaoClient.getMe().getBroadcast(key);
    }

    public void saveBroadcast(String key, Object v)
    {
        CDaoClient.getMe().saveBroadcast(key, v);        
    }

    public Set<String> getForeignChild(String parentClass)
    {
        return CDaoClient.getMe().getForeignChild(parentClass);
    }

    public Set<String> getForeignParent(String childClass)
    {
        return CDaoClient.getMe().getForeignParent(childClass);
    }

    public boolean isForeignParent(String parentClass)
    {
        return CDaoClient.getMe().isForeignParent(parentClass);
    }

    public boolean isValidForeign(String childClass, String parentClass)
    {
        return CDaoClient.getMe().isValidForeign(childClass, parentClass);
    }

    public List<Pair<String, String>> getProjectionRelation(String srcClass)
    {
        return CDaoClient.getMe().getProjectionRelation(srcClass);
    }

    public List<Pair<String, String>> getProjectionRelation(String targetClass, String field) throws ClassNotFoundException
    {
        return CDaoClient.getMe().getProjectionRelation(targetClass, field);
    }

    public CDaoEntity getEntity(String className) throws Exception
    {
        return CDaoClient.getMe().getEntity(className);
    }
    
    public CDaoEntity loadEntity(String className) throws Exception
    {
        return CDaoClient.getMe().loadEntity(className);
    }

    public String toSql(Condition cnd) throws Exception
    {
        return CDaoClient.getMe().toSql(cnd);
    }

    public CDoUser loginWithUser(String userName, String pwd) throws Exception
    {
        return CDaoClient.loginWithUser(userName, pwd);
    }
    
    public CSession loginWithSession(String userName, String pwd) throws Exception
    {
        return CDaoClient.loginWithSession(userName, pwd);
    }

    public void saveCacheMap(CDaoCacheMap cacheMap) throws Exception
    {
        CDaoClient.getIntf().saveCacheMap(cacheMap);
    }

    public CDoModel createModel(CDoModel md) throws Exception
    {
        return CDaoClient.getIntf().createModel(md);
    }

    public CDoModel createModelBlocked(CDoModel md, long timeOut) throws Exception
    {
        long nowTag = getClassTimeTag();
        md = CDaoClient.getIntf().createModel(md);
        long now = System.currentTimeMillis();
        while (getClassTimeTag() <= nowTag)
        {
            if (timeOut > 0 && System.currentTimeMillis() - now > timeOut)
                throw new TimeoutException(SrvRes.getString("Timed out to wait model loaded"));
            ToolUtilities.sleep(10);
        }

        return md;
    }

    public long updateModel(CDoModel md) throws Exception
    {
        return CDaoClient.getIntf().updateModel(md);        
    }
    

    public long updateModelBlocked(CDoModel md, long timeOut) throws Exception
    {
        long newTag = -1;
        try
        {
            newTag = CDaoClient.getIntf().updateModel(md);
            return newTag;
        }finally
        {
            long now = System.currentTimeMillis();
            while (getClassTimeTag() < newTag)
            {
                if (timeOut> 0 && System.currentTimeMillis() - now > timeOut)
                    throw new TimeoutException(SrvRes.getString("Timed out to wait model loaded"));
                ToolUtilities.sleep(10);
            }
        }
    }

    public void deleteModel(String fullClassName) throws Exception
    {
        CDaoClient.getIntf().deleteModel(fullClassName);        
    }
    
    public void deleteModels(String... fullClassNames) throws Exception
    {
        CDaoClient.getIntf().deleteModels(fullClassNames);  
    }

    public List<CDaoIndex> getIndexList(String className) throws Exception
    {
        return CDaoClient.getIntf().getIndexList(className);
    }

    public void renameModel(String orgClassName, String newClassName) throws Exception
    {
        CDaoClient.getIntf().renameModel(orgClassName, newClassName);        
    }
    
    public void renameModel(String orgClassName, String newClassName, ModelObserver obsv) throws Exception
    {
        CDaoClient.getIntf().renameModel(orgClassName, newClassName, obsv);        
    }

    public CDoModel changeParentClass(IProgress prog, String mdClass, String newParent, ModelObserver obsv) throws Exception
    {
        return CDaoClient.getIntf().changeParentClass(prog, mdClass, newParent, obsv);
    }

    public void renameColumns(String fullClassName, Map<String, String> renameColumns) throws Exception
    {
        CDaoClient.getIntf().renameColumns(fullClassName, renameColumns);        
    }

    public int rebuildFollower(String className, String followerField, int timeoutPerCode) throws Exception
    {
        return CDaoClient.getIntf().rebuildFollower(className, followerField, timeoutPerCode);
    }

    public CDaoCenterPackage queryNewestCenterPackage(long orgTimeTag, boolean syncListener)
    {
        return CDaoClient.getIntf().queryNewestCenterPackage(orgTimeTag, syncListener);
    }

    @Override
    public CDaoCenterPackageDelta queryNewestCenterPackageDelta(long orgTimeTag, ISupplier<CDaoCenterPackageBrief> queryBrief, boolean syncListener) throws Exception
    {
        return CDaoClient.getIntf().queryNewestCenterPackageDelta(orgTimeTag, queryBrief, syncListener);
    }

    public BroadcastBoard queryBroadcast(long timetag)
    {
        return CDaoClient.getIntf().queryBroadcast(timetag);
    }

    public void saveDimensionAuthority(GID userOrRole, GID dim, int... opList) throws TimeoutException, Exception
    {
        CDaoClient.getIntf().saveDimensionAuthority(userOrRole, dim, opList);        
    }

    public void saveDimensionAuthority(GID userOrRole, List<AuthLinkDto> lstAuth) throws TimeoutException, Exception
    {
        CDaoClient.getIntf().saveDimensionAuthority(userOrRole, lstAuth);        
    }

    public void saveFieldExempt(GID userOrRole, List<FieldExemptDto> lstExcempt) throws Exception
    {
        CDaoClient.getIntf().saveFieldExempt(userOrRole, lstExcempt);        
    }

    public void deleteFieldExempt(GID userOrRole, String modelClass, String field) throws Exception
    {
        CDaoClient.getIntf().deleteFieldExempt(userOrRole, modelClass, field);        
    }

    public DBDatasource getDs()
    {
        return CDaoClient.getIntf().getDs();
    }

    public CDaoConfig getCenterConfig()
    {
        return CDaoClient.getIntf().getCenterConfig();
    }

    public String getCenterConfig(String key)
    {
        return CDaoClient.getIntf().getCenterConfig(key);
    }

    public ClassInheritNode getModelRoot()
    {
        return CDaoClient.getIntf().getModelRoot();
    }

    public CDoModel queryModel(String className) throws Exception
    {
        return CDaoClient.getIntf().queryModel(className);
    }

    public CDoBasic queryDoByUuid(String uuid, List<String> lstClasses, String... fields) throws Exception
    {
        return CDaoClient.getIntf().queryDoByUuid(uuid, lstClasses, fields);
    }

    public CDoBasic queryDo(GID gid, String... fields) throws Exception
    {
        return CDaoClient.getIntf().queryDo(gid, fields);
    }

    public CDo queryDo(String className, Cnd cnd, String... fields) throws Exception
    {
        return CDaoClient.getIntf().queryDo(className, cnd, fields);
    }

    public MultiPageResult queryDoPage(String className, Cnd cnd, CPager pager) throws Exception
    {
        return CDaoClient.getIntf().queryDoPage(className, cnd, pager);
    }

    public MultiPageResult queryDoPage(String className, Cnd cnd, CPager pager, String... fields) throws Exception
    {
        return CDaoClient.getIntf().queryDoPage(className, cnd, pager, fields);
    }

    public MultiPageResult<CDoLink> queryLinks(Cnd cnd, CPager pager, String... fields) throws Exception
    {
        return CDaoClient.getIntf().queryLinks(cnd, pager, fields);
    }

    public CDoLink queryLink(Cnd cnd, String... fields) throws Exception
    {
        return CDaoClient.getIntf().queryLink(cnd, fields);
    }

    public boolean updateLink(String src, String dst, String flag, Map<String, Object> mapValue) throws Exception
    {
        return CDaoClient.getIntf().updateLink(src, dst, flag, mapValue);
    }

    public int updateLinks(Cnd cnd, Map<String, Object> mapValue) throws Exception
    {
        return CDaoClient.getIntf().updateLinks(cnd, mapValue);
    }

    public List queryDoList(String className, Cnd cnd, String... fields) throws Exception
    {
        return CDaoClient.getIntf().queryDoList(className, cnd, fields);
    }

    public CDoBasic getDo(GID gid) throws Exception
    {
        return CDaoClient.getIntf().getDo(gid);
    }

    public List<CDoBasic> queryChildDo(String parentUuid, List<String> childClass, CPager pager) throws Exception
    {
        return CDaoClient.getIntf().queryChildDo(parentUuid, childClass, pager);
    }

    public CDoBasic createDo(CDoBasic o) throws Exception
    {
        return CDaoClient.getIntf().createDo(o);
    }

    public void updateDo(CDoBasic o) throws Exception
    {
        CDaoClient.getIntf().updateDo(o);
    }

    public void updateDo(GID gid, Map<String, Object> values) throws Exception
    {
        CDaoClient.getIntf().updateDo(gid, values);        
    }
    

    public void updateField(GID gid, String field, Object value) throws Exception
    {
        CDaoClient.getIntf().updateField(gid, field, value);
    }

    public void deleteDo(CDoBasic o) throws Exception
    {
        CDaoClient.getIntf().deleteDo(o);        
    }

    @Override
    public void deleteDo(GID gid) throws Exception
    {
        CDaoClient.getIntf().deleteDo(gid);
    }

    public void saveAttach(GID pGid, Map<String, List<CDoAttach>> mapAttach, boolean deleteOthers) throws Exception
    {
        CDaoClient.getIntf().saveAttach(pGid, mapAttach, deleteOthers);        
    }

    public void saveAttach(GID pGid, String field, List<CDoAttach> lstAttach, boolean deleteOthers) throws Exception
    {
        CDaoClient.getIntf().saveAttach(pGid, field, lstAttach, deleteOthers);        
    }

    public List<CDoAttach> queryAttach(String uuid, String field) throws Exception
    {
        return CDaoClient.getIntf().queryAttach(uuid, field);
    }

    public CDoAttach queryAttach(String uuid, String field, String attachName) throws Exception
    {
        return CDaoClient.getIntf().queryAttach(uuid, field, attachName);
    }

    public List<CDoAttach> queryAttachBrief(String uuid, String field) throws Exception
    {
        return CDaoClient.getIntf().queryAttachBrief(uuid, field);
    }

    public void createLinks(List<CDoLink> links, int commitBatch) throws Exception
    {
        CDaoClient.getIntf().createLinks(links, commitBatch);        
    }

    public void createLink(GID src, GID dst, String flag) throws Exception
    {
        CDaoClient.getIntf().createLink(src, dst, flag);        
    }

    public void createLink(CDoLink link) throws Exception
    {
        CDaoClient.getIntf().createLink(link);        
    }

    public void deleteLink(String srcUuid, String dstUuid) throws Exception
    {
        CDaoClient.getIntf().deleteLink(srcUuid, dstUuid);        
    }

    public void deleteLink(String srcUuid, String dstUuid, String flag) throws Exception
    {
        CDaoClient.getIntf().deleteLink(srcUuid, dstUuid, flag);        
    }

    public void updateDos(String clsName, Set<String> setUuids, Map<String, Object> mapValue) throws Exception
    {
        CDaoClient.getIntf().updateDos(clsName, setUuids, mapValue);        
    }

    public int batchUpdate(List<UpdateAction> lstActions) throws Exception
    {
        return CDaoClient.getIntf().batchUpdate(lstActions);
    }

    public void deleteDos(List<CDoBasic> lstDos) throws Exception
    {
        CDaoClient.getIntf().deleteDos(lstDos);        
    }

    public int updateDos(String clsName, Cnd cnd, Map<String, Object> mapValue) throws Exception
    {
        return CDaoClient.getIntf().updateDos(clsName, cnd, mapValue);
    }

    public List<String> getAllDimensionClass()
    {
        return CDaoClient.getIntf().getAllDimensionClass();
    }

    public List<CDoEnum> queryUserEnum(Cnd cnd) throws Exception
    {
        return CDaoClient.getIntf().queryUserEnum(cnd);
    }

    public CDoEnum createEnum(CDoEnum doEnum) throws Exception
    {
        return CDaoClient.getIntf().createEnum(doEnum);
    }

    public void updateEnum(CDoEnum doEnum) throws Exception
    {
        CDaoClient.getIntf().updateEnum(doEnum);        
    }

    public void deleteEnum(CDoEnum doEnum) throws Exception
    {
        CDaoClient.getIntf().deleteEnum(doEnum);        
    }

    public List<CDimension> queryChildDimenion(String parentClass, String parentCode, String childClass) throws Exception
    {
        return CDaoClient.getIntf().queryChildDimenion(parentClass, parentCode, childClass);
    }

    public MultiPageResult queryEntity(String className, String sqlText, Set<String> extFields, Map<String, Object> vars, Map<String, Object> params, int startPos, int pageSize) throws Exception
    {
        return CDaoClient.getIntf().queryEntity(className, sqlText, extFields, vars, params, startPos, pageSize);
    }

    public int count(String className, Cnd cnd) throws Exception
    {
        return CDaoClient.getIntf().count(className, cnd);
    }

    public int deleteDos(IProgress prog, String clsName, Cnd cnd, int commitBatchCount) throws Exception
    {
        return CDaoClient.getIntf().deleteDos(prog, clsName, cnd, commitBatchCount);
    }

    public int updateDos(IProgress prog, String clsName, Cnd cnd, Map<String, Object> mapValue, int commitBatchCount) throws Exception
    {
        return CDaoClient.getIntf().updateDos(prog, clsName, cnd, mapValue, commitBatchCount);
    }

    public void createDepend(GID src, GID dst) throws Exception
    {
        CDaoClient.getIntf().createDepend(src, dst);        
    }

    public int deleteDepend(String srcUuid, String dstUuid) throws Exception
    {
        return CDaoClient.getIntf().deleteDepend(srcUuid, dstUuid);
    }

    public CDoBasic cqueryDo(GID gid, String... fields) throws Exception
    {
        return CDaoClient.getIntf().cqueryDo(gid, fields);
    }

    public LinkedHashMap<String, CDoBasic> cqueryDo(String clsName, List<String> lstUuids, String... fields) throws Exception
    {
        return CDaoClient.getIntf().cqueryDo(clsName, lstUuids, fields);
    }

    public CDoBasic cgetDo(GID gid) throws Exception
    {
        return CDaoClient.getIntf().cgetDo(gid);
    }

    public CDo cqueryDo(String className, Cnd cnd, String... fields) throws Exception
    {
        return CDaoClient.getIntf().cqueryDo(className, cnd, fields);
    }

    public List cqueryDoList(String className, Cnd cnd, String... fields) throws Exception
    {
        return CDaoClient.getIntf().cqueryDoList(className, cnd, fields);
    }

    public MultiPageResult cqueryDoPage(String className, Cnd cnd, CPager pager) throws Exception
    {
        return CDaoClient.getIntf().cqueryDoPage(className, cnd, pager);
    }

    public MultiPageResult cqueryDoPage(String className, Cnd cnd, CPager pager, String... fields) throws Exception
    {
        return CDaoClient.getIntf().cqueryDoPage(className, cnd, pager, fields);
    }

    public List<CDoBasic> cqueryChildDo(String parentUuid, List<String> childClass, CPager pager) throws Exception
    {
        return CDaoClient.getIntf().cqueryChildDo(parentUuid, childClass, pager);
    }

    public List<CDoAttach> cqueryAttach(String uuid, String field) throws Exception
    {
        return CDaoClient.getIntf().cqueryAttach(uuid, field);
    }

    public CDoAttach cqueryAttach(String uuid, String field, String attachName) throws Exception
    {
        return CDaoClient.getIntf().cqueryAttach(uuid, field, attachName);
    }

    public void linkUser2Role(GID user, GID role) throws Exception
    {
        CDaoClient.getIntf().linkUser2Role(user, role);        
    }

    public List<CDoRole> queryRole(GID user) throws Exception
    {
        return CDaoClient.getIntf().queryRole(user);
    }

    public void ping() throws RemoteException
    {
        CDaoClient.getIntf().ping();
    }

    public boolean isCenterServer()
    {
        return CDaoClient.getMe().isCenterServer();
    }

    public boolean isCenterPackageReady()
    {
        return CDaoClient.getMe().isCenterPackageReady();
    }

    public ClassInheritNode searchModelNode(String fullClassName)
    {
        return CDaoClient.getMe().searchModelNode(fullClassName);
    }

    public ClassInheritNode getInheritTreeRoot()
    {
        return CDaoClient.getMe().getInheritTreeRoot();
    }
    
    public boolean isStaticCodeModel(String fullClassName)
    {
        return CDaoClient.getMe().isStaticCodeModel(fullClassName);
    }

    public Object getCenterCache(String key)
    {
        return CDaoClient.getMe().getCenterCache(key);
    }

    public void putCenterCache(String key, Object value)
    {
        CDaoClient.getMe().putCenterCache(key, value);
    }

    public Object deleteCenterCache(String key)
    {
        return CDaoClient.getMe().deleteCenterCache(key);
    }

    public long importModels(IProgress prog, List<CDoModel> lstModels, ModelObserver observer) throws Exception
    {
        return CDaoClient.getIntf().importModels(prog, lstModels, observer);
    }

    public long importModelsBlocked(IProgress prog, List<CDoModel> lstModels, ModelObserver observer, long timeOut) throws Exception
    {
        long newTag = -1;
        try
        {
            newTag = importModels(prog, lstModels, observer);
            return newTag;
        }finally
        {
            long now = System.currentTimeMillis();
            while (getClassTimeTag() < newTag)
            {
                if (timeOut> 0 && System.currentTimeMillis() - now > timeOut)
                    throw new TimeoutException(SrvRes.getString("Timed out to wait for model update"));
                ToolUtilities.sleep(10);
            }
        }
    }
    
    public Map<String, byte[]> batchCompileModels(Collection<CDoModel> lstModel, boolean acceptMultiException) throws Exception
    {
        return CDaoClient.getIntf().batchCompileModels(lstModel, acceptMultiException);
    }

    public Map<String, byte[]> batchCompileModels(Collection<CDoModel> lstModel, boolean acceptMultiException, boolean dependLocalModels) throws Exception
    {
        return CDaoClient.getIntf().batchCompileModels(lstModel, acceptMultiException, dependLocalModels);
    }
    
    public void forceSyncWithCenter() throws Exception
    {
        CDaoClient.getMe().forceSyncWithCenter();
    }

    @Override
    public boolean isValidBasicModel(String cls)
    {
        return CDaoClient.getMe().isValidBasicModel(cls);
    }
    
    public CDaoCenterPackage getCachedCenterPackage(long timeTag)
    {
        return CDaoClient.getMe().getCachedCenterPackage(timeTag);
    }

    public long getCenterTime()
    {
        return CDaoClient.getIntf().getCenterTime();
    }

    public long getEstimateCenterTime()
    {
        return CDaoClient.getMe().getEstimateCenterTime();
    }

    public void registGlobalListener(int opType, String className, String lsnrCls, boolean includeInherit)
    {
        CDaoClient.getIntf().registGlobalListener(opType, className, lsnrCls, includeInherit);        
    }

    public void removeGlobalListener(int opType, String className, boolean includeInherit)
    {
        CDaoClient.getIntf().removeGlobalListener(opType, className, includeInherit);        
    }

    public void removeGlobalListener(String lsnrCls)
    {
        CDaoClient.getIntf().removeGlobalListener(lsnrCls);
    }
}
