package cell.cdao;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.nutz.dao.Cnd;
import org.nutz.dao.FieldMatcher;
import org.nutz.dao.SimpleFieldMatcher;
import org.nutz.dao.entity.Entity;
import org.nutz.dao.impl.entity.field.NutMappingField;
import org.nutz.dao.pager.Pager;

import com.cdao.dto.CPager;
import com.cdao.dto.DataRow;
import com.cdao.exception.CDaoCasExcpetion;
import com.cdao.impl.entity.field.GID;
import com.cdao.mgr.CDaoEntity;
import com.cdao.mgr.CSession;
import com.cdao.mgr.CommitListener;
import com.cdao.mgr.SavePoint;
import com.cdao.mgr.lock.LockFailException;
import com.cdao.mgr.lock.NoLockException;
import com.cdao.model.CDimension;
import com.cdao.model.CDo;
import com.cdao.model.CDoAttach;
import com.cdao.model.CDoBasic;
import com.cdao.model.CDoGlobalNotice;
import com.cdao.model.CDoLink;
import com.cdao.model.CDoModel;
import com.leavay.common.util.Pair;
import com.leavay.common.util.TimeoutException;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.common.util.ProgressCtrl.crpc.IProgress;

import cell.ResourceCellIntf;
import crpc.CallbackLocalMethod;

public interface IDao extends ResourceCellIntf
{
    public CSession getSession();

    public void setSession(CSession session);

    public <T extends CDoBasic> T createDo(T o) throws Exception;

    /**
     * @param lockTarget : 是否对依赖目标加读锁，为了快速插入，可以在外面自行加锁，无需显性释放，commit或者close 当前dao时会自动释放
     */
    public <T extends CDoBasic> T createDo(T o, boolean lockTarget) throws Exception;

    /**
     * @param lockTarget : 是否对依赖目标加读锁，为了快速插入，可以在外面自行加锁，无需显性释放，commit或者close 当前dao时会自动释放
     * @param givebackSlaveTable : 是否带回Slave数据
     */
    public <T extends CDoBasic> T createDo(T o, boolean lockTarget, boolean givebackSlaveTable) throws Exception;

    // 用数据库锁来保证两端存在，可以支持分布式创建link
    // 由于是数据库锁，且是简单小颗粒事务，可以分布式执行
    public void createLink(GID src, GID dst, String flag) throws Exception;

    public void createLink(CDoLink link) throws Exception;

    public boolean updateLink(String src, String dst, String flag, Map<String, Object> mapValue);

    public int updateLinks(Cnd cnd, Map<String, Object> mapValue);

    public List<CDoAttach> queryAttachBrief(String uuid, String field);

    public List<CDoAttach> queryAttach(String uuid, String field);

    public CDoAttach queryAttach(String uuid, String field, String attachName);

    // 根据名字进行覆盖增量式保存
    // 列表里没出现的都删除，其它的该覆盖覆盖，该新建新建
    public void saveAttach(GID pGid, String field, List<CDoAttach> lstAttach, boolean deleteOthers) throws Exception;

    // 按字段写入附件（覆盖）
    // clearOld 为true，则删除老的附件，否则就追加
    // 由于是数据库锁，且是简单小颗粒事务，可以分布式执行
    public void saveAttach(GID pGid, Map<String, List<CDoAttach>> mapAttach, boolean deleteOthers) throws Exception;

    public <T extends CDoBasic> void updateDo(T o) throws Exception;

    // 每隔多少提交一次
    public void updateDos(String clsName, Set<String> setUuids, Map<String, Object> mapValue, int commitBatchCount) throws Exception;

    // 根据过滤条件批量update
    // 每隔多少提交一次
    public int updateDos(String clsName, Cnd cnd, Map<String, Object> mapValue, int commitBatchCount) throws Exception;

    public int updateDos(IProgress prog, String clsName, Cnd cnd, Map<String, Object> mapValue, int commitBatchCount) throws Exception;

    // 整批执行，不会提交（危险）
    public int updateDos(String clsName, Cnd cnd, Map<String, Object> mapValue) throws Exception;

    // 锁住维度字段关联的维度值
    // Row Share锁，已经可以保护住数据不被删改了
    public void dblockDimShare(Class<CDoBasic> cls, Map<String, Object> mapValue) throws Exception;

    public void updateDoField(CDoBasic o, String field, Object value) throws Exception;

    public void updateDo(GID gid, Map<String, Object> mapValue) throws Exception;

    public void updateDo(CDoBasic o, String... updateFields) throws Exception;

    public void updateDo(CDoBasic o, Map<String, Object> mapValue) throws Exception;

    public void deleteDo(GID gid) throws Exception;

    public void deleteDo(CDoBasic o) throws Exception;

    public int deleteDos(IProgress prog, String clsName, Cnd cnd, int commitBatchCount) throws Exception;

    public int deleteDos(String clsName, Cnd cnd) throws Exception;

    public boolean isClassDependable(String className) throws Exception;

    public void setSavepoint(String spId);

    public void rollback();

    public void rollback(String sp);

    public void rollbackAndThrow(String sp, Throwable err) throws Exception;

    public void commit();

    public <T> Entity<T> prepareEntity(Class<T> classOfT);

    public void verifyFieldValue(Class doClass, Map<String, Object> mapValue) throws Exception;

    public void verifyFieldValue(Object dataObject, NutMappingField f) throws Exception;

    public void verifyFieldValue(Object dataObject, String fieldName, boolean nullable, String checker) throws Exception;

    public void verifyFieldValue(Class mdClass, String fieldName, Object fieldValue, boolean nullable, String checker) throws Exception;

    public void checkCreateAuth(CDoBasic o);

    public void readlockDependTarget(String dstClass, String dstUuid, boolean includeAncestor) throws Exception;

    public void createDepend(GID src, GID dst) throws Exception;

    public int deleteDepend(String srcUuid, String dstUuid);

    public <T extends CDoBasic> List<T> createDos(List<T> lstDo) throws Exception;

    /**
     * @param lockTarget : 是否对依赖目标加读锁，为了快速插入，可以在外面自行加锁，无需显性释放，commit或者close 当前dao时会自动释放
     */
    public <T extends CDoBasic> List<T> createDos(List<T> lstDo, boolean lockDependTarget) throws Exception;

    /**
     * @param lockTarget : 是否对依赖目标加读锁，为了快速插入，可以在外面自行加锁，无需显性释放，commit或者close 当前dao时会自动释放
     * @param givebackSlaveTable : 是否带回Slave数据
     */
    public <T extends CDoBasic> List<T> createDos(List<T> lstDo, boolean lockDependTarget, boolean givebackSlaveTable) throws Exception;

    public boolean isPrintDebug();

    public void setPrintDebug(boolean debug);

    public void debug(String log);

    public long getDbLockTimeout();

    public int getDbLockTimeoutS();

    public int getUpdateTimeoutS();

    public int getCreateTimeoutS();

    public int getBatchUpdateTimeoutS();

    public int getRebuildOneFollowerCodeTimeout();

    public int getDeleteTimeoutS();

    public int getBatchDeleteTimeoutS();

    public int getBatchDeleteTimeoutS(int rows);

    public void setDblockTimeoutMs(int dblockTimeoutMs);
    
    public void setUpdateTimeoutS(int updateTimeoutS);

    public void setCreateTimeoutS(int createTimeoutS);

    public void setQueryTimeoutS(int queryTimeoutS);
    
    public void setBatchUpdateTimeoutS(int batchUpdateTimeoutS);
    
    public void setDeleteTimeoutS(int deleteTimeoutS);
    
    public int getQueryDependTimeoutS();

    public void setQueryDependTimeoutS(int queryDependTimeoutS);

    public boolean isIgnoreMaxDependDepthError();

    public void setIgnoreMaxDependDepthError(boolean ignoreMaxDependDepthError);

    public int getMaxQueryDependDepth();

    public void setMaxQueryDependDepth(int maxQueryDependDepth);

    public boolean dblockShare(GID gid) throws Exception;

    public boolean dblockShare(String uuid, String className) throws Exception;

    public boolean dblockShare(CDoBasic o) throws Exception;

    public boolean dblockShare(Class cls, String uuid) throws Exception;

    public void dblockShare(Map<String, String> mapUuidClass) throws Exception;

    // Row Write锁，独占该条数据，不允许别人加Share锁了;
    public boolean dblockWrite(GID gid) throws Exception;

    // Row Write锁，独占该条数据，不允许别人加Share锁了;
    public void dblockWrite(Map<String, String> mapUuidClass) throws Exception;

    public int clearProjectionByModel(Class projectionClass, Set<String> fields) throws Exception;

    // 清空投影字段的值，给定类、字段以及过滤条件
    // SQL：Update set NULL where field like 'UUID=>%'
    public int clearProjectionByUuid(Class projectionClass, String field, String srcUuid) throws Exception;

    // 删除某个数据时，需要联动清掉所有引用它的投影字段的值
    public int clearRelatedProjectionFields(CDoBasic o) throws Exception;

    public List<Pair<String, String>> searchDimensionRef(String dimClass, boolean includeChild) throws ClassNotFoundException;
    
    /**
     * 搜索Slave模型被哪些Master模型引用，（通过遍历模型树-内存类树）
     *  includeChild : 是否把子类一起返回
     *  返回：Key=类，Value=字段列表
     */
    public Map<String, List<String>> searchMasterOfSlave(String slaveClass, boolean includeChild) throws ClassNotFoundException;

    public int deleteSlave(CDoBasic o) throws Exception;
    
    public int deleteSlave(CDoBasic o, String field) throws Exception;

    public int deleteSlave(String slaveClass, String masterUuid, String masterField) throws Exception;

    public int deleteSlave(String slaveClass, String masterUuid) throws Exception;

    public int deleteSlaveByModel(String slaveClass, String masterClass) throws Exception;

    public int deleteSlaveByModel(String slaveClass, String masterClass, String masterField) throws Exception;

    // 删除某个数据的所有外联子表数据
    public int deleteForeignChild(CDoBasic parent) throws Exception;

    // 删除某个master下所有该类型的外键子表数据
    public int deleteForeignChild(String childClass, String parentKey) throws Exception;

    public void deleteAttachOf(String uuid) throws Exception;

    public void deleteAttachOf(String uuid, String field) throws Exception;

    public void deleteLinkOf(String uuid);

    public void deleteLink(String srcUuid, String dstUuid);

    public void deleteLink(Cnd cnd);

    public void deleteLink(String srcUuid, String dstUuid, String flag);

    public void deleteDependBoth(String uuid);

    // 外部需要对模型加独占锁
    // key=uuid, value=class
    public Map<String, String> queryDependSourceOfModel(String className);

    /**
     * 通过依赖表里查依赖目标，比较容易获得class信息
     * 
     * @param srcClass
     *            ：依赖源（子）的类信息
     * @param dstUuid
     *            : 依赖目标（父）的UUID
     * @return 依赖目标（父）的类信息
     */
    public String queryDependTargetClass(String srcClass, String dstUuid);

    /**
     * 给定依赖父，查询依赖它的子对象（单层第一个，主要用于获取类信息）
     * 
     * @param srcClass
     *            ：依赖源（子）的类信息
     * @param dstUuid
     *            : 依赖目标（父）的UUID
     * @return 依赖目标（父）的类信息
     */
    public CDoBasic queryDependTarget(String srcClass, String dstUuid, String... fields) throws Exception;

    /**
     * 给定依赖父，查询依赖它的子对象（单层）
     * 
     * @param dstUuid：父UUID
     * @param srcClass：依赖子的类列表（不自动含继承类）
     * @param srcField
     *            ：子字段
     * @return 按类区分好的子对象列表，Key为类名，Value为数据UUIID列表
     */
    public Map<String, List<String>> queryDependTarget(String dstUuid, List<String> srcClass, String srcField);

    /**
     * 给定依赖父，查询依赖它的子对象（单层）
     */
    public List<String> queryDependTarget(String dstUuid, String srcClass, String srcField);

    /**
     * 给定依赖父，查询依赖它的子对象（单层）
     * 
     * @param dstUuid：父UUID
     * @param srcClass：依赖子的类列表（不自动含继承类）
     * @param srcField
     *            ：子字段
     * @return 按类区分好的子对象列表，Key为类名，Value为数据UUIID列表
     */
    public Map<String, List<String>> queryDependTarget(String dstUuid, List<String> srcClass, String srcField, CPager pager);

    public Class prepareModelClass(String className) throws Exception;

    // 最快，直接从MGR缓存中获取转换好的CDaoEntity
    public CDaoEntity getCDaoEntity(String className) throws Exception;

    // 较快，MGR中有缓存，但多了一点点转换开销
    public CDaoEntity getCachedEntity(String className) throws Exception;
    
    // 最慢，每次都全新构建
    @Deprecated
    public CDaoEntity buildEntity(String className) throws Exception;
    
    // 较慢，比buildEntity稍快（在单个DAO内部有缓存）
    @Deprecated
    public CDaoEntity getEntity(String className) throws Exception;


    public Object newObject(String className) throws Exception;

    public CDoBasic newObject(String className, String uuid) throws Exception;

    public CDoBasic newObject(GID gid) throws Exception;

    // 给定依赖的父，查所有依赖它的子（递归查所有），不限字段不限类
    public Map<String, String> queryAllDependSource(String depTarget);

    // 给定依赖的子，查所有被它依赖的父（递归查所有），不限字段不限类
    public Map<String, String> queryAllDependTarget(String depSource);
    

    // Key=UUID, Value=ClassName
    public Map<String, String> queryAllLinkSource(String lnkTarget, String flag);

    // Key=UUID, Value=ClassName
    public Map<String, String> queryLinkSource(Set<String> lstTarget, String flag);
    
    // 查询所有“被”自己（linkSource）连接的对象，无限层
    // Key=UUID, Value=ClassName
    public Map<String, String> queryAllLinkTarget(String depSource, String flag);
    
    // Key=UUID, Value=ClassName
    public Map<String, String> queryLinkTarget(Set<String> lstSource, String flag);

    // 查询某个DO下某个slave字段的子表（全部数据，小心数据量）
    public List querySlaveTable(GID masterGid, String field) throws Exception;
    
    public void casUpdateDo(CDoBasic o, String name, Object value) throws CDaoCasExcpetion, Exception;

    /**
     * 以乐观锁方式update对象，会自主对Version字段做+1操作（到最大值会自动回归到0），有如下限制：
     * 1、对象必须有一个Long类型的CDo.CasVersion字段，且传入的对象“o”中必须带有原Version的值（如果为空，则会被默认初始化为0）
     * 2、mapValue里不得含有Version的值，该方法会自主+1
     * 
     * @param o
     *            ：要修改的对象（内必须含UUID + 当前Version的值）
     * @param mapValue
     *            ：要赋的值
     */
    public void casUpdateDo(CDoBasic o, Map<String, Object> mapValue) throws CDaoCasExcpetion, Exception;

    // Row Share锁，已经可以保护住数据不被删改了
    // 如果是多选则会锁住多个维值
    public void dblockDimShare(String dimClass, boolean isMulti, String dimCode) throws Exception;

    // 锁住单个维值
    public void dblockOneDimShare(String dimClass, String dimCode) throws Exception;

    public MultiPageResult queryDoPage(String className, Cnd cnd, CPager pager) throws Exception;

    public MultiPageResult queryDoPage(String className, Cnd cnd, CPager pager, String... fields) throws Exception;

    public <T> MultiPageResult<T> queryDoPage(Class<T> cls, Cnd cnd, CPager pager, String... fields);
    
    /**
     * 自定义查询语句，联合查询等，将查询结果塞到指定模型类对象里，如果有其它字段，则存入对象的extFields里（根据传入的extFields与sql语句中的字段名对应）
     * 没有查总数的功能，如果需要，可调用queryLong另行查询
     * 
     * @param className : 主实体类（返回对象的类）
     * @param sqlText ：查询语句
     * @param extFields ：需要读取的扩展字段（sql语句可能查询出更多字段，通过这个来获取并设置到返回对象的扩展字段里）
     * @param vars ：查询变量（$开头的简单字符替换）
     * @param params：查询参数（@开头的SQL语句参数，例如字符串会自动加单引号）
     * @param startPos ：分页起始位置
     * @param pageSize：分页Size
     * 样例：

            String sql = "select a.*, b.name as projectName from cjava_code a, $TABLE_PROJECT b where a.masterKey=b.uuid and b.name<>@paramProject";
            Set<String> extFields = ToolUtilities.newHashSet("projectName");
            Vars vars = new Vars().add("TABLE_PROJECT", "cjava_project");
            Params params = new Params().add("paramProject", "project1");
            
            MultiPageResult rs = dao.queryEntity(CJavaCodeDo.class.getName(), sql, extFields, vars, params, 0, 100);
     */
    public MultiPageResult queryEntity(String className, String sqlText, Set<String> extFields, Map<String, Object> vars, Map<String, Object> params, int startPos, int pageSize) throws Exception;

    /**
     * 自定义查询语句，返回原始的查询结果，不做任何转换
     * 返回结果中的DataRow为字段名（或Alias）对应库表记录值Object
     * 
     * 如果需要总行数，可再调用queryLong另行查询
     * 
     * @param sqlText ：查询语句
     * @param vars ：查询变量（$开头的简单字符替换）
     * @param params：查询参数（@开头的SQL语句参数，例如字符串会自动加单引号）
     * @param startPos ：分页起始位置
     * @param pageSize：分页Size
     * 
     *  样例：

            String sql = "select a.*, b.name as projectName from cjava_code a, $TABLE_PROJECT b where a.masterKey=b.uuid and b.name<>@paramProject";
            Vars vars = new Vars().add("TABLE_PROJECT", "cjava_project");
            Params params = new Params().add("paramProject", "project1");
            
            MultiPageResult<DataRow> rs2 = dao.queryRows(sql, vars, params, 0, 5);
     */
    public MultiPageResult<DataRow> queryRows(String sqlText, Map<String, Object> vars, Map<String, Object> params, int startPos, int pageSize) throws Exception;

    /**
     * 自定义SQL查询第一行的第一个字段值，并转换为Long
     */
    public long queryLong(String sqlText, Map<String, Object> vars, Map<String, Object> params, long dftValue);
    
    /**
     * 自定义SQL查询第一行的第一个字段值，并转换为Double
     */
    public double queryDouble(String sqlText, Map<String, Object> vars, Map<String, Object> params, double dftValue);
    
    /**
     * 自定义SQL查询第一行的第一个字段值，并转换为Boolean
     */
    public boolean queryBoolean(String sqlText, Map<String, Object> vars, Map<String, Object> params, boolean dftValue);
    
    /**
     * 自定义SQL查询第一行的第一个字段值，并转换为Boolean
     */
    public String queryString(String sqlText, Map<String, Object> vars, Map<String, Object> params, String dftValue);
    
    /**
     * 自定义SQL查询第一行的第一个字段值，返回原始Object
     * 
     *   样例：
            String sql = "select count(1) from cjava_code a, $TABLE_PROJECT b where a.masterKey=b.uuid and b.name<>@paramProject";
            HashMap<String, Object> vars = ToolUtilities.newHashMap("TABLE_PROJECT", "cjava_project");
            HashMap<String, Object> params = ToolUtilities.newHashMap("paramProject", "project1");
            
            long rowCount = dao.queryLong(sql, vars, params, -1);
     */
    public Object queryFirst(String sqlText, Map<String, Object> vars, Map<String, Object> params);
    
    public CDoModel queryModel(String className);

    public CDoModel prepareModel(String className);

    // 首次查询，非常的慢，要查所有库表
    public String queryDoClass(String uuid) throws Exception;

    public CDoBasic queryDoByUuid(String uuid, List<String> lstClasses, String... fields) throws Exception;

    public boolean exists(GID gid) throws Exception;

    public boolean exists(Class clz, Cnd cnd) throws Exception;

    public CDoBasic queryDo(GID gid, String... fields) throws Exception;

    public int countDo(Class<?> classOfT, Cnd cnd, int op);

    public CDo queryDo(String className, Cnd cnd) throws Exception;

    public CDo queryDo(String className, Cnd cnd, String... fields) throws Exception;

    public List<String> queryUuid(Class cls, Cnd cnd);

    public List queryField(Class cls, Cnd cnd, String field);

    public Object queryFieldValue(GID gid, String field) throws Exception;
    
    public Object queryFieldValue(Class cls, Cnd cnd, String field);

    public String queryString(Class cls, Cnd cnd, String field, String defaultValue);

    public long queryLong(Class cls, Cnd cnd, String field, long defaultValue);

    public int queryInt(Class cls, Cnd cnd, String field, int defaultValue);

    public MultiPageResult<String> queryUuid(Class cls, Cnd cnd, CPager pager);

    public <T> T queryDo(Class<T> cls, String fieldName, Object value, String... fields);

    public <T> T queryDo(Class<T> cls, Cnd cnd, String... fields);

    public <T> List<T> queryDoList(Class<T> cls, Cnd cnd, String... fields);
    
    public <T extends CDo> List<T> queryDoList(String clsName, Cnd cnd, String... fields) throws Exception;

    // srcClass为空则表示不限类型
    // pager为空则表示不分页，获取全部数据
    public List<GID> queryChild(String pUuid, List<String> srcClass, CPager pager);

    // 给定维度的类以及维码，查询其某一类子维度的值列表
    public List<CDimension> queryChildDimension(Class parentClass, String parentCode, Class childClass);

    public void deleteDos(List<? extends CDoBasic> lstDos) throws Exception;

    // 传入一个可能是Gid也可能是String的对象，自动判断并转换成GID
    // 如果传入的是非法值或者是不存在的UUID，都会抛出异常
    // 如果传入是空或空字符串，则返回空
    public GID prepareGidByUuid(Object uuidOrGid) throws Exception;
    
    // 临时在当前DAO事务内显示增加一个uuid和类的关联关系（随着rollback或close会消失）
    public void putTranCachedUuidClass(String uuid, String modelClass);
    
    // 在全局缓存中增加一个uuid和类的关联关系，用于加速（如需要查询强依赖目标时）
    public void putCachedUuidClass(String uuid, String modelClass);

    public MultiPageResult<CDoLink> queryLinks(Cnd cnd, CPager pager, String... fields) throws Exception;

    public CDoLink queryLink(Cnd cnd, String... fields);

    public boolean isDisableCache();

    /**
     * 设置当前事务不使用缓存 通常用于重要的数据update，尤其casUpdate
     */
    public void setDisableCache(boolean disableCache);

    public boolean isCacheWork();

    public <T> List<T> queryDo(final Class<T> classOfT, Cnd cnd, final Pager pager, FieldMatcher matcher);

    public LinkedHashMap<String, CDoBasic> queryDo(Class cls, List<String> lstUuids, String... fields);

    public <T> List<T> cqueryDo(final Class<T> classOfT, Cnd cnd, final Pager pager, SimpleFieldMatcher matcher);

    public Cnd wrapAuthCondition(Class cls, Cnd cnd, int op);

    public boolean isClassCacheable(String clsName);

    /**
     * 用uuid带缓存查询
     * 
     * @param lstData
     *            : 只包含Uuid的空对象列表
     * @return 顺序一致的完整对象列表（一定不会为空）
     */
    public LinkedHashMap<String, CDoBasic> cqueryByUuid(Class classOfT, Collection<CDoBasic> lstData, SimpleFieldMatcher matcher);

    public <T> List<T> cqueryDoList(Class<T> cls, Cnd cnd, String... fields);

    public LinkedHashMap<String, CDoBasic> cqueryDo(String clsName, List<String> lstUuids, String... fields) throws Exception;

    public CDoBasic cqueryDo(GID gid, String... fields) throws Exception;

    public <T> T cqueryDo(Class<T> cls, Cnd cnd, String... fields);

    public MultiPageResult cqueryDoPage(String className, Cnd cnd, CPager pager) throws Exception;

    public MultiPageResult cqueryDoPage(String className, Cnd cnd, CPager pager, String... fields) throws Exception;

    public <T> MultiPageResult<T> cqueryDoPage(Class<T> cls, Cnd cnd, CPager pager, String... fields);

    public List<CDoAttach> cqueryAttach(String uuid, String field);

    public CDoAttach cqueryAttach(String uuid, String field, String attachName);

    /**
     * 根据维度主从关系，对冗余字段进行强行自动写入 傀儡字段的值会自动被主值关联引用所覆盖
     * 傀儡字段本身没有单独写的权利，如果混入了mapValue，最终会检测出来并报错
     * 
     * @param cls
     *            ：模型
     * @param mapValue
     *            ：欲写入的值
     * 
     * @return 返回野的傀儡字段，修改的时候应该不允许写入野傀儡，但是创建时，可以
     */
    public Set<String> convertDimCascade(Class cls, Map<String, Object> mapValue) throws Exception;

    // 用于Update数据时的自动转换傀儡值
    // 对冗余级联维度进行自动赋值，覆盖存储到mapValue中
    // 并校验是否有私自篡改傀儡字段的，并报错
    public void convertDimCascadeForUpdate(Class cls, Map<String, Object> mapValue) throws Exception;

    /**
     * 根据字段的傀儡冗余设定，递归将变化了傀儡值查询出来
     * 如：A字段依赖B，B字段依赖C，现在C的级联维度发生变化，那么需要联动自动的把所有符合条件的A和B一次性更新成新的级联脉络
     * 
     * @param cls
     *            ：当前类
     * @param leaderFd
     *            ：领导字段
     * @param leaderCode
     *            ：领导字段的新Code
     * @param mapValue
     *            ：作为输出参数，传递相关傀儡字段的新值
     */
    public void queryFollowerValue(Class cls, Field leaderFd, String leaderCode, Map<String, Object> mapValue);

    /**
     * 注：内部自动提交 
     * 查询或创建：全局唯一的Singleton单例对象，如果存在则返回，不存在则创建，发现超过一个的垃圾则删除多余的
     * 内部会全局加分布式锁，专门针对单例类，所以无需担心分布式创建多余的
     */
    public <T> T getOrCreateSingleton(Class<T> cls) throws Exception;

    /**
     * 将投影字段的值补全，并和引用处确保加锁后一致 查询引用的值，转换成投影字段的值，设置到map中，如果为空或者查不到，则设置为空
     * 
     * @param cls
     * @param mapValue
     */
    public void convertProjectionValue(Class cls, Map<String, Object> mapValue) throws Exception;

    // 给出当前值（得到Uuid），引用目标类以及字段，查出应该写入库的最终值：UUID=>XXXXX
    public String queryAndLockProjectionRefValue(Object currValue, Class refClazz, String field) throws Exception;

    public void addCommitListener(CommitListener lsnr);
    
    /**
     * Savepoint内置了daoCell，只能作为本地方法
     */
    @CallbackLocalMethod
    public default SavePoint newSavepoint()
    {
        return new SavePoint(this);
    }
    
    public String saveGlobalNotice(CDoGlobalNotice notice) throws Exception;
    public int deleteGlobalNotice(String key) throws Exception;
    public CDoGlobalNotice queryGlobalNotice(String key, String ... fields);
    
    /**
     * Center Cache专用于和DAO事务共生的全局性缓存（非本地）
     * 通过IDao提供分布式访问接口，该缓存数据存于主控且只有一份，属于临时性缓存，DAO销毁则无存在意义
     * 
     *  【注】：该缓存不会自动清理（异步监听事件可能在关闭连接后仍需继续访问），一般会跟随DAO对象回收，建议用完主动清理一下：clearCenterCache()
     */
    public Object getCenterCache(String key);
    public void putCenterCache(String key, Object data);
    public Object removeCenterCache(String key);
    public Set<String> getCenterCacheKeys();
    public List<Object> getCenterCacheValues();
    public void clearCenterCache();
    

    //  全网分布式锁(立即返回是否加锁成功)
    public boolean tryLock(String key, String info);
    
    //  全网分布式锁
    public void lockKey(String key, String info, long timeout) throws LockFailException, TimeoutException;
    
    // 全网分布式锁
    public void unlockKey(String key);

    // 全网分布式锁
    public void unlockKey(String key, boolean force);
    public String getLockInfo(String key) throws NoLockException, Exception;
    
    public long getTimeTag();
    
    /**
     * 返回数据库类型名，对应枚举：com.leavay.common.util.DBType
     */
    public String getDbType();
}
