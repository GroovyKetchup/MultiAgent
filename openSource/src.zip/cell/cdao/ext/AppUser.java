package cell.cdao.ext;

import org.nutz.dao.entity.annotation.ColDefine;
import org.nutz.dao.entity.annotation.ColType;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;

import com.cdao.model.CDoUser;

/**
 * 共享模型只适用于静态JAVA模型
 * 
 * 所以同名类会出现在两层Class Loader中，用系统的ClassLoader就会拿到java代码里写死的，而用基于DAO的ClassFactory，则可以拿到我们需要的那个动态模型
 * 
 * 
 */
public class AppUser extends CDoUser
{
    private static final long serialVersionUID = -5497554463255539475L;

    public static final String Email="email";

    @Column
    @Comment("电邮")
    @ColDefine(type=ColType.VARCHAR, width=256)
    private String email;
    
    public String getEmail(){
        return getString(Email);
    }
    
    public AppUser setEmail(String v)
    {
        set(Email, v);
        return this;
    }
}
