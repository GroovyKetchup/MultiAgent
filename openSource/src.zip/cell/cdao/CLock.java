package cell.cdao;

import com.cdao.mgr.CDaoClient;
import com.cdao.mgr.lock.LockFailException;
import com.cdao.mgr.lock.NoLockException;
import com.leavay.common.util.TimeoutException;

import bap.cells.EmptyServiceCell;

public class CLock extends EmptyServiceCell implements ILock
{
    private static final long serialVersionUID = 692556470346407959L;

    public boolean tryLockKey(String key, String info)
    {
        return CDaoClient.getMe().tryLockKey(key, info);
    }

    public void lockKey(String key, String info, long timeout) throws LockFailException, TimeoutException
    {
        CDaoClient.getMe().lockKey(key, info, timeout);                
    }
    
    public void unlock(String key)
    {
        CDaoClient.getMe().unlock(key);        
    }
    
    public void unlock(String key, boolean force)
    {
        CDaoClient.getMe().unlock(key, force);        
    }

    public String getLockInfo(String key) throws NoLockException, Exception
    {
        return CDaoClient.getMe().getLockInfo(key);
    }
}
