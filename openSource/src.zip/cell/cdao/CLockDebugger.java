package cell.cdao;

import com.cdao.mgr.lock.LockFailException;
import com.cdao.mgr.lock.NoLockException;
import com.leavay.common.util.StringLock;
import com.leavay.common.util.StringLock.LockObject;
import com.leavay.common.util.TimeoutException;

import bap.cells.CellDebugger;
import bap.cells.EmptyServiceCell;

/**
 * 云调试（云开发）状态下，只在本地加锁，来模拟分布式锁
 * 
 * 
 * 这样才不会导致远端出现垃圾锁不释放的问题，以此保护
 *  
 */
@CellDebugger
public class CLockDebugger extends EmptyServiceCell implements ILock
{
    StringLock _local = new StringLock();
    
    public boolean tryLockKey(String key, String info)
    {
        return _local.tryLock(key);
    }

    public void lockKey(String key, String info, long timeout) throws LockFailException, TimeoutException
    {
        _local.lockDN(key, info, timeout);
    }

    public void unlock(String key)
    {
        _local.unlockIfExist(key);
    }

    @Override
    public void unlock(String key, boolean force)
    {
        // 这种锁本身没有线程判断，所以无所谓force与否
        _local.unlockIfExist(key);
    }
    
    public String getLockInfo(String key) throws NoLockException, Exception
    {
        LockObject lc = _local.getLock(key);
        if (lc == null)
            throw new NoLockException("No lock on key : " + key);
        
        return lc.getMessage();
    }

}
