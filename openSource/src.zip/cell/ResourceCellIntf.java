package cell;

import java.io.Serializable;

import com.leavay.ms.tool.CmnUtil;

import crpc.CRpcCallbackForeverIntf;
import crpc.CallbackLocalMethod;

/**
 * 资源类cell，用于隔离远程操作在服务端的资源，可以被转发传递，但是关闭逻辑需要触发close 
 * 
 * 继承并实现onClose，以此释放本地资源（如数据库连接、文件流等）
 *
 *
 * 实现类样例：
 * public class CConnection extends BasicCell implements IConnection
 * {
 *      public void onClose()
 *      {
 *          // Close Physical Connection
 *      }
 * }
 */
public interface ResourceCellIntf extends CellIntf, CRpcCallbackForeverIntf, Serializable
{
    /**
     * 子类可以继承重载close方法释放一些资源，随后再调用super.close
     */
    @CallbackLocalMethod
    public default void close()
    {
        try
        {
            // 调用onClose，释放一些本地资源（如数据库连接等）
            // 这个动作必须优先执行，因为后面的releaseLocalCache在远端失效时，很可能阻塞甚至报错
            onClose();
        } catch(Throwable err)
        {
            CmnUtil.err("FATAL : Failed to close resource CELL : " + this);
            err.printStackTrace();
            CmnUtil.throwRuntimeException(err);
        }
        finally
        {
            releaseLocalCache(); // 代理会被反射调用到这里 -> CallbackCache::releaseCallback( ... ) [Line:106]
        }
    }
    
    // 当cell被close的时候，会触发此方法，用于子类释放本地资源（如数据库连接等）
    public void onClose();
}
