package cell.flutter.test;

import flutter.coder.annt.AbstractVirtual;

@AbstractVirtual
public interface ITestBasic2
{
    default void intfBasic2() {
        
    }
}