package cell.flutter.test;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.kwaidoo.ms.tool.CmnUtil;
import com.leavay.common.util.ToolBasic;
import com.leavay.common.util.ToolUtilities;

import bap.cells.Cells;
import cell.ServiceCellIntf;
import flutter.coder.FlutterBuilder;
import flutter.coder.annt.NullReturn;
import flutter.util.test.Bean1Son;
import flutter.util.test.DynamicBean1;
import flutter.util.test.TestBean;
import flutter.util.test.TestDynamicBasic;
import flutter.util.test.TestEnum1;
import flutter.util.test.TestPojoGrandson;
import flutter.util.test.parent.TestPojoParent;
public interface ITestFlutterService extends ServiceCellIntf, ITestBasic1, ITestBasic2, ITestBasicBasic1
{
    public static ITestFlutterService get(){ return Cells.get(ITestFlutterService.class);}
    

    public default void testVoid()
    {

    }
    
    // 枚举的返回值很特殊, 发送的是string, 到了flutter端靠生成的死代码反解出枚举对象
    public default TestEnum1 testEnum(String a)
    {
        return TestEnum1.efg;
    }
    
    public default Bean1Son testSon() {
        return new Bean1Son();
    }
    
    public default TestDynamicBasic testDynamicBasic() {
        List lst = new LinkedList();
        DynamicBean1 b1 = new DynamicBean1();
        b1.lstChild = ToolUtilities.newArrayList(new DynamicBean1(), new Bean1Son());
        
        lst.add(b1);
        
        Bean1Son b2 = new Bean1Son();
        b2.lstChild = ToolUtilities.newArrayList(new DynamicBean1(), new Bean1Son());
        
        lst.add(b2);
        TestDynamicBasic b= new TestDynamicBasic();
        b.lstBeans = lst;
        
        b.bean = b2;
        b.obj = b2;
        
        return b;
    }
    
    public default List<DynamicBean1> testDynamicList() {
        List lst = new LinkedList();
        DynamicBean1 b1 = new DynamicBean1();
        b1.lstChild = ToolUtilities.newArrayList(new DynamicBean1(), new Bean1Son());
        
        lst.add(b1);
        
        Bean1Son b2 = new Bean1Son();
        b2.lstChild = ToolUtilities.newArrayList(new DynamicBean1(), new Bean1Son());
        
        lst.add(b2);
        return lst;
    }
    
    @NullReturn
    public default Object testObject(Object obj)
    {
        CmnUtil.out("Recived Size=" + ToolUtilities.fileSize2String(ToolUtilities.calcObjectMemSize(obj)));
        return obj;
        
//        List lst = new LinkedList();
//        for (int i=0; i<1; i++)
//            lst.add(obj);
//            
//        CmnUtil.out("Size="+ToolUtilities.fileSize2String(ToolUtilities.calcObjectMemSize(lst)));
//        return lst;
    }

    public default List<Integer> testList1()
    {
        return ToolBasic.newArrayList(1, 32);
    }

    public default List<TestBean> testList(List<TestBean> lst)
    {
        if (lst == null)
            return null;
        
         lst.add(new TestBean());
         return lst;
    }
    
    public default List<Boolean> testListBoolen(List<Boolean> lst)
    {
        return lst;
    }
    
    public default List<String> testListString(List<String> lst)
    {
        lst.add("From Server");
        return lst;
    }

//    
//    public default TestBean[] testArray(TestBean[] beans)
//    {
//        return beans;
//    }
//    
    public default Map<String, TestBean> testMap(Map<String, TestBean> mapData)
    {
        if (mapData == null)
            return null;
        
        mapData.put("CK1", null);
        return mapData;
    }
    
    public default Map<String, String> testMapString(Map<String, String> map)
    {
        map.put("From Server", ToolUtilities.getCurrentIP());
        return map;
    }

    public default TestBean test1(TestBean bean1)
    {
        return bean1;
    }

    public default TestBean test2(TestBean bean)
    {
        return bean;
    }

    public default int testInt(int v)
    {
        return v + 1;
    }

    public default long testLong(long v)
    {
        return v + 1;
    }

    public default double testDouble(double v)
    {
        return v + 1;
    }

    public default float testFloat(float f)
    {
        return f + 1;
    }

    public default String testString(String s)
    {
        return s+"[RETURN]";
    }

    public default Object testDynamic(Object obj)
    {
        return obj;
    }
    
    public default TestPojoParent testInherit(TestPojoGrandson grandson) {
        return grandson;
    }

    public static void main(String[] args) throws Exception
    {
        String dstFile = "F:/flutter/core/lib/java_test/test.dart";

        FlutterBuilder builder = new FlutterBuilder().setTargetFile(dstFile);
        builder.buildInterface(ITestFlutterService.class, ITestFlutterServiceAdv.class);
//
//        CmnUtil.out(ToolBasic.readFileUtf8(dstFile));
//        CmnUtil.out("Finish export Dart file to : " + dstFile);
    }
}