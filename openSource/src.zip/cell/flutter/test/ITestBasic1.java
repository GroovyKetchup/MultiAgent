package cell.flutter.test;

import flutter.coder.annt.AbstractVirtual;

@AbstractVirtual
public interface ITestBasic1
{
    default void intfBasic1() {
        
    }
}