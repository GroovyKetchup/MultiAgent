package cell.flutter.test;

import java.util.List;
import java.util.Map;

import bap.cells.Cells;
import cell.ServiceCellIntf;
import flutter.util.test.TestBean2;
import flutter.util.test.bean.subsub.SubSubBean;

public interface ITestFlutterServiceAdv extends ServiceCellIntf, ITestBasic2, ITestBasicBasic1
{
    public static ITestFlutterServiceAdv get(){ return Cells.get(ITestFlutterServiceAdv.class);}

    public default void testVoid()
    {
        
    }
    
    public default List<Integer> testList1()
    {
        return null;
    }
    
    public default List<TestBean2> testList(List<TestBean2> lst)
    {
        return lst;
    }

    public default Map<String, TestBean2> testMap(Map<String, TestBean2> mapData)
    {
        mapData.put("CK1", null);
        return mapData;
    }
    
    public default TestBean2 test1(TestBean2 bean1)
    {
        return bean1;
    }
    
    public default SubSubBean testSubSubBean(SubSubBean b1, List<SubSubBean> lstB)
    {
        return b1;
    }
    
    
}
