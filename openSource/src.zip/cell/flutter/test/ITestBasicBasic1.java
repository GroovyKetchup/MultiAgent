package cell.flutter.test;

import flutter.coder.annt.AbstractVirtual;
import flutter.util.test.TestBeanSon;

@AbstractVirtual
public interface ITestBasicBasic1
{
    default String testBasicBasic1(TestBeanSon son)
    {
        return ""+son;
    }
}
