package cell.flutter.test;

import bap.cells.SimpleServiceCell;

public class CTestFlutterService extends SimpleServiceCell implements ITestFlutterService
{

}
