package cell;

/**
 * 作为二次开发自定义扩展的插件类，需派生此接口
 * 
 * 插件通常作为常驻无状态服务（单例会比较省性能一点）注册在Cells工厂，其包名必须cell开头才能被识别
 * 
 * 必须是无状态的，且无启停动作，内部不得维护缓存，否则必须在stopService时释放清理干净
 * 
 * 二次开发时扩展插件需自定义实现类继承于BasicCell并派生插件接口，重载相关函数即可，同样要保证无状态无缓存无启停动作
 * 
 * 例如：
 * public interface IPluginDemo extends PluginCellIntf
 * {
 *      public default void test(){
 *          // Default Action
 *      };
 * }
 * 
 * public class CPluginDemo extends BasicCell implements IPluginDemo
 * {
 *      public void test(){
 *          //Do Something Customized
 *      };
 * }
 * 
 */
public interface PluginCellIntf extends ServiceCellIntf
{
    // 插件类通常作为常驻服务（无状态），单例会比较省性能一点，无需启停
    public default boolean isStarted()
    {
        return true;
    }
    
    public default void startService() throws Exception
    {
        
    }
    
    public default void stopService()
    {
        
    }
}
