package cell;

public interface UdfIntf extends CellIntf
{
    public final static String PACKAGE_PREFIX = "udf";
    public final static String MAIN_METHOD = "execute";
    
    public static boolean isUdfPackage(String pkg)
    {
        return pkg != null && (pkg.equals(PACKAGE_PREFIX) || pkg.startsWith(PACKAGE_PREFIX+"."));
    }
}
