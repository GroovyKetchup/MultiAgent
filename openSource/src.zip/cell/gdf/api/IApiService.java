package cell.gdf.api;

import bap.cells.Cells;
import cell.ServiceCellIntf;

public interface IApiService extends ServiceCellIntf{
	
	public static IApiService get() {
		return Cells.get(IApiService.class);
	}

	public IApiConn getDefaultApiConn() throws Exception;
	
	public IApiConn getApiConn(String name,String password)throws Exception;
	
	public IApiConn getApiConn(String sessionKey)throws Exception;
}
