package cell.gdf.api;

import bap.cells.CellConfig;

public class CRmiConfig extends CellConfig
{
    private static final long serialVersionUID = 3888868802626302348L;

    //RMI 连接的主控IP地址，在云开发调试的时候设置，发布的时候不需要设置
    public String host = null;
    //RMI 连接默认的连接端口
    public int rmiPort = 10000;
    
}
