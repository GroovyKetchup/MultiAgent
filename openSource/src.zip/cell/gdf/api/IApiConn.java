package cell.gdf.api;

import cell.CellIntf;
import cell.ResourceCellIntf;

public interface IApiConn extends ResourceCellIntf{
	public <T extends CellIntf> T getMgr(Class<T> intf) throws Exception;
	
	public String getSessionKey();
	
}
