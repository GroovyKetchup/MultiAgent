package cell.gdf.api.impl;

import bap.cells.BasicCell;
import bap.cells.Cells;
import cell.CellIntf;
import cell.gdf.api.IApiConn;

public class CApiConn extends BasicCell implements IApiConn{

	protected String sessionKey;
	
	public CApiConn(String sessionKey) {
		this.sessionKey = sessionKey;
	}
	
	@Override
	public void onClose() {
		
	}

	@Override
	public <T extends CellIntf> T getMgr(Class<T> intf) throws Exception {
		return Cells.get(intf, sessionKey);
	}
	
	public String getSessionKey() {
		return sessionKey;
	}

}
