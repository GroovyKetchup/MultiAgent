package cell.gdf.api.impl;

import java.util.concurrent.ConcurrentHashMap;

import com.kwaidoo.ms.tool.CmnUtil;
import com.kwaidoo.ms.tool.ToolUtilities;
import com.leavay.common.util.StringLock;
import com.leavay.common.util.StringLock.LockObject;
import com.leavay.common.util.TimeoutException;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.mgr.dcsutil;
import com.leavay.sm_lm.common.sm.inf.Users;

import bap.cells.BasicServiceCell;
import cell.gdf.api.IApiConn;
import cell.gdf.api.IApiService;

public class CApiService extends BasicServiceCell implements IApiService{
	
	ConcurrentHashMap<String, String> sessionCache = new ConcurrentHashMap<String, String>();
	
	StringLock _lock = new StringLock(30000);

	protected LockObject lock(String rdn) throws TimeoutException {
		return _lock.lockDN(rdn);
	}

	protected LockObject lock(String rdn, long timeout) throws TimeoutException {
		return _lock.lockDN(rdn, timeout);
	}

	protected void unlock(LockObject lock) {
		if (lock != null)
			lock.unlockIfExist();
	}

	@Override
	public IApiConn getDefaultApiConn() throws Exception {
		String password = dcsutil.getDcsIntf().getApiUserPassword();
		return getApiConn(Users.API_USER, password);
	}

	@Override
	public IApiConn getApiConn(String name, String password) throws Exception {
		String thisIP = "127.0.0.1";
		try{
			thisIP = dfcutil.getDfcIntf().getClientHostByRmi();
		}catch (Exception e) {
		}
		String cacheKey = getCacheKey(name, password, thisIP);
		String sessionKey = sessionCache.get(cacheKey);
		ToolUtilities.info(CApiService.class.getSimpleName(),"getApiConn sessionKey = " + sessionKey);
		boolean isValid = false;
		if(!CmnUtil.isStringEmpty(sessionKey)) {
			isValid = dfcutil.getSmIntf().isValid(sessionKey);
//			sessionCache.remove(cacheKey);
		}
		if(!isValid) {
			LockObject lock = null;
			try {
				lock = lock(cacheKey);
//				if(CmnUtil.isStringEmpty(sessionCache.get(cacheKey))){
				ToolUtilities.info(CApiService.class.getSimpleName(),"before-getApiConn sessionKey = " + sessionKey);
					sessionKey = dfcutil.getSmIntf().login(name, password, thisIP);
					ToolUtilities.info(CApiService.class.getSimpleName(),"after-getApiConn sessionKey = " + sessionKey);
					sessionCache.put(cacheKey, sessionKey);
//				}
			}finally {
				ToolUtilities.info(CApiService.class.getSimpleName(),"getApiConn sessionKey = " + sessionKey);
				unlock(lock);
			}
		}
		return getApiConn(sessionKey);
	}
	
	private static String getCacheKey(String user,String password,String ip){
		return user+"_"+password+"_"+ip;
	}

	@Override
	public IApiConn getApiConn(String sessionKey) throws Exception {
		return new CApiConn(sessionKey);
	}

	@Override
	protected void doStartService() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void doStopService() {
		// TODO Auto-generated method stub
		
	}

}
