package cell.gdf.dashboard;

import java.util.List;

import com.kwaidoo.dc.view.dto.ViewAngleDto;

import bap.cells.Cells;
import cell.web.SessionCellIntf;

/**
 * 看板
 * @author ChanJy
 *
 */
public interface IDashboardService extends SessionCellIntf{
	
	public static IDashboardService get(String sessionKey) {
		return Cells.get(IDashboardService.class, sessionKey);
	}
	
	
	/**
	 * 创建看板列表
	 * 
	 * @return
	 * @throws Exception
	 */
	List<ViewAngleDto>  queryViewAngleList()throws Exception;
	
	/**
	 * 创建看板
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 */
	ViewAngleDto  createViewAngel(ViewAngleDto data) throws Exception;
	
	/**
	 * 修改看板信息
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 */
	ViewAngleDto updateViewAngle(ViewAngleDto data) throws Exception;
	
	/**
	 * 删除看板
	 * 
	 * @param id
	 * @throws Exception
	 */
	void deleteViewAngleDto(String id)throws Exception;
	
	/**
	 * 查询看板信息
	 * 
	 * @param id
	 * @return
	 * @throws Exception
	 */
	ViewAngleDto queryViewAngle(String id)throws Exception;
	
}
