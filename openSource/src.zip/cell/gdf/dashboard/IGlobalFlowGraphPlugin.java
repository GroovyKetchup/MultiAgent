package cell.gdf.dashboard;

import java.util.List;
import java.util.Set;

import com.kwaidoo.dashboard.dto.FlowNode;
import com.kwaidoo.dashboard.dto.FlowNodeStatus;
import com.kwaidoo.dc.dto.BaseDto;

import bap.cells.Cells;
import cell.PluginCellIntf;

/**
 * 全局血缘图插件类
 * @author chenxb
 *
 */
public interface IGlobalFlowGraphPlugin extends PluginCellIntf{
	
	public static IGlobalFlowGraphPlugin get() {
		return Cells.get(IGlobalFlowGraphPlugin.class);
	}

	public default void makeNodeSummarys(Set<FlowNode> nodes) {
		for(FlowNode node : nodes) {
			List<BaseDto> summarys = makeNodeSummary(node.getSummary());
			node.setSummary(summarys);
		}
	}
	
	public default List<BaseDto> makeNodeSummary(List<BaseDto> summarys){
		return summarys;
	}
	
	public default void makeNodeStatusSummarys(Set<FlowNodeStatus> nodes) {
		for(FlowNodeStatus node : nodes) {
			List<BaseDto> summarys = makeNodeSummary(node.getSummarys());
			node.setSummarys(summarys);
		}
	}
}
