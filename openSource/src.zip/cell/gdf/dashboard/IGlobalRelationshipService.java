package cell.gdf.dashboard;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.kwaidoo.dashboard.dto.FlowNode;
import com.kwaidoo.dashboard.dto.GlobalFlowGraph;
import com.kwaidoo.dashboard.dto.GlobalFlowGraphStatus;
import com.kwaidoo.dashboard.dto.GlobalRelationShipViewStastic;
import com.kwaidoo.dashboard.dto.GlobalRelationshipView;
import com.kwaidoo.dashboard.dto.GlobalRelationshipViewVo;
import com.kwaidoo.dashboard.dto.PdfLinkDto;
import com.kwaidoo.dashboard.impl.NodeSummary;
import com.kwaidoo.dc.config.dto.PdcDto;
import com.kwaidoo.dc.config.dto.PdcSqlMappingDto;
import com.kwaidoo.dc.dto.BaseDto;
import com.kwaidoo.dc.setting.dto.AgentStatusDto;
import com.kwaidoo.dc.utils.ProgressDetail;

import bap.cells.Cells;
import cell.web.SessionCellIntf;
import web.dto.FormDtoV2;
import web.dto.MultiPageResultDto;
import web.dto.Pair;
import web.vo.Condition;
import web.vo.OrderBy;

public interface IGlobalRelationshipService extends SessionCellIntf{
	
	public static IGlobalRelationshipService get(String sessionKey) {
		return Cells.get(IGlobalRelationshipService.class, sessionKey);
	}
	/**
	 * 查询全局血缘图，
	 * @param uuid
	 * @param ignoreUnnecessary 是否忽略非必要路径
	 * @return
	 * @throws Exception
	 */
	public GlobalFlowGraph queryGlobalFlow(String uuid,boolean ignoreUnnecessary)throws Exception;
	/**
	 * 查询全局血缘图
	 * @param uuid	全局血缘图的uuid
	 * @param viewKey	当前分析的视图
	 * @param expandViews 展开的视图
	 * @param analyzeNode 直系分析的节点
	 * @param ignoreUnnecessary 是否忽略非必要路径
	 * @return
	 * @throws Exception
	 */
	public GlobalFlowGraph queryGlobalFlow(String uuid,String viewKey,List<String> expandViews,String analyzeNode,boolean ignoreUnnecessary)throws Exception ;
	/**
	 * 展开视图
	 * @param uuid 全局血缘图的uuid
	 * @param viewKey 当前分析的视图
	 * @param expandViews 展开的视图
	 * @param analyzeNode 直系分析的节点
	 * @param ignoreUnnecessary 是否忽略非必要路径
	 * @return
	 * @throws Exception
	 */
	public GlobalFlowGraph expandView(String uuid, String viewKey,List<String> expandViews,String analyzeNode,boolean ignoreUnnecessary) throws Exception;
	/**
	 * 展开所有视图
	 * @param uuid 全局血缘图的uuid
	 * @param viewKey 当前分析的视图
	 * @param analyzeNode 直系分析的节点
	 * @param ignoreUnnecessary 是否忽略非必要路径
	 * @return
	 * @throws Exception
	 */
	public GlobalFlowGraph expandAllView(String uuid, String viewKey,String analyzeNode,boolean ignoreUnnecessary) throws Exception ;
	/**
	 * 下钻到视图
	 * @param uuid  全局血缘图的uuid
	 * @param viewKey 当前分析的视图
	 * @param expandViews 展开的视图
	 * @param analyzeNode 直系分析的节点
	 * @param ignoreUnnecessary 是否忽略非必要路径
	 * @return
	 * @throws Exception
	 */
	public GlobalFlowGraph drillInView(String uuid, String viewKey,List<String> expandViews,String analyzeNode,boolean ignoreUnnecessary)throws Exception;
	/**
	 * 查询节点的直系依赖视图
	 * @param uuid 全局血缘图的uuid
	 * @param viewKey 当前分析的视图
	 * @param expandViews 展开的视图
	 * @param analyzeNode 直系分析的节点
	 * @param ignoreUnnecessary 是否忽略非必要路径
	 * @return
	 * @throws Exception
	 */
	public GlobalFlowGraph queryDirectRelationShip(String uuid, String viewKey,List<String> expandViews,String analyzeNode,boolean ignoreUnnecessary)throws Exception;

	public GlobalFlowGraph autoLayout(GlobalFlowGraph data)throws Exception;
	/**
	 * 创建全局血缘视图以及子视图
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public GlobalRelationshipView createView(GlobalRelationshipView data)throws Exception;
	
	public GlobalRelationshipView updateView(GlobalRelationshipView data)throws Exception;
	/**
	 * 更新首层视图的坐标信息
	 * @param nodes
	 * @throws Exception
	 */
	public void updateViewLocation(Set<FlowNode> nodes) throws Exception;
	
	public GlobalRelationshipView queryView(String uuid)throws Exception;
	
	public GlobalRelationshipView queryViewByUuid(String id) throws Exception ;
	
	public GlobalRelationshipView queryViewByName(String parentUuid,String name) throws Exception ;
	
	public List<GlobalRelationshipView> queryChildViews(String uuid)throws Exception;
	
	public List<GlobalRelationshipViewVo> queryViewTree(String uuid,boolean lazyLoad) throws Exception;
	
	public void removeView(String uuid)throws Exception;
	
	public GlobalRelationshipView dragView(String uuid,String targetUuid,List<String> orderList)throws Exception;
	/**
	 * 将产线添加到全局血缘图中
	 * @param viewUuid
	 * @param pdfIds
	 * @throws Exception
	 */
	public void addPdfToView(String viewUuid, List<String> pdfIds) throws Exception ;
	/**
	 * 将产线从全局血缘图移除
	 * @param viewUuid
	 * @param pdfIds
	 * @throws Exception
	 */
	public void removePdfFormView(String viewUuid,List<String> pdfIds)throws Exception;
	public void removePdfFormView(String viewUuid,String pdfId)throws Exception;
	
	public MultiPageResultDto<PdfLinkDto> queryPdfInView(String viewUuid, String filtersKeyWord, List<Condition> filters, List<OrderBy> orderBy,int pageNo,int pageSize) throws Exception ;
	
	public void moveNodeToView(String viewUuid,List<String> nodeKeys)throws Exception;
	/**
	 * 配置全局血缘图中产线和运行产线的管理关系
	 * @param viewUuid
	 * @param pdfId
	 * @param jobId
	 * @throws Exception
	 */
	public void bindPdf2JobInView(String viewUuid,String pdfId,String jobId)throws Exception;
	/**
	 * 选择运行产线，自动根据运行产线下的产线绑定到对应全局血缘图中的产线
	 * @param viewUuid
	 * @param pdfIds
	 * @param jobIds
	 * @throws Exception
	 */
	public void bindAllPdf2JobInView(String viewUuid, List<String> pdfIds, List<String> jobIds) throws Exception;
//	public void bindPdf2JobInView(String viewUuid,List<Pair<String,String>> pdf2Job)throws Exception;
	/**
	 * 查询全局血缘图的节点状态
	 * @param uuid
	 * @return
	 * @throws Exception
	 */
	public GlobalFlowGraphStatus queryNodeStatus(String uuid)throws Exception;
	/**
	 * 查询全局血缘图中视图的统计信息
	 * @param uuid
	 * @param nodeKey
	 * @return
	 * @throws Exception
	 */
	public GlobalRelationShipViewStastic queryViewStastic(String uuid,String nodeKey)throws Exception;
	/**
	 * 查询全局血缘图中视图的汇总信息
	 * @param uuid
	 * @param nodeKey
	 * @return
	 * @throws Exception
	 */
	public NodeSummary queryNodeSummary(String uuid,String nodeKey)throws Exception;
	
	public List<NodeSummary> queryNodeSummary(String uuid,List<String> nodeKeys)throws Exception;
	
	public FormDtoV2 queryNode(String nodeKey,String translator,String privilegeConfig)throws Exception;
	
	public FlowNode updateNode(Map<String,Object> data,String translator)throws Exception;
	/**
	 * 查询指定视图下工位的分页列表
	 * @param viewUuid
	 * @param condition
	 * @param orderBy
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @throws Exception
	 */
	public MultiPageResultDto<FlowNode> queryNodePage(String viewUuid,List<Condition> condition, List<OrderBy> orderBy, int pageNo,
			int pageSize) throws Exception ;
	
	public MultiPageResultDto<FlowNode> queryNodePageByPdcIds(List<String> pdcIds) throws Exception;
	
	/**
	 * 调试pdc
	 * @param pdc
	 * @param selectAgent
	 * @param opTimeMills
	 * @param attrName
	 * @param destroyRpc
	 * @return
	 * @throws Exception
	 */
	public String debugPdc(PdcDto pdc,String selectAgent,long opTimeMills,String attrName, boolean destroyRpc)throws Exception;
	
	/**
	 * 查看详情
	 * @param pollerUuid
	 * @return
	 * @throws Exception
	 */
	public ProgressDetail queryCurrentRuntimeInfo(String pollerUuid) throws Exception;	
	
	/**
	 * 终止
	 * @param uuid
	 * @throws Exception
	 */
	public void terminateRemoteDebug(String uuid) throws Exception;
	
	/**
	 * 节点调试内代理下拉列表
	 * @return
	 * @throws Exception
	 */
	public List<AgentStatusDto> queryAvaliableAgent() throws Exception;
	
	/**
	 * 查询数据映射
	 * @param pdcId
	 * @return
	 * @throws Exception
	 */
	public PdcSqlMappingDto queryPDCSqlMapping(String pdcId) throws Exception;
	/**
	 * 数据映射--试运行sql
	 * @param id
	 * @param key
	 * @param sql
	 * @param pageSize
	 * @return
	 * @throws Exception
	 */
	public MultiPageResultDto<List<BaseDto>> testBuildSql(String id, String key, String sql, int pageSize) throws Exception;
	
	/**
	 * 数据映射--sql语句查询
	 * @param id
	 * @param key
	 * @param opTime
	 * @return
	 * @throws Exception
	 */
	public String queryBuildSql(String id,String key,Long opTime) throws Exception;

	/**
	 * 同步全局血缘图中的所有产线
	 * @param viewUuid 全局血缘图的uuid
	 * @return
	 * @throws Exception
	 */
	public void syncAllPdf2RelationShipView(String viewUuid) throws Exception;

	/**
	 *功能描述
	 * 分页查询全局血缘图下的节点
	 * @author Chand
	 * @date 2022/5/19
	 * @param viewUuid 全局血缘图uuid
	 * @param filtersKeyWord
	 * @param filters
	 * @param orderBy
	 * @param pageNo
	 * @param pageSize
	 * @return web.dto.MultiPageResultDto<com.kwaidoo.dashboard.dto.FlowNode>
	 */
	public MultiPageResultDto<FlowNode> queryFlowNodeInView(String viewUuid, String filtersKeyWord, List<Condition> filters, List<OrderBy> orderBy,int pageNo,int pageSize) throws Exception ;

	/**
	 *功能描述
	 * 获取节点及依赖、影响关系
	 * @author Chand
	 * @date 2022/5/19
	 * @param viewUuid
	 * @param key
	 * @return com.kwaidoo.dashboard.dto.GlobalFlowGraph
	 */
	public GlobalFlowGraph expandSourceAndTarget(String viewUuid, String key) throws Exception;

	/**
	 *功能描述
	 * 获取节点及依赖关系
	 * @author Chand
	 * @date 2022/5/19
	 * @param viewUuid
	 * @param key
	 * @return com.kwaidoo.dashboard.dto.GlobalFlowGraph
	 */
	public GlobalFlowGraph expandSource(String viewUuid, String key) throws Exception;

	/**
	 *功能描述
	 * 获取节点及影响关系
	 * @author Chand
	 * @date 2022/5/19
	 * @param viewUuid
	 * @param key
	 * @return com.kwaidoo.dashboard.dto.GlobalFlowGraph
	 */
	public GlobalFlowGraph expandTarget(String viewUuid, String key) throws Exception;

	/**
	 *功能描述
	 * 获取节点及所有依赖关系
	 * @author Chand
	 * @date 2022/5/19
	 * @param viewUuid
	 * @param key
	 * @return com.kwaidoo.dashboard.dto.GlobalFlowGraph
	 */
	public GlobalFlowGraph expandAllSource(String viewUuid, String key) throws Exception;

	/**
	 *功能描述
	 * 获取节点及所有影响关系
	 * @author Chand
	 * @date 2022/5/19
	 * @param viewUuid
	 * @param key
	 * @return com.kwaidoo.dashboard.dto.GlobalFlowGraph
	 */
	public GlobalFlowGraph expandAllTarget(String viewUuid, String key) throws Exception;


}
