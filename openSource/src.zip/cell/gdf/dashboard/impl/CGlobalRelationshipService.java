package cell.gdf.dashboard.impl;

import java.lang.reflect.Type;
import java.rmi.RemoteException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.kwaidoo.dashboard.dto.FlowNode;
import com.kwaidoo.dashboard.dto.FlowNodeStatus;
import com.kwaidoo.dashboard.dto.GlobalFlowGraph;
import com.kwaidoo.dashboard.dto.GlobalFlowGraphStatus;
import com.kwaidoo.dashboard.dto.GlobalRelationShipViewStastic;
import com.kwaidoo.dashboard.dto.GlobalRelationshipView;
import com.kwaidoo.dashboard.dto.GlobalRelationshipViewVo;
import com.kwaidoo.dashboard.dto.PdfLinkDto;
import com.kwaidoo.dashboard.impl.GlobalFlowCache;
import com.kwaidoo.dashboard.impl.GlobalFlowLayouter;
import com.kwaidoo.dashboard.impl.GlobalRelationshipMoMgr;
import com.kwaidoo.dashboard.impl.NodeSummary;
import com.kwaidoo.dc.BaseDtoUtil;
import com.kwaidoo.dc.BaseSecurityMgr;
import com.kwaidoo.dc.FlowNodeType;
import com.kwaidoo.dc.GdfUtil;
import com.kwaidoo.dc.concrete.dto.CdcDto;
import com.kwaidoo.dc.config.dto.PdcDto;
import com.kwaidoo.dc.config.dto.PdcSqlMappingDto;
import com.kwaidoo.dc.config.dto.ViewFieldDto;
import com.kwaidoo.dc.config.dto.ViewMetaNodeDto;
import com.kwaidoo.dc.dto.BaseDto;
import com.kwaidoo.dc.runtime.dto.JobDto;
import com.kwaidoo.dc.setting.dto.AgentStatusDto;
import com.kwaidoo.dc.translator.PdcDtoTranslator;
import com.kwaidoo.dc.utils.ProgressDetail;
import com.kwaidoo.ms.tool.CmnUtil;
import com.kwaidoo.rmi.GlobalRelationshipRmiMgr;
import com.kwaidoo.verify.ValidateException;
import com.leavay.common.util.DNParser;
import com.leavay.common.util.ToolUtilities;
import com.leavay.dc.design.CDCCustomConfig;
import com.leavay.dc.develop.PDF;
import com.leavay.dc.develop.PDFMgr;
import com.leavay.dc.exception.DCExceptionUtils;
import com.leavay.dc.exception.InputValidationException;
import com.leavay.dc.resource.AppRes;
import com.leavay.dc.runtime.Job;
import com.leavay.dc.runtime.JobMgr;
import com.leavay.dc.tools.DCUtils;
import com.leavay.dc.tools.StringUtil;
import com.leavay.dfc.gui.LvUtil;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.gui.component.JdbcMetaInfo;
import com.leavay.dfc.mgr.dcsutil;
import com.leavay.dfc.mgr.DFlowPattern.DFPatternMgr;
import com.leavay.model.exception.McException;
import com.leavay.model.inf.ManagedData;
import com.leavay.model.inf.filter.*;
import com.leavay.model.inf.sort.OrderByPair;
import com.leavay.model.mgr.MDMgrConn;
import com.leavay.model.mgr.MDUtil;

import cell.cmn.IJson;
import cell.cmn.IJsonService;
import cell.gdf.config.IPdcService;
import cell.gdf.dashboard.IGlobalRelationshipService;
import cell.gdf.dashboard.IGlobalFlowGraphPlugin;
import cell.gdf.design.ICdcService;
import cell.gdf.setting.operationsupport.IAgentService;
import cell.gdf.webframe.IWebConfigService;
import cmn.reflect.TypeToken;
import cmn.util.FlowGraph;
import cmn.util.FlowLink;
import etl.ETLContext;
import etl.ETLUtil;
import etl.handler.adaptor.EntityTranslator;
import modeldef.com.kwaidoo.dc.FlowNodeMo;
import modeldef.com.kwaidoo.dc.PdfLinkMo;
import modeldef.com.kwaidoo.dc.RelationshipViewMo;
import web.adapter.CellAdaptor;
import web.constant.WebConst;
import web.dto.ActionDefineDto;
import web.dto.ControllerDto;
import web.dto.FieldDefineDto;
import web.dto.FormConfigDto;
import web.dto.FormDtoV2;
import web.dto.MultiPageResultDto;
import web.dto.Pair;
import web.ui.component.WebTextField;
import web.util.StringUtils;
import web.vo.Condition;
import web.vo.OrderBy;

import static com.leavay.dfc.mgr.DCoreCache.getMoMgr;

public class CGlobalRelationshipService extends BaseSecurityMgr implements IGlobalRelationshipService{

	/**
	 * 
	 */
	private static final long serialVersionUID = -855836474735496978L;
	
	public final static String LOG = IGlobalRelationshipService.class.getSimpleName();

	public int hSpace = 80;
	public int vSpace = 80;
	public int topGroupWidth = 300;
	public int topGroupHeight = 150;
	public final static String Global_Relation_Flow = GlobalRelationshipMoMgr.Global_Relation_Flow;
	
	private IWebConfigService getWebConfigMgr() throws Exception {
		return getApiUtils().getMgr(IWebConfigService.class);
	}
	
	private IAgentService getAgentService() throws Exception {
		return getApiUtils().getMgr(IAgentService.class);
	}
	
	private GlobalRelationshipRmiMgr getGlobalRelationshipRmiMgr() throws Exception {
		return dcsutil.getDcsIntf().getRmiMgr(GlobalRelationshipRmiMgr.class, getSessionKey());
	}
	
	private IPdcService getPdcService() throws Exception {
		return getApiUtils().getMgr(IPdcService.class);
	}
	
	@Override
	public GlobalFlowGraph queryGlobalFlow(String uuid,boolean ignoreUnnecessary) throws Exception {
		ignoreUnnecessary = false;
		GlobalRelationshipView view = queryView(uuid);
		if(view == null)
			return null;
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		FlowGraph rootLayerGraph = cache.drillInView(view.getRdn(),ignoreUnnecessary);
		GlobalFlowGraph graph = new GlobalFlowGraph();
		graph.setUuid(view.getUuid());
		graph.setName(view.getName());
		Set<FlowNode> nodes = new LinkedHashSet<>();
		for(String node : rootLayerGraph.getAllNodes()) {
			if(cache.isView(node)) {
				FlowNode flowView = cache.getView(node);
				List<NodeSummary> summarys = queryNodeSummary(view.getUuid(), ToolUtilities.newArrayList(node));
				List<BaseDto> nodeSummarys = summarys.get(0).getSummary();
				flowView.setSummary(nodeSummarys);
				nodes.add(flowView);
				flowView.setCategory(FlowNodeType.TOP_GROUP);
			}else {
				nodes.add(cache.getNode(node));
			}
		}
		IGlobalFlowGraphPlugin.get().makeNodeSummarys(nodes);
		graph.setNodes(nodes);
		Set<FlowLink> links = new LinkedHashSet<>(rootLayerGraph.getAllLinks());
		graph.setLinks(links);
		return graph;
	}
	
	@Override
	public GlobalFlowGraph queryGlobalFlow(String uuid,String viewKey,List<String> expandViews,String analyzeNode,boolean ignoreUnnecessary)throws Exception {
		if(CmnUtil.isStringEmpty(viewKey)){
			if(CmnUtil.isStringEmpty(analyzeNode)) {
				return expandView(uuid, viewKey, expandViews,analyzeNode,ignoreUnnecessary);
			}else {
				return queryDirectRelationShip(uuid, viewKey,expandViews, analyzeNode,ignoreUnnecessary);
			}
		}else {
			return drillInView(uuid, viewKey,expandViews,analyzeNode,ignoreUnnecessary);
		}
	}

	@Override
	public GlobalFlowGraph expandView(String uuid, String viewKey,List<String> expandViews,String analyzeNode,boolean ignoreUnnecessary) throws Exception {
		if(!CmnUtil.isStringEmpty(analyzeNode)) {
			return queryDirectRelationShip(uuid, viewKey,expandViews, analyzeNode,ignoreUnnecessary);
		}
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			return null;
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		if(CmnUtil.isStringEmpty(viewKey))
			viewKey = view.getRdn();
		FlowGraph rootLayerGraph = cache.drillInView(view.getRdn(),ignoreUnnecessary);
		FlowGraph expandedGraph = cache.expandView(viewKey, expandViews,ignoreUnnecessary);
		return _buildGraph(view, cache, rootLayerGraph.getAllNodes(),new HashSet<>(expandViews),expandedGraph);
	}
	
	@Override
	public GlobalFlowGraph expandAllView(String uuid, String viewKey,String analyzeNode,boolean ignoreUnnecessary) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			return null;
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		List<String> expandViews = new ArrayList<>(cache.getAllViews().keySet());
		if(!CmnUtil.isStringEmpty(analyzeNode)) {
			return queryDirectRelationShip(uuid, viewKey,expandViews, analyzeNode,ignoreUnnecessary);
		}
		if(CmnUtil.isStringEmpty(viewKey))
			viewKey = view.getRdn();
		FlowGraph rootLayerGraph = cache.drillInView(view.getRdn(),ignoreUnnecessary);
		FlowGraph expandedGraph = cache.expandView(viewKey, expandViews,ignoreUnnecessary);
		return _buildGraph(view, cache, rootLayerGraph.getAllNodes(),new HashSet<>(expandViews),expandedGraph);
	}

	@Override
	public GlobalFlowGraph drillInView(String uuid, String viewKey,List<String> expandViews,String analyzeNode,boolean ignoreUnnecessary) throws Exception {
		if(!CmnUtil.isStringEmpty(analyzeNode)) {
			return queryDirectRelationShip(uuid, viewKey,expandViews, analyzeNode,ignoreUnnecessary);
		}
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			return null;
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		FlowGraph rootLayerGraph = cache.drillInView(view.getRdn(),ignoreUnnecessary);
		FlowGraph drillInGraph = cache.drillInView(viewKey,ignoreUnnecessary);
		Set<String> expandedViews = new HashSet<>();
		if(!CmnUtil.isCollectionEmpty(expandViews)) {
			expandedViews.addAll(expandViews);
		}
		return _buildGraph(view, cache, rootLayerGraph.getAllNodes(),expandedViews,drillInGraph);
	}

	@Override
	public GlobalFlowGraph queryDirectRelationShip(String uuid, String viewKey,List<String> expandViews,String analyzeNode,boolean ignoreUnnecessary) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			return null;
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		if(CmnUtil.isStringEmpty(viewKey))
			viewKey = view.getRdn();
		FlowGraph rootLayerGraph = cache.drillInView(viewKey,ignoreUnnecessary);
		Set<String> allAncestorNodes = cache.getViewTree().getAllAncestorNodes(analyzeNode);
		expandViews.addAll(allAncestorNodes);
		FlowGraph graph = cache.queryDirectRelationShip(view.getRdn(), expandViews,analyzeNode,ignoreUnnecessary);
		return buildGraph(view, cache, rootLayerGraph.getAllNodes(),new HashSet<>(expandViews),graph);
	}
	
	@SuppressWarnings("unchecked")
	private GlobalFlowGraph buildGraph(GlobalRelationshipView view,GlobalFlowCache cache,Set<String> rootNodes,Set<String> expandedViews,FlowGraph flowGraph) throws Exception {
		GlobalFlowGraph graph = new GlobalFlowGraph();
		graph.setUuid(view.getUuid());
		graph.setName(view.getName());
		Set<String> expandRootNodes = new HashSet<>(rootNodes);
		expandRootNodes.retainAll(expandedViews);
		Map<String,Set<String>> nodeInGroupMap = new HashMap<>();
		for(String groupKey : expandRootNodes) {
			nodeInGroupMap.put(groupKey, cache.getViewTree().getAllChildrenNodes(groupKey));
		}
		Set<FlowNode> nodes = new LinkedHashSet<>();
		//flowGraph.getDeepFirstSequence()方法遇到循环的视图，会丢失视图
		for(String nodeKey : flowGraph.getDeepFirstSequence()) {
			if(cache.isView(nodeKey)) {
				FlowNode flowView = cache.getView(nodeKey);
				nodes.add(flowView);
				if(rootNodes.contains(nodeKey)) {
					List<NodeSummary> summarys = queryNodeSummary(view.getUuid(), ToolUtilities.newArrayList(nodeKey));
					List<BaseDto> nodeSummarys = summarys.get(0).getSummary();
					if(!CmnUtil.isCollectionEmpty(view.getExtendInfo())) {
						for(Map<String,Object> extend : view.getExtendInfo()) {
							nodeSummarys.add(new BaseDto(extend));
						}
					}
					flowView.setSummary(nodeSummarys);
					flowView.setCategory(FlowNodeType.TOP_GROUP);
					flowView.setWidth(topGroupWidth);
					flowView.setHeight(topGroupHeight);
				}
			}else {
				FlowNode node = cache.getNode(nodeKey);
				ManagedData mo = dfcutil.getDfcIntf().getMo(node.getDependPDC());
				if(mo != null) {
					String cdcName = DCUtils.getModelName(mo.getCLASS());
					CDCCustomConfig customConfig = dcsutil.getDcsIntf().getCdcCustomConfigCache(cdcName);
					node.setLabel(GlobalRelationshipMoMgr.getPDCLabel(mo,customConfig));
					node.setIcon(WebConst.getIconUri(customConfig.getDisplayIcon()));
					nodes.add(node);
				}
			}
		}
		IGlobalFlowGraphPlugin.get().makeNodeSummarys(nodes);
		graph.setNodes(nodes);
		Set<FlowLink> links = new LinkedHashSet<>(flowGraph.getAllLinks());
		graph.setLinks(links);
//		GlobalFlowLayouter.layOut(graph, nodeInGroupMap,hSpace, vSpace);
		GlobalFlowLayouter.layOut(graph,hSpace, vSpace);
		return graph;
	}

	private GlobalFlowGraph _buildGraph(GlobalRelationshipView view,GlobalFlowCache cache,Set<String> rootNodes,Set<String> expandedViews,FlowGraph flowGraph) throws Exception {
		GlobalFlowGraph graph = new GlobalFlowGraph();
		graph.setUuid(view.getUuid());
		graph.setName(view.getName());
		Set<String> expandRootNodes = new HashSet<>(rootNodes);
		expandRootNodes.retainAll(expandedViews);
		Map<String,Set<String>> nodeInGroupMap = new HashMap<>();
		for(String groupKey : expandRootNodes) {
			nodeInGroupMap.put(groupKey, cache.getViewTree().getAllChildrenNodes(groupKey));
		}
		Set<FlowNode> nodes = new LinkedHashSet<>();
		for (String nodeKey : flowGraph.getAllNodes()) {
			if(cache.isView(nodeKey)) {
				FlowNode flowView = cache.getView(nodeKey);
				nodes.add(flowView);
				if(rootNodes.contains(nodeKey)) {
					List<NodeSummary> summarys = queryNodeSummary(view.getUuid(), ToolUtilities.newArrayList(nodeKey));
					List<BaseDto> nodeSummarys = summarys.get(0).getSummary();
					if(!CmnUtil.isCollectionEmpty(view.getExtendInfo())) {
						for(Map<String,Object> extend : view.getExtendInfo()) {
							nodeSummarys.add(new BaseDto(extend));
						}
					}
					flowView.setSummary(nodeSummarys);
					flowView.setCategory(FlowNodeType.TOP_GROUP);
					flowView.setWidth(topGroupWidth);
					flowView.setHeight(topGroupHeight);
				}
			}else {
				FlowNode node = cache.getNode(nodeKey);
				ManagedData mo = dfcutil.getDfcIntf().getMo(node.getDependPDC());
				if(mo != null) {
					String cdcName = DCUtils.getModelName(mo.getCLASS());
					CDCCustomConfig customConfig = dcsutil.getDcsIntf().getCdcCustomConfigCache(cdcName);
					node.setLabel(GlobalRelationshipMoMgr.getPDCLabel(mo,customConfig));
					node.setIcon(WebConst.getIconUri(customConfig.getDisplayIcon()));
					nodes.add(node);
				}
			}
		}
		IGlobalFlowGraphPlugin.get().makeNodeSummarys(nodes);
		graph.setNodes(nodes);
		Set<FlowLink> links = new LinkedHashSet<>(flowGraph.getAllLinks());
		graph.setLinks(links);
//		GlobalFlowLayouter.layOut(graph, nodeInGroupMap,hSpace, vSpace);
		GlobalFlowLayouter.layOut(graph,hSpace, vSpace);
		return graph;
	}
	
	@Override
	public GlobalFlowGraph autoLayout(GlobalFlowGraph data) throws Exception {
		GlobalFlowLayouter.layOut(data, hSpace, vSpace);
		return data;
	}

	@Override
	public GlobalRelationshipView createView(GlobalRelationshipView data) throws Exception {
		RelationshipViewMo view = convert2ViewMo(data);
		//临时处理
//		if(CmnUtil.isStringEmpty(data.getParentUuid())) {
//			GlobalRelationshipView parentView = queryViewByUuid(null);
//			view.setPDN(parentView.getRdn());
//			view.setParentUuid(parentView.getUuid());
//		}
		if(!CmnUtil.isStringEmpty(data.getParentUuid())) {
			GlobalRelationshipView parentView = queryViewByUuid(data.getParentUuid());
			view.setPDN(parentView.getRdn());
			view.setParentUuid(parentView.getUuid());
		}
		if(!CmnUtil.isStringEmpty(data.getUuid())) {
			GlobalRelationshipView existView = queryViewByUuid(data.getUuid());
			if(existView != null)
				throw new ValidateException(GdfUtil.getString("View uuid %s is used!",data.getUuid()));
		}
		view = getGlobalRelationshipRmiMgr().createView(view);
		RelationshipViewMo bloodGraph = getGlobalRelationshipRmiMgr().queryGlobalBloodView(view.getRDN());
		getGlobalRelationshipRmiMgr().clearDirtyCache(bloodGraph.getRDN());
		return convert2View(view);
	}
	
	public static RelationshipViewMo convert2ViewMo(GlobalRelationshipView view) throws RemoteException, McException, Exception {
		RelationshipViewMo mo = newMoByClassName(RelationshipViewMo.class);
		long id = DNParser.getID(view.getRdn());
		if(id > 0)
			mo.setID(id);
		mo.setName(view.getName());
		mo.setLabel(view.getLabel());
		mo.setUuid(view.getUuid());
		mo.setParentUuid(view.getParentUuid());
		mo.setPDN(view.getPdn());
		mo.setNodeType(view.getNodeType());
		mo.setIcon(view.getIcon());
		mo.setLoc(view.getLoc());
		mo.setWidth(view.getWitdh());
		mo.setHeight(view.getHeight());
		try(IJson json = IJsonService.get().getJson()){
			try {
				mo.setStyle(json.toJson(view.getStyle()));
				view.getExtendInfo();
			}catch (Exception e) {
				ToolUtilities.warning(LOG, "convert2ViewMo GlobalRelationshipView.style toJson failed:",e);
			}
			try {
				mo.setExtendInfo(json.toJson(view.getExtendInfo()));
			}catch (Exception e) {
				ToolUtilities.warning(LOG, "convert2ViewMo GlobalRelationshipView.style toJson failed:",e);
			}
		}
		return mo;
		
	}
	
	@SuppressWarnings("unchecked")
	public static GlobalRelationshipView convert2View(RelationshipViewMo mo) {
		GlobalRelationshipView view = new GlobalRelationshipView();
		view.setRdn(mo.getRDN());
		view.setPdn(mo.getPDN());
		view.setUuid(mo.getUuid());
		view.setParentUuid(mo.getParentUuid());
		view.setName(mo.getName());
		view.setLabel(mo.getLabel());
		view.setNodeType(mo.getNodeType());
		view.setLoc(mo.getLoc());
		view.setIcon(mo.getIcon());
		view.setWidth(mo.getWidth()).setHeight(mo.getHeight());
		try(IJson json = IJsonService.get().getJson()){
			if(!CmnUtil.isStringEmpty(mo.getStyle())) {
				try {
					view.setStyle(json.fromJson(mo.getStyle(), Map.class));
				}catch (Exception e) {
					ToolUtilities.warning(LOG, "convert2View GlobalRelationshipView.style fromJson failed",e);
				}
			}
			try {
				view.setExtendInfo(json.fromJson(mo.getExtendInfo(), List.class));
			}catch (Exception e) {
				ToolUtilities.warning(LOG, "convert2View GlobalRelationshipView.extendInfo fromJson failed:",e);
			}
		}
		return view;
	}
	
	public static <T,R> List<R> convertObjects(List<T> data,Function<T, R> function) {
		return data.stream().map(function).collect(Collectors.toList());
	}
	
	public static Function<RelationshipViewMo, GlobalRelationshipView> getMO2ViewFunction(){
		return new Function<RelationshipViewMo, GlobalRelationshipView>() {
			@Override
			public GlobalRelationshipView apply(RelationshipViewMo t) {
				return convert2View(t);
			}
		};
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T newMoByClassName(Class<T> clazz) throws RemoteException, McException, Exception {
		return (T) dfcutil.getDfcIntf().newMoByClassName(MDUtil.getClassNameForSysteMO(clazz));
	}

	@Override
	public GlobalRelationshipView updateView(GlobalRelationshipView data) throws Exception {
		GlobalRelationshipView existView = queryViewByUuid(data.getUuid());
		if(existView == null) {
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!",data.getUuid()));
		}
		RelationshipViewMo mo = convert2ViewMo(data);
		if(!CmnUtil.isStringEmpty(data.getParentUuid())) {
			GlobalRelationshipView parentView = queryViewByUuid(data.getParentUuid());
			mo.setPDN(parentView.getRdn());
			mo.setParentUuid(parentView.getUuid());
		}
		mo = getGlobalRelationshipRmiMgr().updateView(mo);
		RelationshipViewMo bloodGraph = getGlobalRelationshipRmiMgr().queryGlobalBloodView(mo.getRDN());
		getGlobalRelationshipRmiMgr().clearDirtyCache(bloodGraph.getRDN());
		return convert2View(mo);
	}
	
	@Override
	public void updateViewLocation(Set<FlowNode> nodes) throws Exception{
		if(CmnUtil.isCollectionEmpty(nodes))
			return;
		String nodeKey = null;
		for(FlowNode node : nodes) {
			if(CmnUtil.isStringEqual(node.getCategory(), FlowNodeType.GROUP) 
					|| CmnUtil.isStringEqual(node.getCategory(), FlowNodeType.TOP_GROUP)) {
				String viewKey = node.getKey();
				nodeKey = viewKey;
				String loc = node.getLoc();
				GlobalRelationshipView existView = queryView(viewKey);
				if(existView == null) {
					throw new Exception(AppRes.getStringWithParam("View %s is not exist!",viewKey));
				}
				existView.setLoc(loc);
				updateView(existView);
			}
		}
		if(!CmnUtil.isStringEmpty(nodeKey)) {
			RelationshipViewMo bloodGraph = getGlobalRelationshipRmiMgr().queryGlobalBloodView(nodeKey);
			getGlobalRelationshipRmiMgr().clearDirtyCache(bloodGraph.getRDN());
		}
	}

	@Override
	public GlobalRelationshipView queryViewByUuid(String uuid) throws Exception {
		//TODO 临时做的特殊处理，后续需要屏蔽掉
		if(CmnUtil.isStringEmpty(uuid))
			return queryViewByName(null, Global_Relation_Flow);
		RelationshipViewMo mo = getGlobalRelationshipRmiMgr().queryViewByUuid(uuid);
		if(mo == null)
			return null;
		return convert2View(mo);
	}
	
	@Override
	public GlobalRelationshipView queryViewByName(String parentUuid, String name) throws Exception {
		RelationshipViewMo mo = getGlobalRelationshipRmiMgr().queryViewByName(parentUuid,name);
		if(mo == null)
			return null;
		return convert2View(mo);
	}
	
	@Override
	public GlobalRelationshipView queryView(String rdn)throws Exception{
		//TODO 临时做的特殊处理，后续需要屏蔽掉
		if(CmnUtil.isStringEmpty(rdn))
			return queryViewByName(null, Global_Relation_Flow);
		RelationshipViewMo mo = getGlobalRelationshipRmiMgr().queryView(rdn);
		if(mo == null)
			return null;
		return convert2View(mo);
	}
	@Override
	public List<GlobalRelationshipView> queryChildViews(String uuid)throws Exception{
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			return Collections.emptyList();
		List<RelationshipViewMo> childViews = getGlobalRelationshipRmiMgr().queryChildViews(view.getRdn());
		return convertObjects(childViews, getMO2ViewFunction());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<GlobalRelationshipViewVo> queryViewTree(String uuid,boolean lazyLoad) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!",uuid));
		List<GlobalRelationshipView> childViews = queryChildViews(view.getUuid());
		try(IJson json = CellAdaptor.getJsonService().getJson()){
			Type type = new TypeToken<List<GlobalRelationshipViewVo>>() {}.getType();
			List<GlobalRelationshipViewVo> childrens = json.forceCastByType(type, childViews);
			if(!lazyLoad) {
				for(GlobalRelationshipViewVo children : childrens) {
					loadChildList(children);
				}
			}
			return childrens;
		}
	}
	
	private void loadChildList(GlobalRelationshipViewVo node) throws Exception {
		List<GlobalRelationshipView> childViews = queryChildViews(node.getUuid());
		Type type = new TypeToken<List<GlobalRelationshipViewVo>>() {}.getType();
		try(IJson json = CellAdaptor.getJsonService().getJson()){
			List<GlobalRelationshipViewVo> childrens = json.forceCastByType(type, childViews);
			node.setChildrens(childrens);
			for(GlobalRelationshipViewVo children : childrens) {
				loadChildList(children);
			}
		}
	}

	@Override
	public void removeView(String uuid) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view != null) {
			RelationshipViewMo bloodGraph = getGlobalRelationshipRmiMgr().queryGlobalBloodView(view.getRdn());
			getGlobalRelationshipRmiMgr().deleteView(view.getRdn());
			getGlobalRelationshipRmiMgr().clearDirtyCache(bloodGraph.getRDN());
		}
	}
	
	@Override
	public GlobalRelationshipView dragView(String uuid, String targetUuid, List<String> orderList) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", uuid));
		GlobalRelationshipView targetView = queryViewByUuid(targetUuid);
		if(targetView == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", targetUuid));
		RelationshipViewMo viewMo = convert2ViewMo(view);
		RelationshipViewMo targetViewMo = convert2ViewMo(targetView);
		viewMo = getGlobalRelationshipRmiMgr().moveView(viewMo, targetViewMo, orderList);
		RelationshipViewMo bloodGraph = getGlobalRelationshipRmiMgr().queryGlobalBloodView(viewMo.getRDN());
		getGlobalRelationshipRmiMgr().clearDirtyCache(bloodGraph.getRDN());
		return convert2View(viewMo);
	}

	@Override
	public void addPdfToView(String viewUuid, List<String> pdfIds) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		List<Pair<String, String>> pdfs = new ArrayList<>();
		PDFMgr pdfMgr = getDCSAPIUtils().getPDFMgr();
		for (String pdfId : pdfIds) {
			PDF pdf = pdfMgr.getPDF(pdfId);
			if (null != pdf) {
				pdfs.add(new Pair<>(pdf.getID(), pdf.getName()));
			}
		}
		getGlobalRelationshipRmiMgr().mapPdf2View(view.getRdn(), pdfs);
		RelationshipViewMo bloodGraph = getGlobalRelationshipRmiMgr().queryGlobalBloodView(view.getRdn());
		getGlobalRelationshipRmiMgr().clearDirtyCache(bloodGraph.getRDN());
	}
	
	@Override
	public void removePdfFormView(String viewUuid, List<String> pdfIds) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		getGlobalRelationshipRmiMgr().removePdfFormView(view.getRdn(), pdfIds);
		RelationshipViewMo bloodGraph = getGlobalRelationshipRmiMgr().queryGlobalBloodView(view.getRdn());
		getGlobalRelationshipRmiMgr().clearDirtyCache(bloodGraph.getRDN());
	}

	@Override
	public void removePdfFormView(String viewUuid, String pdfId) throws Exception {
		removePdfFormView(viewUuid, Arrays.asList(pdfId));
	}

	@Override
	public MultiPageResultDto<PdfLinkDto> queryPdfInView(String viewUuid, String filtersKeyWord, List<Condition> filters, List<OrderBy> orderBy,int pageNo,int pageSize) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		int startPos = (pageNo - 1) * pageSize;
		NameValuePair nvQuery = Condition.toNameValuePair(filters);
		if (!CmnUtil.isStringEmpty(filtersKeyWord)) {
			NameValuePair fullContetNvl = getFullContetNvl(filtersKeyWord);
			if (nvQuery == null) {
				nvQuery = fullContetNvl;
			} else {
				nvQuery = MDUtil.newAndNv(nvQuery, fullContetNvl);
			}
		}
		MultiPageResultDto<PdfLinkMo> moLst = getGlobalRelationshipRmiMgr().queryPdfLink(view.getRdn(), nvQuery, startPos, pageSize);
		MultiPageResultDto<PdfLinkDto> rs = BaseDtoUtil.getMe().transformObjectsToPage(moLst.getTableData(), v->toDto(v, PdfLinkDto.class));
		rs.setTotal(moLst.getTotal());
		return rs;
	}

	public NameValuePair getFullContetNvl(String filtersKeyWord) {
		filtersKeyWord = ToolUtilities.replaceAll(filtersKeyWord, "*", "%");
		List<NameValuePair> nvs = new ArrayList<NameValuePair>();
		nvs.add(new LikeNameValuePair(PdfLinkMo.attr_Pdf_name, "%" + filtersKeyWord + "%", true));
		nvs.add(new LikeNameValuePair(PdfLinkMo.attr_Job_name, "%" + filtersKeyWord + "%", true));
		NameValuePair<?> filter = new OrOPNameValue(nvs);
		return filter;
	}
	
	@Override
	public NodeSummary queryNodeSummary(String uuid, String nodeKey) throws Exception {
		List<NodeSummary> summarys = queryNodeSummary(uuid, ToolUtilities.newArrayList(nodeKey));
		if(CmnUtil.isCollectionEmpty(summarys))
			return null;
		return summarys.get(0);
	}
	
	@Override
	public List<NodeSummary> queryNodeSummary(String uuid,List<String> nodeKeys) throws Exception {
		//节点汇总信息：包括视图内的节点数量、运行完成总数、未完成数，运行状态等信息
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", uuid));
		GlobalFlowCache flowCache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		List<NodeSummary> nodeSummarys = new ArrayList<>();
		for(String nodeKey : nodeKeys) {
			if(flowCache.isView(nodeKey)) {
				NodeSummary nodeSummary = new NodeSummary();
				List<BaseDto> summarys = new ArrayList<>();
				nodeSummary.setKey(nodeKey);
				nodeSummary.setSummary(summarys);
				
				BaseDto nodeCount = new BaseDto();
				nodeCount.set(NodeSummary.SUMMARY_KEY,NodeSummary.SUMMARY_KEY_NODE_COUNT);
				nodeCount.set(NodeSummary.SUMMARY_LABEL,NodeSummary.SUMMARY_LABEL_NODE_COUNT);
				Set<String> allLeafNodes = flowCache.getViewTree().getAllLeafNodes(nodeKey);
				nodeCount.set(NodeSummary.SUMMARY_VALUE,""+allLeafNodes.size());
				summarys.add(nodeCount);
				GlobalRelationShipViewStastic stastic = queryViewStastic(uuid, nodeKey);
				BaseDto finishedNodeCount = new BaseDto();
				finishedNodeCount.set(NodeSummary.SUMMARY_KEY,NodeSummary.SUMMARY_KEY_FINISHED_NODE_COUNT);
				finishedNodeCount.set(NodeSummary.SUMMARY_LABEL,NodeSummary.SUMMARY_LABEL_FINISHED_NODE_COUNT);
				finishedNodeCount.set(NodeSummary.SUMMARY_VALUE, ""+stastic.getFinishOk());
				summarys.add(finishedNodeCount);
				
				BaseDto unfinishedNodeCount = new BaseDto();
				unfinishedNodeCount.set(NodeSummary.SUMMARY_KEY,NodeSummary.SUMMARY_KEY_UNFINISHED_NODE_COUNT);
				unfinishedNodeCount.set(NodeSummary.SUMMARY_LABEL,NodeSummary.SUMMARY_LABEL_UNFINISHED_NODE_COUNT);
				unfinishedNodeCount.set(NodeSummary.SUMMARY_VALUE, ""+(allLeafNodes.size() - stastic.getFinishOk()));
				summarys.add(unfinishedNodeCount);
				
				nodeSummarys.add(nodeSummary);
			}
		}
		return nodeSummarys;
	}
	
//	@Override
//	public void bindPdf2JobInView(String viewUuid, List<Pair<String, String>> pdf2Jobs) throws Exception {
//		GlobalRelationshipView view = queryViewByUuid(viewUuid);
//		if(view == null)
//			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
//		getGlobalRelationshipRmiMgr().bindPdf2JobInView(view.getRdn(), pdf2Jobs);
//	}
	
	@Override
	public void bindPdf2JobInView(String viewUuid, String pdfId, String jobId) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		PDFMgr pdfMgr = getDCSAPIUtils().getPDFMgr();
		JobMgr jobMgr = getDCSAPIUtils().getJobMgr();
		String pdfName = null;
		String jobName = null;
		if (!CmnUtil.isStringEmpty(pdfId)) {
			PDF pdf = pdfMgr.getPDF(pdfId);
			if (null != pdf) {
				pdfName = pdf.getName();
			}
		}
		if (!CmnUtil.isStringEmpty(jobId)) {
			Job job = jobMgr.getJob(jobId);
			if (null != job) {
				jobName = job.getName();
			}
		}
		getGlobalRelationshipRmiMgr().bindPdf2JobInView(view.getRdn(), pdfId, jobId, pdfName, jobName);
	}

	@Override
	public void bindAllPdf2JobInView(String viewUuid, List<String> pdfIds, List<String> jobIds) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		//存放调度中pdf与job的关系
		Map<String, String> pdf2Job = new HashMap<>();
		//存放pdfId和pdfName的关系
		Map<String, String> pdf2Name = new HashMap<>();
		//存放jobId和jobName的关系
		Map<String, String> job2Name = new HashMap<>();
		JobMgr jobMgr = getDCSAPIUtils().getJobMgr();
		for (String jobId : jobIds) {
			Job job = jobMgr.getJob(jobId);
			job2Name.put(job.getID(), job.getName());
			List<PDF> pdfs = jobMgr.listAllPDFOfJob(jobId);
			for (PDF pdf : pdfs) {
				pdf2Job.put(pdf.getID(), jobId);
				pdf2Name.put(pdf.getID(), pdf.getName());
			}
		}
		if (CmnUtil.isCollectionEmpty(pdfIds)) {
			//获取全局血缘图中已导入的产线
			List<PdfLinkMo> pdfLinkMos = getGlobalRelationshipRmiMgr().queryPdfLinkInView(view.getRdn());
			for (PdfLinkMo pdfLinkMo : pdfLinkMos) {
				String jobId = pdf2Job.get(pdfLinkMo.getPdf());
				if (null != jobId) {
					//选择的调度中有对应的产线
					String pdfName = pdf2Name.get(pdfLinkMo.getPdf());
					String jobName = job2Name.get(jobId);
					getGlobalRelationshipRmiMgr().bindPdf2JobInView(view.getRdn(), pdfLinkMo.getPdf(), jobId, pdfName, jobName);
				}
			}
		} else {
			PDFMgr pdfMgr = getDCSAPIUtils().getPDFMgr();
			for (String pdfId : pdfIds) {
				PDF pdf = pdfMgr.getPDF(pdfId);
				String jobId = pdf2Job.get(pdf.getID());
				if (null != jobId) {
					//选择的调度中有对应的产线
					String pdfName = pdf2Name.get(pdf.getID());
					String jobName = job2Name.get(jobId);
					getGlobalRelationshipRmiMgr().bindPdf2JobInView(view.getRdn(), pdf.getID(), jobId, pdfName, jobName);
				}
			}
		}
	}

	@Override
	public void moveNodeToView(String viewUuid,List<String> nodeKeys)throws Exception{
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		getGlobalRelationshipRmiMgr().moveNode2View(view.getRdn(), nodeKeys);
		RelationshipViewMo bloodGraph = getGlobalRelationshipRmiMgr().queryGlobalBloodView(view.getRdn());
		getGlobalRelationshipRmiMgr().clearDirtyCache(bloodGraph.getRDN());
	}
	
	protected String getStatusName(Integer status) {
		if(status == null)
			return JobDto.s_STATUS_UNKNOWN;
		switch (status) {
		case JobDto.STATUS_UNKNOWN:
//			return JobDto.s_STATUS_UNKNOWN;
		case JobDto.STATUS_WAITING:
			return JobDto.s_STATUS_WAITING;
		case JobDto.STATUS_POOLING:
			return JobDto.s_STATUS_POOLING;
		case JobDto.STATUS_CHECKING:
			return JobDto.s_STATUS_CHECKING;
		case JobDto.STATUS_RUNNING:
			return JobDto.s_STATUS_RUNNING;
		case JobDto.STATUS_SUSPEND:
			return JobDto.s_STATUS_SUSPEND;
		case JobDto.STATUS_FINISH_OK:
			return JobDto.s_STATUS_FINISH_OK;
		case JobDto.STATUS_FINISH_FAILED:
			return JobDto.s_STATUS_FINISH_FAILED;
		case JobDto.STATUS_FINISH_TERMINATED:
			return JobDto.s_STATUS_FINISH_TERMINATED;
		case JobDto.STATUS_FINISH_IGNORE_FAIL:
			return JobDto.s_STATUS_FINISH_IGNORE_FAIL;
//		case JobDto.STATUS_STOP_INSIDE:
//			return JobDto.STATUS_STOP_INSIDE;
		default:
			return JobDto.s_STATUS_WAITING;
//			return JobDto.s_STATUS_UNKNOWN;
		}
	}
	
	@Override
	public GlobalFlowGraphStatus queryNodeStatus(String uuid) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			return null;
		//判断一下是否有绑定运行产线，没有的话就不查询了
		List<PdfLinkMo> pdfLinks = getGlobalRelationshipRmiMgr().queryPdfLinkInView(view.getRdn());
		List<String> jobIds = new ArrayList<>();
		for (PdfLinkMo pdfLinkMo : pdfLinks) {
			if (!StringUtils.isEmpty(pdfLinkMo.getJob())) {
				jobIds.add(pdfLinkMo.getJob());
			}
		}
		if (jobIds.size() == 0) {
			return new GlobalFlowGraphStatus();
		}
//			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", uuid));
		RelationshipViewMo viewMo = convert2ViewMo(view);
		Map<String,Integer> status = getGlobalRelationshipRmiMgr().queryAllNodeStatusInRelationshipView(viewMo,viewMo);
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		FlowGraph rootLayerGraph = cache.drillInView(view.getRdn(),false);
		Set<String> rootNodes = rootLayerGraph.getAllNodes();
		List<NodeSummary> nodeSummmarys = queryNodeSummary(view.getUuid(), new ArrayList<>(rootNodes));
		Map<String,NodeSummary> nodeSummmaryMap = nodeSummmarys.stream().collect(Collectors.toMap(NodeSummary::getKey, v->v));
		Set<FlowNodeStatus> allNodeStatus = new LinkedHashSet<>();
		for(String nodeKey : cache.getAllNodes().keySet()) {
			String statusName = getStatusName(status.get(nodeKey));
			FlowNodeStatus nodeStatus = new FlowNodeStatus();
			nodeStatus.setKey(nodeKey);
			nodeStatus.setStatus(statusName);
			allNodeStatus.add(nodeStatus);
		}
		for(String viewKey : cache.getAllViews().keySet()) {
			Set<String> nodeKeys = cache.getViewTree().getAllLeafNodes(viewKey);
			Set<Integer> nodeStatusInView = new HashSet<>();
			for(String nodeKey : nodeKeys) {
				if(status.get(nodeKey) != null) {
					nodeStatusInView.add(status.get(nodeKey));
				}
			}
			int viewCmbStatus = DFPatternMgr.getInstance().calcMultipleStatus(Job.STATUS_WAITING,
					new ArrayList<>(nodeStatusInView));
			String viewCmbStatusName = getStatusName(viewCmbStatus);
			FlowNodeStatus nodeStatus = new FlowNodeStatus();
			nodeStatus.setKey(viewKey);
			nodeStatus.setStatus(viewCmbStatusName);
			if(rootNodes.contains(viewKey)) {
				NodeSummary summary = nodeSummmaryMap.get(viewKey);
				if(summary != null) {
					List<BaseDto> summaryRow = summary.getSummary();
					nodeStatus.setSummarys(summaryRow);
				}
			}
			allNodeStatus.add(nodeStatus);
		}
		
		GlobalFlowGraphStatus graphStatus = new GlobalFlowGraphStatus();
		graphStatus.setNodes(allNodeStatus);
		return graphStatus;
	}
	
	@Override
	public GlobalRelationShipViewStastic queryViewStastic(String uuid, String nodeKey) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(uuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", uuid));
		RelationshipViewMo viewMo = convert2ViewMo(view);
		RelationshipViewMo childView = getGlobalRelationshipRmiMgr().queryView(nodeKey);
		if(childView == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", nodeKey));
		GlobalRelationShipViewStastic sts = getGlobalRelationshipRmiMgr().queryStastic(viewMo,childView);
		return sts;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public FormDtoV2 queryNode(String nodeKey,String translator,String privilegeConfig) throws Exception {
		FlowNodeMo flowNode = getGlobalRelationshipRmiMgr().queryFlowNode(nodeKey);
		if(flowNode == null)
			throw new Exception(GdfUtil.getString("Flow Node %s is not exist!",nodeKey));
		String pdcId = flowNode.getDependPDC();
		IPdcService pdcMgr = getApiUtils().getMgr(IPdcService.class);
		PdcDto pdc = pdcMgr.queryPdc(pdcId);
		pdc.setExtField("key", nodeKey);
		EntityTranslator<PdcDto> translatorIntf = null;
		if(CmnUtil.isStringEmpty(translator)) {
			translatorIntf = new PdcDtoTranslator();
		}else {
			Class<EntityTranslator<PdcDto>> clazz = ETLUtil.loadClass(translator);
			translatorIntf = clazz.newInstance();
		}
		ETLContext context = new ETLContext();
		translatorIntf.setContext(context);
		Map<String,Object> data = (Map<String, Object>) translatorIntf.fromEntity(pdc);
		FormDtoV2 form = new FormDtoV2();
		CdcDto cdc = getApiUtils().getMgr(ICdcService.class).queryCdcByPdc(pdc);
		ControllerDto controller = getWebConfigMgr().getPdcTableController(cdc.getId(), null, false, new HashMap<>());
		try(IJson json = IJsonService.get().getJson()){
			FormConfigDto config = new FormConfigDto();
			Type type = new TypeToken<List<Map<String,Object>>>(){}.getType();
			List<ActionDefineDto> actionDtos = controller.getActions().stream().filter(v->v.getType().equals("update")).collect(Collectors.toList());
			List<Map<String,Object>> actions = json.forceCastByType(type, actionDtos);
			config.setActions(actions);
			config.setActionsOverride(true);
			List<Map<String,Object>> fields = json.forceCastByType(type, controller.getFields());
			config.setFields(fields);
			config.setFieldsOverride(true);
			List<Map<String,Object>> layout = json.forceCastByType(type, controller.getLayout());
			config.setLayout(layout);
			form.setConfig(config);
		}
		form.setData(data);
		return form;
	}
	
	@Override
	public FlowNode updateNode(Map<String,Object> data,String translator)throws Exception{
		EntityTranslator<PdcDto> translatorIntf = null;
		if(CmnUtil.isStringEmpty(translator)) {
			translatorIntf = new PdcDtoTranslator();
		}else {
			Class<EntityTranslator<PdcDto>> clazz = ETLUtil.loadClass(translator);
			translatorIntf = clazz.newInstance();
		}
		ETLContext context = new ETLContext();
		translatorIntf.setContext(context);
		String nodeKey = (String) data.get(FlowNode.Key);
		PdcDto pdc = translatorIntf.toEntity(data);
		IPdcService pdcMgr = getApiUtils().getMgr(IPdcService.class);
		pdc = pdcMgr.updatePdc(pdc);
		FlowNodeMo mo = getGlobalRelationshipRmiMgr().queryFlowNode(nodeKey);
		if(mo != null)
			return GlobalRelationshipMoMgr.getInstance().convert2FlowNode(mo);
		return null;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public MultiPageResultDto<FlowNode> queryNodePage(String viewUuid,List<Condition> condition, List<OrderBy> orderBy, int pageNo,
			int pageSize) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		NameValuePair nvQuery = Condition.toNameValuePair(condition);
		OrderByPair order = OrderBy.toOrderBy(orderBy);
		int startPos = (pageNo -1)* pageSize;
		return getGlobalRelationshipRmiMgr().queryFlowNodePageInView(view.getRdn(), nvQuery, order, startPos, pageSize);
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public MultiPageResultDto<FlowNode> queryNodePageByPdcIds(List<String> pdcIds) throws Exception {
		if(CmnUtil.isCollectionEmpty(pdcIds))
			return new MultiPageResultDto<>();
		NameValuePair nvQuery = new InOPNameValue<>(FlowNodeMo.attr_DependPDC, pdcIds);
		List<FlowNodeMo> lstNode = getGlobalRelationshipRmiMgr().queryFlowNodeList(nvQuery, null, 0, Integer.MAX_VALUE);
		List<FlowNode> lst = BaseDtoUtil.getMe().transformObjects(lstNode, v->GlobalRelationshipMoMgr.convert2FlowNode(v));
		MultiPageResultDto<FlowNode> rs = new MultiPageResultDto<>();
		rs.setTableData(lst);
		rs.setTotal(lst.size());
		return rs;
	}

	@Override
	public String debugPdc(PdcDto pdc, String selectAgent, long opTimeMills, String attrName, boolean destroyRpc)
			throws Exception {
		return getPdcService().debugPdc(pdc, selectAgent, opTimeMills, attrName, destroyRpc);
	}

	@Override
	public ProgressDetail queryCurrentRuntimeInfo(String pollerUuid) throws Exception {
		return getPdcService().getCurrentRuntimeInfo(pollerUuid);
	}

	@Override
	public void terminateRemoteDebug(String uuid) throws Exception {
		getPdcService().terminateRemoteDebug(uuid);
		
	}

	@Override
	public List<AgentStatusDto> queryAvaliableAgent() throws Exception {
		List<AgentStatusDto> agentStatuses = getAgentService().queryAllAgentStatus().getTableData();
		List<AgentStatusDto> avaliableAgent = new ArrayList<>();
		// 过滤不在线及失联代理
		for (AgentStatusDto agentStatus : agentStatuses) {
			if (!agentStatus.isOnline() || !agentStatus.isConnected()) {
				continue;
			}
			avaliableAgent.add(agentStatus);
		}
		return avaliableAgent;
	}

	@Override
	public PdcSqlMappingDto queryPDCSqlMapping(String pdcId) throws Exception {
		PdcDto pdc = getPdcService().queryPdc(pdcId);
		if(pdc == null)
			throw DCExceptionUtils.pdcNotFound(pdcId);
		return getPdcService().querySqlMapping(pdcId);
	}

	@Override
	public MultiPageResultDto<List<BaseDto>> testBuildSql(String id, String key, String sql, int pageSize)
			throws Exception {
		PdcDto pdc = getPdcService().queryPdc(id);
		if(pdc == null)
			throw DCExceptionUtils.pdcNotFound(id);
		PdcSqlMappingDto sqlMapping = getPdcService().querySqlMapping(id);
		Set<ViewMetaNodeDto> nodes = sqlMapping.getNodes();
		ViewMetaNodeDto viewMeta = null;
		for(ViewMetaNodeDto meteNode : nodes) {
			if(ToolUtilities.isStringEqual(meteNode.getKey(), key)) {
				viewMeta = meteNode;
			}
		}
		if(viewMeta == null)
			throw new InputValidationException(AppRes.getStringWithParam("View %s is not exist!",key));
		Map<String,String> labelMap = new HashMap<>();
		for(ViewFieldDto colField :viewMeta.getFields()) {
			labelMap.put(colField.getFieldName().toUpperCase(), colField.getLabel());
		}
		
		Pair<List<JdbcMetaInfo>, List<List<String>>> pair = getPdcService().testQuerySql(pdc, key, sql, pageSize);
		List<JdbcMetaInfo> metas = pair.left;
		List<List<String>> datas = pair.right;
		
		List<BaseDto> rows = new ArrayList<>();
		for(List<String> data : datas){
			BaseDto row = new BaseDto();
			for(int i = 0;i<data.size();i++){
				JdbcMetaInfo meta = metas.get(i);
				String value = data.get(i);
				row.put(meta.getName(), value);
			}
			rows.add(row);
		}
		
		MultiPageResultDto rs = new MultiPageResultDto<>();
		List<FieldDefineDto> fields = new ArrayList<>();
		for(JdbcMetaInfo meta : metas){
			WebTextField field = new WebTextField(meta.getName(), labelMap.get(meta.getName().toUpperCase()));
			fields.add(field.getFieldDefine());
		}
		rs.setTableData(rows);
		rs.setFields(fields);
		rs.setTotal(rows.size());
		return rs;
	}

	@Override
	public String queryBuildSql(String id, String key, Long opTime) throws Exception {
		if(opTime == null)
			opTime = System.currentTimeMillis();
		PdcDto pdc = getPdcService().queryPdc(id); 
		if(pdc == null)
			throw DCExceptionUtils.pdcNotFound(id);
		String sql = getPdcService().buildSqlOfSqlPdc(pdc, key, opTime,true);
		return sql;
	}

	@Override
	public void syncAllPdf2RelationShipView(String viewUuid) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		List<PdfLinkMo> pdfLinkMos = getGlobalRelationshipRmiMgr().queryPdfLinkInView(view.getRdn());
		for (PdfLinkMo pdfLinkMo : pdfLinkMos) {
				getGlobalRelationshipRmiMgr().synchronizePdf2RelationShipView(view.getRdn(), pdfLinkMo.getPdf());
		}
	}

	@Override
	public MultiPageResultDto<FlowNode> queryFlowNodeInView(String viewUuid, String filtersKeyWord, List<Condition> filters, List<OrderBy> orderBy, int pageNo, int pageSize) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		int startPos = (pageNo - 1) * pageSize;
		NameValuePair nvQuery = Condition.toNameValuePair(filters);
		if (!CmnUtil.isStringEmpty(filtersKeyWord)) {
			NameValuePair fullContetNvl = getNodeContetNvl(filtersKeyWord);
			if (nvQuery == null) {
				nvQuery = fullContetNvl;
			} else {
				nvQuery = MDUtil.newAndNv(nvQuery, fullContetNvl);
			}
		}
		return getGlobalRelationshipRmiMgr().queryFlowNodeList(view.getRdn(), nvQuery, null, startPos, pageSize);
	}

	public NameValuePair getNodeContetNvl(String filtersKeyWord) {
		filtersKeyWord = ToolUtilities.replaceAll(filtersKeyWord, "*", "%");
		List<NameValuePair> nvs = new ArrayList<NameValuePair>();
		nvs.add(new LikeNameValuePair("name", "%" + filtersKeyWord + "%", true));
		nvs.add(new LikeNameValuePair("label", "%" + filtersKeyWord + "%", true));
		NameValuePair<?> filter = new OrOPNameValue(nvs);
		return filter;
	}

	@Override
	public GlobalFlowGraph expandSourceAndTarget(String viewUuid, String key) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		FlowGraph nodeGraph = cache.getNodeGraph();
		GlobalFlowGraph graph = new GlobalFlowGraph();
		Set<FlowNode> nodes = new HashSet<>();
		Set<FlowLink> links = new HashSet<>();
		nodes.add(cache.getNode(key));
		Set<String> sourceNodes = nodeGraph.getSource(key);
		for (String sourceNode : sourceNodes) {
			nodes.add(cache.getNode(sourceNode));
			FlowLink flowLink = new FlowLink(sourceNode, key, "");
			links.add(flowLink);
		}
		Set<String> targetNodes = nodeGraph.getTarget(key);
		for (String targetNode : targetNodes) {
			nodes.add(cache.getNode(targetNode));
			FlowLink flowLink = new FlowLink(key, targetNode, "");
			links.add(flowLink);
		}
		graph.setNodes(nodes);
		graph.setLinks(links);
		return graph;
	}

	@Override
	public GlobalFlowGraph expandSource(String viewUuid, String key) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		FlowGraph nodeGraph = cache.getNodeGraph();
		GlobalFlowGraph graph = new GlobalFlowGraph();
		Set<FlowNode> nodes = new HashSet<>();
		Set<FlowLink> links = new HashSet<>();
		nodes.add(cache.getNode(key));
		Set<String> sourceNodes = nodeGraph.getSource(key);
		for (String sourceNode : sourceNodes) {
			nodes.add(cache.getNode(sourceNode));
			FlowLink flowLink = new FlowLink(sourceNode, key, "");
			links.add(flowLink);
		}
		graph.setNodes(nodes);
		graph.setLinks(links);
		return graph;
	}

	@Override
	public GlobalFlowGraph expandTarget(String viewUuid, String key) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		FlowGraph nodeGraph = cache.getNodeGraph();
		GlobalFlowGraph graph = new GlobalFlowGraph();
		Set<FlowNode> nodes = new HashSet<>();
		Set<FlowLink> links = new HashSet<>();
		nodes.add(cache.getNode(key));
		Set<String> targetNodes = nodeGraph.getTarget(key);
		for (String targetNode : targetNodes) {
			nodes.add(cache.getNode(targetNode));
			FlowLink flowLink = new FlowLink(key, targetNode, "");
			links.add(flowLink);
		}
		graph.setNodes(nodes);
		graph.setLinks(links);
		return graph;
	}

	@Override
	public GlobalFlowGraph expandAllSource(String viewUuid, String key) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		FlowGraph nodeGraph = cache.getNodeGraph();
		GlobalFlowGraph graph = new GlobalFlowGraph();
		Set<FlowNode> nodes = new HashSet<>();
		Set<FlowLink> links = new HashSet<>();

		Set<String> allSrcNodes = new HashSet<>();
		Set<String> srcNodes = nodeGraph.getSource(key);
		for (String srcNode : srcNodes) {
			FlowLink link = new FlowLink(srcNode, key, "");
			links.add(link);
		}
		while (!ToolUtilities.isCollectionEmpty(srcNodes)) {
			Set<String> tmpNodes = new HashSet<>();
			for (String srcNode : srcNodes) {
				if (!allSrcNodes.contains(srcNode)) {
					Set<String> srcSrcNodes = nodeGraph.getSource(srcNode);
					if (srcSrcNodes != null) {
						tmpNodes.addAll(srcSrcNodes);
						for (String srcSrcNode : srcSrcNodes) {
							FlowLink link = new FlowLink(srcSrcNode, srcNode, "");
							links.add(link);
						}
					}
				}
			}
			allSrcNodes.addAll(srcNodes);
			tmpNodes.removeAll(allSrcNodes);
			srcNodes = tmpNodes;
		}
		nodes.add(cache.getNode(key));
		for (String srcNode : allSrcNodes) {
			nodes.add(cache.getNode(srcNode));
		}
		graph.setNodes(nodes);
		graph.setLinks(links);
		return graph;
	}

	@Override
	public GlobalFlowGraph expandAllTarget(String viewUuid, String key) throws Exception {
		GlobalRelationshipView view = queryViewByUuid(viewUuid);
		if(view == null)
			throw new Exception(AppRes.getStringWithParam("View %s is not exist!", viewUuid));
		GlobalFlowCache cache = getGlobalRelationshipRmiMgr().queryGlobalFlowCache(view.getRdn());
		FlowGraph nodeGraph = cache.getNodeGraph();
		GlobalFlowGraph graph = new GlobalFlowGraph();
		Set<FlowNode> nodes = new HashSet<>();
		Set<FlowLink> links = new HashSet<>();

		Set<String> allDstNodes = new HashSet<>();
		Set<String> dstNodes = nodeGraph.getTarget(key);
		for (String dstNode : dstNodes) {
			FlowLink link = new FlowLink(key, dstNode, "");
			links.add(link);
		}
		while (!ToolUtilities.isCollectionEmpty(dstNodes)) {
			Set<String> tmpNodes = new HashSet<>();
			for (String dstNode : dstNodes) {
				if (!allDstNodes.contains(dstNode)) {
					Set<String> dstDstNodes = nodeGraph.getTarget(dstNode);
					if (dstDstNodes != null) {
						tmpNodes.addAll(dstDstNodes);
						for (String dstDstNode : dstDstNodes) {
							FlowLink link = new FlowLink(dstNode, dstDstNode, "");
							links.add(link);
						}
					}
				}
			}
			allDstNodes.addAll(dstNodes);
			tmpNodes.removeAll(allDstNodes);
			dstNodes = tmpNodes;
		}
		nodes.add(cache.getNode(key));
		for (String srcNode : allDstNodes) {
			nodes.add(cache.getNode(srcNode));
		}
		graph.setNodes(nodes);
		graph.setLinks(links);
		return graph;
	}
}
