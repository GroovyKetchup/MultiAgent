package cell.gdf.dashboard.impl;

import java.util.ArrayList;
import java.util.List;

import com.kwaidoo.dc.BaseSecurityMgr;
import com.kwaidoo.dc.GdfUtil;
import com.kwaidoo.dc.view.dto.ViewAngleDto;
import com.kwaidoo.ms.tool.ToolUtilities;

import cell.gdf.dashboard.IDashboardService;
import cell.gdf.view.ICustomViewService;

public class CDashboardService extends BaseSecurityMgr implements IDashboardService{

	private final static List<String> filterLst = ToolUtilities.newArrayList(GdfUtil.getString("qc_monitor", null),GdfUtil.getString("case", null),GdfUtil.getString("qc_check", null),GdfUtil.getString("qc_adjust", null),GdfUtil.getString("process", null),"SQL工具");
	
	
	private ICustomViewService getCustomViewService() throws Exception {
		return getApiUtils().getMgr(ICustomViewService.class);
	}
	
	@Override
	public List<ViewAngleDto> queryViewAngleList() throws Exception {
		List<ViewAngleDto> lst = new ArrayList<>();
		List<ViewAngleDto> dataLst = getCustomViewService().queryViewAngleList().getTableData();
		for(ViewAngleDto dto : dataLst) {
			if(!filterLst.contains(dto.getName()))
				lst.add(dto);
		}
		return lst;
	}

	@Override
	public ViewAngleDto createViewAngel(ViewAngleDto data) throws Exception {
		return getCustomViewService().createViewAngle(data);
	}

	@Override
	public ViewAngleDto updateViewAngle(ViewAngleDto data) throws Exception {
		String name = data.getName();
		ViewAngleDto view = getCustomViewService().queryViewAngle(data.getId());
		view.setName(name);
		return getCustomViewService().updateViewAngle(view);
	}

	@Override
	public void deleteViewAngleDto(String id) throws Exception {
		getCustomViewService().deleteViewAngle(id);
	}
	
	@Override
	public ViewAngleDto queryViewAngle(String id) throws Exception {
		return getCustomViewService().queryViewAngle(id);
	}
	
	

}
