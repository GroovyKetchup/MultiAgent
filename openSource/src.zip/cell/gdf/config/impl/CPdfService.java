package cell.gdf.config.impl;

import cell.gdf.config.IPdcService;
import cell.gdf.config.IPdfService;
import cell.gdf.dc.tree.GDFTreeMgr;
import cell.gdf.design.ICdcService;
import cmn.util.FlowLink;
import com.kwaidoo.dc.BaseDtoUtil;
import com.kwaidoo.dc.BaseSecurityMgr;
import com.kwaidoo.dc.GdfConst;
import com.kwaidoo.dc.concrete.dto.AttributeDto;
import com.kwaidoo.dc.concrete.dto.CdcDto;
import com.kwaidoo.dc.concrete.dto.CdfDto;
import com.kwaidoo.dc.config.*;
import com.kwaidoo.dc.config.dto.*;
import com.kwaidoo.dc.exception.DcChecker;
import com.kwaidoo.dc.exception.GDFErrorHandler;
import com.kwaidoo.dc.story.dto.StoryDto;
import com.kwaidoo.dc.tree.mgr.ProductDesign;
import com.kwaidoo.dc.tree.node.GdfTreeConst;
import com.kwaidoo.dc.tree.node.TreeNode;
import com.kwaidoo.ms.tool.CmnUtil;
import com.kwaidoo.ms.tool.ToolUtilities;
import com.leavay.common.util.DNParser;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dc.design.CDCCustomConfig;
import com.leavay.dc.design.CDF;
import com.leavay.dc.develop.*;
import com.leavay.dc.develop.impl.PDFFlowCache;
import com.leavay.dc.exception.DCExceptionUtils;
import com.leavay.dc.exception.InputValidationException;
import com.leavay.dc.resource.AppRes;
import com.leavay.dc.security.PrivilegeConst;
import com.leavay.dc.security.PrivilegeMatrix;
import com.leavay.dc.setting.UserIcon;
import com.leavay.dc.tools.DAGParser;
import com.leavay.dc.tools.DCUtils;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.mgr.DCDataCacheMgr;
import com.leavay.dfc.mgr.DFlowPattern.*;
import com.leavay.dfc.mgr.dcsutil;
import com.leavay.dfc.mgr.dfcIntf;
import com.leavay.model.exception.McException;
import com.leavay.model.exception.McValidationException;
import com.leavay.model.inf.ManagedData;
import com.leavay.model.inf.filter.NameValuePair;
import com.leavay.model.inf.sort.OrderByPair;
import com.leavay.model.mgr.MDUtil;
import com.leavay.ms.dcs.dto.RowDataDto;
import modeldef.com.leavay.dc.*;
import modeldef.com.leavay.dfc.mda.DFP;
import modeldef.com.leavay.dfc.mda.PIMBase;
import modeldef.com.leavay.dfc.mda.PSMRef;
import modeldef.com.leavay.dfc.mda.PsmMirror;
import web.dto.MultiPageResultDto;
import web.dto.Pair;

import java.rmi.RemoteException;
import java.util.*;
import java.util.stream.Collectors;

public class CPdfService extends BaseSecurityMgr implements IPdfService{
	
	private PDFMgr getPDFMgr() throws Exception {
		return getDCSAPIUtils().getPDFMgr();
	}
	private PDCMgr getPDCMgr() throws Exception {
		return getDCSAPIUtils().getPDCMgr();
	}
	private ICdcService getCdcMgr() throws Exception {
		return getApiUtils().getMgr(ICdcService.class);
	}	
	
	private IPdcService getPdcMgr() throws Exception {
		return getApiUtils().getMgr(IPdcService.class);
	}
	
	private GDFTreeMgr getGDFTreeMgr() throws Exception {
		return getApiUtils().getMgr(GDFTreeMgr.class);
	}
	
	
	private com.kwaidoo.dc.tree.mgr.GDFTreeMgr getTreeMgr() throws Exception {
		return getDCSAPIUtils().getGDFTreeMgr();
	}
	
	@Override
	public  PdfDto createPdf(CdfDto cdf, String pdfName) throws Exception {
		CDF _cdf = fromDto(cdf, CDF.class);
		PDF _pdf = getPDFMgr().createPDF(_cdf, pdfName);
		return toDto(_pdf);
	}

	@Override
	public PdfDto createPdf(ProductDesign pd, String pdfName) throws Exception {
		PDF _pdf = getPDFMgr().createPDF(pd, pdfName);
		return toDto(_pdf);
	}

	@Override
	public PdcDto createMirrorPdf(String pdfId, String targetPdfId) throws Exception {
		PDC _pdc = getPDFMgr().createMirrorPDF(pdfId, targetPdfId);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdfDto updatePdf(PdfDto pdf) throws Exception {
		DcChecker.checkAuthorized(getSessionKey(), PrivilegeConst.PDF_CREATE_UPDATE, pdf.getSmUserId(),
				pdf.getSmDomainId());
		PdfDto orgPdf = queryPdf(pdf.getId());
		DFP dfp = fromDto(pdf, DFP.class);
		dfp = dfcutil.getDfcIntf().updateDFPattern(dfp);
		PdfDto changePdf = toDto(dfp, PdfDto.class);
		info(dfp.getRDN(), dfp.getName(), "",orgPdf,changePdf);
		return toDto(dfp, PdfDto.class);
	}
	
	public PdfFlowDto queryPdfFlow(String id)throws Exception{
		PdfDto pdf = queryPdf(id);
		if(pdf == null)
			return null;
		DFPCache cache = dfcutil.getDfcIntf().getDfpCache(id);
		if(cache == null)
			return null;
		PdfFlowDto flow = new PdfFlowDto();
		flow.setId(id);
		flow.setName(pdf.getName());
		flow.setSmDomainId(pdf.getSmDomainId());
		flow.setSmUserId(pdf.getSmUserId());
		Set<PdfNodeDto> nodes = new LinkedHashSet<>();
		Set<cmn.util.FlowLink> links = new LinkedHashSet<>();
		for(MOKey moKey : cache.getAllNodes()) {
			PdfNodeDto node = new PdfNodeDto();
			node.setKey(moKey.getRdn());
			node.setName(moKey.getName());
			CDCCustomConfig customCfg = null;
			if(moKey instanceof PsmRefKey) {
				ManagedData mo = dfcutil.getDfcIntf().getMo(((PsmRefKey) moKey).getRelatedPSM());
				String cdcName = DCUtils.getModelName(mo.getCLASS());
				customCfg = dcsutil.getDcsIntf().getCdcCustomConfigCache(cdcName);
				if(customCfg != null) {
					String label = mo.getAttribute(customCfg.getDisplayAttr()).toString();
					if(CmnUtil.isStringEmpty(label)) {
						label = moKey.getName();
					}
					node.setLabel(label);
				}
				node.setPdcType(PdfNodeDto.PDC_TYPE_REFERENCE);
			}else {
				ManagedData mo = dfcutil.getDfcIntf().getMo(moKey.getRdn());
				String cdcName = DCUtils.getModelName(mo.getCLASS());
				node.setKey(moKey.getRdn());
				customCfg = dcsutil.getDcsIntf().getCdcCustomConfigCache(cdcName);
				if(customCfg != null) {
					String label = mo.getAttribute(customCfg.getDisplayAttr()).toString();
					if(CmnUtil.isStringEmpty(label)) {
						label = moKey.getName();
					}
					node.setLabel(label);
				}
				node.setPdcType(PdfNodeDto.PDC_TYPE_INSTANCE);
			}
			if(customCfg != null)
				node.setIcon(customCfg.getDisplayIcon());
			node.setCategory(PdfNodeDto.CATEGORY_PDC);
			nodes.add(node);
		}
		flow.setNodes(nodes);
		flow.setLinks(links);
		return flow;
	}
	
	@Override
	public PdfFlowDto queryPdfFlow(String pdfId, String displayMode) throws Exception {
//		PDFFlow pdfFlow = getPDFMgr().getPDFFlow(pdfId, displayMode);
//		return toDto(pdfFlow, PdfFlowDto.class);
		PdfDto pdf = queryPdf(pdfId);
		if(pdf == null)
			return null;
		if(!PdfFlowDto.isSummaryDisplayMode(displayMode)){
			return queryPdfFlowByDetailMode(pdf);
		}else{
			return queryPdfFlowBySummaryMode(pdf);
		}
	}
	
	private PdfFlowDto queryPdfFlowByDetailMode(PdfDto pdf) throws Exception{
		PdfFlowDto flow = new PdfFlowDto();
		flow.setId(pdf.getId());
		flow.setDisplayMode(GdfConst.DISPLAY_MODE_DETAIL);
		flow.setName(pdf.getName());
		flow.setSmDomainId(pdf.getSmDomainId());
		flow.setSmUserId(pdf.getSmUserId());
		DFPCache dfpCache = dfcutil.getDfcIntf().getDfpCache(pdf.getId());
		DAGParser dag = dcsutil.getDcsIntf().getPDCFlowCacheWithRef(pdf.getId());
		for(String pdcId : dag.getAllNodes()){
			MOKey moKey = dfpCache.getNode(pdcId);
			PdfNodeDto node = toPdfNodeDto(moKey);
			if(node != null)
				flow.addNode(node);
		}
		for(FlowLink link : dag.getAllLinks()){
			flow.addLink(link.getFrom(), link.getTo());
		}
		return flow;
	}
	
	private PdfFlowDto queryPdfFlowBySummaryMode(PdfDto pdf) throws Exception{
		PdfFlowDto flow = new PdfFlowDto();
		flow.setId(pdf.getId());
		flow.setDisplayMode(GdfConst.DISPLAY_MODE_SUMMARY);
		flow.setName(pdf.getName());
		flow.setSmDomainId(pdf.getSmDomainId());
		flow.setSmUserId(pdf.getSmUserId());
		DFPCache dfpCache = dfcutil.getDfcIntf().getDfpCache(pdf.getId());
		DAGParser dag = dcsutil.getDcsIntf().getPDFViewFlow(pdf.getId(), null,true);
		Set<PdfNodeDto> nodes = new LinkedHashSet<>();
		for(String nodeKey : dag.getAllNodes()){
			ManagedData mo = dfcutil.getDfcIntf().getMo(nodeKey);
			if(mo == null)
				continue;
			PdfNodeDto node = null;
			if(mo instanceof PDFViewMo){
				PdfViewDto view = toDto(mo, PdfViewDto.class);
				node = toPdfNodeDto(view);
			}else{
				node = toPdfNodeDto(dfpCache.getNode(nodeKey));
			}
			if(node != null)
				nodes.add(node);
		}
		for(FlowLink link : dag.getAllLinks()){
			flow.addLink(link.getFrom(), link.getTo());
		}
		return flow;
	}
	
	private PdfNodeDto toPdfNodeDto(PdfViewDto view) {
		PdfNodeDto node = new PdfNodeDto();
		node.setKey(view.getId());
		node.setName(view.getName());
		node.setLabel(view.getName());
		node.setCategory(PdfNodeDto.CATEGORY_PDFVIEW);
		node.setGroup(view.getParentViewId());
		node.setImage("/ebook/api/usericon?action=downloadByName&name=" + UserIcon.ICON_PDF_SEGMENT);
		return node;
	}
	
	private PdfNodeDto toPdfNodeDto(MOKey moKey) throws RemoteException, McValidationException, McException, Exception {
		PdfNodeDto node = new PdfNodeDto();
		node.setKey(moKey.getRdn());
		node.setName(moKey.getName());
		CDCCustomConfig cdcCustomConfig = null;
		if(moKey instanceof PsmRefKey) {
			ManagedData mo = dfcutil.getDfcIntf().getMo(((PsmRefKey) moKey).getRelatedPSM());
			String cdcName = DCUtils.getModelName(mo.getCLASS());
			cdcCustomConfig = dcsutil.getDcsIntf().getCdcCustomConfigCache(cdcName);
			String label = mo.getAttribute(cdcCustomConfig.getDisplayAttr()).toString();
			if(CmnUtil.isStringEmpty(label)) {
				label = moKey.getName();
			}
			node.setLabel(label);
			node.setPdcType(PdfNodeDto.PDC_TYPE_REFERENCE);
		}else {
			ManagedData mo = dfcutil.getDfcIntf().getMo(moKey.getRdn());
			String cdcName = DCUtils.getModelName(mo.getCLASS());
			cdcCustomConfig = dcsutil.getDcsIntf().getCdcCustomConfigCache(cdcName);
			String label = mo.getAttribute(cdcCustomConfig.getDisplayAttr()).toString();
			if(CmnUtil.isStringEmpty(label)) {
				label = moKey.getName();
			}
			node.setLabel(label);
			node.setPdcType(PdfNodeDto.PDC_TYPE_INSTANCE);
		}
		node.setIcon(cdcCustomConfig.getDisplayIcon());
		node.setCategory(PdfNodeDto.CATEGORY_PDC);
		node.setImage("/ebook/api/usericon?action=downloadByName&name=" + node.getIcon());
//		node.setGroup(group);
		return node;
	}
	
	@Override
	public PdfFlowDto updatePdfFlow(PdfFlowDto pdfFlow,String updateOption)throws Exception {
		//判断引用节点前面是否有依赖
		Set<FlowLink> links = pdfFlow.getLinks();
		Map<String, String> toMap = new HashMap<>();
		for (FlowLink link : links) {
			toMap.put(link.getTo(), "1");
		}
		for (PdfNodeDto node : pdfFlow.getNodes()) {
			if(node.isReference() && toMap.get(node.getKey()) != null) {
				throw new InputValidationException(AppRes.getStringWithParam("Reference Node %s Can Not Depend!", node.getLabel()));
			}
		}
		//orginfo
		PdfFlowDto orgPdfFlow = queryPdfFlow(pdfFlow.getId());
		DcChecker.checkPDFNotNull(orgPdfFlow);
		DcChecker.checkAuthorized(getSessionKey(), PrivilegeConst.PDF_CREATE_UPDATE, orgPdfFlow.getSmUserId(),
				orgPdfFlow.getSmDomainId());
		dfcIntf srv = dfcutil.getDfcIntf();
		DFPCache oldDfpCache = srv.getDfpCache(pdfFlow.getId());
		Map<String, MOKey> oldMOKeyMap = new HashMap<>();
		for (MOKey moKey : oldDfpCache.getAllNodes()) {
			if (moKey instanceof PSMKey) {
				oldMOKeyMap.put(moKey.getName(),moKey);
			} else if (moKey instanceof PsmRefKey) {
				oldMOKeyMap.put(moKey.getName(), moKey);
			}
		}
		DFPCache newDfpCache = new DFPCache();
		Set<String> removePdcGuids = new HashSet<>();
		Map<String,String> newPdcGuidMap = new HashMap<>();
		Map<String,String> oldPdcGuidMap = new HashMap<>();
		//添加新的PDC节点到缓存图中，这里只需要处理实例节点，引用节点单独添加处理
		for (PdfNodeDto node : pdfFlow.getNodes()) {
			if (oldDfpCache.containsKey(node.getKey())) {
				newDfpCache.putNode(oldDfpCache.getNode(node.getKey()));
				if (!PdfNodeDto.PDC_TYPE_REFERENCE.equals(node.getPdcType())) {
					ManagedData psmMo = srv.getMo(node.getKey());
					if (psmMo != null && !CmnUtil.isStringEmpty(PIMBase.getGUID(psmMo))) {
						newPdcGuidMap.put(node.getKey(), PIMBase.getGUID(psmMo));
					}
				}
			} else {
				ManagedData psmMo = srv.getMo(node.getKey());
				if(node.getPdcType().equals(PdfNodeDto.PDC_TYPE_REFERENCE)) {

					PsmRefKey refKey = (PsmRefKey)oldMOKeyMap.get(node.getName());
					if(refKey == null) {
						PSMRef psmRef = srv.createPsmRef(node.getKey(), pdfFlow.getId());
						refKey = DFPNodeUtil.createPsmRefKey(psmRef);
					}
					newDfpCache.putNode(refKey);
					newPdcGuidMap.put(refKey.getRdn(), PIMBase.getGUID(psmMo));


				}else {
					psmMo = (ManagedData) psmMo.clone();
					PIMBase.setParentDFP(psmMo, pdfFlow.getId());
					psmMo = srv.updatePSM(psmMo);
					PSMKey psmKey = DFPNodeUtil.createPsmKey(psmMo);
					newDfpCache.putNode(psmKey);
					newPdcGuidMap.put(psmKey.getRdn(),PIMBase.getGUID(psmMo));
				}
			}
		}
		for (MOKey oldKey : oldMOKeyMap.values()) {
			if (oldKey instanceof PsmRefKey) {
				continue;
			}
			ManagedData oldPsmMo = srv.getMo(oldKey.getRdn());
			if (oldPsmMo != null && !CmnUtil.isStringEmpty(PIMBase.getGUID(oldPsmMo))) {
				oldPdcGuidMap.put(oldKey.getRdn(), PIMBase.getGUID(oldPsmMo));
			}
		}
		//获取保存数据中要移除的pdc列表，这里只处理pdc实例的，引用的不需要删除pdc
		Set<String> newPdcGuids = new HashSet<>(newPdcGuidMap.values());
		for (String oldPdcGuid : oldPdcGuidMap.values()) {
			if (!newPdcGuids.contains(oldPdcGuid)) {
				removePdcGuids.add(oldPdcGuid);
			}
		}
		if(PdfFlowDto.isKeepPdcInstance(updateOption)) {
			getPDFMgr().movePdcOutOfPDF(pdfFlow.getId(), new ArrayList<>(removePdcGuids), true);
		}else if(PdfFlowDto.isKeepPdcAndReference(updateOption)) {
			getPDFMgr().movePdcOutOfPDF(pdfFlow.getId(), new ArrayList<>(removePdcGuids), false);
		}
		for (FlowLink link : pdfFlow.getLinks()) {
			MOKey srcMOKey = newDfpCache.getNode(link.getFrom());
			MOKey dstMOKey = newDfpCache.getNode(link.getTo());
			if(srcMOKey == null)
				continue;
			if(dstMOKey == null)
				continue;
			DfpLink dfpLink = new DfpLink(srcMOKey.getRdn(), dstMOKey.getRdn());
			newDfpCache.getLstLinks().add(dfpLink);
		}
		srv.saveDFPattern(pdfFlow.getId(), newDfpCache);
		pdfFlow = queryPdfFlow(pdfFlow.getId());
		info(pdfFlow.getId(), pdfFlow.getName(), "",orgPdfFlow,pdfFlow);
		return pdfFlow;
	}
	
	@Override
	public List<PdfNodeDto> importPdcNode(List<String> pdcList,String pdfId,String pdcType) throws Exception{
		List<PdfNodeDto> nodes = new ArrayList<>();
		boolean isReference = PdfNodeDto.isReference(pdcType);
		for(String pdcId : pdcList){
			ManagedData mo = dfcutil.getDfcIntf().getMo(pdcId);
			if(mo == null)
				continue;
			String cdcName = DCUtils.getModelName(mo.getCLASS());
			CDCCustomConfig customConfig = dcsutil.getDcsIntf().getCdcCustomConfigCache(cdcName);
			PdfNodeDto pdcNode = new PdfNodeDto();
			pdcNode.setKey(pdcId);
			String guid = PIMBase.getGUID(mo);
			String parentDfp = PIMBase.getParentDFP(mo);
			if(isReference){
				try{
					PSMRef psmRef = dfcutil.getDfcIntf().createPsmRef(pdcId, pdfId);
					pdcNode.setKey(psmRef.getRDN());
				}catch(Exception e){
					continue;
				}
			}else{
				if(!ToolUtilities.isStringEmpty(parentDfp) && !ToolUtilities.isStringEqual(parentDfp, pdfId)) {
					PdfDto parentPdf = queryPdf(parentDfp);
					throw new InputValidationException(AppRes.getStringWithParam("PDC %s is added in PDF %s!",guid,parentPdf.getName()));
				}
			}
//			pdcNode.setKey(pdcId);
			pdcNode.setName(guid);
			if (mo instanceof PsmMirror) {
				pdcNode.setIcon(UserIcon.ICON_MIRROR);
				pdcNode.setLabel(guid);
			} else if (mo instanceof DFP) {
				pdcNode.setIcon(UserIcon.ICON_PDF_REFERENCE);
				pdcNode.setIcon(guid);
			}else{
				String icon = customConfig.getDisplayIcon();
				String displayAttr = customConfig.getDisplayAttr();
				String label = mo.getAttribute(displayAttr).toString();
				if(CmnUtil.isStringEmpty(label)) {
					label = guid;
				}
				pdcNode.setIcon(icon);
				pdcNode.setLabel(label);
			}
			pdcNode.setPdcType(pdcType);
			nodes.add(pdcNode);
		}
		return nodes;
	}

	@Override
	public void updateSegmentOfPdf(String pdfId, List<String> deletePdcNames, List<FlowLink> deleteLinks,
			List<String> addPdcNames, List<String> addRefPdcNames, List<FlowLink> addLinks) throws Exception {
		dfcIntf srv = dfcutil.getDfcIntf();
		DFPCache cache = srv.getDfpCache(pdfId);
		Map<String, MOKey> oldMOKeyMap = new HashMap<>();
		for (MOKey moKey : cache.getAllNodes()) {
			if (moKey instanceof PSMKey) {
				oldMOKeyMap.put(moKey.getName(), moKey);
			} else if (moKey instanceof PsmRefKey) {
				oldMOKeyMap.put(moKey.getName(), moKey);
			}
		}
		//删除节点
		if(!CmnUtil.isCollectionEmpty(deletePdcNames)) {
			for(String deletePdcName : deletePdcNames) {
				MOKey key = oldMOKeyMap.get(deletePdcName);
				if(key != null)
					cache.removeNodeAndLinks(key.getRdn());
			}
		}
		//删除连线
		Map<String,DfpLink> linkMap = new HashMap<>();
		for(DfpLink link : cache.getLstLinks()) {
			linkMap.put(link.getSrc()+"->"+link.getDst(), link);
		}
		if(!CmnUtil.isCollectionEmpty(deleteLinks)) {
			for(FlowLink deleteLink : deleteLinks) {
				MOKey srcKey = cache.getNode(deleteLink.getFrom());
				MOKey dstKey = cache.getNode(deleteLink.getTo());
				if(srcKey != null && dstKey != null)
					linkMap.remove(srcKey.getRdn()+"->"+dstKey.getRdn());
			}
		}
		//添加节点
		if(!CmnUtil.isCollectionEmpty(addPdcNames)) {
			for(String pdcName : addPdcNames) {
				MOKey key = oldMOKeyMap.get(pdcName);
				if(key == null) {
					ManagedData psmMo = srv.getPSMByGUID(pdcName);
					if(psmMo != null) {
						psmMo = (ManagedData) psmMo.clone();
						PIMBase.setParentDFP(psmMo, pdfId);
						psmMo = srv.updatePSM(psmMo);
						PSMKey psmKey = DFPNodeUtil.createPsmKey(psmMo);
						oldMOKeyMap.put(pdcName, psmKey);
						cache.putNode(psmKey);
					}
				}
					
			}
		}
		if(!CmnUtil.isCollectionEmpty(addRefPdcNames)) {
			for(String refPdcName : addRefPdcNames) {
				MOKey key = oldMOKeyMap.get(refPdcName);
				if(key == null) {
					ManagedData psmMo = srv.getPSMByGUID(refPdcName);
					if(psmMo != null) {
						PsmRefKey refKey = (PsmRefKey) oldMOKeyMap.get(refPdcName);
						if (refKey == null) {
							PSMRef psmRef = srv.createPsmRef(psmMo.getRDN(), pdfId);
							refKey = DFPNodeUtil.createPsmRefKey(psmRef);
						}
						oldMOKeyMap.put(refPdcName, refKey);
						cache.putNode(refKey);
					}
				}
					
			}
		}
		//添加连线
		if(!CmnUtil.isCollectionEmpty(addLinks)) {
			for(FlowLink addLink : addLinks) {
				MOKey srcKey = oldMOKeyMap.get(addLink.getFrom());
				MOKey dstKey = oldMOKeyMap.get(addLink.getTo());
				if(srcKey != null && dstKey != null)
					linkMap.put(srcKey.getRdn()+"->"+dstKey.getRdn(), new DfpLink(srcKey.getRdn(), dstKey.getRdn()));
			}
		}
		cache.setLstLinks(new ArrayList<>(linkMap.values()));
		srv.saveDFPattern(pdfId, cache);
	}

	@Override
	public List<String> querySourcePdcGuids(String pdfId, String pdcGuid) throws Exception {
		return getPDFMgr().getSourcePdcNames(pdfId, pdcGuid);
	}

	@Override
	public PdfDto renamePdf(String pdfName, String newPdfName) throws Exception {
		//orginfo
		PdfDto orgPDF = queryPdfByName(pdfName);
		if (orgPDF == null)
			throw new Exception(AppRes.getStringWithParam("PDF %s is not exist!", pdfName));
		DcChecker.checkAuthorized(getSessionKey(), PrivilegeConst.PDF_CREATE_UPDATE, orgPDF.getSmUserId(),
						orgPDF.getSmDomainId());
		orgPDF.setName(newPdfName);
		return orgPDF;
	}

	@Override
	public PdfDto queryPdf(String pdfId) throws Exception {
		dfcIntf srv = dfcutil.getDfcIntf();
		ManagedData mo = srv.getMo(pdfId);
		if(!(mo instanceof DFP)){
			return null;
		}
		DFP dfp = (DFP)mo;
		if (dfp != null)
//				&& PrivilegeMatrix.getInstance().canRead(getSessionKey(), dfp.getSMUserID(), dfp.getSMDomainID()))
			return toDto(dfp, PdfDto.class);
		return null;
	}

	@Override
	public MultiPageResultDto<PdfDto> queryPdfList(List<String> pdfIds) throws Exception {
		List<PdfDto> pdfLst = new ArrayList<>();
		for(String pdfId : pdfIds){
			PdfDto pdf = queryPdf(pdfId);
			if(pdf != null)
				pdfLst.add(pdf);
		}
		MultiPageResultDto<PdfDto> rs = new MultiPageResultDto<>();
		rs.setTotal(pdfLst.size());
		rs.setTableData(pdfLst);
		return rs;
	}

	@Override
	public PdfNodeDto queryPdfNode(String pdfId,String nodeKey) throws Exception {
		ManagedData mo = dfcutil.getDfcIntf().getMo(nodeKey);
		if(mo == null)
			return null;
		if(mo instanceof PDFViewMo){
			PdfViewDto view = toDto(mo, PdfViewDto.class);
			return toPdfNodeDto(view);
		}else{
			DFPCache dfpCache = dfcutil.getDfcIntf().getDfpCache(pdfId);
			if(dfpCache == null)
				return null;
			MOKey moKey = dfpCache.getNode(nodeKey);
			if(moKey == null)
				return null;
			return toPdfNodeDto(moKey);
		}
	}

	@Override
	public List<PdfNodeDto> queryPdcNodeOfPdf(String pdfId) throws Exception {
		PdfFlowDto flow = queryPdfFlow(pdfId);
		if(flow == null)
			return Collections.emptyList();
		return new ArrayList<>(flow.getNodes());
	}
	
	@Override
	public PdcDto queryPdcInfoByNodeKey(String pdfId,String nodeKey) throws Exception {
		PdfNodeDto node = queryPdfNode(pdfId, nodeKey);
		if(node == null)
			return null;
		IPdcService pdcMgr = getApiUtils().getMgr(IPdcService.class);
		if(node.isPdc()) {
			PdcDto dto = pdcMgr.queryPdcByGuid(node.getName());
			dto.set(PdfNodeDto.Key, node.getKey());
			dto.set("pdfId", pdfId);
			return dto;
		}
		return null;
	}
	
	@Override
	public PdfNodeDto updatePdcInPdfFlow(PdcDto data) throws Exception {
		String pdfId = data.getString("pdfId",null);
		String nodeKey = data.getString(PdfNodeDto.Key, null);
		IPdcService pdcMgr = getApiUtils().getMgr(IPdcService.class);
		pdcMgr.updatePdc(data);
		return queryPdfNode(pdfId, nodeKey);
	}

	@Override
	public PdfDto queryPdfByName(String pdfName) throws Exception {
		dfcIntf srv = dfcutil.getDfcIntf();
		DFP dfp = (DFP) srv.getDfpByName(pdfName);
		if (dfp != null
				&& PrivilegeMatrix.getInstance().canRead(getSessionKey(), dfp.getSMUserID(), dfp.getSMDomainID()))
			return toDto(dfp, PdfDto.class);
		return null;
	}

	@Override
	public MultiPageResultDto<PdfDto> queryPdfOfStory(StoryDto story) throws Exception {
		List<Relation_Mo2Story> rels = dcsutil.getDcsIntf().listMo2StoryLinkOfStory(story.getId(),
				CatalogMo.NODE_TYPE_PDF);
		List<PdfDto> pdfLst = new ArrayList<>();
		if (rels != null) {
			for (Relation_Mo2Story rel : rels) {
				String moRdn = rel.getMoRdn();
				PdfDto pdf = queryPdf(moRdn);
				if (pdf != null)
					pdfLst.add(pdf);
			}
		}
		MultiPageResultDto<PdfDto> rs = new MultiPageResultDto<>();
		rs.setTotal(pdfLst.size());
		rs.setTableData(pdfLst);
		return rs;
	}

	@Override
	public List<String> queryPdfIdOfStory(StoryDto story) throws Exception {
		List<Relation_Mo2Story> rels = dcsutil.getDcsIntf().listMo2StoryLinkOfStory(story.getId(),
				CatalogMo.NODE_TYPE_PDF);
		List<String> pdfLst = new ArrayList<>();
		if (rels != null) {
			for (Relation_Mo2Story rel : rels) {
				String moRdn = rel.getMoRdn();
				pdfLst.add(moRdn);
			}
		}
		return pdfLst;
	}

	@Override
	public MultiPageResultDto<PdfDto> queryPdfOfCdf(CdfDto cdf) throws Exception {
		List<Relation_DF> dfLinks = dcsutil.getDcsIntf().listDFOfSrc(cdf.getId());
		List<PdfDto> pdfLst = new ArrayList<>();
		for (Relation_DF dfLink : dfLinks) {
			PdfDto pdf = queryPdf(dfLink.getDst());
			if (pdf != null)
				pdfLst.add(pdf);
		}
		MultiPageResultDto<PdfDto> rs = new MultiPageResultDto<>();
		rs.setTotal(pdfLst.size());
		rs.setTableData(pdfLst);
		return rs;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<String> queryPdfIdOfReferencePdc(String pdcId) throws Exception {
		IPdcService pdcMgr  = getApiUtils().getMgr(IPdcService.class);
		PdcDto pdc = pdcMgr.queryPdc(pdcId);
		DcChecker.checkPDCNotNull(pdc);
		NameValuePair nvQuery = new NameValuePair(PSMRef.attr_RelatePSM, pdc.getId());
		MultiPageResult<PSMRef> rs = dfcutil.getDfcIntf().getMoDataByModel(MDUtil.getClassNameForSysteMO(PSMRef.class),
				nvQuery, null, 0, Integer.MAX_VALUE);
		List<String> pdfLst = new ArrayList<>();
		if (rs.hasData()) {
			for (PSMRef ref : rs.getListData()) {
				PdfDto pdf = queryPdf(ref.getPDN());
				if (pdf != null)
					pdfLst.add(pdf.getId());
			}
		}
		return pdfLst;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<PdfDto> queryPdfOfReferencePdc(String pdcId) throws Exception {
		IPdcService pdcMgr  = getApiUtils().getMgr(IPdcService.class);
		PdcDto pdc = pdcMgr.queryPdc(pdcId);
		DcChecker.checkPDCNotNull(pdc);
		NameValuePair nvQuery = new NameValuePair(PSMRef.attr_RelatePSM, pdc.getId());
		MultiPageResult<PSMRef> rs = dfcutil.getDfcIntf().getMoDataByModel(MDUtil.getClassNameForSysteMO(PSMRef.class),
				nvQuery, null, 0, Integer.MAX_VALUE);
		List<PdfDto> pdfLst = new ArrayList<>();
		if (rs.hasData()) {
			for (PSMRef ref : rs.getListData()) {
				PdfDto pdf = queryPdf(ref.getPDN());
				if (pdf != null)
					pdfLst.add(pdf);
			}
		}
		return pdfLst;
	}

	@Override
	public void deletePdf(String pdfId) throws Exception {
		PdfDto orgPdf = queryPdf(pdfId);
		dfcIntf srv = dfcutil.getDfcIntf();
		if (orgPdf != null) {
			DcChecker.checkAuthorized(getSessionKey(), PrivilegeConst.PDF_DELETE, orgPdf.getSmUserId(),
					orgPdf.getSmDomainId());
			// ɾ��������PDFJob��ĿǰGDF���Ѿ�û�ж�PDF������Job�ˣ����������ε�
			/*
			 * JobMgr jobMgr = dcsutil.getDcsIntf().getJobMgr(getSessionKey()); List<Job>
			 * jobs = jobMgr.listPDFJob(orgPdf.getName()); for (Job job : jobs) {
			 * jobMgr.deleteJob(job.getID()); }
			 */
			srv.deleteDFPattern(orgPdf.getId());
			info(orgPdf.getId(), orgPdf.getName(), "",orgPdf,"");
		}
	}

	@Override
	public void deletePdfByName(String pdfName) throws Exception {
		PdfDto orgPdf = queryPdfByName(pdfName);
		if(orgPdf != null) {
			deletePdf(orgPdf.getId());
		}
	}

	@Override
	public Pair<String, byte[]> exportPdf(String pdfId, boolean isExportCdcPdc) throws Exception {
		com.leavay.common.util.Pair<String, byte[]> pair = getPDFMgr().exportPDF(pdfId, isExportCdcPdc);
		return toPair(pair);
	}

	@Override
	public boolean isPdfGuid(String guid) throws Exception {
		ManagedData mo = dfcutil.getDfcIntf().getPsmByGUID(guid);
		if(mo == null)
			return false;
		return mo instanceof DFP;
	}

	@Override
	public boolean isPdf(String id) throws Exception {
		ManagedData mo = dfcutil.getDfcIntf().getMo(id);
		if(mo == null)
			return false;
		return mo instanceof DFP;
	}

	@Override
	public PdfViewDto createPdfView(PdfViewDto view) throws Exception {
		PdfDto pdf = queryPdf(view.getPdfId());
		if(pdf == null){
			throw DCExceptionUtils.pdfNotFound(view.getPdfId());
		}
		PdfViewDto existView = queryPdfViewByName(view.getPdfId(), view.getName());
		if(existView != null)
			throw new InputValidationException(AppRes.getStringWithParam("View Name %s is Used!", view.getName()));
		PDFViewMo viewMo = dcsutil.getDcsIntf().createPDFView(view.getPdfId(), view.getName());
		if(!ToolUtilities.isStringEmpty(view.getParentViewId()))
			dcsutil.getDcsIntf().move2TargetPdfView(viewMo.getRDN(), view.getParentViewId());
		return toDto(viewMo, PdfViewDto.class);
	}

	@Override
	public PdfViewDto renamePdfView(String viewId, String name) throws Exception {
		PdfViewDto view = queryPdfView(viewId);
		if(view == null)
			throw new InputValidationException(AppRes.getStringWithParam("Job View is not exist!", viewId));
		view.setName(name);
		PDFViewMo viewMo = fromDto(view, PDFViewMo.class);
		viewMo = (PDFViewMo) viewMo.clone();
		viewMo = (PDFViewMo) dfcutil.getDfcIntf().updateMo(viewMo);
		return toDto(viewMo, PdfViewDto.class);
	}

	@Override
	public PdfViewDto queryPdfView(String viewId) throws Exception {
		ManagedData mo = dfcutil.getDfcIntf().getMo(viewId);
		if(mo == null || !(mo instanceof PDFViewMo))
			return null;
		return toDto(mo, PdfViewDto.class);
	}

	@Override
	public boolean isPdfView(String viewId) throws Exception {
		ManagedData mo = dfcutil.getDfcIntf().getMo(viewId);
		if(mo == null || !(mo instanceof PDFViewMo))
			return false;
		return true;
	}

	@Override
	public PdfViewDto queryPdfViewByName(String pdfId, String name) throws Exception {
		PDFViewMo mo = dcsutil.getDcsIntf().getPDFView(pdfId, name);
		return toDto(mo, PdfViewDto.class);
	}

	@Override
	public List<PdfViewDto> queryChildPdfViews(String pdfId,String viewId) throws Exception {
		PdfDto pdf = queryPdf(pdfId);
		if(pdf == null)
			throw DCExceptionUtils.pdfNotFound(pdfId);
		List<PDFViewMo> pdfViewMos = dcsutil.getDcsIntf().getPDFViewOfPDF(pdfId);
		if(ToolUtilities.isCollectionEmpty(pdfViewMos))
			return new ArrayList<>();
		List<PdfViewDto> pdfViews = BaseDtoUtil.getMe().transformObjects(pdfViewMos, v->fromDto(v, PdfViewDto.class));
		Map<String,PdfViewDto> pdfViewMaps = pdfViews.stream().collect(Collectors.toMap(PdfViewDto::getId, v->v));
		if(ToolUtilities.isStringEmpty(viewId)){
			//�ҳ�������Ŀ����ͼ�Ľڵ㣬����ͼ���ǲ���Ŀ����ͼ�Ľڵ�
			List<NodeLinkMo> links = dcsutil.getDcsIntf().getNodeLinkByDst(new ArrayList<>(pdfViewMaps.keySet()));
			List<String> childViewIds = new ArrayList<>();
			if(!ToolUtilities.isCollectionEmpty(links)){
				childViewIds = links.stream().map(v->v.getDst()).collect(Collectors.toList());
			}
			for(String childViewId : childViewIds){
				pdfViewMaps.remove(childViewId);
			}
			return new ArrayList<>(pdfViewMaps.values());
		}else{
			List<NodeLinkMo> links = dcsutil.getDcsIntf().getChildNode(viewId);
			List<String> childViewIds = new ArrayList<>();
			if(!ToolUtilities.isCollectionEmpty(links)){
				childViewIds = links.stream().map(v->v.getDst()).collect(Collectors.toList());
			}
			List<PdfViewDto> childViews = new ArrayList<>();
			for(String childViewId : childViewIds){
				if(pdfViewMaps.containsKey(childViewId))
					childViews.add(pdfViewMaps.get(childViewId));
			}
			return childViews;
		}
	}

	@Override
	public void deletePdfView(String viewId) throws Exception {
		PdfViewDto view = queryPdfView(viewId);
		if(view != null){
			if(!ToolUtilities.isStringEmpty(view.getParentViewId())){
				List<NodeLinkMo> childLinks = dcsutil.getDcsIntf().getChildNode(viewId);
				if(!ToolUtilities.isCollectionEmpty(childLinks)){
					List<String> childNodes = new ArrayList<>();
					for(NodeLinkMo link : childLinks){
						childNodes.add(link.getDst());
					}
					dcsutil.getDcsIntf().move2TargetPdfView(childNodes, view.getParentViewId());
				}
			}
			List<JobPDFSetting> jobPdfSettings = dcsutil.getDcsIntf().listJobPDFSetting(view.getPdfId());
			if(jobPdfSettings != null){
				for(JobPDFSetting jobPdfSetting :  jobPdfSettings){
					dcsutil.getDcsIntf().removeJobFlowCache(DNParser.getRDN(jobPdfSetting.getPDN()));
				}
			}
			dfcutil.getDfcIntf().deleteMo(viewId);
		}
	}

	@Override
	public void move2PdfView(String pdfId, List<String> nodeIds, String viewId) throws Exception {
		Set<String> parentViews = new HashSet<>();
		if(ToolUtilities.isStringEmpty(viewId) || ToolUtilities.isStringEqual(pdfId, viewId)){
			//���Ŀ����ͼΪ�գ��������ͼ�ƶ���PDF���ϣ���Ҫ�ҵ�ɾ���ڵ��������Դ��ͼ�ڵ㣬��ѯ����ͼ�ڵ㱻�Ƴ��ڵ��Ĺ�ϵ
			List<NodeLinkMo> links = dcsutil.getDcsIntf().getNodeLinkByDst(nodeIds);
			for(NodeLinkMo link : links)
				parentViews.add(link.getSrc());
			//ֻ���ƶ��ڵ�Ĺ�ϵ�Ƴ�����ɾ���ӽڵ�
			dcsutil.getDcsIntf().deleteLinkOfDsts(nodeIds);
		}else{
			PdfViewDto view = queryPdfView(viewId);
			if(view == null)
				throw new InputValidationException(AppRes.getStringWithParam("PDF View is not exist!", viewId));
			if(!ToolUtilities.isCollectionEmpty(nodeIds))
				dcsutil.getDcsIntf().move2TargetPdfView(nodeIds,viewId);
			parentViews.add(viewId);
		}
		parentViews.addAll(nodeIds);
		List<JobPDFSetting> jobPdfSettings = dcsutil.getDcsIntf().listJobPDFSetting(pdfId);
		if(jobPdfSettings != null){
			for(JobPDFSetting jobPdfSetting :  jobPdfSettings){
				dcsutil.getDcsIntf().removeJobFlowCache(DNParser.getRDN(jobPdfSetting.getPDN()));
			}
		}
	}

	@Override
	public Set<String> queryReferencePdcIds(String pdfId) throws Exception {
		DFPCache cache = dfcutil.getDfcIntf().getDfpCache(pdfId);
		Set<String> referencePdcs = new HashSet<>();
		for(MOKey key : cache.getAllNodes()){
			if(key instanceof PsmRefKey){
				referencePdcs.add(((PsmRefKey) key).getRelatedPSM());
			}
		}
		return referencePdcs;
	}

	@Override
	public PdfSegmentFlowDto expandPdfView(String pdfId, String pdfViewId, List<String> nodesKey, List<FlowLink> links)
			throws Exception {
		ManagedData mo = dfcutil.getDfcIntf().getMo(pdfViewId);
		PdfSegmentFlowDto segment = new PdfSegmentFlowDto();
		segment.setId(pdfId);
		if(!(mo instanceof PDFViewMo))
			return segment;
		PDFFlowCache flowCache = dcsutil.getDcsIntf().getPDFFlowCache(pdfId);
		DFPCache dfpCache = dfcutil.getDfcIntf().getDfpCache(pdfId);
		Pair<Set<String>,Set<FlowLink>> relPair = flowCache.getNodeAndRelationInView(pdfViewId, new HashSet<>(nodesKey));
		LinkedHashSet<PdfNodeDto> nodes = new LinkedHashSet<>();
		Set<FlowLink> newLinks = relPair.right;
		for(String nodeKey : relPair.left){
			PdfNodeDto node = null;
			if(flowCache.isPdfViewNode(nodeKey)){
				PdfViewDto view = queryPdfView(nodeKey);
				node = toPdfNodeDto(view);
			}else{
				MOKey moKey = dfpCache.getNode(nodeKey);
				node = toPdfNodeDto(moKey);
				node.setGroup(pdfViewId);
			}
			if(node != null)
				nodes.add(node);
		}
		Set<String> deleteNodes = new HashSet<>();
		deleteNodes.add(pdfViewId);
		segment.setDeleteNodes(deleteNodes);
		segment.setNodes(nodes);
		segment.setLinks(new LinkedHashSet<>(newLinks));
		return segment;
	}

	@Override
	public PdfSegmentFlowDto shrinkPdfView(String pdfId, String pdfViewId, List<String> nodesKey, List<FlowLink> links)
			throws Exception {
		ManagedData mo = dfcutil.getDfcIntf().getMo(pdfViewId);
		PdfSegmentFlowDto segment = new PdfSegmentFlowDto();
		segment.setId(pdfId);
		if(!(mo instanceof PDFViewMo))
			return segment;
		PDFFlowCache flowCache = dcsutil.getDcsIntf().getPDFFlowCache(pdfId);
		LinkedHashSet<PdfNodeDto> nodes = new LinkedHashSet<>();
		PdfNodeDto node = null;
		PdfViewDto view = queryPdfView(pdfViewId);
		node = toPdfNodeDto(view);
		nodes.add(node);
		Pair<Set<String>,Set<FlowLink>> relPair = flowCache.getAllChildNodeInView(pdfViewId, new HashSet<>(nodesKey));
		segment.setDeleteNodes(relPair.left);
		segment.setNodes(nodes);
		segment.setLinks(new LinkedHashSet<>(relPair.right));
		return segment;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TreeNode> getPdfViewTree(String pdfId, boolean lazyLoad) throws Exception {
		PdfDto pdf = queryPdf(pdfId);
		if(pdf == null)
			return new ArrayList<>();
		TreeNode rootNode = new TreeNode();
		rootNode.setID(TreeNode.getIdOfOutSideNode(GdfTreeConst.NODE_TYPE_PDFVIEWROOT_IN_PDFFLOW, pdfId));
		rootNode.setRealMoId(pdfId);
		rootNode.setNodeType(GdfTreeConst.NODE_TYPE_PDFVIEWROOT_IN_PDFFLOW);
		rootNode.setName(pdf.getName());
		if(!lazyLoad){
			getTreeMgr().loadChildList(rootNode);
		}
		return ToolUtilities.newArrayList(rootNode);
	}

	@Override
	public ProductRequirementFlow queryProductRequirementFlow(String id) throws Exception {
		return getPDFMgr().getProductRequirementFlow(id);
	}

	@Override
	public ProductRequirementFlow queryProductRequirementFlowByPdf(String pdfId) throws Exception {
		return getPDFMgr().getProductRequirementFlowByPdf(pdfId);
	}

	@Override
	public ProductRequirementFlowGraph queryProductRequirementFlowGraph(String id) throws Exception {
		return getPDFMgr().getProductRequirementFlowGraph(id);
	}

	@Override
	public ProductRequirementFlowGraph queryProductRequirementFlowGraphByPdf(String pdfId) throws Exception {
		return getPDFMgr().getProductRequirementFlowGraphByPdf(pdfId);
	}

	@Override
	public ProductRequirementFlowGraph saveProductRequirementFlowGraph(ProductRequirementFlowGraph graph)
			throws Exception {
		return getPDFMgr().saveProductRequirementFlowGraph(graph);
	}

	@Override
	public ProductRequirementRelatePdcFlow queryProductRequirementRelatePdcFlow(String productReqId) throws Exception {
		return getPDFMgr().getProductRequirementRelatePdcFlow(productReqId);
	}

	@Override
	public void createRelationOfProductRequirementAndPdc(ProductRequirement pr, List<String> pdcIds) throws Exception {
		getPDFMgr().createRelationOfProductRequirementAndPdc(pr, pdcIds);
	}

	@Override
	public ProductRequirement queryProductRequirement(String id) throws Exception {
		return getPDFMgr().getProductRequirement(id);
	}

	@Override
	public ProductRequirement createProductRequirement(ProductDesign pd, ProductRequirement pr) throws Exception {
		return getPDFMgr().createProductRequirement(pd, pr);
	}

	@Override
	public ProductRequirement updateProductRequirement(ProductRequirement pr) throws Exception {
		return getPDFMgr().updateProductRequirement(pr);
	}

	@Override
	public void bindPdc2ProductRequirement(String requirementId, List<String> nodeKeys) throws Exception {
		getPDFMgr().bindPdc2ProductRequirement(requirementId, nodeKeys);
	}

	@Override
	public PdfNodeDto craetePDCNode(String pdfId, String requirementId, PdcDto pdc) throws Exception {
		setDefaultValue(pdc);
		getPdcMgr().beforeSavedPdcDtoByDefault(pdc);
		PdfDto pdf = queryPdf(pdfId);
		DcChecker.checkPDFNotNull(pdf);
		pdc.setPdfId(pdfId);
		pdc = getPdcMgr().createPdc(pdc);
		getPdcMgr().onAfterSavedPdcDtoByDefault(GdfConst.ON_AFTER_SAVE_PDC_MODE_BY_SINGLE_CREATE_OR_UPDATE_PDC,pdc.getGuid());
		pdc =getPdcMgr().queryPdc(pdc.getId());
		if(!ToolUtilities.isStringEmpty(requirementId)) {
			ProductRequirement pr = queryProductRequirement(requirementId);
			if(pr == null) {
				throw GDFErrorHandler.productRequirementNotFound(requirementId);
			}
			List<String> pdcIds = ToolUtilities.newArrayList(pdc.getId());
			createRelationOfProductRequirementAndPdc(pr, pdcIds);
		}
		return queryPdfNode(pdfId, pdc.getId());
	}
	
	
	@Override
	public void setDefaultValue(PdcDto pdc) throws Exception {
		CdcDto cdc = getCdcMgr().queryCdcByPdc(pdc);
		List<String> designAttributes = cdc.getProductDesignAttriubtes();
		for (AttributeDto attr : cdc.getAttributes()) {
			if (designAttributes.contains(attr.getName()))
				continue;
			if (!attr.isCanBeEmpty()) {
				Object value = pdc.get(attr.getName());
				if (value == null) {
					if (attr.isString() || attr.isDatasource() || attr.isServer())
						pdc.set(attr.getName(), "-");
					else if (attr.isBoolean())
						pdc.set(attr.getName(), false);
					else if (attr.isDataSet() || attr.isGTable()) {
						pdc.setDataSet(attr.getName(), new PdcDataSetDto());
					} else if (attr.isInteger() || attr.isLong() || attr.isDouble() || attr.isSingleEnum())
						pdc.set(attr.getName(), -1);
					else if (attr.isFileEntity()) {
						PdcFileEntityDto fileEntity = new PdcFileEntityDto("-", "");
						pdc.setFileEntityDto(attr.getName(), fileEntity);
					} else if (attr.isSqlMapping() || attr.isTableEntity()) {
						List<ColumnDto> colRows = new ArrayList<>();
						ColumnDto column = new ColumnDto("-", "-", "", "", false, false);
						colRows.add(column);
						PdcTableEntityDto tableEntity = new PdcTableEntityDto();
						tableEntity.setColRows(colRows);
						pdc.setTableEntity(attr.getName(), tableEntity);
					}
				}
			}
		}
	}
	@Override
	public PdfFlowDto querySummaryPDF(String id) throws Exception {
		PDFFlow pdfFlow = getPDFMgr().getSummaryPDF(id);
		return toDto(pdfFlow, PdfFlowDto.class);
//		PdfFlowDto flow = new PdfFlowDto();
//		IPdcService pdcMgr = getPdcMgr();
//		List<TreeNode> childTreeNodeList = queryAllChildPDF(id);
//		List<PdfFlowDto> pdfList=new ArrayList<>();
//		//把目录下的所有产线加到list里
//		for (TreeNode treeNode : childTreeNodeList) {
//			pdfList.add(queryPdfFlow(treeNode.getRealMoId()));
//		}
//		flow.setId(id);
//		flow.setName(getGDFTreeMgr().queryTreeNode(id).getName());
//		flow.setDisplayMode(GdfConst.DISPLAY_MODE_DETAIL);
//		Set<PdfNodeDto> nodes = flow.getNodes();
//		Set<FlowLink> links = flow.getLinks();
//		for(PdfFlowDto pdf : pdfList) {
//			for(PdfNodeDto node :  pdf.getNodes()) {
//				nodes.add(node);
//			}
//			for(FlowLink link : pdf.getLinks()) {
//				links.add(link);
//			}
//		}
//		Map<String, PdfNodeDto> nodeMap  = new HashMap<String, PdfNodeDto>();
//		for(PdfNodeDto node : nodes) {
//			if(nodeMap.containsKey(node.getName())) {
//				//map内的引用节点
//				PdfNodeDto pdfNodeDto = nodeMap.get(node.getName());
//				if(pdfNodeDto.isReference()) {
//					FlowLink fromLink = null;
//					FlowLink toLink = null;
//					Iterator<FlowLink> linksIterator = links.iterator();
//					while(linksIterator.hasNext()) {
//						FlowLink link = linksIterator.next();
//						if(ToolUtilities.isStringEqual(link.getFrom(), pdfNodeDto.getKey())) {
//							fromLink = link;
//							links.remove(link);
//							fromLink.setFrom(node.getKey());
//						}else if(ToolUtilities.isStringEqual(link.getTo(), pdfNodeDto.getKey())) {
//							toLink = link;
//							links.remove(link);
//							toLink.setFrom(node.getKey());
//						}
//					}
//					if(fromLink!=null) {
//						links.add(fromLink);
//					}else if(toLink!=null) {
//						links.add(toLink);
//					}
//
//					nodes.remove(pdfNodeDto);
//					nodeMap.put(node.getName(), node);
//				}else {
//					FlowLink fromLink = null;
//					FlowLink toLink = null;
//					Iterator<FlowLink> linksIterator = links.iterator();
//					while(linksIterator.hasNext()) {
//						FlowLink link = linksIterator.next();
//						if(ToolUtilities.isStringEqual(link.getFrom(), node.getKey())) {
//							fromLink = link;
//							links.remove(link);
//							fromLink.setFrom(pdfNodeDto.getKey());
//						}else if(ToolUtilities.isStringEqual(link.getTo(), node.getKey())) {
//							toLink = link;
//							links.remove(link);
//							toLink.setFrom(pdfNodeDto.getKey());
//						}
//					}
//					if(fromLink!=null) {
//						links.add(fromLink);
//					}else if(toLink!=null) {
//						links.add(toLink);
//					}
//					nodes.remove(node);
//				}
//			}else {
//				nodeMap.put(node.getName(), node);
//			}
//			flow.setLinks(links);
//			flow.setNodes(nodes);
//			return flow;
//		}
		
		
		
//		return  flow;
	}
	public List<TreeNode> queryAllChildPDF(String id) throws Exception{
		List<TreeNode> treeNodeList=new ArrayList<>();
		List<TreeNode> childTreeNodeList = getGDFTreeMgr().queryChildTreeNodeList(id, false);
		for (TreeNode treeNode : childTreeNodeList) {
			if (treeNode.getNodeType().equals("PDF"))
			treeNodeList.add(treeNode);
			if(treeNode.getNodeType().equals("PDFFolder")) {
				List<TreeNode> childTreeNodeList1 =queryAllChildPDF(treeNode.getID());
			treeNodeList.addAll(childTreeNodeList1);
			}
		}
		return treeNodeList;

	}
	
	@Override
	public PDCBriefNode queryPDCBriefNode(String id) throws Exception {
		return getPDFMgr().getPDCBriefNode(id);
	}
	
	
	public PdfDto toDto(PDF pdf) {
		PdfDto dto = new PdfDto();
		if (!CmnUtil.isStringEmpty(pdf.getID())) {
			dto.setId(pdf.getID());
		}
		dto.setName(pdf.getName());
		dto.setSmDomainId(pdf.getSmDomainId());
		dto.setSmUserId(pdf.getSmDomainId());
		return dto;
	}
	public MultiPageResultDto<RowDataDto> pagePDCofPDF(String pdfId, NameValuePair condition, OrderByPair orderBy, int pageNo, int pageSize) throws Exception {
		PDF pdf = getPDFMgr().getPDF(pdfId);
		String keyword = null;
		if (GdfConst.isFullContentSerach(condition)) {
			keyword = ((String) condition.getValue()).toUpperCase();
			keyword = keyword.substring(1, keyword.length() - 1);
		}
		List<PDC> allPDC = pdf.getAllPDC();
		List<RowDataDto> rowDataDtoList = new ArrayList<>();
		for (PDC pdc : allPDC) {
			RowDataDto rowDataDto = new RowDataDto();
			rowDataDto.put("id", pdc.getID());
			rowDataDto.put("guid", pdc.getGUID());
			rowDataDto.setName(pdc.getGUID());
			String label = "";
			CDCCustomConfig cstCfg = DCDataCacheMgr.getInstance().getCdcCustomConfigCache(pdc.getCDCName());
			if (cstCfg != null && !CmnUtil.isStringEmpty(cstCfg.getDisplayAttr()))
				label = pdc.getAttrValueAsString(cstCfg.getDisplayAttr());
			label = ToolUtilities.isStringEmpty(label) ? pdc.getGUID() : label;
			if (!CmnUtil.isStringEmpty(keyword)) {
				if (!pdc.getGUID().toUpperCase().contains(keyword) && !label.toUpperCase().contains(keyword)) {
					continue;
				}
			}
			rowDataDto.put("label", label);
			rowDataDtoList.add(rowDataDto);
		}
		List<RowDataDto> pageData = DCUtils.getPageResult(pageNo, pageSize, rowDataDtoList);
		MultiPageResultDto<RowDataDto> rs = new MultiPageResultDto<>();
		rs.setTotal(rowDataDtoList.size());
		rs.setTableData(pageData);
		return rs;
	}
	@Override
	public List<PdcDto> queryPdcofPdf(String pdfId) throws Exception {
		PDF pdf = getPDFMgr().getPDF(pdfId);
		List<PDC> allPDC = pdf.getAllPDC();
		
		List<PdcDto> pdcLst = new ArrayList<>();
		if(!CmnUtil.isCollectionEmpty(allPDC)) {
			for(PDC pdc : allPDC) {
				PdcDto pdcDto = BaseDtoUtil.getMe().toDto(pdc);
				pdcLst.add(pdcDto);
			}
		}
		return pdcLst;
	}
	@Override
	public List<PdcDto> queryPdcSourceAndTarget(String pdfId, String key) throws Exception {
		PDC pdc = getPDCMgr().getPDC(key);
		PDF pdf = getPDFMgr().getPDF(pdfId);
		List<PdcDto> pdcLst = new ArrayList<>();
		
		Map<String, PDC> SourcePDC = pdf.getSourcePDC(pdc.getGUID());
		Map<String, PDC> TargetPDC = pdf.getTargetPDC(pdc.getGUID());
		
		 Collection<PDC> sourceLst = SourcePDC.values();
		 Collection<PDC> TargetLst = TargetPDC.values();
		
		for(PDC source : sourceLst) {
			PdcDto pdcDto = toDto(source, PdcDto.class);
			pdcLst.add(pdcDto);
		}
		for(PDC Target : TargetLst) {
			PdcDto pdcDto = toDto(Target, PdcDto.class);
			pdcLst.add(pdcDto);
		}
		return pdcLst;
	}

}