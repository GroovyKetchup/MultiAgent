package cell.gdf.config.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import com.kwaidoo.dc.BaseDtoUtil;
import com.kwaidoo.dc.BaseSecurityMgr;
import com.kwaidoo.dc.concrete.dto.AttributeDto;
import com.kwaidoo.dc.concrete.dto.CdcDto;
import com.kwaidoo.dc.config.dto.ColumnDto;
import com.kwaidoo.dc.config.dto.PdcDto;
import com.kwaidoo.dc.config.dto.PdcSqlMappingDto;
import com.kwaidoo.dc.config.dto.PdcTableEntityDto;
import com.kwaidoo.dc.config.dto.PdfDto;
import com.kwaidoo.dc.config.dto.ViewMetaNodeDto;
import com.kwaidoo.dc.develop.SqlMappingFlow;
import com.kwaidoo.dc.develop.SqlMappingRuntimeParam;
import com.kwaidoo.dc.develop.ViewMetaNode;
import com.kwaidoo.dc.dto.BaseDto;
import com.kwaidoo.dc.exception.DcChecker;
import com.kwaidoo.dc.mgr.ClassTransformUtil;
import com.kwaidoo.dc.setting.CustomView;
import com.kwaidoo.dc.setting.CustomViewMgr;
import com.kwaidoo.dc.setting.TransformRC;
import com.kwaidoo.dc.setting.dto.DBDataSourceDto;
import com.kwaidoo.dc.setting.dto.DataSetDefDto;
import com.kwaidoo.dc.transform.ClassTransformIntf;
import com.kwaidoo.dc.utils.ProgressDetail;
import com.kwaidoo.ms.tool.CmnUtil;
import com.leavay.common.util.KeyValuePair;
import com.leavay.common.util.ToolUtilities;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dc.design.CDC;
import com.leavay.dc.design.CDCMgr;
import com.leavay.dc.develop.*;
import com.leavay.dc.develop.PDCSqlMapping.ViewMeta;
import com.leavay.dc.setting.DBDataSource;
import com.leavay.dc.setting.DataSetDef;
import com.leavay.dfc.gui.dfcutil;
import com.leavay.dfc.gui.component.JdbcMetaInfo;
import com.leavay.model.inf.MDConstants;
import com.leavay.model.inf.ManagedData;
import com.leavay.model.inf.filter.AndOPNameValue;
import com.leavay.model.inf.filter.LikeNameValuePair;
import com.leavay.model.inf.filter.NameValuePair;
import com.leavay.model.inf.filter.OrOPNameValue;
import com.leavay.model.inf.filter.SqlNameValuePair;
import com.leavay.model.inf.model.Model;
import com.leavay.model.inf.sort.OrderByPair;
import com.leavay.model.mgr.MDUtil;
import com.project.gui.common.DBDataSourceIntf;

import cell.cmn.IJson;
import cell.cmn.IJsonService;
import cell.gdf.config.IPdcService;
import cell.gdf.design.ICdcService;
import modeldef.com.leavay.dfc.mda.PSMRef;
import web.dto.MultiPageResultDto;
import web.dto.Pair;
import web.vo.Condition;
import web.vo.OrderBy;

public class CPdcService extends BaseSecurityMgr implements IPdcService{

	public PDCMgr getPDCMgr() throws Exception {
		return getDCSAPIUtils().getPDCMgr();
	}
	
	public CDCMgr getCDCMgr() throws Exception {
		return getDCSAPIUtils().getCDCMgr();
	}

	private CustomViewMgr getCustomViewMgr() throws Exception {
		return getDCSAPIUtils().getCustomViewMgr();
	}
	
	@Override
	public PdcDto newPdcByCdc(String cdcId) throws Exception {
		PDC _pdc = getPDCMgr().newPDCByCDC(cdcId);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdcDto newPdcByCdc(CdcDto cdc) throws Exception {
		CDC _cdc = fromDto(cdc, CDC.class);
		PDC _pdc = getPDCMgr().newPDCByCDC(_cdc);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdcDto createPdc(PdcDto pdc) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		_pdc = getPDCMgr().createPDC(_pdc);
		return toDto(_pdc, PdcDto.class);
	}
	
	@Override
	public PdcDto autoBuildPDc(String buildMode,PdcDto pdc) throws Exception {
		pdc = beforeSavedPdcDtoByDefault(pdc);
		if(pdc.getId() == null) {
			pdc = createPdc(pdc);
		}else {
			pdc = updatePdc(pdc);
		}
		onAfterSavedPdcDtoByDefault(buildMode, pdc.getGuid());
		return pdc;
	}

	@Override
	public PdcDto createMirrorPdc(String pdcId, String targetPdfId) throws Exception {
		PDC _pdc = getPDCMgr().createMirrorPDC(pdcId, targetPdfId);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdcDto queryPdc(String id) throws Exception {
		PDC _pdc = getPDCMgr().getPDC(id);
		if (_pdc == null) {
			return null;
		}
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdcDto queryPdcWithViewId(String id, String viewId) throws Exception {
		PDC _pdc = getPDCMgr().getPDC(id);
		if (_pdc == null) {
			return null;
		}
		//获取View显示配置，根据他来筛选可见字段
		CustomView customView = getCustomViewMgr().getCustomView(viewId);
		if (customView != null) {
			ClassTransformIntf<PDC> pdcTransform = ClassTransformUtil.getInstance().getTransformIntfByClass(getSessionKey(), PDC.class);
			Object obj = pdcTransform.transform(_pdc);
			pdcTransform.afterTransform(null, customView, obj);
			PDC orgValue = getPDCMgr().newPDCByCDC(_pdc.getCDCID());
			_pdc = pdcTransform.reverse(obj, orgValue, TransformRC.getInstance());
		}
		PdcDto pdcDto = toDto(_pdc, PdcDto.class);
		//把viewId存进去，在PdcDtoIntervenor中使用
		pdcDto.put(PdcDto.VIEW_ID, viewId);
		return pdcDto;
	}

	@Override
	public PdcDto queryPdcByGuid(String guid) throws Exception {
		PDC _pdc = getPDCMgr().getPDCbyName(guid);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public String queryGuidById(String pdcId) throws Exception {
		return getPDCMgr().getGuidByPDCID(pdcId);
	}
	@Override
	public String queryIdByGuid(String guid)throws Exception{
		return getPDCMgr().getPdcIdByGuid(guid);
	}

	@Override
	public List<String> queryGuidsByCdcName(String cdcName) throws Exception {
		return getPDCMgr().getGuidsByCdcName(cdcName);
	}

	@Override
	public MultiPageResultDto<PdcDto> queryPdcs(List<String> pdcIds) throws Exception {
		List<PDC> data = getPDCMgr().getPDCs(pdcIds);
		return BaseDtoUtil.getMe().transformObjectsToPage(data, v->toDto(v, PdcDto.class));
	}

	@Override
	public MultiPageResultDto<PdcDto> queryPdcByGuids(List<String> guids) throws Exception {
		List<PDC> data = getPDCMgr().listPDCsByName(guids);
		return BaseDtoUtil.getMe().transformObjectsToPage(data, v->toDto(v, PdcDto.class));
	}
	@Override
	public MultiPageResultDto<BaseDto> queryPdcEnums(String cdcId)throws Exception{
		CdcDto cdc = getApiUtils().getMgr(ICdcService.class).queryCdc(cdcId);
		if(cdc == null)
			return new MultiPageResultDto<>();
		String displayAttr = cdc.getDisplayAttr();
		displayAttr = CmnUtil.isStringEmpty(displayAttr) ? PdcDto.Guid : displayAttr;
		MultiPageResultDto<PdcDto> pdcRs = queryPdcByCondition(cdc.getName(), null, null);
		MultiPageResultDto<BaseDto> enumRs = new MultiPageResultDto<>();
		enumRs.setTotal(pdcRs.getTotal());
		if(pdcRs.hasData()) {
			List<BaseDto> data = new ArrayList<>();
			for(PdcDto pdc : pdcRs.getTableData()) {
				BaseDto item = new BaseDto();
				item.put("value", pdc.getGuid());
				item.put("label", pdc.getString(displayAttr, "")+"("+pdc.getGuid()+")");
				data.add(item);
			}
			enumRs.setTableData(data);
		}
		return enumRs;
	}

	@Override
	public MultiPageResultDto<PdcDto> queryAllPdcByCdcName(String cdcName) throws Exception {
		List<PDC> data = getPDCMgr().listAllPDCbyCDCName(cdcName);
		return BaseDtoUtil.getMe().transformObjectsToPage(data, v->toDto(v, PdcDto.class));
	}

	@Override
	public MultiPageResultDto<PdcDto> queryAllPdcbyCdcName(List<String> cdcNameLst) throws Exception {
		List<PDC> data = getPDCMgr().listAllPDCbyCDCName(cdcNameLst);
		return BaseDtoUtil.getMe().transformObjectsToPage(data, v->toDto(v, PdcDto.class));
	}

	@SuppressWarnings("rawtypes")
	@Override
	public MultiPageResultDto<PdcDto> queryPdcByCondition(String cdcName, List<Condition> condition,
			List<OrderBy> orderBy) throws Exception {
		NameValuePair nvQuery = Condition.toNameValuePair(condition);
		OrderByPair order = OrderBy.toOrderBy(orderBy);
		List<PDC> data = getPDCMgr().listPDCByCondition(cdcName, nvQuery, order);
		return BaseDtoUtil.getMe().transformObjectsToPage(data, v->toDto(v, PdcDto.class));
	}

	@Override
	public List<String> queryPdcGuidsByKeyWord(String keyWord) throws Exception {
		return getPDCMgr().listPDCByGuid(keyWord);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public MultiPageResultDto<PdcDto> queryPdcPage(String cdcId, List<Condition> filters, List<OrderBy> orderBy,
			int pageNo, int pageSize,String filtersKeyWord) throws Exception {
		CdcDto cdc = getApiUtils().getMgr(ICdcService.class).queryCdc(cdcId);
		if(cdc == null)
			return new MultiPageResultDto<>();
		if(filters == null)
			filters = new ArrayList<>();
		if(!CmnUtil.isStringEmpty(filtersKeyWord)) {
			Condition contentCondition = getContentCondition(cdcId, filtersKeyWord);
			filters.add(contentCondition);
		}
		NameValuePair nvQuery = Condition.toNameValuePair(filters);
		OrderByPair order = OrderBy.toOrderBy(orderBy);
		int startPos = (pageNo -1) * pageSize;
		MultiPageResult<PDC> rs = getPDCMgr().pagingPDCByCondition(cdc.getName(), nvQuery, order, startPos, pageSize);
		MultiPageResultDto<PdcDto> rs2 = new MultiPageResultDto<>();
		rs2.setTotal(rs.getTotalCount());
		rs2.setTableData(BaseDtoUtil.getMe().transformObjects(rs.getListData(), v->toDto(v, PdcDto.class)));
		return rs2;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public MultiPageResultDto<PdcDto> queryPdcPageOfCdcList(List<String> cdcNameLst, List<Condition> condition,
			List<OrderBy> orderBy, int pageNo, int pageSize) throws Exception {
		NameValuePair nvQuery = Condition.toNameValuePair(condition);
		OrderByPair order = OrderBy.toOrderBy(orderBy);
		int startPos = (pageNo -1) * pageSize;
		MultiPageResult<PDC> rs = getPDCMgr().pagingPDCByCondition(cdcNameLst, nvQuery, order, startPos, pageSize);
		MultiPageResultDto<PdcDto> rs2 = new MultiPageResultDto<>();
		rs2.setTotal(rs.getTotalCount());
		rs2.setTableData(BaseDtoUtil.getMe().transformObjects(rs.getListData(), v->toDto(v, PdcDto.class)));
		return rs2;
	}

	@Override
	public MultiPageResultDto<PdcDto> queryPdcOfCdcListByConditionMap(List<String> cdcNameLst,
			Map<String, List<Condition>> conditionMap, List<OrderBy> orderBy, int pageNo, int pageSize)
			throws Exception {
		Map<String,NameValuePair<?>> nvQueryMap = new HashMap<>();
		if(!CmnUtil.isMapEmpty(conditionMap)) {
			for(Entry<String,List<Condition>> entry : conditionMap.entrySet()) {
				NameValuePair nvQuery = Condition.toNameValuePair(entry.getValue());
				nvQueryMap.put(entry.getKey(), nvQuery);
			}
		}
		OrderByPair order = OrderBy.toOrderBy(orderBy);
		int startPos = (pageNo -1) * pageSize;
		MultiPageResult<PDC> rs = getPDCMgr().pagingPDCByConditionMap(cdcNameLst, nvQueryMap, order, startPos, pageSize);
		MultiPageResultDto<PdcDto> rs2 = new MultiPageResultDto<>();
		rs2.setTotal(rs.getTotalCount());
		rs2.setTableData(BaseDtoUtil.getMe().transformObjects(rs.getListData(), v->toDto(v, PdcDto.class)));
		return rs2;
	}

	@Override
	public String queryDisplayNameByGuid(String guid) throws Exception {
		PDC pdc = getPDCMgr().getPDCbyName(guid);
		if(pdc != null){
			CDC cdc = getCDCMgr().getCdcCacheByName(pdc.getCDCName());
			if(cdc.getCustomConfig() != null){
				String displayLabelAttr = cdc.getCustomConfig().getDisplayAttr();
				if(!CmnUtil.isStringEmpty(displayLabelAttr)){
					return CmnUtil.getString(pdc.getAttrValueAsString(displayLabelAttr),"");
				}
			}
			return "";
		}
		return "";
	}

	@Override
	public PdcDto updatePdc(PdcDto pdc) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		_pdc = getPDCMgr().updatePDC(_pdc);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdcDto updatePdcWithViewId(PdcDto pdc) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		String viewId = pdc.getViewId();
		//获取View显示配置，根据他来筛选可见字段
		CustomView customView = getCustomViewMgr().getCustomView(viewId);
		if (customView == null) {
			_pdc = getPDCMgr().updatePDC(_pdc);
		} else {
			ClassTransformIntf<PDC> pdcTransform = ClassTransformUtil.getInstance().getTransformIntfByClass(getSessionKey(), PDC.class);
			pdcTransform.afterReverse(null, customView, _pdc);
			_pdc = getPDCMgr().updatePDC(_pdc);
		}
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdcDto importPdc(PdcDto pdc) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		_pdc = getPDCMgr().importPDC(_pdc);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdcDto updatePdcAttachmentDto(String pdcId, String attrName, File attachFile) throws Exception {
		PDC _pdc = getPDCMgr().updatePDCAttachment(pdcId, attrName, attachFile);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public Pair<String, byte[]> queryPdcAttachmentDto(String pdcId, String attrName) throws Exception {
		com.leavay.common.util.Pair<String, byte[]> pair = getPDCMgr().getPDCAttachment(pdcId, attrName);
		return toPair(pair);
	}

	@Override
	public PdcDto updatePdcSqlMapping(PdcDto pdc, PdcSqlMappingDto sqlMapping) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		PDCSqlMapping _sqlMapping = fromDto(sqlMapping, PDCSqlMapping.class);
		_pdc = getPDCMgr().updatePDCSqlMapping(_pdc, _sqlMapping);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdcDto updatePdcSqlMappingAndRemoveDirty(PdcDto pdc, PdcSqlMappingDto sqlMapping) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		PDCSqlMapping _sqlMapping = fromDto(sqlMapping, PDCSqlMapping.class);
		_pdc = getPDCMgr().updatePDCSqlMappingAndRemoveDirty(_pdc, _sqlMapping);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public void deletePdc(String id) throws Exception {
		getPDCMgr().deletePDC(id);
	}

	@Override
	public void deletePdcByGuid(String guid) throws Exception {
		getPDCMgr().deletePDCByName(guid);;
	}

	@Override
	public PdcDto copyPdc(String newPdcGuid, PdcDto srcPdc, Map attrValueMap) throws Exception {
		try(IJson json = IJsonService.get().getJson()){
			PdcDto newPdc = json.cloneObject(srcPdc);
			for(Object key : attrValueMap.keySet()) {
				newPdc.set((String)key, attrValueMap.get(key));
			}
			newPdc.setId(null);
			newPdc.setGuid(newPdcGuid);
			PDC _newPdc = fromDto(newPdc, PDC.class);
			_newPdc.getMo().setID(-1);
			_newPdc = getPDCMgr().updatePDC(_newPdc);
			return toDto(_newPdc, PdcDto.class);
		}
	}

	@Override
	public PdcDto copySqlMapping(PdcDto srcPdc, PdcDto dstPdc, boolean rebuildMainOutput, boolean ignoreComplieError)
			throws Exception {
		PDC _srcPdc = fromDto(srcPdc, PDC.class);
		PDC _dstPdc = toDto(dstPdc,PDC.class);
		_dstPdc = getPDCMgr().copySqlMapping(_srcPdc, _dstPdc, rebuildMainOutput, ignoreComplieError);
		return toDto(_dstPdc, PdcDto.class);
	}

	@Override
	public PdcDto copyPdcToOtherCdc(CdcDto cdc, String newPdcGuid, PdcDto srcPdc, Map attrValueMap) throws Exception {
		try(IJson json = IJsonService.get().getJson()){
			PdcDto newPdc = json.cloneObject(srcPdc);
			for(Object key : attrValueMap.keySet()) {
				newPdc.set((String)key, attrValueMap.get(key));
			}
			newPdc.setId(null);
			newPdc.setGuid(newPdcGuid);
			newPdc.setClassName(cdc.getClassName());
			PDC _newPdc = fromDto(newPdc, PDC.class);
			_newPdc.getMo().setID(-1);
			_newPdc = getPDCMgr().updatePDC(_newPdc);
			return toDto(_newPdc, PdcDto.class);
		}
	}

	@Override
	public Condition getContentCondition(String cdcId, String sSearchText) throws Exception {
		ICdcService cdcMgr = getApiUtils().getMgr(ICdcService.class);
		CdcDto cdc = cdcMgr.queryCdc(cdcId);
		DcChecker.checkCDCNotNull(cdc);
		sSearchText = ToolUtilities.replaceAll(sSearchText, "*", "%");
		if (!ToolUtilities.isStringEmpty(sSearchText)) {
			List<Condition> conditions = new ArrayList<>();
			List<AttributeDto> attrs = cdc.getAttributes();
			for (Iterator<AttributeDto> itAttr = attrs.iterator(); itAttr.hasNext();) {
				AttributeDto attr = itAttr.next();
				if (attr.isAttachment() || attr.isDataSet() || attr.isFileEntity() || attr.isGTable() || attr.isSqlMapping() || attr.isTableEntity() || attr.isUDF())
					continue;

				if (attr.isString()) {
					int iMax = ToolUtilities.getInteger(attr.getSize(), -1);
					if (iMax <= 0 || iMax > 4000)
						continue;
				}
				conditions.add(Condition.like(attr.getName(), sSearchText));
			}

			if (!conditions.isEmpty()) {
				Condition orCondtion = Condition.or(conditions);
				return orCondtion;
			}
			return null;
		}else {
			return null;
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Pair<String, byte[]> exportPdc(List<String> cdcIds, List<Condition> condition) throws Exception {
		NameValuePair nvQuery = Condition.toNameValuePair(condition);
		com.leavay.common.util.Pair<String, byte[]> pair = getPDCMgr().exportPDC(cdcIds, nvQuery);
		return toPair(pair);
	}

	@Override
	public Pair<String, byte[]> exportPdc(List<String> pdcNames, boolean exportRelInPdf) throws Exception {
		com.leavay.common.util.Pair<String, byte[]> pair = getPDCMgr().exportPDC(pdcNames, exportRelInPdf);
		return toPair(pair);
	}

	@Override
	public boolean isMirrorPdc(String guid) throws Exception {
		return getPDCMgr().isMirrorPDC(guid);
	}

	@Override
	public boolean isMirrorPdc(PdcDto pdc) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().isMirrorPDC(_pdc);
	}

	@Override
	public boolean isPdfDto(PdcDto pdc) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().isPDF(_pdc);
	}

	@Override
	public Pair<String, byte[]> exportTableEntityColumn(String tableEntityDefName, List<ColumnDto> columns)
			throws Exception {
		List<PDCTableEntity.Column> _columns = BaseDtoUtil.getMe().transformObjects(columns, v->fromDto(v, PDCTableEntity.Column.class));
		com.leavay.common.util.Pair<String, byte[]> pair = getPDCMgr().exportTableEntityColumn(tableEntityDefName, _columns);
		return toPair(pair);
	}

	@Override
	public List<ColumnDto> importTableEntityColumn(File excelFile, String tableEntityDefName) throws Exception {
		List<PDCTableEntity.Column> _columns = getPDCMgr().importTableEntityColumn(excelFile, tableEntityDefName);
		return BaseDtoUtil.getMe().transformObjects(_columns, v->toDto(v, ColumnDto.class));
	}

	@Override
	public String getCreateSql(PdcDto pdc, String attrName) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().getCreateSql(_pdc, attrName);
	}

	@Override
	public String testCreateSql(PdcDto pdc, String attrName) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().testCreateSql(_pdc, attrName);
	}

	@Override
	public Pair<String, byte[]> exportDataSetContent(DataSetDefDto dataSetDef, List<Map<String, String>> rows)
			throws Exception {
		DataSetDef _dataSetDef = fromDto(dataSetDef, DataSetDef.class);
		com.leavay.common.util.Pair<String, byte[]> pair = getPDCMgr().exportDataSetContent(_dataSetDef, rows);
		return toPair(pair);
	}

	@Override
	public PdcDto configSourceTableOfSqlPdc(PdcDto pdc, PdfDto pdf, List<PdcDto> pdcLst) throws Exception {
		String pdfId = pdf.getId();
		List<String> pdcIds = pdcLst.stream().map(v->v.getId()).collect(Collectors.toList());
		return configSourceTableOfSqlPdc(pdc, pdfId, pdcIds);
	}

	@Override
	public PdcDto configSourceTableOfSqlPdc(PdcDto pdc, String pdfId, List<String> pdcIds) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		_pdc = getPDCMgr().configSourceTableOfSqlPdc(_pdc, pdfId, pdcIds);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public SqlMappingRuntimeParam getSqlMappingRuntimeParam(String pdcId) throws Exception {
		return getPDCMgr().getSqlMappingRuntimeParam(pdcId);
	}

	@Override
	public SqlMappingRuntimeParam updateSqlMappingRuntimeParam(String pdcId, SqlMappingRuntimeParam data)
			throws Exception {
		return getPDCMgr().updateSqlMappingRuntimeParam(pdcId, data);
	}

	@Override
	public List<Map<String, String>> getOutputSqlOfSqlPdc(PdcDto pdc) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().getOutputSqlOfSqlPdc(_pdc);
	}

	@Override
	public String buildSqlOfSqlPdc(PdcDto pdc, String viewName, long opTime) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().buildSqlOfSqlPdc(_pdc, viewName, opTime);
	}

	@Override
	public String buildSqlOfSqlPdc(PdcDto pdc, String viewName, long opTime, boolean preview) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().buildSqlOfSqlPdc(_pdc, viewName, opTime,preview);
	}

	@Override
	public String buildSqlOfSqlPdcWithDS(DBDataSourceIntf ds, PdcDto pdc, String viewName, long opTime, boolean preview)
			throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().buildSqlOfSqlPdcWithDS(ds,_pdc, viewName, opTime,preview);
	}

	@Override
	public String buildSqlOfSqlPdcWithOutReplaceParameter(PdcDto pdc, String viewName, boolean preview)
			throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().buildSqlOfSqlPdcWithOutReplaceParameter(_pdc, viewName,preview);
	}

	@Override
	public String buildWithSqlOfSqlPdc(PdcDto pdc, String viewName, long opTime) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().buildWithSqlOfSqlPdc(_pdc, viewName,opTime);
	}

	@Override
	public String buildWithSqlOfSqlPdc(PdcDto pdc, String viewName, long opTime, boolean preview) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().buildWithSqlOfSqlPdc(_pdc, viewName,opTime,preview);
	}

	@Override
	public String buildWithSqlOfSqlPdcWithDS(DBDataSourceIntf ds, PdcDto pdc, String viewName, long opTime,
			boolean preview) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().buildWithSqlOfSqlPdcWithDS(ds,_pdc, viewName,opTime,preview);
	}

	@Override
	public String buildWithSqlOfViewInSqlMapping(PdcDto pdc, String viewName, boolean preview) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().buildWithSqlOfViewInSqlMapping(_pdc, viewName,preview);
	}

	@Override
	public Pair<List<JdbcMetaInfo>, List<List<String>>> testQuerySql(PdcDto pdc, String viewName, String sSql, int rows)
			throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		com.leavay.common.util.Pair<List<JdbcMetaInfo>, List<List<String>>> pair = getPDCMgr().testQuerySql(_pdc, viewName,sSql,rows);
		return toPair(pair);
	}

	@Override
	public Pair<List<JdbcMetaInfo>, List<List<String>>> testQuerySql(PdcDto pdc, DBDataSourceIntf ds, String sSql,
			int rows) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		com.leavay.common.util.Pair<List<JdbcMetaInfo>, List<List<String>>> pair = getPDCMgr().testQuerySql(_pdc, ds,sSql,rows);
		return toPair(pair);
	}

	@Override
	public String testRunQuerySqlByAgent(String selectAgent, DBDataSourceIntf ds, PdcDto pdc, String sSql, int rows)
			throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().testRunQuerySqlByAgent(selectAgent, ds, _pdc, sSql, rows);
	}

	@Override
	public String testRunQuerySqlByAgent2(String selectAgent, DBDataSourceDto ds, PdcDto pdc, String sSql, int rows)
			throws Exception {
		DBDataSource _ds = fromDto(ds, DBDataSource.class);
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().testRunQuerySqlByAgent2(selectAgent, _ds, _pdc, sSql, rows);
	}

	@Override
	public Pair<List<JdbcMetaInfo>, List<List<String>>> testGetQueryResultFromAgent(String uuid) throws Exception {
		com.leavay.common.util.Pair<List<JdbcMetaInfo>, List<List<String>>> pair = getPDCMgr().testGetQueryResultFromAgent(uuid);
		return toPair(pair);
	}

	@Override
	public PdcDto beforeSavedPdcDto(PdcDto pdc) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		_pdc = getPDCMgr().beforeSavedPDC(_pdc);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public PdcDto beforeSavedPdcDtoByDefault(PdcDto pdc) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		_pdc = getPDCMgr().beforeSavedPDCByDefault(_pdc);
		return toDto(_pdc, PdcDto.class);
	}

	@Override
	public void onAfterSavedPdcDto(String guid) throws Exception {
		getPDCMgr().onAfterSavedPDC(guid);
	}

	@Override
	public void onAfterSavedPdcDtoByDefault(String buildMode, String guid) throws Exception {
		getPDCMgr().onAfterSavedPDCByDefault(buildMode, guid);
	}

	@Override
	public List<KeyValuePair> queryAllSelectableAgents() throws Exception {
		return getPDCMgr().listAllSelectableAgents();
	}

	@Override
	public String remoteDebugSUDF(PdcDto pdc, String attrName, String selectAgent, long opTimeMills, boolean destroyRpc)
			throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().remoteDebugSUDF(_pdc, attrName, selectAgent, opTimeMills, destroyRpc);
	}

	@Override
	public String remoteDebugSUDFWithRC(PdcDto pdc, String attrName, String selectAgent, long opTimeMills,
			boolean destroyRpc, Map<String, Object> runtimeContext) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().remoteDebugJobFlowWithRC(_pdc, selectAgent, opTimeMills, destroyRpc, runtimeContext);
	}

	@Override
	public String remoteDebugJobFlow(PdcDto pdc, String selectAgent, long opTimeMills, boolean destroyRpc)
			throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().remoteDebugJobFlow(_pdc, selectAgent, opTimeMills, destroyRpc);
	}

	@Override
	public String remoteDebugJobFlowWithRC(PdcDto pdc, String selectAgent, long opTimeMills, boolean destroyRpc,
			Map<String, Object> runtimeContext) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().remoteDebugJobFlowWithRC(_pdc, selectAgent, opTimeMills, destroyRpc, runtimeContext);
	}

	@Override
	public String debugPdc(PdcDto pdc, String selectAgent, long opTimeMills, String attrName, boolean destroyRpc)
			throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().debugPDC(_pdc, selectAgent, opTimeMills, attrName, destroyRpc);
	}

	@Override
	public String debugPdcWithRC(PdcDto pdc, String selectAgent, long opTimeMills, String attrName,
			boolean destroyRpc, Map<String, Object> runtimeContext) throws Exception {
		PDC _pdc = fromDto(pdc, PDC.class);
		return getPDCMgr().debugPDCWithRC(_pdc, selectAgent, opTimeMills, attrName, destroyRpc, runtimeContext);
	}

	@Override
	public Map<String, String> getCurrentRmtLaunchInfo(String pollerUuid) throws Exception {
		return getPDCMgr().getCurrentRmtLaunchInfo(pollerUuid);
	}

	@Override
	public Map<String, String> getCurrentRmtLaunchInfo(String pollerUuid, String udfAttrName) throws Exception {
		return getPDCMgr().getCurrentRmtLaunchInfo(pollerUuid, udfAttrName);
	}

	@Override
	public ProgressDetail getCurrentRuntimeInfo(String pollerUuid) throws Exception {
		return getPDCMgr().getCurrentRuntimeInfo(pollerUuid);
	}

	@Override
	public ProgressDetail getUdfCurrentRuntimeInfo(String pollerUuid, String udfAttrName) throws Exception {
		return getPDCMgr().getUdfCurrentRuntimeInfo(pollerUuid, udfAttrName);
	}

	@Override
	public Throwable getCurrentRuntimeError(String pollerUuid) throws Exception {
		return getPDCMgr().getCurrentRuntimeError(pollerUuid);
	}

	@Override
	public Throwable getUdfCurrentRuntimeError(String pollerUuid, String udfAttrName) throws Exception {
		return getPDCMgr().getUdfCurrentRuntimeError(pollerUuid, udfAttrName);
	}

	@Override
	public void terminateRemoteDebug(String pollerUuid) throws Exception {
		getPDCMgr().terminateRemoteDebug(pollerUuid);
	}

	@Override
	public SqlMappingFlow getSqlMappingFlow(String pdcId) throws Exception {
		return getPDCMgr().getSqlMappingFlow(pdcId);
	}

	@Override
	public ViewMetaNode getViewMetaNode(String viewKey) throws Exception {
		return getPDCMgr().getViewMetaNode(viewKey);
	}

	@Override
	public SqlMappingFlow expandSourceSqlMappingFlow(String viewKey) throws Exception {
		return getPDCMgr().expandSourceSqlMappingFlow(viewKey);
	}

	@Override
	public SqlMappingFlow expandTragetSqlMappingFlow(String viewKey) throws Exception {
		return getPDCMgr().expandTragetSqlMappingFlow(viewKey);
	}

	@Override
	public PdcTableEntityDto getSqlMappingEntity(String pdcId) throws Exception {
		PDCTableEntity tableEntity = getPDCMgr().getSqlMappingEntity(pdcId);
		return toDto(tableEntity, PdcTableEntityDto.class);
	}

	@Override
	public List<String> getDesignAttributes(String pdcId) throws Exception {
		return getPDCMgr().getDesignAttributes(pdcId);
	}

	@Override
	public SqlMappingFlow reloadSqlMappingConfigFlow(String pdcId, String mappingConfigId, String angle)
			throws Exception {
		return getPDCMgr().reloadSqlMappingConfigFlow(pdcId, mappingConfigId, angle);
	}

	@Override
	public void savePdcSqlMappingFlow(String pdcId, String mappingConfigId, SqlMappingFlow flow) throws Exception {
		getPDCMgr().savePDCSqlMappingFlow(pdcId, mappingConfigId, flow);
	}
	
	@Override
	public PdcSqlMappingDto querySqlMapping(String pdcId) throws Exception {
		PDC pdc = getPDCMgr().getPDC(pdcId);
		PDCSqlMapping _sqlMapping = pdc.getSqlMapping();
		return toDto(_sqlMapping, PdcSqlMappingDto.class);
	}

	@Override
	public PdcDto queryPdfNodeInSummary(String nodeKey) throws Exception {
		ManagedData mo = dfcutil.getDfcIntf().getMo(nodeKey);
    	String pdcId = nodeKey;
    	if(mo instanceof PSMRef) {
    		pdcId = ((PSMRef) mo).getRelatePSM();
    	}
		return queryPdc(pdcId);
	}

	@Override
	public void deletePdcList(String id, List<String> ids) throws Exception {
		if(ids == null) {
			deletePdc(id);
		}else {
			for(String i : ids) {
				deletePdc(i);
			}
		}
	}

	@Override
	public MultiPageResultDto<PdcDto> queryPdcPageInPdf(String pdfId, String cdcId, List<Condition> filters,
			List<OrderBy> orderBy, int pageNo, int pageSize, String filtersKeyWord) throws Exception {
		MultiPageResultDto<PdcDto> rs = new MultiPageResultDto<PdcDto>();
		if(filters == null)
			filters = new ArrayList<>();
		if(!CmnUtil.isStringEmpty(filtersKeyWord)) {
			Condition contentCondition = getContentCondition(cdcId, filtersKeyWord);
			filters.add(contentCondition);
		}
		
		NameValuePair filter = Condition.toNameValuePair(filters);
		OrderByPair order = OrderBy.toOrderBy(orderBy);
		int startPos = (pageNo -1) * pageSize;
		String fullDn = dfcutil.getDfcIntf().getFullDN(pdfId);
		CDC cdc = getCDCMgr().getCDC(cdcId);
		Model model = dfcutil.getDfcIntf().getModelByClassName(MDUtil.getClassNameForMo(PSMRef.class));
		String querySql = "'"+cdc.getID().toLowerCase().replace("=","_")+"='"+"||"+"pid in (select "+MDConstants.getColumnPrefix()+PSMRef.attr_RelatePSM + " from t"+model.getTableName()+" where ppdn ='"+fullDn+"')";
		NameValuePair sqlQuery = new SqlNameValuePair(querySql,new ArrayList<>());
		NameValuePair pdfQuery = new LikeNameValuePair(PDC.attr_ParentPDF, pdfId);

		NameValuePair BaseQuery = new OrOPNameValue(ToolUtilities.newArrayList(sqlQuery,pdfQuery));
		List<NameValuePair> AndQuery = new ArrayList<NameValuePair>();
		AndQuery.add(BaseQuery);
		if(filter != null)
			AndQuery.add(filter);
		
		NameValuePair nvQuery = new AndOPNameValue(AndQuery);
 		MultiPageResult<PDC> pdcRs = getPDCMgr().pagingPDCByCondition(cdc.getName(), nvQuery, order, startPos, pageSize);
		rs.setTableData(BaseDtoUtil.getMe().transformObjects(pdcRs.getListData(), v->toDto(v, PdcDto.class)));
		rs.setTotal(pdcRs.getTotalCount());
		return rs;
	}

	@Override
	public ViewMetaNodeDto queryViewMetaNode(String pdcId, String viewKey) throws Exception {
		PDC pdc = getDCSAPIUtils().getPDCMgr().getPDC(pdcId);
		PDCSqlMapping sqlMapping = pdc.getSqlMapping();
		ViewMeta _viewMeta = sqlMapping.getViewMeta(viewKey);
		
		return BaseDtoUtil.getMe().toDto(_viewMeta);
		
	}


}
