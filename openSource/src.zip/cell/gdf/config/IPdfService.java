package cell.gdf.config;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Set;

import com.kwaidoo.dc.concrete.dto.CdfDto;
import com.kwaidoo.dc.config.ProductRequirement;
import com.kwaidoo.dc.config.ProductRequirementFlow;
import com.kwaidoo.dc.config.ProductRequirementFlowGraph;
import com.kwaidoo.dc.config.ProductRequirementRelatePdcFlow;
import com.kwaidoo.dc.config.dto.PdcDto;
import com.kwaidoo.dc.config.dto.PdfDto;
import com.kwaidoo.dc.config.dto.PdfFlowDto;
import com.kwaidoo.dc.config.dto.PdfNodeDto;
import com.kwaidoo.dc.config.dto.PdfSegmentFlowDto;
import com.kwaidoo.dc.config.dto.PdfViewDto;
import com.kwaidoo.dc.story.dto.StoryDto;
import com.kwaidoo.dc.tree.mgr.ProductDesign;
import com.kwaidoo.dc.tree.node.TreeNode;
import com.leavay.dc.develop.PDCBriefNode;
import com.leavay.model.inf.filter.NameValuePair;
import com.leavay.model.inf.sort.OrderByPair;
import com.leavay.ms.dcs.dto.RowDataDto;

import bap.cells.Cells;
import cell.web.SessionCellIntf;
import cmn.util.FlowLink;
import web.dto.MultiPageResultDto;
import web.dto.Pair;

public interface IPdfService extends SessionCellIntf{
	
	public static IPdfService get(String sessionKey) {
		return Cells.get(IPdfService.class, sessionKey);
	}
	
	public void ping() throws RemoteException;
	
	/**
	 * 指定CDF对象创建PDF
	 *
	 * @param cdf
	 *            CDF对象
	 * @param pdfName
	 *            PDF名称
	 * @return 创建后的PDF对象
	 * @throws Exception
	 */
	public  PdfDto createPdf(CdfDto cdf, String pdfName) throws Exception ;
	public PdfDto createPdf(ProductDesign pd,String pdfName)throws Exception;

	/**
	 * 创建PdfDto的依赖PdfDto镜像点
	 * 
	 * @param pdfId
	 *            依赖PdfDto对应的PdfDto的ID
	 * @param targetPdfId
	 *            要创建依赖PdfDto镜像点的PdfDto的ID
	 * @return 依赖PdfDto镜像点PDC
	 * @throws Exception
	 */
	public  PdcDto createMirrorPdf(String pdfId, String targetPdfId) throws Exception ;

	/**
	 * 更新PdfDto内容，通过PdfDto.addPDC(pdcName),PdfDto.deletePDC(pdcName),PdfDto.addLink(srcPDCName,dstPDCName),PdfDto.deleteLink(srcPDCName,dstPDCName)操作后更新
	 * 
	 * @param pdf
	 *            PdfDto对象
	 * @return PdfDto对象
	 * @throws Exception
	 */
	public  PdfDto updatePdf(PdfDto pdf) throws Exception ;
	
	public PdfFlowDto queryPdfFlow(String pdfId, String displayMode) throws Exception;
	
	public PdfFlowDto updatePdfFlow(PdfFlowDto pdfFlow,String updateOption)throws Exception ;
	
	public List<PdfNodeDto> importPdcNode(List<String> pdcList,String pdfId,String pdcType) throws Exception;

	public void updateSegmentOfPdf(String pdfId,List<String> deletePdcNames,List<FlowLink> deleteLinks,List<String> addPdcNames,List<String> addRefPdcNames,List<FlowLink> addLinks)throws Exception;

	public List<String> querySourcePdcGuids(String pdfId,String pdcGuid)throws Exception;
	
	/**
	 * 重命名PdfDto
	 * 
	 * @param pdfName
	 *            原PdfDto名称
	 * @param newPdfName
	 *            PdfDto新名称
	 * @return 重命名后的PdfDto对象
	 * @throws Exception
	 */
	public  PdfDto renamePdf(String pdfName, String newPdfName) throws Exception ;

	/**
	 * 根据PdfDto的ID获取PdfDto
	 * 
	 * @param pdfId
	 *            PdfDto的ID
	 * @return PdfDto对象
	 * @throws Exception
	 */
	public  PdfDto queryPdf(String pdfId) throws Exception ;
	
	public  MultiPageResultDto<PdfDto> queryPdfList(List<String> pdfIds) throws Exception ;

	public PdfNodeDto queryPdfNode(String pdfId,String nodeKey) throws Exception ;
	public List<PdfNodeDto> queryPdcNodeOfPdf(String pdfId) throws Exception ;
	
	public PdcDto queryPdcInfoByNodeKey(String pdfId,String nodeKey) throws Exception ;
	public PdfNodeDto updatePdcInPdfFlow(PdcDto data) throws Exception ;
	
	/**
	 * 根据PdfDto的名称获取PdfDto
	 * 
	 * @param pdfName
	 *            PdfDto的名称
	 * @return PdfDto对象
	 * @throws Exception
	 */
	public  PdfDto queryPdfByName(String pdfName) throws Exception ;

	/**
	 * 查询Story下的所有PdfDto
	 * 
	 * @param story
	 *            story对象
	 * @return PdfDto对象列表
	 * @throws Exception
	 */
	public  MultiPageResultDto<PdfDto> queryPdfOfStory(StoryDto story) throws Exception ;
	
	public  List<String> queryPdfIdOfStory(StoryDto story) throws Exception ;

	/**
	 * 查询指定CdfDto的PdfDto列表
	 * 
	 * @param cdf
	 *            CdfDto对象
	 * @return PdfDto列表
	 * @throws Exception
	 */
	public  MultiPageResultDto<PdfDto> queryPdfOfCdf(CdfDto cdf) throws Exception ;
	
	public List<String> queryPdfIdOfReferencePdc(String pdcId) throws Exception ;
	/**
	 * 获取被引用的PDC所在的PdfDto的摘要信息
	 * @param pdcId	 被引用的PDC的ID
	 * @return	PdfDto摘要信息列表
	 * @throws Exception
	 */
	public  List<PdfDto> queryPdfOfReferencePdc(String pdcId) throws Exception;

	/**
	 * 删除PdfDto
	 * 
	 * @param pdfId
	 *            PdfDto的ID
	 * @throws Exception
	 */
	public  void deletePdf(String pdfId) throws Exception ;

	/**
	 * 删除PdfDto
	 * 
	 * @param pdfName
	 *            PdfDto的名称
	 * @throws Exception
	 */
	public  void deletePdfByName(String pdfName) throws Exception ;

	/**
	 * 导出PdfDto数据包
	 * @param pdfId PdfDto的ID
	 * @param isExportCdcPdc	是否导出PDC数据
	 * @return
	 * @throws Exception
	 */
	public  Pair<String,byte[]> exportPdf(String pdfId, boolean isExportCdcPdc)
			throws Exception ;

	/**
	 * 根据名称判断数据是否是Pdf
	 * 
	 * @param name
	 *            数据的名称
	 * @return 是否PdfDto对象
	 * @throws Exception
	 */
	public  boolean isPdfGuid(String guid) throws Exception ;

	/**
	 * 根据ID判断数据是否PdfDto对象
	 * 
	 * @param id
	 *            数据的ID
	 * @return 是否PdfDto对象
	 * @throws Exception
	 */
	public  boolean isPdf(String id) throws Exception ;
	
	public PdfViewDto createPdfView(PdfViewDto pdfView)throws Exception;
	public PdfViewDto renamePdfView(String viewId,String name)throws Exception;
	public PdfViewDto queryPdfView(String viewId) throws Exception;
	public boolean isPdfView(String viewId)throws Exception;
	public PdfViewDto queryPdfViewByName(String pdfId,String name)throws Exception;
	public List<PdfViewDto> queryChildPdfViews(String pdfId,String viewId)throws Exception;
	public void deletePdfView(String viewId)throws Exception;
	public void move2PdfView(String pdfId,List<String> nodeIds,String viewId)throws Exception;
	public Set<String> queryReferencePdcIds(String pdfId)throws Exception;
	
	public PdfSegmentFlowDto expandPdfView(String pdfId,String pdfViewId,List<String> nodesKey,List<FlowLink> links)throws Exception;
	public PdfSegmentFlowDto shrinkPdfView(String pdfId,String pdfViewId,List<String> nodesKey,List<FlowLink> links)throws Exception;
	
	public List<TreeNode> getPdfViewTree(String pdfId,boolean lazyLoad)throws Exception;
	
	public ProductRequirementFlow queryProductRequirementFlow(String id)throws Exception;
	
	public ProductRequirementFlow queryProductRequirementFlowByPdf(String pdfId)throws Exception;
	
	public ProductRequirementFlowGraph queryProductRequirementFlowGraph(String id)throws Exception;
	
	public ProductRequirementFlowGraph queryProductRequirementFlowGraphByPdf(String pdfId)throws Exception;
	
	public ProductRequirementFlowGraph saveProductRequirementFlowGraph(ProductRequirementFlowGraph graph) throws Exception ;
	
	public ProductRequirementRelatePdcFlow queryProductRequirementRelatePdcFlow(String productReqId)throws Exception;
	
	public void createRelationOfProductRequirementAndPdc(ProductRequirement pr,List<String> pdcIds)throws Exception;
	
	ProductRequirement queryProductRequirement(String id)throws Exception;
	
	ProductRequirement createProductRequirement(ProductDesign pd,ProductRequirement pr)throws Exception;
	
	ProductRequirement updateProductRequirement(ProductRequirement pr)throws Exception;
	
	void bindPdc2ProductRequirement(String requirementId,List<String> nodeKeys)throws Exception;
	
	PdfNodeDto craetePDCNode(String pdfId, String requirementId, PdcDto pdc) throws Exception;
	
	void setDefaultValue(PdcDto pdc)throws Exception;
	
	PdfFlowDto querySummaryPDF(String id) throws Exception;
	
	public PDCBriefNode queryPDCBriefNode(String id) throws Exception ;
	
	public MultiPageResultDto<RowDataDto> pagePDCofPDF(String pdfId, NameValuePair condition, OrderByPair orderBy, int pageNo, int pageSize) throws Exception;
	
	public List<PdcDto> queryPdcofPdf(String pdfId) throws Exception;
	
	/**
	 * 查询pdf上pdc的所有来源与目标节点
	 * @param pdfId
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public List<PdcDto> queryPdcSourceAndTarget(String pdfId,String key) throws Exception;
	
}