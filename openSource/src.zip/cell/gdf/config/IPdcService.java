package cell.gdf.config;

import java.io.File;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.kwaidoo.dc.concrete.dto.CdcDto;
import com.kwaidoo.dc.config.dto.ColumnDto;
import com.kwaidoo.dc.config.dto.PdcDto;
import com.kwaidoo.dc.config.dto.PdcSqlMappingDto;
import com.kwaidoo.dc.config.dto.PdcTableEntityDto;
import com.kwaidoo.dc.config.dto.PdfDto;
import com.kwaidoo.dc.config.dto.ViewMetaNodeDto;
import com.kwaidoo.dc.develop.SqlMappingFlow;
import com.kwaidoo.dc.develop.SqlMappingRuntimeParam;
import com.kwaidoo.dc.develop.ViewMetaNode;
import com.kwaidoo.dc.dto.BaseDto;
import com.kwaidoo.dc.setting.dto.DBDataSourceDto;
import com.kwaidoo.dc.setting.dto.DataSetDefDto;
import com.kwaidoo.dc.utils.ProgressDetail;
import com.leavay.common.util.KeyValuePair;
import com.leavay.dfc.gui.component.JdbcMetaInfo;
import com.project.gui.common.DBDataSourceIntf;

import bap.cells.Cells;
import cell.CellIntf;
import cell.web.SessionCellIntf;
import web.dto.MultiPageResultDto;
import web.dto.Pair;
import web.vo.Condition;
import web.vo.OrderBy;

public interface IPdcService extends SessionCellIntf {
	
	public static IPdcService get(String sessionKey) {
		return Cells.get(IPdcService.class, sessionKey);
	}
	
	public void ping() throws RemoteException;
	
	/**
	 * 根据CdcDto构建内存中的PdcDto对象
	 * 
	 * @param cdcId
	 *            CdcDto的ID
	 * @return 内存中的PdcDto对象
	 * @throws Exception
	 */
	public PdcDto newPdcByCdc(String cdcId) throws Exception;
	/**
	 * 根据CdcDto构建内存中的PdcDto对象
	 * @param cdc	CdcDto对象
	 * @return	内存中的PdcDto对象
	 * @throws Exception
	 */
	public PdcDto newPdcByCdc(CdcDto cdc) throws Exception;

	/**
	 * 创建PdcDto
	 * 
	 * @param pdc
	 *            内存中的PdcDto对象
	 * @return 创建成功的PdcDto对象
	 * @throws Exception
	 */
	public PdcDto createPdc(PdcDto pdc) throws Exception;
	/**
	 * 自动构建PDC，在PDC创建或更新时调用自动构建的校验和构建规则
	 * @param buildMode
	 * @param pdc
	 * @return
	 * @throws Exception
	 */
	public PdcDto autoBuildPDc(String buildMode,PdcDto pdc)throws Exception;
	
	/**
	 * 创建指定PdcDto的镜像节点PdcDto
	 * 
	 * @param pdcId
	 *            PdcDto的ID
	 * @param targetPdfId
	 *            要创建PdcDto镜像点的PdfDto的ID
	 * @return PdcDto的镜像点
	 * @throws Exception
	 */
	public PdcDto createMirrorPdc(String pdcId, String targetPdfId) throws Exception;

	/**
	 * 根据PdcDto的ID获取PdcDto对象
	 * 
	 * @param id
	 *            PdcDto的ID
	 * @return PdcDto对象
	 * @throws Exception
	 */
	public PdcDto queryPdc(String id) throws Exception;
	public PdcDto queryPdcWithViewId(String id, String viewId) throws Exception;
	
	/**
	 * 通过名称查出对应的PdcDto
	 * 
	 * @param guid
	 *            PdcDto的名称
	 * @return PdcDto对象
	 * @throws Exception
	 */
	public PdcDto queryPdcByGuid(String guid) throws Exception;

	/**
	 * 通过PdcDto的ID获取PdcDto的GUID
	 * 
	 * @param pdcId
	 *            PdcDto的ID
	 * @return PdcDto的GUID
	 * @throws Exception
	 */
	public String queryGuidById(String pdcId) throws Exception;
	/**
	 * 通过PdcDto的guid获取PdcDto的id
	 * 
	 * @param guid
	 *            PdcDto的guid
	 * @return PdcDto的id
	 * @throws Exception
	 */
	public String queryIdByGuid(String guid)throws Exception;
	/**
	 * 根据CdcDto名称获取底下所有PdcDto的Guid列表
	 * @param cdcName	CdcDto名称
	 * @return	Guid列表
	 * @throws Exception
	 */
	public List<String> queryGuidsByCdcName(String cdcName)throws Exception;

	/**
	 * 获取PdcDto列表
	 * 
	 * @param pdcIds
	 *            PdcDto的ID列表
	 * @return PdcDto对象列表
	 * @throws Exception
	 */
	public MultiPageResultDto<PdcDto> queryPdcs(List<String> pdcIds) throws Exception;

	/**
	 * 获取PdcDto列表
	 * 
	 * @param guids
	 *            guid列表
	 * @return PdcDto对象列表
	 * @throws Exception
	 */
	public MultiPageResultDto<PdcDto> queryPdcByGuids(List<String> guids) throws Exception;
	/**
	 * 查询工位枚举列表，包含 value 和labe两个属性
	 * @param cdcId
	 * @return
	 * @throws Exception
	 */
	public MultiPageResultDto<BaseDto> queryPdcEnums(String cdcId)throws Exception;

	/**
	 * 通过CdcDto名称查出对应的所有PdcDto
	 * 
	 * @param cdcName
	 *            CdcDto的名称
	 * @return PdcDto对象集合
	 * @throws Exception
	 */
	public MultiPageResultDto<PdcDto> queryAllPdcByCdcName(String cdcName) throws Exception;

	/**
	 * 通过CdcDto名称集合查出对应的所有PdcDto
	 * 
	 * @param cdcNameLst
	 *            CdcDto名称集合
	 * @return PdcDto对象集合
	 * @throws Exception
	 */
	public MultiPageResultDto<PdcDto> queryAllPdcbyCdcName(List<String> cdcNameLst) throws Exception;

	/**
	 * 通过CdcDto名称，查询条件、排序规则查出对应的所有PdcDto
	 * 
	 * @param cdcName
	 *            CdcDto的名称
	 *            
	 * @param condition
	 * 
	 * @param orderBy
	 * 
	 * @return PdcDto对象集合
	 * @throws Exception
	 */
	public MultiPageResultDto<PdcDto> queryPdcByCondition(String cdcName, List<Condition> condition, List<OrderBy> orderBy) throws Exception;
	/**
	 * 根据PdcDto名称关键字查询匹配的PdcDto名称列表
	 * @param keyWord	PdcDto名称关键字
	 * @return	 PdcDto名称列表
	 * @throws Exception
	 */
	public List<String> queryPdcGuidsByKeyWord(String keyWord) throws Exception;
	/**
	 * 通过CdcDto名称，查询条件、排序规则查出对应的PdcDto分页结果
	 * 
	 * @param cdcId
	 *            CdcDto的id
	 * @param filters
	 * @param orderBy
	 * @param pageNo
	 * @param pageSize
	 *            分页大小
	 * @param filtersKeyWord
	 * @return PdcDto对象分页查询结果
	 * @throws Exception
	 */
	public MultiPageResultDto<PdcDto> queryPdcPage(String cdcId, List<Condition> filters, List<OrderBy> orderBy,
			int pageNo, int pageSize,String filtersKeyWord) throws Exception;

	/**
	 * 通过CdcDto名称集合，查询条件、排序规则查出对应的PdcDto分页结果
	 * 
	 * @param cdcNameLst
	 *            CdcDto名称集合
	 * @param condition
	 * @param orderBy
	 * @param pageNo
	 *            分页开始位置
	 * @param pageSize
	 *            分页大小
	 * @return PdcDto对象分页查询结果
	 * @throws Exception
	 */
	public MultiPageResultDto<PdcDto> queryPdcPageOfCdcList(List<String> cdcNameLst, List<Condition> condition, List<OrderBy> orderBy, int pageNo, int pageSize) throws Exception;

	/**
	 * 通过CdcDto名称集合，查询条件、排序规则查出对应的PdcDto分页结果
	 * 
	 * @param cdcNameLst
	 *            Cdc名称集合
	 * @param nvQueryMap
	 *            查询条件Map，key：Cdc名称，vlaue:查询条件
	 * @param condition
	 * @param orderBy
	 * @param pageNo
	 *            分页开始位置
	 * @param pageSize
	 *            分页大小
	 * @return PdcDto对象分页查询结果
	 * @return
	 * @throws Exception
	 */
	public MultiPageResultDto<PdcDto> queryPdcOfCdcListByConditionMap(List<String> cdcNameLst,
			Map<String, List<Condition>> conditionMap, List<OrderBy> orderBy, int pageNo, int pageSize) throws Exception;

	/**
	 * 更新PdcDto
	 * 
	 * @param pdc
	 *            修改或的PdcDto
	 * @return 更新成功的PdcDto对象
	 * @throws Exception
	 */
	public PdcDto updatePdc(PdcDto pdc) throws Exception;
	public PdcDto updatePdcWithViewId(PdcDto pdc) throws Exception;
	
	public PdcDto importPdc(PdcDto pdc) throws Exception;

	/**
	 * 更新PdcDto的附件
	 * 
	 * @param pdcId
	 *            PdcDto的ID
	 * @param attrName
	 *            附件属性名称
	 * @param attachFile
	 *            附件文件
	 * @return 更新后的PdcDto对象
	 * @throws Exception
	 */
	public PdcDto updatePdcAttachmentDto(String pdcId, String attrName, File attachFile) throws Exception;

	/**
	 * 获取PdcDto的附件属性内容
	 * 
	 * @param pdcId
	 *            PdcDto的ID
	 * @param attrName
	 *            附件属性
	 * @return 文件名和数据字节数组
	 * @throws Exception
	 */
	public Pair<String, byte[]> queryPdcAttachmentDto(String pdcId, String attrName) throws Exception;

	/**
	 * 更新SQL数据映射
	 * 
	 * @param pdc
	 *            PdcDto对象
	 * @param sqlMapping
	 *            SQL数据映射对象
	 * @return 更新后的PdcDto对象
	 * @throws Exception
	 */
	public PdcDto updatePdcSqlMapping(PdcDto pdc, PdcSqlMappingDto sqlMapping) throws Exception;
	
	public PdcDto updatePdcSqlMappingAndRemoveDirty(PdcDto pdc, PdcSqlMappingDto sqlMapping) throws Exception;

	/**
	 * 根据PdcDto的ID删除PdcDto
	 * 
	 * @param id
	 *            PdcDto的ID
	 * @throws Exception
	 */
	public void deletePdc(String id) throws Exception;
	
	public void deletePdcList(String id,List<String> ids) throws Exception;

	/**
	 * 传入PdcDto的名称删除PdcDto
	 * 
	 * @param guid
	 *            PdcDto的名称
	 * @throws Exception
	 */
	public void deletePdcByGuid(String guid) throws Exception;

	/**
	 * 从已有的PdcDto复制配置参数生成新的PdcDto，可配置额外的参数
	 * 
	 * @param newPdcGuid
	 *            目标PdcDto名称
	 * @param srcPdc
	 *            复制源PdcDto对象
	 * @param attrValueMap
	 *            额外的配置参数，选填
	 * @return 复制生成的PdcDto对象
	 * @throws Exception
	 */
	public PdcDto copyPdc(String newPdcGuid, PdcDto srcPdc, Map attrValueMap) throws Exception;
	
	public PdcDto copySqlMapping(PdcDto srcPdc,PdcDto dstPdc,boolean rebuildMainOutput,boolean ignoreComplieError) throws Exception;

	/**
	 * 从已有的PdcDto复制配置参数生成其他CdcDto下新的PdcDto，可配置额外的参数
	 * 
	 * @param cdc
	 *            目标CdcDto对象
	 * @param newPdcGuid
	 *            目标PdcDto名称
	 * @param srcPdc
	 *            复制源PdcDto对象
	 * @param attrValueMap
	 *            额外的配置参数，选填
	 * @return 复制生成的PdcDto对象
	 * @throws Exception
	 */
	public PdcDto copyPdcToOtherCdc(CdcDto cdc, String newPdcGuid, PdcDto srcPdc, Map attrValueMap) throws Exception;

	/**
	 * 获取指定CdcDto的全文检索查询条件
	 * 
	 * @param cdcId
	 *            CdcDto的ID
	 * @param sSearchText
	 *            搜索关键字，可使用*作为通配符
	 * @return 对应CdcDto的全文检索查询条件
	 * @throws Exception
	 */
	public Condition getContentCondition(String cdcId, String sSearchText) throws Exception;

	/**
	 * 导出数据包
	 * 
	 * @param cdcIds
	 *            CdcDto的ID列表
	 * @param nvQuery
	 *            查询条件
	 * @return 文件名和数据字节数组
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportPdc(List<String> cdcIds, List<Condition> condition) throws Exception;
	/**
	 * 导出PdcDto数据
	 * @param pdcNames	PdcDto名称列表
	 * @param exportRelInPdf	是否导出在PdfDto的关联关系
	 * @return	文件名和数据字节数组
	 * @throws Exception
	 */
	public Pair<String,byte[]> exportPdc(List<String> pdcNames,boolean exportRelInPdf) throws Exception ;

	/**
	 * PdcDto是否是镜像点
	 * 
	 * @param guid
	 *            PdcDto名称
	 * @return 是否镜像点
	 * @throws Exception
	 */
	public boolean isMirrorPdc(String guid) throws Exception;

	/**
	 * PdcDto是否镜像点
	 * 
	 * @param pdc
	 *            PdcDto对象
	 * @return 是否镜像点
	 * @throws Exception
	 */
	public boolean isMirrorPdc(PdcDto pdc) throws Exception;

	/**
	 * PdcDto是否PdfDto对象
	 * 
	 * @param pdc
	 *            PdcDto对象
	 * @return 是否PdfDto对象
	 */
	public boolean isPdfDto(PdcDto pdc) throws Exception;

	/**
	 * 导出表实体的列定义内容
	 * 
	 * @param tableEntityDefName
	 *            表实体的类型名称
	 * @param columns
	 *            表实体的列定义内容
	 * @return 文件名和数据字节数组
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportTableEntityColumn(String tableEntityDefName, List<ColumnDto> columns)
			throws Exception;

	/**
	 * 从excel文件读取列定义内容
	 * 
	 * @param excelFile
	 *            来源excel文件
	 * @param tableEntityDefName
	 *            表实体的实体定义名称
	 * @return 列定义内容
	 * @throws Exception
	 */
	public List<ColumnDto> importTableEntityColumn(File excelFile, String tableEntityDefName)
			throws Exception;

	/**
	 * 获取PdcDto中表实体属性的建表SQL
	 * 
	 * @param pdc
	 *            PdcDto对象
	 * @param attrName
	 *            表实体属性名称
	 * @return 建表SQL语句
	 * @throws Exception
	 */
	public String getCreateSql(PdcDto pdc, String attrName) throws Exception;

	/**
	 * 测试PdcDto中表实体属性的建表SQL是否正常执行
	 * 
	 * @param pdc
	 *            PdcDto对象
	 * @param attrName
	 *            表实体属性名称
	 * @return 测试结果
	 * @throws Exception
	 */
	public String testCreateSql(PdcDto pdc, String attrName) throws Exception;

	/**
	 * 将数据集内容导出
	 * 
	 * @param dataSetDef
	 *            数据集定义
	 * @param rows
	 *            数据集内容
	 * @return 文件名和数据字节数组
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportDataSetContent(DataSetDefDto dataSetDef, List<Map<String, String>> rows)
			throws Exception;

	/**
	 * 配置SQL PdcDto的来源表
	 * 
	 * @param pdc
	 *            SQL PdcDto
	 * @param pdf
	 *            选择的PdfDto
	 * @param pdcLst
	 *            来源表PdcDto列表
	 * @return 更新后的SQL PdcDto对象
	 * @throws Exception
	 */
	public PdcDto configSourceTableOfSqlPdc(PdcDto pdc, PdfDto pdf, List<PdcDto> pdcLst) throws Exception;

	/**
	 * 配置SQL PdcDto的来源表
	 * 
	 * @param pdc
	 *            SQL PdcDto
	 * @param pdfId
	 *            选择的PdfDto的ID
	 * @param pdcIds
	 *            来源表PdcDto的ID列表
	 * @return 更新后的SQL PdcDto对象
	 * @throws Exception
	 */
	public PdcDto configSourceTableOfSqlPdc(PdcDto pdc, String pdfId, List<String> pdcIds) throws Exception;

	/**
	 * 获取数据映射作业参数定义
	 * @param pdcId
	 * @return
	 * @throws Exception
	 */
	public SqlMappingRuntimeParam getSqlMappingRuntimeParam(String pdcId)throws Exception;
	/**
	 * 更新数据映射作业参数定义
	 * @param pdcId
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SqlMappingRuntimeParam updateSqlMappingRuntimeParam(String pdcId,SqlMappingRuntimeParam data)throws Exception;
	/**
	 * 获取SQL PdcDto的所有输出表SQL
	 * 
	 * @param pdc
	 *            SQL PdcDto对象
	 * @return 所有输出表SQL，包括序号（NO）、来源表（SOURCE_TABLE）、SQL、描述（DESC）
	 * @throws Exception
	 */
	public List<Map<String, String>> getOutputSqlOfSqlPdc(PdcDto pdc) throws Exception;
	/**
	 * 构建SQL数据映射中指定视图的SQL语句
	 * @param pdc	SQL PdcDto对象
	 * @param viewName	视图名称
	 * @param opTime	数据时间
	 * @return	构建好的SQL语句
	 * @throws Exception
	 */
	public String buildSqlOfSqlPdc(PdcDto pdc,String viewName,long opTime) throws Exception ;
	
	public String buildSqlOfSqlPdc(PdcDto pdc,String viewName,long opTime,boolean preview) throws Exception ;
	
	public String buildSqlOfSqlPdcWithDS(DBDataSourceIntf ds,PdcDto pdc,String viewName,long opTime,boolean preview) throws Exception ;
	
	public String buildSqlOfSqlPdcWithOutReplaceParameter(PdcDto pdc, String viewName, boolean preview) throws Exception ;
	
	public String buildWithSqlOfSqlPdc(PdcDto pdc,String viewName,long opTime) throws Exception ;

	public String buildWithSqlOfSqlPdc(PdcDto pdc,String viewName,long opTime,boolean preview) throws Exception ;
	
	public String buildWithSqlOfSqlPdcWithDS(DBDataSourceIntf ds,PdcDto pdc,String viewName,long opTime,boolean preview) throws Exception ;
	
	public String buildWithSqlOfViewInSqlMapping(PdcDto pdc, String viewName, boolean preview) throws Exception ;
	/**
	 * 试运行SQL
	 * @param pdc	SQL PdcDto对象
	 * @param viewName	视图名称
	 * @param sSql	SQL语句
	 * @param rows	查询记录数
	 * @return	查询结果
	 * @throws Exception
	 */
	public Pair<List<JdbcMetaInfo>, List<List<String>>> testQuerySql(PdcDto pdc, String viewName,String sSql, int rows) throws Exception;

	public Pair<List<JdbcMetaInfo>, List<List<String>>> testQuerySql(PdcDto pdc,DBDataSourceIntf ds,String sSql, int rows) throws Exception;
	/**
	 * 通过代理试运行SQL，返回代理执行日志的进度uuid
	 * @param selectAgent
	 * @param ds 
	 * @param pdc
	 * @param sSql
	 * @param rows
	 * @return
	 * @throws Exception
	 */
	public String testRunQuerySqlByAgent(String selectAgent, DBDataSourceIntf ds, PdcDto pdc,String sSql, int rows) throws Exception;
	
	public String testRunQuerySqlByAgent2(String selectAgent,DBDataSourceDto ds, PdcDto pdc,String sSql, int rows) throws Exception;
	
	public Pair<List<JdbcMetaInfo>, List<List<String>>> testGetQueryResultFromAgent(String uuid) throws Exception;
	/**
	 * 在PdcDto保存前调用Story中的合规行检查方法SUDF，用于设置默认值或者进行数据内容检查
	 * 
	 * @param pdc
	 *            保存前的PdcDto数据
	 * @return 检查后的pdc数据
	 * @throws Exception
	 */
	public PdcDto beforeSavedPdcDto(PdcDto pdc) throws Exception;
	
	public PdcDto beforeSavedPdcDtoByDefault(PdcDto pdc) throws Exception ;

	/**
	 * 在PdcDto保存成功之后调用Story中的重建血缘关系方法SUDF，用于重建PdcDto的血缘关系或配置一些联动保存的PdcDto数据
	 * 
	 * @param guid
	 *            保存成功的PdcDto的guid
	 * @throws Exception
	 */
	public void onAfterSavedPdcDto(String guid) throws Exception;
	
	public void onAfterSavedPdcDtoByDefault(String buildMode,String guid) throws Exception ;

	/**
	 * 获取所有可执行的代理
	 * 
	 * @return 可执行的代理列表
	 * @throws Exception
	 */
	public List<KeyValuePair> queryAllSelectableAgents() throws Exception;

	/**
	 * 远程调试PdcDto上的UDF，返回远程调试轮询器的uuid
	 * 
	 * @param pdc
	 *            PdcDto对象
	 * @param attrName
	 *            UDF属性名
	 * @param selectAgent
	 *            远程调试的代理
	 * @param opTimeMills
	 *            数据时间毫秒值
	 * @param destroyRpc
	 *            执行完成时是否自动销毁RPC
	 * @return 远程调试轮询器的uuid
	 * @throws Exception
	 */
	public String remoteDebugSUDF(PdcDto pdc, String attrName, String selectAgent, long opTimeMills, boolean destroyRpc)
			throws Exception;

	/**
	 * 远程调试PdcDto上的UDF，返回远程调试轮询器的uuid(可通过$RC$参数携带可序列化对象，在UDF内接收)
	 *
	 * @param pdc
	 *            PdcDto对象
	 * @param attrName
	 *            UDF属性名
	 * @param selectAgent
	 *            远程调试的代理
	 * @param opTimeMills
	 *            数据时间毫秒值
	 * @param destroyRpc
	 *            执行完成时是否自动销毁RPC
	 * @param runtimeContext
	 *            调用过程传输的上下文参数，可在UDF内接收
	 * @return 远程调试轮询器的uuid
	 * @throws Exception
	 */
	public String remoteDebugSUDFWithRC(PdcDto pdc, String attrName, String selectAgent, long opTimeMills, boolean destroyRpc, Map<String,Object> runtimeContext)
			throws Exception;
	
	/**
	 * 远程调试PdcDto上的作业定义，返回远程调试轮询器的uuid
	 * 
	 * @param pdc
	 *            PdcDto对象
	 * @param selectAgent
	 *            远程调试的代理
	 * @param opTimeMills
	 *            数据时间毫秒值
	 * @param destroyRpc
	 *            执行完成时是否自动销毁RPC
	 * @return 远程调试轮询器的uuid
	 * @throws Exception
	 */
	public String remoteDebugJobFlow(PdcDto pdc, String selectAgent, long opTimeMills, boolean destroyRpc)
			throws Exception;

	/**
	 * 远程调试PdcDto上的作业定义，返回远程调试轮询器的uuid(可通过$RC$参数携带可序列化对象，在UDF内接收)
	 *
	 * @param pdc
	 *            PdcDto对象
	 * @param selectAgent
	 *            远程调试的代理
	 * @param opTimeMills
	 *            数据时间毫秒值
	 * @param destroyRpc
	 *            执行完成时是否自动销毁RPC
	 * @param runtimeContext
	 *            调用过程传输的上下文参数，可在UDF内接收
	 * @return 远程调试轮询器的uuid
	 * @throws Exception
	 */
	public String remoteDebugJobFlowWithRC(PdcDto pdc, String selectAgent, long opTimeMills, boolean destroyRpc,Map<String,Object> runtimeContext)
			throws Exception;

	/**
	 * 调试PdcDto上指定或所有作业定义，返回远程调试轮询器的uuid
	 * @param pdc
	 *            PdcDto对象
	 * @param selectAgent
	 *            远程调试的代理
	 * @param opTimeMills
	 *            数据时间毫秒值
	 * @param attrName
	 *            指定调试的UDF属性名称，$ALL$为按序调试所有UDF
	 * @param destroyRpc
	 *            执行完成时是否自动销毁RPC
	 * @return 远程调试轮询器的uuid
	 * @throws Exception
	 */
	public String debugPdc(PdcDto pdc,String selectAgent,long opTimeMills,String attrName, boolean destroyRpc)throws Exception;

	/**
	 * 调试PdcDto上指定或所有作业定义，返回远程调试轮询器的uuid(可通过$RC$参数携带可序列化对象，在UDF内接收)
	 * @param pdc
	 *            PdcDto对象
	 * @param selectAgent
	 *            远程调试的代理
	 * @param opTimeMills
	 *            数据时间毫秒值
	 * @param attrName
	 *            指定调试的UDF属性名称，$ALL$为按序调试所有UDF
	 * @param destroyRpc
	 *            执行完成时是否自动销毁RPC
	 * @param runtimeContext
	 *            调用过程传输的上下文参数，可在UDF内接收
	 * @return 远程调试轮询器的uuid
	 * @throws Exception
	 */
	public String debugPdcWithRC(PdcDto pdc,String selectAgent,long opTimeMills,String attrName, boolean destroyRpc,Map<String,Object> runtimeContext)throws Exception;

		/**
		 * 获取远程调试当前的trace日志和报错信息
		 *
		 * @param pollerUuid
		 *            远程调试轮询器的uuid
		 * @return 远程调试当前的trace日志和报错信息、返回结果
		 * @throws Exception
		 */
	public Map<String, String> getCurrentRmtLaunchInfo(String pollerUuid) throws Exception;
	
	/**
	 * 获取远程调试当前的trace日志和报错信息,指定UDF
	 * 
	 * @param pollerUuid
	 *            远程调试轮询器的uuid
	 * @param udfAttrName
	 *            PdcDto上UDF的属性名
	 * @return 远程调试当前的trace日志和报错信息、返回结果
	 * @throws Exception
	 */
	public Map<String, String> getCurrentRmtLaunchInfo(String pollerUuid, String udfAttrName) throws Exception;
	
	public ProgressDetail getCurrentRuntimeInfo(String pollerUuid) throws Exception;
	
	public ProgressDetail getUdfCurrentRuntimeInfo(String pollerUuid, String udfAttrName) throws Exception;

	public Throwable getCurrentRuntimeError(String pollerUuid) throws Exception;

	public Throwable getUdfCurrentRuntimeError(String pollerUuid, String udfAttrName) throws Exception;

	/**
	 * 终止远程调试
	 * 
	 * @param pollerUuid
	 *            远程调试轮询器的uuid
	 * @throws Exception
	 */
	public void terminateRemoteDebug(String pollerUuid) throws Exception;

	/**
	 * 获取当前PdcDto的数据映射视图
	 * @param pdcId
	 * @return
	 * @throws Exception
	 */
	public SqlMappingFlow getSqlMappingFlow(String pdcId)throws Exception;
	
	public ViewMetaNode getViewMetaNode(String viewKey) throws Exception;
	
	public ViewMetaNodeDto queryViewMetaNode(String pdcId,String viewKey)throws Exception;
	/**
	 * 展开来源表的数据映射视图
	 * @param viewKey
	 * @return
	 * @throws Exception
	 */
	public SqlMappingFlow expandSourceSqlMappingFlow(String viewKey)throws Exception;
	/**
	 * 展开输出表的数据映射视图
	 * @param viewKey
	 * @return
	 * @throws Exception
	 */
	public SqlMappingFlow expandTragetSqlMappingFlow(String viewKey)throws Exception;
	
	/**
	 * 获取PdcDto中的sqlMapping类型实体
	 * @param pdcId
	 * @return
	 * @throws Exception
	 */
	public PdcTableEntityDto getSqlMappingEntity(String pdcId) throws Exception;
	/**
	 * 获取PdcDto的产品设计属性列表
	 * @param pdcId
	 * @return
	 * @throws Exception
	 */
	public List<String> getDesignAttributes(String pdcId)throws Exception;
	/**
	 * 重新加载PdcDto数据映射配置
	 * @param pdcId
	 * @param mappingConfigId
	 * @param angle
	 * @return
	 * @throws Exception
	 */
	public SqlMappingFlow reloadSqlMappingConfigFlow(String pdcId,String mappingConfigId,String angle) throws Exception;
	/**
	 * 保存PdcDto数据映射配置
	 * @param pdcId
	 * @param mappingConfigId
	 * @param flow
	 * @throws Exception
	 */
	public void savePdcSqlMappingFlow(String pdcId,String mappingConfigId,SqlMappingFlow flow)throws Exception;
	
	/**
	 * 查询Pdc的数据映射
	 * 
	 * @param pdcId
	 * @return
	 * @throws Exception
	 */
	public PdcSqlMappingDto querySqlMapping(String pdcId)throws Exception;
	
	/**
	 * 根据nodeKey查询Pdc
	 * 
	 * @param nodeKey
	 * @return
	 * @throws Exception
	 */
	public PdcDto queryPdfNodeInSummary(String nodeKey) throws Exception;
	
	MultiPageResultDto<PdcDto> queryPdcPageInPdf(String pdfId,String cdcId, List<Condition> filters, List<OrderBy> orderBy,
			int pageNo, int pageSize,String filtersKeyWord)throws Exception;
	
}