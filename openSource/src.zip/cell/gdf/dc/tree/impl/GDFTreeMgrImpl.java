package cell.gdf.dc.tree.impl;

import java.rmi.RemoteException;
import java.util.*;

import com.kwaidoo.dc.BaseSecurityMgr;
import com.kwaidoo.dc.config.dto.SudfDto;
import com.kwaidoo.dc.design.ProductLineTemplate;
import com.kwaidoo.dc.design.ProductlineTemplateImportData;
import com.kwaidoo.dc.tree.mgr.GDFCatalog;
import com.kwaidoo.dc.tree.mgr.ProductDesign;
import com.kwaidoo.dc.tree.mgr.TreeNodeExtendCfg;
import com.kwaidoo.dc.tree.node.GdfTreeConst;
import com.kwaidoo.dc.tree.node.TreeNode;
import com.kwaidoo.ms.tool.ToolUtilities;
import com.kwaidoo.tree.dto.TreeNodeDto;
import com.kwaidoo.tree.proc.impl.BaseTreeNodeDtoProc;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dc.exception.DCExceptionUtils;
import com.leavay.model.exception.McException;
import com.leavay.model.inf.filter.NameValuePair;
import com.leavay.model.inf.sort.OrderByPair;

import cell.gdf.dc.tree.GDFTreeMgr;
import cell.gdf.design.IProductLineTemplateService;
import cell.gdf.develop.ISudfService;
import cell.gdf.webframe.IWebConfigService;
import web.dto.ControllerDto;
import web.dto.MultiPageResultDto;
import web.vo.OrderBy;

public class GDFTreeMgrImpl extends BaseSecurityMgr implements GDFTreeMgr {

	private com.kwaidoo.dc.tree.mgr.GDFTreeMgr getGDFTreeMgr() throws Exception {
		return getDCSAPIUtils().getGDFTreeMgr();
	}
	
	private IProductLineTemplateService getProductLineTemplateMgr() throws Exception {
		return getApiUtils().getMgr(IProductLineTemplateService.class);
	}
	
	private ISudfService getSudfMgr() throws Exception {
		return getApiUtils().getMgr(ISudfService.class);
	}
	
	private IWebConfigService getIWebConfigMgr() throws Exception {
		return getApiUtils().getMgr(IWebConfigService.class);
	}
	
	@Override
	public GDFCatalog queryChildRealMoCatalog(String pCtlId, String childNodeType, String realMoId) throws Exception {
		return getGDFTreeMgr().getChildRealMoCatalog(pCtlId, childNodeType, realMoId);
	}
	
	@Override
	public List<GDFCatalog> queryAllChildRealMoCatalogs(String sRDN, String childNodeType, String realMoId)
			throws Exception {
		return getGDFTreeMgr().getAllChildRealMoCatalogs(sRDN, childNodeType, realMoId);
	}
	
	@Override
	public List<GDFCatalog> queryAllChildRealMoCatalogsInStyle(String catalogStyle, String realMoId) throws Exception {
		return getGDFTreeMgr().getAllChildRealMoCatalogsInStyle(catalogStyle, realMoId);
	}
	
	@Override
	public boolean isEnableProductDesign(String uuid) throws Exception {
		return getGDFTreeMgr().isEnableProductDesign(uuid);
	}
	
	@Override
	public GDFCatalog queryJobStasticRoot() throws Exception {
		return getGDFTreeMgr().getJobStasticRoot();

	}


	@Override
	public GDFCatalog queryCatalogByUuid(String uuid) throws Exception {
		return getGDFTreeMgr().getCatalogByUuid(uuid);
	}

	@Override
	public GDFCatalog queryCoreProductlineCatalog() throws Exception {
		return getGDFTreeMgr().getCoreProductlineCatalog();
	}

	@Override
	public GDFCatalog queryChildCatalogByType(String pId, String nodeType) throws Exception {
		return getGDFTreeMgr().getChildCatalogByType(pId, nodeType);
	}

	@Override
	public GDFCatalog queryChildCatalogByName(String id, String name) throws Exception {
		return getGDFTreeMgr().getChildCatalogByName(id, name);
	}

	@Override
	public GDFCatalog queryDFDesignCatalog(GDFCatalog workshopCtl) throws Exception {
		return getGDFTreeMgr().getDFDesignCatalog(workshopCtl);
	}

	@Override
	public GDFCatalog queryConfigCatalog(GDFCatalog workshopCtl) throws Exception {
		return getGDFTreeMgr().getConfigCatalog(workshopCtl);
	}

	@Override
	public GDFCatalog queryDistributeCatalog(GDFCatalog workshopCtl) throws Exception {
		return getGDFTreeMgr().getDistributeCatalog(workshopCtl);
	}

	@Override
	public List<TreeNode> queryChildTreeNodeList(String id, boolean lazyLoad) throws Exception {
		return getGDFTreeMgr().getChildTreeNodeList(id, lazyLoad);
	}

	@Override
	public List<TreeNode> queryCoreProductLineTree(boolean lazyLoad) throws Exception {
		return getGDFTreeMgr().getCoreProductLineTree(lazyLoad);
	}

	@Override
	public TreeNode createTreeNode(TreeNode node) throws Exception {
		return getGDFTreeMgr().createTreeNode(node);
	}

	@Override
	public TreeNode updateTreeNode(TreeNode node) throws Exception {
		return getGDFTreeMgr().updateTreeNode(node);
	}

	@Override
	public void deleteTreeNode(String nodeId) throws Exception {
		getGDFTreeMgr().deleteTreeNode(nodeId);

	}

	@Override
	public List<TreeNode> queryAdcInAdfTree(String adfId, TreeNodeExtendCfg extendCfg) throws Exception {
		return getGDFTreeMgr().getADCInADFTree(adfId, extendCfg);
	}

	@Override
	public List<TreeNode> queryCdcInCdfTree(String cdfId, TreeNodeExtendCfg extendCfg) throws Exception {
		return getGDFTreeMgr().getCDCInCDFTree(cdfId, extendCfg);
	}

	@Override
	public TreeNode queryTreeNode(String id) throws Exception {
		return getGDFTreeMgr().getTreeNode(id);
	}

	@Override
	public List<TreeNode> queryProductRequirementTreeByPdf(String pdfId) throws Exception {
		return getGDFTreeMgr().getProductRequirementTreeByPdf(pdfId);
	}

	@Override
	public List<TreeNode> queryPDFInJob(String jobId, TreeNodeExtendCfg extendCfg) throws Exception {
		return getGDFTreeMgr().getPDFInJob(jobId, extendCfg);
	}

	@Override
	public List<TreeNode> queryDomainTree() throws Exception {
		return getGDFTreeMgr().getDomainTree();
	}

	@Override
	public List<TreeNode> queryUserGroupTree() throws Exception {
		return getGDFTreeMgr().getUserGroupTree();
	}

	@Override
	public List<TreeNode> querySUDFTree(TreeNodeExtendCfg extendCfg) throws Exception {
		return getGDFTreeMgr().getSUDFTree(extendCfg);
	}

	@Override
	public List<GDFCatalog> queryAllChildCatalog(String id, String keyWord, NameValuePair nvQuery) throws Exception {
		return getGDFTreeMgr().queryAllChildCatalog(id, keyWord, nvQuery);
	}

	@Override
	public List<GDFCatalog> queryAllChildCatalog(String id) throws Exception {
		return getGDFTreeMgr().getAllChildCatalog(id);
	}

	@Override
	public GDFCatalog querySupportProductlineCatalog() throws Exception {
		return getGDFTreeMgr().getSupportProductlineCatalog();
	}

	@Override
	public GDFCatalog queryChildRealMoIdCatalogInStyle(String catalogStyle, String realMoId) throws Exception {
		return getGDFTreeMgr().getChildRealMoIdCatalogInStyle(catalogStyle, realMoId);
	}

	@Override
	public GDFCatalog queryWorkShopCatalogByGrandson(GDFCatalog catalog)
			throws RemoteException, McException, Exception {
		return getGDFTreeMgr().getWorkShopCatalogByGrandson(catalog);
	}

	@Override
	public GDFCatalog queryDCDesignCatalog(GDFCatalog workshopCtl) throws Exception {
		return getGDFTreeMgr().getDCDesignCatalog(workshopCtl);
	}

	@Override
	public GDFCatalog queryAncestorCatalog(String id, String ancestorNodeType) throws Exception {
		return getGDFTreeMgr().getAncestorCatalog(id, ancestorNodeType);
	}

	@Override
	public List<GDFCatalog> queryChildCatalog(String id) throws Exception {
		return getGDFTreeMgr().getChildCatalog(id);
	}

	@Override
	public GDFCatalog queryStationProductlineCatalog() throws Exception {
		return getGDFTreeMgr().getStationProductlineCatalog();
	}

	@Override
	public GDFCatalog querySpeacialUseCodeCatalog(GDFCatalog workshopCtl) throws Exception {
		return getGDFTreeMgr().getSpeacialUseCodeCatalog(workshopCtl);
	}

	@Override
	public ProductDesign queryProductDesign(String id) throws Exception {
		return getGDFTreeMgr().getProductDesign(id);
	}

	@Override
	public GDFCatalog queryCatalogByRealMoIdAndType(String realMoId, String type) throws Exception {
		return getGDFTreeMgr().getCatalogByRealMoIdAndType(realMoId, type);
	}

	@Override
	public ProductlineTemplateImportData queryProductlineTemplateImportData(String uuid) throws Exception {
		return getGDFTreeMgr().getProductlineTemplateImportData(uuid);
	}

	@Override
	public List<TreeNode> queryPDCInPDFTree(String pdfId, TreeNodeExtendCfg extendCfg) throws Exception {
		return getGDFTreeMgr().getPDCInPDFTree(pdfId, extendCfg);
	}
	
	@Override
	public List<TreeNode> queryRelRequirementTree(String workshopCtlId) throws Exception {
		return getGDFTreeMgr().getRelRequirementTree(workshopCtlId);
	}
	
	@Override
	public MultiPageResultDto<TreeNode> queryJobStasticTree(String keyWord, List<OrderBy> orderBy, int startPos,
			int pageSize) throws Exception {
		OrderByPair order = OrderBy.toOrderBy(orderBy);
		MultiPageResult<TreeNode> jobStasticTree = getGDFTreeMgr().getJobStasticTree(keyWord, order, startPos, pageSize);
		MultiPageResultDto<TreeNode> lstResultDto = new MultiPageResultDto<TreeNode>();
		lstResultDto.setTotal(jobStasticTree.getTotalCount());
		lstResultDto.setTableData(jobStasticTree.getListData());
		return lstResultDto;
		
	}

	@Override
	public List<ControllerDto> queryProductlineTemplateByProductLineConfig(String uuid) throws Exception {
//		List<com.leavay.ms.dcs.dto.ControllerDto> lstControllerDtos = getGDFTreeMgr().getProductlineTemplateByProductLineConfig(uuid);
//		return BaseDtoUtil.getMe().transformObjects(lstControllerDtos, v->toDto(v, ControllerDto.class));
		GDFCatalog ctl = queryCatalogByUuid(uuid);
		if(ctl == null)
			throw DCExceptionUtils.treeNodeNotFound(uuid);
		GDFCatalog pCtl = queryAncestorCatalog(ctl.getId(), GdfTreeConst.NODE_TYPE_PRODUCT_DESIGN);
		ProductDesign pd = queryProductDesign(pCtl.getRealMoRdn());
		List<String> tmpltIds = pd.getTemplateList();
		List<ProductLineTemplate> tmplts = getProductLineTemplateMgr().queryTemplateList(tmpltIds);
		return getIWebConfigMgr().getProductlineTemplateTableControllers(pd,tmplts);
	
	}	
	
	@Override
	public List<GDFCatalog> queryCdfCatalogListInWorkshop(GDFCatalog workshopCtl) throws Exception {
		return getGDFTreeMgr().listCdfCatalogInWorkshop(workshopCtl);
	}	
	
	@Override
	public List<TreeNode> queryPrivilegeTree() throws Exception {
		return getGDFTreeMgr().getPrivilegeTree();
	}
	
	@Override
	public GDFCatalog queryCatalog(String id) throws Exception {
		return getGDFTreeMgr().getCatalog(id);
	}
	
	@Override
	public GDFCatalog queryCommonUserCodeCatalog(GDFCatalog workshopCtl) throws Exception {
		return getGDFTreeMgr().getChildCatalogByType(workshopCtl.getId(), GdfTreeConst.NODE_TYPE_COMMON_USE_CODE);
	}
	
	@Override
	public List<TreeNode> queryWholePDCTree(TreeNodeExtendCfg extendCfg) throws Exception {
		return getGDFTreeMgr().getWholePDCTree(extendCfg);
	}
	
	@Override
	public GDFCatalog querySudfCatalogByName(String sudfName) throws Exception {
		SudfDto sudf = getSudfMgr().queryUdfByName(sudfName);
		List<GDFCatalog> lstCatalog = queryAllChildRealMoCatalogsInStyle(GdfTreeConst.CATALOG_STYLE_GDF,sudf.getId());
		if(!ToolUtilities.isCollectionEmpty(lstCatalog)) {
			return lstCatalog.get(0);
		}
		return null;
	}
	
	@Override
	public List<GDFCatalog> queryChildCatalog(String id, NameValuePair nvQuery, OrderByPair orderBy) throws Exception {
		return getGDFTreeMgr().getChildCatalog(id, nvQuery, orderBy);
	}
	
	@Override
	public GDFCatalog queryOrCreateCatalog(String pUuid, GDFCatalog catalog) throws Exception {
		return getGDFTreeMgr().getOrCreateCatalog(pUuid, catalog);
	}
	
	@Override
	public String queryPath(GDFCatalog ancestorCatalog, GDFCatalog catalog) throws Exception {
		return getGDFTreeMgr().getPath(ancestorCatalog, catalog);
	}
	
	@Override
	public GDFCatalog createCatalog(GDFCatalog catalog) throws Exception {
		return getGDFTreeMgr().createCatalog(catalog);
	}
	
	@Override
	public GDFCatalog moveCatalog(GDFCatalog catalog, GDFCatalog targetCatalog) throws Exception {
		return getGDFTreeMgr().moveCatalog(catalog, targetCatalog);
	}
	
	@Override
	public void deleteCatalogByUuid(String uuid) throws Exception {
		getGDFTreeMgr().deleteCatalogByUuid(uuid);
	}
	
	@Override
	public GDFCatalog queryRootCatalogByStyle(String catalogStyle) throws Exception {
		return getGDFTreeMgr().getRootCatalogByStyle(catalogStyle);
	}
	
	@Override
	public GDFCatalog moveCatalog(String catalogId, String targetCatalogId, List<String> orderUuids) throws Exception {
		return getGDFTreeMgr().moveCatalog(catalogId, targetCatalogId, orderUuids);
	}
	
	@Override
	public GDFCatalog queryAncestorCatalogByLevel(GDFCatalog catalog, int level) throws Exception {
		return getGDFTreeMgr().getAncestorCatalogByLevel(catalog, level);
	}
	
	@Override
	public MultiPageResultDto<GDFCatalog> queryPagingChildCatalog(String id, NameValuePair nvQuery, OrderByPair orderBy,
			int startPos, int pageSize) throws Exception {
		MultiPageResult<GDFCatalog> pageLst = getGDFTreeMgr().pagingChildCatalog(id, nvQuery, orderBy, startPos, pageSize);
		MultiPageResultDto<GDFCatalog> page = new MultiPageResultDto<GDFCatalog>();
		page.setTableData(pageLst.getListData());
		page.setTotal(pageLst.getTotalCount());
		return page;
	}

	@Override
	public List<GDFCatalog> sortChildrenCatalog(String uuid, String type) throws Exception {
		GDFCatalog root = queryCatalogByUuid(uuid);
		if(root == null)
			throw DCExceptionUtils.treeNodeNotFound(uuid);
		List<GDFCatalog> childLst = queryChildCatalog(root.getId());
		if(com.leavay.common.util.ToolUtilities.isCollectionEmpty(childLst))
			return new ArrayList<>();
		boolean flag = com.leavay.common.util.ToolUtilities.isStringEqual(GdfTreeConst.NODE_SORT_ASC, type);
		if(flag) {//升序
			Collections.sort(childLst, (o1, o2) -> {
				String o1Label = com.leavay.common.util.ToolUtilities.isStringEmpty(o1.getLabel())?o1.getName():o1.getLabel();
				String o2Label = com.leavay.common.util.ToolUtilities.isStringEmpty(o2.getLabel())?o2.getName():o2.getLabel();
				return o1Label.compareTo(o2Label);
			});
		}else {//降序
			Collections.sort(childLst, (o1, o2) -> {
				String o1Label = com.leavay.common.util.ToolUtilities.isStringEmpty(o1.getLabel())?o1.getName():o1.getLabel();
				String o2Label = com.leavay.common.util.ToolUtilities.isStringEmpty(o2.getLabel())?o2.getName():o2.getLabel();
				return o2Label.compareTo(o1Label);
			});
		}
		List<String> uuidLst = new ArrayList<>();
		for(GDFCatalog node : childLst) {
			uuidLst.add(node.getUuid());
		}
		BaseTreeNodeDtoProc<TreeNodeDto> proc = com.kwaidoo.tree.proc.TreeNodeV1Factory.getMe().createBaseTreeNodeDtoProc(BaseTreeNodeDtoProc.PARAM_SESSION_KEY, getSessionKey(), childLst.get(0).getNodeType());
		proc.dragNode(uuidLst.get(0),root.getUuid(),uuidLst);
		return childLst;

	}
}
