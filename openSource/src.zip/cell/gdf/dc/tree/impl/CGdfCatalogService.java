package cell.gdf.dc.tree.impl;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import cell.gdf.api.IApiService;
import cell.gdf.dc.tree.GDFTreeMgr;
import com.kwaidoo.dc.BaseDtoUtil;
import com.kwaidoo.dc.BaseSecurityMgr;
import com.kwaidoo.dc.config.dto.SudfDto;
import com.kwaidoo.dc.design.ProductLineTemplate;
import com.kwaidoo.dc.design.ProductlineTemplateImportData;
import com.kwaidoo.dc.story.dto.StoryDto;
import com.kwaidoo.dc.tree.mgr.GDFCatalog;
import com.kwaidoo.dc.tree.mgr.ProductDesign;
import com.kwaidoo.dc.tree.mgr.TreeNodeExtendCfg;
import com.kwaidoo.dc.tree.node.GdfTreeConst;
import com.kwaidoo.dc.tree.node.TreeNode;
import com.kwaidoo.ms.tool.ToolUtilities;
import com.kwaidoo.tree.dto.GdfCatalogDto;
import com.kwaidoo.tree.dto.TreeNodeDto;
import com.leavay.common.util.Pair;
import com.leavay.common.util.MultiPage.MultiPageResult;
import com.leavay.dc.dto.EnumItemDto;
import com.leavay.dc.exception.DCExceptionUtils;
import com.leavay.dc.setting.Story;
import com.leavay.model.exception.McException;
import com.leavay.model.inf.filter.NameValuePair;
import com.leavay.model.inf.sort.OrderByPair;

import cell.gdf.dc.tree.IGdfCatalogService;
import cell.gdf.design.IProductLineTemplateService;
import cell.gdf.develop.ISudfService;
import cell.gdf.webframe.IWebConfigService;
import web.dto.ControllerDto;
import web.dto.MultiPageResultDto;
import web.vo.OrderBy;

public class CGdfCatalogService extends BaseSecurityMgr implements IGdfCatalogService{
	
	private com.kwaidoo.dc.tree.mgr.GDFTreeMgr getGDFTreeMgr() throws Exception {
		return getDCSAPIUtils().getGDFTreeMgr();
	}
	
	private ISudfService getSudfMgr() throws Exception {
		return getApiUtils().getMgr(ISudfService.class);
	}
	
	private IProductLineTemplateService getProductLineTemplateMgr() throws Exception {
		return getApiUtils().getMgr(IProductLineTemplateService.class);
	}
	
	private IWebConfigService getIWebConfigMgr() throws Exception {
		return getApiUtils().getMgr(IWebConfigService.class);
	}
	
	private GdfCatalogDto toDto(GDFCatalog catalog) throws Exception {
		return BaseDtoUtil.getMe().toDto(catalog);
	}
	
	private GDFCatalog fromDto(GdfCatalogDto catalog) throws Exception {
		return BaseDtoUtil.getMe().fromDto(catalog);
	}
	
	private StoryDto toDto(Story story) throws Exception {
		return BaseDtoUtil.getMe().toDto(story);
	}
	
	private Story fromDto(StoryDto story) throws Exception {
		return BaseDtoUtil.getMe().fromDto(story);
	}

	@Override
	public MultiPageResultDto<GdfCatalogDto> queryPagingChildCatalog(String id, NameValuePair nvQuery,
			OrderByPair orderBy, int startPos, int pageSize) throws Exception {
		MultiPageResult<GDFCatalog> pageLst = getGDFTreeMgr().pagingChildCatalog(id, nvQuery, orderBy, startPos, pageSize);
		MultiPageResultDto<GdfCatalogDto> page = new MultiPageResultDto<GdfCatalogDto>();
		List<GDFCatalog> catalogLst = pageLst.getListData();
		List<GdfCatalogDto> catalogDtoLst = new ArrayList<>();
		for(GDFCatalog catalog : catalogLst) {
			GdfCatalogDto catalogDto = toDto(catalog);
			catalogDtoLst.add(catalogDto);
		}
		page.setTableData(catalogDtoLst);
		page.setTotal(pageLst.getTotalCount());
		return page;
	}

	@Override
	public GdfCatalogDto queryAncestorCatalogByLevel(GdfCatalogDto catalog, int level) throws Exception {
		GDFCatalog data = fromDto(catalog);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getAncestorCatalogByLevel(data, level));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto moveCatalog(String catalogId, String targetCatalogId, List<String> orderUuids)
			throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().moveCatalog(catalogId, targetCatalogId, orderUuids));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryRootCatalogByStyle(String catalogStyle) throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getRootCatalogByStyle(catalogStyle));
		return catalogDto;
	}

	@Override
	public void deleteCatalogByUuid(String uuid) throws Exception {
		getGDFTreeMgr().deleteCatalogByUuid(uuid);	
	}

	@Override
	public GdfCatalogDto moveCatalog(GdfCatalogDto catalog, GdfCatalogDto targetCatalog) throws Exception {
		GDFCatalog gdfCatalog = fromDto(catalog);
		GDFCatalog gdfTargetCatalog = fromDto(targetCatalog);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().moveCatalog(gdfCatalog, gdfTargetCatalog));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto createCatalog(GdfCatalogDto catalog) throws Exception {
		GDFCatalog gdfCatalog = fromDto(catalog);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().createCatalog(gdfCatalog));
		return catalogDto;
	}

	@Override
	public String queryPath(GdfCatalogDto ancestorCatalog, GdfCatalogDto catalog) throws Exception {
		GDFCatalog gdfAncestorCatalog = fromDto(ancestorCatalog);
		GDFCatalog gdfCatalog = fromDto(catalog);
		String path = getGDFTreeMgr().getPath(gdfAncestorCatalog, gdfCatalog);
		return path;
	}

	@Override
	public GdfCatalogDto queryOrCreateCatalog(String pUuid, GdfCatalogDto catalog) throws Exception {
		GDFCatalog gdfCatalog = fromDto(catalog);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getOrCreateCatalog(pUuid, gdfCatalog));
		return catalogDto;
	}

	@Override
	public List<GdfCatalogDto> queryChildCatalog(String id, NameValuePair nvQuery, OrderByPair orderBy)
			throws Exception {
		List<GDFCatalog> catalogLst = getGDFTreeMgr().getChildCatalog(id, nvQuery, orderBy);
		List<GdfCatalogDto> catalogDtoLst = new ArrayList<>();
		for(GDFCatalog i : catalogLst) {
			GdfCatalogDto catalogDto = toDto(i);
			catalogDtoLst.add(catalogDto);
		}
		return catalogDtoLst;
	}

	@Override
	public GdfCatalogDto querySudfCatalogByName(String sudfName) throws Exception {
		SudfDto sudf = getSudfMgr().queryUdfByName(sudfName);
		List<GdfCatalogDto> lstCatalog = queryAllChildRealMoCatalogsInStyle(GdfTreeConst.CATALOG_STYLE_GDF,sudf.getId());
		if(!ToolUtilities.isCollectionEmpty(lstCatalog)) {
			return lstCatalog.get(0);
		}
		return null;
	}



	@Override
	public GdfCatalogDto queryChildRealMoCatalog(String pCtlId, String childNodeType, String realMoId)
			throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getChildRealMoCatalog(pCtlId, childNodeType, realMoId));
		return catalogDto;
	}

	@Override
	public List<GdfCatalogDto> queryAllChildRealMoCatalogs(String sRDN, String childNodeType, String realMoId)
			throws Exception {
		List<GDFCatalog> catalogLst = getGDFTreeMgr().getAllChildRealMoCatalogs(sRDN, childNodeType, realMoId);
		List<GdfCatalogDto> catalogDtoLst = new ArrayList<>();
		for(GDFCatalog catalog : catalogLst) {
			GdfCatalogDto catalogDto = toDto(catalog);
			catalogDtoLst.add(catalogDto);
		}
		return catalogDtoLst;
	}

	@Override
	public List<GdfCatalogDto> queryAllChildRealMoCatalogsInStyle(String catalogStyle, String realMoId)
			throws Exception {
		List<GDFCatalog> catalogLst = getGDFTreeMgr().getAllChildRealMoCatalogsInStyle(catalogStyle, realMoId);
		List<GdfCatalogDto> catalogDtoLst = new ArrayList<>();
		for(GDFCatalog i : catalogLst) {
			GdfCatalogDto catalogDto = toDto(i);
			catalogDtoLst.add(catalogDto);
		}
		return catalogDtoLst;
	}

	@Override
	public boolean isEnableProductDesign(String uuid) throws Exception {
		return getGDFTreeMgr().isEnableProductDesign(uuid);
	}

	@Override
	public GdfCatalogDto queryCatalog(String id) throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getCatalog(id));
		return catalogDto;
	}



	@Override
	public List<GdfCatalogDto> queryCdfCatalogListInWorkshop(GdfCatalogDto workshopCtl) throws Exception {
		GDFCatalog catalog = fromDto(workshopCtl);
		List<GDFCatalog> catalogLst = getGDFTreeMgr().listCdfCatalogInWorkshop(catalog);
		List<GdfCatalogDto> catalogDtoLst = new ArrayList<>();
		for(GDFCatalog data : catalogLst) {
			GdfCatalogDto catalogDto = toDto(data);
			catalogDtoLst.add(catalogDto);
		}
		return catalogDtoLst;
	}

	@Override
	public List<ControllerDto> queryProductlineTemplateByProductLineConfig(String uuid) throws Exception {
		GdfCatalogDto ctl = queryCatalogByUuid(uuid);
		if(ctl == null)
			throw DCExceptionUtils.treeNodeNotFound(uuid);
		GdfCatalogDto pCtl = queryAncestorCatalog(ctl.getId(), GdfTreeConst.NODE_TYPE_PRODUCT_DESIGN);
		ProductDesign pd = queryProductDesign(pCtl.getRealMoRdn());
		List<String> tmpltIds = pd.getTemplateList();
		List<ProductLineTemplate> tmplts = getProductLineTemplateMgr().queryTemplateList(tmpltIds);
		return getIWebConfigMgr().getProductlineTemplateTableControllers(pd, tmplts);
	}


	@Override
	public ProductlineTemplateImportData queryProductlineTemplateImportData(String uuid) throws Exception {
		return getGDFTreeMgr().getProductlineTemplateImportData(uuid);
	}

	@Override
	public GdfCatalogDto queryCatalogByRealMoIdAndType(String realMoId, String type) throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getCatalogByRealMoIdAndType(realMoId, type));
		return catalogDto;
	}

	@Override
	public ProductDesign queryProductDesign(String id) throws Exception {
		return getGDFTreeMgr().getProductDesign(id);
	}

	@Override
	public GdfCatalogDto querySpeacialUseCodeCatalog(GdfCatalogDto workshopCtl) throws Exception {
		GDFCatalog catalog = fromDto(workshopCtl);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getSpeacialUseCodeCatalog(catalog));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryCommonUserCodeCatalog(GdfCatalogDto workshopCtl) throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getChildCatalogByType(workshopCtl.getId(), GdfTreeConst.NODE_TYPE_COMMON_USE_CODE));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryStationProductlineCatalog() throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getStationProductlineCatalog());
		return catalogDto;
	}

	@Override
	public List<GdfCatalogDto> queryChildCatalog(String id) throws Exception {
		List<GDFCatalog> catalogLst = getGDFTreeMgr().getChildCatalog(id);
		List<GdfCatalogDto> catalogDtoLst = new ArrayList<>();
		for(GDFCatalog i : catalogLst) {
			GdfCatalogDto catalogDto = toDto(i);
			catalogDtoLst.add(catalogDto);
		}
		return catalogDtoLst;
	}

	@Override
	public GdfCatalogDto queryAncestorCatalog(String id, String ancestorNodeType) throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getAncestorCatalog(id, ancestorNodeType));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryDCDesignCatalog(GdfCatalogDto workshopCtl) throws Exception {
		GDFCatalog data = fromDto(workshopCtl);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getDCDesignCatalog(data));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryWorkShopCatalogByGrandson(GdfCatalogDto catalog)
			throws RemoteException, McException, Exception {
		GDFCatalog data = fromDto(catalog);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getWorkShopCatalogByGrandson(data));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryChildRealMoIdCatalogInStyle(String catalogStyle, String realMoId) throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getChildRealMoIdCatalogInStyle(catalogStyle, realMoId));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto querySupportProductlineCatalog() throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getSupportProductlineCatalog());
		return catalogDto;
	}

	@Override
	public List<GdfCatalogDto> queryAllChildCatalog(String id) throws Exception {
		List<GDFCatalog> catalogLst = getGDFTreeMgr().getAllChildCatalog(id);
		List<GdfCatalogDto> catalogDtoLst = new ArrayList<>();
		for(GDFCatalog i : catalogLst) {
			GdfCatalogDto catalogDto = toDto(i);
			catalogDtoLst.add(catalogDto);
		}
		return catalogDtoLst;
	}

	@Override
	public List<GdfCatalogDto> queryAllChildCatalog(String id, String keyWord, NameValuePair nvQuery) throws Exception {
		List<GDFCatalog> catalogLst = getGDFTreeMgr().queryAllChildCatalog(id, keyWord, nvQuery);
		List<GdfCatalogDto> catalogDtoLst = new ArrayList<>();
		for(GDFCatalog i : catalogLst) {
			GdfCatalogDto catalogDto = toDto(i);
			catalogDtoLst.add(catalogDto);
		}
		return catalogDtoLst;
	}

	
	@Override
	public ProductDesign updateProductDesign(ProductDesign productDesign) throws Exception{
		ProductDesign pro = getGDFTreeMgr().updateProductDesign(productDesign);
		return pro;
	}
	
	@Override
	public void deleteProductDesign(String id) throws Exception{
		getGDFTreeMgr().deleteProductDesign(id);
	}

	@Override
	public GdfCatalogDto queryDistributeCatalog(GdfCatalogDto workshopCtl) throws Exception {
		GDFCatalog catalog = fromDto(workshopCtl);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getDistributeCatalog(catalog));
		return catalogDto;
	}

	
	
	
	@Override
	public GdfCatalogDto queryConfigCatalog(GdfCatalogDto workshopCtl) throws Exception {
		GDFCatalog catalog = fromDto(workshopCtl);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getConfigCatalog(catalog));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryDFDesignCatalog(GdfCatalogDto workshopCtl) throws Exception {
		GDFCatalog catalog = fromDto(workshopCtl);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getDFDesignCatalog(catalog));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryChildCatalogByName(String id, String name) throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getChildCatalogByName(id, name));
		return catalogDto;
	}
	
	@Override
	public GdfCatalogDto queryStoryCatalogByGrandson(GdfCatalogDto catalog) throws RemoteException, McException, Exception{
		GDFCatalog cata = fromDto(catalog);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getStoryCatalogByGrandson(cata));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryChildCatalogByType(String pId, String nodeType) throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getChildCatalogByType(pId, nodeType));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryCoreProductlineCatalog() throws Exception {	
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getCoreProductlineCatalog());
		return catalogDto;
	}

	@Override
	public void setJobStasticDirty() throws Exception{
		getGDFTreeMgr().setJobStasticDirty();
	}
	
	@Override
	public GdfCatalogDto queryCatalogByUuid(String uuid) throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getCatalogByUuid(uuid));
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryJobStasticRoot() throws Exception {
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().getJobStasticRoot());
		return catalogDto;
	}

	@Override
	public GdfCatalogDto updateCatalog(GdfCatalogDto catalog) throws Exception {
		GDFCatalog gdfcatalog = fromDto(catalog);
		GdfCatalogDto catalogDto = toDto(getGDFTreeMgr().updateCatalog(gdfcatalog));
		return catalogDto;
	}
	
	@Override
	public List<GdfCatalogDto> queryAllChildCatalogByType(String id, String nodeType, String nameFilter, OrderByPair orderBy)
			throws Exception{
		List<GDFCatalog> catalogLst = getGDFTreeMgr().getAllChildCatalogByType(id, nodeType, nameFilter, orderBy);
		List<GdfCatalogDto> catalogDtoLst = new ArrayList<>();
		for(GDFCatalog cata : catalogLst) {
			GdfCatalogDto catalogDto = toDto(cata);
			catalogDtoLst.add(catalogDto);
		}
		return catalogDtoLst;
	}
	
	@Override
	public Pair<String, byte[]> exportCdcsByCatalogs(List<String> ids) throws Exception {
		Pair<String, byte[]> export = getGDFTreeMgr().exportCdcsByCatalogs(ids);
		return export;
	}
	
	@Override
	public Pair<String, byte[]> exportAdcsByCatalogs(List<String> ids) throws Exception {
		Pair<String, byte[]> export = getGDFTreeMgr().exportAdcsByCatalogs(ids);
		return export;
	}
	
	@Override
	public Pair<String, byte[]> exportAdfsByCatalogs(List<String> ids) throws Exception{
		Pair<String, byte[]> export = getGDFTreeMgr().exportAdfsByCatalogs(ids);
		return export;
	}
	
	@Override
	public Pair<String, byte[]> exportAutoBuildByCatalogs(List<String> ids) throws Exception{
		Pair<String, byte[]> export = getGDFTreeMgr().exportAutoBuildByCatalogs(ids);
		return export;
	}

	@Override
	public Pair<String, byte[]> exportCdfByCatalogs(List<String> ids) throws Exception{
		Pair<String, byte[]> export = getGDFTreeMgr().exportCdfByCatalogs(ids);
		return export;
	}
	
	@Override
	public Pair<String, byte[]> exportPdfsByCatalogs(List<String> ids) throws Exception{
		Pair<String, byte[]> export = getGDFTreeMgr().exportPdfsByCatalogs(ids);
		return export;
	}
	
	@Override
	public Pair<String, byte[]> exportSdfByCatalogs(List<String> ids) throws Exception{
		Pair<String, byte[]> export = getGDFTreeMgr().exportSdfByCatalogs(ids);
		return export;
	}
	
	@Override
	public Pair<String, byte[]> exportJobsByCatalogs(List<String> ids) throws Exception{
		Pair<String, byte[]> export = getGDFTreeMgr().exportJobsByCatalogs(ids);
		return export;
	}
	@Override
	public Pair<String, byte[]> exportSudfByCatalogs(List<String> ids) throws Exception{
		Pair<String, byte[]> export = getGDFTreeMgr().exportSudfByCatalogs(ids);
		return export;
	}
	
	@Override
	public Pair<String, byte[]> exportProductDesignByCatalogs(List<String> ids) throws Exception{
		Pair<String, byte[]> export = getGDFTreeMgr().exportProductDesignByCatalogs(ids);
		return export;
	}
	
	@Override
	public Pair<String, byte[]> exportGDFCatalogsAndData(String id) throws Exception{
		Pair<String, byte[]> export = getGDFTreeMgr().exportGDFCatalogsAndData(id);
		return export;
	}

	@Override
	public ProductDesign createProductDesign(ProductDesign productDesign) throws Exception {
		return getGDFTreeMgr().createProductDesign(productDesign);
	}

	@Override
	public GdfCatalogDto queryViewAngleRoot() throws Exception {
		GDFCatalog catalog = getGDFTreeMgr().getViewAngleRoot();
		GdfCatalogDto catalogDto = toDto(catalog);
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryStoryCatalog(StoryDto story) throws Exception {
		GDFCatalog catalog = getGDFTreeMgr().getStoryCatalog(fromDto(story));
		GdfCatalogDto catalogDto = toDto(catalog);
		return catalogDto;
	}

	@Override
	public boolean isGrandsonCatalog(String parentId, String grandsonId) throws Exception {
		return getGDFTreeMgr().isGrandsonCatalog(parentId, grandsonId);
	}

	@Override
	public GdfCatalogDto queryCatalogByPath(GdfCatalogDto ancestorCatalog, String path) throws Exception {
		GDFCatalog catalog = getGDFTreeMgr().getCatalogByPath(fromDto(ancestorCatalog), path);
		GdfCatalogDto catalogDto = toDto(catalog);
		return catalogDto;
	}

	@Override
	public void deleteCatalog(String id) throws Exception {
		getGDFTreeMgr().deleteCatalog(id);
	}

	@Override
	public GdfCatalogDto createFunctionCatalog(String parentId, String functionNodeType) throws Exception {
		GDFCatalog catalog = getGDFTreeMgr().createFunctionCatalog(parentId, functionNodeType);
		GdfCatalogDto catalogDto = toDto(catalog);
		return catalogDto;
	}

	@Override
	public GdfCatalogDto queryDFDesignCatalogInWorkshop(GdfCatalogDto workshopCtl) throws Exception {
		return queryChildCatalogByType(workshopCtl.getId(), GdfTreeConst.NODE_TYPE_DF_DESIGN);
	}

	@Override
	public List<GdfCatalogDto> sortChildrenCatalogDto(String uuid, String type) throws Exception {
		GDFTreeMgr gdfTreeMgr = IApiService.get().getApiConn(getSessionKey()).getMgr(GDFTreeMgr.class);
		List<GDFCatalog> catalogList = gdfTreeMgr.sortChildrenCatalog(uuid, type);
		return BaseDtoUtil.getMe().transformObjects(catalogList,x-> toDto(x,GdfCatalogDto.class));
	}

	@Override
	public List<EnumItemDto> queryProductDesignCdcListByNode(String nodeUuid) throws Exception {
		return getGDFTreeMgr().getProductDesignCdcListByNode(nodeUuid);
	}
}
