package cell.gdf.dc.tree;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.kwaidoo.dc.design.ProductlineTemplateImportData;
import com.kwaidoo.dc.story.dto.StoryDto;
import com.kwaidoo.dc.tree.mgr.GDFCatalog;
import com.kwaidoo.dc.tree.mgr.ProductDesign;
import com.kwaidoo.dc.tree.mgr.TreeNodeExtendCfg;
import com.kwaidoo.dc.tree.node.TreeNode;
import com.kwaidoo.tree.dto.TreeNodeDto;
import com.kwaidoo.tree.proc.TreeNodeProcessorContext;
import com.leavay.dc.setting.Story;
import com.leavay.model.exception.McException;
import com.leavay.model.inf.filter.NameValuePair;
import com.leavay.model.inf.sort.OrderByPair;

import bap.cells.Cells;
import cell.web.SessionCellIntf;
import web.dto.ControllerDto;
import web.dto.MultiPageResultDto;
import web.vo.OrderBy;

public interface GDFTreeMgr extends SessionCellIntf {

	public static GDFTreeMgr get(String sessionKey) {
		return Cells.get(GDFTreeMgr.class, sessionKey);
	}
	
	/**
	 * 获取对应目录的子目录分页结果
	 * @param id
	 * @param nvQuery
	 * @param orderBy
	 * @param startPos
	 * @param pageSize
	 * @return
	 * @throws Exception
	 */
	public MultiPageResultDto<GDFCatalog> queryPagingChildCatalog(String id,NameValuePair nvQuery,OrderByPair orderBy,int startPos,int pageSize) throws Exception ;
	
	/**
	 * 根据祖宗级别，获取祖宗节点目录
	 *
	 * @param catalog 目录id
	 * @param level   祖宗级别（如：1为GDF，2为对应的产线集，以此类推）
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryAncestorCatalogByLevel(GDFCatalog catalog, int level) throws Exception;
	
	/**
	 * 移动目录到指定的父目录底下
	 *
	 * @param catalogId       需要移动的指定的目录id
	 * @param targetCatalogId 目标的父目录的id
	 * @param orderUuids      移动后，对应父目录底下的一级子目录的排列顺序
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog moveCatalog(String catalogId, String targetCatalogId, List<String> orderUuids) throws Exception;
	
	/**
	 * 获取指定目录类型的根目录
	 *
	 * @param catalogStyle 目录类型
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryRootCatalogByStyle(String catalogStyle) throws Exception;
	
	/**
	 * 指定目录的uuid，删除目录
	 *
	 * @param uuid 目录的uuid
	 * @throws Exception
	 */
	public void deleteCatalogByUuid(String uuid) throws Exception;
	
	/**
	 * 移动目录到指定父目录底下
	 *
	 * @param catalog       需要移动的指定目录
	 * @param targetCatalog 目标的父目录
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog moveCatalog(GDFCatalog catalog, GDFCatalog targetCatalog) throws Exception;
	
	/**
	 * 创建一个目录
	 *
	 * @param catalog 目录 GDFCatalog cata=new GDFCatalog(); cata.setId(id);
	 *                cata.setNodeType(nodeType); cata.setName(name);
	 *                cata.setParentId(parentId);
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog createCatalog(GDFCatalog catalog) throws Exception;
	
	/**
	 * 获取从祖宗目录到子目录的完整路径
	 *
	 * @param ancestorCatalog 祖宗目录
	 * @param catalog         子目录
	 * @return
	 * @throws Exception
	 */
	public String queryPath(GDFCatalog ancestorCatalog, GDFCatalog catalog) throws Exception;
	
	/**
	 * 获取或创建指定的目录
	 *
	 * @param pUuid   父节点目录的uuid
	 * @param catalog 指定的目录
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryOrCreateCatalog(String pUuid, GDFCatalog catalog) throws Exception;

	
	/**
	 * 根据条件获取对应目录的子目录（只获取一级子目录）
	 * @param id
	 * @param nvQuery
	 * @param orderBy
	 * @return
	 * @throws Exception
	 */
	public List<GDFCatalog> queryChildCatalog(String id, NameValuePair nvQuery, OrderByPair orderBy) throws Exception;
	
	
	/**
	 *  根据sudfName获取对应的树节点
	 * 
	 * @param sudfName
	 * @return
	 * @throws Exception
	 */
	GDFCatalog querySudfCatalogByName(String sudfName) throws Exception;
	
	
	/**
	 * 获取所有的PDC树结构
	 *
	 * @param extendCfg 自定义的拓展类
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryWholePDCTree(TreeNodeExtendCfg extendCfg) throws Exception;
	
	/**
	 * 在指定父目录id下查找符合子节点类型和数据id的目录
	 *
	 * @param pCtlId        指定目录id
	 * @param childNodeType 子节点类型
	 * @param realMoId      数据id
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryChildRealMoCatalog(String pCtlId, String childNodeType, String realMoId) throws Exception;
	
	/**
	 * 指定节点类型、父节点id 获取所有子节点目录
	 *
	 * @param sRDN          父节点的id
	 * @param childNodeType 需要获取的子节点类型
	 * @param realMoId
	 * @return
	 * @throws Exception
	 */
	public List<GDFCatalog> queryAllChildRealMoCatalogs(String sRDN, String childNodeType, String realMoId)
			throws Exception;
	
	/**
	 * 获取指定目录的所有子节点
	 *
	 * @param catalogStyle 目录类型（如GDF、COMMON）
	 * @param realMoId     指定目录的mo的id
	 * @return
	 * @throws Exception
	 */
	public List<GDFCatalog> queryAllChildRealMoCatalogsInStyle(String catalogStyle, String realMoId) throws Exception;
	
	/**
	 * 产品线设计是否启用产品设计流程
	 * @param nodeUuid	选择的目录树节点id
	 * @return
	 * @throws Exception
	 */
	public boolean isEnableProductDesign(String uuid)throws Exception;
	
	/**
	 * 根据目录id获取到GDF的目录
	 *
	 * @param id 目录的id
	 * @return 目录对象
	 * @throws Exception
	 */
	public GDFCatalog queryCatalog(String id) throws Exception;
	
	
	/**
	 * 获取权限的树结构
	 *
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryPrivilegeTree() throws Exception;
	
	/**
	 * 获取指定车间下的所有CDF的目录列表
	 *
	 * @param workshopCtl 指定的车间目录
	 * @return
	 * @throws Exception
	 */
	public List<GDFCatalog> queryCdfCatalogListInWorkshop(GDFCatalog workshopCtl) throws Exception;

	/**
	 * 从产线配置获取对应的产线模板配置信息
	 *
	 * @param uuid 产线配置的uuid
	 * @return
	 * @throws Exception
	 */
	public List<ControllerDto> queryProductlineTemplateByProductLineConfig(String uuid) throws Exception;
	
	/**
	 * 获取调度流的树结构
	 *
	 * @param keyWord  调度流的id（传null时默认为根节点）
	 * @param orderBy  排列顺序
	 * @param startPos 开始
	 * @param pageSize 分页数量
	 * @return
	 * @throws Exception
	 */
	public MultiPageResultDto<TreeNode> queryJobStasticTree(String keyWord, List<OrderBy> orderBy, int startPos, int pageSize)
			throws Exception;
	
	/**
	 * 获取相应车间下的关联需求目录树
	 * @param workshopCtlId
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryRelRequirementTree(String workshopCtlId)throws Exception;
	
	/**
	 * 获取指定PDF上的PDC树结构
	 *
	 * @param pdfId     PDF的id
	 * @param extendCfg 自定义的拓展类
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryPDCInPDFTree(String pdfId, TreeNodeExtendCfg extendCfg) throws Exception;
	
	/**
	 * 获取产线模板的导入数据
	 *
	 * @param uuid 产线模板的uuid
	 * @return
	 * @throws Exception
	 */
	public ProductlineTemplateImportData queryProductlineTemplateImportData(String uuid) throws Exception;
	
	
	 GDFCatalog queryCatalogByRealMoIdAndType(String realMoId,String type) throws Exception;
	
	/**
	 * 通过id获取到对应的产品设计
	 *
	 * @param id 产品设计的id
	 * @return 产品设计
	 * @throws Exception
	 */
	 ProductDesign queryProductDesign(String id) throws Exception;
	
	/**
	 * 获取指定车间的专用代码的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	 GDFCatalog querySpeacialUseCodeCatalog(GDFCatalog workshopCtl) throws Exception;
	 
	 /**
	  * 获取指定车间的通用代码的目录
	  * 
	 * @param workshopCtl
	 * @return
	 * @throws Exception
	 */
	GDFCatalog queryCommonUserCodeCatalog(GDFCatalog workshopCtl) throws Exception;
	
	/**
	 * 获取通用工位集的目录
	 *
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryStationProductlineCatalog() throws Exception;
	
	/**
	 * 获取对应目录的子目录（只获取一级子目录）
	 *
	 * @param id 目录的id
	 * @return
	 * @throws Exception
	 */
	public List<GDFCatalog> queryChildCatalog(String id) throws Exception;

	/**
	 * 指定祖宗目录的节点类型，获取祖宗节点目录
	 *
	 * @param id               目录id
	 * @param ancestorNodeType 祖宗节点的节点类型（如：GdfTreeConst.NODE_TYPE_SDF）
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryAncestorCatalog(String id, String ancestorNodeType) throws Exception;

	/**
	 * 获取指定车间的DC设计的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryDCDesignCatalog(GDFCatalog workshopCtl) throws Exception;

	/**
	 * 通过孙子节点目录找到对应的车间目录
	 *
	 * @param catalog 指定的孙子节点目录
	 * @return
	 * @throws RemoteException
	 * @throws McException
	 * @throws Exception
	 */
	public GDFCatalog queryWorkShopCatalogByGrandson(GDFCatalog catalog) throws RemoteException, McException, Exception;

	/**
	 * 获取指定style下指定数据id对应的子目录，适用于数据id只挂载一个数据目录的场景
	 *
	 * @param catalogStyle 目录style
	 * @param realMoId     数据id
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryChildRealMoIdCatalogInStyle(String catalogStyle, String realMoId) throws Exception;

	/**
	 * 获取支撑产线集的目录
	 *
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog querySupportProductlineCatalog() throws Exception;

	/**
	 * 获取对应目录的所有子目录
	 * 
	 * @param id
	 * @param keyWord
	 * @param nvQuery
	 * @return
	 * @throws Exception
	 */
	public List<GDFCatalog> queryAllChildCatalog(String id) throws Exception;

	public List<GDFCatalog> queryAllChildCatalog(String id, String keyWord, NameValuePair nvQuery) throws Exception;

	/**
	 * 获取SUDF的树结构
	 *
	 * @param extendCfg 树节点的配置（可传null）
	 * @return SUDF的树结构
	 * @throws Exception
	 */
	public List<TreeNode> querySUDFTree(TreeNodeExtendCfg extendCfg) throws Exception;

	/**
	 * 获取用户组的树结构
	 *
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryUserGroupTree() throws Exception;

	/**
	 * 获取数据域的树
	 *
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryDomainTree() throws Exception;

	/**
	 * 获取Job中的PDF列表
	 *
	 * @param jobId     job的id
	 * @param extendCfg 自定义的拓展类
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryPDFInJob(String jobId, TreeNodeExtendCfg extendCfg) throws Exception;

	/**
	 * 获取产品需求模型目录树
	 * 
	 * @param pdfId
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryProductRequirementTreeByPdf(String pdfId) throws Exception;

	/**
	 * 获取树节点
	 *
	 * @param id 节点的id
	 * @return
	 * @throws Exception
	 */
	public TreeNode queryTreeNode(String id) throws Exception;

	/**
	 * 获取指定CDF树上的CDC子节点
	 *
	 * @param cdfId     CDF节点的id
	 * @param extendCfg 自定义的拓展类
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryCdcInCdfTree(String cdfId, TreeNodeExtendCfg extendCfg) throws Exception;

	/**
	 * 获取指定ADF树上的ADC子节点
	 *
	 * @param adfId     ADF节点的id
	 * @param extendCfg 自定义的拓展类
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryAdcInAdfTree(String adfId, TreeNodeExtendCfg extendCfg) throws Exception;

	/**
	 * 更新树节点
	 *
	 * @param node 指定的节点
	 * @return
	 * @throws Exception
	 */
	public TreeNode updateTreeNode(TreeNode node) throws Exception;

	/**
	 * 删除树节点
	 *
	 * @param nodeId 节点的id
	 * @throws Exception
	 */
	public void deleteTreeNode(String nodeId) throws Exception;

	/**
	 * 创建节点
	 * 
	 * @param node
	 * @return
	 * @throws Exception
	 */
	public TreeNode createTreeNode(TreeNode node) throws Exception;

	/**
	 * 获取核心产线集的目录树
	 *
	 * @param lazyLoad 是否懒加载
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryCoreProductLineTree(boolean lazyLoad) throws Exception;

	/**
	 * 获取子节点的树结构
	 *
	 * @param id       子节点的id
	 * @param lazyLoad 是否懒加载
	 * @return
	 * @throws Exception
	 */
	public List<TreeNode> queryChildTreeNodeList(String id, boolean lazyLoad) throws Exception;

	/**
	 * 获取指定车间的发布的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryDistributeCatalog(GDFCatalog workshopCtl) throws Exception;

	/**
	 * 获取指定车间的配置的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryConfigCatalog(GDFCatalog workshopCtl) throws Exception;

	/**
	 * 获取指定车间的DF设计的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryDFDesignCatalog(GDFCatalog workshopCtl) throws Exception;

	
	/**
	 * 通过子目录的名称找到对应的子目录
	 *
	 * @param id   目录id
	 * @param name 子目录的名称
	 * @return 子目录
	 * @throws Exception
	 */
	public GDFCatalog queryChildCatalogByName(String id, String name) throws Exception;

	/**
	 * 获取指定目录下指定类型的儿子或孙子目录，适用于查询指定类型只有一个目录的场景
	 *
	 * @param pId      指定的目录id
	 * @param nodeType 节点类型
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryChildCatalogByType(String pId, String nodeType) throws Exception;

	/**
	 * 获取核心产线集的目录
	 *
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryCoreProductlineCatalog() throws Exception;


	/**
	 * 通过uuid获取到对应目录
	 *
	 * @param uuid 目录的uuid
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryCatalogByUuid(String uuid) throws Exception;

	/**
	 * 获取job的根节点的目录
	 *
	 * @return
	 * @throws Exception
	 */
	public GDFCatalog queryJobStasticRoot() throws Exception;

	/**
	 *
	 * @param uuid
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public List<GDFCatalog> sortChildrenCatalog(String uuid, String type) throws Exception;

}
