package cell.gdf.dc.tree;

import java.rmi.RemoteException;
import java.util.List;

import com.kwaidoo.dc.design.ProductlineTemplateImportData;
import com.kwaidoo.dc.story.dto.StoryDto;
import com.kwaidoo.dc.tree.mgr.GDFCatalog;
import com.kwaidoo.dc.tree.mgr.ProductDesign;
import com.kwaidoo.tree.dto.GdfCatalogDto;
import com.leavay.common.util.Pair;
import com.leavay.dc.dto.EnumItemDto;
import com.leavay.model.exception.McException;
import com.leavay.model.inf.filter.NameValuePair;
import com.leavay.model.inf.sort.OrderByPair;

import bap.cells.Cells;
import cell.web.SessionCellIntf;
import web.dto.ControllerDto;
import web.dto.MultiPageResultDto;

public interface IGdfCatalogService extends SessionCellIntf{
	
	public static IGdfCatalogService get(String sessionKey) {
		return Cells.get(IGdfCatalogService.class, sessionKey);
	}
	/**
	 * 获取对应目录的子目录分页结果
	 * @param id
	 * @param nvQuery
	 * @param orderBy
	 * @param startPos
	 * @param pageSize
	 * @return
	 * @throws Exception
	 */
	public MultiPageResultDto<GdfCatalogDto> queryPagingChildCatalog(String id,NameValuePair nvQuery,OrderByPair orderBy,int startPos,int pageSize) throws Exception ;

	/**
	 * 根据祖宗级别，获取祖宗节点目录
	 *
	 * @param catalog 目录id
	 * @param level   祖宗级别（如：1为GDF，2为对应的产线集，以此类推）
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryAncestorCatalogByLevel(GdfCatalogDto catalog, int level) throws Exception;
	
	/**
	 * 获取预览视图根节点的目录
	 *
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryViewAngleRoot() throws Exception;
	
	/**
	 * 移动目录到指定的父目录底下
	 *
	 * @param catalogId       需要移动的指定的目录id
	 * @param targetCatalogId 目标的父目录的id
	 * @param orderUuids      移动后，对应父目录底下的一级子目录的排列顺序
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto moveCatalog(String catalogId, String targetCatalogId, List<String> orderUuids) throws Exception;
	
	/**
	 * 获取指定目录类型的根目录
	 *
	 * @param catalogStyle 目录类型
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryRootCatalogByStyle(String catalogStyle) throws Exception;
	
	/**
	 * 指定目录的uuid，删除目录
	 *
	 * @param uuid 目录的uuid
	 * @throws Exception
	 */
	public void deleteCatalogByUuid(String uuid) throws Exception;
	
	/**
	 * 删除目录
	 *
	 * @param id 指定目录的id
	 * @throws Exception
	 */
	public void deleteCatalog(String id) throws Exception;
	
	/**
	 * 移动目录到指定父目录底下
	 *
	 * @param catalog       需要移动的指定目录
	 * @param targetCatalog 目标的父目录
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto moveCatalog(GdfCatalogDto catalog, GdfCatalogDto targetCatalog) throws Exception;
	
	/**
	 * 创建一个目录
	 *
	 * @param catalog 目录 GDFCatalog cata=new GDFCatalog(); cata.setId(id);
	 *                cata.setNodeType(nodeType); cata.setName(name);
	 *                cata.setParentId(parentId);
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto createCatalog(GdfCatalogDto catalog) throws Exception;
	
	/**
	 * 获取从祖宗目录到子目录的完整路径
	 *
	 * @param ancestorCatalog 祖宗目录
	 * @param catalog         子目录
	 * @return
	 * @throws Exception
	 */
	public String queryPath(GdfCatalogDto ancestorCatalog, GdfCatalogDto catalog) throws Exception;
	
	/**
	 * 根据指定的路径和祖宗目录，获取到对应的目录 如；核心产线集/电信成本ABC/设计/DF设计/分摊流程抽象/成本分摊流程 可获取到“成本分摊流程”的目录
	 *
	 * @param ancestorCatalog 祖宗目录
	 * @param path            对应的路径
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryCatalogByPath(GdfCatalogDto ancestorCatalog, String path) throws Exception;
	
	/**
	 * 获取或创建指定的目录
	 *
	 * @param pUuid   父节点目录的uuid
	 * @param catalog 指定的目录
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryOrCreateCatalog(String pUuid, GdfCatalogDto catalog) throws Exception;

	
	/**
	 * 创建功能节点目录
	 *
	 * @param parentId         父目录节点的id
	 * @param functionNodeType 功能节点类型
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto createFunctionCatalog(String parentId, String functionNodeType) throws Exception;
	
	/**
	 * 根据条件获取对应目录的子目录（只获取一级子目录）
	 * @param id
	 * @param nvQuery
	 * @param orderBy
	 * @return
	 * @throws Exception
	 */
	public List<GdfCatalogDto> queryChildCatalog(String id, NameValuePair nvQuery, OrderByPair orderBy) throws Exception;
	
	
	/**
	 *  根据sudfName获取对应的树节点
	 * 
	 * @param sudfName
	 * @return
	 * @throws Exception
	 */
	GdfCatalogDto querySudfCatalogByName(String sudfName) throws Exception;
	
	
	
	/**
	 * 在指定父目录id下查找符合子节点类型和数据id的目录
	 *
	 * @param pCtlId        指定目录id
	 * @param childNodeType 子节点类型
	 * @param realMoId      数据id
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryChildRealMoCatalog(String pCtlId, String childNodeType, String realMoId) throws Exception;
	
	/**
	 * 指定节点类型、父节点id 获取所有子节点目录
	 *
	 * @param sRDN          父节点的id
	 * @param childNodeType 需要获取的子节点类型
	 * @param realMoId
	 * @return
	 * @throws Exception
	 */
	public List<GdfCatalogDto> queryAllChildRealMoCatalogs(String sRDN, String childNodeType, String realMoId)
			throws Exception;
	
	/**
	 * 获取指定目录的所有子节点
	 *
	 * @param catalogStyle 目录类型（如GDF、COMMON）
	 * @param realMoId     指定目录的mo的id
	 * @return
	 * @throws Exception
	 */
	public List<GdfCatalogDto> queryAllChildRealMoCatalogsInStyle(String catalogStyle, String realMoId) throws Exception;
	
	/**
	 * 产品线设计是否启用产品设计流程
	 * @param nodeUuid	选择的目录树节点id
	 * @return
	 * @throws Exception
	 */
	public boolean isEnableProductDesign(String uuid)throws Exception;
	
	/**
	 * 根据目录id获取到GDF的目录
	 *
	 * @param id 目录的id
	 * @return 目录对象
	 * @throws Exception
	 */
	public GdfCatalogDto queryCatalog(String id) throws Exception;
	
	
	/**
	 * 获取指定车间下的所有CDF的目录列表
	 *
	 * @param workshopCtl 指定的车间目录
	 * @return
	 * @throws Exception
	 */
	public List<GdfCatalogDto> queryCdfCatalogListInWorkshop(GdfCatalogDto workshopCtl) throws Exception;

	/**
	 * 从产线配置获取对应的产线模板配置信息
	 *
	 * @param uuid 产线配置的uuid
	 * @return
	 * @throws Exception
	 */
	public List<ControllerDto> queryProductlineTemplateByProductLineConfig(String uuid) throws Exception;
	
	
	/**
	 * 获取产线模板的导入数据
	 *
	 * @param uuid 产线模板的uuid
	 * @return
	 * @throws Exception
	 */
	public ProductlineTemplateImportData queryProductlineTemplateImportData(String uuid) throws Exception;
	
	
	 GdfCatalogDto queryCatalogByRealMoIdAndType(String realMoId,String type) throws Exception;
	
	/**
	 * 通过id获取到对应的产品设计
	 *
	 * @param id 产品设计的id
	 * @return 产品设计
	 * @throws Exception
	 */
	 ProductDesign queryProductDesign(String id) throws Exception;
	
	/**
	 * 获取指定车间的专用代码的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	 GdfCatalogDto querySpeacialUseCodeCatalog(GdfCatalogDto workshopCtl) throws Exception;
	 
	 /**
	  * 获取指定车间的通用代码的目录
	  * 
	 * @param workshopCtl
	 * @return
	 * @throws Exception
	 */
	 GdfCatalogDto queryCommonUserCodeCatalog(GdfCatalogDto workshopCtl) throws Exception;
	
	/**
	 * 获取通用工位集的目录
	 *
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryStationProductlineCatalog() throws Exception;
	
	/**
	 * 获取对应目录的子目录（只获取一级子目录）
	 *
	 * @param id 目录的id
	 * @return
	 * @throws Exception
	 */
	public List<GdfCatalogDto> queryChildCatalog(String id) throws Exception;
	
	/**
	 * 新增产品设计
	 *
	 * @param productDesign 产品设计 ProductDesign pd=new ProductDesign(); pd.setId(id);
	 *                      pd.setName(name); pd.setLabel(label);
	 *                      pd.setCdcList(cdcList); pd.setRelateCdf(relateCdf);
	 *                      pd.setTemplateList(templateList);
	 * @return
	 * @throws Exception
	 */
	public ProductDesign createProductDesign(ProductDesign productDesign) throws Exception;

	/**
	 * 指定祖宗目录的节点类型，获取祖宗节点目录
	 *
	 * @param id               目录id
	 * @param ancestorNodeType 祖宗节点的节点类型（如：GdfTreeConst.NODE_TYPE_SDF）
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryAncestorCatalog(String id, String ancestorNodeType) throws Exception;

	/**
	 * 获取指定车间的DC设计的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryDCDesignCatalog(GdfCatalogDto workshopCtl) throws Exception;

	/**
	 * 通过孙子节点目录找到对应的车间目录
	 *
	 * @param catalog 指定的孙子节点目录
	 * @return
	 * @throws RemoteException
	 * @throws McException
	 * @throws Exception
	 */
	public GdfCatalogDto queryWorkShopCatalogByGrandson(GdfCatalogDto catalog) throws RemoteException, McException, Exception;

	/**
	 * 通过孙子节点的目录找到对应的Story目录（产线集）
	 *
	 * @param catalog 指定的孙子节点目录
	 * @return
	 * @throws RemoteException
	 * @throws McException
	 * @throws Exception
	 */
	public GdfCatalogDto queryStoryCatalogByGrandson(GdfCatalogDto catalog) throws RemoteException, McException, Exception;
	
	
	/**
	 * 判断该节点是不是parent的孙子节点
	 *
	 * @param parentId   目录节点的id
	 * @param grandsonId 孙子节点的id（判断对象）
	 * @return
	 * @throws Exception
	 */
	public boolean isGrandsonCatalog(String parentId, String grandsonId) throws Exception;
	
	/**
	 * 通过Story找到对应的目录
	 *
	 * @param story Story
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryStoryCatalog(StoryDto story) throws Exception;
	
	/**
	 * 获取指定style下指定数据id对应的子目录，适用于数据id只挂载一个数据目录的场景
	 *
	 * @param catalogStyle 目录style
	 * @param realMoId     数据id
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryChildRealMoIdCatalogInStyle(String catalogStyle, String realMoId) throws Exception;

	/**
	 * 获取支撑产线集的目录
	 *
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto querySupportProductlineCatalog() throws Exception;

	/**
	 * 获取对应目录的所有子目录
	 * 
	 * @param id
	 * @param keyWord
	 * @param nvQuery
	 * @return
	 * @throws Exception
	 */
	public List<GdfCatalogDto> queryAllChildCatalog(String id) throws Exception;

	public List<GdfCatalogDto> queryAllChildCatalog(String id, String keyWord, NameValuePair nvQuery) throws Exception;


	
	/**
	 * 删除产品设计
	 *
	 * @param id 产品设计的id
	 * @throws Exception
	 */
	public void deleteProductDesign(String id) throws Exception ;



	/**
	 * 获取指定车间的发布的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryDistributeCatalog(GdfCatalogDto workshopCtl) throws Exception;

	/**
	 * 获取指定车间的配置的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryConfigCatalog(GdfCatalogDto workshopCtl) throws Exception;
	
	

	/**
	 * 获取指定车间的DF设计的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryDFDesignCatalog(GdfCatalogDto workshopCtl) throws Exception;

	/**
	 * 设置Job监控视图的统计为脏数据，让Job监控视图进行同步更新
	 *
	 * @throws Exception
	 */
	public void setJobStasticDirty() throws Exception;
	
	/**
	 * 更新产品设计
	 *
	 * @param productDesign 产品设计 ProductDesign pd=new ProductDesign(); pd.setId(id);
	 *                      pd.setName(name); pd.setLabel(label);
	 *                      pd.setCdcList(cdcList); pd.setRelateCdf(relateCdf);
	 *                      pd.setTemplateList(templateList);
	 *
	 * @return 更新后的产品设计
	 * @throws Exception
	 */
	public ProductDesign updateProductDesign(ProductDesign productDesign) throws Exception;
	
	/**
	 * 通过子目录的名称找到对应的子目录
	 *
	 * @param id   目录id
	 * @param name 子目录的名称
	 * @return 子目录
	 * @throws Exception
	 */
	public GdfCatalogDto queryChildCatalogByName(String id, String name) throws Exception;

	/**
	 * 获取指定目录下指定类型的儿子或孙子目录，适用于查询指定类型只有一个目录的场景
	 *
	 * @param pId      指定的目录id
	 * @param nodeType 节点类型
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryChildCatalogByType(String pId, String nodeType) throws Exception;

	/**
	 * 获取核心产线集的目录
	 *
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryCoreProductlineCatalog() throws Exception;

	/**
	 * 通过uuid获取到对应目录
	 *
	 * @param uuid 目录的uuid
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryCatalogByUuid(String uuid) throws Exception;
	
	/**
	 * 更新指定目录
	 *
	 * @param catalog 目录
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto updateCatalog(GdfCatalogDto catalog) throws Exception;
	
	/**
	 * 通过查询条件获取到对应的子节点列表
	 *
	 * @param id         父节点的目录id
	 * @param nodeType   需要获取的子节点类型
	 * @param nameFilter 子节点名字
	 * @param orderBy    排列顺序
	 * @return
	 * @throws Exception
	 */
	public List<GdfCatalogDto> queryAllChildCatalogByType(String id, String nodeType, String nameFilter, OrderByPair orderBy)
			throws Exception;

	/**
	 * 获取job的根节点的目录
	 *
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryJobStasticRoot() throws Exception;
	
	/**
	 * 获取指定车间的DF设计的目录
	 *
	 * @param workshopCtl 车间目录
	 * @return
	 * @throws Exception
	 */
	public GdfCatalogDto queryDFDesignCatalogInWorkshop(GdfCatalogDto workshopCtl) throws Exception;
	
	/**
	 * 导出指定目录id下的CDC
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportCdcsByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定目录id下的ADC
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportAdcsByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定目录id下的ADF
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportAdfsByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定目录id下的自动构建
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportAutoBuildByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定目录id下的CDF
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportCdfByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定目录id下的PDF
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportPdfsByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定目录id下的SDF
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportSdfByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定目录id下的job
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportJobsByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定目录id下的SUDF
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportSudfByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定目录id下的产品设计
	 *
	 * @param ids 目录id列表
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportProductDesignByCatalogs(List<String> ids) throws Exception;
	
	/**
	 * 导出指定的GDF目录（不包含子节点）
	 *
	 * @param id GDF目录的id
	 * @return 导出的zip压缩包
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportGDFCatalogsAndData(String id) throws Exception;

	/**
	 *
	 * @param uuid 节点uuid
	 * @param type ASC或DESC
	 * @return
	 * @throws Exception
	 */
	public List<GdfCatalogDto> sortChildrenCatalogDto(String uuid, String type) throws Exception;

	/**
	 * 根据节点的ID获取产品线设计关联的具象工位列表
	 * @param nodeUuid
	 * @return
	 * @throws Exception
	 */
	public List<EnumItemDto> queryProductDesignCdcListByNode(String nodeUuid)throws Exception;
}
