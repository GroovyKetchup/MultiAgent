package cell.gdf.design;

import java.rmi.RemoteException;
import java.util.List;

import cell.web.SessionCellIntf;
import com.kwaidoo.dc.abstractive.dto.AdcDto;
import com.kwaidoo.dc.abstractive.dto.AdfDto;
import com.kwaidoo.dc.concrete.dto.CdcDto;
import com.kwaidoo.dc.concrete.dto.CdfDto;
import com.kwaidoo.dc.story.dto.StoryDto;
import com.leavay.common.util.Pair;

import bap.cells.Cells;
import web.dto.MultiPageResultDto;

public interface IAdcService extends SessionCellIntf {

	public static IAdcService get(String sessionKey) {
		return Cells.get(IAdcService.class, sessionKey);
	}

	public void ping() throws RemoteException;
	
	public String newAdcName()throws Exception;

	/**
	 * 在story上创建ADC
	 * 
	 * @param story story对象
	 * @param adc   ADC对象
	 * @return ADC对象
	 * @throws Exception
	 */
	public AdcDto createAdc(StoryDto story, AdcDto adc) throws Exception;

	/**
	 * 根据ADC的id获取ADC对象
	 * 
	 * @param adcId ADC的id
	 * @return ADC对象
	 * @throws Exception
	 */
	public AdcDto queryAdc(String adcId) throws Exception;

	public AdcDto queryAdcWithViewId(String id, String viewId) throws Exception;

	/**
	 * 根据ADC的名字获取ADC
	 * 
	 * @param adcName ADC的名字
	 * @return ADC对象
	 * @throws Exception
	 */
	public AdcDto queryAdcByName(String adcName) throws Exception;

	/**
	 * 通过CDC对象获取所属ADC对象
	 * 
	 * @param cdc CDC对象
	 * @return ADC对象
	 * @throws Exception
	 */
	public AdcDto queryBasicAdcOfCDC(CdcDto cdc) throws Exception;

	/**
	 * 更新ADC
	 * 
	 * @param adc ADC对象
	 * @return 更新后的ADC对象
	 * @throws Exception
	 */
	public AdcDto updateAdc(AdcDto adc) throws Exception;
	public AdcDto updateAdcWithViewId(AdcDto adc) throws Exception;

	/**
	 * 更名
	 * 
	 * @param adcName    ADC名称
	 * @param newAdcName 新的ADC名称
	 * @return 更名后的ADC对象
	 * @throws Exception
	 */
	public AdcDto renameAdc(String adcName, String newAdcName) throws Exception;

	/**
	 * 根据ADC的id删除ADC
	 * 
	 * @param adcId ADC的id
	 * @throws Exception
	 */
	public void deleteAdc(String adcId) throws Exception;

	/**
	 * 根据ADC的名称删除ADC
	 * 
	 * @param adcName ADC的名称
	 * @throws Exception
	 */
	public void deleteAdcByName(String adcName) throws Exception;

	/**
	 * 根据ADC ID列表获取ADC列表
	 * 
	 * @param adcIds ADC ID列表
	 * @return ADC对象列表
	 * @throws Exception
	 */
	public MultiPageResultDto<AdcDto> queryAdcList(List<String> adcIds) throws Exception;

	/**
	 * 获取系统所有的ADC
	 * 
	 * @return ADC列表
	 * @throws Exception
	 */
	public MultiPageResultDto<AdcDto> queryAllAdc() throws Exception;

	public List<String> queryAllAdcIdOfStory(StoryDto story) throws Exception;

	/**
	 * 获取story下的ADC列表
	 * 
	 * @param story story对象
	 * @return ADC列表
	 * @throws Exception
	 */
	public MultiPageResultDto<AdcDto> queryAllAdcOfStory(StoryDto story) throws Exception;

	/**
	 * 导出ADC数据包
	 * 
	 * @param adcIds 导出的ADC的ID列表
	 * @return 导出文件名和数据内容字节数组
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportAdc(List<String> adcIds) throws Exception;

	/**
	 * 创建ADF设计对象
	 * 
	 * @param story Story名称
	 * @param adf   ADF设计内容
	 * @return ADF对象
	 * @throws Exception
	 */
	public AdfDto createAdf(StoryDto story, AdfDto adf) throws Exception;

	/**
	 * 根据ADF的id获取ADF对象
	 * 
	 * @param adfId ADF的id
	 * @return ：ADF对象
	 * @throws Exception
	 */
	public AdfDto queryAdf(String adfId) throws Exception;
	public AdfDto queryAdfWithViewId(String id, String viewId) throws Exception;

	/**
	 * 根据ADF的名字获取ADF对象
	 * 
	 * @param adfName ADF的名字
	 * @return ADF对象
	 * @throws Exception
	 */
	public AdfDto queryAdfByName(String adfName) throws Exception;

	/**
	 * 根据ADF的ID列表获取ADF列表
	 * 
	 * @param adfIds ADF的ID列表
	 * @return ADF对象列表
	 * @throws Exception
	 */
	public MultiPageResultDto<AdfDto> queryAdfList(List<String> adfIds) throws Exception;

	public AdfDto queryAdfOfCdf(CdfDto cdf) throws Exception;

	public List<String> queryAdfIdOfStory(StoryDto story) throws Exception;

	/**
	 * 查询指定车间下的所有ADF集合
	 * 
	 * @param story Story对象
	 * @return ADF对象列表
	 * @throws Exception
	 */
	public MultiPageResultDto<AdfDto> queryAdfOfStory(StoryDto story) throws Exception;

	/**
	 * 更新ADF内容
	 * 
	 * @param adf ADF对象
	 * @return ADF对象
	 * @throws Exception
	 */
	public AdfDto updateAdf(AdfDto adf) throws Exception;
	public AdfDto updateAdfWithViewId(AdfDto adf) throws Exception;

	/**
	 * 删除ADF
	 *
	 * @param adf ADF对象
	 * @throws Exception
	 */
	public void deleteAdf(AdfDto adf) throws Exception;

	/**
	 * 删除ADF
	 * 
	 * @param adfId ADF的ID
	 * @throws Exception
	 */
	public void deleteAdf(String adfId) throws Exception;

	/**
	 * 删除Story下的所有ADF
	 * 
	 * @param story Story对象
	 * @throws Exception
	 */
	public void deleteAdfOfStory(StoryDto story) throws Exception;

	/**
	 * 删除ADF
	 * 
	 * @param adfName ADF的名称
	 * @throws Exception
	 */
	public void deleteAdfByName(String adfName) throws Exception;

	/**
	 * 导出ADF数据包
	 * 
	 * @param adfIds ADF ID列表
	 * @return 导出文件名和数据内容字节数组
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportAdf(List<String> adfIds) throws Exception;

}
