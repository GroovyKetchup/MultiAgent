package cell.gdf.design;

import java.util.List;

import com.kwaidoo.dc.abstractive.dto.AdcDto;
import com.kwaidoo.dc.abstractive.dto.AdfDto;
import com.kwaidoo.dc.concrete.dto.CdcDto;
import com.kwaidoo.dc.concrete.dto.CdfDto;
import com.kwaidoo.dc.config.dto.PdcDto;
import com.kwaidoo.dc.dto.BaseDto;
import com.kwaidoo.dc.dto.EnumItemDto;
import com.kwaidoo.dc.story.dto.StoryDto;
import com.leavay.common.util.Pair;

import bap.cells.Cells;
import cell.CellIntf;
import cell.web.SessionCellIntf;
import web.dto.MultiPageResultDto;

public interface ICdcService extends SessionCellIntf {

	public static ICdcService get(String sessionKey) {
		return Cells.get(ICdcService.class, sessionKey);
	}

	public void ping() throws Exception;

	/**
	 * 创建CDC
	 * 
	 * @param story    Story对象
	 * @param basicAdc 隶属的ADC对象
	 * @param cdc      新建的CDC对象
	 * @return 创建后的CDC对象
	 * @throws Exception
	 */
	public CdcDto createCdc(StoryDto story, AdcDto basicAdc, CdcDto cdc) throws Exception;

	/**
	 * 创建SQL映射配置CDC
	 * 
	 * @param story    Story对象
	 * @param basicAdc 隶属的ADC对象
	 * @param cdc      CDC对象
	 * @return 创建成功的CDC对象
	 * @throws Exception
	 */
	public CdcDto createSqlCdc(StoryDto story, AdcDto basicAdc, CdcDto cdc) throws Exception;

	/**
	 * 通过CDC的id获取CDC对象
	 * 
	 * @param cdcId CDC的id
	 * @return CDC对象
	 * @throws Exception
	 */
	public CdcDto queryCdc(String cdcId) throws Exception;
	public CdcDto queryCdcWithViewId(String id, String viewId) throws Exception;
	
	public CdcDto queryCdcCache(String cdcId)throws Exception;

	/**
	 * 通过CDC名称获取CDC对象
	 * 
	 * @param cdcName CDC名称
	 * @return CDC对象
	 * @throws Exception
	 */
	public CdcDto queryCdcByName(String cdcName) throws Exception;
	
	public CdcDto queryCdcCacheByName(String className)throws Exception;
	/**
	 * 通过类名获取CDC对象
	 * 
	 * @param cdcName CDC名称
	 * @return CDC对象
	 * @throws Exception
	 */
	public CdcDto queryCdcByClassName(String className) throws Exception;
	

	/**
	 * 通过PDC对象获取相应的CDC对象
	 * 
	 * @param pdc PDC对象
	 * @return CDC对象
	 * @throws Exception
	 */
	public CdcDto queryCdcByPdc(PdcDto pdc) throws Exception;

	/**
	 * 根据CDC的ID列表获取CDC列表
	 * 
	 * @param cdcIds CDC的ID列表
	 * @return CDC列表
	 * @throws Exception
	 */
	public MultiPageResultDto<CdcDto> queryCdcList(List<String> cdcIds) throws Exception;

	public List<String> queryCdcIdOfStory(StoryDto story) throws Exception;

	/**
	 * 获取Story下的所有CDC集合
	 * 
	 * @return CDC集合
	 * @throws Exception
	 */
	public MultiPageResultDto<CdcDto> queryCdcOfStory(StoryDto story) throws Exception;

	/**
	 * 获取平台中的所有CDC集合
	 * 
	 * @return CDC集合
	 * @throws Exception
	 */
	public MultiPageResultDto<CdcDto> queryCdcList() throws Exception;

	/**
	 * 以复写CDC属性列表的方式更新CDC对象，使用此方法将删除不在要复写的属性列表中的属性定义
	 * 
	 * @param cdc 要更新的CDC对象
	 * @return 更新成功的CDC对象
	 * @throws Exception
	 */
	public CdcDto updateCdc(CdcDto cdc) throws Exception;
	public CdcDto updateCdcWithViewId(CdcDto cdc) throws Exception;
	/**
	 * CDC重命名
	 * 
	 * @param cdcName    CDC的名称
	 * @param newCdcName 新的CDC名称
	 * @return CDC对象
	 * @throws Exception
	 */
	public CdcDto updateCdc(String cdcName, String newCdcName) throws Exception;

	/**
	 * 根据属性名称删除CDC中的属性
	 * 
	 * @param cdcName   CDC名称
	 * @param attrNames 属性名称集合
	 * @return CDC对象
	 * @throws Exception
	 */
	public CdcDto deleteAttribute(String cdcName, List<String> attrNames) throws Exception;

	/**
	 * 通过CDC的id删除CDC对象
	 * 
	 * @param cdcId CDC的id
	 * @throws Exception
	 */
	public void deleteCdc(String cdcId) throws Exception;

	/**
	 * 根据CDC名称删除CDC
	 * 
	 * @param cdcName CDC名称
	 * @throws Exception
	 */
	public void deleteCdcbyName(String cdcName) throws Exception;

	/**
	 * 导出CDC数据包
	 * 
	 * @param cdcIds CDC的ID列表
	 * @return 文件名和导出数据字节数组
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportCdc(List<String> cdcIds) throws Exception;

	/**
	 * 获取ADC相关的CDC集合
	 * 
	 * @param adc ADC对象
	 * @return CDC集合
	 * @throws Exception
	 */
	public MultiPageResultDto<CdcDto> queryCdcListOfAdc(AdcDto adc) throws Exception;

	/**
	 * 根据ADF对象创建CDF对象，创建的CDF只能加入ADF中的ADC对象创建的CDC对象
	 * 
	 * @param cdfName 要创建的CDF名称
	 * @param adf     ADF对象
	 * @return CDF对象
	 * @throws Exception
	 */
	public CdfDto createCdf(String cdfName, AdfDto adf) throws Exception;

	/**
	 * 创建CDF对象
	 * 
	 * @param cdf 内存中的CDF对象
	 * @return 创建成功的CDF对象
	 * @throws Exception
	 */
	public CdfDto createCdf(CdfDto cdf) throws Exception;

	/**
	 * 根据CDF的id获取CDF对象
	 * 
	 * @param cdfId
	 * @return CDF对象
	 * @throws Exception
	 */
	public CdfDto queryCdf(String cdfId) throws Exception;
	public CdfDto queryCdfWithViewId(String id, String viewId) throws Exception;

	public MultiPageResultDto<CdfDto> queryRelateCdfByCdf(List<String> cdcIds) throws Exception;

	/**
	 * 根据CDF的名称获取CDF对象
	 * 
	 * @param cdfName CDF名称
	 * @return CDF对象
	 * @throws Exception
	 */
	public CdfDto queryCdfByName(String cdfName) throws Exception;

	public CdfDto queryCdfByPDF(String pdfId) throws Exception;

	/**
	 * 根据CDF的ID获取CDF列表
	 * 
	 * @param cdfIds CDF的ID
	 * @return CDF对象列表
	 * @throws Exception
	 */
	public MultiPageResultDto<CdfDto> queryListByCdfs(List<String> cdfIds) throws Exception;

	/**
	 * 获取ADF相关的CDF集合
	 * 
	 * @param adf ADF对象
	 * @return CDF集合
	 * @throws Exception
	 */
	public MultiPageResultDto<CdfDto> queryCdfListOfAdf(AdfDto adf) throws Exception;

	public MultiPageResultDto<CdfDto> queryCdfListOfCdc(CdcDto cdc) throws Exception;

	public List<String> queryCDFIdsList(StoryDto story) throws Exception;

	/**
	 * 查询指定Story下的CDF集合
	 * 
	 * @param story Story对象
	 * @return CDF集合
	 * @throws Exception
	 */
	public MultiPageResultDto<CdfDto> queryCdfList(StoryDto story) throws Exception;

	/**
	 * 更新CDF
	 * 
	 * @param cdf CDF对象
	 * @return 更新的CDF对象
	 * @throws Exception
	 */
	public CdfDto updateCdf(CdfDto cdf) throws Exception;
	public CdfDto updateCdfWithViewId(CdfDto cdf) throws Exception;

	/**
	 * 删除CDF
	 * 
	 * @param cdfId CDF的ID
	 * @throws Exception
	 */
	public void deleteCdf(String cdfId) throws Exception;

	/**
	 * 删除CDF
	 * 
	 * @param cdf CDF对象
	 * @throws Exception
	 */
	public void deleteCdf(CdfDto cdf) throws Exception;

	/**
	 * 删除CDF对象
	 * 
	 * @param cdfName CDF的名称
	 * @throws Exception
	 */
	public void deleteCdfByName(String cdfName) throws Exception;

	/**
	 * 删除Story下的所有CDF
	 * 
	 * @param story Story对象
	 * @throws Exception
	 */
	public void deleteCdfOfStory(StoryDto story) throws Exception;

	/**
	 * 导出CDF数据包
	 * 
	 * @param cdfIds CDF的ID列表
	 * @return 文件名和导出数据字节数组
	 * @throws Exception
	 */
	public Pair<String, byte[]> exportCdf(List<String> cdfIds) throws Exception;
	
	public List<BaseDto> queryAllDCAttributeDataType() throws Exception;
	
	public List<EnumItemDto> querySUDFInputParams() throws Exception ;
	
	public List<EnumItemDto> querySUDFInputParams(String cdcId) throws Exception;

}
